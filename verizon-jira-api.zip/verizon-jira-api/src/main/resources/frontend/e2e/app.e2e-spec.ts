import { VerizonJiraUiPage } from './app.po';

describe('verizon-jira-ui App', () => {
  let page: VerizonJiraUiPage;

  beforeEach(() => {
    page = new VerizonJiraUiPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
