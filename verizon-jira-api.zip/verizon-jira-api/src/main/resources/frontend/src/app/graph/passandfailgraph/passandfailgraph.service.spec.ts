import { TestBed, inject } from '@angular/core/testing';

import { PassandfailgraphService } from './passandfailgraph.service';

describe('PassandfailgraphService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PassandfailgraphService]
    });
  });

  it('should ...', inject([PassandfailgraphService], (service: PassandfailgraphService) => {
    expect(service).toBeTruthy();
  }));
});
