import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import 'rxjs/add/operator/map';
@Injectable()
export class PassandfailgraphService {

public graphdataURL = "http://10.146.217.20:8082/api/APIWise_StatusCount"; 
  constructor(public http: Http) { }
createAuthorizationHeader(headers: Headers) {
    headers.append('Access-Control-Allow-Origin', '*'),     
    headers.append('Content-Type', 'application/json');
  }

  getgraphData() {    
      console.log(this.graphdataURL);
      return  this.http.get(this.graphdataURL).map(res=> res.json());     
    }

}
