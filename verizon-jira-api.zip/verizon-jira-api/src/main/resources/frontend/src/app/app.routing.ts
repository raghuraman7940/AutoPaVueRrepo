import { Routes, RouterModule } from '@angular/router';
import { loginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { IssuesComponent } from './issues/issues.component';
import { TestResultComponent } from './test-result/test-result.component';
import { GraphComponent } from './graph/graph.component';
import { MenuComponent } from './menu/menu.component';
import { SchedulerComponent } from './issues/scheduler/scheduler.component';
import { ReportComponent } from './test-result/report/report.component';
import { PassandfailgraphComponent } from './graph/passandfailgraph/passandfailgraph.component';
const appRoutes: Routes = [
    { path: '', component: loginComponent },
    {path: 'menu', component: MenuComponent },
    { path: 'dashboard', component: DashboardComponent },
    { path: 'issues', component: IssuesComponent },
    { path: 'scheduler', component: SchedulerComponent},
    { path: 'result', component: TestResultComponent }, 
    { path: 'report', component: ReportComponent },
    { path: 'graph', component: GraphComponent },  
    { path: '*', component: loginComponent },
    { path: 'passandfail', component: PassandfailgraphComponent }    
    
];

export const routing = RouterModule.forRoot(appRoutes); 