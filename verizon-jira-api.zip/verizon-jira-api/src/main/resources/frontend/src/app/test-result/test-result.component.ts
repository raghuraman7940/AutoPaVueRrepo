import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, } from '@angular/router';
import { TestResultService } from './test-result.service';
@Component({
  selector: 'app-test-result',
  templateUrl: './test-result.component.html',
  styleUrls: ['./test-result.component.css']
})
export class TestResultComponent implements OnInit {

 myName: string; 
 router:Router;
 results:any[]=[]; 
 result1:any; 
 responsekey:string;
currentIssue:any;
currentIssueIndex = 0;
  currentInputValues = [];
testcaseKeys:any
datas:any[]=[];
  constructor(private service:TestResultService ,router:Router) { 
    this.router=router;
    this.myName = localStorage.getItem('userName'); //to get the logged username  
    console.log('username'+ this.myName); 
    console.log("in dependent constructor ");
        if(this.myName == null)   //to redirect to home page for invalid access
        { this.router.navigate(['']);}
  }

  ngOnInit() {
             
    this.results = JSON.parse(localStorage.getItem('IssueDetail')); //to get the table data from the backend response     
     localStorage.removeItem('testdata');
    
  }

  // onResponseClick(key){               //for displaying ResponseString in the popup on clicking Response.
  //   this.responsekey = key;
  //   this.getCurrentResponseValues();
  // }

  // getCurrentResponseValues(){
       
  //     this.results.forEach((x, i) => {
  //     if (x.Response == this.responsekey){
  //       this.currentIssue = x.tests[this.currentIssueIndex];        
  //     }
  //     this.testcaseKeys = Object.keys(this.currentIssue);
  //   });
  // }

//To display the background color for status according to json data values(Pass or failed).
  getResultColor(val) {
                        if (val == "Pass") {
                          return "#c2eac2";                      
                        }

                        else if (val == "Failed") {
                          return "#f1afaf";
                        }
                        else if (val == "skipped") {
                          return "rgba(255, 255, 0, 0.4)";
                        }
                      }

 logout() {
              // remove user from local storage to log user out
              localStorage.removeItem('userName');
           }

loadresults(){
           document.getElementById('result').style.display='block';
           document.getElementById('fulldetails').style.display='none';
           document.getElementById('passeddetails').style.display='none';
           document.getElementById('faileddetails').style.display='none';
           document.getElementById('skippeddetails').style.display='none';
}

loadalltests(){               
          document.getElementById('result').style.display='none';
          document.getElementById('fulldetails').style.display='block' ;
          document.getElementById('passeddetails').style.display='none';
          document.getElementById('faileddetails').style.display='none';
          document.getElementById('skippeddetails').style.display='none';
}

loadpasseddata(){
           document.getElementById('result').style.display='none';
           document.getElementById('fulldetails').style.display='none';
           document.getElementById('passeddetails').style.display='block';
           document.getElementById('faileddetails').style.display='none';
           document.getElementById('skippeddetails').style.display='none';
}

loadfaileddata(){
           document.getElementById('result').style.display='none';
           document.getElementById('fulldetails').style.display='none';
           document.getElementById('passeddetails').style.display='none';
           document.getElementById('faileddetails').style.display='block';
           document.getElementById('skippeddetails').style.display='none';
}

loadskippeddata(){
           document.getElementById('result').style.display='none';
           document.getElementById('fulldetails').style.display='none';
           document.getElementById('passeddetails').style.display='none';
           document.getElementById('faileddetails').style.display='none';
           document.getElementById('skippeddetails').style.display='block';
}


}
