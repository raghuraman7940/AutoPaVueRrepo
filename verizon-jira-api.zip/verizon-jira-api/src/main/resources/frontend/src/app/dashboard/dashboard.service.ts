import { Injectable } from '@angular/core';
import { Http,Response,Headers,RequestOptionsArgs, RequestOptions,URLSearchParams } from "@angular/http";
import 'rxjs/add/operator/map';
//import {GlobalService} from "../global.service";


//let headers = new Headers();
@Injectable()
export class DashboardService {

  constructor(public http: Http) { }

  createAuthorizationHeader(headers: Headers) {
    headers.append('Access-Control-Allow-Origin', '*'),     
    headers.append('Content-Type', 'application/json');
  }

        public getProjectURL="http://10.146.217.20:8082/api/getProjects"; //ulr or Source file path to get the data
        public getIssueURL="http://10.146.217.20:8082/api/getIssueTypes"; //ulr or Source file path to get the data
        public getSprintURL="http://10.146.217.20:8082/api/getSprints"; //ulr or Source file path to get the data


        getProjects(){     //getting data from the above linked jsonfile or url

                let headers = new Headers();
                this.createAuthorizationHeader(headers);          
                return this.http.get(this.getProjectURL,headers).map(res => res.json());             
        
                     }

        getIssues(){         //getting data from the above linked jsonfile or url

          let headers = new Headers();
          this.createAuthorizationHeader(headers);
          console.log(this.getIssueURL);
          return this.http.get(this.getIssueURL).map(res => res.json());
                  }

        getSprints(){         //getting data from the above linked jsonfile or url

          let headers = new Headers();
          this.createAuthorizationHeader(headers);
          console.log(this.getSprintURL);
          return this.http.get(this.getSprintURL).map(res => res.json());
                    }  


next(projectname: string, issuetype: string, sprint:string,TestingType:string) {
        let headers = new Headers();
         this.createAuthorizationHeader(headers);
          return this.http.post('http://10.146.217.20:8082/api/getIssue', 
              JSON.stringify({ projectname: projectname, issuetype: issuetype, sprint: sprint,TestingType:TestingType}), headers)
              .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let issues= response.json();
                localStorage.setItem('myIssues',JSON.stringify(issues));
                localStorage.setItem('projectname',projectname);
                localStorage.setItem('issuetype',issuetype);
                localStorage.setItem('sprint',sprint);
                localStorage.setItem('TestingType',TestingType);
                return issues;
                
            });
     
}     
}