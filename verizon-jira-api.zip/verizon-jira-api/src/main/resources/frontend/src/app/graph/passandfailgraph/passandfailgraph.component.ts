import { Component, OnInit } from '@angular/core';
import { PassandfailgraphService } from './passandfailgraph.service'
import { Router, ActivatedRoute, } from '@angular/router';
@Component({
  selector: 'app-passandfailgraph',
  templateUrl: './passandfailgraph.component.html',
  styleUrls: ['./passandfailgraph.component.css']
})
export class PassandfailgraphComponent implements OnInit {

public graphdata: any;
myName: string;
router:Router;
  constructor(private RestApiService: PassandfailgraphService,router: Router) {
    this.router = router;

                      this.myName = localStorage.getItem('userName'); //to get the logged username  
                        //console.log('username'+ this.myName);
                            if(this.myName == null)        //to redirect to home page for invalid access
                            { this.router.navigate(['']);}
                                            
                      // binding global service to component(username binding to differnent component)
                        this.RestApiService=RestApiService;
  }

  ngOnInit() {

      this.getgraphData(); 
  }

  getgraphData() {
    document.getElementById('loading').style.display = 'block';
    this.RestApiService.getgraphData()
        .subscribe(       
            data => { this.graphdata = data;
                console.log(" graphdata" + this.graphdata);
                document.getElementById('loading').style.display = 'none'; 
        }
        
        );  
             
  }

   logout(){
            // remove user from local storage to log user out
            localStorage.removeItem('userName');
        }

}
