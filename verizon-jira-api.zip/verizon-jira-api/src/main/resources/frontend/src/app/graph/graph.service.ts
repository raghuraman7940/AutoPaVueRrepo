import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import 'rxjs/add/operator/map';
@Injectable()
export class GraphService {

 //public testcasesURL = "assets/data/graph.json";
 public testcasesURL = "http://10.146.217.20:8082/api/APIWise_AvgRespTime"; 
 public leveltwoURL="http://10.146.217.20:8082/api/VersionWise_AvgRespTime";
 public levelthreeURL="http://10.146.217.20:8082/api/Datewise_RespTime";
  constructor(public http: Http) { }
  createAuthorizationHeader(headers: Headers) {
    headers.append('Access-Control-Allow-Origin', '*'),     
    headers.append('Content-Type', 'application/json');
  }
  
    getissuesData() {    
      console.log(this.testcasesURL);
      return  this.http.get(this.testcasesURL).map(res=> res.json());     
    }

    leveltwo(apiServer:string,apiUrl:string,methodType:string){
       let headers = new Headers();
         this.createAuthorizationHeader(headers);
         console.log(JSON.stringify({apiServer:apiServer,apiUrl:apiUrl,methodType:methodType}));
          return this.http.post(this.leveltwoURL, JSON.stringify({apiServer:apiServer,apiUrl:apiUrl,methodType:methodType}), headers).map(res=> res.json());  
         

    }

    levelthree(apiServer:string,apiUrl:string,methodType:string,version:string){
       let headers = new Headers();
         this.createAuthorizationHeader(headers);
         console.log(JSON.stringify({apiServer:apiServer,apiUrl:apiUrl,methodType:methodType,version:version}));
          return this.http.post(this.levelthreeURL, JSON.stringify({apiServer:apiServer,apiUrl:apiUrl,methodType:methodType,version:version}), headers).map(res=> res.json());  
         

    }

}
