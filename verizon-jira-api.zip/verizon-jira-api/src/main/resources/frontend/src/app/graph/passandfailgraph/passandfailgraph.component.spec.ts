import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PassandfailgraphComponent } from './passandfailgraph.component';

describe('PassandfailgraphComponent', () => {
  let component: PassandfailgraphComponent;
  let fixture: ComponentFixture<PassandfailgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PassandfailgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PassandfailgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
