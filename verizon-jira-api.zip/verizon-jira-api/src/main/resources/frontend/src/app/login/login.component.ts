import { Component,OnInit,HostListener } from '@angular/core';
import { NgForm } from "@angular/forms";
import { Router, ActivatedRoute, } from '@angular/router';
import { LogInService } from './log-in.service';
import { Http,URLSearchParams, Headers, Response, Jsonp } from '@angular/http';


@Component({
  selector: 'app-homelogin',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
   providers: [Http]
})



export class loginComponent implements OnInit {
user: any = { };
    loading = false;
    returnUrl: string;
    error = '';
    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: LogInService            
        ) {
       
        this.router=router;
        }

    ngOnInit() {
        // reset login status
        this.authenticationService.logout();

        // get return url from route parameters or default to '/'
       
        this.returnUrl ='/menu';
    }

    login() {
        this.loading = true;        
        this.authenticationService.login(this.user.name, this.user.password) //to validate the loggedin user 
            .subscribe(
                data => {
                  
                    this.router.navigate([this.returnUrl]);
                    this.error ="";
                    localStorage.setItem('userName', this.user.name); //storing loggedin user 
                },
                error => {
                   this.error = 'Username or password is incorrect';                 
                    this.loading = false;                
                    
                });
    }

    fa(event){
        //console.log('in the event');
       if((event.charCode >= 65 && event.charCode <= 90)||(event.charCode >= 97 && event.charCode <= 122 ))
            {
                document.getElementById("error").style.display="none";
            // console.log('True case');
                return true;
            }
       else
            {
            // console.log('False case');
                document.getElementById("error").style.display="block";
                return false;
            }
    }

    
}


