import { TestBed, inject } from '@angular/core/testing';

import { ProjectissueService } from './projectissue.service';

describe('ProjectissueService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProjectissueService]
    });
  });

  it('should ...', inject([ProjectissueService], (service: ProjectissueService) => {
    expect(service).toBeTruthy();
  }));
});
