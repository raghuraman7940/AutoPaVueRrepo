import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { routing }    from './app.routing';
import { AppComponent } from './app.component';
import { loginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { IssuesComponent } from './issues/issues.component';
import { TestResultComponent } from './test-result/test-result.component';
import { HttpService } from "./issues/http.service";
import { LogInService } from "./login/log-in.service";
import {GlobalService} from "./global.service";
import {Ng2PaginationModule} from 'ng2-pagination';
import { DashboardService } from './dashboard/dashboard.service'; 
import { TestResultService } from './test-result/test-result.service';
import { GraphComponent } from './graph/graph.component';
import { BargraphComponent } from './graph/bargraph/bargraph.component';
import { GraphService } from './graph/graph.service';
import { MenuComponent } from './menu/menu.component';
import{ MenuService } from'./menu/menu.service';
import { SchedulerComponent } from './issues/scheduler/scheduler.component';
import { NguiDatetimePickerModule } from '@ngui/datetime-picker';
import { ReportComponent } from './test-result/report/report.component';
import {MomentModule} from 'angular2-moment';
import { PassandfailgraphComponent } from './graph/passandfailgraph/passandfailgraph.component';
import { PassFailgraphComponent } from './graph/passandfailgraph/pass-failgraph/pass-failgraph.component';
import{ PassandfailgraphService } from './graph/passandfailgraph/passandfailgraph.service';
@NgModule({
  declarations: [
    AppComponent,
    loginComponent,
    DashboardComponent,    
    IssuesComponent,
    TestResultComponent,
    GraphComponent,
    BargraphComponent,
    MenuComponent,
    SchedulerComponent,
    ReportComponent,
    PassandfailgraphComponent,
    PassFailgraphComponent,      
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing,
    Ng2PaginationModule,
    NguiDatetimePickerModule,
    MomentModule
  ],
  providers: [HttpService, LogInService,DashboardService,TestResultService,GraphService,MenuService,PassandfailgraphService],
  bootstrap: [AppComponent]
})
export class AppModule { }
