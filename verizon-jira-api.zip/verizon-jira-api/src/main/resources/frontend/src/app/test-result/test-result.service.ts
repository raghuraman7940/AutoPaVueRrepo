import { Injectable } from '@angular/core';
import { Http,Response,Headers,RequestOptionsArgs, RequestOptions,URLSearchParams } from "@angular/http";
import 'rxjs/add/operator/map';
@Injectable()
export class TestResultService {

  constructor(public http: Http) { }
    createAuthorizationHeader(headers: Headers) {
    headers.append('Access-Control-Allow-Origin', '*'),     
    headers.append('Content-Type', 'application/json');
}
                     public getReportURL="http://10.146.217.20:8082/api/JenkinBuildHistory"; 
                     
                    getReport(){     //getting data from the above linked jsonfile or url

                          let headers = new Headers();
                          this.createAuthorizationHeader(headers);          
                          return this.http.get(this.getReportURL,headers).map(res => res.json());             
                  
                                 }
  
                      
}