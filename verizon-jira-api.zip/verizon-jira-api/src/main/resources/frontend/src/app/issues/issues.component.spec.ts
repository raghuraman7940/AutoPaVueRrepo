import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DependencytcComponent } from './dependencytc.component';

describe('DependencytcComponent', () => {
  let component: DependencytcComponent;
  let fixture: ComponentFixture<DependencytcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DependencytcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DependencytcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
