import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PassFailgraphComponent } from './pass-failgraph.component';

describe('PassFailgraphComponent', () => {
  let component: PassFailgraphComponent;
  let fixture: ComponentFixture<PassFailgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PassFailgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PassFailgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
