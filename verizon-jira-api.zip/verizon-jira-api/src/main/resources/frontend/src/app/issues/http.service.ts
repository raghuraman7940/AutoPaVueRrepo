import { Injectable } from '@angular/core';
import { Http,Response,Headers,RequestOptions } from "@angular/http";
import 'rxjs/add/operator/map';

@Injectable()
export class HttpService {

  constructor(public http: Http) { }

         public baseURL="http://10.146.217.20:8082/api"; //ulr or Source file path to get the data

        updatedTC(apiURL, latestValues) {
          console.log("inservice update : "+latestValues);
          return this.http.post(this.baseURL+apiURL,latestValues)
          .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let testDetail= response.json();
                localStorage.setItem('IssueDetail',JSON.stringify(testDetail));                
                return testDetail;               
            });

        }

      
}