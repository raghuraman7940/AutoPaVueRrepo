import { Component, OnInit } from '@angular/core';
import { GraphService } from './graph.service'
import { Router, ActivatedRoute, } from '@angular/router';
@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.css']
})
export class GraphComponent implements OnInit {
public chartData: any;
myName: string;
router:Router;
graph1:boolean = true;
graph2:boolean = false;
graph3:boolean = false;
  constructor(private RestApiService: GraphService,router: Router) {
    this.router = router;

                      this.myName = localStorage.getItem('userName'); //to get the logged username  
                        //console.log('username'+ this.myName);
                            if(this.myName == null)        //to redirect to home page for invalid access
                            { this.router.navigate(['']);}
                                            
                      // binding global service to component(username binding to differnent component)
                        this.RestApiService=RestApiService;
   }

  ngOnInit() {    // give everything a chance to get loaded before starting the animation to reduce choppiness
    
      this.generateData();   
      
  }

  generateData() {
      document.getElementById('loading').style.display = 'block';
    this.RestApiService.getissuesData()
        .subscribe(          
            data =>{ this.chartData = data;
            document.getElementById('loading').style.display = 'none';
            }
        );        
  }
  onDataChange(e){
      
    //console.log(e);  
    if(e.level == 1){ 
         this.graph1 = false;
         this.graph2 = true; 
    this.RestApiService.leveltwo(e.apiServer, e.apiUrl,e.methodType)
        .subscribe(          
            data => this.chartData = data,
            error => console.log("error"),
            () => this.chartData.map(d => d.level = e.level)
        );  
    }
     else if(e.level == 2){
         this.graph1 = false;
         this.graph2 = false;
         this.graph3 = true;
         
        this.RestApiService.levelthree(e.apiServer, e.apiUrl,e.methodType,e.apiID)
        .subscribe(          
            data => this.chartData = data,
            error => console.log("error"),
            () => this.chartData.map(d => d.level = e.level)
        ); 
        
    }     
      
  }
  
  logout(){
            // remove user from local storage to log user out
            localStorage.removeItem('userName');
        }
 
   refresh(): void {
    
    window.location.reload();
}

}
