import { Component, OnInit, OnChanges, ViewChild, ElementRef, Input, Output, ViewEncapsulation, EventEmitter } from '@angular/core';
import * as d3 from 'd3';
import { GraphService } from '../graph.service'
import { Router, ActivatedRoute, } from '@angular/router';
@Component({
  selector: 'app-bargraph',
  templateUrl: './bargraph.component.html',
  styleUrls: ['./bargraph.component.css']
})
export class BargraphComponent implements OnInit, OnChanges {
  @ViewChild('chart') private chartContainer: ElementRef;
  @Input() private data: Array<any>;
  @Output() changed: EventEmitter<string> = new EventEmitter();
  private margin: any = { top: 50, bottom: 240, left: 100, right: 100 };
  private chart: any;
  private width: number;
  private height: number;
  private xScale: any;
  private yScale: any;
  private xDomain: any;
  private yDomain: any;
  private colors: any;
  private xAxis: any;
  private yAxis: any;
  private svg: any;
  private zoom:any;  
  private g :any;
  private tooltip: any;
  public chartData: any;
  public returnUrl: any;
  public div: any;
  public level: any = 0;
  public xLabels: Array<any> = ["API Names", "Version", "Date & time"];  
  
  constructor(private router: Router, private graphService: GraphService) { }

  ngOnInit() {
    this.createChart();
    if (this.data) {
      this.drawBarChart();
    } else {
      console.log("Data Not Received");
    }

  }

  ngOnChanges() {
    if (this.chart)
      this.drawBarChart();
  }


  //creating a chart
  createChart() {

    // let zoom = d3.behavior.zoom()  
    // .scaleExtent([1, 10])
    // .on("zoom", zoomed);

    let element = this.chartContainer.nativeElement;
    this.width = 600 - this.margin.left - this.margin.right;
    this.height = 600 - this.margin.top - this.margin.bottom;
    this.svg = d3.select(element).append('svg')
      .attr('width', this.width + this.margin.left + this.margin.right)      
      .attr('height', this.height + this.margin.top + this.margin.bottom)
      .style("background-color", "#1F1D1D");
      // .append("g")
      // .attr("transform", "translate(" + this.margin.left + "," + this.margin.right + ")")
      // .call(zoom);  
  

    // define X & Y domains
    this.xDomain = this.data.map(d => d.apiID);
    this.yDomain = [0, d3.max(this.data, d => d.avgRespTime)];

    // create scales
    this.xScale = d3.scaleBand().padding(0.1).domain(this.xDomain).rangeRound([0, this.width]);
    this.yScale = d3.scaleLinear().domain(this.yDomain).range([this.height, 0]);

    // bar colors
    this.colors = d3.scaleLinear().domain([0, this.data.length]).range(<any[]>['red', 'green']);


    // x & y axis
    this.xAxis = this.svg.append('g')    
      .attr('class', 'axis axis-x')
      .attr('transform', `translate(${this.margin.left}, ${this.margin.top + this.height})`)
      .style("font-size", "15px") //Text size of x axis values from json            
      .call(d3.axisBottom(this.xScale))
      .selectAll("text")	  //To rotate text on x axis 90 degrees
            .style("text-anchor", "end")
            .attr("dx", "-.8em")
            .attr("dy", ".15em")
             .style("fill", "white")  
            .attr("transform", function(d) {
                return "rotate(-65)" 
                });

    this.yAxis = this.svg.append('g')
      .attr('class', 'axis axis-y')
      .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`)
      .style("font-size", "15px") //Text size of y axis values from json            
      .call(d3.axisLeft(this.yScale))
      .selectAll("text")
             .style("fill", "white");

    this.yAxis = this.svg.append('text') //todisplay description text on y-axis
      .attr("transform", "rotate(-90)")
      .attr("x", -(this.height / 2)-60)
      .attr("y", 20)
      .attr("dy", "1em")
      .style("fill", "white")
      .style("text-anchor", "middle")
      .style("font-size", "15px") //size of the description text
      .text("Avg Response Time (ms)")

    this.xAxis = this.svg.append('text') //to display text on  x-axis
      .attr("transform", "rotate(0)")
      .attr("x", ((this.width/2)-155))
      .attr("y", (this.height + 80))
      .attr("dy", "1em")
      .attr("class","x-label")
      .style("fill", "white")
      .style("text-anchor", "middle")
      .style("font-size", "15px")      
      .text(this.xLabels[this.level]);


    // chart plot area
    this.chart = this.svg.append('g')    
      .attr('class', 'bar')
      .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`)
      .on("mousemove", null)
      .on("mouseout", null)
      .on("click", null)   

// function zoomed() {
//   this.svg.attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
// }
      
  }


  drawBarChart() {
    //console.log(this.data);
   
    this.xDomain = this.data.map(d => d.apiID);
    this.yDomain = [0, d3.max(this.data, d => d.avgRespTime)];
    console.log(this.yDomain)
    // create scales
    this.xScale = d3.scaleBand().padding(0.1).domain(this.xDomain).rangeRound([0, this.width]);
    this.yScale = d3.scaleLinear().domain(this.yDomain).range([this.height, 0]);

    // bar colors
    this.colors = d3.scaleLinear().domain([0, this.data.length]).range(<any[]>['#7c1c04', '#7c1c04']);

    this.svg.select(".axis-x").transition().call(d3.axisBottom(this.xScale));
            
    this.svg.select(".axis-y").transition().call(d3.axisLeft(this.yScale));
   
   
    let thisData = [];
    thisData = this.data;
    let _changed = this.changed;
    let _level = this.level;
    
    let update = this.chart.selectAll('.bar')
      .data(this.data);

    // remove exiting bars
    update.exit().remove();

    // update existing bars
    this.chart.selectAll('.bar').transition()
      .attr('x', d => this.xScale(d.apiID))
      .attr('y', d => this.yScale(d.avgRespTime))
      .attr('width', d => this.xScale.bandwidth())
      .attr('height', d => this.height - this.yScale(d.avgRespTime))
      .style('fill', (d, i) => this.colors(i));




    let updateText = this.chart.selectAll(".btext")
      .data(this.data);

    updateText
      .exit()
      .remove();

    updateText    
      .attr('transform', d => `translate(` + (this.xScale(d.apiID) + this.xScale.bandwidth() / 2 - 15) + `,` + (this.yScale(d.avgRespTime) - 8) + `)`)
      //.attr('transform', d => `translate(`+(this.xScale(d.api)+this.xScale.bandwidth()/2)+`,`+(this.height - this.yScale(d.time) )+`)`)
      .style("fill", "white")  
      .text(function (d) { return d.avgRespTime });


    updateText      
      .enter().append("text")
      .attr("class", "btext")
      .style("font-size", "13px")
      .style("font-weight","bold")       
      .attr('transform', d => `translate(` + (this.xScale(d.apiID) + this.xScale.bandwidth() / 2 - 15) + `,` + (this.yScale(d.avgRespTime) - 8) + `)`)
       .style("fill", "white")  
      //.attr('transform', d => `translate(`+(this.xScale(d.api)+this.xScale.bandwidth()/2)+`,`+(this.height - this.yScale(d.time) )+`)`)
        .text(function (d) { return d.level!=2 ? d.avgRespTime : "" }) // to remove text on graph
        // .text(function (d) { return  d.avgRespTime  })   //to display text on graph
    // add new bars   

    if(this.data[0].level == 2){  //to remove previous values in 3rd graph 
      this.svg.selectAll(".btext").remove();
    }

    

    update
      .enter()
      .append('rect')      
      .on("mousemove", function(d){})
      .on("mouseout", function(d){})
      .on("click", function(d){})
      .attr('class', 'bar')
      .on("mousemove", function (d) {
        // console.log("mouse hovered",d3.event)
        var xPosition = parseFloat(d3.select(this).attr("x")) + this.width / 2;
        var yPosition = parseFloat(d3.select(this).attr("y")) / 2 + this.height / 2;
        //console.log(d)
        if(d && d.apiName && d.apiServer && _level == 0) { //to show tool tip for level 0(first graph)
         
           //console.log(thisData)
          d3.select("#tooltip")
            .style("left", d3.event.clientX + "px")
            .style("top", d3.event.clientY + "px")
            .style("color","brown")            
            .select("#value")
            .html("<span style='color:black'>Api Detail:</span>  " +  (d.apiName) + "<br/>"+ "<span style='color:black'>Api Server:</span>  " + d.apiServer+ "<br/>"+ "<span style='color:black'>Max Value:</span>  " + d.MaxValue+ "<br/>"+ "<span style='color:black'>Min Value:</span>" + d.MinValue + "<br/>"+ "<span style='color:black'>Execution Count:</span>" + d.Count);          
          d3.select("#tooltip").classed("hidden", false);          
        }
        if(d && d.apiUrl && d.apiServer && d.methodType && _level == 1) { //to show tool tip for level 1(2nd graph)
           //console.log(thisData)
          d3.select("#tooltip")
            .style("left", d3.event.clientX + "px")
            .style("top", d3.event.clientY + "px")
            .style("color","brown")
            .select("#value")
            .html("<span style='color:black'>Api Url:</span>" +  (d.apiUrl) + "<br/>"+ "<span style='color:black'>Api Server:</span>  " + d.apiServer+ "<br/>"+ "<span style='color:black'>Method Type:</span>  " + d.methodType + "<br/>"+ "<span style='color:black'>Max Value:</span>  " + d.MaxValue+ "<br/>"+ "<span style='color:black'>Min Value:</span>" + d.MinValue + "<br/>"+ "<span style='color:black'>Execution Count:</span>" + d.Count);
          d3.select("#tooltip").classed("hidden", false);          
        }

        if(d && d.Issue_key && d.avgRespTime && _level != 1){  //to show tool tip for level 2(3rd graph)
            d3.select("#tooltip")
            .style("left", d3.event.clientX + "px")
            .style("top", d3.event.clientY + "px")
            .select("#value")
            .html("<span style='color:black'>IssueKey:</span>  " + d.Issue_key + "<br/>" + "<span style='color:black'>Avg Responce Time:</span>" + d.avgRespTime);
          d3.select("#tooltip").classed("hidden", false);
        }        

      })
			   .on("mouseout", function (d) {
        d3.select("#tooltip").classed("hidden", true);
			   })
      .on("click", function (d) {
        //thisData = this.data;
        _level++;
        console.log(d)
        if(!d.level)            //to restrict the click after third graph
          d.level = _level;
        else
          d.level++;
        //console.log(thisData, this);
       // if(!d.level)
          _changed.emit(d);
			   })

      .attr('x', d => this.xScale(d.apiID))
      .attr('y', d => this.yScale(0))
      .attr('width', this.xScale.bandwidth())
      .attr('height', 0)
      .style('fill', (d, i) => this.colors(i))
      .transition()
      // .delay((d, i) => i * 50)
      // .duration(1000) //bar animation delay in loading
      .attr('y', d => this.yScale(d.avgRespTime))
      .attr('height', d => this.height - this.yScale(d.avgRespTime))
      .attr("id", (d, i) => i);
      //console.log(this.svg.select(".x-label"))
      this.svg.select(".x-label")
      .text(this.xLabels[this.data[0].level] || this.xLabels[_level]); //to update the x and y labels on the graph
      
      if(this.data[0].level && this.data[0].level == 2){
         
        this.svg.select(".axis-x")
            .selectAll("text")	//To rotate text on level-2(graph 3) x axis -65 degrees
            .style("text-anchor", "end")
            .attr("dx", "-.8em")
            .attr("dy", ".15em")
             .style("fill", "white")  
            .attr("transform", function(d) {
                  return "rotate(-65)"
                });
        this.svg.select(".axis-y")
        .selectAll("text")
         .style("fill", "white")  
    
      }   
      else if (this.data[0].level && this.data[0].level == 1) {
         this.svg.select(".axis-x")
            .selectAll("text")	//To rotate text on level-1(graph 2) x axis -65 degrees
            .style("text-anchor", "end")
            .attr("dx", "-.8em")
            .attr("dy", ".15em")
            .style("fill", "white")  
            .attr("transform", function(d) {
                  return "rotate(-65)"
                });
        this.svg.select(".axis-y")
        .selectAll("text")
         .style("fill", "white")    

      }      
      
  }

}
