import { Injectable } from '@angular/core';
import { tokenNotExpired } from 'angular2-jwt';
import { Router } from '@angular/router';
import { Http,URLSearchParams, Headers, Response, Jsonp } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

export class Login {
  username: string
  password: string
}
@Injectable()
export class LogInService {

 constructor(private http: Http) {  }
 
 createAuthorizationHeader(headers: Headers) {
    headers.append("Access-Control-Allow-Origin", "*"); 
    headers.append("Content-Type", "application/json");
    headers.append("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE, PUT");
    console.log("Headers are: "+JSON.stringify(headers));
  }
 
    login(username: string, password: string) {
        
       
        let headers = new Headers();
         this.createAuthorizationHeader(headers);
         
        return this.http
            .post('http://10.146.217.20:8082/api/login', JSON.stringify({ username: username, password: password }), headers)
		.map((response: Response) => {
                // login successful 
                let user = response.json();
                if (user && user.username) {
                    // store user details  in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(user.username));
                }
            });
            
    }


    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }
 



}
