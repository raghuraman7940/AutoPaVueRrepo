import { Component, OnInit,OnChanges, ViewChild, ElementRef,Input } from '@angular/core';
import * as d3 from 'd3';
import { line } from 'd3-shape';

import { PassandfailgraphService } from '../passandfailgraph.service'
import { Router, ActivatedRoute, } from '@angular/router';
@Component({
  selector: 'app-pass-failgraph',
  templateUrl: './pass-failgraph.component.html',
  styleUrls: ['./pass-failgraph.component.css']
})
export class PassFailgraphComponent implements OnInit {

  @ViewChild('chart') private chartContainer: ElementRef; 
  @Input() private data: Array<any>; 
  private margin: any = { top: 50, bottom: 240, left: 100, right: 100 };   
  private chart: any;
  private width: number;
  private height: number;
  private x:any;
  private y:any;  
  private xDomain: any;
  private yDomain: any;
  private colors: any;
  private xAxis: any;
  private yAxis: any;
  private svg: any;
  private zoom:any;  
  private g :any;
  private tooltip: any;
  public chartData: any;
  public returnUrl: any;
  public  line:any;
  public points:any;  
  public path:any;
//  public fullWidth:any;
//  public fullHeight:any;
public legend:any;
public options:any;
  constructor(private router: Router, private graphService: PassandfailgraphService) { }

  ngOnInit() {
    this.createChart();
    
  }

createChart() {

    let element = this.chartContainer.nativeElement;
    this.width = 600 - this.margin.left - this.margin.right;
    this.height = 600 - this.margin.top - this.margin.bottom;
    

    this.svg = d3.select(element).append('svg')
              .attr('width', this.width + this.margin.left + this.margin.right)      
              .attr('height', this.height + this.margin.top + this.margin.bottom)
              .style("background-color", "white");
              // .call(responsivefy);
              
              

  this.xDomain = this.data.map(d => d.apiID);
  this.yDomain = [0, d3.max(this.data, function(d) {
	  return Math.max(d.PassCount, d.FailCount); })];
// console.log("xdomain" +this.xDomain)

  this.x=  d3.scaleBand().padding(0.1).domain(this.xDomain).rangeRound([0, this.width]);
 
  this.y= d3.scaleLinear().domain(this.yDomain).range([this.height, 0]);

this.g = this.svg.append("g")
    .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");

// To create x axis with the data
this.xAxis = this.svg.append('g')    
                  .attr('class', 'axis axis-x')
                  .attr('transform', `translate(${this.margin.left}, ${this.margin.top + this.height})`)
                  .style("font-size", "15px") //Text size of x axis values from json            
                  .call(d3.axisBottom(this.x))
                  .selectAll("text")	  //To rotate text on x axis 90 degrees
                        .style("text-anchor", "end")
                        .attr("dx", "-.8em")
                        .attr("dy", ".15em")
                        .style("fill", "black")                           
                        .attr("transform", function(d) {
                            return "rotate(-65)" 
                            });

            this.svg.append('text') //to display description text on  x-axis 
                    .attr("transform", "rotate(0)")
                    .attr("x", ((this.width/2)-155))
                    .attr("y", (this.height + 80))
                    .attr("dy", "1em")
                    .attr("class","x-label")
                    .style("fill", "black")
                    .style("text-anchor", "middle")
                    .style("font-weight","bold")  
                    .style("font-size", "15px")      
                    .text("API ID");

            this.svg.append("rect")            //label for PassCount(box)
                    .attr("transform", "translate(" + (this.width/2-100) + "," + (this.height-280) + ")")       
                    .attr("width", 13)
                    .attr("height", 13)
                    .style("fill", "green");

            this.svg.append("text")             //label text 
                    .attr("transform", "translate(" + (this.width/2-85) + "," + (this.height-275) + ")")
                    .attr("dy", ".35em")
                    .attr("text-anchor", "start")
                    .style("fill", "black")
                    .style("font-weight","bold")        
                    .text("Pass Count");

          this.svg.append("rect")                  //label for failCount(box)
                    .attr("transform", "translate(" + (this.width/2+35) + "," + (this.height-280) + ")")       
                    .attr("width", 13)
                    .attr("height", 13)
                    .style("fill", "red");

            this.svg.append("text")              //label text 
                    .attr("transform", "translate(" + (this.width/2+50) + "," + (this.height-275) + ")")
                    .attr("dy", ".35em")
                    .attr("text-anchor", "start")
                    .style("fill", "black")
                    .style("font-weight","bold")  
                    .text("Fail Count");

// To create y axis with the data	
this.yAxis = this.svg.append('g')
                  .attr('class', 'axis axis-y')
                  .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`)
                  .style("font-size", "15px") //Text size of y axis values from json            
                  .call(d3.axisLeft(this.y))
                  .selectAll("text")                   
                  .style("fill", "black"); 

            this.svg.append('text') //todisplay description text on y-axis
                  .attr("transform", "rotate(-90)")
                  .attr("x", -(this.height / 2)-60)
                  .attr("y", 20)
                  .attr("dy", "1em")
                  .style("fill", "black")
                  .style("text-anchor", "middle")
                  .style("font-weight","bold")  
                  .style("font-size", "15px") //size of the description text
                  .text("Execution Count");
           

// To create line svg with the data
let line1 = d3.line()              // for Fail count line
    .x(d => this.x(d.apiID))
    .y(d => this.y(d.FailCount));

let line2 = d3.line()               // for pass count line
    .x(d => this.x(d.apiID))
    .y(d => this.y(d.PassCount));

this.svg                            // svg to draw a line1-fail count line
        .data([this.data])        
        .append('path')
        .attr('class','line')
        .attr('transform', `translate(${this.margin.left+20}, ${this.margin.top})`)
        .attr('d',line1)
        .style('stroke',"red")
        .style('stroke-width',5)
        .style('fill','none');
        

this.svg                               // svg to draw a line2-pass count line
        .data([this.data])
        .append('path')
        .attr('class','line')
        .attr('transform', `translate(${this.margin.left+20}, ${this.margin.top})`)
        .attr('d',line2)
        .style('stroke',"green")
        .style('stroke-width',5)
        .style('fill','none');

 //to create a dot at the required points for fail count      
 this.svg.selectAll("dot")     //to apply dot circle shape at the data specific points for 
      .data(this.data)
      .enter().append("circle")
      .attr("r", 4)
      .attr('transform', `translate(${this.margin.left+20}, ${this.margin.top})`)
      .attr("cx", d=> this.x(d.apiID))
      .attr("cy", d=> this.y(d.FailCount))
      .on("mousemove", function (d) {       //creating tooltip on hovering the FailCount dot on the line.

      var xPosition = parseFloat(d3.select(this).attr("x")) + this.width / 2;
      var yPosition = parseFloat(d3.select(this).attr("y")) / 2 + this.height / 2;
         d3.select("#tooltip")
            .style("left", d3.event.clientX + "px")
            .style("top", d3.event.clientY + "px")
            .style("color","brown")            
            .select("#value")
            .html("<span style='color:black'>Api Name:</span>  " +  (d.apiName) + "<br/>"+ "<span style='color:black'>Api Server:</span>  " + d.apiServer+ "<br/>"+ "<span style='color:black'>Api Url:</span>  " + d.apiUrl+ "<br/>"+ "<span style='color:black'>Method Type:</span>" + d.methodType );          
            d3.select("#tooltip").classed("hidden", false);     
                  })

      .on("mouseout", function (d) {
        d3.select("#tooltip").classed("hidden", true);
			            });

//to create a dot at the required points for pass count
this.svg.selectAll("dot")       //to apply dot circle shape at the data specific points
      .data(this.data)
    .enter().append("circle")
      .attr("r", 4)
      .attr('transform', `translate(${this.margin.left+20}, ${this.margin.top})`)
      .attr("cx", d=> this.x(d.apiID))
      .attr("cy", d=> this.y(d.PassCount))     
      .on("mousemove", function (d) {       //tooltip on hovering the Passcount dot on the line.

      var xPosition = parseFloat(d3.select(this).attr("x")) + this.width / 2;
      var yPosition = parseFloat(d3.select(this).attr("y")) / 2 + this.height / 2;
         d3.select("#tooltip")
            .style("left", d3.event.clientX + "px")
            .style("top", d3.event.clientY + "px")
            .style("color","brown")            
            .select("#value")
            .html("<span style='color:black'>api Name:</span>  " +  (d.apiName) + "<br/>"+ "<span style='color:black'>Api Server:</span>  " + d.apiServer+ "<br/>"+ "<span style='color:black'>Api Url:</span>  " + d.apiUrl+ "<br/>"+ "<span style='color:black'>Method Type:</span>" + d.methodType );         
          d3.select("#tooltip").classed("hidden", false);     
             })

      .on("mouseout", function (d) {
        d3.select("#tooltip").classed("hidden", true);
			       }); 	

}


}

