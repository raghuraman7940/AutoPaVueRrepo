import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, } from '@angular/router';
import { TestResultService } from '../test-result.service';
// import * as moment from 'moment';
// import { NguiDatetime } from '@ngui/datetime-picker';
@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {

 myName: string; 
 router:Router;
 results:any[]=[]; 
 report:any[]=[];
 builds:any[]=[];
 jobs:any[]=[];
 currentReport:any;
 suite:any;
//  public datepicker = false;
//  selectedDate = new Date();
//   defaultValue = new Date();
//   defaultDate = moment(this.defaultValue).format("MMM DD, YYYY hh:mm:ss");
 
  constructor(private service:TestResultService ,router:Router) { 
    this.router=router;
    this.myName = localStorage.getItem('userName'); //to get the logged username  
    console.log('username'+ this.myName); 
    console.log("in dependent constructor ");
        if(this.myName == null)   //to redirect to home page for invalid access
        { this.router.navigate(['']);}
  }

  ngOnInit() {
             
    this.results = JSON.parse(localStorage.getItem('IssueDetail')); //to get the table data from the backend response 

     localStorage.removeItem('testdata');

     this.getReport();
  }
  
  openReport(report){
    console.log(report);
    if(report){
      this.currentReport=JSON.parse(report);
      this.suite = this.currentReport.suite;
    document.getElementById('finalresult').style.display='block';
    document.getElementById('reportpage').style.display='none';
    document.getElementById('fulldetails').style.display='none';
    document.getElementById('passeddetails').style.display='none';
    document.getElementById('faileddetails').style.display='none';
    document.getElementById('skippeddetails').style.display='none';
    }
    else{
      alert("data is not present");
    }
  }

  // displaydatepicker(){  
    
  //     this.datepicker = true;
    
  // }

  // getDatePicker(dt){
  //   var newDate = new Date(dt);
  //   console.log(newDate);
  //   this.selectedDate = newDate;
  //   console.log(moment(this.selectedDate).format("MM/DD/YYYY hh:mm:ss"));
  //   this.defaultDate = moment(this.selectedDate).format("MMM DD, YYYY hh:mm:ss");
  // }

  back(){
    document.getElementById('finalresult').style.display='none';
    document.getElementById('reportpage').style.display='block';
         }
  getReport(){
   document.getElementById('loading').style.display='block';
                this.service.getReport().subscribe(
                  data => {
                     // console.log("Got Projects" + data);
                      this.report=data;
                      this.builds = this.report["Jobs"][0].Builds;
                      this.jobs = this.report["Jobs"][0];
                   document.getElementById('loading').style.display='none';   
                       //to display the default value in select box
                      console.log(" Projects" + this.report);
                    },                    
                    err => //console.error(err),                
                    () => console.log('done loading Projects data')
                    );
              }

//To display the background color for status according to json data values(Pass or failed).
  getResultColor(val) {
                        if (val == "Pass") {
                          return "#c2eac2";                      
                        }

                        else if (val == "Failed") {
                          return "#f1afaf";
                        }
                        else if (val == "skipped") {
                          return "rgba(255, 255, 0, 0.4)";
                        }
                      }

 logout() {
              // remove user from local storage to log user out
              localStorage.removeItem('userName');
           }

loadresults(){
           document.getElementById('result').style.display='block';
           document.getElementById('fulldetails').style.display='none';
           document.getElementById('passeddetails').style.display='none';
           document.getElementById('faileddetails').style.display='none';
           document.getElementById('skippeddetails').style.display='none';
}

loadalltests(){         
          document.getElementById('fulldetails').style.display='block' ;
          document.getElementById('passeddetails').style.display='none';
          document.getElementById('faileddetails').style.display='none';
          document.getElementById('skippeddetails').style.display='none';
}

loadpasseddata(){           
           document.getElementById('fulldetails').style.display='none';
           document.getElementById('passeddetails').style.display='block';
           document.getElementById('faileddetails').style.display='none';
           document.getElementById('skippeddetails').style.display='none';
}

loadfaileddata(){           
           document.getElementById('fulldetails').style.display='none';
           document.getElementById('passeddetails').style.display='none';
           document.getElementById('faileddetails').style.display='block';
           document.getElementById('skippeddetails').style.display='none';
}

loadskippeddata(){           
           document.getElementById('fulldetails').style.display='none';
           document.getElementById('passeddetails').style.display='none';
           document.getElementById('faileddetails').style.display='none';
           document.getElementById('skippeddetails').style.display='block';
}


}
