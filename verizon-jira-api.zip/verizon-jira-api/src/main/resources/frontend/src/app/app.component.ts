import { Component } from '@angular/core';
import { LogInService } from '../app/login/log-in.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
   

}
