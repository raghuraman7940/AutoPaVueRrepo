import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})

export class MenuComponent  {

 router:Router; 
 myName: string; 
  constructor( router: Router) {         
    this.myName = localStorage.getItem('userName'); //to get the logged username  
    console.log('username'+ this.myName); 
    console.log("in dependent constructor ");
        if(this.myName == null)   //to redirect to home page for invalid access
        { this.router.navigate(['']);}
        
   }

   logout() {
              // remove user from local storage to log user out
              localStorage.removeItem('userName');
           }

  

}
