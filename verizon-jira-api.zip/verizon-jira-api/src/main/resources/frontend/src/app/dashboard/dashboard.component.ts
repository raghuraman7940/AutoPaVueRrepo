import { Component,OnInit,trigger, transition, style, animate, state} from '@angular/core';
import { DashboardService } from './dashboard.service';
import { Router, ActivatedRoute, } from '@angular/router';
@Component({
  selector: 'app-projectissue',  
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  
   providers: [DashboardService]
})
export class DashboardComponent implements OnInit {
  
  dashboard: any = {};  
  projects:any[]=[];
  issuetypes:any[]=[];
  sprints:any[]=[];
  testtype:any={};
  error = '';
  myName: string;
  radioVal: string = "immediate";
  router:Router;
  returnUrl: string;
constructor(private service:DashboardService,router: Router){
                      this.router = router;

                      this.myName = localStorage.getItem('userName'); //to get the logged username  
                        console.log('username'+ this.myName);
                            if(this.myName == null)        //to redirect to home page for invalid access
                            { this.router.navigate(['']);}                      
                      
                      // binding global service to component(username binding to differnent component)
                        this.service=service;
                      
                    }
  

ngOnInit(){
              this.getProjects();
              this.getIssues();    
              this.getSprints();
               this.testtype="Regression";              
          }

getProjects(){
  console.log("in component ");
                this.service.getProjects().subscribe(
                  data => {
                    //  console.log("Got Projects" + data);
                      this.projects=data;
                      this.dashboard.projectname = this.projects[0].key; //to display the default value in select box
                      //console.log(" Projects" + this.projects);
                    },                    
                    err => //console.error(err),                
                    () => console.log('done loading Projects data')
                    );
              }


getIssues(){
               this.service.getIssues().subscribe(
                data => {
                   this.issuetypes=data;
                   this.dashboard.issuetype=this.issuetypes[0].name; //to display the default value in select box
                 // console.log(" issuetypes" + this.issuetypes);
                         },                  
                  err => //console.error(err),                
                  () => console.log('done loading Issues data')
                  );
           }

getSprints(){
              this.service.getSprints().subscribe(
                data => {
                    this.sprints=data;
                     this.dashboard.sprint=this.sprints['sprintList'][0].name; //to display the default value in select box
                    //console.log(" issuetypes" + this.issuetypes);
                  },
                  
                  err => //console.error(err),                
                  () => console.log('done loading Sprints data')
                  );
             }


logout(){
            // remove user from local storage to log user out
            localStorage.removeItem('userName');
        }
getRadioValue(val){
  this.radioVal = val;
  console.log(this.radioVal);
} 

 //on submition of selected values
next(){
  document.getElementById('loading').style.display='block';
             console.log(this.testtype);
                this.service.next(this.dashboard.projectname, this.dashboard.issuetype,this.dashboard.sprint,this.testtype) //to validate theentered values 
                  .subscribe(
                      data => {
                        console.log("result : "+JSON.stringify(data));
                        if (data['issueList'].length != 0){ //to check the data is available or not in response from backend
                            if(this.radioVal == "immediate")
                              this.router.navigate(["/issues"]);
                            else
                              this.router.navigate(["/scheduler"]);
                        }else
                          // alert("data.issueList.length "+ data['issueList'].length);

                          document.getElementById('loading').style.display='none';
                            this.error = 'Please select valid options';

                        },
                        error => {

                                 document.getElementById('loading').style.display='none';
                            this.error = 'Please select valid options';     
                            
                        });
    
       }
}