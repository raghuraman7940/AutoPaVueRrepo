import { Component,Injectable,Input,Output,EventEmitter } from '@angular/core';


@Injectable()
export class GlobalService {

        Issues:any = {"issueList": [{"summary": "Get Customer XML","Issue_key": "COB-349","RunMode": "No","TestResultStatus": "Failed"}]};
          setIssues(issues){
                console.log('in global Service Issues are:' + JSON.stringify(issues));
                this.Issues =issues;
                 console.log('in global Service Issues are:' + JSON.stringify(this.Issues));
          }
          getIssues(){
                console.log('Issues Will be : '+ JSON.stringify(this.Issues));
                return this.Issues;
          }


 

}