import { ChangeDetectionStrategy, Component, OnInit, NgModule, Input } from '@angular/core';
import { Response } from "@angular/http";
import { HttpService } from "../http.service";
import {Observable} from 'rxjs/Rx';
import { loginComponent } from '../../login/login.component';
import { Router, ActivatedRoute, } from '@angular/router';
import {PaginationInstance} from 'ng2-pagination';
import { NguiDatetime } from '@ngui/datetime-picker';
import * as moment from 'moment';
@Component({
  selector: 'app-scheduler',
  templateUrl: './scheduler.component.html',
  styleUrls: ['./scheduler.component.css']
})
export class SchedulerComponent implements OnInit {

  // datas:any[]=[];
  tocheck: boolean; 
  //declaring string in service 
  returnUrl: string;
  projectname: string;
  issuetype: string;
  sprint: string;
  TestingType:string;
  myName: string;  //logged username
  router:Router; 
  currentIssueKey:string;
  currentIssue: any;
  currentIssueIndex = 0;
  currentInputValues = [];
  testcaseKeys = [];
  showCalendar = false;
  selectedDate = new Date();
  defaultValue = new Date();
  defaultDate = moment(this.defaultValue).format("MMM DD, YYYY hh:mm:ss A");
  minDate = new Date(1000, 0, 1);
  maxDate = new Date(9999, 11, 31);
  disabledDates = [new Date(2016, 11, 26), new Date(2016, 11, 27)];
 schedule:string="";
  _httpService: HttpService;
  public datepicker = false;
  editMode: boolean = true;
  editModeValue = "Edit";

  constructor( _httpService: HttpService, router: Router) {
    
    this.router = router;   
    this._httpService = _httpService;
    this.myName = localStorage.getItem('userName'); //to get the logged username  
    console.log('username'+ this.myName); 
    console.log("in dependent constructor ");
        if(this.myName == null)   //to redirect to home page for invalid access
        { this.router.navigate(['']);}
  }
  getDatePicker(dt){
    var newDate = new Date(dt);
    console.log(newDate);
    this.selectedDate = newDate;
    console.log(moment(this.selectedDate).format("MM/DD/YYYY hh:mm:ss"));
    this.defaultDate = moment(this.selectedDate).format("MMM DD, YYYY hh:mm:ss A");
  }

  displaydatepicker(){  
    var isAnyChecked = false;
      this.datas["issueList"].forEach(x => {
        if(x.RunMode == "Yes")
          isAnyChecked = true;
        
        
      });
      
    if(isAnyChecked)   
      this.datepicker = true;
    else
    alert("Please Select minimum one test");
  }
  //To display the background color for status according to json data values(Pass or failed).
  getResultColor(val) {
                        if (val == "Pass") {
                          return "#77b300";
                        }
                        else if (val == "Failed") {
                          return "#ff3333";
                        }
                      }

  //To check the boxs according to json data.
  getCheck(runmode) {
                      if (runmode == "Yes") {
                        //this.tocheck = true;
                        return true;
                      }
                      else if (runmode == "No") {
                        //this.tocheck = false;
                        return false;
                      }
                     }
 //To check all checkboxes in table when header checkbox is clicked
  Checkall($event) {
                    console.log($event.target.checked)
                    

                    this.datas["issueList"].forEach(x => x.RunMode = $event.target.checked ? "Yes" : "No")  ;
                    
                    console.log(JSON.stringify(this.datas["issueList"]));
                   }

  checkIt(index,$event){
    this.datas["issueList"].forEach((x,i) =>{
      if (index == i)
        x.RunMode = $event.target.checked ? "Yes" : "No" ;
    })
    //console.log(JSON.stringify(this.datas["issueList"]));
    }
    
    onIssueClick(key) {
    this.currentIssueKey = key;
    this.getCurrentIssueValues();
  }
  getCurrentIssueValues(){
    this.datas["issueList"].forEach((x, i) => {
      if (x.Issue_key == this.currentIssueKey){
        this.currentIssue = x.INPUT_VALUES[this.currentIssueIndex];
        this.currentInputValues = x.INPUT_VALUES;
      }
      this.testcaseKeys = Object.keys(this.currentIssue);
    });
  }
  
  updateInputValues(){
    let latestValues = {
      "updateIssueDetails":[
        {
          "Issue_key":this.currentIssueKey,
          "INPUT_VALUES":this.currentInputValues
        }
      ]
    }
    console.log(latestValues);
    this._httpService.updatedTC("/updateIssueDetails", JSON.stringify(latestValues))  //to redirect to required page after validation
      .subscribe(
      data => {
        console.log("success");
        localStorage.setItem('myIssues', JSON.stringify(this.datas));
        //this.router.navigate(['/result']);
      },
      error => {
      });
  }
     
  updateTC(){
     document.getElementById('loading').style.display='block';
      let latestValues = {
              "updateIssue": [],
              "projectname": this.projectname,
              "issuetype": this.issuetype,
              "sprint": this.sprint,
              "TestingType":this.TestingType,
              "date":moment(this.selectedDate).format("MM/DD/YYYY HH:mm:ss")
          };

      this.datas["issueList"].forEach(x =>{
          let newItem = {
            "Issue_key":x.Issue_key,
            "RunMode":x.RunMode
          };
          latestValues.updateIssue.push(newItem);
      });
        
      console.log("latestValues are : "+JSON.stringify(latestValues));
      
      this._httpService.updatedTC("/JenkinScheduleJob ",JSON.stringify(latestValues))  //to redirect to required page after validation
            .subscribe(
                data => {                                  
                  console.log(data);  
                  if(data.message == "success")       //for alerting the success message on scheduling
                    alert("Scheduled Successfully!");
                  else
                    alert("Schedule failed! Please try again!");               
                   localStorage.setItem('myIssues',JSON.stringify(this.datas));                   
                },
                error => {
                });                

  }



  ngOnInit() {
             
              this.datas = JSON.parse(localStorage.getItem('myIssues')); //to get the table data from the backend response
              this.projectname = localStorage.getItem('projectname');
              this.issuetype = localStorage.getItem('issuetype');
              this.sprint = localStorage.getItem('sprint');
              this.TestingType = localStorage.getItem('TestingType');
              this.returnUrl ='/result';              
            
             }
 


  //To get the options to select number of items to display per page 
  @Input('data') datas: string[] = [];

  public filter: string = '';
  public maxSize: number = 7;
  public directionLinks: boolean = true;
  public autoHide: boolean = false;
  public config: PaginationInstance = {
    itemsPerPage: 5,
    currentPage: 1
  };
  public labels: any = {
    previousLabel: 'Previous',
    nextLabel: 'Next',
    screenReaderPaginationLabel: 'Pagination',
    screenReaderPageLabel: 'page',
    screenReaderCurrentLabel: `You're on page`
  };


  onPageChange(number: number) {
    console.log('change to page', number);
    this.config.currentPage = number;  
    
  }


  logout() {
              // remove user from local storage to log user out
              localStorage.removeItem('userName');
           }
gotoPrevIssue(){
    if(this.currentIssueIndex > 0)
      this.currentIssueIndex--;
   // console.log(this.currentIssueIndex)
    this.getCurrentIssueValues();
  }
  gotoNextIssue(){
    if(this.currentIssueIndex < this.currentInputValues.length-1)
      this.currentIssueIndex++;
    this.getCurrentIssueValues();
  }
  toggleEditMode(){
    this.editMode = !this.editMode;
    if(!this.editMode)
      this.editModeValue = "Update";
    else{
      this.editModeValue = "Edit";
      //call update api service
      this.updateInputValues();
      //console.log(this.datas)
    }
  }

  closemode(){
     	this.editMode = true;
      this.editModeValue = "Edit";
      this.currentIssueIndex = 0;
      this.currentInputValues = [];
  }
  /*getEditModeIcon(){
      if(this.editMode)
        return "glyphicon-pencil";
      else
        return "glyphicon-ok";
  }*/
}
