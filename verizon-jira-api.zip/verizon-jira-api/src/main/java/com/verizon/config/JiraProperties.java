package com.verizon.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * This class represents the JIRA Properties.
 * 
 * @author balakumar-s
 *
 */
@ConfigurationProperties(prefix = "JIRAConfig")
public class JiraProperties {
	/**
	 * URL for JIRA.
	 */
	public String url;
	/**
	 * JIRA Username.
	 */
	public String username;
	/**
	 * JIRA User password.
	 */
	public String password;
	
	/**
	 * URL for Jenkin.
	 */
	public String jenkinurl;
	/**
	 * Jenkin Username.
	 */
	public String jenkinusername;
	/**
	 * Jenkin User password.
	 */
	public String jenkinpassword;
	/**
	 * jql query.
	 */
	public String jql;

	/**
	 * board name.
	 */
	public String board;

	/**
	 * Export depedent issue into CSV file.
	 */
	public String dependentExport;
	/**
	 * Export Non depedent issue into CSV file.
	 */
	public String nonDependentExport;
	/**
	 * Import CSV file.
	 */
	public String csvFileImport;
	
	/**
	 * download path.
	 */
	public String downloadPath;

	/**
	 * Get the JIRA URL.
	 * 
	 * @return url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * Set the JIRA URL.
	 * 
	 * @param url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Get the JIRA User name
	 * 
	 * @return username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * Set the JIRA User Password
	 * 
	 * @param username
	 *            username
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * Get the JIRA User password.
	 * 
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Set the JIRA User password.
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Get the jql query.
	 * 
	 * @return jql
	 */
	public String getJql() {
		return jql;
	}

	/**
	 * Set the jql query.
	 * 
	 * @param jql
	 *            jql
	 */
	public void setJql(String jql) {
		this.jql = jql;
	}

	/**
	 * get the board name.
	 * 
	 * @return board
	 */
	public String getBoard() {
		return board;
	}

	/**
	 * set the board name.
	 * 
	 * @param board
	 */
	public void setBoard(String board) {
		this.board = board;
	}

	/**
	 * Get the CSV File to export dependent issues from JIRA.
	 * 
	 * @return dependentExport
	 */
	public String getDependentExportt() {
		return dependentExport;
	}

	/**
	 * Set the CSV File to export dependent issues from JIRA
	 * 
	 * @param dependentExport
	 */
	public void setDependentExport(String dependentExport) {
		this.dependentExport = dependentExport;
	}

	/**
	 * Get the CSV File to export NON dependent issues from JIRA.
	 * 
	 * @return nonDependentExport
	 */
	public String getNonDependentExportt() {
		return nonDependentExport;
	}

	/**
	 * Set the CSV File to export NON dependent issues from JIRA
	 * 
	 * @param nonDependentExport
	 */
	public void setNonDependentExport(String nonDependentExport) {
		this.nonDependentExport = nonDependentExport;
	}

	/**
	 * Get the CSV File to import into JIRA.
	 * 
	 * @return csvFileImport
	 */
	public String getCsvFileImport() {
		return csvFileImport;
	}

	/**
	 * Set the CSV File to import into JIRA.
	 * 
	 * @param csvFileImport
	 */
	public void setCsvFileImport(String csvFileImport) {
		this.csvFileImport = csvFileImport;
	}

	
	/**
	 * Get the download the path.
	 * 
	 * @return downloadPath
	 */
	public String getDownloadPath() {
		return downloadPath;
	}

	/**
	 * Set the download path.
	 * 
	 * @param downloadPath
	 *            downloadPath
	 */
	public void setDownloadPath(String downloadPath) {
		this.downloadPath = downloadPath;
	}
	/**
	 * Get the Jenkin URL.
	 * 
	 * @return url
	 */
	public String getJenkinurl() {
		return jenkinurl;
	}

	/**
	 * Set the Jenkin URL.
	 * 
	 * @param url
	 */
	public void setJenkinurl(String jenkinurl) {
		this.jenkinurl = jenkinurl;
	}

	/**
	 * Get the Jenkin User name
	 * 
	 * @return username
	 */
	public String getJenkinusername() {
		return jenkinusername;
	}

	/**
	 * Set the Jenkin User Password
	 * 
	 * @param username
	 *            username
	 */
	public void setJenkinusername(String jenkinusername) {
		this.jenkinusername = jenkinusername;
	}

	/**
	 * Get the Jenkin User password.
	 * 
	 * @return password
	 */
	public String getJenkinpassword() {
		return jenkinpassword;
	}

	/**
	 * Set the Jenkin User password.
	 * 
	 * @param password
	 */
	public void setJenkinpassword(String jenkinpassword) {
		this.jenkinpassword = jenkinpassword;
	}
}