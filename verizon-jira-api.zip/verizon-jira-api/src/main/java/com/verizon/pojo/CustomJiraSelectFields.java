package com.verizon.pojo;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 * This class represents the JIRA Custom field of Run Mode.
 * 
 * @author balakumar-s
 *
 */
public class CustomJiraSelectFields {
	/**
	 * self field.
	 */
	@JsonIgnore
	private String self;
	/**
	 * value field.
	 */
	private String value;
	/**
	 * id field.
	 */
	@JsonIgnore
	private String id;

	/**
	 * Get the self field.
	 * 
	 * @return self
	 */
	@JsonIgnore
	public String getSelf() {
		return self;
	}

	/**
	 * Set the self field.
	 * 
	 * @param self
	 */
	@JsonProperty
	public void setSelf(String self) {
		this.self = self;
	}

	/**
	 * Get the value.
	 * 
	 * @return value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Set the value.
	 * 
	 * @param value
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Get the Issue id.
	 * 
	 * @return id
	 */
	@JsonIgnore
	public String getId() {
		return id;
	}

	/**
	 * Set the issue id.
	 * 
	 * @param id
	 */
	@JsonProperty
	public void setId(String id) {
		this.id = id;
	}
}