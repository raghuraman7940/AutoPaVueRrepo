package com.verizon.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.google.gson.JsonObject;
import com.verizon.config.JiraProperties;

import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.pojo.TokenCredentials;
import com.verizon.services.CsvFileReader;
import com.verizon.services.CsvFileWriter;
import com.verizon.services.JiraUpdateIssue;
import com.verizon.services.JsonJiraExportIssues;

/**
 * 
 * This class is used to handle the JIRA REST API Request.
 * 
 * @author balakumar-s
 *
 */
@EnableConfigurationProperties(JiraProperties.class)
public class JiraService {
	/**
	 * Csv File for write operation.
	 */
	static CsvFileWriter csvFile = new CsvFileWriter();
	/**
	 * Csv File for write operation.
	 */
	static JsonJiraExportIssues jsonExport = new JsonJiraExportIssues();
	/**
	 * Csv File for read operation.
	 */
	CsvFileReader csvFileReader = new CsvFileReader();

	/**
	 * Jira Update Issue.
	 */
	JiraUpdateIssue UpdateIssue = new JiraUpdateIssue();
	/**
	 * jira credentials.
	 */
	JiraClient jira = null;
	/**
	 * JIRA Properties.
	 */
	private JiraProperties properties;
	/**
	 * Basic credentials.
	 */
	TokenCredentials creds = null;

	public JiraService() {

	}

	/**
	 * JiraExport.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	public String JiraExport(JiraClient jira, String jql, JiraProperties properties) {
		String message = null;
		try {
			// jira = new JiraClient(properties.getUrl(), creds);
			String issueDetail = csvFile.writeCsvFile(jira, properties, jql);
			message = issueDetail;
		} catch (Exception e) {
			message = e.getMessage();
		}
		return message;
	}
	
	
	/**
	 * JiraExport.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	public JsonObject JiraJSONExport(JiraClient jira, String jql, JiraProperties properties) {
		 JsonObject JsonTestData = null;
		try {
				// jira = new JiraClient(properties.getUrl(), creds);
			  JsonTestData =jsonExport.JiraGetIssues(jira, properties,jql);
			
		} catch (Exception e) {
			e.getMessage();
		}
		return JsonTestData;
	}

	/**
	 * JiraImport.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	public String JiraImport() throws JiraException {
		String message = null;
		try {
			//jira = new JiraClient(properties.getUrl(), creds);
			String updateString = csvFileReader.readCsvFile(jira, properties);
			message = updateString;
		} catch (Exception e) {
			message = e.getMessage();
		}
		return message;
	}

	/**
	 * JiraUpdateIssueKey.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	public String JiraUpdateIssueKey(JiraClient jira,String Issue_Key, String Test_Results, String Resp_Time,
			String Output_Values) throws JiraException {
		String message = null;
		try {
			String updateString = UpdateIssue.UpdateIssueKey(jira, Issue_Key, Test_Results,  Resp_Time, Output_Values);
			message = updateString;
		} catch (Exception e) {
			message = e.getMessage();
		}
		return message;
	}

}
