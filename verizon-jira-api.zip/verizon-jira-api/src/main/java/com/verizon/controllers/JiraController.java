package com.verizon.controllers;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.offbytwo.jenkins.client.JenkinsHttpClient;
import com.verizon.scheduler.JenkinsScheduler;
import com.verizon.DriverScript;
import com.verizon.agile.AgileClient;
import com.verizon.agile.Board;
import com.verizon.agile.Sprint;
import com.verizon.config.JiraProperties;
import com.verizon.pojo.CustomJiraSelectFields;
import com.verizon.pojo.Issue;
import com.verizon.pojo.IssueHistory;
import com.verizon.pojo.IssueHistoryItem;
import com.verizon.pojo.IssueLink;
import com.verizon.pojo.IssueType;
import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.pojo.Project;
import com.verizon.pojo.TokenCredentials;
import com.verizon.pojo.Version;
import com.verizon.services.CsvFileReader;
import com.verizon.services.CsvFileWriter;
import com.verizon.services.JiraUpdateIssue;
import com.verizon.util.Constants;
import com.verizon.util.JIRAConstants;

/**
 * 
 * This class is used to handle the JIRA REST API Request.
 * 
 * @author balakumar-s
 *
 */
@RestController
@EnableConfigurationProperties(JiraProperties.class)
@RequestMapping("/api")
public class JiraController {
	int iCount=1;
	/**
	 * Csv File for write operation.
	 */
	CsvFileWriter csvFile = new CsvFileWriter();
	/**
	 * Csv File for read operation.
	 */
	CsvFileReader csvFileReader = new CsvFileReader();

	/**
	 * Jira Update Issue.
	 */
	JiraUpdateIssue UpdateIssue = new JiraUpdateIssue();
	/**
	 * jira credentials.
	 */
	JiraClient jira = null;
	JenkinsHttpClient jenkinclient=null;
	JenkinsScheduler jenkinscheduler = null;
	/**
	 * JIRA Properties.
	 */
	private final JiraProperties properties;
	/**
	 * Basic credentials.
	 */
	TokenCredentials creds = null;
	/**
	 * objectMapper for JSON Handle.
	 */
	ObjectMapper mapper = new ObjectMapper();

	/**
	 * 
	 * Constructor for configuring the properties.
	 * 
	 * @param properties
	 *            properties
	 * @throws JiraException
	 *             JiraException
	 * @throws URISyntaxException 
	 */
	@Autowired
	public JiraController(JiraProperties properties) throws JiraException, URISyntaxException {
		this.properties = properties;
		creds = new TokenCredentials(properties.getUsername(), properties.getPassword());
		jira = new JiraClient(properties.getUrl(), creds);
		jenkinclient = new JenkinsHttpClient(new URI(properties.getJenkinurl()), properties.getJenkinusername(), properties.getJenkinpassword());
		jenkinscheduler= new JenkinsScheduler();
	}


	/**
	 * Login - REST API Call with JIRA.
	 * 
	 * @return String String
	 * @throws JiraException
	 *             JiraException
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<String> login(@RequestBody String login) throws JiraException {
		String message = null;
		System.out.println("POST api/login  "+login);
		try {
			JSONObject jsonObject = new JSONObject(login.toString());
			String username = jsonObject.getString("username");
			String password = jsonObject.getString("password");
			creds = new TokenCredentials(username, password);
			jira = new JiraClient(properties.getUrl(), creds);
			message = login;
		} catch (Exception e) {
			message = e.getMessage() + ". Please check your JIRA Username and Password.";
		}

		return new ResponseEntity<>(message, HttpStatus.OK);
	}

	/**
	 * Get Projects - REST API Call with JIRA.
	 * 
	 * @return String String
	 * @throws JiraException
	 *             JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/getProjects", method = RequestMethod.GET)
	public ResponseEntity<String> getProjects() throws JiraException {
		String message = null;
		System.out.println("GET api/getProjects  ");
		try {
			jira = new JiraClient(properties.getUrl(), creds);
			List<Project> projects = jira.getProjects();
			String jsonInProjects = mapper.writeValueAsString(projects);
			message = jsonInProjects;
		} catch (Exception e) {
			message = e.getMessage();
		}
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	/**
	 * Get IssueTypes - REST API Call with JIRA.
	 * 
	 * @return String String
	 * @throws JiraException
	 *             JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/getIssueTypes", method = RequestMethod.GET)
	public ResponseEntity<String> getIssueTypes() throws JiraException {
		String message = null;
		System.out.println("GET api/getIssueTypes  ");
		try {
			List<IssueType> issueTypes = jira.getIssueTypes();
			String jsonInIssueTypes = mapper.writeValueAsString(issueTypes);
			message = jsonInIssueTypes;
		} catch (Exception e) {
			message = e.getMessage();
		}
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	/**
	 * Get Sprints - REST API Call with JIRA.
	 * 
	 * @return String String
	 * @throws JiraException
	 *             JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/getSprints", method = RequestMethod.GET)
	public ResponseEntity<String> getSprints() throws JiraException {
		String message = null;
		System.out.println("GET api/getSprints  ");
		try {
			AgileClient agileClient = new AgileClient(jira);
			List<Board> allBoards = agileClient.getBoards();
			long boardId = 0;
			for (Board board : allBoards) {
				if (properties.getBoard().equalsIgnoreCase(board.getName())) {
					boardId = board.getId();
				}
			}
			Board getBoard = agileClient.getBoard(boardId);
			List<Sprint> sprints = getBoard.getSprints();
			JSONObject jsonObject = new JSONObject();
			JSONArray jsonArray = new JSONArray();
			for (Sprint s : sprints) {
				JSONObject sprintJSON = new JSONObject();
				sprintJSON.put("id", s.getId());
				sprintJSON.put("name", s.getName());
				jsonArray.put(sprintJSON);
			}
			jsonObject.put("sprintList", jsonArray);
			message = jsonObject.toString();
		} catch (Exception e) {
			message = e.getMessage();
		}
		return new ResponseEntity<>(message, HttpStatus.OK);
	}

	/**
	 * Get Issue - REST API Call with JIRA.
	 * 
	 * @return String String
	 * @throws JiraException
	 *             JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/getIssue", method = RequestMethod.POST)
	public ResponseEntity<String> getIssues(@RequestBody String jiraIssues) throws JiraException {
		String message = null;
		try {
			JSONObject jsonObject = new JSONObject(jiraIssues.toString());

			/* Search for issues */
			// String jql = properties.getJql();
			List<Map<String , String>> InputData=null;
			String pName = jsonObject.getString("projectname");// "COB";
			String tName = jsonObject.getString("issuetype");// "Test";
			String sName = jsonObject.getString("sprint");// "TEMP Sprint 2";
			String sTestingTpe = jsonObject.getString("TestingType");// "Regression";
			String jql = "project = " + pName + " AND issueType = " + tName + " AND Sprint in (\"" + sName + "\")"+ " AND labels in (\"" + sTestingTpe + "\")";
			System.out.println("POST api/getIssue  "+jql.toString());
			Issue.SearchResult searchResult = jira.searchIssues(jql);
			Issue issue = null;
			JSONObject json = new JSONObject();
			JSONArray array = new JSONArray();
			for (Issue searchIssue : searchResult.issues) {
				issue = jira.getIssue(searchIssue.getKey());
				JSONObject issueJSON = new JSONObject();
				issueJSON.put(JIRAConstants.ISSUE_KEY_LIST, issue.getKey());
				CustomJiraSelectFields runMode = mapper.readValue(
						issue.getField(JIRAConstants.CUSTOMFIELD_RUNMODE).toString(), CustomJiraSelectFields.class);
				if (runMode != null) {
					issueJSON.put(JIRAConstants.RUNMODE, runMode.getValue());
				}
				issueJSON.put(JIRAConstants.SUMMARY, issue.getField(JIRAConstants.SUMMARY).toString());
				InputData  = GetInputDetails(issue.getField(JIRAConstants.CUSTOMFIELD_INPUT_VALUES).toString());
				issueJSON.put(JIRAConstants.INPUT_VALUES, InputData);
				CustomJiraSelectFields restResult = mapper.readValue(
						issue.getField(JIRAConstants.CUSTOMFIELD_TEST_RESULT_STATUS).toString(),
						CustomJiraSelectFields.class);
				if (restResult != null) {
					issueJSON.put(JIRAConstants.TEST_RESULT_STATUS, restResult.getValue());
				}
				JSONArray dependentArray = new JSONArray();
				if (issue.getIssueLinks().toArray().length > 0) {
					for (IssueLink issueLink : issue.getIssueLinks()) {
						JSONObject issueDependJSON = new JSONObject();
						JSONObject JsonObj = new JSONObject(issueLink);
						if (JsonObj.has(JIRAConstants.INWARD_ISSUE)) {
							Issue inwardIssue = jira.getIssue(issueLink.getInwardIssue().getKey());
							issueDependJSON.put(JIRAConstants.ISSUE_KEY_LIST, inwardIssue.getKey());
							issueDependJSON.put(JIRAConstants.SUMMARY, inwardIssue.getDescription());
							InputData  = GetInputDetails(issue.getField(JIRAConstants.CUSTOMFIELD_INPUT_VALUES).toString());
							issueDependJSON.put(JIRAConstants.INPUT_VALUES, InputData);
						} else if (JsonObj.has(JIRAConstants.OUTWARD_ISSUE)) {
							Issue outwardIssue = jira.getIssue(issueLink.getOutwardIssue().getKey());
							issueDependJSON.put(JIRAConstants.ISSUE_KEY_LIST, outwardIssue.getKey());
							issueDependJSON.put(JIRAConstants.SUMMARY, outwardIssue.getDescription());
							InputData  = GetInputDetails(issue.getField(JIRAConstants.CUSTOMFIELD_INPUT_VALUES).toString());
							issueDependJSON.put(JIRAConstants.INPUT_VALUES, InputData);
						}
						dependentArray.put(issueDependJSON);
					}
					issueJSON.put("issueDependentList", dependentArray);
				}
				array.put(issueJSON);
			}
			json.put("issueList", array);
			message = json.toString();
		} catch (Exception e) {
			message = e.getMessage();
		}
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	private List<Map<String, String>> GetInputDetails(String IPValues) {
		// TODO Auto-generated method stub
		List<Map<String , String>> InputData  = new ArrayList<Map<String,String>>();
		try{
			//System.out.println("Input Values : \n"+IPValues);
			String lines[] = IPValues.split(JIRAConstants.RecordDelimiter);
			if (lines.length>1){
				String recordsCol[] = lines[0].split(JIRAConstants.ValueDelimiter);
				for (int i=1;i<lines.length;i++){
					Map<String,String> testCasesInput = new LinkedHashMap<String,String>();
					String records[] = lines[i].split(JIRAConstants.ValueDelimiter);
					for (int j=0;j<records.length;j++){
						testCasesInput.put(recordsCol[j].trim(), records[j].trim());
					}
					InputData.add(testCasesInput);
				}
				//System.out.println("Final: "+InputData);
			}
		}
		catch(Exception e){
			System.out.println("Exception in Getting input fields" + e.getMessage());
		}
		return InputData;
		
	}
	
	
	 public static String GetInputDetailsText(List<Map<String , String>> listmap)
	    {
	    	String ResText=null;
	        try{
	        	ResText=JIRAConstants.DATAFLAG+JIRAConstants.ValueDelimiter+JIRAConstants.DATASETID
	        			+JIRAConstants.ValueDelimiter+JIRAConstants.REFURLValue+JIRAConstants.ValueDelimiter+JIRAConstants.HEADER_KEYS+JIRAConstants.ValueDelimiter+JIRAConstants.HEADER_VALUES+JIRAConstants.ValueDelimiter
	        			+JIRAConstants.PARAM_KEYS+JIRAConstants.ValueDelimiter+JIRAConstants.PARAM_VALUES+JIRAConstants.ValueDelimiter+JIRAConstants.GET_OUTPUT_KEY+JIRAConstants.ValueDelimiter
	        			+JIRAConstants.EXPECTED_STATUS_CODE+JIRAConstants.ValueDelimiter+JIRAConstants.EXPECTED_KEYS+JIRAConstants.ValueDelimiter+JIRAConstants.EXPECTED_VALUES;
	            for (Map<String, String> Ipmap : listmap) {
	            	ResText=ResText+JIRAConstants.NEWLineDelimiter+Ipmap.get(JIRAConstants.DATAFLAG)+JIRAConstants.ValueDelimiter+Ipmap.get(JIRAConstants.DATASETID)+JIRAConstants.ValueDelimiter+Ipmap.get(JIRAConstants.REFURLValue)+JIRAConstants.ValueDelimiter
	            			+Ipmap.get(JIRAConstants.HEADER_KEYS)+JIRAConstants.ValueDelimiter+Ipmap.get(JIRAConstants.HEADER_VALUES)+JIRAConstants.ValueDelimiter+Ipmap.get(JIRAConstants.PARAM_KEYS)+JIRAConstants.ValueDelimiter
	            			+Ipmap.get(JIRAConstants.PARAM_VALUES)+JIRAConstants.ValueDelimiter+Ipmap.get(JIRAConstants.GET_OUTPUT_KEY)+JIRAConstants.ValueDelimiter+Ipmap.get(JIRAConstants.EXPECTED_STATUS_CODE)+JIRAConstants.ValueDelimiter
	            			+Ipmap.get(JIRAConstants.EXPECTED_KEYS)+JIRAConstants.ValueDelimiter+Ipmap.get(JIRAConstants.EXPECTED_VALUES);
	            }
	        }
	        catch(Exception e){
	            System.out.println("Exception in Getting input fields text" + e.getMessage());
	        }
	        return ResText;
	    }

	 public List<Map<String, String>> json_string_to_listmap(String json){   
		    Gson gson = new Gson();
		    Type type = new TypeToken<ArrayList<Map<String, String>>>() {}.getType();
		    // Use fromJson method to deserialize json into an ArrayList of Map
		    return gson.fromJson(json , type);
		}
	 
	 /**
		 * Update Issue - REST API Call with JIRA.
		 * 
		 * @return String String
		 * @throws JiraException
		 *             JiraException
		 * @throws JSONException
		 *             JSONException
		 */
		@SuppressWarnings("serial")
		@CrossOrigin
		@RequestMapping(value = "/updateIssueDetails", method = RequestMethod.POST)
		public ResponseEntity<String> updateIssuesInputDetails(@RequestBody String jiraIssues) throws JiraException, JSONException {
			// @RequestBody String jiraIssues
			String message = null;
			List<String> runModeUpdate = new ArrayList<String>();
			JSONObject jsonObject = new JSONObject(jiraIssues.toString());
			JSONArray jsonArray = jsonObject.getJSONArray("updateIssueDetails");
			System.out.println("POST api/updateIssueDetails  "+jiraIssues);
			for (int i = 0, size = jsonArray.length(); i < size; i++) {
				final JSONObject objectInArray = jsonArray.getJSONObject(i);
				try {
					Issue issue = jira.getIssue(objectInArray.get("Issue_key").toString());
					/* Update the JIRA Fields. */
					
					if (StringUtils.isNotEmpty(objectInArray.get(JIRAConstants.INPUT_VALUES).toString())
							&& !objectInArray.get(JIRAConstants.INPUT_VALUES).equals(JIRAConstants.NULL_VALUE)) {	
						 List<Map<String , String>> listInputData  =  json_string_to_listmap(objectInArray.get(JIRAConstants.INPUT_VALUES).toString());
					     String JiraIPValue=GetInputDetailsText(listInputData);
						issue.update()
								.field(JIRAConstants.CUSTOMFIELD_INPUT_VALUES,JiraIPValue)
								.execute();
						message = "{\"message\" : \"success\" }";
					} else {
						System.out.println("jira Value to not Inserted ");
					}
				} catch (Exception e) {
					message = "Error in Issue update!!!" + e.getMessage();
				}

			}
			return new ResponseEntity<>(message, HttpStatus.OK);
		}

	/**
	 * Update Issue - REST API Call with JIRA.
	 * 
	 * @return String String
	 * @throws JiraException
	 *             JiraException
	 * @throws JSONException
	 *             JSONException
	 */
	@SuppressWarnings("serial")
	@CrossOrigin
	@RequestMapping(value = "/updateIssue", method = RequestMethod.POST)
	public ResponseEntity<String> updateIssues(@RequestBody String jiraIssues) throws JiraException, JSONException {
		// @RequestBody String jiraIssues
		String message = null;
		List<String> runModeUpdate = new ArrayList<String>();
		JSONObject jsonObject = new JSONObject(jiraIssues.toString());
		JSONArray jsonArray = jsonObject.getJSONArray("updateIssue");
		System.out.println("POST api/updateIssue  "+jiraIssues);
		for (int i = 0, size = jsonArray.length(); i < size; i++) {
			final JSONObject objectInArray = jsonArray.getJSONObject(i);
			try {
				Issue issue = jira.getIssue(objectInArray.get("Issue_key").toString());
				/* Update the JIRA Fields. */
				if (objectInArray.get("RunMode").equals(JIRAConstants.RUNMODE_VALUE_YES)
						&& StringUtils.isNotEmpty(objectInArray.get("RunMode").toString())
						&& !objectInArray.get("RunMode").equals(JIRAConstants.NULL_VALUE)) {
					issue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
						{
							add(objectInArray.get("RunMode"));
						}
					}).execute();
					runModeUpdate.add(issue.getKey());
					if (issue.getIssueLinks().toArray().length > 0) {
						for (IssueLink issueLink : issue.getIssueLinks()) {
							JSONObject JsonObj = new JSONObject(issueLink);
							if (JsonObj.has(JIRAConstants.INWARD_ISSUE)) {
								Issue inwardIssue = jira.getIssue(issueLink.getInwardIssue().getKey());
								inwardIssue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
									{
										add(JIRAConstants.RUNMODE_VALUE_YES);
									}
								}).execute();
								runModeUpdate.add(issueLink.getInwardIssue().getKey());
							}
							if (JsonObj.has(JIRAConstants.OUTWARD_ISSUE)) {
								Issue outwardIssue = jira.getIssue(issueLink.getOutwardIssue().getKey());
								outwardIssue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
									{
										add(JIRAConstants.RUNMODE_VALUE_YES);
									}
								}).execute();
								runModeUpdate.add(issueLink.getOutwardIssue().getKey());
							}
						}

					} else {
						issue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
							{
								add(objectInArray.get("RunMode"));
							}
						}).execute();
					}
				} else {
					if (!runModeUpdate.contains(issue.getKey())) {
						issue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
							{
								add(objectInArray.get("RunMode"));
							}
						}).execute();
					}
				}
			} catch (Exception e) {
				message = "Error in Issue update!!!" + e.getMessage();
			}

		}
		//Automation Main Script call
		message =this.executeIssues(jiraIssues);
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	
	/**
	 * Execute Issue - REST API Call with JIRA.
	 * 
	 * @return String String
	 * @throws JiraException
	 *             JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/executeIssue", method = RequestMethod.POST)
	public String executeIssues(@RequestBody String jiraIssues) throws JiraException {
		System.out.println("POST api/executeIssue  "+jiraIssues);
		JSONObject jsonObject = new JSONObject(jiraIssues.toString());
		String message = null;
		try {
			/* Search for issues */
			// String jql = properties.getJql();
			String pName = jsonObject.getString("projectname");//"COB";
			String tName = jsonObject.getString("issuetype");//"Test";
			String sName =  jsonObject.getString("sprint");//"TEMP Sprint 2";
			String sTestingTpe = jsonObject.getString("TestingType");// "Regression";
			String jql = "project = " + pName + " AND issueType = " + tName + " AND Sprint in (\"" + sName + "\")"+ " AND labels in (\"" + sTestingTpe + "\")";
			Constants.JIRAProject=pName;
			Constants.JIRAIssueType=tName;
			Constants.JIRASprint=sName;
			Constants.JIRATestingType=sTestingTpe;
			System.out.println("Execute:"+jql.toString());
//			DriverScript test = new DriverScript();
//			JsonObject js= test.startDriverScript(jira,jql,properties);
			
			DriverScript test = new DriverScript();
			JSONObject js= test.startDriverScript(jira,jql,properties);		
			message = js.toString();
		} catch (Exception e) {
			message = e.getMessage();
		}

		return message;
	}
	
	/**
	 * Execute Issue - REST API Call with Jenkin.
	 * 
	 * @return String String
	 * @throws JiraException
	 *             JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/JenkinScheduleJob", method = RequestMethod.POST)
	public ResponseEntity<String>  ScheduleJob(@RequestBody String jiraIssues) {
		//System.out.println("JenkinScheduleJob:"+jiraIssues.toString());
		//System.out.println("jiraIssues:"+jiraIssues.toString());
		// @RequestBody String jiraIssues
				String message = null;
				List<String> runModeUpdate = new ArrayList<String>();
				JSONObject jsonObject = new JSONObject(jiraIssues.toString());
				JSONArray jsonArray = jsonObject.getJSONArray("updateIssue");
				System.out.println("POST api/JenkinScheduleJob  "+jiraIssues);
				for (int i = 0, size = jsonArray.length(); i < size; i++) {
					final JSONObject objectInArray = jsonArray.getJSONObject(i);
					try {
						Issue issue = jira.getIssue(objectInArray.get("Issue_key").toString());
						/* Update the JIRA Fields. */
						if (objectInArray.get("RunMode").equals(JIRAConstants.RUNMODE_VALUE_YES)
								&& StringUtils.isNotEmpty(objectInArray.get("RunMode").toString())
								&& !objectInArray.get("RunMode").equals(JIRAConstants.NULL_VALUE)) {
							issue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
								{
									add(objectInArray.get("RunMode"));
								}
							}).execute();
							runModeUpdate.add(issue.getKey());
							if (issue.getIssueLinks().toArray().length > 0) {
								for (IssueLink issueLink : issue.getIssueLinks()) {
									JSONObject JsonObj = new JSONObject(issueLink);
									if (JsonObj.has(JIRAConstants.INWARD_ISSUE)) {
										Issue inwardIssue = jira.getIssue(issueLink.getInwardIssue().getKey());
										inwardIssue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
											{
												add(JIRAConstants.RUNMODE_VALUE_YES);
											}
										}).execute();
										runModeUpdate.add(issueLink.getInwardIssue().getKey());
									}
									if (JsonObj.has(JIRAConstants.OUTWARD_ISSUE)) {
										Issue outwardIssue = jira.getIssue(issueLink.getOutwardIssue().getKey());
										outwardIssue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
											{
												add(JIRAConstants.RUNMODE_VALUE_YES);
											}
										}).execute();
										runModeUpdate.add(issueLink.getOutwardIssue().getKey());
									}
								}

							} else {
								issue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
									{
										add(objectInArray.get("RunMode"));
									}
								}).execute();
							}
						} else {
							if (!runModeUpdate.contains(issue.getKey())) {
								issue.update().field(JIRAConstants.CUSTOMFIELD_RUNMODE, new ArrayList<Object>() {
									{
										add(objectInArray.get("RunMode"));
									}
								}).execute();
							}
						}
					} catch (Exception e) {
						message = "Error in Issue update!!!" + e.getMessage();
					}

				}
				//Jenking schedule
				JSONObject jsonProjectObject = new JSONObject(jiraIssues.toString());
				//String message = null;
				try {
					/* Search for issues */
					// String jql = properties.getJql();
					String pName = jsonProjectObject.getString("projectname");//"COB";
					String tName = jsonProjectObject.getString("issuetype");//"Test";
					String sName =  jsonProjectObject.getString("sprint");//"TEMP Sprint 2";
					String sTestingTpe = jsonProjectObject.getString("TestingType");// "Regression";
					String date = jsonObject.getString("date");//"Test";
					// Format for input
					DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
					// Parsing the date
					DateTime SchDatetime = dtf.parseDateTime(date);
					System.out.println("JenkinScheduleJob:: projectname :"+pName+"issuetype :"+tName+"sprint :"+sName+"TestingType :"+sTestingTpe+"Scheduled date :"+date);
					jenkinscheduler.scheduleJob(jenkinclient,pName,tName,sName,sTestingTpe, SchDatetime);
					//JsonObject js= test.startDriverScript(jira,jql,properties);
					message = "{\"message\" : \"success\" }";
				} catch (Exception e) {
					message = e.getMessage();
				}
		//return message;
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	
	/**
	 * Get Jenkin Build History - REST API Call with JIRA.
	 * 
	 * @return String String
	 * @throws JiraException
	 *             JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/JenkinBuildHistory", method = RequestMethod.GET)
	public ResponseEntity<String> JenkinBuildHistory(){
		String message = null;
		System.out.println("GET api/JenkinBuildHistory  ");
		try {
			JsonObject js=jenkinscheduler.BuildHistory(jenkinclient);
			//JsonObject js= test.startDriverScript(jira,jql,properties);
			Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
		    //System.out.println(gson.toJson(js));
			message =  gson.toJson(js);
		} catch (Exception e) {
			message = e.getMessage();
		}
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	
	/**
	 * Get API wise Average Response Time API GET Call with JIRA.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/APIWise_AvgRespTime", method = RequestMethod.GET)
    public ResponseEntity<String> APIWise_AvgRespTime() throws JiraException {		
		JSONArray apiArray = new JSONArray();
		String message = null;
		Issue issue = null;
		String ReqType=null;
		String APIUrl=null;
		String APIServer = null;
		int APICount=0;
		HashMap<String, ArrayList<Integer>> api = new HashMap<>();
		HashMap<String, String> mapapiServer = new HashMap<>();
		HashMap<String, String> mapapiUrl = new HashMap<>();
		HashMap<String, String> mapapiMethodType = new HashMap<>();
		try {
			String key;
			String value;
			String jql = properties.getJql();
			//Issue.SearchResult searchResult = jira.searchIssues(jql, "ResponseTime", "changelog");
			Issue.SearchResult searchResult = jira.searchIssues(jql);
			JSONObject apiIssueJson = new JSONObject();
			for (Issue searchIssue : searchResult.issues) {
				//System.out.println(".");
				CustomJiraSelectFields methodType = mapper.readValue(searchIssue
					.getField(JIRAConstants.CUSTOMFIELD_METHOD_TYPE)
					.toString(), CustomJiraSelectFields.class);
				if (methodType != null) {
						ReqType=methodType.getValue().toString();
				}
				APIUrl=searchIssue.getField(JIRAConstants.CUSTOMFIELD_URL).toString();
				value = searchIssue.getField(JIRAConstants.CUSTOMFIELD_RESPONSE_TIME).toString();
				APIServer=searchIssue.getField(JIRAConstants.CUSTOMFIELD_SERVER).toString();
				key = ReqType+" "+ APIUrl;
				mapapiServer.put(key, APIServer);
				mapapiUrl.put(key, APIUrl);
				mapapiMethodType.put(key, ReqType);
				//System.out.println("Key :"+searchIssue.getKey());
                for (IssueHistory history : jira.getIssueChangeLog(searchIssue)) {
                    for (IssueHistoryItem historyItem : history.getChanges()) {
                        if (historyItem.getField().equals(JIRAConstants.RESPONSE_TIME)) {
                           	 String responseTime = historyItem.getToStr().replace(" ms", "");
                           	// System.out.println("responseTime :"+responseTime);
	                          if(isInteger(responseTime)){
                            		if (api.containsKey(key)) {
                						api.get(key).add(Integer.parseInt(responseTime));
                					} else {
                						ArrayList<Integer> li = new ArrayList<>();
                						li.add(Integer.parseInt(responseTime));
                						api.put(key, li);
                					}
	                           }
                            }
                      }
               }
			}
			//System.out.println("Overall Api5 list"+api);
			HashMap<String, Integer> apiList = new HashMap<>();
			//JSONArray apiArray = new JSONArray();
			 for (String apiKey : api.keySet()) {
				 JSONObject apiJson = new JSONObject();
				 APICount=APICount+1;
				 Map<String,Integer> mapAvgResTime= sum(api.get(apiKey));
				 apiJson.put("apiID", "API"+APICount);
				 apiJson.put("apiServer", mapapiServer.get(apiKey));
				 //apiList.put(apiKey, sum(api.get(apiKey)));
				 apiJson.put("apiUrl", mapapiUrl.get(apiKey));
				 apiJson.put("apiName", apiKey);
				 apiJson.put("methodType", mapapiMethodType.get(apiKey));
				 apiJson.put("avgRespTime", mapAvgResTime.get("AvgRespTime"));
				 apiJson.put("Count", mapAvgResTime.get("Count"));
				 apiJson.put("MaxValue", mapAvgResTime.get("Max"));
				 apiJson.put("MinValue", mapAvgResTime.get("Min"));
				 apiArray.put(apiJson);
			 }
			//System.out.println(apiArray.toString());
		} catch (Exception e) {
			message = e.getMessage();
		}
        return new ResponseEntity<>(apiArray.toString(), HttpStatus.OK);
    }
	
	
	
	/**
	 * Get Version wise Average Response Time API POST Call with JIRA.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/VersionWise_AvgRespTime", method = RequestMethod.POST)
	public ResponseEntity<String> VersionWise_AvgRespTime(@RequestBody String APIDetails) throws JiraException, JsonParseException, JsonMappingException, IOException {
		String message = null;
		JSONObject jsonObject = new JSONObject(APIDetails.toString());
		JSONArray apiArray = new JSONArray();
		try {
			//Start API Version Details
			HashMap<String, ArrayList<Integer>> api1 = new HashMap<>();
			String server = jsonObject.getString("apiServer");//"http://10.146.217.20:3030";
			String apiURL = jsonObject.getString("apiUrl");//"/api/v1/AddDevice";
			String methodType =  jsonObject.getString("methodType");//"POST";
			//{'apiServer': 'http://10.146.217.20:3030', 'apiUrl': '/api/v1/AddDevice', 'methodType':'POST'}
			String jql1 = properties.getJql() + " AND Server ~ \""+server +"\" AND url ~ \""+apiURL+"\" AND MethodType in (\"" + methodType + "\")" ;
			System.out.println(jql1);
			Issue.SearchResult searchResult = jira.searchIssues(jql1);
			Issue issue1 = null;
			JSONObject apiIssueJson = new JSONObject();
			for (Issue searchIssue : searchResult.issues) {
				
				issue1 = jira.getIssue(searchIssue.getKey());
				List<String> verList = new ArrayList<String>();
  				for (Version ver : issue1.getFixVersions()) {
  					verList.add(ver.getName());
	                for (IssueHistory history : jira.getIssueChangeLog(searchIssue)) {
	                    for (IssueHistoryItem historyItem : history.getChanges()) {
	                        if (historyItem.getField().equals(JIRAConstants.RESPONSE_TIME)) {
	                           	 String responseTime = historyItem.getToStr().replace(" ms", "");
	                           	// System.out.println("responseTime :"+responseTime);
		                          if(isInteger(responseTime)){
	                            		if (api1.containsKey(ver.getName())) {
	                						api1.get(ver.getName()).add(Integer.parseInt(responseTime));
	                					} else {
	                						ArrayList<Integer> li = new ArrayList<>();
	                						li.add(Integer.parseInt(responseTime));
	                						api1.put(ver.getName(), li);
	                					}
		                           }
	                            }
	                      }
	               }
                 // System.out.println("Api5 list"+api);
			}
			
			}
			
			System.out.println("API Data : "+api1);
		 for (String apiKey : api1.keySet()) {
			 JSONObject apiJson = new JSONObject();
			 //apiJson.put("apiServer", APIServer);
			 Map<String,Integer> mapAvgResTime= sum(api1.get(apiKey));
			 apiJson.put("apiID", apiKey);
			 apiJson.put("apiServer", server);
			 apiJson.put("apiUrl", apiURL);
			 apiJson.put("methodType", methodType);
			 apiJson.put("avgRespTime", mapAvgResTime.get("AvgRespTime"));
			 apiJson.put("Count", mapAvgResTime.get("Count"));
			 apiJson.put("MaxValue", mapAvgResTime.get("Max"));
			 apiJson.put("MinValue", mapAvgResTime.get("Min"));
			 
			 apiArray.put(apiJson);
		 }
		 //System.out.println(apiArray.toString());
		} catch (Exception e) {
			message = e.getMessage();
		}
		return new ResponseEntity<>(apiArray.toString(), HttpStatus.OK);
	}
	
	/**
	 * Get Request time and Response Time for selected API POST Call with JIRA.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/Datewise_RespTime", method = RequestMethod.POST)
    public ResponseEntity<String> Datewise_RespTime(@RequestBody String APIDetails) throws JiraException {		
		JSONObject jsonObject = new JSONObject(APIDetails.toString());
		JSONArray apiArray = new JSONArray();
		String message = null;
		try {
			//Start API Version Details
			String server = jsonObject.getString("apiServer");//"http://10.146.217.20:3030";
			String apiURL = jsonObject.getString("apiUrl");//"/api/v1/AddDevice";
			String methodType =  jsonObject.getString("methodType");//"POST";
			String version = jsonObject.getString("version");//"CoHo-Test-V1.0.0.0";
//          {'apiServer': 'http://10.146.217.20:3030', 'apiUrl': '/api/v1/AddDevice', 'methodType':'POST', 'version':'CoHo-Test-V1.0.0.0'}
			String jql1 = properties.getJql() + " AND Server ~ \""+server +"\" AND url ~ \""+apiURL+"\" AND MethodType in (\"" + methodType + "\") "
           		+ "AND fixVersion= \""+ version+"\"" ;
			System.out.println(jql1);
			//System.out.println("Hello"+jql1);
			Issue.SearchResult searchResult = jira.searchIssues(jql1, "ResponseTime", "changelog");
			JSONObject apiIssueJson = new JSONObject();
			for (Issue searchIssue : searchResult.issues) {
                 // apiIssueJson.put(searchIssue.getKey(), getIssueHistory(searchIssue));
                 // apiArray.put(apiIssueJson);
                  for (IssueHistory history : jira.getIssueChangeLog(searchIssue)) {
                      for (IssueHistoryItem historyItem : history.getChanges()) {
                            if (historyItem.getField().equals(JIRAConstants.RESPONSE_TIME)) {
	                               String responseTime = historyItem.getToStr().replace(" ms", "");
	                               //String date = history.getCreated().toString();
	                               Date respDate=history.getCreated();
	                               String date =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(respDate);
	                               JSONObject apiJson = new JSONObject();
	                               if((!responseTime.equalsIgnoreCase(""))&(!responseTime.equalsIgnoreCase("0"))){
                            	   		//System.out.println("date :"+date);
	                           		  	apiJson.put("Issue_key", searchIssue.getKey());
	                           		  	apiJson.put("apiID", date);
	                           		  	apiJson.put("avgRespTime", Integer.parseInt(responseTime));
	                           		  	apiArray.put(apiJson);
	                               }
                            }
                      }
               }
			}
			//System.out.println(apiArray.toString());
		} catch (Exception e) {
			message = e.getMessage();
		}
        return new ResponseEntity<>(apiArray.toString(), HttpStatus.OK);
    }

	
	
	/**
	 * Get API wise Average Response Time API GET Call with JIRA.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/APIWise_StatusCount", method = RequestMethod.GET)
    public ResponseEntity<String> APIWise_StatusCount() throws JiraException {		
		JSONArray apiArray = new JSONArray();
		String message = null;
		Issue issue = null;
		String ReqType=null;
		String APIUrl=null;
		String APIServer = null;
		int APICount=0;
		int iAPIPassCount=0;
		int iAPIFailCount=0;
		HashMap<String, Integer> apiPassCount = new HashMap<>();
		HashMap<String, Integer> apicount = new HashMap<>();
		HashMap<String, Integer> apiFailCount = new HashMap<>();
		HashMap<String, String> mapapiServer = new HashMap<>();
		HashMap<String, String> mapapiUrl = new HashMap<>();
		HashMap<String, String> mapapiMethodType = new HashMap<>();
		try {
			String key;
			String value;
			String jql = properties.getJql();
			//Issue.SearchResult searchResult = jira.searchIssues(jql, "ResponseTime", "changelog");
			Issue.SearchResult searchResult = jira.searchIssues(jql);
			JSONObject apiIssueJson = new JSONObject();
			for (Issue searchIssue : searchResult.issues) {
				
				String sTestcaseStatus="Pass";
				int ApiCount=0;
				//System.out.println(".");
				CustomJiraSelectFields methodType = mapper.readValue(searchIssue
					.getField(JIRAConstants.CUSTOMFIELD_METHOD_TYPE)
					.toString(), CustomJiraSelectFields.class);
				if (methodType != null) {
						ReqType=methodType.getValue().toString();
				}
				APIUrl=searchIssue.getField(JIRAConstants.CUSTOMFIELD_URL).toString();
				value = searchIssue.getField(JIRAConstants.CUSTOMFIELD_RESPONSE_TIME).toString();
				APIServer=searchIssue.getField(JIRAConstants.CUSTOMFIELD_SERVER).toString();
				key = ReqType+" "+ APIUrl;
				mapapiServer.put(key, APIServer);
				mapapiUrl.put(key, APIUrl);
				mapapiMethodType.put(key, ReqType);
				
				//System.out.println("Key :"+searchIssue.getKey());
                for (IssueHistory history : jira.getIssueChangeLog(searchIssue)) {
                    for (IssueHistoryItem historyItem : history.getChanges()) {
                    	
                    	if (historyItem.getField().equals(JIRAConstants.TEST_RESULT_STATUS)) {
                   		 String TestStatus = historyItem.getToStr();
                   		 if(!TestStatus.equalsIgnoreCase("")){
                   			 sTestcaseStatus=TestStatus;
                   		 }
                   	  }
                        if (historyItem.getField().equals(JIRAConstants.RESPONSE_TIME)) {
                           	 String responseTime = historyItem.getToStr().replace(" ms", "");
                           	// System.out.println("responseTime :"+responseTime);
	                          if(!responseTime.equalsIgnoreCase("")){
	                        	  if(sTestcaseStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
	                        	  {
                            		if (apiPassCount.containsKey(key)) {
                						ApiCount=apiPassCount.get(key);
                						ApiCount=ApiCount+1;
                						apiPassCount.put(key, ApiCount);
                					} else {
                						apiPassCount.put(key, 1);
                						apicount.put(key, 1);
                					}
	                        	  }
	                        	  else
	                        	  {
	                        		  if (apiFailCount.containsKey(key)) {
	                						ApiCount=apiFailCount.get(key);
	                						ApiCount=ApiCount+1;
	                						apiFailCount.put(key, ApiCount);
	                					} else {
	                						apiFailCount.put(key, 1);
	                						apicount.put(key, 1);
	                					}
	                        	  }
	                           }
                            }
                      }
               }
			}
			//System.out.println("Overall Api5 apiPassCount : "+apiPassCount);
			//System.out.println("Overall Api5 apiFailCount : "+apiFailCount);
			//JSONArray apiArray = new JSONArray();
			 for (String apiKey : apicount.keySet()) {
				 JSONObject apiJson = new JSONObject();
				 APICount=APICount+1;
				 apiJson.put("apiID", "API"+APICount);
				 apiJson.put("apiServer", mapapiServer.get(apiKey));
				 if (apiPassCount.containsKey(apiKey)) {
					 iAPIPassCount= apiPassCount.get(apiKey);
				 }
				 else
				 {
					 iAPIPassCount=0;
				 }
				 if (apiFailCount.containsKey(apiKey)) {
					 iAPIFailCount= apiFailCount.get(apiKey);
				 }
				 else
				 {
					 iAPIFailCount=0;
				 }
				 
				 //apiList.put(apiKey, sum(api.get(apiKey)));
				 apiJson.put("apiUrl", mapapiUrl.get(apiKey));
				 apiJson.put("apiName", apiKey);
				 apiJson.put("methodType", mapapiMethodType.get(apiKey));
				 apiJson.put("PassCount", iAPIPassCount);
				 apiJson.put("FailCount", iAPIFailCount);
				 apiArray.put(apiJson);
			 }
			//System.out.println(apiArray.toString());
		} catch (Exception e) {
			message = e.getMessage();
		}
        return new ResponseEntity<>(apiArray.toString(), HttpStatus.OK);
    }
	
	
	
	/**
	 * Get Version wise Average Response Time API POST Call with JIRA.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/VersionWise_StatusCount", method = RequestMethod.POST)
	public ResponseEntity<String> VersionWise_StatusCount(@RequestBody String APIDetails) throws JiraException, JsonParseException, JsonMappingException, IOException {
		String message = null;
		JSONObject jsonObject = new JSONObject(APIDetails.toString());
		JSONArray apiArray = new JSONArray();
		try {
			//Start API Version Details
			HashMap<String, ArrayList<Integer>> api1 = new HashMap<>();
			HashMap<String, Integer> apiPassCount = new HashMap<>();
			HashMap<String, Integer> apicount = new HashMap<>();
			HashMap<String, Integer> apiFailCount = new HashMap<>();
			String server = jsonObject.getString("apiServer");//"http://10.146.217.20:3030";
			String apiURL = jsonObject.getString("apiUrl");//"/api/v1/AddDevice";
			String methodType =  jsonObject.getString("methodType");//"POST";
			//{'apiServer': 'http://10.146.217.20:3030', 'apiUrl': '/api/v1/AddDevice', 'methodType':'POST'}
			String jql1 = properties.getJql() + " AND Server ~ \""+server +"\" AND url ~ \""+apiURL+"\" AND MethodType in (\"" + methodType + "\")" ;
			System.out.println(jql1);
			Issue.SearchResult searchResult = jira.searchIssues(jql1);
			Issue issue1 = null;
			JSONObject apiIssueJson = new JSONObject();
			for (Issue searchIssue : searchResult.issues) {
				
				String sTestcaseStatus="Pass";
				int ApiCount=0;
				issue1 = jira.getIssue(searchIssue.getKey());
				List<String> verList = new ArrayList<String>();
  				for (Version ver : issue1.getFixVersions()) {
  					verList.add(ver.getName());
	                for (IssueHistory history : jira.getIssueChangeLog(searchIssue)) {
	                    for (IssueHistoryItem historyItem : history.getChanges()) {
	                    	
	                    	if (historyItem.getField().equals(JIRAConstants.TEST_RESULT_STATUS)) {
	                      		 String TestStatus = historyItem.getToStr();
	                      		 if(!TestStatus.equalsIgnoreCase("")){
	                      			 sTestcaseStatus=TestStatus;
	                      		 }
	                      	  }
	                        if (historyItem.getField().equals(JIRAConstants.RESPONSE_TIME)) {
	                           	 String responseTime = historyItem.getToStr().replace(" ms", "");
	                           	// System.out.println("responseTime :"+responseTime);
	                           	 
	                           	 if(!responseTime.equalsIgnoreCase("")){
		                        	  if(sTestcaseStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
		                        	  {
	                            		if (apiPassCount.containsKey(ver.getName())) {
	                						ApiCount=apiPassCount.get(ver.getName());
	                						ApiCount=ApiCount+1;
	                						apiPassCount.put(ver.getName(), ApiCount);
	                					} else {
	                						apiPassCount.put(ver.getName(), 1);
	                						apicount.put(ver.getName(), 1);
	                					}
		                        	  }
		                        	  else
		                        	  {
		                        		  if (apiFailCount.containsKey(ver.getName())) {
		                						ApiCount=apiFailCount.get(ver.getName());
		                						ApiCount=ApiCount+1;
		                						apiFailCount.put(ver.getName(), ApiCount);
		                					} else {
		                						apiFailCount.put(ver.getName(), 1);
		                						apicount.put(ver.getName(), 1);
		                					}
		                        	  }
		                           }
	                            }
	                      }
	               }
                 // System.out.println("Api5 list"+api);
  				}
			}
			System.out.println("API Data : "+api1);
		 for (String apiKey : apicount.keySet()) {
			 JSONObject apiJson = new JSONObject();
			 //apiJson.put("apiServer", APIServer);
			 apiJson.put("apiID", apiKey);
			 apiJson.put("apiServer", server);
			 apiJson.put("apiUrl", apiURL);
			 apiJson.put("methodType", methodType);
			 apiJson.put("PassCount", apiPassCount.get(apiKey));
			 apiJson.put("FailCount", apiFailCount.get(apiKey));
			 apiArray.put(apiJson);
		 }
		 //System.out.println(apiArray.toString());
		} catch (Exception e) {
			message = e.getMessage();
		}
		return new ResponseEntity<>(apiArray.toString(), HttpStatus.OK);
	}
	
	/**
	 * Get Request time and Response Time for selected API Call with JIRA.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/Datewise_StatusCount", method = RequestMethod.POST)
    public ResponseEntity<String> Datewise_StatusCount(@RequestBody String APIDetails) throws JiraException {		
		JSONObject jsonObject = new JSONObject(APIDetails.toString());
		JSONArray apiArray = new JSONArray();
		String message = null;
		try {
			//Start API Version Details
			String server = jsonObject.getString("apiServer");//"http://10.146.217.20:3030";
			String apiURL = jsonObject.getString("apiUrl");//"/api/v1/AddDevice";
			String methodType =  jsonObject.getString("methodType");//"POST";
			String version = jsonObject.getString("version");//"CoHo-Test-V1.0.0.0";
//          {'apiServer': 'http://10.146.217.20:3030', 'apiUrl': '/api/v1/AddDevice', 'methodType':'POST', 'version':'CoHo-Test-V1.0.0.0'}
			String jql1 = properties.getJql() + " AND Server ~ \""+server +"\" AND url ~ \""+apiURL+"\" AND MethodType in (\"" + methodType + "\") " ;
			System.out.println(jql1);
			//System.out.println("Hello"+jql1);
			Issue.SearchResult searchResult = jira.searchIssues(jql1, "ResponseTime", "changelog");
			JSONObject apiIssueJson = new JSONObject();
			for (Issue searchIssue : searchResult.issues) {
                 // apiIssueJson.put(searchIssue.getKey(), getIssueHistory(searchIssue));
                 // apiArray.put(apiIssueJson);
				String sTestcaseStatus="Pass";
                  for (IssueHistory history : jira.getIssueChangeLog(searchIssue)) {
                      for (IssueHistoryItem historyItem : history.getChanges()) {
                    	  //System.out.println("historyItem Field :"+historyItem.getField());
                    	  //if ((historyItem.getField().equals(JIRAConstants.TEST_RESULT_STATUS))|(historyItem.getField().equals(JIRAConstants.RESPONSE_TIME))|(historyItem.getField().equals(JIRAConstants.OUTPUT_VALUES))) {
                    	if (historyItem.getField().equals(JIRAConstants.TEST_RESULT_STATUS)) {
                    		 String TestStatus = historyItem.getToStr();
                    		 if(!TestStatus.equalsIgnoreCase("")){
                    			 sTestcaseStatus=TestStatus;
                    		 }
                    	  }
                            if (historyItem.getField().equals(JIRAConstants.RESPONSE_TIME)) {
                            	 String responseTime = historyItem.getToStr().replace(" ms", "");
	                               //String date = history.getCreated().toString();
	                               Date respDate=history.getCreated();
	                               String date =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(respDate);
	                               JSONObject apiJson = new JSONObject();
	                               if(!responseTime.equalsIgnoreCase("")){
                            	   		//System.out.println("date :"+date);
	                           		  	apiJson.put("Issue_key", searchIssue.getKey());
	                           		  	apiJson.put("apiID", date);
	                           		  	apiJson.put("RespTime", Integer.parseInt(responseTime));
	                           		  	apiJson.put("Status", sTestcaseStatus);
	                           		  	apiArray.put(apiJson);
	                               }
                            }
                      }
               }
			}
			//System.out.println(apiArray.toString());
		} catch (Exception e) {
			message = e.getMessage();
		}
        return new ResponseEntity<>(apiArray.toString(), HttpStatus.OK);
    }
	
	
	
	
	/**
	 * Get Request time and Response Time for selected API Call with JIRA.
	 * 
	 * @return String
	 * @throws JiraException
	 */
	@CrossOrigin
	@RequestMapping(value = "/query", method = RequestMethod.POST)
    public ResponseEntity<String> query(@RequestBody String APIDetails) throws JiraException {		
		

		JSONObject jsonObject = new JSONObject(APIDetails.toString());
		System.out.println("Json Grafana :"+jsonObject);
		HashMap<String, Integer> apicount = new HashMap<>();
		JSONObject resjsonObject = new JSONObject();
		resjsonObject.put("timings", "null");
		JSONObject js=new JSONObject();
		JSONArray apiArray = new JSONArray();
		String message = null;
		try {
			//Start API Version Details
			String server = "http://10.146.217.20:3030";
			String apiURL ="/api/v1/AddDevice";
			String methodType = "POST";
			String version ="CoHo-Test-V1.0.0.0";
//          {'apiServer': 'http://10.146.217.20:3030', 'apiUrl': '/api/v1/AddDevice', 'methodType':'POST', 'version':'CoHo-Test-V1.0.0.0'}
			String jql1 = properties.getJql() + " AND Server ~ \""+server +"\" AND url ~ \""+apiURL+"\" AND MethodType in (\"" + methodType + "\") " ;
			System.out.println(jql1);
			
		 	
		    JSONArray timeArray = new JSONArray();
		    timeArray.put(apicount.get("A"));
		    js.put("timings", timeArray);
		    JSONObject jsre=new JSONObject();
		    JSONObject jsrA=new JSONObject();
		    JSONArray SerArray = new JSONArray();
		    
			//System.out.println("Hello"+jql1);
			Issue.SearchResult searchResult = jira.searchIssues(jql1, "ResponseTime", "changelog");
			JSONObject apiIssueJson = new JSONObject();
			for (Issue searchIssue : searchResult.issues) {
                 // apiIssueJson.put(searchIssue.getKey(), getIssueHistory(searchIssue));
                 // apiArray.put(apiIssueJson);
				  Date incrementedDate = new Date();
				if (searchIssue.getKey().equalsIgnoreCase("COB-344"))
				{
					 JSONObject serJson = new JSONObject();
					 serJson.put("name", "A-series");
					
					 
					JSONArray apiArray1 = new JSONArray();
					
					String sTestcaseStatus="Pass";
					
					 JSONArray pts = new JSONArray();
	                  for (IssueHistory history : jira.getIssueChangeLog(searchIssue)) {
	                	  
	                      for (IssueHistoryItem historyItem : history.getChanges()) {
	                    	  //System.out.println("historyItem Field :"+historyItem.getField());
	                    	  //if ((historyItem.getField().equals(JIRAConstants.TEST_RESULT_STATUS))|(historyItem.getField().equals(JIRAConstants.RESPONSE_TIME))|(historyItem.getField().equals(JIRAConstants.OUTPUT_VALUES))) {
	                    	if (historyItem.getField().equals(JIRAConstants.TEST_RESULT_STATUS)) {
	                    		 String TestStatus = historyItem.getToStr();
	                    		 if(!TestStatus.equalsIgnoreCase("")){
	                    			 sTestcaseStatus=TestStatus;
	                    		 }
	                    	  }
	                            if (historyItem.getField().equals(JIRAConstants.RESPONSE_TIME)) {
	                            	 String responseTime = historyItem.getToStr().replace(" ms", "");
		                               //String date = history.getCreated().toString();
		                               Date respDate=history.getCreated();
		                               String date =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(respDate);
		                               
		                             
		                   	         incrementedDate = DateUtils.addHours(incrementedDate, 1);
		                   	        
		                               if(!responseTime.equalsIgnoreCase("")){
	                            	   		//System.out.println("date :"+date); 	
		                           		 JSONArray pts2 = new JSONArray();
		                 				 pts2.put(Integer.parseInt(responseTime));
		                 				 pts2.put(incrementedDate.getTime());
		                 				 pts.put(pts2);
		                           		  	
		                               }
	                            }
	                      }  
	               }
	                  serJson.put("points", pts);
	                  SerArray.put(serJson);
					}
			}
			
			 jsre.put("series", SerArray);
			 jsre.put("refId", "A");
			 jsre.put("tables",apicount.get("A"));
			 jsrA.put("A", jsre);
			 js.put("results", jsrA);
			 apiArray.put(SerArray);
			 System.out.println(js.toString());
		} catch (Exception e) {
			message = e.getMessage();
		}
		//apiArray.put(apiJson1);
        return new ResponseEntity<>(js.toString(), HttpStatus.OK);
    }

	
	
    public JSONArray getIssueHistory(Issue issue) throws JiraException {
           JSONArray apiArray = new JSONArray();           
           for (IssueHistory history : jira.getIssueChangeLog(issue)) {
                  for (IssueHistoryItem historyItem : history.getChanges()) {
                        if (historyItem.getField().equals(JIRAConstants.RESPONSE_TIME)) {
                        	String responseTime = historyItem.getToStr().replace(" ms", "");
                            //String date = history.getCreated().toString();
                            Date respDate=history.getCreated();
                            String date =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(respDate);
                            JSONObject apiJson = new JSONObject();
                            if((!responseTime.equalsIgnoreCase(""))&(!responseTime.equalsIgnoreCase("0"))){
                     	   		//System.out.println("date :"+date);
                        		  	apiJson.put("Issue_key", issue.getKey());
                        		  	apiJson.put("apiID", date);
                        		  	apiJson.put("avgRespTime", Integer.parseInt(responseTime));
                        		  	apiArray.put(apiJson);
                            }
                        }
                  }
           }
           return apiArray;
    }

	
	
	public static Map<String,Integer> sum(List<Integer> ints) {

		int sum = 0;
		int size = ints.size();
		Map<String,Integer> mapAvgResTime = new HashMap<String,Integer>();
		mapAvgResTime.put("Count", size);
		for (Integer i : ints) {
			sum += i;
		}
		int result = sum/size;
		mapAvgResTime.put("AvgRespTime", result);
		mapAvgResTime.put("Max", Collections.max(ints));
		mapAvgResTime.put("Min", Collections.min(ints));
		//System.out.println("List Ints "+ints+" \n Avg Values \n "+mapAvgResTime);
		return mapAvgResTime;
	}
	
	public boolean isInteger( String input )
	{
		boolean bInt=false;
	   try
	   {
	      if((!input.equalsIgnoreCase(""))&(!input.equalsIgnoreCase("0")))
	      {
	    	   Integer.parseInt(input);
	    	   bInt=true;
	    	   return bInt;
	      }
	   }
	   catch( Exception e )
	   {
	      return bInt;
	   }
	   return bInt;
	}
}
