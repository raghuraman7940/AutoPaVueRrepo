package com.verizon;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.JsonObject;
import com.verizon.util.ReportJSON;
import com.verizon.config.JiraProperties;
import com.verizon.controllers.JiraService;
import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.util.App;
import com.verizon.util.WorkerTestSet;
import com.verizon.util.Constants;
import com.verizon.util.ReportUtil;

import io.restassured.path.json.JsonPath;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;

public class DriverScript {
	//Log object Creation
	public static Logger APP_LOGS;
	public static JiraService jiraService;
	//App Object creation;
	public static App API;
	public static WorkerTestSet wTestSet;
	public static ReportUtil Rep;
 	public static ReportJSON RepJs;
	// properties
	public static Properties CONFIG;
	public static List<String> DependentList;
	public static JSONObject jsonTestReportData;
	
	/**
	 * 
	 * Constructor for intializing the log, properties and Object.
	 * 
	 */
	public DriverScript() throws NoSuchMethodException, SecurityException, JiraException,IOException {
		// Initialize the app logs
		APP_LOGS = Logger.getLogger("devpinoyLogger");
		APP_LOGS.debug("Hello");
		APP_LOGS.debug("Start API Automation testing");
		// Initialize Configuration
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + Constants.CONFIG_FILEPATH + Constants.CONFIG_FILE);
		CONFIG = new Properties();
		CONFIG.load(fs);
		APP_LOGS.debug("Properties loaded.");
		//Initialize objects
	//	API = new App();
		API=new App();
		wTestSet=new WorkerTestSet();
		Rep = new ReportUtil();
		RepJs=new ReportJSON();
		jiraService = new JiraService();
		DependentList = new ArrayList<String>();
		jsonTestReportData = new JSONObject();
	}
	
	/***************************************************************************************
  	 *  Function name 		: startDriverScript
  	 *  Reuse Function 		:  
  	 *  Description 		: Start Execution
  	/****************************************************************************************/ 
	public JSONObject startDriverScript(JiraClient jira, String jql,JiraProperties properties) throws NoSuchMethodException, SecurityException, IOException, JiraException,IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	//public static void main (String arg[]){
		// Initialize and execute
		JSONObject jsonRep=null;
		try {
			APP_LOGS.debug("Start Rest API Execution");
			// Export Issues from JIRA
			JsonObject JsonTestData= jiraService.JiraJSONExport(jira, jql, properties);
			
			long startTime = System.currentTimeMillis();
			
			// Main driver function, read from excel and execute
			JSONObject jsRepData=ReadJSON_Data(jira,JsonTestData);
			//System.out.println("Completed Report : \n"+jsRepData);
			//End of Execution
			
			//Calculate execution time taken
			long endTime   = System.currentTimeMillis();
	    	long totalTime = endTime - startTime;
	    	Constants.ExecutionDuration=Long.toString(TimeUnit.MILLISECONDS.toSeconds(totalTime));
	    	Constants.TimeType=" Secs";
			//Generate report
	    	 if (CONFIG.getProperty("ReportType").equalsIgnoreCase("JSON")){
	    		 jsonRep= RepJs.BuildJSONReport(jsRepData);
		     }
//	    	 else{ //Excel
//	    		 Rep.GeneratehtmlReport();
//	    	 }
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonRep;
	}
	
	/*************************************************************************************************
	 *  Function name 		: ReadJSON_Data
	 *  Reuse Function 		: 
	 *  Description 		: Read the all the Excel values.Based on the inputs flow the functionality. 
	/
	 * @throws ProcessingException 
	 * @throws JiraException **************************************************************************************************/  
    public JSONObject ReadJSON_Data(JiraClient jira,JsonObject JsonTestData)throws AbstractMethodError, BiffException, IOException,  WriteException, ProcessingException, JiraException
    {
        String TestCaseID,TestRunMode;
		JSONObject jsTestData = new JSONObject(JsonTestData.toString());
		//JSONObject jsTestReportData = new JSONObject();
		//System.out.println(JsonTestData);
		String ExecuteType=CONFIG.getProperty("TestSetExecutionType");//Parallel//Sequential
		boolean bConExecution=false;
        ExecutorService executor = null;
		int iThread=Integer.parseInt(CONFIG.getProperty("ThreadCount"));
		executor = Executors.newFixedThreadPool(iThread);
		
		jsonTestReportData.put(Constants.JSReportTitle, "API Automation Test Report");
		Date d = new Date();
		jsonTestReportData.put(Constants.JSRunDate, d.toString());
		//Check wheather dependent or non dependent
		boolean bDependent=VerifyDependents(jsTestData,"Tests.DependentIssues.Issue_key","Tests.Issue_key");
		//Tests
        JSONArray TestSets = (JSONArray) jsTestData.get("Tests");
        for (int iTestIter = 0; iTestIter < TestSets.length(); iTestIter++) {
        	//System.out.println("DependentList : "+DependentList);
        	JSONObject Testset = TestSets.getJSONObject(iTestIter);
            TestRunMode = Testset.get(Constants.TESTRUNMODE).toString();
            TestCaseID = Testset.get(Constants.TCID).toString();
            if ((TestRunMode.equalsIgnoreCase("YES"))&&(!DependentList.contains(TestCaseID))){
                //Execute Dependents Issues
                JSONArray DependentTests = (JSONArray) Testset.get("DependentIssues");
                if(DependentTests.length()>0){
	                for (int iDepenIter = 0; iDepenIter < DependentTests.length(); iDepenIter++) {
	                	JSONObject DependentTest = DependentTests.getJSONObject(iDepenIter);
	                	String FilterQuery="Tests.findAll{Tests->Tests.Issue_key==datefilter}";
	                	String FilterValue=DependentTest.get("Issue_key").toString();
	                	if (!DependentList.contains(FilterValue)){
	                		DependentIssueExecution(jira,jsTestData, FilterQuery,FilterValue);
	                	}
	                }
	                //Sequential Execution
	                wTestSet.TestExecution(jira,Testset);
                	DependentList.add(TestCaseID);
					//System.out.println("Seq: "+jsonTestReportData);	
                }
                else{
                	if ((ExecuteType.contains("Parallel"))&(!bDependent)) {
                		// Execute Concurrent in Thread
                		bConExecution=true;
                		DependentList.add(TestCaseID);
						Runnable worker = new WorkerTestSet(jira,Testset,"Testset");
						executor.execute(worker);// calling execute
						//System.out.println("Concurrent Report: "+jsonTestReportData);
                	}
                	else{
                		wTestSet.TestExecution(jira,Testset);
                		DependentList.add(TestCaseID);
                		//System.out.println("Sequential Report: "+jsonTestReportData);
					}
                }
            }
         }
        if ((ExecuteType.contains("Parallel"))&(bConExecution)) {
 			executor.shutdown();
 			// Wait Till all thread complete
 			while (!executor.isTerminated()) {
 			}
 			System.out.println(" DataSet Finished all threads");
	 	}
        //System.out.println(JsonTestData);
        return jsonTestReportData;
    }
    
    
	/*************************************************************************************************
	 *  Function name 		: DependentIssueExecution
	 *  Reuse Function 		: 
	 *  Description 		: Read the dependent issues and execute first. 
	/
	 * @throws ProcessingException 
	 * @throws JiraException **************************************************************************************************/ 
    public JSONObject DependentIssueExecution(JiraClient jira,JSONObject JsonTestData, String FilterQuery,String FilterValue) throws ProcessingException, IOException
    {
    	String TestCaseID = null;
        JSONArray Testsets = null;
        try{
         	if (!DependentList.contains(FilterValue)){
		        JsonPath jsonResponse = new JsonPath(JsonTestData.toString());
				List<JSONObject> jsText = jsonResponse.param("datefilter", FilterValue).get(FilterQuery);
				Testsets = new JSONArray(jsText);
				for (int iTestIter = 0;iTestIter < Testsets.length(); iTestIter++) {
					JSONObject Testset = Testsets.getJSONObject(iTestIter);
					 TestCaseID = Testset.get(Constants.TCID).toString();
		        	if (!DependentList.contains(TestCaseID)){
		        		JSONArray DependentTests = (JSONArray)Testset.get("DependentIssues");
		        		for (int iDepenIter = 0; iDepenIter < DependentTests.length(); iDepenIter++) {
		        			JSONObject DependentTest = DependentTests.getJSONObject(iDepenIter);
		        			String Query="Tests.findAll{Tests->Tests.Issue_key==datefilter}";
		        			String QueryValue=DependentTest.get("Issue_key").toString();
		        			if (!DependentList.contains(QueryValue)){
		        			DependentIssueExecution(jira,JsonTestData, Query,QueryValue);
		        			}
		        		}
		        		//System.out.println("Exec "+TestCaseID+" --- "+DependentList);	
		        		wTestSet.TestExecution(jira,Testset);
			        	DependentList.add(TestCaseID);
	        		}
				}
         	}
        }
        catch(Exception e){
        	e.printStackTrace();
        }
        return jsonTestReportData;
    }

    /*************************************************************************************************
	 *  Function name 		: VerifyDependents
	 *  Reuse Function 		: 
	 *  Description 		: Verify whether Dependents issues in test data
	/**************************************************************************************************/ 
	public static boolean VerifyDependents(JSONObject JsonTestData,String Key, String Key2)
    {   	
		APP_LOGS.debug("Check whether Dependents "+Key);
    	boolean retnValue=false;
	    try {
	    	JsonPath jsonResponse = new JsonPath(JsonTestData.toString());
	    	List<List<String>> jsText = jsonResponse.get(Key);
			 for (List<String> map :jsText) {
				 for(String Issuekey:map){
					 if(Issuekey.length()>0) {
						 retnValue=true;
//						 ReString=jsonResponse.getString(Key2);
//						 if(ReString.contains(Issuekey))
//						 {
//							 //System.out.println("Contains: "+s);
//						 }
					 }
				 }
			 }
	      } 
	      catch (Exception e){
	    	e.printStackTrace();
	      }        	      
     	  return retnValue;
      } 
}
