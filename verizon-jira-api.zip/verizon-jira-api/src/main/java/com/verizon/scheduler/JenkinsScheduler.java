package com.verizon.scheduler;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.activiti.engine.impl.util.json.JSONArray;
import org.activiti.engine.impl.util.json.JSONObject;
import org.joda.time.DateTime;
import org.joda.time.Seconds;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.offbytwo.jenkins.JenkinsServer;
import com.offbytwo.jenkins.client.JenkinsHttpClient;
import com.offbytwo.jenkins.model.Build;
import com.offbytwo.jenkins.model.BuildWithDetails;
import com.offbytwo.jenkins.model.FolderJob;
import com.offbytwo.jenkins.model.Job;
import com.offbytwo.jenkins.model.JobWithDetails;
import com.offbytwo.jenkins.model.Queue;
import com.offbytwo.jenkins.model.QueueItem;
import com.verizon.util.Constants;

public class JenkinsScheduler {
	//TODO: make static(Performance in general) 
		public boolean scheduleJob(JenkinsHttpClient client,String projectname,String issuetype,String sprint, String TestingType,DateTime date) {
			boolean scheduledone=false;
			int scheduleDelay = Seconds.secondsBetween(DateTime.now(), date).getSeconds();
			scheduleDelay = scheduleDelay > 0 ? scheduleDelay : 0;
			String FOLDER_NAME = Constants.JENKINProjectFolderName;
			String JOB_NAME = Constants.JENKINSchJobName;
			try {
				ClassLoader classLoader = getClass().getClassLoader();
				byte[] configXML = Files.readAllBytes(Paths.get(("D:\\Users\\raghuraman-k\\workspace\\verizon-jira-api\\src\\main\\resources\\jenkins\\buildConfig.xml")));
				String configStr = new String(configXML, Charset.defaultCharset());
				JenkinsServer jenkins = new JenkinsServer(client);
				Map<String, Job> allJobs = jenkins.getJobs();
				if(!allJobs.containsKey(FOLDER_NAME)) {
					jenkins.createFolder(FOLDER_NAME, true);
				}
				Job utapFolder = jenkins.getJob(FOLDER_NAME);
				//System.out.println(utapFolder.getName());
				FolderJob folder = jenkins.getFolderJob(utapFolder).get();
				Map<String, Job> utapJobs = jenkins.getJobs(folder);
				if(!utapJobs.containsKey(JOB_NAME)) {
					jenkins.createJob(folder, JOB_NAME, configStr);
				}
				Job utapJob = jenkins.getJob(folder, JOB_NAME);
				
				JSONObject obj = new JSONObject();
				obj.put("WaitFor", scheduleDelay);
				obj.put("name", utapJob.getName());
				
				JSONObject params = new JSONObject();
				params.put("projectname", projectname);
				params.put("issuetype", issuetype);
				params.put("sprint", sprint);
				params.put("TestingType", TestingType);
				obj.put("Parameters", params);
				
				JSONArray list = new JSONArray();
				list.put(obj);
				
				String groovy = "def jobsToRunStr = '" + list.toString() + "'\n";
				
				//System.out.println("groovy :\n"+groovy);
				//Get file from resources folder
				byte[] encoded = null;
				encoded = Files.readAllBytes(Paths.get("D:\\Users\\raghuraman-k\\workspace\\verizon-jira-api\\src\\main\\resources\\jenkins\\schedule.groovy"));
				String script = groovy + new String(encoded, Charset.defaultCharset());
				//System.out.println("script :\n"+script);
				jenkins.runScript(script,true);
				scheduledone=true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return scheduledone;
		}

		//TODO: make static(Performance in general) 
		public JsonObject BuildHistory(JenkinsHttpClient client) {
			String FOLDER_NAME = Constants.JENKINProjectFolderName;
			//String JOB_NAME = Jobname;
			// create the JsonTestRep object
			int Queuecount=0;
	        JsonObject JenkinProject = new JsonObject();
			try {
				JenkinsServer jenkins = new JenkinsServer(client);
				Map<String, Job> allJobs = jenkins.getJobs();
				if(allJobs.containsKey(FOLDER_NAME)) {
					JenkinProject.addProperty(Constants.JENKINProjectFolder, FOLDER_NAME);
					Job utapFolder = jenkins.getJob(FOLDER_NAME);
					//System.out.println("FOLDER_NAME: "+utapFolder.getName());
					FolderJob folder = jenkins.getFolderJob(utapFolder).get();
					Map<String, Job> utapJobs = jenkins.getJobs(folder);
					// create an array called JenkinJobs
					  JsonArray JenkinJobs = new JsonArray();
					for (String key: utapJobs.keySet()) {
						 // create a SuiteTest
				        JsonObject JenkinJob = new JsonObject();
				        JobWithDetails jobdetails=utapJobs.get(key).details();
				        JenkinJob.addProperty(Constants.JENKINJobName, key);
				        JenkinJob.addProperty(Constants.JENKINJobId, utapJobs.get(key).toString());
				        JenkinJob.addProperty(Constants.JENKINJobLastSuccessfulBuild, jobdetails.getLastSuccessfulBuild().details().getDisplayName());
				        JenkinJob.addProperty(Constants.JENKINJobLastFailedBuild, jobdetails.getLastFailedBuild().details().getDisplayName());
				        JenkinJob.addProperty(Constants.JENKINJobLastStableBuild,jobdetails.getLastStableBuild().details().getDisplayName());
						// create an array called JenkinJobBuilds
						JsonArray JenkinJobBuilds= new JsonArray();
				        // create an array called JenkinJobQueues
						JsonArray JenkinJobQueues= new JsonArray();
				        if(utapJobs.get(key).details().isInQueue()){
				        	Queue item=jenkins.getQueue();
							List<QueueItem> items=item.getItems();
							//System.out.println("items : " + items);
							for (QueueItem qt :items){
								if (qt.getTask().getName().equalsIgnoreCase(key)){
									// create a JenkinJobQueue
							        JsonObject JenkinJobQueue = new JsonObject();
							        QueueItem queitem=jobdetails.getQueueItem();
							        // create a JenkinJobBuild
							        JsonObject JenkinJobBuild = new JsonObject();
							        //Add in Queues
							   	 	JenkinJobQueue.addProperty(Constants.JENKINQueueid, qt.getId());
							        JenkinJobQueue.addProperty(Constants.JENKINQueueTaskName, qt.getTask().getName());
							        JenkinJobQueue.addProperty(Constants.JENKINQueueParameters, qt.getParams());
							        JenkinJobQueue.addProperty(Constants.JENKINQueueUrl, qt.getUrl());
							        
							        //Timestamp to Date
							        String  stimestamp=qt.getInQueueSince().toString();
							    	long lTimeStamp = Long.parseLong(stimestamp.substring(0, stimestamp.length() - 3));
							        java.util.Date NormalDate=new java.util.Date((long)lTimeStamp*1000);
							        
							        JenkinJobQueue.addProperty(Constants.JENKINQueueSince,NormalDate.toString());
							        JenkinJobQueue.addProperty(Constants.JENKINQueueWhy, qt.getWhy());
							        //Add to Builds with Pending Status
							        JenkinJobBuild.addProperty(Constants.JENKINBuildId ,qt.getId());
							        JenkinJobBuild.addProperty(Constants.JENKINBuildName , "#"+(jobdetails.getNextBuildNumber()+Queuecount));
							        JenkinJobBuild.addProperty(Constants.JENKINBuildDuration , Constants.JENKINQueueDuration);
							        
							        
							        JenkinJobBuild.addProperty(Constants.JENKINBuildTimestamp ,NormalDate.toString());
							        JenkinJobBuild.addProperty(Constants.JENKINBuildUrl , qt.getUrl());
							        JenkinJobBuild.addProperty(Constants.JENKINBuildResult , Constants.JENKINQueueStatus);
							        JenkinJobBuild.addProperty(Constants.JENKINBuildConsole  ,qt.getWhy());
							        // Add Queue details into Queues
							        JenkinJobQueues.add(JenkinJobQueue);
							        // Add Queue details into Build with Pending Status
							    	JenkinJobBuilds.add(JenkinJobBuild);
							    	//Increment Queue count
							    	Queuecount=Queuecount+1;
								  }
							  }
				        }
				        JenkinJob.add(Constants.JENKINQueues, JenkinJobQueues);
				        //Get Build History
					    List<Build> builds=jobdetails.getBuilds();
					    for (Build build:builds)
					    {
					    	// create a SuiteTest
					        JsonObject JenkinJobBuild = new JsonObject();
					        BuildWithDetails builddetails=build.details();
					        JenkinJobBuild.addProperty(Constants.JENKINBuildId ,builddetails.getId());
					        JenkinJobBuild.addProperty(Constants.JENKINBuildName , builddetails.getDisplayName());
					        JenkinJobBuild.addProperty(Constants.JENKINBuildDuration , builddetails.getDuration());
					        
					        //Timestamp to Date
					        String sbuildtimestamp=String.valueOf(builddetails.getTimestamp());  
					    	long lTimeStamp = Long.parseLong(sbuildtimestamp.substring(0, sbuildtimestamp.length() - 3));
					        java.util.Date BuildDate=new java.util.Date((long)lTimeStamp*1000);
					        
					        JenkinJobBuild.addProperty(Constants.JENKINBuildTimestamp , BuildDate.toString());
					        JenkinJobBuild.addProperty(Constants.JENKINBuildUrl , builddetails.getUrl());
					       
					        String BuildResult=builddetails.getResult().toString();
					        String BuildConsoleOutput=builddetails.getConsoleOutputText();
					        String BuilResponse="";
					        JenkinJobBuild.addProperty(Constants.JENKINBuildResult , BuildResult);
					        JenkinJobBuild.addProperty(Constants.JENKINBuildConsole  ,BuildConsoleOutput);
					        if(BuildResult.equalsIgnoreCase("SUCCESS")){
					        	int StartIndex=BuildConsoleOutput.indexOf(Constants.JENKINBuildConsoleStart);
						     	int lenStartLen=StartIndex+Constants.JENKINBuildConsoleStart.length();
					        	int EndIndex=BuildConsoleOutput.lastIndexOf(Constants.JENKINBuildConsoleEnd);
					        	if((lenStartLen>0)&(EndIndex>0)){
					        		BuilResponse=BuildConsoleOutput.substring(lenStartLen, EndIndex);
					        		JenkinJobBuild.addProperty(Constants.JENKINBuildReport,BuilResponse.trim());
					        	} 
					        }
					        else{
					        	JenkinJobBuild.addProperty(Constants.JENKINBuildReport,BuilResponse);
					        }
					    	// Add build details into Builds
					    	JenkinJobBuilds.add(JenkinJobBuild);
					    }
					    JenkinJob.add(Constants.JENKINJobBuilds, JenkinJobBuilds);
					 // Add job details into jobs
					    JenkinJobs.add(JenkinJob);
					}
					JenkinProject.add(Constants.JENKINJob, JenkinJobs);
					Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
				    //System.out.println(gson.toJson(JenkinProject));
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return JenkinProject;
		}
		
		
	}
