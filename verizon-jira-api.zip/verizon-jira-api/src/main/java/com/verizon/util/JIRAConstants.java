package com.verizon.util;

public class JIRAConstants {
	// Csv File Header
	public static final String RUNMODE = "RunMode";
	public static final String SERVER = "Server";
	public static final String URL = "URL";
	public static final String REFURLValue = "RefValue";
	public static final String METHOD_TYPE = "MethodType";
	public static final String HEADER_KEYS = "Header_Keys";
	public static final String HEADER_VALUES = "Header_Values";
	public static final String PARAM_KEYS = "Param_Keys";
	public static final String PARAM_VALUES = "Param_Values";
	public static final String EXPECTED_KEYS = "Expected_Keys";
	public static final String EXPECTED_VALUES = "Expected_Values";
	public static final String EXPECTED_STATUS_CODE = "ExpectedStatusCode";
	public static final String EXPECTED_SCHEMA = "ExpectedSchema";
	public static final String GET_OUTPUT_KEY = "GetOutputKey";
	public static final String SWITCHING_MODE = "SwitchingMode";
	public static final String TEST_RESULT_STATUS = "TestResultStatus";
	public static final String RESPONSE_DESCRIPTION = "ResponseDescription";
	public static final String RESPONSE_TIME = "ResponseTime";
	public static final String OUTPUT_VALUES = "Output_Values";
	public static final String PASS = "Pass";
	public static final String FAILED = "Failed";

	public static final String NULL_VALUE = "null";
	public static final String RUNMODE_VALUE_YES = "Yes";
	public static final String RUNMODE_VALUE_NO = "No";
	public static final String ISSUE_KEY_LIST = "Issue_key";
	public static final String ISSUE_KEY = "Issue_key";
	public static final String ISSUE_TYPE = "Issue_Type";
	public static final String PROJECT = "Project_key";
	public static final String SPRINT = "Sprint";
	public static  final String FIXVERSION = "Version";
	public static final String FIXRELEASEDATE = "ReleaseDate";
	
	
	// Custom Fields
	public static final String CUSTOMFIELD_RUNMODE = "customfield_10301";
	public static final String CUSTOMFIELD_SERVER = "customfield_10302";
	public static final String CUSTOMFIELD_URL = "customfield_10303";
	public static final String CUSTOMFIELD_METHOD_TYPE = "customfield_10304";
	public static final String CUSTOMFIELD_HEADER_KEYS = "customfield_10305";
	public static final String CUSTOMFIELD_HEADER_VALUES = "customfield_10306";
	public static final String CUSTOMFIELD_PARAM_KEYS = "customfield_10307";
	public static final String CUSTOMFIELD_PARAM_VALUES = "customfield_10308";
	public static final String CUSTOMFIELD_EXPECTED_KEYS = "customfield_10309";
	public static final String CUSTOMFIELD_EXPECTED_VALUES = "customfield_10310";
	public static final String CUSTOMFIELD_EXPECTED_STATUS_CODE = "customfield_10311";
	public static final String CUSTOMFIELD_EXPECTED_SCHEMA = "customfield_10313";
	public static final String CUSTOMFIELD_GET_OUTPUT_KEY = "customfield_10314";
	public static final String CUSTOMFIELD_SWITCHING_MODE = "customfield_10315";
	public static final String CUSTOMFIELD_RESPONSE_DESCRIPTION = "customfield_10317";
	public static final String CUSTOMFIELD_TEST_RESULT_STATUS = "customfield_10401";
	public static final String CUSTOMFIELD_OUTPUT_VALUES = "customfield_10500";
	public static final String CUSTOMFIELD_RESPONSE_TIME = "customfield_10501";
	public static final String CUSTOMFIELD_INPUT_VALUES = "customfield_10600";
	public static final String SUMMARY = "summary";
	public static final String DETAILS = "Details";
	public static final String INPUT_VALUES = "INPUT_VALUES";
	public static final String LABELS = "labels";
	public static final String FIX_VERSION = "Fix Version/s";
	public static final String TESTINGTYPE = "TestingType";

	public static final String INWARD_ISSUE = "inwardIssue";
	public static final String OUTWARD_ISSUE = "outwardIssue";
	
	public static final String RecordDelimiter = "\\r?\\n";
	public static final String NEWLineDelimiter = "\n";
	public static final String ValueDelimiter = ",";
	public static final String DATAFLAG = "DSFlag";
	public static final String DATASETID = "DatasetID";
	public static final String DATASETS = "Datasets";
	public static final String Tests = "Tests";
	public static final String DEPENDENTISSUES = "DependentIssues";

}