package com.verizon.util;
// reads the xls files and generates corresponding html reports
// Calls sendmail - mail

import static com.verizon.DriverScript.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;




public class ReportUtil {
public static String result_FolderName=null;
// properties
//public static Properties CONFIG;

	public static void main(String[] arg) throws Exception {
		// read suite.xls
		ReportUtil Rep=new ReportUtil();
//		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"/src/main/resources/config/config.properties");
//		Properties CONFIG= new Properties();
//		CONFIG.load(fs);
//	
		Rep.GeneratehtmlReport();
		//SendMail.execute(CONFIG.getProperty("report_file_name"));
	}

	
	 public void ReportExcelData(String XlFile, String XLSheetName, String TCID, String APIMethodType,String APIURL,String APIDescription,String Input_KeyValues,String Expected,String Status,String Description,String RespTime, String Output_Values,String Response)throws AbstractMethodError,  IOException
	 {
		APP_LOGS.debug("Report Test Case Result in Sheet :"+XLSheetName+TCID);
		int NewRow=1;
		
		//Initialize test case sheer
		String XLFileNmae=XlFile;
		String SheetName=XLSheetName;
		
		//System.out.println(SheetName+" : "+TCID+" : "+TestScenario+" : "+Description+" : "+InputDetails+" : "+Expected+" : "+Status+" : "+Actuals+" : "+Comments);
		Xls_Reader current_TestCase_xls=null;
        
  	 	current_TestCase_xls=new Xls_Reader(XLFileNmae);
	  	boolean SheetExist=current_TestCase_xls.isSheetExist(SheetName);
	  	//System.out.println("SheetName Exist"+SheetExist);
	  	if (SheetExist)
	  	{
	  		int rowCount= current_TestCase_xls.getRowCount(SheetName);
	  		NewRow=rowCount+1;
	  		current_TestCase_xls.setCellData(SheetName, Constants.RepIssue_key, NewRow, TCID);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepAPIMethodType, NewRow, APIMethodType);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepAPIURL, NewRow, APIURL);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepAPIDescription, NewRow, APIDescription);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepInput_KeyValues, NewRow, Input_KeyValues);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepExpected, NewRow, Expected);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepTestResultStatus, NewRow, Status);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepResponseDescription, NewRow, Description);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepResponseTime, NewRow, RespTime);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepOutput_Values, NewRow, Output_Values);
	    	current_TestCase_xls.setCellData(SheetName, Constants.RepResponse, NewRow, Response);
	  	}
	  }
	
	 
	 public void ClearReportExcel(String XLFile,String XLSheetName)throws AbstractMethodError,  IOException
	 {
		 APP_LOGS.debug("Clear Test Case Sheet :"+XLSheetName);
		//Initialize test case sheet
		String XLFileNmae=XLFile;//Constants.TEST_XLFILE;
		String SheetName=XLSheetName;
		Xls_Reader current_TestCase_xls=null;
  	 	current_TestCase_xls=new Xls_Reader(XLFile);
	  	boolean SheetExist=current_TestCase_xls.isSheetExist(SheetName);
	  	if (SheetExist)
	  	{
	  		int rowCount= current_TestCase_xls.getRowCount(SheetName);
	  		if (rowCount>1)
	  		{
	  			current_TestCase_xls.removeAllRow(SheetName);
	  		}
	  	}
	  	else
	  	{
	  		
	  		//TestResults
	  		current_TestCase_xls.addSheet(SheetName);
	  		current_TestCase_xls.addColumn(SheetName,Constants.RepIssue_key );
	  		current_TestCase_xls.addColumn(SheetName, Constants.RepAPIMethodType);
	  		current_TestCase_xls.addColumn(SheetName,Constants.RepAPIURL);
	  		current_TestCase_xls.addColumn(SheetName, Constants.RepAPIDescription);
	  		current_TestCase_xls.addColumn(SheetName, Constants.RepInput_KeyValues);
	  		current_TestCase_xls.addColumn(SheetName, Constants.RepExpected);
	  		current_TestCase_xls.addColumn(SheetName, Constants.RepTestResultStatus);
	  		current_TestCase_xls.addColumn(SheetName, Constants.RepResponseDescription);
	  		current_TestCase_xls.addColumn(SheetName, Constants.RepResponseTime);
	  		current_TestCase_xls.addColumn(SheetName, Constants.RepOutput_Values);
	  		current_TestCase_xls.addColumn(SheetName, Constants.RepResponse);
	  		
	  		
	  	}
	  }
	 
	 
	 public void ClearSuiteExcel(String XLFile,String XLSheetName)throws AbstractMethodError,  IOException {
		//Clear test case sheet
		 APP_LOGS.debug("Clear Test Suite Sheet :"+XLSheetName);
		String XLFileNmae=XLFile;//Constants.TEST_XLFILE;
		String SheetName=XLSheetName;
		Xls_Reader current_TestCase_xls=null;
  	 	current_TestCase_xls=new Xls_Reader(XLFile);
	  	boolean SheetExist=current_TestCase_xls.isSheetExist(SheetName);
	  	if (SheetExist)
	  	{
	  		int rowCount= current_TestCase_xls.getRowCount(SheetName);
	  		if (rowCount>1)
	  		{
	  			current_TestCase_xls.removeAllRow(SheetName);
	  		}
	  	}
	  	else
	  	{
	  		current_TestCase_xls.addSheet(SheetName);
	  		current_TestCase_xls.addColumn(SheetName, "TestSuiteID");
	  		current_TestCase_xls.addColumn(SheetName, "RunMode");
	  		current_TestCase_xls.addColumn(SheetName, "SuiteName");
	  		current_TestCase_xls.addColumn(SheetName, "Description");
	  	}
  	 
	  }
	 
	 
	 public void SuiteExcelData(String XlFile, String XLSheetName, String TestSuiteID, String RunMode,String SuiteName,String Description)throws AbstractMethodError,  IOException
	 {
		 APP_LOGS.debug("Add Test Suites in Sheet :"+XLSheetName);
		//Initialize Suite sheet
		 int NewRow=1;
		String XLFileNmae=XlFile;
		String SheetName=XLSheetName;
		Xls_Reader current_TestCase_xls=null;
  	 	current_TestCase_xls=new Xls_Reader(XLFileNmae);
	  	boolean SheetExist=current_TestCase_xls.isSheetExist(SheetName);
	  	if (SheetExist)
	  	{
	  		int rowCount= current_TestCase_xls.getRowCount(SheetName);
	  		NewRow=rowCount+1;
	  		current_TestCase_xls.setCellData(SheetName, "TestSuiteID", NewRow, TestSuiteID);
	    	current_TestCase_xls.setCellData(SheetName, "RunMode", NewRow, RunMode);
	    	current_TestCase_xls.setCellData(SheetName, "SuiteName", NewRow, SuiteName);
	    	current_TestCase_xls.setCellData(SheetName, "Description", NewRow, Description);
	    	
	  	}
	  }
	 
	 public static void ConvertCSVToXLSX2(String csvFile,String XlsxFile,String Sheetname) {
		 APP_LOGS.debug("Convert CSV To XLSX :"+Sheetname);
		    try {
		    	 File inputFile=new File(csvFile);
				 File outputFile=new File(XlsxFile);
		        XSSFWorkbook workBook = new XSSFWorkbook();
		        XSSFSheet sheet = workBook.createSheet(Sheetname);
		        String currentLine=null;
		        int RowNum=0;
		        BufferedReader br = new BufferedReader(new FileReader(inputFile));
		        while ((currentLine = br.readLine()) != null) {
		            String str[] = currentLine.split(",");
		           // System.out.println("Row : "+RowNum);
		            XSSFRow currentRow=sheet.createRow(RowNum);
		            for(int i=0;i<str.length;i++){
		            	//System.out.println("Column : "+i+" is "+str[i]);
		                currentRow.createCell(i).setCellValue(str[i]);
		            }
		            RowNum++;
		        }
		        
		        FileOutputStream fileOutputStream =  new FileOutputStream(outputFile,true);
		        workBook.write(fileOutputStream);
		        fileOutputStream.close();
		        workBook.close();
		        
		       // System.out.println("Converted to XLSX");
		    } catch (Exception ex) {
		        System.out.println(ex.getMessage()+"Exception in try");
		    }
		}
	 
	 public static void ConvertCSVToXLSX(String csvFile,String XlsxFile,String Sheetname) {
		 APP_LOGS.debug("Convert CSV To XLSX :"+Sheetname);
		    try {
		    	 File inputFile=new File(csvFile);
				 CreateXLFILE(XlsxFile,Sheetname);
				 Thread.sleep(2000);
				 Xls_Reader current_TestCase_xls=null;
			  	 current_TestCase_xls=new Xls_Reader(XlsxFile);
				 boolean SheetExist=current_TestCase_xls.isSheetExist(Sheetname);
				 if (SheetExist){
				  	int rowCount= current_TestCase_xls.getRowCount(Sheetname);
				  	if (rowCount>0){
				  			current_TestCase_xls.removeAllRow1(Sheetname);
				  	}
				  }
				  else{
				  	current_TestCase_xls.addSheet(Sheetname);
				  }
				List<String> ColName = new ArrayList<String>();
		        String currentLine=null;
		        int RowNum=0;
		        int rowCount=0;
		        BufferedReader br = new BufferedReader(new FileReader(inputFile));
		        while ((currentLine = br.readLine()) != null) {
		            String str[] = currentLine.split(",");
		            rowCount= current_TestCase_xls.getRowCount(Sheetname);
		            rowCount=rowCount+1;
		            for(int i=0;i<str.length;i++){
		                if (RowNum==0){
		                	current_TestCase_xls.addColumn(Sheetname, str[i]);
		                	ColName.add(str[i]);
		                }
		                else{
		                	current_TestCase_xls.setCellData(Sheetname, ColName.get(i), rowCount, str[i]);
		                }
		            }
		            RowNum++;
		        }
		      //  System.out.println("Converted to XLSX");
		    	} 
		    catch (Exception ex) {
		        System.out.println(ex.getMessage()+"Exception in try");
		    }
		}
	 
	 
	 public static void convertXLSXtoCSV(String inputFilePath, String outputFilePath)  {
		 APP_LOGS.debug("Convert XLSX To CSV :");
	     // For storing data into CSV files
		 StringBuffer cellValue = new StringBuffer();
		 try 
		 {
			 File inputFile=new File(inputFilePath);
			 File outputFile=new File(outputFilePath);
			 int RowClomn=0;
	         FileOutputStream fos = new FileOutputStream(outputFile);
	         // Get the workbook instance for XLSX file
	         XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(inputFile));
	         for (int i = 0; i < wb.getNumberOfSheets(); i++) 
	         {
		         // Get first sheet from the workbook
		         XSSFSheet sheet = wb.getSheetAt(i);
		         if(!sheet.getSheetName().contains("_TestResult"))
		         {
			         Row row;
			         Cell cell;
			         Iterator<Row> rowIterator = sheet.iterator();
			         while (rowIterator.hasNext()) 
			         {
			         row = rowIterator.next();
			         if((RowClomn==0)&(row.getRowNum()==0))
			         {
			        	 RowClomn=1;
				         Iterator<Cell> cellIterator = row.cellIterator();
				         while (cellIterator.hasNext()) 
				         {
				                 cell = cellIterator.next();
			
				                 switch (cell.getCellType()) 
				                 {
				                 case Cell.CELL_TYPE_BOOLEAN:
				                         cellValue.append(cell.getBooleanCellValue() + ",");
				                         break;
				                 case Cell.CELL_TYPE_NUMERIC:
				                         cellValue.append(cell.getNumericCellValue() + ",");
				                         break;
				                 case Cell.CELL_TYPE_STRING:

				                 	String str=cell.getStringCellValue().replaceAll("\n", "");
				                 	str=str.replaceAll(",", " ");
				                         cellValue.append(str + ",");
				                         break;
				                 case Cell.CELL_TYPE_BLANK:
				                         cellValue.append("" + ",");
				                         break;
				                 default:
				                         cellValue.append(cell + ",");
				                 }
				         }
				         cellValue.append("\r\n");
				         }
			         else if(row.getRowNum()>0)
			         {
			        	 // For each row, iterate through each columns
				         Iterator<Cell> cellIterator = row.cellIterator();
				         while (cellIterator.hasNext()) 
				         {
				                 cell = cellIterator.next();
			
				                 switch (cell.getCellType()) 
				                 {
				                 
				                 case Cell.CELL_TYPE_BOOLEAN:
				                         cellValue.append(cell.getBooleanCellValue() + ",");
				                         break;
				                 case Cell.CELL_TYPE_NUMERIC:
				                         cellValue.append(cell.getNumericCellValue() + ",");
				                         break;
				                 case Cell.CELL_TYPE_STRING:
				                 	String str=cell.getStringCellValue().replaceAll("\n", "");
				                 	str=str.replaceAll(",", " ");
				                         cellValue.append(str + ",");
				                         break;
				                 case Cell.CELL_TYPE_BLANK:
				                         cellValue.append("" + ",");
				                         break;
				                 default:
				                         cellValue.append(cell + ",");
				                 }
				         }
				         cellValue.append("\r\n");
			         	}
			      }
		   }
	 }
	 fos.write(cellValue.toString().getBytes());
	 fos.close();
	// System.out.println("Converted to CSV");
	 } 
	 catch (Exception e) 
	 {
	    System.err.println("Exception :" + e.getMessage());
	 }
	 }
	 
	 public static void xlsxtocsv(File inputFile, File outputFile) {
		 APP_LOGS.debug("Convert XLSX To CSV :");
	     // For storing data into CSV files
	     StringBuffer data = new StringBuffer();
	     try 
	     {
	     FileOutputStream fos = new FileOutputStream(outputFile);
	     // Get the workbook object for XLS file
	     HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(inputFile));
	     // Get first sheet from the workbook
	     HSSFSheet sheet = workbook.getSheetAt(0);
	     Cell cell;
	     Row row;
	     // Iterate through each rows from first sheet
	     Iterator<Row> rowIterator = sheet.iterator();
	     while (rowIterator.hasNext()) 
	     {
	    	 row = rowIterator.next();
             // For each row, iterate through each columns
             Iterator<Cell> cellIterator = row.cellIterator();
             while (cellIterator.hasNext()) 
             {
                     cell = cellIterator.next();
                     switch (cell.getCellType()) 
                     {
                     case Cell.CELL_TYPE_BOOLEAN:
                             data.append(cell.getBooleanCellValue() + ",");
                             break;
                     case Cell.CELL_TYPE_NUMERIC:
                             data.append(cell.getNumericCellValue() + ",");
                             break;
                     case Cell.CELL_TYPE_STRING:
                             data.append(cell.getStringCellValue() + ",");
                             break;
                     case Cell.CELL_TYPE_BLANK:
                             data.append("" + ",");
                             break;
                     default:
                             data.append(cell + ",");
                     }   
	             }
	             data.append('\n'); 
	     }
	     fos.write(data.toString().getBytes());
	     fos.close();
	     }
	     catch (FileNotFoundException e) 
	     {
	             e.printStackTrace();
	     }
	     catch (IOException e) 
	     {
	             e.printStackTrace();
	     }
	     }

	public void GeneratehtmlReport() throws Exception 
	{
		APP_LOGS.debug("Generate HTML Report");
		// read suite.xls
		
		int iNoOfTestCase=0,iNoOfPass = 0,iNoOfFail=0,iNoOfSkip=0;
		Date d = new Date();
		String date=d.toString().replaceAll(" ", "_");
		date=date.replaceAll(":", "_");
		date=date.replaceAll("\\+", "_");
		result_FolderName="Reports"+"_"+date;
		//String reportsDirPath=System.getProperty("user.dir")+"\\Reports";
		String reportsDirPath=System.getProperty("user.dir")+"\\Reports\\"+result_FolderName;
		new File(reportsDirPath).mkdirs();
		System.out.println("\nGenerates Test Report Path \n"+reportsDirPath);
		String environment=CONFIG.getProperty("environment");
		String version=CONFIG.getProperty("version");
		Xls_Reader suiteXLS = new Xls_Reader(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Xls/"+Constants.SUITE_XLFILE);
		// create index.html
		String indexHtmlPath=reportsDirPath+"\\index.html";
		new File(indexHtmlPath).createNewFile();
		try{
			  
			  FileWriter fstream = new FileWriter(indexHtmlPath);
			  BufferedWriter out = new BufferedWriter(fstream);
			  out.write("<html><HEAD> <TITLE>Automation Test Results</TITLE></HEAD><body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u> Automation Test Results</u></b></h4><table  border=1 cellspacing=1 cellpadding=1 ><tr><h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(d.toString());
			  out.write("</b></td></tr><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Environment</b></td><td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(environment);
			  out.write("</b></td></tr><tr><td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Version</b></td><td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  out.write(version);
			  out.write("</b></td></tr></table><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>Report :</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=15% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SUITE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=15% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Status</b></td>");
			  out.write("<td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of TestCases</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of Passed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Failed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Skipped</b></td></tr>");
			  int totalTestSuites=suiteXLS.getRowCount(Constants.TEST_SUITE_SHEET);
			  String currentTestSuite=null;
			  Xls_Reader current_suite_xls=null;
			  String suite_result="";
			  //Harcoded suite count
			  currentTestSuite=null;
			  current_suite_xls=null;
			  if (CONFIG.getProperty("InputType").equalsIgnoreCase("Jira")){
				  current_suite_xls=new Xls_Reader(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Xls/"+Constants.TEST_JIRAXLFILE);
		     	}
			  else
			  {
				  current_suite_xls=new Xls_Reader(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Xls/"+Constants.TEST_XLFILE);
			  }
			  String currentTestName=null;
			  String currentTestRunmode=null;
			  String currentTestDescription=null;
			  for(int currentTestCaseID=2;currentTestCaseID<=suiteXLS.getRowCount(Constants.TEST_SUITE_SHEET);currentTestCaseID++)
			   {
				  	iNoOfTestCase=0;
				  	currentTestSuite = suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.Test_Suite_ID,currentTestCaseID);
			    	 currentTestName=null;
			    	 currentTestDescription=null;
			    	 currentTestRunmode=null;
			    	 Constants.TEST_STEPS_SHEET=suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.TEST_CASES_SHEET, currentTestCaseID);
			    	 Constants.TEST_STEPS_SHEET=Constants.TEST_STEPS_SHEET+"_TestResult";
			    	 currentTestName = current_suite_xls.getCellData( Constants.TEST_STEPS_SHEET, Constants.TCID, currentTestCaseID);
			    	 currentTestDescription = current_suite_xls.getCellData( Constants.TEST_STEPS_SHEET, Constants.DESCRIPTION, currentTestCaseID);
			    	 currentTestRunmode = current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, Constants.RUNMODE, currentTestCaseID);
			    	 System.out.println(currentTestSuite + " -- "+currentTestName +currentTestRunmode);
			    	 String testSteps_file=reportsDirPath+"\\"+currentTestSuite+"_steps.html";
					 new File(testSteps_file).createNewFile();						  
					 int rows= current_suite_xls.getRowCount(Constants.TEST_STEPS_SHEET);
					 int cols = current_suite_xls.getColumnCount(Constants.TEST_STEPS_SHEET);
					  FileWriter fstream_test_steps= new FileWriter(testSteps_file);
					  BufferedWriter out_test_steps= new BufferedWriter(fstream_test_steps);
					  out_test_steps.write("<html><HEAD> <TITLE>"+currentTestSuite+" Test Results</TITLE></HEAD><body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u> "+currentTestSuite+" Detailed Test Results</u></b></h4><table width=100% border=1 cellspacing=1 cellpadding=1 >");
					  out_test_steps.write("<tr>");
					  for(int colNum=0;colNum<cols;colNum++)
					  {
						 String TestStepColumnName=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1);
						  switch (TestStepColumnName)
						  {
						  case "Issue key":
							  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  case "APIMethodType":
							  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  case "APIURL":
							  out_test_steps.write("<td align= center width=10px bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  case "APIDescription":
							  out_test_steps.write("<td align= center width=10px bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  case "Input_KeyValues":
							  out_test_steps.write("<td align= Left width=15px bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  case "Expected":
							  out_test_steps.write("<td align= center width=15% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  case "TestResultStatus":
							  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  case "ResponseDescription":
							  out_test_steps.write("<td align= Left width=10px bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  case "Output_Values":
							  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  case "Response":
							  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
							  break;
						  default:
							  out_test_steps.write("<td align= center bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(TestStepColumnName);
						  }
						  
					  }
					  out_test_steps.write("</b></tr>");
					 // fill the whole sheet
				  boolean result_col=false;
				 // System.out.println("Debug:4 Rows: "+rows);
				  iNoOfPass=0;
				  iNoOfFail=0;
				  iNoOfSkip=0;
				  for(int rowNum=2;rowNum<=rows;rowNum++){
					  iNoOfTestCase=iNoOfTestCase+1;
					  out_test_steps.write("<tr>");  
					  for(int colNum=0;colNum<cols-1;colNum++){						
						   String data=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, rowNum);
						   data=data.replace("\n", "<br>");
						   result_col=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1).startsWith(Constants.RESULT);
						  if(data.isEmpty()){
							  if(result_col)
								  data="SKIP";  
							  else
								  data=" ";
						  }
						  //System.out.println(data);
						  if((data.startsWith("Pass") || data.startsWith("PASS")) && result_col)
						  {
							  iNoOfPass=iNoOfPass+1;
							  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
						  }
						  else if((data.startsWith("Fail") || data.startsWith("FAIL")) && result_col){
							  iNoOfFail=iNoOfFail+1;
							  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  if(suite_result.equals(""))
								  suite_result="FAIL";
						  	}
						  else if((data.startsWith("Skip") || data.startsWith("SKIP")) && result_col)
						  {
							  iNoOfSkip=iNoOfSkip+1;
							  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
						  }
						  else 
						  {
							  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
						  }
						   out_test_steps.write(data );

						}
						out_test_steps.write("<td>");
						String TestcaseID1 = current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET,Constants.TCID, rowNum);							  
						String fp = current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET,"Response", rowNum);
						out_test_steps.write("<a href="+fp+">"+TestcaseID1 +"</a>");
						out_test_steps.write("</td>"); 
						out_test_steps.write("</tr>");
				  }					  
				  out_test_steps.write("</tr>");
				  out_test_steps.write("</table>");  
				  out_test_steps.close();
				  out.write("<tr><td width=10% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
				  out.write("<a href="+currentTestSuite.replace(" ", "%20")+"_steps.html>"+currentTestSuite+"</a>");
				  out.write("</b></td><td width=25% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
				  out.write(suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.DESCRIPTION,currentTestCaseID));
				  out.write("</b></td><td width=10% align=center  bgcolor=");
				  if(suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.RUNMODE,currentTestCaseID).equalsIgnoreCase(Constants.RUNMODE_YES))
					  if(suite_result.equals("FAIL"))
						  	out.write("red><FONT COLOR=153E7E FACE=Arial SIZE=2><b>FAIL</b></td>");
					  else
						  	out.write("green><FONT COLOR=153E7E FACE=Arial SIZE=2><b>PASS</b></td>");
				  else
					  out.write("yellow><FONT COLOR=153E7E FACE=Arial SIZE=2><b>SKIP</b></td>");
				  
				  out.write("<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+iNoOfTestCase+"</b></td>");
				  out.write("<td width=10% align=center  bgcolor=green><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+iNoOfPass+"</b></td>");
				  out.write("<td width=10% align=center  bgcolor=red><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+iNoOfFail+"</b></td>");
				  out.write("<td width=10% align=center  bgcolor=yellow><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+iNoOfSkip+"</b></td></tr>");
			     }
			   
			    //Close the output stream
				  out.write("</table>");
				  out.close();
		}
			  catch (Exception e){//Catch exception if any
			  System.err.println("Error: " + e.getMessage());
			  e.printStackTrace();
		  }
	}
	
	public static void CreateXLFILE(String path,String Sheetname) {
		try {
			File fs=new File(path);
			if(!fs.exists())
			{
				FileOutputStream fileOut = new FileOutputStream(fs);
				XSSFWorkbook workbook = new XSSFWorkbook();
				XSSFSheet sheet = workbook.createSheet(Sheetname);
				//Create a new row in current sheet
				Row row = sheet.createRow(0);
				//Create a new cell in current row
				Cell cell = row.createCell(0);
				//Set value to new value
				cell.setCellValue("Slim Shady");
				workbook.write(fileOut);
				fileOut.close();
				//workbook.close();
			}
			
		} 
		catch (FileNotFoundException e) {
	        e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	

}
