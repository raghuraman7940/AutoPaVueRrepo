package com.verizon.util;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;

import java.util.ArrayList;

import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.verizon.util.Constants;


import io.restassured.builder.ResponseBuilder;
import io.restassured.path.json.JsonPath;
//import io.restassured.response.Headers;
import io.restassured.response.Response;




public class HttpClientAPI {

	static CloseableHttpClient httpclient;
	static HttpClientContext context;

	// properties
	public static Properties CONFIG;
	

	final static String TargetHost = "agtechactivatedemo.verizon.com"; // bitbucket host
	final static int TargetPort = 443; //bitbucket port
	final static String TargetType = "https"; // bitbucket type
	final static String TargetUsername = "admin"; // bitbucket username
	final static String TargetPassword = "admin"; // bitbucket password
	
	
	
	public static void main(String[] args) throws ClientProtocolException, IOException {
		// TODO Auto-generated method stub
		  
		// Initialize configuration file
		FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+Constants.CONFIG_FILEPATH+Constants.CONFIG_FILE);
		CONFIG= new Properties();
		CONFIG.load(fs);
		System.out.println("Start1 : ");
	  	//Proxy host details
	    HttpHost proxy = new HttpHost(CONFIG.getProperty("PROXY_HOST"),Integer.parseInt((CONFIG.getProperty("PROXY_PORT"))));
	    DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
	    CredentialsProvider credsProvider = new BasicCredentialsProvider();
	    credsProvider.setCredentials(
	    		new AuthScope(CONFIG.getProperty("PROXY_HOST"), Integer.parseInt((CONFIG.getProperty("PROXY_PORT"))), AuthScope.ANY_HOST, "ntlm"), 
	    		new NTCredentials(CONFIG.getProperty("PROXY_USERNAME"), CONFIG.getProperty("PROXY_PASSWORD"), "", CONFIG.getProperty("PROXY_DOMAIN")));
	    context = HttpClientContext.create();
	    //Target host details
	    
	    HttpHost targetHost = new HttpHost(CONFIG.getProperty("TARGET_HOST"), Integer.parseInt((CONFIG.getProperty("TARGET_PORT"))), CONFIG.getProperty("TARGET_TYPE"));
	    credsProvider.setCredentials(
	            new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT),
	            new UsernamePasswordCredentials(CONFIG.getProperty("TARGET_USERNAME"), CONFIG.getProperty("TARGET_PASSWORD")));
	    
	    // Create AuthCache instance
	    AuthCache authCache = new BasicAuthCache();
	    // Generate BASIC scheme object and add it to the local auth cache
	    BasicScheme basicAuth = new BasicScheme();
	    authCache.put(targetHost, basicAuth);
	    context.setCredentialsProvider(credsProvider);
	    context.setAuthCache(authCache);    
	    httpclient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).setRoutePlanner(routePlanner).build();
		    try {

		    	 
		    	 System.out.println("Start2 : ");
		    	 //HttpResponse resGetSrcDir2 =Post_Method("https://agtechactivatedemo.verizon.com/api/v1/home/login","username|password","admin|admin");
		    	 HttpResponse resGetSrcDir2 =HttpGet_Method("http://www.thomas-bayer.com/sqlrest","","");
		    	 System.out.println("Start3 : ");
		    	 //String resGetSrc = GetRespString(resGetSrcDir2);
		    	 
		    	 HttpEntity entity = resGetSrcDir2.getEntity();
			     String responseString = EntityUtils.toString(entity, "UTF-8");
			        
		    	 
		    	 System.out.println("Resp Str : "+resGetSrcDir2);
		    	 System.out.println("Resp Entity : "+responseString);

		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		    
		 
		    }

	

	
	/***************************************************************************************
	 *  Function name 		: Get_Method
	 *  Reuse Function 		:  
	 *  Description 		: GET Method API WebServices
	/****************************************************************************************/         
    public static HttpResponse HttpGet_Method(String apiurl,String HKeys, String HValues) throws ClientProtocolException, IOException
	{
	
		HttpResponse resp=null;
		try{
			 HttpGet httpget = new HttpGet(apiurl);
			if ((HKeys.length()>0)&(HValues.length()>0))
			{
		        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
		        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
		        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
		        {
		        	httpget.setHeader(ArKeys[i],ArValues[i]);
		        }
			}
	        resp = httpclient.execute(httpget, context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	       VerifyResponseStatus(httpCode,200);
	   	 	return resp;
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
	}
    
    
    /***************************************************************************************
	 *  Function name 		: Post_Method
	 *  Reuse Function 		: NA
	 *  Description 		: Post Method API WebServices using HttpPost
	/****************************************************************************************/         
    public static HttpResponse HTTPPost_Method(String apiurl,String HKeys, String HValues,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
		HttpResponse resp=null;
		try{
			HttpPost httppost = new HttpPost(apiurl);
			if ((HKeys.length()>0)&(HValues.length()>0))
			{
		        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
		        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
		        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
		        {
		        	httppost.setHeader(ArKeys[i],ArValues[i]);
		        }
			}
			ArrayList<NameValuePair> postParameters=GetNameValuePair(PKeys,PValues);
			httppost.setEntity(new UrlEncodedFormEntity(postParameters));
	        resp = httpclient.execute(httppost,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
	        
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;

	}
    
    

	/***************************************************************************************
	 *  Function name 		: HttpPut_Method
	 *  Reuse Function 		: 
	 *  Description 		: Update Method API WebServices 
	/****************************************************************************************/ 
	public HttpResponse HttpPut_Method(String apiurl,String HKeys, String HValues,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
		HttpResponse resp=null;
		try{
			 HttpPut httpput = new HttpPut(apiurl);
			 
				if ((HKeys.length()>0)&(HValues.length()>0))
				{
			        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	httpput.setHeader(ArKeys[i],ArValues[i]);
			        }
				}
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
					ArrayList<NameValuePair> postParameters= GetNameValuePair(PKeys,PValues); 
			        httpput.setEntity(new UrlEncodedFormEntity(postParameters));
				}
	        resp = httpclient.execute(httpput,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;

	}
	
	/***************************************************************************************
	 *  Function name 		: Delete_Method
	 *  Reuse Function 		: 
	 *  Description 		: delete Method API WebServices 
	/****************************************************************************************/ 
	public HttpResponse HttpDelete_Method(String apiurl,String HKeys, String HValues,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
		HttpResponse resp=null;
		try{
			 HttpDelete httpdelete = new HttpDelete(apiurl);
			 
				if ((HKeys.length()>0)&(HValues.length()>0))
				{
			        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	httpdelete.setHeader(ArKeys[i],ArValues[i]);
			        }
				}
				
			 if ((PKeys.length()>0)&(PValues.length()>0))
			{
				 ArrayList<NameValuePair> postParameters= GetNameValuePair(PKeys,PValues); 
			     ((HttpResponse) httpdelete).setEntity(new UrlEncodedFormEntity(postParameters));
			}
	        resp = httpclient.execute(httpdelete,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;

	}
    
    
    /********************************************************************************
 		 *  Function name 		: VerifyResponseStatus
 		 *  Reuse Function 		: 
 		 *  Description 		: Validate expected status from Actual
 		 /*******************************************************************************/  
 	    
 	    public static void VerifyResponseStatus(int ActualStatusCode,int expStatusCode)
 	    {
 	    
 	    	String APIStatus,ApiDescription;
 	     
 	    		if (ActualStatusCode==expStatusCode)
 	    		{
 	    			System.out.println("Resp Status : "+ActualStatusCode);
 	    			APIStatus=Constants.KEYWORD_PASS;
 	    		    ApiDescription="Valid Response Code: "+ActualStatusCode;
 	    		}
 	    	else
 	   		 {     		
 	   			APIStatus=Constants.KEYWORD_FAIL;
 	   			System.out.println("Resp Status "+ActualStatusCode);
 	   			ApiDescription="Invalid Response status:"+ActualStatusCode;
 	   		 }
 	
 	    }
   
 	    
 	   /**************************************************************************
 		 *  Function name 		: GetKeyValuePair
 		 *  Reuse Function 		: 
 		 *  Description 		: Provide paired key values from  excel input key values    
 		 /**********************************************************************/    
 		    public static ArrayList<NameValuePair> GetNameValuePair(String PKeys,String PValues) 
 			{
 				//Map<String, String>  mKeyValue=new HashMap<>();
 				
 				ArrayList<NameValuePair> mKeyValue = null;

 		        
 					if ((PKeys.length()>0)&(PValues.length()>0))
 					{
 						mKeyValue = new ArrayList<NameValuePair>();
 				        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
 				        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
 				        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
 				        {
 				        	mKeyValue.add(new BasicNameValuePair(ArKeys[i], ArValues[i]));
 				        }
 					
 	 
 					}
 					return mKeyValue;
 				}
	public void responseTakeCharsetIntoAccount(HttpResponse res) throws Exception {
		
		
//		Header[] map = res.getAllHeaders();
//		List<Header> headerList = new LinkedList<Header>();
//		for (Header HE:map)
//		{
//		
//		
//			Header header11 = new Header(HE.getName(),HE.getValue());
//			headerList.add(header11);
//			
//		}
//		Headers headers = new Headers(headerList);
		
//		//get the list of header names (keys)
//		string[] headerkeys = res.getHeaderKeys();
//
//		//create an object to store your header key-value pairs
//		Map<string, string> headers = new map<string, string>();
//
//		//iterate through they keys, and populate your map
//		for(string s : headerkeys){
//		   headers.put(s,res.getHeader(s));
//		  // system.debug('header: ' + s + ' value: ' + res.getHeader(s));
//		}
	    ResponseBuilder b = new ResponseBuilder();
	    //b.clone((Response) res);
	    b.setHeaders(null);
	    b.setBody(new ByteArrayInputStream("���".getBytes("UTF-8")));
	    b.setStatusCode(200);
	    b.setContentType("application/json;charset=UTF-8");
	    Response response = b.build();
	    
	    //assertThat("���", equalTo(response.asString()));
	}
	
	
	public static HttpResponse Post_Method(String apiurl,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
		HttpResponse resp=null;
		try{
			HttpPost httppost = new HttpPost(apiurl);
			ArrayList<NameValuePair> postParameters;
	        postParameters = new ArrayList<NameValuePair>();
	        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
	        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
	        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
	        {
	        	postParameters.add(new BasicNameValuePair(ArKeys[i], ArValues[i]));
	        }
	
	        httppost.setEntity(new UrlEncodedFormEntity(postParameters));
	        resp = httpclient.execute(httppost,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        if (httpCode==200)
	        {
		       // System.out.println("Request Get :"+apiurl);
		        //System.out.println("Status Code :"+httpCode);
		        //System.out.println("Response String :"+responseString);
	        }
	        else
	        {
	        	System.out.println("Request Get :"+apiurl);
	        	System.out.println("Status Code :"+httpCode);
	        	//System.out.println("Response String :"+responseString);
	        	
	        }
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;

	}
	
	
	
	public static HttpResponse Put_Method(String apiurl,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
		HttpResponse resp=null;
		try{
			 HttpPut httpput = new HttpPut(apiurl);
			ArrayList<NameValuePair> postParameters;
	        postParameters = new ArrayList<NameValuePair>();
	        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
	        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
	        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
	        {
	        	postParameters.add(new BasicNameValuePair(ArKeys[i], ArValues[i]));
	        }
	
	        httpput.setEntity(new UrlEncodedFormEntity(postParameters));
	        resp = httpclient.execute(httpput,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        if (httpCode==200)
	        {
		       // System.out.println("Request Get :"+apiurl);
		        //System.out.println("Status Code :"+httpCode);
		        //System.out.println("Response String :"+responseString);
	        }
	        else
	        {
	        	System.out.println("Request Get :"+apiurl);
	        	System.out.println("Status Code :"+httpCode);
	        	//System.out.println("Response String :"+responseString);
	        	
	        }
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;

	}
	
	public static HttpResponse Delete_Method(String apiurl) throws ClientProtocolException, IOException
	{
		HttpResponse resp=null;
		try{
			 HttpDelete httpdelete = new HttpDelete(apiurl);
	        resp = httpclient.execute(httpdelete,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        if (httpCode==200)
	        {
		       // System.out.println("Request Get :"+apiurl);
		        //System.out.println("Status Code :"+httpCode);
		        //System.out.println("Response String :"+responseString);
	        }
	        else
	        {
	        	System.out.println("Request Get :"+apiurl);
	        	System.out.println("Status Code :"+httpCode);
	        	//System.out.println("Response String :"+responseString);
	        	
	        }
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;

	}
	
	public static String GetRespString(HttpResponse respString) 
	{
		String responseString=null;
		try{
	        HttpEntity entity = respString.getEntity();
	        responseString = EntityUtils.toString(entity, "UTF-8");
	        //System.out.println("Response Stringsss :"+responseString);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return responseString;
		}
		return responseString;
	}
	
	public static String GetJsonKeyValue(String JsonSSString,String Key)
    {   	
    	String ReString;
    	ReString=null;
    	ReString="Not Found";
	    try 
	      {
	    	JsonPath jsonResponse = new JsonPath(JsonSSString);
	    	ReString= jsonResponse.getString(Key);			 
	      } 
	    catch (Exception e) 
	      {
	    	e.printStackTrace();
	       }        	      
     	return ReString;
      } 
	
	


}

