package com.verizon.util;


import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static io.restassured.matcher.RestAssuredMatchers.matchesXsd;
import static io.restassured.matcher.RestAssuredMatchers.matchesDtd;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.ProxySpecification;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import static com.verizon.DriverScript.*;
import com.verizon.DriverScript;
import com.verizon.controllers.JiraService;
import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.util.Constants;
import com.verizon.util.Xls_Reader;

public class App implements Runnable

{
  	public static String ApiDescription = "";
  	public static String APIStatus="";
	public static String ResponseFilePath;
	public static String ContentType;
	public static long responseTime=0;
	public static String responseTimeinMs;
	public static String OutValues;
	public static Response res = null;
	public static List<Map<String , String>> lstDataSetresult =null;
	static SchemaValidation vjson;
	static CloseableHttpClient httpclient;
	static HttpClientContext context;
  	static Xls_Reader current_TestCase_xls=null;
  	static Xls_Reader XlsxSuite_xls=null;
	public static JiraService jiraService;
  	static ProxySpecification proxySpecification;
  	int ExpStatusid;
	int rowNum;
	boolean bExpected;
	String APIURL,URL,HeaderKey,HeaderValues,ParamKey,ParamValues,methodType,APIServer,Url,Details,HeaderKeyValue,ExpStatusCode,InputValues,GivenExpectedValues;
	String XLSheetname_TestResults;
	String resString=null;
	String ThreadExecType=null;
	String OpKey,XlsxInputFile,XLInputSheetName,SwitchingMode,ExpectedSchemaPath,ExpectedKeys,ExpectedValues,TestCaseID,DataSetID;
	JSONObject jsonTestReport=null;
	JiraClient jira = null;
	JSONObject jsonTestSet=null;
	public Map<String,String> APIResult= new HashMap<String,String>();;
  	public App() throws IOException, JiraException
  	{
  		jiraService = new JiraService();
  		APP_LOGS.debug("Initialize App Constructor");
  	 	//Create instance
  		vjson=new SchemaValidation();
  		lstDataSetresult  = new ArrayList<Map<String,String>>();
  		//Proxy host details
	    HttpHost proxy = new HttpHost(CONFIG.getProperty("PROXY_HOST"),Integer.parseInt((CONFIG.getProperty("PROXY_PORT"))));
	    DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
	    CredentialsProvider credsProvider = new BasicCredentialsProvider();
	    credsProvider.setCredentials(
	    		new AuthScope(CONFIG.getProperty("PROXY_HOST"), Integer.parseInt((CONFIG.getProperty("PROXY_PORT"))), AuthScope.ANY_HOST, "ntlm"), 
	    		new NTCredentials(CONFIG.getProperty("PROXY_USERNAME"), CONFIG.getProperty("PROXY_PASSWORD"), "", CONFIG.getProperty("PROXY_DOMAIN")));
	    context = HttpClientContext.create();
	    //Target host details
	    HttpHost targetHost = new HttpHost(CONFIG.getProperty("TARGET_HOST"), Integer.parseInt((CONFIG.getProperty("TARGET_PORT"))), CONFIG.getProperty("TARGET_TYPE"));
	    credsProvider.setCredentials(
	            new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT),
	            new UsernamePasswordCredentials(CONFIG.getProperty("TARGET_USERNAME"), CONFIG.getProperty("TARGET_PASSWORD")));
	    
	    // Create AuthCache instance
	    AuthCache authCache = new BasicAuthCache();
	    // Generate BASIC scheme object and add it to the local auth cache
	    BasicScheme basicAuth = new BasicScheme();
	    authCache.put(targetHost, basicAuth);
	    context.setCredentialsProvider(credsProvider);
	    context.setAuthCache(authCache);    
	    httpclient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).setRoutePlanner(routePlanner).build();
	    //Proxy Specification
	    proxySpecification=new ProxySpecification(CONFIG.getProperty("PROXY_HOST"),Integer.parseInt((CONFIG.getProperty("PROXY_PORT"))),CONFIG.getProperty("PROXY_TYPE")).withAuth(CONFIG.getProperty("PROXY_USERNAME"), CONFIG.getProperty("PROXY_PASSWORD"));
  	}
  	
  	
	public App(JSONObject jsTestReportData,String TestCaseID,String DataSetID,String Details,String APIServer,String Url, String MethodType, String HeaderKey,String HeaderValues,String ParamKey, String ParamValues,String OpKey, String Switchingmode, String ExpectedKeys, String ExpectedValues, String ExpectedStatusCode, String ExpectedSchemaPath, String ThreadExecType)
	{
		//Initialize values
		this.ThreadExecType=ThreadExecType;
		this.jsonTestReport=jsTestReportData;
		this.TestCaseID= TestCaseID;
		this.DataSetID=DataSetID;
		this.Details = Details;
		this.APIServer = APIServer;
		this.Url = Url;
		this.methodType = MethodType;
		this.HeaderKey = HeaderKey;
		this.HeaderValues=HeaderValues;
		this.ParamKey = ParamKey;
		this.ParamValues = ParamValues;
		this.ExpStatusCode = ExpectedStatusCode;
		this.OpKey = OpKey;
		this.SwitchingMode= Switchingmode;
		this.ExpectedSchemaPath = ExpectedSchemaPath;
		this.ExpectedKeys = ExpectedKeys;
		this.ExpectedValues = ExpectedValues;
		
		 //Proxy Specification
	    proxySpecification=new ProxySpecification(CONFIG.getProperty("PROXY_HOST"),Integer.parseInt((CONFIG.getProperty("PROXY_PORT"))),CONFIG.getProperty("PROXY_TYPE")).withAuth(CONFIG.getProperty("PROXY_USERNAME"), CONFIG.getProperty("PROXY_PASSWORD"));

	}
	
	
	 /**************************************************************************
     *  Function name 		: run
     *  Reuse Function 		:
     *  Description 		: Execute non dependent test cases
     /**********************************************************************/
	public void run()
	{
		APP_LOGS.debug("Run Method :");
		System.out.println(Thread.currentThread().getName()+" (Start) "+ThreadExecType+" :"+TestCaseID+DataSetID);
		 try {
			APICall(jsonTestReport,TestCaseID,DataSetID,Details,APIServer,Url, methodType, HeaderKey,HeaderValues,ParamKey, ParamValues,OpKey, SwitchingMode, ExpectedKeys, ExpectedValues, ExpStatusCode, ExpectedSchemaPath);
		} catch (ProcessingException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName()+" (End)"+ThreadExecType+" :"+TestCaseID+DataSetID);//prints thread name
	}
	
	/*************************************************************************************************
	 *  Function name 		: TestExecution
	 *  Reuse Function 		: 
	 *  Description 		: Read the JSON Test set values.Based on the inputs flow the functionality. 
	/
	 * @throws ProcessingException 
	 * @throws JiraException **************************************************************************************************/  
    public JSONObject TestExecution(JiraClient jira,JSONObject Testset) throws ProcessingException, IOException, JiraException
    {
    	String APIURL,APIServer,Url,MethodType,ParamKey,ParamValues,ExpectedKeys,ExpectedValues,OpKey,SwitchingMode,ExpectedStatusCode,ExpectedSchemaPath,TestCaseID = null,DataSetID;
        String Details,HeaderKey,HeaderValues,refvalue;
        int iCount=0;
		int SumRespTime=0;
		String OverallStatus = null;
		String sTestResponseDes = null;
        int AvgRespTime=0;
        Map<String,String> APIResult=null;
	
		try{
    	//JSONObject Testset = Testsets.getJSONObject(iTestIter);
		//System.out.println("APP2 Testset Start: "+Testset);
		//TCID = Testset.get(Constants.TCID).toString();
        TestCaseID = Testset.get(Constants.TCID).toString();
        sTestResponseDes="DataSetID"+JIRAConstants.ValueDelimiter+"TestStatus"+JIRAConstants.ValueDelimiter+"ResponseDescription"+JIRAConstants.ValueDelimiter+"	ResponseTime"+JIRAConstants.ValueDelimiter+"OutValues";
    	OverallStatus=Constants.KEYWORD_PASS;
        APIServer = Testset.get(Constants.SERVER).toString();
         Url = Testset.get(Constants.URL).toString();
         MethodType = Testset.get(Constants.MethodType).toString();
         Details = Testset.get(Constants.Details).toString();
         ExpectedSchemaPath = Testset.get(Constants.ExpectedSchema).toString();;
         SwitchingMode = Testset.get(Constants.SwitchingMode).toString();
         JSONArray DataSets1 = (JSONArray) Testset.get("Datasets");
         for (int k = 0; k < DataSets1.length(); k++) {
			JSONObject DataSet = DataSets1.getJSONObject(k);
			//System.out.println(DataSet.get("DatasetID"));
			iCount=iCount+1;
			DataSetID = DataSet.get(Constants.DATASET).toString();
			refvalue=DataSet.get(JIRAConstants.REFURLValue).toString();
			APIURL=Url+refvalue;
            HeaderKey = DataSet.get(Constants.Header_Keys).toString();
            HeaderValues = DataSet.get(Constants.Header_Values).toString();
            ParamKey = DataSet.get(Constants.Param_Keys).toString();
            ParamValues = DataSet.get(Constants.Param_Values).toString();
            OpKey = DataSet.get(Constants.GetOutputKey).toString();
            ExpectedKeys = DataSet.get(Constants.Expected_Keys).toString();
            ExpectedValues = DataSet.get(Constants.Expected_Values).toString();
            ExpectedStatusCode = DataSet.get(Constants.ExpectedStatusCode).toString();
            APIResult=APICall(DriverScript.jsonTestReportData,TestCaseID,DataSetID,Details,APIServer,APIURL, MethodType, HeaderKey,HeaderValues,ParamKey, ParamValues,OpKey, SwitchingMode, ExpectedKeys, ExpectedValues, ExpectedStatusCode, ExpectedSchemaPath);
            System.out.println(TestCaseID+"-"+DataSetID+":"+APIResult.get("APIStatus"));
            DataSet.put("HeaderKeyValue", APIResult.get("HeaderKeyValue"));
            DataSet.put("Input_KeyValues", APIResult.get("InputValues"));
            DataSet.put("Expected", APIResult.get("GivenExpectedValues"));
            DataSet.put("APIURL", APIResult.get("APIURL"));
            if (APIResult.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_FAIL)){
				 OverallStatus=Constants.KEYWORD_FAIL;
			 }
            sTestResponseDes=sTestResponseDes+"\n"+DataSetID+JIRAConstants.ValueDelimiter+APIResult.get("APIStatus")+JIRAConstants.ValueDelimiter+APIResult.get("ApiDescription")+JIRAConstants.ValueDelimiter+APIResult.get("responseTime")+JIRAConstants.ValueDelimiter+APIResult.get("Output_Values")+"\n";
        	if(APIResult.get("responseTime")!=null)
				 SumRespTime = SumRespTime+Integer.parseInt(APIResult.get("responseTime").replaceAll("\\D+",""));
            DataSet.put("TestResultStatus", APIResult.get("APIStatus"));
            DataSet.put("ResponseDescription", APIResult.get("ApiDescription"));
            DataSet.put("ResponseTime", APIResult.get("responseTime")+" ms");
            DataSet.put("Output_Values", APIResult.get("Output_Values").toString());
            DataSet.put("Response", APIResult.get("resString"));
            DataSet.put("ResponseFilePath", APIResult.get("ResponseFilePath"));
        }
        //System.out.println("APP2 Data Iter: "+TestCaseID);
        Testset.put("TestStatus", OverallStatus);
        if (iCount>0)
    		AvgRespTime=SumRespTime/iCount;
        //System.out.println("APP2 Data : "+TestCaseID+AvgRespTime);
        Testset.put("AvgResponseTime", String.valueOf(AvgRespTime)+" ms");
	 	if (CONFIG.getProperty("InputType").equalsIgnoreCase("Jira")) {
	 		//System.out.println("TestSet :"+TestCaseID+sTestResponseDes);
       		 jiraService.JiraUpdateIssueKey(jira,TestCaseID,OverallStatus,String.valueOf(AvgRespTime)+" ms", sTestResponseDes);
       		 
        }
	 	
	 	//System.out.println("APP2 Testset End: "+Testset);
	 	DriverScript.jsonTestReportData.append("Tests", Testset);
		}
	 	catch(Exception e)
        {
        	e.printStackTrace();
        }
	  //System.out.println("APP2 jsonTestReportData: "+DriverScript.jsonTestReportData);
	  //System.out.println("APP2 Test: "+jsonTestReport);
 	  return DriverScript.jsonTestReportData;
    }
	
	 /**************************************************************************
     *  Function name 		: APICall
     *  Reuse Function 		:
     *  Description 		: Initialize and set API input values
     /**********************************************************************/
	public Map<String,String> APICall(JSONObject jsTestReportData,String TestCaseID,String DataSetID,String Details,String APIServer,String Url, String MethodType, String HeaderKey,String HeaderValues,String ParamKey, String ParamValues,String OpKey, String Switchingmode, String ExpectedKeys, String ExpectedValues, String ExpectedStatusCode, String ExpectedSchemaPath) throws ProcessingException, IOException
	{
		  String APIURL;
	      String InputValues,GivenExpectedValues,HeaderKeyValue;
	      int ExpStatusid;
	      String Status=Constants.KEYWORD_FAIL;;
	      String Description=null;
	      InputValues = "";
	      GivenExpectedValues = "";
	      HeaderKeyValue = "";
	      ExpStatusid = (int) Double.parseDouble(ExpectedStatusCode);
	      Map<String,String> testCaseResult = new HashMap<String,String>();
	      
	      
	      try{
			//API Url initialize
	    	  System.out.println("\nTestcaseID : "+TestCaseID+"-"+DataSetID);
	    	  
	    	 // System.out.println("\nTestcaseID Referen json TestData : "+jsTestReportData);
	    	  Map<String, String> mapRefUrl=GetReferenceValue(jsTestReportData,Url);
	    	
		      if (mapRefUrl.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_SKIP)){
		    	  Status= Constants.KEYWORD_SKIP;
		    	  Description=mapRefUrl.get("ApiDescription");
		      }
		      Url= mapRefUrl.get("ReferenceValue");
		      APIURL=APIServer+Url;
			//Header value
			if ((HeaderValues.length()>0)&&(!HeaderValues.equalsIgnoreCase("na"))&&(!HeaderValues.equalsIgnoreCase("null"))){
				 Map<String, String> mapRefHValues=GetReferenceValue(jsTestReportData,HeaderValues);
			      if (mapRefHValues.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_SKIP)){
			    	  Status= Constants.KEYWORD_SKIP;
			    	  Description=mapRefHValues.get("ApiDescription");
			      }
			      HeaderValues= mapRefHValues.get("ReferenceValue");
			      HeaderKeyValue=" <b>Request Headers:</b>"+Rep_InputValues(HeaderKey,HeaderValues);
			}
			//Parameter input values
			if ((ParamValues.length()>0)&&(!ParamValues.equalsIgnoreCase("na"))&&(!ParamValues.equalsIgnoreCase("null"))){
				Map<String, String> mapRefPValues=GetReferenceValue(jsTestReportData,ParamValues);
			      if (mapRefPValues.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_SKIP)){
			    	  Status= Constants.KEYWORD_SKIP;
			    	  Description=mapRefPValues.get("ApiDescription");
			      }
			      ParamValues= mapRefPValues.get("ReferenceValue");
				InputValues="\n <b>Request Parameters:</b> "+Rep_InputValues(ParamKey,ParamValues);
			}
			//Expected values
			GivenExpectedValues=" <b>Expected Criteria</b> \n Status Code :"+ExpectedStatusCode;
			if ((ExpectedValues.length()>0)&&(!ExpectedValues.equalsIgnoreCase("null"))&&(!ExpectedValues.equalsIgnoreCase("na"))){
				Map<String, String> mapRefExValues=GetReferenceValue(jsTestReportData,ExpectedValues);
			      if (mapRefExValues.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_SKIP)){
			    	  Status= Constants.KEYWORD_SKIP;
			    	  Description=mapRefExValues.get("ApiDescription");
			      }
			      ExpectedValues= mapRefExValues.get("ReferenceValue");
				GivenExpectedValues=GivenExpectedValues+"\n Expected Key Values :"+Rep_InputValues(ExpectedKeys,ExpectedValues);
			}
			if ((ExpectedSchemaPath.length()>0)&&(!ExpectedSchemaPath.equalsIgnoreCase("null"))){
				GivenExpectedValues=GivenExpectedValues+"\n Expected Schema File : "+ExpectedSchemaPath;
				//ExpectedSchemaPath=System.getProperty("user.dir")+CONFIG.getProperty("JIRAConfig.downloadPath")+ExpectedSchemaPath;
				ExpectedSchemaPath=CONFIG.getProperty("JIRAConfig.downloadPath")+ExpectedSchemaPath;
			}
			System.out.println("Request Input : "+MethodType+" "+APIURL+" "+HeaderValues+" "+ParamValues+" "+ExpectedStatusCode+" "+ExpectedKeys+" "+ExpectedValues+" "+ExpectedSchemaPath);
    		testCaseResult.put("TestCaseID",TestCaseID);
    		testCaseResult.put("DataSetID",DataSetID);
    		testCaseResult.put("methodType",MethodType);
    		testCaseResult.put("APIURL",APIURL);
    		testCaseResult.put("Details",Details);
    		testCaseResult.put("HeaderKeyValue",HeaderKeyValue);
    		testCaseResult.put("InputValues",InputValues);
    		testCaseResult.put("GivenExpectedValues",GivenExpectedValues);
		    //Start test level execution
		    if (!Status.equalsIgnoreCase(Constants.KEYWORD_SKIP)) {
	          //Execute API Call
	            Map<String,String> APIResult=ExecuteAPICall(TestCaseID,DataSetID,Details,APIURL,  MethodType,  HeaderKey, HeaderValues, ParamKey,  ParamValues, OpKey,  Switchingmode,  ExpectedKeys,  ExpectedValues,ExpectedSchemaPath,ExpStatusid);
	            
	    		testCaseResult.put("ContentType",APIResult.get("ContentType"));
	    		testCaseResult.put("resString",APIResult.get("resString"));
	    		testCaseResult.put("APIStatus",APIResult.get("APIStatus"));
	    		testCaseResult.put("ApiDescription",APIResult.get("ApiDescription"));
	    		testCaseResult.put("Output_Values",APIResult.get("Output_Values"));
	    		testCaseResult.put("responseTime",APIResult.get("responseTime"));
	    		testCaseResult.put("ResponseFilePath",APIResult.get("ResponseFilePath"));
		    }
		    else{
		    	
		    	testCaseResult.put("ContentType","");
	    		testCaseResult.put("resString","");
	    		testCaseResult.put("APIStatus",Status);
	    		testCaseResult.put("ApiDescription",Description);
	    		testCaseResult.put("Output_Values","");
	    		testCaseResult.put("responseTime","0");
	    		testCaseResult.put("ResponseFilePath","");
		    }
		    
		    lstDataSetresult.add(testCaseResult);
	      }
	      catch(Exception e)
	      {
	    	  e.printStackTrace();
			return testCaseResult;
	      }
	      return testCaseResult;
	}
	
    /**************************************************************************
     *  Function name 		: ExecuteAPICall
     *  Reuse Function 		:
     *  Description 		: Execute API Call
     /
     * @throws IOException 
     * @throws ProcessingException **********************************************************************/
	public Map<String,String> ExecuteAPICall(String TestCaseID,String DataSetID,String Details,String APIURL, String MethodType, String HeaderKey,String HeaderValues,String ParamKey, String ParamValues,String OpKey, String Switchingmode, String ExpectedKeys, String ExpectedValues, String ExpectedSchemaPath, int ExpStatusid) throws ProcessingException, IOException
	{
		Response res=null;
		String ContentType=null,ResponseFilePath=null,OutValues="";
		long responseTime=0;
		String Status=null;
		String Description=null;		
		APP_LOGS.debug("API call");
		//Store response in a map
		Map<String,String> testCaseResult = new HashMap<String,String>();
		try
		{
			switch(MethodType)
			{
				case "GET":
					res=Get_Method(APIURL,HeaderKey,HeaderValues);
					break;
				case "POST":
					res=Post_Method(APIURL,HeaderKey,HeaderValues,ParamKey,ParamValues);
					break;
				case "PUT":
					res=Put_Method(APIURL,HeaderKey,HeaderValues,ParamKey,ParamValues);
					break;
				case "DELETE":
					res=Delete_Method(APIURL,HeaderKey,HeaderValues,ParamKey,ParamValues);
					break;
			}
			//testCaseResult.put("RequestDateTime",Date());
			String resString=GetRespString(res);
	        ContentType = GetResponseContentType(res);
	        ResponseFilePath = StoreRespose(TestCaseID+"_"+DataSetID, ContentType,resString);
	        Map<String, String> mapAPIRespStatus=VerifyResponseStatus(TestCaseID+"_"+DataSetID, res, ExpStatusid);
	        Status=mapAPIRespStatus.get("APIStatus");
	        Description=mapAPIRespStatus.get("ApiDescription");
	      //  System.out.println(TestCaseID+DataSetID+" 1: "+Status);
			if(mapAPIRespStatus.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_PASS)) {
				responseTime = GetResponseTime(res);
	            OutValues = GetOutkeyValueFromResponse(res, OpKey);
	            //ImplSwitchingMode(XlsxInputFile, XLInputSheetName, res, SwitchingMode);
	            //Validate Schema
	            Map<String, String> mapAPIRespSchStatus=ValidataSchema(res, ExpectedSchemaPath, ResponseFilePath);
	            if(mapAPIRespSchStatus.get("APIStatus")!=null)
	            {
	            	Status=mapAPIRespSchStatus.get("APIStatus");
	            	Description=Description+mapAPIRespSchStatus.get("ApiDescription");
	            }
		        //Validate expected Key values pairs
	            Map<String, String> mapAPIRespKeyValues = ResponseExpectedValidation(TestCaseID+"_"+DataSetID, res, ExpectedKeys, ExpectedValues);
	            if(mapAPIRespKeyValues.get("APIStatus")!=null)
	            {
	            Status=mapAPIRespKeyValues.get("APIStatus");
	       	 	Description=Description+mapAPIRespKeyValues.get("ApiDescription");
	            }
	        }
			Description=Description.replace("null", "");
			//System.out.println(TestCaseID+DataSetID+" 2: "+Status);
			testCaseResult.put("TestCaseID",TestCaseID);
			testCaseResult.put("DataSetID",DataSetID);
			testCaseResult.put("ContentType",ContentType);
			testCaseResult.put("resString",resString);
			testCaseResult.put("APIStatus",Status);
			testCaseResult.put("ApiDescription",Description);
			testCaseResult.put("Output_Values",OutValues);
			testCaseResult.put("responseTime",String.valueOf(responseTime));
			testCaseResult.put("ResponseFilePath",ResponseFilePath);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			 return testCaseResult;
		}
	
		return testCaseResult;
	}
    
    
    /***************************************************************************************
	 *  Function name 		: Get_Method
	 *  Reuse Function 		:  
	 *  Description 		: GET Method API WebServices
	/****************************************************************************************/         
    public HttpResponse HttpGet_Method(String apiurl,String HKeys, String HValues) throws ClientProtocolException, IOException
	{
    	APP_LOGS.debug("Execute GET Call :"+apiurl+HKeys+HValues);
		HttpResponse resp=null;
		try{
			 HttpGet httpget = new HttpGet(apiurl);
			 if ((HKeys.length()>0)&(HValues.length()>0))
			 {
		        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
		        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
		        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
		        {
		        	httpget.setHeader(ArKeys[i],ArValues[i]);
		        }
			}
	        resp = httpclient.execute(httpget, context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
	   	 	return resp;
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
	}
    
    /***************************************************************************************
	 *  Function name 		: Get_Method
	 *  Reuse Function 		:  
	 *  Description 		: GET Method API WebServices
	/****************************************************************************************/         
    public Response Get_Method(String apiurl,String HKeys, String HValues)
    {    
    	APP_LOGS.debug("Execute GET Call :"+apiurl+HKeys+HValues);
    	Response GetResp = null;
    	try
    	{
    		Map<String, String> header = GetKeyValuePair(HKeys,HValues);
	    	GetResp=given()   
	    			//.relaxedHTTPSValidation()
	        .proxy(proxySpecification)
	        .headers(header)
			.get(apiurl);
    	}
    	catch(Exception e)
    	{
    		return GetResp;
    	}
    	return GetResp;
   }
	/***************************************************************************************
	 *  Function name 		: Post_Method
	 *  Reuse Function 		:  
	 *  Description 		: Post Method API WebServices
	/****************************************************************************************/         
    public Response Post_Method(String apiurl,String HKeys, String HValues,String PKeys, String PValues){
    	APP_LOGS.debug("Execute POST Call :"+apiurl+HKeys+HValues+PKeys+PValues);
    	Response PostResp = null;
    	try
    	{
    		Map<String, String> BodyParameter = GetKeyValuePair(PKeys,PValues);
    		Map<String, String> header = GetKeyValuePair(HKeys,HValues);
    		PostResp=given()   
	        .proxy(proxySpecification)		
	        .headers(header)
			.body(BodyParameter)
			.when()
			.post(apiurl);
    	}
      	catch(Exception e)
    	{
    		return PostResp;
    	}
      	return PostResp;
    	
   }
    
	/***************************************************************************************
	 *  Function name 		: Post_Method
	 *  Reuse Function 		: NA
	 *  Description 		: Post Method API WebServices using HttpPost
	/****************************************************************************************/         
    public HttpResponse HTTPPost_Method(String apiurl,String HKeys, String HValues,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
    	APP_LOGS.debug("Execute POST Call :"+apiurl+HKeys+HValues+PKeys+PValues);
		HttpResponse resp=null;
		try{
			HttpPost httppost = new HttpPost(apiurl);
			if ((HKeys.length()>0)&(HValues.length()>0))
			{
		        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
		        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
		        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
		        {
		        	httppost.setHeader(ArKeys[i],ArValues[i]);
		        }
			}
			ArrayList<NameValuePair> postParameters=GetNameValuePair(PKeys,PValues);
			httppost.setEntity(new UrlEncodedFormEntity(postParameters));
	        resp = httpclient.execute(httppost,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;
	}
	
	/***************************************************************************************
	 *  Function name 		: Delete_Method
	 *  Reuse Function 		: ReadExcel_Data
	 *  Description 		: Delete Method API WebServices  
	/****************************************************************************************/ 
    public Response Delete_Method(String apiurl,String HKeys, String HValues,String PKeys, String PValues){
    	APP_LOGS.debug("Execute DELETE Call :"+apiurl+HKeys+HValues+PKeys+PValues);
    	Map<String, String> BodyParameter = GetKeyValuePair(PKeys,PValues);
    	Map<String, String> header = GetKeyValuePair(HKeys,HValues);
    	Response res=given()
    	.proxy(proxySpecification)	
    	.headers(header)
		.body(BodyParameter)
		.when()
		.delete(apiurl);
		 return res;
   }
	/***************************************************************************************
	 *  Function name 		: Put_Method
	 *  Reuse Function 		: 
	 *  Description 		: Update Method API WebServices 
	/****************************************************************************************/ 
    public Response Put_Method(String apiurl,String HKeys, String HValues,String PKeys, String PValues){
    	APP_LOGS.debug("Execute PUT Call :"+apiurl+HKeys+HValues+PKeys+PValues);
    	
    	//int StatusCode;
    	//StatusCode=1;
    	Map<String, String> BodyParameter = GetKeyValuePair(PKeys,PValues);
    	Map<String, String> header = GetKeyValuePair(HKeys,HValues);
    	Response res=given()
    	.proxy(proxySpecification)	
    	.headers(header)
		.body(BodyParameter)
		.when()
		.put(apiurl);
    	return res;
   }
    
    
	/***************************************************************************************
	 *  Function name 		: HttpPut_Method
	 *  Reuse Function 		: 
	 *  Description 		: Update Method API WebServices 
	/****************************************************************************************/ 
	public HttpResponse HttpPut_Method(String apiurl,String HKeys, String HValues,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
		APP_LOGS.debug("Execute PUT Call :"+apiurl+HKeys+HValues+PKeys+PValues);
		HttpResponse resp=null;
		try{
			 HttpPut httpput = new HttpPut(apiurl);
			 
				if ((HKeys.length()>0)&(HValues.length()>0))
				{
			        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	httpput.setHeader(ArKeys[i],ArValues[i]);
			        }
				}
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
					ArrayList<NameValuePair> postParameters= GetNameValuePair(PKeys,PValues); 
			        httpput.setEntity(new UrlEncodedFormEntity(postParameters));
				}
	        resp = httpclient.execute(httpput,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;
	}
	
	/***************************************************************************************
	 *  Function name 		: Delete_Method
	 *  Reuse Function 		: 
	 *  Description 		: delete Method API WebServices 
	/****************************************************************************************/ 
	public HttpResponse HttpDelete_Method(String apiurl,String HKeys, String HValues,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
		APP_LOGS.debug("Execute DELETE Call :"+apiurl+HKeys+HValues+PKeys+PValues);
		HttpResponse resp=null;
		try{
			 HttpDelete httpdelete = new HttpDelete(apiurl);
				if ((HKeys.length()>0)&(HValues.length()>0))
				{
			        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	httpdelete.setHeader(ArKeys[i],ArValues[i]);
			        }
				}
				
			 if ((PKeys.length()>0)&(PValues.length()>0))
			{
				 ArrayList<NameValuePair> postParameters= GetNameValuePair(PKeys,PValues); 
			     ((HttpResponse) httpdelete).setEntity(new UrlEncodedFormEntity(postParameters));
			}
	        resp = httpclient.execute(httpdelete,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;

	}

	/***************************************************************************************
	 *  Function name 		: ImplSwitchingMode
	 *  Reuse Function 		:  GetOutkeyValueFromResponse
	 *  Description 		: Depends upon response switch which test need to be executed
	/****************************************************************************************/    
	  public void ImplSwitchingMode(String Filename, String Sheetname, Response res,String SwitchingMode) 
	  {
		  APP_LOGS.debug("Switching Mode :"+SwitchingMode);
		String switchValues=null;
		if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS)){
			//Xls_Reader current_TestCase_xls1=new Xls_Reader(Filename);
	        if((SwitchingMode.length()>0)&&(!SwitchingMode.equalsIgnoreCase("null")))
			{
		  	String[] switching = SwitchingMode.split("\\|");					        										           
		  	if ((switching.length>0))
		  	{				
		  		switchValues=GetOutkeyValueFromResponse(res,switching[0]);
				for(int i=1;i<switching.length ;i++)
				{								    			
					String[] tc=switching[i].split(":");									    			
					if (switchValues.equalsIgnoreCase(tc[0]))
					{		
						int rownum2=current_TestCase_xls.getCellRowNum(Sheetname, Constants.TCID,tc[1]);
						current_TestCase_xls.setCellData(Sheetname,Constants.TESTRUNMODE, rownum2, "Yes");
					}	
				}
			}
	    }
		}
	  }
		
	/***************************************************************************************
	 *  Function name 		: GetOutkeyValueFromResponse
	 *  Reuse Function 		:  GetResponseContentType
	 *  Description 		: Get output key value from the response
	/****************************************************************************************/    
	public String GetOutkeyValueFromResponse(Response res,String Key) 
	{
		APP_LOGS.debug("Get Key Value from Response :"+Key);
	   	String repOutputKey=null;
	   	String repContentType=null;
	    	try
	   		 {  
	    		if ((Key.length()>0)&&(!Key.equalsIgnoreCase("null")))
	    		{
	    			repContentType=GetResponseContentType(res);
		    		if ((repContentType.contains("json"))|(repContentType.contains("JSON")))
		    		{
		    			repOutputKey=res.then().extract().jsonPath().getString(Key);
			    	
		    		}
		    		else if ((repContentType.contains("xml"))|(repContentType.contains("XML")))
		    		{
		    			repOutputKey=res.then().extract().xmlPath().getString(Key);
		    		}	
		    		else if ((repContentType.contains("html"))|(repContentType.contains("HTML")))
		    		{
		    			repOutputKey=res.then().extract().htmlPath().getString(Key);
		    		}
		    		
		    	   	if ((repOutputKey.contains("["))&(repOutputKey.contains("]")))
		            {
		    	   		repOutputKey=repOutputKey.replace("[", "");
		    	   		repOutputKey=repOutputKey.replace("]", "");
		            }
		    	
	    		}	
	    	}
	    	catch (AssertionError e)
	   		 {     		
	   			 System.out.println("Err Catch GetOutkeyValue :"+e.getMessage());
	   			 return repOutputKey;
	   		 }
	    	return repOutputKey;
	    	
	    }

	/*************************************************************************************************
	 *  Function name 		: GetJsonValueFromResponse
	 *  Reuse Function 		: 
	 *  Description 		:  Get the Value of  key from responsestring
	/**************************************************************************************************/
	 public String GetJsonValueFromResponse(String ResponseString,String Key)
	 {   	
		 APP_LOGS.debug("Get Key Value from Response :"+Key);
	    	String ReString;
	    	ReString=null;
	    	ReString="Not Found";
		    try 
		        {
		    	if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
		    	{
			    	JsonPath jsonResponse = new JsonPath(ResponseString);
				    ReString= jsonResponse.getString(Key);			 		 
					System.out.println("Json Values for output key "+Key+" is "+ReString);
		    	}
		    	else
		    	{
		    		ReString="";
		    	}
		        } 
		     catch (Exception e) 
		        {
		        	e.printStackTrace();
		        }        	      
	     	return ReString;
	      }    
	
	 
		/*************************************************************************************************
		 *  Function name 		: GetJsonValueFromResponse2
		 *  Reuse Function 		: 
		 *  Description 		: Get the Value of  key from external json file
		/**************************************************************************************************/
		 public String GetJsonValueFromResponse2(String FileName,String FileType,String Key)
		    {   	
			 APP_LOGS.debug("Get Key Value from Response File :"+Key);
		    	String ReString;
		    	ReString=null;
		    	ReString="Not Found";
			    File file = new File(System.getProperty("user.dir")+"/src/test/resources/Response/"+FileName+"."+FileType);
			    try 
			        {
			    	
			    	JsonPath jsonResponse = new JsonPath(new FileReader(file));
				    ReString= jsonResponse.getString(Key);			 		 
					System.out.println("Json Values for output key "+Key+" is "+ReString);

			        } 
			     catch (IOException e) 
			        {
			        	e.printStackTrace();
			        }        	      
		     	return ReString;
		      }    
		
		/**************************************************************************
		 *  Function name 		: ExpectedValueValidation
		 *  Reuse Function 		: 
		 *  Description 		: Get Method with validation
		 	/**********************************************************************/
	    public boolean ExpectedValueValidation(String apiurl,String Key,String ExpectedValue) 
	    {
	    	APP_LOGS.debug("Validate response code with expected:"+ExpectedValue);
	    		try
	    		 {    
	    			get(apiurl).then().assertThat().body(Key, equalTo(ExpectedValue));
	    			return true;
	    		 }
	    		 catch (AssertionError e)
	    		 {     			
	    			 return false;
	    		 }
	    }
	    
		/**************************************************************************
		 *  Function name 		: Rep_InputValues
		 *  Reuse Function 		: 
		 *  Description 		: Provide paired key values from  excel input key values    
		 	/**********************************************************************/    
	    public String Rep_InputValues(String PKeys,String PValues) 
		{
	    	APP_LOGS.debug("Get Input Values :"+PKeys+PValues);
			String RetnString="";
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
		
			        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
			
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	RetnString=RetnString+"\n "+ArKeys[i]+" : "+ArValues[i];
			        	
			        }
				}
				else
				{
					RetnString="NA";
				}
				return RetnString;
			}
	    
	    
    /**************************************************************************
	 *  Function name 		: GetKeyValuePair
	 *  Reuse Function 		: 
	 *  Description 		: Provide paired key values from  excel input key values    
	 /**********************************************************************/    
	    public ArrayList<NameValuePair> GetNameValuePair(String PKeys,String PValues) 
		{
			//Map<String, String>  mKeyValue=new HashMap<>();
	    	APP_LOGS.debug("Get Arraylist Input Value Pair:"+PKeys+PValues);
			ArrayList<NameValuePair> mKeyValue = null;

	        
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
					mKeyValue = new ArrayList<NameValuePair>();
			        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	mKeyValue.add(new BasicNameValuePair(ArKeys[i], ArValues[i]));
			        }
				
 
				}
				return mKeyValue;
			}
	    
	    
    /**************************************************************************
	 *  Function name 		: GetKeyValuePair
	 *  Reuse Function 		: 
	 *  Description 		: Provide paired key values from  excel input key values    
	 /**********************************************************************/    
	    public Map<String, String> GetKeyValuePair(String PKeys,String PValues) 
		{
	    	APP_LOGS.debug("Get Maplist of Key Value Pair :"+PKeys+PValues);
			Map<String, String>  mKeyValue=new HashMap<>();
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
			        
					//jsonAsMap = new HashMap<>();
			        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	mKeyValue.put(ArKeys[i], ArValues[i]);
			        	
			        }
 
				}
				return mKeyValue;
			}
	    
	    /**************************************************************************
		 *  Function name 		: ResponseExpectedValidation
		 *  Reuse Function 		: 
		 *  Description 		: Validate response with expected key value pair    
		 /**********************************************************************/    
	    public boolean ResponseExpectedValidation(Response res, String PKeys,String PValues)
	    {
	    	APP_LOGS.debug("Validation API Response with expected keyvalue :"+PKeys+PValues);
	    	 boolean Validation= false;
	    	 String ExpecKeytoFind=null;
	    	 String repKeyExist=null;
	  
		    	try
		   		 {  
		    		 if ((PKeys.length()>0)&(PValues.length()>0)&(!PKeys.equalsIgnoreCase("null"))&(!PKeys.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("null")))
					{
			    		
				        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
				        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
				        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
				        {
				        	ExpecKeytoFind=ArKeys[i];
				        
				        	//Check whether key is present
				        	repKeyExist=res.then().extract().path(ArKeys[i]);
				        	if(repKeyExist!=null)
				        	{	
						        res.then().assertThat().body(ArKeys[i], equalTo(ArValues[i]));
						    	Validation= true;
				        	}
				        	else
				        	{
				        		ApiDescription=ApiDescription+"\n  Key not found : "+ArKeys[i];
					   			APIStatus=Constants.KEYWORD_FAIL;
					   			System.out.println("Err Catch ResponseExpectedValidation :"+ApiDescription);
					   			return false;
				        	}
				        }
	
					}
			    	else
			    	{
			    		 Validation= true;
			    		 //ApiDescription=ApiDescription+"\n  Expected Values not provided";
			    		 return Validation;
			    	}
		   		 }
		   		 catch (AssertionError e)
		   		 {     		
		   			System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Mismatched Actual Values:"+e.getMessage();
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    	catch (ClassCastException e)
		   		 {     		
		    		System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Key not found  :"+ExpecKeytoFind;
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
			    APIStatus=Constants.KEYWORD_PASS;
				ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
		    		

	    	return Validation;
	    	
	    }
    /**************************************************************************
     *  Function name 		: ResponseExpectedValidation
     *  Reuse Function 		:
     *  Description 		: Validate response with expected key value pair
     /**********************************************************************/
    public  Map<String, String> ResponseExpectedValidation(String TestCaseId,Response res, String PKeys,String PValues)
    {
    	APP_LOGS.debug("Validation API Response with expected keyvalue :"+TestCaseId+PKeys+PValues);
        
        String ExpecKeytoFind=null;
        String repKeyExist=null;
        Map<String, String> mapKeyValueValidation = new HashMap<String,String>();
        String Description = null;
        String Status=null;
            try
            {
            	 if ((PKeys.length()>0)&(PValues.length()>0)&(!PKeys.equalsIgnoreCase("null"))&(!PKeys.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("null")))
                {

                    String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
                    String[] ArValues = PValues.split(Constants.DATA_SPLIT);
                    for(int i =0; i < (ArKeys.length & ArValues.length) ; i++){
                        ExpecKeytoFind=ArKeys[i];
                        //Check whether key is present
                        repKeyExist=res.then().extract().path(ArKeys[i]);
                        if(repKeyExist!=null){
                            res.then().assertThat().body(ArKeys[i], equalTo(ArValues[i]));
                        }
                        else{
                        	Description="Key not found : "+ArKeys[i];
                        	Status=Constants.KEYWORD_FAIL;
                            System.out.println("Err Catch ResponseExpectedValidation for "+ TestCaseId+":"+ApiDescription);
                            mapKeyValueValidation.put("APIStatus", Status);
                            mapKeyValueValidation.put("ApiDescription", Description); 
                            return mapKeyValueValidation;
                        }
                    }
                }
                else{
                    //ApiDescription=ApiDescription+"\n  Expected Values not provided";
                    mapKeyValueValidation.put("APIStatus", Status);
                    mapKeyValueValidation.put("ApiDescription", Description); 
                    return mapKeyValueValidation;
                }
            }
            catch (AssertionError e){
                System.out.println("Err Catch ResponseExpectedValidation for "+ TestCaseId+":"+e.getMessage());
                Description=Description+"\n  Mismatched Actual Values:"+e.getMessage();
                Status=Constants.KEYWORD_FAIL;
                mapKeyValueValidation.put("APIStatus", Status);
                mapKeyValueValidation.put("ApiDescription", Description); 
                return mapKeyValueValidation;
            }
            catch (ClassCastException e){
                System.out.println("Err Catch ResponseExpectedValidation for "+ TestCaseId+":"+e.getMessage());
                Description=Description+"\n  Key not found  :"+ExpecKeytoFind;
                Status=Constants.KEYWORD_FAIL;
                mapKeyValueValidation.put("APIStatus", Status);
                mapKeyValueValidation.put("ApiDescription", Description); 
                return mapKeyValueValidation;
            }
            Status=Constants.KEYWORD_PASS;
            Description=Description+"\n  Expected Values matched with actual values";
            mapKeyValueValidation.put("APIStatus", Status);
            mapKeyValueValidation.put("ApiDescription", Description); 
            return mapKeyValueValidation;
    }
    
   
	    /**************************************************************************
		 *  Function name 		: ResponseExpectedValidation
		 *  Reuse Function 		: 
		 *  Description 		: Validate response with expected key value pair    
		 /**********************************************************************/    
	    public boolean ResponseValidation_hasitem(Response res, String PKeys,String PValues)
	    {
	    	APP_LOGS.debug("Validation API Response hasitem with expected keyvalue :"+PKeys+PValues);
	    	 boolean Validation= false;
	    	 String ExpecKeytoFind=null;
	    	 String repKeyExist=null;
		    	try
		   		 {  
		    		 if ((PKeys.length()>0)&(PValues.length()>0)&(!PKeys.equalsIgnoreCase("null"))&(!PKeys.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("null")))
		                {
		    			 String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
				        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
				        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
				        {
				        	ExpecKeytoFind=ArKeys[i];
				        	//Check whether key is present
				        	repKeyExist=res.then().extract().path(ArKeys[i]);
				        	if(repKeyExist!=null)
				        	{	
						        res.then().assertThat().body(ArKeys[i], hasItem(ArValues[i]));
						    	Validation= true;
				        	}
				        	else
				        	{
				        		ApiDescription=ApiDescription+"\n  Key not found : "+ArKeys[i];
					   			APIStatus=Constants.KEYWORD_FAIL;
					   			System.out.println("Err Catch ResponseExpectedValidation :"+ApiDescription);
					   			return false;
				        	}
				        }
					}
			    	else
			    	{
			    		 Validation= true;
			    		 //ApiDescription=ApiDescription+"\n  Expected Values not provided";
			    		 return Validation;
			    	}
		   		 }
		   		 catch (AssertionError e)
		   		 {     		
		   			System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Mismatched Actual Values:"+e.getMessage();
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    	catch (ClassCastException e)
		   		 {     		
		    		System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Key not found :"+ExpecKeytoFind;
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    APIStatus=Constants.KEYWORD_PASS;
			ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
	    	return Validation;
	    	
	    }
	    
	    /***************************************************************************************
		 *  Function name 		: GetOutkeyValueFromResponse
		 *  Reuse Function 		:  GetResponseContentType
		 *  Description 		: Get output key value from the response
		/****************************************************************************************/    
		public static String VerifyPathFromResponse(Response res,String Key) 
		{
			APP_LOGS.debug("Verify the key exist in API Response :"+Key);
		   	String bResPathValid=null;
	
		    	try
		   		 {  
		    		bResPathValid=res.then().extract().path(Key);
			    	System.out.println("Path exist : "+Key+" : "+bResPathValid);
		    	}
		    	catch (AssertionError e)
		   		 {     		
		   			 System.out.println("Err Catch VerifyPathFromResponse :"+e.getMessage());
		   			 return bResPathValid;
		   		 }
		    	catch (ClassCastException e)
		   		 {     		
		   			 System.out.println("Err Catch VerifyPathFromResponse :"+e.getMessage());
		   			 return bResPathValid;
		   		 }
		    	return bResPathValid;
		    	
		    }
	    
	    /**************************************************************************
		 *  Function name 		: GetResponseTime
		 *  Reuse Function 		: 
		 *  Description 		: Get response time from response    
		 /**********************************************************************/  
	    public long GetResponseTime(Response res)
	    {
	    	APP_LOGS.debug("Get API Response Time ");
	    	long repTime=0;
		    	try{  
				    repTime=res.then().extract().response().getTime();
				    System.out.println("Response Time "+repTime);
				   // ApiDescription=ApiDescription+"\n  Response Time:"+repTime +" ms";
				 }
		    	catch (AssertionError e){     		
		   			 System.out.println("Err Catch GetResponseTime :"+e.getMessage());
		   			 ApiDescription=ApiDescription+"\n  Invalid Response Time: "+repTime;
		   			 return repTime;
		   		 }
	    	return repTime;	    	
	    }

	    /**************************************************************************
		 *  Function name 		: GetResponseTimeinMS
		 *  Reuse Function 		: 
		 *  Description 		: Get response time in ms from response    
		 /**********************************************************************/  
	    public String GetResponseTimeinMS(Response res)
	    {
	    	APP_LOGS.debug("Get Response time(ms) ");
	    	String respinms="";
	    	long repTime=0;
		    	try
		   		 {  
				    repTime=res.then().extract().response().getTime();
				    System.out.println("Resp Time "+repTime);
				    respinms=repTime+" ms";
				   // ApiDescription=ApiDescription+"\n  Response Time:"+repTime +" ms";
				 }
		    	catch (AssertionError e)
		   		 {     		
		   			
		   			 System.out.println("Err Catch GetResponseTime :"+e.getMessage());
		   			 ApiDescription=ApiDescription+"\n  Invalid Response Time: "+repTime;
		   			 return respinms;
		   		 }
		    	//ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
	    	return respinms;
	    	
	    }
	    
	    /**************************************************************************
		 *  Function name 		: GetResponseContentType
		 *  Reuse Function 		: 
		 *  Description 		: Get content type from response    
		 /**********************************************************************/  
	    public static String GetResponseContentType(Response res)
	    {
	    	APP_LOGS.debug("Get Response ContentType ");
	    	String repContentType=null;
	    	String RespContent=null;
	    	try
	   		 {  
	    		repContentType=res.then().extract().response().contentType();
			    //System.out.println("Resp Content Type "+repContentType);
	    		
	      		if ((repContentType.contains("json"))|(repContentType.contains("JSON")))
	    		{
	      			RespContent="json";
	    		}
	    		else if ((repContentType.contains("xml"))|(repContentType.contains("XML")))
	    		{
	    			RespContent="xml";
	    		}	
	    		else if ((repContentType.contains("html"))|(repContentType.contains("HTML")))
	    		{
	    			RespContent="html";
	    		}
	    		else
	    		{
	    			RespContent="txt";
	    		}
	  
			 }
	    	catch (AssertionError e){     		
	   			 System.out.println("Err Catch GetResponseContentType :"+e.getMessage());
	   			 ApiDescription=ApiDescription+"\n  Invalid Content Type:"+repContentType;
	   			 return RespContent;
	   		 }
	    	return RespContent;
	    }
	    
    /********************************************************************************
	 *  Function name 		: ValidataSchema
	 *  Reuse Function 		: 
	 *  Description 		: Validate response with schema from JSON, XML-XSD/DTD
	 /*******************************************************************************/  
	public Map<String, String> ValidataSchema(Response res,String SchemaFilepath,String ResponseFilePath) throws ProcessingException, IOException
	{
		APP_LOGS.debug("Validate API Response with Schema file "+SchemaFilepath);
	   	String repContentType=null;
	    File SchmFile = new File(SchemaFilepath);
	 	Map<String, String> mapSchValidation = new HashMap<String,String>();
	 	String Description = null;
	 	String Status=null;
	   	 if (SchmFile.exists())
    	 {
	    	try
	   		 {  
	    			repContentType=GetResponseContentType(res);
		    		if ((repContentType.contains("json"))|(repContentType.contains("JSON")))
		    		{
		    			Description="Json Schema Validation : ";
		    			//res.then().assertThat().body(matchesJsonSchemaInClasspath(""));
		    			Map<String, String> mapJsonSchValidation =ValidateJSONSchema(SchemaFilepath,ResponseFilePath);
		    			Status=mapJsonSchValidation.get("APIStatus");
		    			Description=Description+"\n"+mapJsonSchValidation.get("ApiDescription");
		    		}
		    		else if ((repContentType.contains("xml"))|(repContentType.contains("XML")))
		    		{
		    			String ext =FilenameUtils.getExtension(SchemaFilepath);
		    			if (ext.equalsIgnoreCase("xsd"))
		    			{
		    				Description="XML Schema Valitation with XSD :";
		    				res.then().assertThat().body(matchesXsd(SchmFile));
		    				Status=Constants.KEYWORD_PASS;
		    				Description=Description+"\n Passed ";
		    			}
		    			else if (ext.equalsIgnoreCase("dtd"))
		    			{
		    				Description="XML Schema Valitation with Dtd :";
		    				res.then().assertThat().body(matchesDtd(SchmFile));
		    				Status=Constants.KEYWORD_PASS;
		    				Description=Description+"\n Passed ";
		    			}
		    		else if ((repContentType.contains("html"))|(repContentType.contains("HTML")))
		    		{
		    			
		    		}
	    	}
			 }
	    	catch (AssertionError e)
	   		 {     		
	   			System.out.println("Err Catch ValidataSchema :"+e.getMessage());
	   			Status=Constants.KEYWORD_FAIL;
	   			Description=Description+"\n Faileded :";
	   		  	mapSchValidation.put("APIStatus", Status);
	   		   	mapSchValidation.put("ApiDescription", Description); 
	   			 return mapSchValidation;
	   		 }
	    	
    	 }
	   	 
	  	
	   	mapSchValidation.put("APIStatus", Status);
	   	mapSchValidation.put("ApiDescription", Description);   
	    	return mapSchValidation;
	    	
	    }
	   
    /********************************************************************************
	 *  Function name 		: ValidateJSONSchema
	 *  Reuse Function 		: 
	 *  Description 		: Validate response string with schema from JSON
	 /*******************************************************************************/  
	    public static Map<String, String> ValidateJSONSchema(String JsonSchemaFile,String JsonValueFile) throws ProcessingException, IOException
	    {
	    	APP_LOGS.debug("Validate JSON Schema"+JsonSchemaFile);
	  	  	boolean isvalid=false;
	  	  	String PrcMsg=null;
	  	  	vjson=new SchemaValidation();
	  	  	String Status=null;
	  	  	String Description=null;
	  	  	Map<String, String> mapJsonSchValidation = new HashMap<String,String>();
	  		  File sFile = new File(JsonSchemaFile);
	  		  File jFile = new File(JsonValueFile);
	  		  if ((sFile.exists())&(jFile.exists())) 
	  		  {
	  			  isvalid=vjson.isJsonValid(sFile, jFile);
	  			  if (!isvalid)
	  			  {
	  				PrcMsg=vjson.validateJson(sFile,jFile);
	  				System.out.println("Json Schema Process Msg :"+PrcMsg);
	  				Status=Constants.KEYWORD_FAIL;
	  				Description="Json Schema Faileded Process Msg: \n "+PrcMsg;
	  			  }
	  			  else
	  			  {
	  				  Status=Constants.KEYWORD_PASS;
	  				  Description="Passed ";
	  			  }
	  			}
	  		  else
	  		  {
	  			mapJsonSchValidation.put("APIStatus", Status);
		  		mapJsonSchValidation.put("ApiDescription", Description); 
	  			return mapJsonSchValidation;
	  			  
	  		  }
	  		mapJsonSchValidation.put("APIStatus", Status);
	  		mapJsonSchValidation.put("ApiDescription", Description); 
	  	  return mapJsonSchValidation;
	    }

    /********************************************************************************
	 *  Function name 		: VerifyResponseStatus
	 *  Reuse Function 		:
	 *  Description 		: Validate expected status from response
	 /*******************************************************************************/
	    public int VerifyResponseStatus(Response res,int expStatusCode)
	    {
	    	APP_LOGS.debug("Validate API Response code "+expStatusCode);
	    	int RespStatus=0;
	    	try
	   		 {

			    res.then().assertThat().statusCode(expStatusCode);
			    RespStatus=res.getStatusCode();
			    System.out.println("Response Status :"+RespStatus);

			 }
	    	catch (AssertionError e)
	   		 {
	    		 System.out.println("Err Catch ResponseStatus :"+e.getMessage());
	   			 APIStatus=Constants.KEYWORD_FAIL;
	   			 ApiDescription="The following response details: \n Invalid Response Code:"+RespStatus+"\n"+e.getMessage();
	   			 return RespStatus;
	   		 }
	    	APIStatus=Constants.KEYWORD_PASS;
		    ApiDescription="The following response details: \n Response Code: "+RespStatus;

	    	return RespStatus;
	    }

    /********************************************************************************
     *  Function name 		: VerifyResponseStatus
     *  Reuse Function 		:
     *  Description 		: Validate expected status from response
     /*******************************************************************************/
    public Map<String, String> VerifyResponseStatus(String TestCaseID,Response res,int expStatusCode)
    {
    	APP_LOGS.debug("Validate API Response code "+expStatusCode);
    	Map<String, String> Statusmap = new HashMap<String,String>();
    	String Description;
        int RespStatus=0;
        try{
            res.then().assertThat().statusCode(expStatusCode);
            RespStatus=res.getStatusCode();
            System.out.println("Response Status :"+RespStatus);
        }
        catch (AssertionError e){
            System.out.println("Err Catch ResponseStatus for "+TestCaseID+ " :" +e.getMessage());
            Description="The following response details: \n Invalid Response Code:"+RespStatus+"\n"+e.getMessage();
            Statusmap.put("APIStatus", Constants.KEYWORD_FAIL);
            Statusmap.put("ApiDescription", Description);
            return Statusmap;
        }
        Description="The following response details: \n Response Code: "+RespStatus;
        
    	
        Statusmap.put("APIStatus", Constants.KEYWORD_PASS);
        Statusmap.put("ApiDescription", Description);        
        return Statusmap;
    }

    /********************************************************************************
		 *  Function name 		: VerifyResponseStatus
		 *  Reuse Function 		: 
		 *  Description 		: Validate expected status from Actual
		 /*******************************************************************************/  
	    
	    public static void VerifyResponseStatus(int ActualStatusCode,int expStatusCode)
	    {
	    	APP_LOGS.debug("Validate API Response code "+expStatusCode);
	     
	    		if (ActualStatusCode==expStatusCode)
	    		{
	    			APIStatus=Constants.KEYWORD_PASS;
	    		    ApiDescription="Valid Response Code: "+ActualStatusCode;
	    		}
	    	else
	   		 {     		
	   			APIStatus=Constants.KEYWORD_FAIL;
	   			System.out.println("Response Status "+ActualStatusCode);
	   			ApiDescription="Invalid Response status:"+ActualStatusCode;
	   		 }
	
	    }
	    
		/***************************************************************************************
		 *  Function name 		: VerifyExpectedValues
		 *  Reuse Function 		: 
		 *  Description 		: Split the GetOutputKey and Expected values using delimiter |. 
		/****************************************************************************************/         
	    public void VerifyExpectedValues( Xls_Reader current_TestCase_xls,int rowNum,String url,String OpKey, String Expected) 
	    {
	    	APP_LOGS.debug("Validate API Response keyvalue  "+OpKey+Expected);
	    	boolean SetValue3,SetValue4;
	       	String joined = null;
	       	if (Expected.length() > 0 )
	       	{
		    	String[] GetOutputKey = OpKey.split("\\|");
		    	String[] Actual = Expected.split("\\|");
		    	String[] descrition = new String[GetOutputKey.length];
		    	String Status=null;
		    	
		    	boolean TestFlag=true; 	
		    	boolean[] result = new boolean[GetOutputKey.length];
				for(int i=0;i<GetOutputKey.length;i++)
				{	
				 	result[i]= ExpectedValueValidation(url, GetOutputKey[i], Actual[i]);
					if (result[i] == true)
						descrition[i]= "Validation match " + GetOutputKey[i]+":" +Actual[i];				
					else{
						TestFlag=false;
						descrition[i]= "Validation not match " + GetOutputKey[i]+":" +Actual[i];
						}
				  } 			
					joined = String.join("|", descrition);			
					if (TestFlag==true)
					 Status =Constants.KEYWORD_PASS; 
					else
					 {Status=Constants.KEYWORD_FAIL;}
					
					 SetValue3=current_TestCase_xls.setCellData(Constants.TEST_STEPS_SHEET, Constants.ResponseDescription, rowNum, joined);
					 SetValue4=current_TestCase_xls.setCellData(Constants.TEST_STEPS_SHEET, Constants.RESULT, rowNum, Status);
					 System.out.println(" Result:"+SetValue3+SetValue4);
	      	}
			}
	    
	    /*************************************************************************************************
		 *  Function name 		: GetReferenceValue
		 *  Reuse Function 		: 
		 *  Description 		: Get the reference value from the URL column  
		/**************************************************************************************************/   
		public static Map<String, String> GetReferenceValue(JSONObject jsTestReportData, String XString)
	    {
			APP_LOGS.debug("Get reference value  "+XString);
			Map<String, String> Refencemap = new HashMap<String,String>();
	    	String OpValue=null;
	    	String ReTurnString=XString;
	    	String TCID = null,sRefDataSetID=null,TcColm;
	    	String Description=null;
	    	Refencemap.put("ReferenceValue", ReTurnString);
	    	Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
			Refencemap.put("ApiDescription", Description);  
	    	while (ReTurnString.contains(Constants.KEYWORD_REF))
			{
		    	int strlen=XString.length();
		    	if ((XString.contains("{"))&(XString.contains("}")))
		        {
		    		String Url1 = XString.substring(0,XString.indexOf("{"));
		    		String RefString = XString.substring(XString.indexOf("{")+1, XString.indexOf("}"));
		    		//System.out.println("Ref String : "+RefString);
		    		String[] ArTcCol = RefString.split(Constants.DATA_SPLIT);
		    		String RefTCid=ArTcCol[0];
		    		//System.out.println(RefTCid);
		    		String[] A1tTCs=RefTCid.split(Constants.KEYWORD_REF);
		    		if (A1tTCs[1].contains(Constants.DATASET_SPLIT)){
		    			String[] SplitDataset=A1tTCs[1].split(Constants.DATASET_SPLIT);
		    			TCID=SplitDataset[0];
		    			sRefDataSetID=SplitDataset[1];
		    		}
		    		else{
		    			TCID=A1tTCs[1];
		    		}
		    		TcColm=ArTcCol[1];
		    		String Urllast = XString.substring(XString.indexOf("}")+1,strlen);
		    		
		    		//System.out.println("Req Ref Value  : "+TCID+"-"+sRefDataSetID+" : "+TcColm);
		    		OpValue=GetOutputKeyValue(jsTestReportData,TCID,sRefDataSetID,TcColm);
		    		System.out.println("Ref Value  : "+TCID+"-"+sRefDataSetID+" : "+TcColm+" :"+OpValue);
		    		if ((OpValue!=null)&&(OpValue.length()>0)){
        				ReTurnString=Url1+OpValue+Urllast;
        				Refencemap.put("ReferenceValue", ReTurnString);
        				Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
        				Refencemap.put("ApiDescription", Description);  
        				return Refencemap;
        			}
		        	if(OpValue==null){
			    		ReTurnString=Url1+"Ref not Found"+Urllast;
			    		Description="Skipped due to failed status of dependent Test case  : " +TCID;
			    		Refencemap.put("ReferenceValue", ReTurnString);
        				Refencemap.put("APIStatus", Constants.KEYWORD_SKIP);
        				Refencemap.put("ApiDescription", Description); 
			    	}
		          }
			}
	    	return Refencemap;
	    }

	/*************************************************************************************************
	 *  Function name 		: StoreRespose
	 *  Reuse Function 		: 
	 *  Description 		: Store the Web services Response to local src/res/Response path
	/**************************************************************************************************/
	
    public String StoreRespose(Xls_Reader current_TestCase_xls,String Filename, String FileType,String Value,int rowNum)throws FileNotFoundException
    {
    	APP_LOGS.debug("Store Response "+Filename);
    	String RespPath=null;
    	File file = new File(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Response/"+Filename+"."+FileType);
		try (FileOutputStream fop = new FileOutputStream(file)) 
		{
			// if file doesn't exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			// get the content in bytes
			byte[] contentInBytes = Value.getBytes();
			fop.write(contentInBytes);
			fop.flush();
			fop.close();
			URL myUrl = file.toURI().toURL();
			RespPath=file.getAbsolutePath();
			System.out.println("Response stored Path : "+RespPath);	
			current_TestCase_xls.setCellData(Constants.TEST_STEPS_SHEET, Constants.Response, rowNum,myUrl.toString());
			return RespPath;
			
		}
     catch (IOException e) {e.printStackTrace();}
		return RespPath;
    }
    
    

	/*************************************************************************************************
	 *  Function name 		: StoreRespose
	 *  Reuse Function 		: 
	 *  Description 		: Store the Web services Response to local src/res/Response path
	/**************************************************************************************************/
	
    public String StoreRespose(String Filename, String FileType,String Value)throws FileNotFoundException
    {
    	APP_LOGS.debug("Store Response "+Filename);
    	String RespPath=null;
    	File file = new File(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Response/"+Filename+"."+FileType);
		try (FileOutputStream fop = new FileOutputStream(file)) 
		{
			// if file doesn't exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			// get the content in bytes
			byte[] contentInBytes = Value.getBytes();
			fop.write(contentInBytes);
			fop.flush();
			fop.close();
			//URL myUrl = file.toURI().toURL();
			RespPath=file.getAbsolutePath();
			System.out.println("Response stored Path : "+RespPath);	
			///current_TestCase_xls.setCellData(Constants.TEST_STEPS_SHEET, Constants.Response, rowNum,myUrl.toString());
			return RespPath;
			
		}
     catch (IOException e) {e.printStackTrace();}
		return RespPath;
    }
    
	/*************************************************************************************************
	 *  Function name 		: GetValuefromXMLStream
	 *  Reuse Function 		: 
	 *  Description 		: Read the XML response and get field value 
	/**************************************************************************************************/    
    public static String GetValuefromXMLStream(String FileName,String FileType,String Key)
    {
    	APP_LOGS.debug("Get value from XML Stream "+Key);
    	String ReString;
    	ReString=null;
    	ReString="Not Found"; 
    	      try {				
		    	  	System.out.println("XML Value for : "+FileName+" : " +FileType);	
				  	File fXmlFile = new File(System.getProperty("user.dir")+"/src/res/Response/"+FileName+"."+FileType);
				  	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				  	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();				 
				  	Document doc = dBuilder.parse(fXmlFile);
				  	doc.getDocumentElement().normalize();  				  						  	
				  	String roolElement=doc.getDocumentElement().getNodeName().toString();			  
				  	
				    NodeList nList = doc.getElementsByTagName(roolElement);			  					  					  	
				  	for (int temp = 0; temp < nList.getLength(); temp++)
				  	{				
				  		Node nNode = nList.item(temp);	
				  		
				  		if (nNode.getNodeType() == Node.ELEMENT_NODE) {				
				  			Element eElement = (Element) nNode;	
				  			ReString=eElement.getElementsByTagName(Key.trim()).item(0).getTextContent();			  						  						
				  			}
				  	}
				  } 
		      catch (Exception e) {e.printStackTrace();}
    	      return ReString;
     }


	/*************************************************************************************************
	 *  Function name 		: GetHttpRespString
	 *  Reuse Function 		: 
	 *  Description 		: Get Body string from HttpResponse
	/**************************************************************************************************/ 
	
	public static String GetHttpRespString(HttpResponse respString) 
	{
		APP_LOGS.debug("Get API Response string ");
		String responseString=null;
		try{
	        HttpEntity entity = respString.getEntity();
	        responseString = EntityUtils.toString(entity, "UTF-8");
	        //System.out.println("Response Stringsss :"+responseString);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return responseString;
		}
		return responseString;
	}
	
	/*************************************************************************************************
	 *  Function name 		: GetRespString
	 *  Reuse Function 		: 
	 *  Description 		: Get Body string from Response
	/**************************************************************************************************/ 
	public String GetRespString(Response respString) 
	{
		APP_LOGS.debug("Get API Response string ");
		String responseString=null;
		try{
	       
	        responseString = respString.asString();
	        //System.out.println("Response Stringsss :"+responseString);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return responseString;
		}
		return responseString;
	}
	
	/*************************************************************************************************
	 *  Function name 		: GetJsonKeyValue
	 *  Reuse Function 		: 
	 *  Description 		: Get value for key from Response string
	/**************************************************************************************************/ 
	public static String GetJsonKeyValue(String JsonSSString,String Key)
    {   	
		APP_LOGS.debug("Get JSON Key Value "+Key);
    	String ReString;
    	ReString=null;
    	ReString="Not Found";
	    try 
	      {
	    	JsonPath jsonResponse = new JsonPath(JsonSSString);
	    	ReString= jsonResponse.getString(Key);			 
	      } 
	    catch (Exception e) 
	      {
	    	e.printStackTrace();
	       }        	      
     	return ReString;
      } 
	
	/*************************************************************************************************
	 *  Function name 		: GetJsonKeyValue
	 *  Reuse Function 		: 
	 *  Description 		: Get value for key from Response string
	/**************************************************************************************************/ 
	public static String GetOutputKeyValue(JSONObject JsonData,String Key1,String Key2,String opkey)
    {   	
		APP_LOGS.debug("Get JSON Key Value "+Key1+Key2);
    	String ReString;
    	ReString=null;
	    try {
	    	JsonPath jsonResponse2 = new JsonPath(JsonData.toString());
//			Key1="COB-344";
//			Key2 ="DS1";
    		String Query1="Tests.find{Tests->Tests.Issue_key==datefilter1}.Datasets.findAll{ Datasets -> Datasets.DatasetID == datefilter2 && Datasets.TestResultStatus==datefilter3}";
			List<Map> lstJsonValue = jsonResponse2.param("datefilter1", Key1).param("datefilter2", Key2).param("datefilter3", Constants.KEYWORD_PASS).get(Query1);
			if(lstJsonValue!=null)
			{
			 for (Map<String , Object> map :lstJsonValue){
				 ReString=map.get(opkey).toString();
				 return ReString;
			 }
			}
	      } 
	    catch (Exception e) 
	      {
	    	e.printStackTrace();
	       }        	      
     	return ReString;
      } 
	
	/*************************************************************************************************
	 *  Function name 		: deletfile
	 *  Reuse Function 		: 
	 *  Description 		: Delete file from location
	/**************************************************************************************************/
	public static void deletfile(String FilePath)
	{
		APP_LOGS.debug("Delete File "+FilePath);
		try {
			
			File files= new File(FilePath);
			if (files.exists())
			{
				files.delete();
				//System.out.println("File "+files.getName()+" deleted: "+bool);
			}
		} catch (Exception x) {
		    // File permission problems are caught here.
		    System.out.println("Err Catch in deletfile"+x);
		}
	}
	
	/*************************************************************************************************
	 *  Function name 		: getDynamicvalue
	 *  Reuse Function 		: 
	 *  Description 		: Generate random value
	/**************************************************************************************************/
	 public String getDynamicvalue(String RandomValue)
	 {
		 String RetnResult;
		 if (RandomValue.contains(Constants.KEYWORD_RANDOM))
		 {
		       String[] ArKeys = RandomValue.split(Constants.KEYWORD_RANDOM);
		        int NofValue = Integer.parseInt(ArKeys[1]);
				SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMddHHmmss");//dd/MM/yyyy
				Date now = new Date();
				String strDate = sdfDate.format(now);
				strDate="000000"+strDate;
			    //System.out.println("Randam Full Value : "+strDate);//00000020160627172129
			    String GeneratedRmValue=StringUtils.right(strDate, NofValue);
				//System.out.println("Randam Value : "+GeneratedRmValue);
				RetnResult=ArKeys[0]+GeneratedRmValue;
		 }
		 else
		 {
			 RetnResult=RandomValue;
		 }
		 return RetnResult;
	 }

	/*************************************************************************************************
	 *  Function name 		: StoreReponseToExternal
	 *  Reuse Function 		: 
	 *  Description 		: Store the response string to local path
	/**************************************************************************************************/ 
	 public void StoreReponseToExternal(String Filename,String Value)throws FileNotFoundException
	    {
		 APP_LOGS.debug("Store response to External "+Filename);
		 	String TempPath=null;
		 	Boolean result;
		 	File folder = new File(TempPath);
	        //ResponseBuilder response = Response.ok((Object) file);
		 	if (!folder.exists()) {
		 		 try{
		 			folder.getParentFile().mkdirs();
		 			//folder.mkdir();
		 	        result = true;
		 	    } 
		 	    catch(SecurityException se){
		 	        //handle it
		 	    }
		 	}
		 	if (result=true)
		 	{
		    	File file = new File(TempPath);
				try (FileOutputStream fop = new FileOutputStream(file)) 
				{
					// if file doesn't exists, then create it
					file.getParentFile().mkdirs();
					if (!file.exists()) {
						file.createNewFile();
					}
					// get the content in bytes
					byte[] contentInBytes = Value.getBytes();
					fop.write(contentInBytes);
					fop.flush();
					fop.close();
				}
		     catch (IOException e) {e.printStackTrace();}
	    }
	    }


	}
	
    
	
