package com.verizon.util;



import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


import com.github.fge.jsonschema.core.exceptions.ProcessingException;

import org.json.JSONArray;
import org.json.JSONObject;


import static com.verizon.DriverScript.*;

import com.verizon.DriverScript;
import com.verizon.controllers.JiraService;
import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.util.Constants;

public class WorkerTestSet implements Runnable

{
	public static JiraService jiraService;
  	String ThreadExecType=null;
	JiraClient jira = null;
	JSONObject jsonTestSet=null;
	public Map<String,String> APIResult= new HashMap<String,String>();;
  	public WorkerTestSet() throws IOException, JiraException
  	{
  		APP_LOGS.debug("Initialize App Constructor");
  		jiraService = new JiraService();
  	}
	public WorkerTestSet(JiraClient jira, JSONObject jsTestSet, String ThreadExecType)
	{
		//Initialize values
		this.jira=jira;
		this.jsonTestSet= jsTestSet;
		this.ThreadExecType=ThreadExecType;
	}
	
	 /**************************************************************************
     *  Function name 		: run
     *  Reuse Function 		:
     *  Description 		: Execute non dependent test cases
     /**********************************************************************/
	public void run()
	{
		APP_LOGS.debug("Run Method :");
		System.out.println(Thread.currentThread().getName()+" (Start) App3 "+ThreadExecType+" :"+jsonTestSet);
		 try {
			 TestExecution(jira,jsonTestSet);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JiraException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName()+" (End) App3 "+ThreadExecType+" :"+jsonTestSet);//prints thread name
	}
	
	
	/*************************************************************************************************
	 *  Function name 		: TestExecution
	 *  Reuse Function 		: 
	 *  Description 		: Read the JSON Test set values.Based on the inputs flow the functionality. 
	/
	 * @throws ProcessingException 
	 * @throws JiraException **************************************************************************************************/  
    public JSONObject TestExecution(JiraClient jira,JSONObject Testset) throws ProcessingException, IOException, JiraException
    {
    	String APIURL,APIServer,Url,MethodType,ParamKey,ParamValues,ExpectedKeys,ExpectedValues,OpKey,SwitchingMode,ExpectedStatusCode,ExpectedSchemaPath,TestCaseID = null,DataSetID;
        String Details,HeaderKey,HeaderValues,refvalue;
        String DataRunMode;
        int iCount=0;
		int SumRespTime=0;
		String OverallStatus = null;
		String sTestResponseDes = null;
        int AvgRespTime=0;
    	String ExecuteType=CONFIG.getProperty("DataSetExecutionType");//Parallel//Sequential
        ExecutorService executor = null;
        Map<String,String> APIResult=null;
		int iThread=Integer.parseInt(CONFIG.getProperty("ThreadCount"));
		executor = Executors.newFixedThreadPool(iThread);
		try{
    	//JSONObject Testset = Testsets.getJSONObject(iTestIter);
		//TCID = Testset.get(Constants.TCID).toString();
        TestCaseID = Testset.get(Constants.TCID).toString();
        sTestResponseDes="DataSetID"+JIRAConstants.ValueDelimiter+"TestStatus"+JIRAConstants.ValueDelimiter+"ResponseDescription"+JIRAConstants.ValueDelimiter+"	ResponseTime"+JIRAConstants.ValueDelimiter+"OutValues";
    	OverallStatus=Constants.KEYWORD_PASS;
             APIServer = Testset.get(Constants.SERVER).toString();
             Url = Testset.get(Constants.URL).toString();
             MethodType = Testset.get(Constants.MethodType).toString();
             Details = Testset.get(Constants.Details).toString();
             ExpectedSchemaPath = Testset.get(Constants.ExpectedSchema).toString();;
             SwitchingMode = Testset.get(Constants.SwitchingMode).toString();
             JSONArray DataSets1 = (JSONArray) Testset.get("Datasets");
             for (int iDataItr = 0; iDataItr < DataSets1.length(); iDataItr++) {
				JSONObject DataSet = DataSets1.getJSONObject(iDataItr);
				//System.out.println(DataSet.get("DatasetID"));
				DataSetID = DataSet.get(Constants.DATASET).toString();
				DataRunMode= DataSet.get(JIRAConstants.DATAFLAG).toString();
				if (DataRunMode.equalsIgnoreCase("YES")){
					refvalue=DataSet.get(JIRAConstants.REFURLValue).toString();
					APIURL=Url+refvalue;
	                HeaderKey = DataSet.get(Constants.Header_Keys).toString();
	                HeaderValues = DataSet.get(Constants.Header_Values).toString();
	                ParamKey = DataSet.get(Constants.Param_Keys).toString();
	                ParamValues = DataSet.get(Constants.Param_Values).toString();
	                OpKey = DataSet.get(Constants.GetOutputKey).toString();
	                ExpectedKeys = DataSet.get(Constants.Expected_Keys).toString();
	                ExpectedValues = DataSet.get(Constants.Expected_Values).toString();
	                ExpectedStatusCode = DataSet.get(Constants.ExpectedStatusCode).toString();
	                if (ExecuteType.contains("Parallel")) {
						// Execute Concurrent in Thread
						Runnable worker = new App(DriverScript.jsonTestReportData,TestCaseID,DataSetID,Details,APIServer,APIURL, MethodType, HeaderKey,HeaderValues,ParamKey, ParamValues,OpKey, SwitchingMode, ExpectedKeys, ExpectedValues, ExpectedStatusCode, ExpectedSchemaPath,"DataSet");
						executor.execute(worker);// calling execute
					}
					else{
						APIResult=API.APICall(DriverScript.jsonTestReportData,TestCaseID,DataSetID,Details,APIServer,APIURL, MethodType, HeaderKey,HeaderValues,ParamKey, ParamValues,OpKey, SwitchingMode, ExpectedKeys, ExpectedValues, ExpectedStatusCode, ExpectedSchemaPath);
						iCount=iCount+1;
		                System.out.println(TestCaseID+"-"+DataSetID+":"+APIResult.get("APIStatus"));
		                DataSet.put("HeaderKeyValue", APIResult.get("HeaderKeyValue"));
		                DataSet.put("Input_KeyValues", APIResult.get("InputValues"));
		                DataSet.put("Expected", APIResult.get("GivenExpectedValues"));
		                DataSet.put("APIURL", APIResult.get("APIURL"));
		                if (APIResult.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_FAIL)){
							 OverallStatus=Constants.KEYWORD_FAIL;
						 }
		                sTestResponseDes=sTestResponseDes+"\n"+DataSetID+JIRAConstants.ValueDelimiter+APIResult.get("APIStatus")+JIRAConstants.ValueDelimiter+APIResult.get("ApiDescription")+JIRAConstants.ValueDelimiter+APIResult.get("responseTime")+JIRAConstants.ValueDelimiter+APIResult.get("Output_Values")+"\n";
		            	if(APIResult.get("responseTime")!=null)
							 SumRespTime = SumRespTime+Integer.parseInt(APIResult.get("responseTime").replaceAll("\\D+",""));
		                DataSet.put("TestResultStatus", APIResult.get("APIStatus"));
		                DataSet.put("ResponseDescription", APIResult.get("ApiDescription"));
		                DataSet.put("ResponseTime", APIResult.get("responseTime")+" ms");
		                DataSet.put("Output_Values", APIResult.get("Output_Values"));
		                DataSet.put("Response", APIResult.get("resString"));
		                DataSet.put("ResponseFilePath", APIResult.get("ResponseFilePath"));
					}
				}
            }
            if (ExecuteType.contains("Parallel")) {
 	 			executor.shutdown();
 	 			// Wait Till all thread complete
 	 			while (!executor.isTerminated()) {
 	 			}
 	 			
 	 			System.out.println("DataSet Finished all threads");
 	 			for (int k = 0; k < DataSets1.length(); k++) {
 	 				JSONObject DataSet = DataSets1.getJSONObject(k);
 	 				//System.out.println(DataSet.get("DatasetID"));
 	 				iCount=iCount+1;
 	 				DataSetID = DataSet.get(Constants.DATASET).toString();
 	 				for (Map<String, String> mapDataSet : App.lstDataSetresult) {
 	 					//Report in Testdata sheet
 	 					if ((TestCaseID.equalsIgnoreCase(mapDataSet.get("TestCaseID")))&&(DataSetID.equalsIgnoreCase(mapDataSet.get("DataSetID"))))
 	 					{
 	 						
 	 						//System.out.println("Dataset"+TestCaseID+"-"+DataSetID+":"+mapDataSet.get("APIStatus"));
 	 						DataSet.put("HeaderKeyValue", mapDataSet.get("HeaderKeyValue"));
 	 						DataSet.put("Input_KeyValues", mapDataSet.get("InputValues"));
 	 						DataSet.put("Expected", mapDataSet.get("GivenExpectedValues"));
 	 						DataSet.put("APIURL", mapDataSet.get("APIURL"));
 	 						if (mapDataSet.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_FAIL)){
 	 							OverallStatus=Constants.KEYWORD_FAIL;
 	 						}
 	 						sTestResponseDes=sTestResponseDes+"\n"+DataSetID+JIRAConstants.ValueDelimiter+mapDataSet.get("APIStatus")+JIRAConstants.ValueDelimiter+mapDataSet.get("ApiDescription")+JIRAConstants.ValueDelimiter+mapDataSet.get("responseTime")+JIRAConstants.ValueDelimiter+mapDataSet.get("Output_Values")+"\n";
 	 						if(mapDataSet.get("responseTime")!=null)
 	 							SumRespTime = SumRespTime+Integer.parseInt(mapDataSet.get("responseTime").replaceAll("\\D+",""));
 	 						DataSet.put("TestResultStatus", mapDataSet.get("APIStatus"));
 	 						DataSet.put("ResponseDescription", mapDataSet.get("ApiDescription"));
 	 						DataSet.put("ResponseTime", mapDataSet.get("responseTime")+" ms");
 	 						DataSet.put("Output_Values", mapDataSet.get("Output_Values"));
 	 						DataSet.put("Response", mapDataSet.get("resString"));
 	 						DataSet.put("ResponseFilePath", mapDataSet.get("ResponseFilePath"));
 	 						
 	 						//System.out.println("Data Binding :"+sTestResponseDes);
 	 					}
 	 				}
 	 			}
    	}
        Testset.put("TestStatus", OverallStatus);
        if (iCount>0)
    		AvgRespTime=SumRespTime/iCount;
        Testset.put("AvgResponseTime", String.valueOf(AvgRespTime)+" ms");
	 	if (CONFIG.getProperty("InputType").equalsIgnoreCase("Jira")) {
	 		//System.out.println("DataSet :"+TestCaseID+sTestResponseDes);
       		 jiraService.JiraUpdateIssueKey(jira,TestCaseID,OverallStatus,String.valueOf(AvgRespTime)+" ms", sTestResponseDes);
        }
	 	
	 	DriverScript.jsonTestReportData.append("Tests", Testset);
    	
	}
	catch(Exception e){
	    e.printStackTrace();
	}
	return DriverScript.jsonTestReportData;
   }
	
	
	}
	
    
	
