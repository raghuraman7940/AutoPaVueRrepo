package com.verizon.util;


import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static io.restassured.matcher.RestAssuredMatchers.matchesXsd;
import static io.restassured.matcher.RestAssuredMatchers.matchesDtd;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.ProxySpecification;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import static com.verizon.DriverScript.*;

import com.verizon.config.JiraProperties;
import com.verizon.controllers.JiraService;
import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.util.Constants;
import com.verizon.util.Xls_Reader;

public class Xls_App implements Runnable

{
  	public static String ApiDescription = "";
  	public static String APIStatus="";
	public static String ResponseFilePath;
	public static String ContentType;
	public static long responseTime=0;
	public static String responseTimeinMs;
	public static String OutValues;
	public static Response res = null;
	public static List<Map<String , String>> result  = new ArrayList<Map<String,String>>();
	static SchemaValidation vjson;
	static CloseableHttpClient httpclient;
	static HttpClientContext context;
  	static Xls_Reader current_TestCase_xls=null;
  	static Xls_Reader XlsxSuite_xls=null;
  	JiraService jiraService;
  	static ProxySpecification proxySpecification;
  	int ExpStatusid;
	int rowNum;
	boolean bExpected;
	String APIURL,HeaderKey,HeaderValues,ParamKey,ParamValues,methodType,APIServer,Url,Details,HeaderKeyValue,InputValues,GivenExpectedValues;
	String XLSheetname_TestResults;
	String resString=null;
	String OpKey,XlsxInputFile,XLInputSheetName,SwitchingMode,ExpectedSchemaPath,ExpectedKeys,ExpectedValues,TestCaseID,DataSetID;

  	public Xls_App() throws IOException, JiraException
  	{
  		jiraService = new JiraService();
  		APP_LOGS.debug("Initialize App Constructor");
  	 	//Create instance
  		vjson=new SchemaValidation();
  		//Proxy host details
	    HttpHost proxy = new HttpHost(CONFIG.getProperty("PROXY_HOST"),Integer.parseInt((CONFIG.getProperty("PROXY_PORT"))));
	    DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
	    CredentialsProvider credsProvider = new BasicCredentialsProvider();
	    credsProvider.setCredentials(
	    		new AuthScope(CONFIG.getProperty("PROXY_HOST"), Integer.parseInt((CONFIG.getProperty("PROXY_PORT"))), AuthScope.ANY_HOST, "ntlm"), 
	    		new NTCredentials(CONFIG.getProperty("PROXY_USERNAME"), CONFIG.getProperty("PROXY_PASSWORD"), "", CONFIG.getProperty("PROXY_DOMAIN")));
	    context = HttpClientContext.create();
	    //Target host details
	    HttpHost targetHost = new HttpHost(CONFIG.getProperty("TARGET_HOST"), Integer.parseInt((CONFIG.getProperty("TARGET_PORT"))), CONFIG.getProperty("TARGET_TYPE"));
	    credsProvider.setCredentials(
	            new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT),
	            new UsernamePasswordCredentials(CONFIG.getProperty("TARGET_USERNAME"), CONFIG.getProperty("TARGET_PASSWORD")));
	    
	    // Create AuthCache instance
	    AuthCache authCache = new BasicAuthCache();
	    // Generate BASIC scheme object and add it to the local auth cache
	    BasicScheme basicAuth = new BasicScheme();
	    authCache.put(targetHost, basicAuth);
	    context.setCredentialsProvider(credsProvider);
	    context.setAuthCache(authCache);    
	    httpclient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).setRoutePlanner(routePlanner).build();
	    
	    //Proxy Specification
	    proxySpecification=new ProxySpecification(CONFIG.getProperty("PROXY_HOST"),Integer.parseInt((CONFIG.getProperty("PROXY_PORT"))),CONFIG.getProperty("PROXY_TYPE")).withAuth(CONFIG.getProperty("PROXY_USERNAME"), CONFIG.getProperty("PROXY_PASSWORD"));
	    
  	}
	public Xls_App(int rowNum,String methodType,int ExpStatusid, String OpKey, String ExpectedSchemaPath, String ExpectedKeys,String ExpectedValues,String XlsxInputFile,String XLInputSheetName,String APIServer,String Url,String Details,String HeaderKeyValue,String InputValues,String GivenExpectedValues,String XLSheetname_TestResults,String SwitchingMode,String APIURL,String HeaderKey,String HeaderValues,String ParamKey,String ParamValues,Xls_Reader current_TestCase_xls,String TestCaseID, String DataSetID)
	{
		//Initialize values
		this.rowNum = rowNum;
		this.methodType = methodType;
		this.APIURL = APIURL;
		this.HeaderKey = HeaderKey;
		this.HeaderValues=HeaderValues;
		this.ParamKey = ParamKey;
		this.ParamValues = ParamValues;
		this.ExpStatusid = ExpStatusid;
		this.OpKey = OpKey;
		this.XLInputSheetName = XLInputSheetName;
		this.XlsxInputFile = XlsxInputFile;
		this.ExpectedSchemaPath = ExpectedSchemaPath;
		this.ExpectedKeys = ExpectedKeys;
		this.ExpectedValues = ExpectedValues;
		this.APIServer = APIServer;
		this.Url = Url;
		this.Details = Details;
		this.HeaderKeyValue=HeaderKeyValue;
		this.InputValues=InputValues;
		this.GivenExpectedValues=GivenExpectedValues;
		this.SwitchingMode= SwitchingMode;
		this.XLSheetname_TestResults=XLSheetname_TestResults;
		this.TestCaseID= TestCaseID;
		this.DataSetID=DataSetID;
	}
	
	 /**************************************************************************
     *  Function name 		: run
     *  Reuse Function 		:
     *  Description 		: Execute non dependent test cases
     /**********************************************************************/
	public void run()
	{
		APP_LOGS.debug("Run Method :");
		System.out.println(Thread.currentThread().getName()+" (Start) message = "+ rowNum);
		try {
			apiCall();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        String resString=GetRespString(res);
		

		System.out.println(Thread.currentThread().getName()+" (End)");//prints thread name
	}
	
    /**************************************************************************
     *  Function name 		: apiCall
     *  Reuse Function 		:
     *  Description 		: Execute API Call
     /
     * @throws FileNotFoundException **********************************************************************/
	public void apiCall() throws FileNotFoundException
	{
		APP_LOGS.debug("API call");
		switch(methodType)
		{
			case "GET":
				res=Get_Method(APIURL,HeaderKey,HeaderValues);
				break;
			case "POST":
				res=Post_Method(APIURL,HeaderKey,HeaderValues,ParamKey,ParamValues);
				break;
			case "PUT":
				res=Put_Method(APIURL,HeaderKey,HeaderValues,ParamKey,ParamValues);
				break;
			case "DELETE":
				res=Delete_Method(APIURL,HeaderKey,HeaderValues,ParamKey,ParamValues);
				break;
		}
        ContentType = GetResponseContentType(res);
        ResponseFilePath = StoreRespose(current_TestCase_xls, TestCaseID+"_"+DataSetID, ContentType, res.asString(), rowNum);
		if(VerifyResponseStatus(TestCaseID, res, ExpStatusid)) {
			responseTimeinMs = GetResponseTimeinMS(res);
            OutValues = GetOutkeyValueFromResponse(res, OpKey);
            ImplSwitchingMode(XlsxInputFile, XLInputSheetName, res, SwitchingMode);
            //Validate Schema and expected values
            try {
                ValidataSchema(res, ExpectedSchemaPath, ResponseFilePath);
            } catch (Exception e) {
                System.out.println("Error occured while doing schema validation" + e.getMessage());
            }
            bExpected = ResponseExpectedValidation(TestCaseID, res, ExpectedKeys, ExpectedValues);
        }
		//Store response in a map
		Map<String,String> testCaseResult = new HashMap<String,String>();
		testCaseResult.put("TestCaseID",TestCaseID);
		testCaseResult.put("DataSetID",DataSetID);
		testCaseResult.put("ContentType",ContentType);
		testCaseResult.put("resString",resString);
		testCaseResult.put("rowNum",String.valueOf(rowNum));
		testCaseResult.put("APIStatus",APIStatus);
		testCaseResult.put("ApiDescription",ApiDescription);
		testCaseResult.put("Output_Values",OutValues);
		testCaseResult.put("responseTime",responseTimeinMs);
		testCaseResult.put("methodType",methodType);
		testCaseResult.put("APIServer",APIServer);
		testCaseResult.put("Url",Url);
		testCaseResult.put("Details",Details);
		testCaseResult.put("HeaderKeyValue",HeaderKeyValue);
		testCaseResult.put("InputValues",InputValues);
		testCaseResult.put("GivenExpectedValues",GivenExpectedValues);
		testCaseResult.put("ResponseFilePath",ResponseFilePath);
		
		try {
			result.add(testCaseResult);
		}
		catch (Exception e)
		{
			System.out.println("Exception in storing list in a map" + e.getMessage());
		}
	}
    /***************************************************************************************
  	 *  Function name 		: JIRAExport
  	 *  Reuse Function 		:  
  	 *  Description 		: JIRA Issues export to CSV
  	/****************************************************************************************/ 
     public void JIRAExport(JiraClient jira, String jql, JiraProperties properties)
     {
    	 int JiraStatusCode=0;
    	 if (CONFIG.getProperty("InputType").equalsIgnoreCase("Jira"))
	     {
	    	 	APP_LOGS.debug("Clear Jira import/export csv files");
	    		//Delete Import and Export File
		    	deletfile(System.getProperty("user.dir")+CONFIG.getProperty("JIRAConfig.dependentExport"));
		    	deletfile(System.getProperty("user.dir")+CONFIG.getProperty("JIRAConfig.nonDependentExport"));
		    	deletfile(System.getProperty("user.dir")+CONFIG.getProperty("JIRAConfig.csvFileImport"));
		    	deletfile(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Xls/"+Constants.TEST_JIRAXLFILE);
		    	//Export CSV from JIRA
		    	jiraService.JiraExport(jira, jql, properties);
		    	JiraStatusCode=200;
		    	System.out.println("Executing Jira Issues :\n");
	     }
     }
 	
     /***************************************************************************************
   	 *  Function name 		: JIRAImport
   	 *  Reuse Function 		:  
   	 *  Description 		: JIRA Issues update from CSV
   	/****************************************************************************************/ 
     public void JIRAImport() throws JiraException
     {
    	if (CONFIG.getProperty("InputType").equalsIgnoreCase("Jira"))
     	{
    		APP_LOGS.debug("Jira import csv files");
		   //Updated JIRA with Status	
    		jiraService.JiraImport();
    		System.out.println("Updated test result in Jira :\n");
     	}
     }
    
    /***************************************************************************************
	 *  Function name 		: Get_Method
	 *  Reuse Function 		:  
	 *  Description 		: GET Method API WebServices
	/****************************************************************************************/         
    public HttpResponse HttpGet_Method(String apiurl,String HKeys, String HValues) throws ClientProtocolException, IOException
	{
    	APP_LOGS.debug("Execute GET Call :"+apiurl+HKeys+HValues);
		HttpResponse resp=null;
		try{
			 HttpGet httpget = new HttpGet(apiurl);
			 if ((HKeys.length()>0)&(HValues.length()>0))
			 {
		        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
		        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
		        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
		        {
		        	httpget.setHeader(ArKeys[i],ArValues[i]);
		        }
			}
	        resp = httpclient.execute(httpget, context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
	   	 	return resp;
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
	}
    
    /***************************************************************************************
	 *  Function name 		: Get_Method
	 *  Reuse Function 		:  
	 *  Description 		: GET Method API WebServices
	/****************************************************************************************/         
    public Response Get_Method(String apiurl,String HKeys, String HValues)
    {    
    	APP_LOGS.debug("Execute GET Call :"+apiurl+HKeys+HValues);
    	int StatusCode=0;
    	Response GetResp = null;
    	//System.out.println("Get call"+apiurl+HKeys+HValues);
    	try
    	{
    		Map<String, String> header = GetKeyValuePair(HKeys,HValues);
	    	GetResp=given()   
	    			//.relaxedHTTPSValidation()
	        .proxy(proxySpecification)
	        .headers(header)
			.get(apiurl);
	    	StatusCode=GetResp.getStatusCode();
	    	//VerifyResponseStatus(GetResp,200);
    	}
    	catch(Exception e)
    	{
    		return GetResp;
    	}
    	return GetResp;
   }
	/***************************************************************************************
	 *  Function name 		: Post_Method
	 *  Reuse Function 		:  
	 *  Description 		: Post Method API WebServices
	/****************************************************************************************/         
    public Response Post_Method(String apiurl,String HKeys, String HValues,String PKeys, String PValues){
    	APP_LOGS.debug("Execute POST Call :"+apiurl+HKeys+HValues+PKeys+PValues);
    	int StatusCode;
    	StatusCode=1;
    	Response PostResp = null;
    	try
    	{
    		Map<String, String> BodyParameter = GetKeyValuePair(PKeys,PValues);
    		Map<String, String> header = GetKeyValuePair(HKeys,HValues);
    		PostResp=given()   
	        .proxy(proxySpecification)		
	        .headers(header)
			.body(BodyParameter)
			.when()
			.post(apiurl);
	    	StatusCode=PostResp.getStatusCode();
    	}
      	catch(Exception e)
    	{
    		return PostResp;
    	}
      	return PostResp;
    	
   }
    
	/***************************************************************************************
	 *  Function name 		: Post_Method
	 *  Reuse Function 		: NA
	 *  Description 		: Post Method API WebServices using HttpPost
	/****************************************************************************************/         
    public HttpResponse HTTPPost_Method(String apiurl,String HKeys, String HValues,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
    	APP_LOGS.debug("Execute POST Call :"+apiurl+HKeys+HValues+PKeys+PValues);
		HttpResponse resp=null;
		try{
			HttpPost httppost = new HttpPost(apiurl);
			if ((HKeys.length()>0)&(HValues.length()>0))
			{
		        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
		        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
		        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
		        {
		        	httppost.setHeader(ArKeys[i],ArValues[i]);
		        }
			}
			ArrayList<NameValuePair> postParameters=GetNameValuePair(PKeys,PValues);
			httppost.setEntity(new UrlEncodedFormEntity(postParameters));
	        resp = httpclient.execute(httppost,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;
	}
	
	/***************************************************************************************
	 *  Function name 		: Delete_Method
	 *  Reuse Function 		: ReadExcel_Data
	 *  Description 		: Delete Method API WebServices  
	/****************************************************************************************/ 
    public Response Delete_Method(String apiurl,String HKeys, String HValues,String PKeys, String PValues){
    	APP_LOGS.debug("Execute DELETE Call :"+apiurl+HKeys+HValues+PKeys+PValues);
    	int StatusCode;
    	StatusCode=1;
    	Map<String, String> BodyParameter = GetKeyValuePair(PKeys,PValues);
    	Map<String, String> header = GetKeyValuePair(HKeys,HValues);
    	Response res=given()
    	.proxy(proxySpecification)	
    	.headers(header)
		.body(BodyParameter)
		.when()
		.delete(apiurl);
		 StatusCode=res.getStatusCode();
		 return res;
   }
	/***************************************************************************************
	 *  Function name 		: Put_Method
	 *  Reuse Function 		: 
	 *  Description 		: Update Method API WebServices 
	/****************************************************************************************/ 
    public Response Put_Method(String apiurl,String HKeys, String HValues,String PKeys, String PValues){
    	APP_LOGS.debug("Execute PUT Call :"+apiurl+HKeys+HValues+PKeys+PValues);
    	
    	int StatusCode;
    	StatusCode=1;
    	Map<String, String> BodyParameter = GetKeyValuePair(PKeys,PValues);
    	Map<String, String> header = GetKeyValuePair(HKeys,HValues);
    	Response res=given()
    	.proxy(proxySpecification)	
    	.headers(header)
		.body(BodyParameter)
		.when()
		.put(apiurl);
    	return res;
   }
    
    
	/***************************************************************************************
	 *  Function name 		: HttpPut_Method
	 *  Reuse Function 		: 
	 *  Description 		: Update Method API WebServices 
	/****************************************************************************************/ 
	public HttpResponse HttpPut_Method(String apiurl,String HKeys, String HValues,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
		APP_LOGS.debug("Execute PUT Call :"+apiurl+HKeys+HValues+PKeys+PValues);
		HttpResponse resp=null;
		try{
			 HttpPut httpput = new HttpPut(apiurl);
			 
				if ((HKeys.length()>0)&(HValues.length()>0))
				{
			        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	httpput.setHeader(ArKeys[i],ArValues[i]);
			        }
				}
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
					ArrayList<NameValuePair> postParameters= GetNameValuePair(PKeys,PValues); 
			        httpput.setEntity(new UrlEncodedFormEntity(postParameters));
				}
	        resp = httpclient.execute(httpput,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;

	}
	
	/***************************************************************************************
	 *  Function name 		: Delete_Method
	 *  Reuse Function 		: 
	 *  Description 		: delete Method API WebServices 
	/****************************************************************************************/ 
	public HttpResponse HttpDelete_Method(String apiurl,String HKeys, String HValues,String PKeys,String PValues) throws ClientProtocolException, IOException
	{
		APP_LOGS.debug("Execute DELETE Call :"+apiurl+HKeys+HValues+PKeys+PValues);
		HttpResponse resp=null;
		try{
			 HttpDelete httpdelete = new HttpDelete(apiurl);
				if ((HKeys.length()>0)&(HValues.length()>0))
				{
			        String[] ArKeys = HKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = HValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	httpdelete.setHeader(ArKeys[i],ArValues[i]);
			        }
				}
				
			 if ((PKeys.length()>0)&(PValues.length()>0))
			{
				 ArrayList<NameValuePair> postParameters= GetNameValuePair(PKeys,PValues); 
			     ((HttpResponse) httpdelete).setEntity(new UrlEncodedFormEntity(postParameters));
			}
	        resp = httpclient.execute(httpdelete,context);
	        int httpCode = resp.getStatusLine().getStatusCode();
	        VerifyResponseStatus(httpCode,200);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return resp;
		}
   	 return resp;

	}

	/***************************************************************************************
	 *  Function name 		: ImplSwitchingMode
	 *  Reuse Function 		:  GetOutkeyValueFromResponse
	 *  Description 		: Depends upon response switch which test need to be executed
	/****************************************************************************************/    
	  public void ImplSwitchingMode(String Filename, String Sheetname, Response res,String SwitchingMode) 
	  {
		  APP_LOGS.debug("Switching Mode :"+SwitchingMode);
		String switchValues=null;
		if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS)){
			Xls_Reader current_TestCase_xls1=null;
	        current_TestCase_xls1=new Xls_Reader(Filename);
	        if((SwitchingMode.length()>0)&&(!SwitchingMode.equalsIgnoreCase("null")))
			{
		  	String[] switching = SwitchingMode.split("\\|");					        										           
		  	if ((switching.length>0))
		  	{				
		  		switchValues=GetOutkeyValueFromResponse(res,switching[0]);
				for(int i=1;i<switching.length ;i++)
				{								    			
					String[] tc=switching[i].split(":");									    			
					if (switchValues.equalsIgnoreCase(tc[0]))
					{		
						int rownum2=current_TestCase_xls.getCellRowNum(Sheetname, Constants.TCID,tc[1]);
						current_TestCase_xls.setCellData(Sheetname,Constants.TESTRUNMODE, rownum2, "Yes");
					}	
				}
			}
	    }
		}
	  }
		
	/***************************************************************************************
	 *  Function name 		: GetOutkeyValueFromResponse
	 *  Reuse Function 		:  GetResponseContentType
	 *  Description 		: Get output key value from the response
	/****************************************************************************************/    
	public String GetOutkeyValueFromResponse(Response res,String Key) 
	{
		APP_LOGS.debug("Get Key Value from Response :"+Key);
	   	String repOutputKey=null;
	   	String repContentType=null;
	    	try
	   		 {  
	    		if ((Key.length()>0)&&(!Key.equalsIgnoreCase("null")))
	    		{
	    			repContentType=GetResponseContentType(res);
		    		if ((repContentType.contains("json"))|(repContentType.contains("JSON")))
		    		{
		    			repOutputKey=res.then().extract().jsonPath().getString(Key);
			    	
		    		}
		    		else if ((repContentType.contains("xml"))|(repContentType.contains("XML")))
		    		{
		    			repOutputKey=res.then().extract().xmlPath().getString(Key);
		    		}	
		    		else if ((repContentType.contains("html"))|(repContentType.contains("HTML")))
		    		{
		    			repOutputKey=res.then().extract().htmlPath().getString(Key);
		    		}
		    		
		    	   	if ((repOutputKey.contains("["))&(repOutputKey.contains("]")))
		            {
		    	   		repOutputKey=repOutputKey.replace("[", "");
		    	   		repOutputKey=repOutputKey.replace("]", "");
		            }
		    	
	    		}	
	    	}
	    	catch (AssertionError e)
	   		 {     		
	   			 System.out.println("Err Catch GetOutkeyValue :"+e.getMessage());
	   			 return repOutputKey;
	   		 }
	    	return repOutputKey;
	    	
	    }

	/*************************************************************************************************
	 *  Function name 		: GetJsonValueFromResponse
	 *  Reuse Function 		: 
	 *  Description 		:  Get the Value of  key from responsestring
	/**************************************************************************************************/
	 public String GetJsonValueFromResponse(String ResponseString,String Key)
	 {   	
		 APP_LOGS.debug("Get Key Value from Response :"+Key);
	    	String ReString;
	    	ReString=null;
	    	ReString="Not Found";
		    try 
		        {
		    	if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
		    	{
			    	JsonPath jsonResponse = new JsonPath(ResponseString);
				    ReString= jsonResponse.getString(Key);			 		 
					System.out.println("Json Values for output key "+Key+" is "+ReString);
		    	}
		    	else
		    	{
		    		ReString="";
		    	}
		        } 
		     catch (Exception e) 
		        {
		        	e.printStackTrace();
		        }        	      
	     	return ReString;
	      }    
	
	 
		/*************************************************************************************************
		 *  Function name 		: GetJsonValueFromResponse2
		 *  Reuse Function 		: 
		 *  Description 		: Get the Value of  key from external json file
		/**************************************************************************************************/
		 public String GetJsonValueFromResponse2(String FileName,String FileType,String Key)
		    {   	
			 APP_LOGS.debug("Get Key Value from Response File :"+Key);
		    	String ReString;
		    	ReString=null;
		    	ReString="Not Found";
			    File file = new File(System.getProperty("user.dir")+"/src/test/resources/Response/"+FileName+"."+FileType);
			    try 
			        {
			    	
			    	JsonPath jsonResponse = new JsonPath(new FileReader(file));
				    ReString= jsonResponse.getString(Key);			 		 
					System.out.println("Json Values for output key "+Key+" is "+ReString);

			        } 
			     catch (IOException e) 
			        {
			        	e.printStackTrace();
			        }        	      
		     	return ReString;
		      }    
		
		/**************************************************************************
		 *  Function name 		: ExpectedValueValidation
		 *  Reuse Function 		: 
		 *  Description 		: Get Method with validation
		 	/**********************************************************************/
	    public boolean ExpectedValueValidation(String apiurl,String Key,String ExpectedValue) 
	    {
	    	APP_LOGS.debug("Validate response code with expected:"+ExpectedValue);
	    		try
	    		 {    
	    			get(apiurl).then().assertThat().body(Key, equalTo(ExpectedValue));
	    			return true;
	    		 }
	    		 catch (AssertionError e)
	    		 {     			
	    			 return false;
	    		 }
	    }
	    
		/**************************************************************************
		 *  Function name 		: Rep_InputValues
		 *  Reuse Function 		: 
		 *  Description 		: Provide paired key values from  excel input key values    
		 	/**********************************************************************/    
	    public String Rep_InputValues(String PKeys,String PValues) 
		{
	    	APP_LOGS.debug("Get Input Values :"+PKeys+PValues);
			String RetnString="";
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
		
			        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
			
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	RetnString=RetnString+"\n "+ArKeys[i]+" : "+ArValues[i];
			        	
			        }
				}
				else
				{
					RetnString="NA";
				}
				return RetnString;
			}
	    
	    
    /**************************************************************************
	 *  Function name 		: GetKeyValuePair
	 *  Reuse Function 		: 
	 *  Description 		: Provide paired key values from  excel input key values    
	 /**********************************************************************/    
	    public ArrayList<NameValuePair> GetNameValuePair(String PKeys,String PValues) 
		{
			//Map<String, String>  mKeyValue=new HashMap<>();
	    	APP_LOGS.debug("Get Arraylist Input Value Pair:"+PKeys+PValues);
			ArrayList<NameValuePair> mKeyValue = null;

	        
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
					mKeyValue = new ArrayList<NameValuePair>();
			        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	mKeyValue.add(new BasicNameValuePair(ArKeys[i], ArValues[i]));
			        }
				
 
				}
				return mKeyValue;
			}
	    
	    
    /**************************************************************************
	 *  Function name 		: GetKeyValuePair
	 *  Reuse Function 		: 
	 *  Description 		: Provide paired key values from  excel input key values    
	 /**********************************************************************/    
	    public Map<String, String> GetKeyValuePair(String PKeys,String PValues) 
		{
	    	APP_LOGS.debug("Get Maplist of Key Value Pair :"+PKeys+PValues);
			Map<String, String>  mKeyValue=new HashMap<>();
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
			        
					//jsonAsMap = new HashMap<>();
			        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	mKeyValue.put(ArKeys[i], ArValues[i]);
			        	
			        }
 
				}
				return mKeyValue;
			}
	    
	    /**************************************************************************
		 *  Function name 		: ResponseExpectedValidation
		 *  Reuse Function 		: 
		 *  Description 		: Validate response with expected key value pair    
		 /**********************************************************************/    
	    public boolean ResponseExpectedValidation(Response res, String PKeys,String PValues)
	    {
	    	APP_LOGS.debug("Validation API Response with expected keyvalue :"+PKeys+PValues);
	    	 boolean Validation= false;
	    	 String ExpecKeytoFind=null;
	    	 String repKeyExist=null;
	    	 if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
	    	 {
		    	try
		   		 {  
		    		 if ((PKeys.length()>0)&(PValues.length()>0)&(!PKeys.equalsIgnoreCase("null"))&(!PKeys.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("null")))
					{
			    		
				        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
				        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
				        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
				        {
				        	ExpecKeytoFind=ArKeys[i];
				        
				        	//Check whether key is present
				        	repKeyExist=res.then().extract().path(ArKeys[i]);
				        	if(repKeyExist!=null)
				        	{	
						        res.then().assertThat().body(ArKeys[i], equalTo(ArValues[i]));
						    	Validation= true;
				        	}
				        	else
				        	{
				        		ApiDescription=ApiDescription+"\n  Key not found : "+ArKeys[i];
					   			APIStatus=Constants.KEYWORD_FAIL;
					   			System.out.println("Err Catch ResponseExpectedValidation :"+ApiDescription);
					   			return false;
				        	}
				        }
	
					}
			    	else
			    	{
			    		 Validation= true;
			    		 //ApiDescription=ApiDescription+"\n  Expected Values not provided";
			    		 return Validation;
			    	}
		   		 }
		   		 catch (AssertionError e)
		   		 {     		
		   			System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Mismatched Actual Values:"+e.getMessage();
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    	catch (ClassCastException e)
		   		 {     		
		    		System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Key not found  :"+ExpecKeytoFind;
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
			    APIStatus=Constants.KEYWORD_PASS;
				ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
		    	}

	    	return Validation;
	    	
	    }
    /**************************************************************************
     *  Function name 		: ResponseExpectedValidation
     *  Reuse Function 		:
     *  Description 		: Validate response with expected key value pair
     /**********************************************************************/
    public boolean ResponseExpectedValidation(String TestCaseId,Response res, String PKeys,String PValues)
    {
    	APP_LOGS.debug("Validation API Response with expected keyvalue :"+TestCaseId+PKeys+PValues);
        boolean Validation= false;
        String ExpecKeytoFind=null;
        String repKeyExist=null;
        if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
        {
            try
            {
            	 if ((PKeys.length()>0)&(PValues.length()>0)&(!PKeys.equalsIgnoreCase("null"))&(!PKeys.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("null")))
                {

                    String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
                    String[] ArValues = PValues.split(Constants.DATA_SPLIT);
                    for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
                    {
                        ExpecKeytoFind=ArKeys[i];

                        //Check whether key is present
                        repKeyExist=res.then().extract().path(ArKeys[i]);
                        if(repKeyExist!=null)
                        {
                            res.then().assertThat().body(ArKeys[i], equalTo(ArValues[i]));
                            Validation= true;
                        }
                        else
                        {
                            ApiDescription=ApiDescription+"\n  Key not found : "+ArKeys[i];
                            APIStatus=Constants.KEYWORD_FAIL;
                            System.out.println("Err Catch ResponseExpectedValidation for "+ TestCaseId+":"+ApiDescription);
                            return false;
                        }
                    }
                }
                else
                {
                    Validation= true;
                    //ApiDescription=ApiDescription+"\n  Expected Values not provided";
                    return Validation;
                }
            }
            catch (AssertionError e)
            {
                System.out.println("Err Catch ResponseExpectedValidation for "+ TestCaseId+":"+e.getMessage());
                ApiDescription=ApiDescription+"\n  Mismatched Actual Values:"+e.getMessage();
                APIStatus=Constants.KEYWORD_FAIL;
                return false;
            }
            catch (ClassCastException e)
            {
                System.out.println("Err Catch ResponseExpectedValidation for "+ TestCaseId+":"+e.getMessage());
                ApiDescription=ApiDescription+"\n  Key not found  :"+ExpecKeytoFind;
                APIStatus=Constants.KEYWORD_FAIL;
                return false;
            }
            APIStatus=Constants.KEYWORD_PASS;
            ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
        }

        return Validation;

    }
    
   
	    /**************************************************************************
		 *  Function name 		: ResponseExpectedValidation
		 *  Reuse Function 		: 
		 *  Description 		: Validate response with expected key value pair    
		 /**********************************************************************/    
	    public boolean ResponseValidation_hasitem(Response res, String PKeys,String PValues)
	    {
	    	APP_LOGS.debug("Validation API Response hasitem with expected keyvalue :"+PKeys+PValues);
	    	 boolean Validation= false;
	    	 String ExpecKeytoFind=null;
	    	 String repKeyExist=null;
	    	 if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
	    	 {
		    	try
		   		 {  
			    	if ((PKeys.length()>0)&(PValues.length()>0)&(!PKeys.equalsIgnoreCase("null"))&(!PValues.equalsIgnoreCase("null")))
					{			    		
				        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
				        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
				        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
				        {
				        	ExpecKeytoFind=ArKeys[i];
				        	//Check whether key is present
				        	repKeyExist=res.then().extract().path(ArKeys[i]);
				        	if(repKeyExist!=null)
				        	{	
						        res.then().assertThat().body(ArKeys[i], hasItem(ArValues[i]));
						    	Validation= true;
				        	}
				        	else
				        	{
				        		ApiDescription=ApiDescription+"\n  Key not found : "+ArKeys[i];
					   			APIStatus=Constants.KEYWORD_FAIL;
					   			System.out.println("Err Catch ResponseExpectedValidation :"+ApiDescription);
					   			return false;
				        	}
				        }
					}
			    	else
			    	{
			    		 Validation= true;
			    		 //ApiDescription=ApiDescription+"\n  Expected Values not provided";
			    		 return Validation;
			    	}
		   		 }
		   		 catch (AssertionError e)
		   		 {     		
		   			System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Mismatched Actual Values:"+e.getMessage();
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    	catch (ClassCastException e)
		   		 {     		
		    		System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Key not found :"+ExpecKeytoFind;
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    	}
		    APIStatus=Constants.KEYWORD_PASS;
			ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
	    	return Validation;
	    	
	    }
	    
	    /***************************************************************************************
		 *  Function name 		: GetOutkeyValueFromResponse
		 *  Reuse Function 		:  GetResponseContentType
		 *  Description 		: Get output key value from the response
		/****************************************************************************************/    
		public static String VerifyPathFromResponse(Response res,String Key) 
		{
			APP_LOGS.debug("Verify the key exist in API Response :"+Key);
		   	String bResPathValid=null;
	
		    	try
		   		 {  
		    		bResPathValid=res.then().extract().path(Key);
			    	System.out.println("Path exist : "+Key+" : "+bResPathValid);
		    	}
		    	catch (AssertionError e)
		   		 {     		
		   			 System.out.println("Err Catch VerifyPathFromResponse :"+e.getMessage());
		   			 return bResPathValid;
		   		 }
		    	catch (ClassCastException e)
		   		 {     		
		   			 System.out.println("Err Catch VerifyPathFromResponse :"+e.getMessage());
		   			 return bResPathValid;
		   		 }
		    	return bResPathValid;
		    	
		    }
	    
	    /**************************************************************************
		 *  Function name 		: GetResponseTime
		 *  Reuse Function 		: 
		 *  Description 		: Get response time from response    
		 /**********************************************************************/  
	    public long GetResponseTime(Response res)
	    {
	    	APP_LOGS.debug("Get API Response Time ");
	    	String respinms="";
	    	long repTime=0;
		   	 if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
	    	 {
		    	try
		   		 {  
				    repTime=res.then().extract().response().getTime();
				    System.out.println("Response Time "+repTime);
				    respinms=repTime+" ms";
				   // ApiDescription=ApiDescription+"\n  Response Time:"+repTime +" ms";
				 }
		    	catch (AssertionError e)
		   		 {     		
		   			
		   			 System.out.println("Err Catch GetResponseTime :"+e.getMessage());
		   			 ApiDescription=ApiDescription+"\n  Invalid Response Time: "+repTime;
		   			 return repTime;
		   		 }
		    	//ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
	    	 }
	    	return repTime;
	    	
	    }

	    /**************************************************************************
		 *  Function name 		: GetResponseTimeinMS
		 *  Reuse Function 		: 
		 *  Description 		: Get response time in ms from response    
		 /**********************************************************************/  
	    public String GetResponseTimeinMS(Response res)
	    {
	    	APP_LOGS.debug("Get Response time(ms) ");
	    	String respinms="";
	    	long repTime=0;
		   	 if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
	    	 {
		    	try
		   		 {  
				    repTime=res.then().extract().response().getTime();
				    System.out.println("Resp Time "+repTime);
				    respinms=repTime+" ms";
				   // ApiDescription=ApiDescription+"\n  Response Time:"+repTime +" ms";
				 }
		    	catch (AssertionError e)
		   		 {     		
		   			
		   			 System.out.println("Err Catch GetResponseTime :"+e.getMessage());
		   			 ApiDescription=ApiDescription+"\n  Invalid Response Time: "+repTime;
		   			 return respinms;
		   		 }
		    	//ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
	    	 }
	    	return respinms;
	    	
	    }
	    
	    /**************************************************************************
		 *  Function name 		: GetResponseContentType
		 *  Reuse Function 		: 
		 *  Description 		: Get content type from response    
		 /**********************************************************************/  
	    public static String GetResponseContentType(Response res)
	    {
	    	APP_LOGS.debug("Get Response ContentType ");
	    	String repContentType=null;
	    	String RespContent=null;
	    	try
	   		 {  
	    		repContentType=res.then().extract().response().contentType();
			    //System.out.println("Resp Content Type "+repContentType);
	    		
	      		if ((repContentType.contains("json"))|(repContentType.contains("JSON")))
	    		{
	      			RespContent="json";
	    		}
	    		else if ((repContentType.contains("xml"))|(repContentType.contains("XML")))
	    		{
	    			RespContent="xml";
	    		}	
	    		else if ((repContentType.contains("html"))|(repContentType.contains("HTML")))
	    		{
	    			RespContent="html";
	    		}
	    		else
	    		{
	    			RespContent="txt";
	    		}
	  
			 }
	    	catch (AssertionError e){     		
	   			 System.out.println("Err Catch GetResponseContentType :"+e.getMessage());
	   			 ApiDescription=ApiDescription+"\n  Invalid Content Type:"+repContentType;
	   			 return RespContent;
	   		 }
	    	return RespContent;
	    }
	    
    /********************************************************************************
	 *  Function name 		: ValidataSchema
	 *  Reuse Function 		: 
	 *  Description 		: Validate response with schema from JSON, XML-XSD/DTD
	 /*******************************************************************************/  
	public String ValidataSchema(Response res,String SchemaFilepath,String ResponseFilePath) throws ProcessingException, IOException
	{
		APP_LOGS.debug("Validate API Response with Schema file "+SchemaFilepath);
	   	String repContentType=null;
	    File SchmFile = new File(SchemaFilepath);
	   	 if ((APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))&(SchmFile.exists()))
    	 {
	    	try
	   		 {  
	    			repContentType=GetResponseContentType(res);
		    		if ((repContentType.contains("json"))|(repContentType.contains("JSON")))
		    		{
		    			ApiDescription=ApiDescription+"\n  Json Schema Validation : ";
		    			//res.then().assertThat().body(matchesJsonSchemaInClasspath(""));
		    			ValidateJSONSchema(SchemaFilepath,ResponseFilePath);
		    		}
		    		else if ((repContentType.contains("xml"))|(repContentType.contains("XML")))
		    		{
		    			String ext =FilenameUtils.getExtension(SchemaFilepath);
		    			if (ext.equalsIgnoreCase("xsd"))
		    			{
		    				ApiDescription=ApiDescription+"\n  XML Schema Valitation with XSD :";
		    				res.then().assertThat().body(matchesXsd(SchmFile));
		    				APIStatus=Constants.KEYWORD_PASS;
		    				ApiDescription=ApiDescription+"\n Passed ";
		    			}
		    			else if (ext.equalsIgnoreCase("dtd"))
		    			{
		    				ApiDescription=ApiDescription+"\n  XML Schema Valitation with Dtd :";
		    				res.then().assertThat().body(matchesDtd(SchmFile));
		    				APIStatus=Constants.KEYWORD_PASS;
		    				ApiDescription=ApiDescription+"\n Passed ";
		    			}
		    		else if ((repContentType.contains("html"))|(repContentType.contains("HTML")))
		    		{
		    			
		    		}
	    	}
	    		
			 }
	    	catch (AssertionError e)
	   		 {     		
	   			
	   			 System.out.println("Err Catch ValidataSchema :"+e.getMessage());
	   			 APIStatus=Constants.KEYWORD_FAIL;
	   			 ApiDescription=ApiDescription+"\n Faileded :";
	   			 return repContentType;
	   		 }
	    	
    	 }
	    	return repContentType;
	    	
	    }
	   
    /********************************************************************************
	 *  Function name 		: ValidateJSONSchema
	 *  Reuse Function 		: 
	 *  Description 		: Validate response string with schema from JSON
	 /*******************************************************************************/  
	    public static boolean ValidateJSONSchema(String JsonSchemaFile,String JsonValueFile) throws ProcessingException, IOException
	    {
	    	APP_LOGS.debug("Validate JSON Schema"+JsonSchemaFile);
	  	  boolean isvalid=false;
	  	  String PrcMsg=null;
	  	  vjson=new SchemaValidation();
	   	 if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
	   	 {
	  		  File sFile = new File(JsonSchemaFile);
	  		  File jFile = new File(JsonValueFile);
	  		  if ((sFile.exists())&(jFile.exists())) 
	  		  {
	  			  isvalid=vjson.isJsonValid(sFile, jFile);
	  			  if (!isvalid)
	  			  {
	  				PrcMsg=vjson.validateJson(sFile,jFile);
	  				System.out.println("Json Schema Process Msg :"+PrcMsg);
	  				APIStatus=Constants.KEYWORD_FAIL;
	  				ApiDescription=ApiDescription+"\n  Json Schema Faileded Process Msg: \n "+PrcMsg;
	  			  }
	  			  else
	  			  {
	  				  APIStatus=Constants.KEYWORD_PASS;
	  				  ApiDescription=ApiDescription+"\n Passed ";
	  			  }
	  			}
	  		  else
	  		  {
	  			  return true;
	  			  
	  		  }
	   	 }
	   	
	  	  return isvalid;
	    }

    /********************************************************************************
	 *  Function name 		: VerifyResponseStatus
	 *  Reuse Function 		:
	 *  Description 		: Validate expected status from response
	 /*******************************************************************************/
	    public int VerifyResponseStatus(Response res,int expStatusCode)
	    {
	    	APP_LOGS.debug("Validate API Response code "+expStatusCode);
	    	int RespStatus=0;
	    	try
	   		 {

			    res.then().assertThat().statusCode(expStatusCode);
			    RespStatus=res.getStatusCode();
			    System.out.println("Response Status :"+RespStatus);

			 }
	    	catch (AssertionError e)
	   		 {
	    		 System.out.println("Err Catch ResponseStatus :"+e.getMessage());
	   			 APIStatus=Constants.KEYWORD_FAIL;
	   			 ApiDescription="The following response details: \n Invalid Response Code:"+RespStatus+"\n"+e.getMessage();
	   			 return RespStatus;
	   		 }
	    	APIStatus=Constants.KEYWORD_PASS;
		    ApiDescription="The following response details: \n Response Code: "+RespStatus;

	    	return RespStatus;
	    }

    /********************************************************************************
     *  Function name 		: VerifyResponseStatus
     *  Reuse Function 		:
     *  Description 		: Validate expected status from response
     /*******************************************************************************/
    public boolean VerifyResponseStatus(String TestCaseID,Response res,int expStatusCode)
    {
    	APP_LOGS.debug("Validate API Response code "+expStatusCode);
        int RespStatus=0;
        try
        {

            res.then().assertThat().statusCode(expStatusCode);
            RespStatus=res.getStatusCode();
            System.out.println("Response Status :"+RespStatus);

        }
        catch (AssertionError e)
        {
            System.out.println("Err Catch ResponseStatus for "+TestCaseID+ " :" +e.getMessage());
            APIStatus=Constants.KEYWORD_FAIL;
            ApiDescription="The following response details: \n Invalid Response Code:"+RespStatus+"\n"+e.getMessage();
            return false;
        }
        APIStatus=Constants.KEYWORD_PASS;
        ApiDescription="The following response details: \n Response Code: "+RespStatus;
        return true;
    }

    /********************************************************************************
		 *  Function name 		: VerifyResponseStatus
		 *  Reuse Function 		: 
		 *  Description 		: Validate expected status from Actual
		 /*******************************************************************************/  
	    
	    public static void VerifyResponseStatus(int ActualStatusCode,int expStatusCode)
	    {
	    	APP_LOGS.debug("Validate API Response code "+expStatusCode);
	     
	    		if (ActualStatusCode==expStatusCode)
	    		{
	    			APIStatus=Constants.KEYWORD_PASS;
	    		    ApiDescription="Valid Response Code: "+ActualStatusCode;
	    		}
	    	else
	   		 {     		
	   			APIStatus=Constants.KEYWORD_FAIL;
	   			System.out.println("Response Status "+ActualStatusCode);
	   			ApiDescription="Invalid Response status:"+ActualStatusCode;
	   		 }
	
	    }
	    
		/***************************************************************************************
		 *  Function name 		: VerifyExpectedValues
		 *  Reuse Function 		: 
		 *  Description 		: Split the GetOutputKey and Expected values using delimiter |. 
		/****************************************************************************************/         
	    public void VerifyExpectedValues( Xls_Reader current_TestCase_xls,int rowNum,String url,String OpKey, String Expected) 
	    {
	    	APP_LOGS.debug("Validate API Response keyvalue  "+OpKey+Expected);
	    	boolean SetValue3,SetValue4;
	       	String joined = null;
	       	if (Expected.length() > 0 )
	       	{
		    	String[] GetOutputKey = OpKey.split("\\|");
		    	String[] Actual = Expected.split("\\|");
		    	String[] descrition = new String[GetOutputKey.length];
		    	String Status=null;
		    	
		    	boolean TestFlag=true; 	
		    	boolean[] result = new boolean[GetOutputKey.length];
				for(int i=0;i<GetOutputKey.length;i++)
				{	
				 	result[i]= ExpectedValueValidation(url, GetOutputKey[i], Actual[i]);
					if (result[i] == true)
						descrition[i]= "Validation match " + GetOutputKey[i]+":" +Actual[i];				
					else{
						TestFlag=false;
						descrition[i]= "Validation not match " + GetOutputKey[i]+":" +Actual[i];
						}
				  } 			
					joined = String.join("|", descrition);			
					if (TestFlag==true)
					 Status =Constants.KEYWORD_PASS; 
					else
					 {Status=Constants.KEYWORD_FAIL;}
					
					 SetValue3=current_TestCase_xls.setCellData(Constants.TEST_STEPS_SHEET, Constants.ResponseDescription, rowNum, joined);
					 SetValue4=current_TestCase_xls.setCellData(Constants.TEST_STEPS_SHEET, Constants.RESULT, rowNum, Status);
					 System.out.println(" Result:"+SetValue3+SetValue4);
	      	}
			}
	    
	    /*************************************************************************************************
		 *  Function name 		: GetReferenceValue
		 *  Reuse Function 		: 
		 *  Description 		: Get the reference value from the URL column  
		/**************************************************************************************************/   
		public static String GetReferenceValue(String Filename, String SheetName, String XString)
	    {
			APP_LOGS.debug("Get reference value  "+XString);
	    	String OpValue=null,OpStatus;
	    	String ReTurnString=XString;
	    	String TCID = null,sRefDataSetID=null,TcColm;
	    	while (ReTurnString.contains(Constants.KEYWORD_REF))
			{
		    	int strlen=XString.length();
		    	Xls_Reader TestCase_xls=null;
		    	TestCase_xls=new Xls_Reader(Filename);
		    	if ((XString.contains("{"))&(XString.contains("}")))
		        {
		    		String Url1 = XString.substring(0,XString.indexOf("{"));
		    		String RefString = XString.substring(XString.indexOf("{")+1, XString.indexOf("}"));
		    		//System.out.println("Ref String : "+RefString);
		    		String[] ArTcCol = RefString.split(Constants.DATA_SPLIT);
		    		String RefTCid=ArTcCol[0];
		    		//System.out.println(RefTCid);
		    		String[] A1tTCs=RefTCid.split(Constants.KEYWORD_REF);
		    		if (A1tTCs[1].contains(Constants.DATASET_SPLIT)){
		    			String[] SplitDataset=A1tTCs[1].split(Constants.DATASET_SPLIT);
		    			TCID=SplitDataset[0];
		    			sRefDataSetID=SplitDataset[1];
		    		}
		    		else{
		    			TCID=A1tTCs[1];
		    		}
		    		TcColm=ArTcCol[1];
		    		String Urllast = XString.substring(XString.indexOf("}")+1,strlen);
		        	//int ValueRow= TestCase_xls.getCellRowNum(SheetName, Constants.TCID, TCID);
		        	//OpStatus=TestCase_xls.getCellData(SheetName, Constants.RESULT, ValueRow);
		        	for (Map<String, String> map : result){
		        		if((map.get("TestCaseID").equalsIgnoreCase(TCID))&(map.get("DataSetID").equalsIgnoreCase(sRefDataSetID))&(map.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_PASS))){
		        			if (map.containsKey(TcColm))
		        			{
		        				OpValue= map.get(TcColm);
		        				System.out.println("Colm Value  : "+TcColm+" : "+OpValue);
			        			if (OpValue.length()>0){
			        				ReTurnString=Url1+OpValue+Urllast;
			        				return ReTurnString;
			        			}
		        			}
	                  }
	                }
		        	if(OpValue==null){
			    		ReTurnString=Url1+"Ref not Found"+Urllast;
		        		APIStatus=Constants.KEYWORD_SKIP;
		    		    ApiDescription="Skipped due to failed status of dependent Test case  : " +TCID;
			    	}
		          }
			}
	    	return ReTurnString;
	    }

	/*************************************************************************************************
	 *  Function name 		: StoreRespose
	 *  Reuse Function 		: 
	 *  Description 		: Store the Web services Response to local src/res/Response path
	/**************************************************************************************************/
	
    public String StoreRespose(Xls_Reader current_TestCase_xls,String Filename, String FileType,String Value,int rowNum)throws FileNotFoundException
    {
    	APP_LOGS.debug("Store Response "+Filename);
    	boolean SetValue2;
    	String RespPath=null;
    	File file = new File(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Response/"+Filename+"."+FileType);
		try (FileOutputStream fop = new FileOutputStream(file)) 
		{
			// if file doesn't exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			// get the content in bytes
			byte[] contentInBytes = Value.getBytes();
			fop.write(contentInBytes);
			fop.flush();
			fop.close();
			URL myUrl = file.toURI().toURL();
			RespPath=file.getAbsolutePath();
			System.out.println("Response stored Path : "+RespPath);	
			current_TestCase_xls.setCellData(Constants.TEST_STEPS_SHEET, Constants.Response, rowNum,myUrl.toString());
			return RespPath;
			
		}
     catch (IOException e) {e.printStackTrace();}
		return RespPath;
    }
    
	/*************************************************************************************************
	 *  Function name 		: GetValuefromXMLStream
	 *  Reuse Function 		: 
	 *  Description 		: Read the XML response and get field value 
	/**************************************************************************************************/    
    public static String GetValuefromXMLStream(String FileName,String FileType,String Key)
    {
    	APP_LOGS.debug("Get value from XML Stream "+Key);
    	String ReString;
    	ReString=null;
    	ReString="Not Found"; 
    	      try {				
		    	  	System.out.println("XML Value for : "+FileName+" : " +FileType);	
				  	File fXmlFile = new File(System.getProperty("user.dir")+"/src/res/Response/"+FileName+"."+FileType);
				  	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				  	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();				 
				  	Document doc = dBuilder.parse(fXmlFile);
				  	doc.getDocumentElement().normalize();  				  						  	
				  	String roolElement=doc.getDocumentElement().getNodeName().toString();			  
				  	
				    NodeList nList = doc.getElementsByTagName(roolElement);			  					  					  	
				  	for (int temp = 0; temp < nList.getLength(); temp++)
				  	{				
				  		Node nNode = nList.item(temp);	
				  		
				  		if (nNode.getNodeType() == Node.ELEMENT_NODE) {				
				  			Element eElement = (Element) nNode;	
				  			ReString=eElement.getElementsByTagName(Key.trim()).item(0).getTextContent();			  						  						
				  			}
				  	}
				  } 
		      catch (Exception e) {e.printStackTrace();}
    	      return ReString;
     }


	/*************************************************************************************************
	 *  Function name 		: GetHttpRespString
	 *  Reuse Function 		: 
	 *  Description 		: Get Body string from HttpResponse
	/**************************************************************************************************/ 
	
	public static String GetHttpRespString(HttpResponse respString) 
	{
		APP_LOGS.debug("Get API Response string ");
		String responseString=null;
		try{
	        HttpEntity entity = respString.getEntity();
	        responseString = EntityUtils.toString(entity, "UTF-8");
	        //System.out.println("Response Stringsss :"+responseString);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return responseString;
		}
		return responseString;
	}
	
	/*************************************************************************************************
	 *  Function name 		: GetRespString
	 *  Reuse Function 		: 
	 *  Description 		: Get Body string from Response
	/**************************************************************************************************/ 
	public String GetRespString(Response respString) 
	{
		APP_LOGS.debug("Get API Response string ");
		String responseString=null;
		try{
	       
	        responseString = respString.asString();
	        //System.out.println("Response Stringsss :"+responseString);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return responseString;
		}
		return responseString;
	}
	
	/*************************************************************************************************
	 *  Function name 		: GetJsonKeyValue
	 *  Reuse Function 		: 
	 *  Description 		: Get value for key from Response string
	/**************************************************************************************************/ 
	public static String GetJsonKeyValue(String JsonSSString,String Key)
    {   	
		APP_LOGS.debug("Get JSON Key Value "+Key);
    	String ReString;
    	ReString=null;
    	ReString="Not Found";
	    try 
	      {
	    	JsonPath jsonResponse = new JsonPath(JsonSSString);
	    	ReString= jsonResponse.getString(Key);			 
	      } 
	    catch (Exception e) 
	      {
	    	e.printStackTrace();
	       }        	      
     	return ReString;
      } 
	
	/*************************************************************************************************
	 *  Function name 		: deletfile
	 *  Reuse Function 		: 
	 *  Description 		: Delete file from location
	/**************************************************************************************************/
	public static void deletfile(String FilePath)
	{
		APP_LOGS.debug("Delete File "+FilePath);
		try {
			
			File files= new File(FilePath);
			if (files.exists())
			{
				boolean bool=files.delete();
				//System.out.println("File "+files.getName()+" deleted: "+bool);
			}
		} catch (Exception x) {
		    // File permission problems are caught here.
		    System.out.println("Err Catch in deletfile"+x);
		}
	}
	
	/*************************************************************************************************
	 *  Function name 		: getDynamicvalue
	 *  Reuse Function 		: 
	 *  Description 		: Generate random value
	/**************************************************************************************************/
	 public String getDynamicvalue(String RandomValue)
	 {
		 String RetnResult;
		 if (RandomValue.contains(Constants.KEYWORD_RANDOM))
		 {
		       String[] ArKeys = RandomValue.split(Constants.KEYWORD_RANDOM);
		        int NofValue = Integer.parseInt(ArKeys[1]);
				SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMddHHmmss");//dd/MM/yyyy
				Date now = new Date();
				String strDate = sdfDate.format(now);
				strDate="000000"+strDate;
			    //System.out.println("Randam Full Value : "+strDate);//00000020160627172129
			    String GeneratedRmValue=StringUtils.right(strDate, NofValue);
				//System.out.println("Randam Value : "+GeneratedRmValue);
				RetnResult=ArKeys[0]+GeneratedRmValue;
		 }
		 else
		 {
			 RetnResult=RandomValue;
		 }
		 return RetnResult;
	 }

	/*************************************************************************************************
	 *  Function name 		: StoreReponseToExternal
	 *  Reuse Function 		: 
	 *  Description 		: Store the response string to local path
	/**************************************************************************************************/ 
	 public void StoreReponseToExternal(String Filename,String Value)throws FileNotFoundException
	    {
		 APP_LOGS.debug("Store response to External "+Filename);
		 	String TempPath=null;
		 	
		 	
		 	//System.out.println(Filename);
		 	Boolean result;
		 	File folder = new File(TempPath);
	        //ResponseBuilder response = Response.ok((Object) file);
		 	if (!folder.exists()) {
		 		 try{
		 			folder.getParentFile().mkdirs();
		 			//folder.mkdir();
		 	        result = true;
		 	    } 
		 	    catch(SecurityException se){
		 	        //handle it
		 	    }
		 	}
		 	if (result=true)
		 	{
		    	File file = new File(TempPath);
				try (FileOutputStream fop = new FileOutputStream(file)) 
				{
					// if file doesn't exists, then create it
					file.getParentFile().mkdirs();
					if (!file.exists()) {
						file.createNewFile();
					}
					// get the content in bytes
					byte[] contentInBytes = Value.getBytes();
					fop.write(contentInBytes);
					fop.flush();
					fop.close();
				}
		     catch (IOException e) {e.printStackTrace();}
	    }
	    }


	}
	
    
	
