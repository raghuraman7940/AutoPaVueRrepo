package com.verizon.util;


import static com.verizon.DriverScript.*;
import java.io.*;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.verizon.util.Constants;
import com.verizon.util.Xls_Reader;




public class ReportJSON {
public static String result_FolderName=null;
// properties
//public static Properties CONFIG;

	public static void main(String[] arg) throws Exception {
		ReportJSON Rep=new ReportJSON();
		Rep.GenerateJSONReport();
		
	}

	
	/***************************************************************************************
 	 *  Function name 		: GenerateJSONReport
 	 *  Reuse Function 		:  
 	 *  Description 		: To generate excel testresult into JSON
 	/****************************************************************************************/ 
	public JSONObject BuildJSONReport(JSONObject JsonTestReport)
	{
	     //Initialize Test case summary Count
		int iNoOfTestCase=0,iNoOfPass = 0,iNoOfFail=0,iNoOfSkip=0;    
		JSONObject jsTestData = new JSONObject(JsonTestReport.toString());
		JSONObject jsReportData = new JSONObject();
		try{
		//Create Report Folder
		Date d = new Date();
		 // Add test report details
		jsReportData.put(Constants.JSReportTitle, "API Automation Test Report");
		jsReportData.put(Constants.JSRunDate, d.toString());
		jsReportData.put(Constants.JSRunEnvironment, CONFIG.getProperty("environment"));
		jsReportData.put(Constants.JSVersion, CONFIG.getProperty("version"));
		jsReportData.put(Constants.JSReleaseVersion, Constants.JIRAReleaseVersion);
		jsReportData.put(Constants.JSReleaseDate, Constants.JIRAReleaseDate);
		jsReportData.put(Constants.JSTestingType, Constants.JIRATestingType);
        
	     // JsonArray JsonTSuites = new JsonArray();
	      JSONArray JsonTSuites = new JSONArray();
	      
	      for (int iSuiteIter = 0; iSuiteIter < 1; iSuiteIter++)
	      {
	    	  String suite_result="";
		  // create a JsonTSuite
	      JSONObject JsonTSuite = new JSONObject();
	      JsonTSuite.put(Constants.JSProject, Constants.JIRAProject);
	      JsonTSuite.put(Constants.JSIssueType, Constants.JIRAIssueType);
	      JsonTSuite.put(Constants.JSSprint, Constants.JIRASprint);
	      JsonTSuite.put(Constants.JSTestingType, Constants.JIRATestingType);
	      JsonTSuite.put(Constants.JSExecutionDuration, Constants.ExecutionDuration+Constants.TimeType);	
	      //Tests
	      JSONArray TestSets = (JSONArray) jsTestData.get("Tests");
        
	      //Tests Report
	      JSONArray RepTests = new JSONArray();
	      for (int iTestIter = 0; iTestIter < TestSets.length(); iTestIter++) {
        	JSONObject Testset = TestSets.getJSONObject(iTestIter);	
        	//System.out.println("TestSet : "+Testset);
                //DataSets
                JSONArray DataSets = (JSONArray) Testset.get("Datasets");
                for (int iDataIter = 0; iDataIter < DataSets.length(); iDataIter++) {
                	JSONObject DataSet = DataSets.getJSONObject(iDataIter);
                	JSONObject jsTestReps = new JSONObject();
                	jsTestReps.put(Constants.RepIssue_key, Testset.get(Constants.TCID).toString());
        		  	jsTestReps.put(Constants.RepAPIMethodType, Testset.get(Constants.MethodType).toString());
        		  	jsTestReps.put(Constants.RepAPIDescription, Testset.get(Constants.Details).toString());
                	iNoOfTestCase=iNoOfTestCase+1;
                	String TestResults=DataSet.get(Constants.RepTestResultStatus).toString();
                	  if((TestResults.startsWith("Pass") || TestResults.startsWith("PASS"))){
						  iNoOfPass=iNoOfPass+1;
					  }
					  else if((TestResults.startsWith("Fail") || TestResults.startsWith("FAIL"))){
						  iNoOfFail=iNoOfFail+1;
						  if(suite_result.equals(""))
							  suite_result=Constants.KEYWORD_FAIL;
					  }
					  else if((TestResults.startsWith("Skip") ||TestResults.startsWith("skip")|| TestResults.startsWith("SKIP")||TestResults.isEmpty())){
						  TestResults=Constants.KEYWORD_SKIP;
						  iNoOfSkip=iNoOfSkip+1;
					  }
                	
                	jsTestReps.put(Constants.RepAPIURL, DataSet.get(Constants.RepAPIURL).toString());
                	jsTestReps.put(Constants.RepInput_KeyValues, DataSet.get("HeaderKeyValue").toString()+DataSet.get(Constants.RepInput_KeyValues).toString());
                	jsTestReps.put(Constants.RepExpected, DataSet.get(Constants.RepExpected).toString());
                	jsTestReps.put(Constants.RepTestResultStatus, TestResults);
                	jsTestReps.put(Constants.RepResponseDescription, DataSet.get(Constants.RepResponseDescription).toString());
                	jsTestReps.put(Constants.RepOutput_Values, DataSet.get(Constants.RepOutput_Values).toString());
                	jsTestReps.put(Constants.RepResponseTime, DataSet.get(Constants.RepResponseTime).toString());
                	jsTestReps.put(Constants.RepResponse, DataSet.get("ResponseFilePath").toString());
                	jsTestReps.put(Constants.RepResponseString, DataSet.get(Constants.RepResponse).toString());
                	
                	RepTests.put(jsTestReps);
                }
               
	      	}
	      JsonTSuite.put(Constants.JSsuitTest, RepTests);
	      
	      if(suite_result.equals("FAIL"))
			  JsonTSuite.put(Constants.JSsuiteStatus, "Fail");
		  else
		  JsonTSuite.put(Constants.JSsuiteStatus, "Pass");
	      JsonTSuite.put(Constants.JSsuiteNoOfTestCases, iNoOfTestCase);
		  JsonTSuite.put(Constants.JSsuiteNoOfPassed, iNoOfPass);
		  JsonTSuite.put(Constants.JSsuiteNoOfFailed, iNoOfFail);
		  JsonTSuite.put(Constants.JSsuitNoOfSkipped, iNoOfSkip);
		  JsonTSuites.put(JsonTSuite);
	      
	      }
	      jsReportData.put(Constants.JSsuite, JsonTSuites);
	      
	      System.out.println("Input ReportData : \n"+JsonTestReport);
	      System.out.println("Final ReportData : \n"+jsReportData);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	      return jsReportData;
	}
		
	/***************************************************************************************
 	 *  Function name 		: GenerateJSONReport
 	 *  Reuse Function 		:  
 	 *  Description 		: To generate excel testresult into JSON
 	/****************************************************************************************/ 
	public JsonObject GenerateJSONReport() throws Exception 
	{
		//APP_LOGS.debug("Generate JSON Report");
		String JSONFilePath=null;
		String currentTestSuite=null;
		Xls_Reader current_suite_xls=null;
		//Initialize Test case summary Count
		int iNoOfTestCase=0,iNoOfPass = 0,iNoOfFail=0,iNoOfSkip=0;
		// create the JsonTestRep object
        JsonObject JsonTestRep = new JsonObject();
		try{
			//Create Report Folder
			Date d = new Date();
			String date=d.toString().replaceAll(" ", "_");
			date=date.replaceAll(":", "_");
			date=date.replaceAll("\\+", "_");
			result_FolderName="Reports"+"_"+date;
			String reportsDirPath=System.getProperty("user.dir")+"\\Reports\\"+result_FolderName;
			new File(reportsDirPath).mkdirs();
			// create TestReport.json
			JSONFilePath=reportsDirPath+"\\TestReport.json";
			System.out.println("\nGenerates JSON Test Report Path \n"+JSONFilePath);
			 // Add test report details
	        JsonTestRep.addProperty(Constants.JSReportTitle, "API Automation Test Report");
	        JsonTestRep.addProperty(Constants.JSRunDate, d.toString());
	        JsonTestRep.addProperty(Constants.JSRunEnvironment, CONFIG.getProperty("environment"));
	        JsonTestRep.addProperty(Constants.JSVersion, CONFIG.getProperty("version"));
	        JsonTestRep.addProperty(Constants.JSReleaseVersion, Constants.JIRAReleaseVersion);
	        JsonTestRep.addProperty(Constants.JSReleaseDate, Constants.JIRAReleaseDate);
	        JsonTestRep.addProperty(Constants.JSTestingType, Constants.JIRATestingType);
	        //Get Suite excel
			Xls_Reader suiteXLS = new Xls_Reader(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Xls/"+Constants.SUITE_XLFILE);
			 //Get Suite row count
			//int totalTestSuites=suiteXLS.getRowCount(Constants.TEST_SUITE_SHEET);
			String suite_result="";
			 //Get Testcase Sheet row count
			if (CONFIG.getProperty("InputType").equalsIgnoreCase("Jira")){
				  current_suite_xls=new Xls_Reader(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Xls/"+Constants.TEST_JIRAXLFILE);
		    }
			else{
				  current_suite_xls=new Xls_Reader(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Xls/"+Constants.TEST_XLFILE);
			 }
			 // create an array called JsonTSuites
		      JsonArray JsonTSuites = new JsonArray();
			  // create a JsonTSuite
		      JsonObject JsonTSuite = new JsonObject();
		      JsonTSuite.addProperty(Constants.JSProject, Constants.JIRAProject);
		      JsonTSuite.addProperty(Constants.JSIssueType, Constants.JIRAIssueType);
		      JsonTSuite.addProperty(Constants.JSSprint, Constants.JIRASprint);
		      JsonTSuite.addProperty(Constants.JSTestingType, Constants.JIRATestingType);
		      JsonTSuite.addProperty(Constants.JSExecutionDuration, Constants.ExecutionDuration+Constants.TimeType);
		      
		      // create an array called SuiteTests
			  JsonArray JsonTSuiteTests = new JsonArray();
			  //Initialize summary count
			  	iNoOfTestCase=0;
				iNoOfPass=0;
				iNoOfFail=0;
				iNoOfSkip=0;
			  for(int currentTestCaseID=2;currentTestCaseID<=suiteXLS.getRowCount(Constants.TEST_SUITE_SHEET);currentTestCaseID++)
			   {
				  	//Get suite wise test cases
				  	currentTestSuite = suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.Test_Suite_ID,currentTestCaseID);
				  	//System.out.println("currentTestSuite: "+currentTestSuite);
				  	//Get suite details
				  	JsonTSuite.addProperty(Constants.JSsuiteTitle, currentTestSuite);
				  	JsonTSuite.addProperty(Constants.JSsuiteName, suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.TEST_CASES_SHEET, currentTestCaseID));
				  	JsonTSuite.addProperty(Constants.JSsuiteDes, suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.DESCRIPTION,currentTestCaseID));
			    	Constants.TEST_STEPS_SHEET=suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.TEST_CASES_SHEET, currentTestCaseID);
			    	Constants.TEST_STEPS_SHEET=Constants.TEST_STEPS_SHEET+"_TestResult";
					//System.out.println("TEST_STEPS_SHEET: "+ Constants.TEST_STEPS_SHEET);
					int rows= current_suite_xls.getRowCount(Constants.TEST_STEPS_SHEET);
					int cols = current_suite_xls.getColumnCount(Constants.TEST_STEPS_SHEET);
					// fill the whole sheet
					// System.out.println("Debug:4 Rows: "+rows);
			        for(int rowNum=2;rowNum<=rows;rowNum++){
			        	  // create a SuiteTest
				        JsonObject JsonTSuiteTest = new JsonObject();
					  iNoOfTestCase=iNoOfTestCase+1;
					  for(int colNum=0;colNum<cols;colNum++){	
						  String ColName=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, 1);
						  String data=current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET, colNum, rowNum);
						 // System.out.println("Test Data: "+ColName+" : "+data);
						  data=data.replace("\n", "<br>");
						// Get count for Test result
						  if (ColName.startsWith(Constants.RESULT)){
							  if((data.startsWith("Pass") || data.startsWith("PASS"))){
								  iNoOfPass=iNoOfPass+1;
							  }
							  else if((data.startsWith("Fail") || data.startsWith("FAIL"))){
								  iNoOfFail=iNoOfFail+1;
								  if(suite_result.equals(""))
									  suite_result="FAIL";
							  }
							  else if((data.startsWith("Skip") ||data.startsWith("skip")|| data.startsWith("SKIP")||data.isEmpty())){
								  data="skipped";
								  iNoOfSkip=iNoOfSkip+1;
							  }
						  }
						// Get response as hyperlink
						  if (ColName.equalsIgnoreCase(Constants.Response))
						  {
							  String TestcaseID1 = current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET,Constants.TCID, rowNum);							  
							  String fp = current_suite_xls.getCellData(Constants.TEST_STEPS_SHEET,Constants.Response, rowNum);
							  data="<a href="+fp+">"+TestcaseID1 +"</a>";
								//System.out.println("Resp Test Data: "+ColName+data);
						  }
						  JsonTSuiteTest.addProperty(ColName, data);
						}
					// Add Test details into Test
					  JsonTSuiteTests.add(JsonTSuiteTest);
					  JsonTSuite.add(Constants.JSsuitTest, JsonTSuiteTests);
				  }					  
				  //Get overall Status
				  if(suiteXLS.getCellData(Constants.TEST_SUITE_SHEET, Constants.RUNMODE,currentTestCaseID).equalsIgnoreCase(Constants.RUNMODE_YES))
					  if(suite_result.equals("FAIL"))
						  JsonTSuite.addProperty(Constants.JSsuiteStatus, "Fail");
					  else
						  JsonTSuite.addProperty(Constants.JSsuiteStatus, "Pass");
				  else
					  JsonTSuite.addProperty(Constants.JSsuiteStatus, "skipped");
				  
				  JsonTSuite.addProperty(Constants.JSsuiteNoOfTestCases, iNoOfTestCase);
				  JsonTSuite.addProperty(Constants.JSsuiteNoOfPassed, iNoOfPass);
				  JsonTSuite.addProperty(Constants.JSsuiteNoOfFailed, iNoOfFail);
				  JsonTSuite.addProperty(Constants.JSsuitNoOfSkipped, iNoOfSkip);
			     }
			  // Add Tests  into Suite
			  JsonTSuites.add(JsonTSuite);
			  JsonTestRep.add(Constants.JSsuite, JsonTSuites);
			  Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
		      //System.out.println(gson.toJson(JsonTestRep));
		      try (FileWriter file = new FileWriter(JSONFilePath)) {
		            file.write(gson.toJson(JsonTestRep));
		            file.flush();
		      } catch (IOException e) {
		        	 System.err.println("Error: " + e.getMessage());
		      }
		}
			  catch (Exception e){//Catch exception if any
			  System.err.println("Error: " + e.getMessage());
		  }
		return JsonTestRep;
	}
	

}
