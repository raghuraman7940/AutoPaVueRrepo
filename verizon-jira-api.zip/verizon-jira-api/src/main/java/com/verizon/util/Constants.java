package com.verizon.util;

public class Constants {


	//Suite Sheet
	public static String SUITE_XLFILE="Suite.xlsx";
	public static final String SUITE_ID = "TestSuiteID";
	public static final String DESCRIPTION = "Description";
	public static String TEST_SUITE_SHEET = "TestSuite";
	public static String Test_Suite_ID = "TestSuiteID";
	public static String TEST_CASES_SHEET = "SuiteName";
	public static String RUNMODE = "RunMode";
	public static String RUNMODE_YES = "YES";
	public static String SRC_RES_FILEPATH="/src/main/resources/restApi/";
	
	//Input Sheet Column
	public static String TEST_XLFILE="Automation_Run_Report.xlsx";
	public static String TEST_JIRAXLFILE="Automation_Run_Report_Export.xlsx";
	public static String CONFIG_FILEPATH="/src/main/resources/";
	public static String CONFIG_FILE="application.properties";
	public static String TEST_STEPS_SHEET ="Cropsnap";
	public static String ISSUE_TYPE="Issue_Type";
	public static String PROJECT_KEY="Project_key";	
	public static String TCID = "Issue_key";
	public static String DATASET = "DatasetID";
	public static String TESTRUNMODE = "RunMode";
	public static String SERVER="Server";	
	public static String URL="URL";	
	public static String Details="Details";	
	public static String MethodType="MethodType";	
	public static String Header_Keys="Header_Keys";	
	public static String Header_Values="Header_Values";	
	public static String Param_Keys="Param_Keys";	
	public static String Param_Values="Param_Values";
	public static String Expected_Keys="Expected_Keys";
	public static String Expected_Values="Expected_Values";
	public static String ExpectedStatusCode="ExpectedStatusCode";
	public static String ExpectedSchema="ExpectedSchema";
	public static String GetOutputKey="GetOutputKey";
	public static String SwitchingMode="SwitchingMode";
	public static String RESULT = "TestResultStatus";
	public static String ResponseDescription="ResponseDescription";
	public static String ResponseTime="ResponseTime";
	public static String Output_Values="Output_Values";
	public static String Response="Response";
	
	//TestResults
	public static String RepIssue_key="Issue_key";
	public static String RepAPIMethodType="APIMethodType";
	public static String RepAPIURL="APIURL";
	public static String RepAPIDescription="APIDescription";
	public static String RepInput_KeyValues="Input_KeyValues";
	public static String RepExpected="Expected";
	public static String RepTestResultStatus="TestResultStatus";
	public static String RepResponseDescription="ResponseDescription";
	public static String RepResponseTime="ResponseTime";
	public static String RepOutput_Values="Output_Values";
	public static String RepResponse="Response";
	public static String RepResponseString="ResponseString";
	
	//Others
	public static String KEYWORD = "Keyword";
	public static String KEYWORD_PASS = "Pass";
	public static String KEYWORD_FAIL = "Failed";
	public static String KEYWORD_SKIP = "skipped";
	public static String KEYWORD_REF = "ref#";
	public static String KEYWORD_RANDOM = "#random";
	public static String DATA = "Data";
	public static String OBJECT = "Object";
	public static String DATA_START_COL = "col";
	public static String DATA_SPLIT = "\\|";
	public static String DATASET_SPLIT = "@";
	public static String BDD_VALUESEPERATOR = "~";
	public static String BDD_TABSEPERATOR = "|";
	public static Object POSITIVE_DATA = "Y";
	public static Object RANDOM_VALUE = "Random_Value";
	public static String CONFIG = "config";

	//JSON Report TAG
	public static String JSReportTitle = "TestDataTitle";
	public static String JSRunDate = "RunDate";
	public static String JSRunEnvironment = "RunEnvironment";
	public static String JSTestingType = "TestingType";
	public static String JSReleaseVersion = "ReleaseVersion";
	public static String JSReleaseDate = "ReleaseDate";
	public static String JSVersion = "Version";
	public static String JSsuite = "suite";
	public static String JSsuiteTitle = "title";
	public static String JSsuiteName = "SUITENAME";
	public static String JSsuiteDes = "DESCRIPTION";
	public static String JSProject = "Project";
	public static String JSIssueType = "IssueType";
	public static String JSSprint = "Sprint";
	public static String JSsuiteStatus = "Status";
	public static String JSExecutionDuration = "TimeTaken";
	public static String JSsuiteNoOfTestCases = "NoOfTestCases";
	public static String JSsuiteNoOfPassed = "NoOfPassed";
	public static String JSsuiteNoOfFailed = "NoOfFailed";
	public static String JSsuitNoOfSkipped = "NoOfSkipped";
	public static String JSsuitTest = "tests";
	
	
	//JSON Report TAG
	public static String JIRAProject = "COB";
	public static String JIRAIssueType = "Test";
	public static String JIRASprint = "Sprint-1";
	public static String JIRATestingType = "Functional";
	public static String ExecutionDuration = "30";
	public static String TimeType = "Mins";
	public static String JIRAReleaseVersion = "CoHo-Test-V1.0.0.0";
	public static String JIRAReleaseDate = "2017-03-31";

	//Jenkin
	public static String JENKINProjectFolderName = "RestAPIAutomation";
	public static String JENKINSchJobName = "COBJob";
	public static String JENKINProjectFolder = "Project";
	public static String JENKINJob = "Jobs";
	public static String JENKINJobName = "JobName";
	public static String JENKINJobId = "JobId";
	public static String JENKINJobLastSuccessfulBuild = "LastSuccessfulBuild";
	public static String JENKINJobLastFailedBuild = "LastFailedBuild";
	public static String JENKINJobLastStableBuild = "LastStableBuild";
	public static String JENKINJobBuilds = "Builds";
	public static String JENKINBuildId = "Id";
	public static String JENKINBuildName = "DisplayName";
	public static String JENKINBuildDuration = "Duration";
	public static String JENKINBuildUrl = "Url";
	public static String JENKINBuildTimestamp = "Timestamp";
	public static String JENKINBuildResult = "Result";
	public static String JENKINBuildConsole = "ConsoleOutputText";
	public static String JENKINBuildReport = "Report";
	public static String JENKINBuildConsoleStart = "<Response [200]>";
	public static String JENKINBuildConsoleEnd = "Finished:";
	
	
	public static String JENKINQueues = "Queues";
	public static String JENKINQueueid = "Queueid";
	public static String JENKINQueueTaskName = "TaskName";
	public static String JENKINQueueParameters = "Parameters";
	public static String JENKINQueueUrl = "QueueUrl";
	public static String JENKINQueueSince = "QueueSince";
	public static String JENKINQueueWhy = "QueueWhy";
	public static String JENKINQueueStatus = "PENDING";
	public static String JENKINQueueDuration = "-";

}
