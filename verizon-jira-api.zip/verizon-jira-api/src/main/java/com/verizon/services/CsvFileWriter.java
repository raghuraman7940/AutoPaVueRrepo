package com.verizon.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;

import com.verizon.pojo.Attachment;
import com.verizon.pojo.CustomJiraSelectFields;
import com.verizon.pojo.Issue;
import com.verizon.pojo.IssueLink;
import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.pojo.Version;
import com.verizon.util.Constants;
import com.verizon.util.JIRAConstants;
import com.verizon.config.JiraProperties;
import com.verizon.util.ReportUtil;

import net.sf.json.JSONException;

/**
 * This class is used to write the csv file from JIRA.
 * 
 */
public class CsvFileWriter {
	
	static ReportUtil Rep; 
	static List<String> DependentList;
	
	// CSV file header
	private static final Object[] FILE_HEADER = { "Issue_Type", "Project_key",
			"Issue_key", "DataSetID", "RunMode", "Server", "URL", "Details", "MethodType",
			"Header_Keys", "Header_Values", "Param_Keys", "Param_Values",
			"Expected_Keys", "Expected_Values", "ExpectedStatusCode",
			"ExpectedSchema", "GetOutputKey", "SwitchingMode",
			"TestResultStatus", "ResponseDescription", "ResponseTime",
			"Output_Values" };
	// New line used in CSV file
	private static final String NEW_LINE_SEPARATOR = "\n";
	// error message.
	String errorMessage = null;
	// File writer object initialize.
	FileWriter dependentFileWriter, nonDependentFileWriter = null;
	// Csv File printer object initialize.
	CSVPrinter dependentFilePrinter, nonDependentFilePrinter = null;
	// Create the CSVFormat object with "\n" as a record delimiter
	CSVFormat csvFileFormat = CSVFormat.DEFAULT
			.withRecordSeparator(NEW_LINE_SEPARATOR).withEscape('\\')
			.withQuoteMode(QuoteMode.NONE);
	// object mapper creation.
	ObjectMapper mapper = new ObjectMapper();

	// write the csv file.
	public String writeCsvFile(JiraClient jira, JiraProperties properties, String jql)
			throws JSONException {
		try {
			Rep=new ReportUtil();
			DependentList = new ArrayList<String>();
			String XlsxSuiteFile = System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Xls/"+Constants.SUITE_XLFILE;
			Rep.ClearSuiteExcel(XlsxSuiteFile, Constants.TEST_SUITE_SHEET);
	
			File dependentExport = new File(properties.getDependentExportt());
			
			
			//System.out.println("dependentExport: "+dependentExport.getAbsoluteFile());
			if (dependentExport.exists()) {
				dependentExport.delete();
			}
			Rep.SuiteExcelData(XlsxSuiteFile, Constants.TEST_SUITE_SHEET, "1", "YES", "Dependent", "Dependent File");
			File nonDependentExport = new File(properties.getNonDependentExportt());
			//System.out.println("nonDependentExport: "+nonDependentExport.getAbsoluteFile());
			if (nonDependentExport.exists()) {
				nonDependentExport.delete();
			}
			Rep.SuiteExcelData(XlsxSuiteFile, Constants.TEST_SUITE_SHEET, "2", "YES", "Nondependent", "Non dependent File");
			// initialize FileWriter object
			dependentFileWriter = new FileWriter(dependentExport, true);
			// initialize FileWriter object
			nonDependentFileWriter = new FileWriter(nonDependentExport, true);
			// initialize CSVPrinter object
	
			dependentFilePrinter = new CSVPrinter(dependentFileWriter,
					csvFileFormat);
			// initialize CSVPrinter object
			nonDependentFilePrinter = new CSVPrinter(nonDependentFileWriter,
					csvFileFormat);
			// Create CSV file header
			dependentFilePrinter.printRecord(FILE_HEADER);
			// Create CSV file header
			nonDependentFilePrinter.printRecord(FILE_HEADER);
			/* Search for issues */
			//String jql = properties.getJql();
			Issue.SearchResult searchResult = jira.searchIssues(jql);
			System.out.print("Exporting JIRA Issues");
			Issue issue = null;
			// Write a new record into the CSV file
			for (Issue searchIssue : searchResult.issues) {
				issue = jira.getIssue(searchIssue.getKey());
				System.out.print(".");
				//Get dependent issues
				
				List<Version> FixVersions=issue.getFixVersions();
				for (Version ver:FixVersions)
				{
					Constants.JIRAReleaseVersion=ver.getName();
					Constants.JIRAReleaseDate=ver.getReleaseDate();
				}
				
				if (issue.getIssueLinks().toArray().length > 0) {
					getdependentIssues(jira,properties,issue);
				}
				else {
					List<List<String >> issueDatas=getIssueDetails(jira,properties,issue);
					for (List<String> issuedata :issueDatas){
						nonDependentFilePrinter.printRecord(issuedata);
					}
				}

			}
			
			return searchResult.issues.toString();
			
		} catch (NullPointerException e) {
			errorMessage = "Error in Custom Fields!!!" + e.getMessage();
			return errorMessage;
		} catch (Exception e) {
			errorMessage = "Error in CsvFileReader !!!" + e.getMessage();
			return errorMessage;
		} finally {
			try {
				dependentFileWriter.flush();
				dependentFileWriter.close();
				nonDependentFileWriter.flush();
				nonDependentFileWriter.close();
				dependentFilePrinter.close();
				nonDependentFilePrinter.close();
				System.out.println();
			} catch (IOException e) {
				errorMessage = "Error while flushing/closing fileWriter/csvPrinter !!!"
						+ e.getMessage();
				return errorMessage;
			}
		}
	}
	
		
	 /***************************************************************************************
	 *  Function name 		: getIssueDetails
	 *  Reuse Function 		:  
	 *  Description 		: Get issue data for the issue
	/****************************************************************************************/ 
		public List<List<String >> getIssueDetails(JiraClient jira,JiraProperties properties,Issue issue) throws JsonParseException, JsonMappingException, IOException, JiraException
		{
			//List<Map<String , String>> InputData  = new ArrayList<Map<String,String>>();
			List<List<String >> issueDatas  = new ArrayList<List<String>>();
			Map<String,String> hmapIssueData = new HashMap<String,String>();
			hmapIssueData.put(JIRAConstants.ISSUE_TYPE, issue.getIssueType().getName());
			hmapIssueData.put(JIRAConstants.PROJECT, issue.getProject().getKey());
			hmapIssueData.put(JIRAConstants.ISSUE_KEY, issue.getKey());
			//System.out.println("Issue Key : "+issue.getKey());
			CustomJiraSelectFields runMode = mapper.readValue(
					issue.getField(JIRAConstants.CUSTOMFIELD_RUNMODE)
							.toString(), CustomJiraSelectFields.class);
			if (runMode != null) {
				hmapIssueData.put(JIRAConstants.RUNMODE, runMode.getValue());
			}
			hmapIssueData.put(JIRAConstants.SERVER, issue.getField(JIRAConstants.CUSTOMFIELD_SERVER)
					.toString());
			hmapIssueData.put(JIRAConstants.URL, issue.getField(JIRAConstants.CUSTOMFIELD_URL)
					.toString());
			hmapIssueData.put(JIRAConstants.DETAILS, issue.getField(JIRAConstants.SUMMARY).toString());
			CustomJiraSelectFields methodType = mapper.readValue(issue
					.getField(JIRAConstants.CUSTOMFIELD_METHOD_TYPE)
					.toString(), CustomJiraSelectFields.class);
			if (methodType != null) {
				hmapIssueData.put(JIRAConstants.METHOD_TYPE, methodType.getValue());
			}
			//Download attached schema
			
			hmapIssueData.put(JIRAConstants.EXPECTED_SCHEMA, issue.getField(
					JIRAConstants.CUSTOMFIELD_EXPECTED_SCHEMA).toString());
			getissueSchemaFileAttachment(jira,properties,issue);
			
			
			hmapIssueData.put(JIRAConstants.SWITCHING_MODE, issue.getField(
					JIRAConstants.CUSTOMFIELD_SWITCHING_MODE).toString());
			
			String IPValues=issue.getField(
					JIRAConstants.CUSTOMFIELD_INPUT_VALUES)
					.toString();	
			if (IPValues.contains("DSFlag"))
			{
				List<Map<String , String>> InputData  = GetInputDetails(IPValues);
				for (Map<String, String> IPMapValues : InputData) {
					List<String> issueData = new ArrayList<>();
					issueData.add(hmapIssueData.get(JIRAConstants.ISSUE_TYPE));
					issueData.add(hmapIssueData.get(JIRAConstants.PROJECT));
					
					issueData.add(hmapIssueData.get(JIRAConstants.ISSUE_KEY));
					issueData.add(IPMapValues.get(JIRAConstants.DATASETID));
					if (hmapIssueData.get(JIRAConstants.RUNMODE).equalsIgnoreCase("Yes"))
					{
						if(IPMapValues.get(JIRAConstants.DATAFLAG).equalsIgnoreCase("Yes"))
						{
							issueData.add(hmapIssueData.get(JIRAConstants.RUNMODE));
						}
						else
						{
							issueData.add(JIRAConstants.RUNMODE_VALUE_NO);
						}
					}
					else
					{
						issueData.add(hmapIssueData.get(JIRAConstants.RUNMODE));
					}
					issueData.add(hmapIssueData.get(JIRAConstants.SERVER));
					issueData.add(hmapIssueData.get(JIRAConstants.URL)+IPMapValues.get(JIRAConstants.REFURLValue));
					issueData.add(hmapIssueData.get(JIRAConstants.DETAILS));
					issueData.add(hmapIssueData.get(JIRAConstants.METHOD_TYPE));
					issueData.add(IPMapValues.get(JIRAConstants.HEADER_KEYS));
					issueData.add(IPMapValues.get(JIRAConstants.HEADER_VALUES));
					issueData.add(IPMapValues.get(JIRAConstants.PARAM_KEYS));
					issueData.add(IPMapValues.get(JIRAConstants.PARAM_VALUES));
					issueData.add(IPMapValues.get(JIRAConstants.EXPECTED_KEYS));
					issueData.add(IPMapValues.get(JIRAConstants.EXPECTED_VALUES));
					issueData.add(IPMapValues.get(JIRAConstants.EXPECTED_STATUS_CODE));
					issueData.add(hmapIssueData.get(JIRAConstants.EXPECTED_SCHEMA));
					issueData.add(IPMapValues.get(JIRAConstants.GET_OUTPUT_KEY));
					issueData.add(hmapIssueData.get(JIRAConstants.SWITCHING_MODE));
					issueDatas.add(issueData);
				}
			}
			return issueDatas;
		}
		
	    /***************************************************************************************
		 *  Function name 		: GetInputDetails
		 *  Reuse Function 		:  
		 *  Description 		: Parse and get input detail from the issue fields
		/****************************************************************************************/ 
		public List<Map<String , String>> GetInputDetails(String IPValues)
		{
			List<Map<String , String>> InputData  = new ArrayList<Map<String,String>>();
			try{
				
				String lines[] = IPValues.split(JIRAConstants.RecordDelimiter);
				if (lines.length>1){
					String recordsCol[] = lines[0].split(JIRAConstants.ValueDelimiter);
					for (int i=1;i<lines.length;i++){
						Map<String,String> testCasesInput = new HashMap<String,String>();
						String records[] = lines[i].split(JIRAConstants.ValueDelimiter);
						for (int j=0;j<records.length;j++){
							testCasesInput.put(recordsCol[j].trim(), records[j].trim());
						}
						InputData.add(testCasesInput);
					}
					//System.out.println("Final: "+InputData);
				}
			}
			catch(Exception e){
				System.out.println("Input Values : \n"+IPValues);
				System.out.println("Exception in Getting input fields" + e.getMessage());
			}
			return InputData;
		}
		
	    /***************************************************************************************
		 *  Function name 		: getIssueDetails
		 *  Reuse Function 		:  
		 *  Description 		: Get issue data for the issue
		/****************************************************************************************/ 
		public List<String> getIssueDetails2(Issue issue) throws JsonParseException, JsonMappingException, IOException
		{
		
			List<String> issueData = new ArrayList<>();
			issueData.add(issue.getIssueType().getName());
			issueData.add(issue.getProject().getKey());
			issueData.add(issue.getKey());
			CustomJiraSelectFields runMode = mapper.readValue(
					issue.getField(JIRAConstants.CUSTOMFIELD_RUNMODE)
							.toString(), CustomJiraSelectFields.class);
			if (runMode != null) {
				issueData.add(runMode.getValue());
			}
			issueData.add(issue.getField(JIRAConstants.CUSTOMFIELD_SERVER)
					.toString());
			issueData.add(issue.getField(JIRAConstants.CUSTOMFIELD_URL)
					.toString());
			issueData.add(issue.getField(JIRAConstants.SUMMARY).toString());
			CustomJiraSelectFields methodType = mapper.readValue(issue
					.getField(JIRAConstants.CUSTOMFIELD_METHOD_TYPE)
					.toString(), CustomJiraSelectFields.class);
			if (methodType != null) {
				issueData.add(methodType.getValue());
			}
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_HEADER_KEYS).toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_HEADER_VALUES).toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_PARAM_KEYS).toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_PARAM_VALUES).toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_EXPECTED_KEYS).toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_EXPECTED_VALUES).toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_EXPECTED_STATUS_CODE)
					.toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_EXPECTED_SCHEMA).toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_GET_OUTPUT_KEY).toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_SWITCHING_MODE).toString());
			CustomJiraSelectFields restResult = mapper.readValue(issue
					.getField(JIRAConstants.CUSTOMFIELD_TEST_RESULT_STATUS)
					.toString(), CustomJiraSelectFields.class);
			if (restResult != null) {
				issueData.add(restResult.getValue());
			}
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_RESPONSE_DESCRIPTION)
					.toString());
			issue.getField(
					JIRAConstants.CUSTOMFIELD_RESPONSE_DESCRIPTION)
					.toString();
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_RESPONSE_TIME).toString());
			issueData.add(issue.getField(
					JIRAConstants.CUSTOMFIELD_OUTPUT_VALUES).toString());
			return issueData;
		}
		
	    /***************************************************************************************
		 *  Function name 		: getissueSchemaFileAttachment
		 *  Reuse Function 		:  
		 *  Description 		: download issue schema file for the issue
		/****************************************************************************************/ 
		public void getissueSchemaFileAttachment(JiraClient jira,JiraProperties properties,Issue issue) throws JiraException, IOException
		{
			if (!issue.getAttachments().isEmpty()
					&&(issue.getField(JIRAConstants.CUSTOMFIELD_EXPECTED_SCHEMA).toString() != null)) {
				for (Attachment attach : issue.getAttachments()) {
						Attachment downloadAttachment = Attachment.get(
								jira.getRestClient(), attach.getId());
						File downloadFile = new File(
								properties.getDownloadPath()
										+ attach.getFileName());
						FileOutputStream stream = new FileOutputStream(
								downloadFile);
						try {
							stream.write(downloadAttachment.download());
						} catch (Exception e) {
							errorMessage = "Error in downloading the attachment!!!"
									+ e.getMessage();
							//return errorMessage;
						} finally {
							stream.close();
						}
				}
			}
		}
		
	    /***************************************************************************************
		 *  Function name 		: getdependentIssues
		 *  Reuse Function 		:  
		 *  Description 		: get dependent issues for the issue
		/****************************************************************************************/ 
		public void getdependentIssues(JiraClient jira,JiraProperties properties,Issue issue) throws JiraException, JsonParseException, JsonMappingException, IOException
		{
		//System.out.println("ISSUE : "+issue.getKey());
		if (!DependentList.contains(issue.getKey()))
		{
			///System.out.println("Not in Dependent List : "+issue.getKey());
			if (issue.getIssueLinks().toArray().length > 0) {
				//System.out.println("Contains  Dependent List : "+issue.getKey());
				for (IssueLink issueLink : issue.getIssueLinks()) {
					JSONObject JsonObj = new JSONObject(issueLink);
					if (JsonObj.has(JIRAConstants.OUTWARD_ISSUE)) {
						Issue outwardIssue = jira
								.getIssue(issueLink
										.getOutwardIssue().getKey());
						//System.out.println("Contains  outward Dependent  : "+issue.getKey()+" : "+outwardIssue.getKey());
						getdependentIssues(jira,properties,outwardIssue);
						//System.out.println(issue.getKey()+" : OUTWARD_ISSUE-SUB : "+outwardIssue.getKey());
						if(!DependentList.contains(outwardIssue.getKey())){
							List<List<String >> outwardIssueDatas=getIssueDetails(jira,properties,outwardIssue);
							DependentList.add(outwardIssue.getKey());
							for (List<String> outwardIssueData :outwardIssueDatas){
								dependentFilePrinter.printRecord(outwardIssueData);
							}
						}
					}
					if (JsonObj.has(JIRAConstants.INWARD_ISSUE)) {
						if(!DependentList.contains(issue.getKey())){
							DependentList.add(issue.getKey());
							List<List<String >> issueData1s=getIssueDetails(jira,properties,issue);
							for (List<String> issueData1 :issueData1s){
								dependentFilePrinter.printRecord(issueData1);
							}
						}
						Issue inwardIssue = jira.getIssue(issueLink
								.getInwardIssue().getKey());
						//System.out.println("Contains  inward Dependent  : "+issue.getKey()+" : "+inwardIssue.getKey());
						getdependentIssues(jira,properties,inwardIssue);
						if(!DependentList.contains(inwardIssue.getKey())){
							//System.out.println("Added Inward-SUB :"+inwardIssue.getKey());
							DependentList.add(inwardIssue.getKey());
							List<List<String >> inwardIssueDatas=getIssueDetails(jira,properties,inwardIssue);
							for (List<String> inwardIssueData :inwardIssueDatas){
								dependentFilePrinter.printRecord(inwardIssueData);
							}
						}
					}
				}
				if(!DependentList.contains(issue.getKey())){
					//System.out.println("issue Key Primay added has Putward-SUB : "+issue.getKey());
					DependentList.add(issue.getKey());
					List<List<String >> issueData1s=getIssueDetails(jira,properties,issue);
					for (List<String> issueData1 :issueData1s){
						dependentFilePrinter.printRecord(issueData1);
					}
				}
			}
			}
		}
	
}
