package com.verizon.services;

import java.util.ArrayList;
import com.verizon.pojo.Issue;
import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.util.JIRAConstants;
/**
 * This class is used to read the CSV file.
 *
 */
public class JiraUpdateIssue {

	public String UpdateIssueKey(JiraClient jira,String Issue_Key, String Test_Results,String Resp_Time,String Output_Values)
			throws JiraException 
	{
		// error message construct.
		String errorMessage = null;
		final String TestOpStatus;
		try {
			// initialize FileReader object
			Issue issue = jira.getIssue(Issue_Key);
			/* Update the JIRA Fields. */
			if (Test_Results.equals(JIRAConstants.PASS)) 
			{
				TestOpStatus=JIRAConstants.PASS;
			}
			else
			{
				TestOpStatus=JIRAConstants.FAILED;
				
			}
			
			issue.update()
			.field(JIRAConstants.CUSTOMFIELD_TEST_RESULT_STATUS,
					new ArrayList<Object>() {
				{
					add(TestOpStatus);
				}
			})
			//.field(JIRAConstants.CUSTOMFIELD_RESPONSE_DESCRIPTION,Resp_Description)
			.field(JIRAConstants.CUSTOMFIELD_RESPONSE_TIME,Resp_Time)
			.field(JIRAConstants.CUSTOMFIELD_OUTPUT_VALUES,Output_Values)
			.execute();
			
			return "Data updated Successfully";
		} catch (Exception e) {
			errorMessage = "Error in JiraUpdate Issue !!!" + e.getMessage();
			return errorMessage;
		} 
	}
}
