package com.verizon.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.verizon.pojo.Attachment;
import com.verizon.pojo.CustomJiraSelectFields;
import com.verizon.pojo.Issue;
import com.verizon.pojo.IssueLink;
import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.pojo.Version;
import com.verizon.util.Constants;
import com.verizon.util.JIRAConstants;
import com.verizon.config.JiraProperties;

import net.sf.json.JSONException;
/**
 * This class is used to write the JSON file from JIRA.
 * 
 */
public class JsonJiraExportIssues {
	// error message.
	String errorMessage = null;
	// object mapper creation.
	ObjectMapper mapper = new ObjectMapper();
	// write the csv file.
	// create the JsonTestRep object
    JsonObject JsonTestData = new JsonObject();
	public JsonObject JiraGetIssues(JiraClient jira, JiraProperties properties, String jql)throws JSONException 
	{
		try {
	        Date d = new Date();
	        JsonTestData.addProperty(Constants.JSReportTitle, "API Automation Test Data");
	        JsonTestData.addProperty(Constants.JSRunDate, d.toString());
	        //JsonTestData.addProperty(Constants.JSVersion, CONFIG.getProperty("version"));
	        JsonTestData.addProperty(Constants.JSReleaseVersion, Constants.JIRAReleaseVersion);
	        JsonTestData.addProperty(Constants.JSReleaseDate, Constants.JIRAReleaseDate);
	        JsonTestData.addProperty(Constants.JSTestingType, Constants.JIRATestingType);
			/* Search for issues */
			//String jql = properties.getJql();
			Issue.SearchResult searchResult = jira.searchIssues(jql);
			System.out.print("Exporting JIRA Issues");
			Issue issue = null;
			// create an array called JsonTSuites
		     JsonArray JsonTests = new JsonArray();
			for (Issue searchIssue : searchResult.issues) {
				issue = jira.getIssue(searchIssue.getKey());
				System.out.print(".");
				JsonObject JsonIssueDetails=getIssueDetails(jira,properties,issue);
				JsonArray JsonDependentIssueDetails=getdependentIssues(jira,properties,issue,issue.getIssueType().getName());
				JsonIssueDetails.add(JIRAConstants.DEPENDENTISSUES, JsonDependentIssueDetails);
				JsonTests.add(JsonIssueDetails);
			}
			JsonTestData.add(JIRAConstants.Tests, JsonTests);
			//Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE).create();
		   // System.out.println("Json Value: \n"+gson.toJson(JsonTestData));
			return JsonTestData;
		} catch (NullPointerException e) {
			errorMessage = "Error in Custom Fields!!!" + e.getMessage();
		} catch (Exception e) {
			errorMessage = "Error in CsvFileReader !!!" + e.getMessage();
		} finally {
			System.out.println();
		}
		return JsonTestData;
	}
	/***************************************************************************************
	 *  Function name 		: getIssueDetails
	 *  Reuse Function 		:  
	 *  Description 		: Get issue data for the issue
	/****************************************************************************************/ 
	public JsonObject getIssueDetails(JiraClient jira,JiraProperties properties,Issue issue) throws JsonParseException, JsonMappingException, IOException, JiraException
	{
		 // create a JsonTest
	      JsonObject JsonTest = new JsonObject();
	      JsonTest.addProperty(JIRAConstants.PROJECT, issue.getProject().getKey());
	      JsonTest.addProperty(JIRAConstants.ISSUE_TYPE, issue.getIssueType().getName());
	      JsonTest.addProperty(JIRAConstants.SPRINT, Constants.JIRASprint);
	      JsonTest.addProperty(JIRAConstants.TESTINGTYPE,issue.getLabels().toString());
	      JsonTest.addProperty(JIRAConstants.ISSUE_KEY, issue.getKey());
	      List<Version> FixVersions=issue.getFixVersions();
	      for (Version ver:FixVersions){
				JsonTest.addProperty(JIRAConstants.FIXVERSION,ver.getName());
				JsonTest.addProperty(JIRAConstants.FIXRELEASEDATE,ver.getReleaseDate());
				Constants.JIRAReleaseVersion=ver.getName();
				Constants.JIRAReleaseDate=ver.getReleaseDate();
	      }
	      CustomJiraSelectFields runMode = mapper.readValue(
					issue.getField(JIRAConstants.CUSTOMFIELD_RUNMODE)
							.toString(), CustomJiraSelectFields.class);
	      if (runMode != null) {
			JsonTest.addProperty(JIRAConstants.RUNMODE, runMode.getValue());
	      }
		JsonTest.addProperty(JIRAConstants.SERVER, issue.getField(JIRAConstants.CUSTOMFIELD_SERVER)
				.toString());
		JsonTest.addProperty(JIRAConstants.URL, issue.getField(JIRAConstants.CUSTOMFIELD_URL)
				.toString());
		JsonTest.addProperty(JIRAConstants.DETAILS, issue.getField(JIRAConstants.SUMMARY).toString());
		CustomJiraSelectFields methodType = mapper.readValue(issue
				.getField(JIRAConstants.CUSTOMFIELD_METHOD_TYPE)
				.toString(), CustomJiraSelectFields.class);
		if (methodType != null) {
			JsonTest.addProperty(JIRAConstants.METHOD_TYPE, methodType.getValue());
		}
		//Download attached schema
		
		JsonTest.addProperty(JIRAConstants.EXPECTED_SCHEMA, issue.getField(
				JIRAConstants.CUSTOMFIELD_EXPECTED_SCHEMA).toString());
		getissueSchemaFileAttachment(jira,properties,issue);
		
		
		JsonTest.addProperty(JIRAConstants.SWITCHING_MODE, issue.getField(
				JIRAConstants.CUSTOMFIELD_SWITCHING_MODE).toString());
		
		String IPValues=issue.getField(
				JIRAConstants.CUSTOMFIELD_INPUT_VALUES)
				.toString();	
		if (IPValues.contains("DSFlag"))
		{
			JsonArray InputData  = GetInputDetails(IPValues);
			JsonTest.add(JIRAConstants.DATASETS, InputData);
		}
		
		return JsonTest;
		}
	
		/***************************************************************************************
		 *  Function name 		: GetInputDetails
		 *  Reuse Function 		:  
		 *  Description 		: Parse and get input detail from the issue fields
		/****************************************************************************************/ 
		public JsonArray GetInputDetails(String IPValues)
		{
		  // create an array called SuiteTests
		  JsonArray JSDataSets = new JsonArray();
		 
	      try{
				String lines[] = IPValues.split(JIRAConstants.RecordDelimiter);
				if (lines.length>1){
					String recordsCol[] = lines[0].split(JIRAConstants.ValueDelimiter);
					for (int i=1;i<lines.length;i++){
						 // create a SuiteTest
					      JsonObject JSDataSet = new JsonObject();
						String records[] = lines[i].split(JIRAConstants.ValueDelimiter);
						for (int j=0;j<records.length;j++){
							JSDataSet.addProperty(recordsCol[j].trim(), records[j].trim());
						}
						JSDataSets.add(JSDataSet);
					}
					//System.out.println("Final: "+JSDataSets);
				}
			}
			catch(Exception e){
				System.out.println("Input Values : \n"+IPValues);
				System.out.println("Exception in Getting input fields" + e.getMessage());
			}
			return JSDataSets;
		}
		
	   
	    /***************************************************************************************
		 *  Function name 		: getissueSchemaFileAttachment
		 *  Reuse Function 		:  
		 *  Description 		: download issue schema file for the issue
		/****************************************************************************************/ 
		public void getissueSchemaFileAttachment(JiraClient jira,JiraProperties properties,Issue issue) throws JiraException, IOException
		{
			if (!issue.getAttachments().isEmpty()
					&&(issue.getField(JIRAConstants.CUSTOMFIELD_EXPECTED_SCHEMA).toString() != null)) {
				for (Attachment attach : issue.getAttachments()) {
						Attachment downloadAttachment = Attachment.get(
								jira.getRestClient(), attach.getId());
						File downloadFile = new File(
								properties.getDownloadPath()
										+ attach.getFileName());
						FileOutputStream stream = new FileOutputStream(
								downloadFile);
						try {
							stream.write(downloadAttachment.download());
						} catch (Exception e) {
							errorMessage = "Error in downloading the attachment!!!"
									+ e.getMessage();
							//return errorMessage;
						} finally {
							stream.close();
						}
				}
			}
		}
		
		
		 /***************************************************************************************
		 *  Function name 		: getdependentIssues
		 *  Reuse Function 		:  
		 *  Description 		: get dependent issues for the issue for JSON
		/****************************************************************************************/ 
		public JsonArray getdependentIssues(JiraClient jira,JiraProperties properties,Issue issue,String istype) throws JiraException, JsonParseException, JsonMappingException, IOException
		{

			  // create an array called SuiteTests
			  JsonArray JSDependentSets = new JsonArray();
			  
		    
			if (issue.getIssueLinks().toArray().length > 0) {
				for (IssueLink issueLink : issue.getIssueLinks()) {
					JSONObject JsonObj = new JSONObject(issueLink);
					
					if (JsonObj.has(JIRAConstants.OUTWARD_ISSUE)) {
						JsonObject JsonOutwardIssueDetails=new JsonObject();
						Issue outwardIssue = jira
								.getIssue(issueLink
										.getOutwardIssue().getKey());
						if(outwardIssue.getIssueType().getName().equalsIgnoreCase(istype)){
							JsonOutwardIssueDetails.addProperty(JIRAConstants.ISSUE_KEY, outwardIssue.getKey());
							//JsoninwardIssueDetails=getIssueDetails2(jira,properties,issue);
						}
						JSDependentSets.add(JsonOutwardIssueDetails);
					}
//					if (JsonObj.has(JIRAConstants.INWARD_ISSUE)) {
//						JsonObject JsoninwardIssueDetails=new JsonObject();
//						Issue inwardIssue = jira.getIssue(issueLink
//								.getInwardIssue().getKey());
//						if(inwardIssue.getIssueType().getName().equalsIgnoreCase(istype)){
//							JsoninwardIssueDetails.addProperty(JIRAConstants.ISSUE_KEY, inwardIssue.getKey());
//							//JsoninwardIssueDetails=getIssueDetails2(jira,properties,issue);
//						}
//						JSDependentSets.add(JsoninwardIssueDetails);
//					}
				
				}
				
			}
			return JSDependentSets;
		}
	
}
