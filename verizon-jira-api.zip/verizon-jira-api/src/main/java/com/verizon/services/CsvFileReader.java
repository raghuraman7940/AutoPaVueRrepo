package com.verizon.services;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang.StringUtils;

import com.verizon.pojo.Issue;
import com.verizon.pojo.JiraClient;
import com.verizon.pojo.JiraException;
import com.verizon.util.JIRAConstants;
import com.verizon.config.JiraProperties;

/**
 * This class is used to read the CSV file.
 *
 */
public class CsvFileReader {

	// Read csv file.
	@SuppressWarnings({ "resource", "serial" })
	public String readCsvFile(JiraClient jira, JiraProperties properties)
			throws JiraException {
		// file reader initiation.
		FileReader fileReader = null;
		// error message construct.
		String errorMessage = null;
		CSVParser parser = null;
		try {
			// initialize FileReader object
			File file = new File(properties.getCsvFileImport());
			fileReader = new FileReader(file);

			// Create the CSVFormat object
			CSVFormat format = CSVFormat.RFC4180.withHeader()
					.withDelimiter(',');

			// initialize the CSVParser object
			parser = new CSVParser(fileReader, format);
			for (final CSVRecord record : parser) {
				try {
					Issue issue = jira.getIssue(record
							.get(JIRAConstants.ISSUE_KEY));
					/* Update the JIRA Fields. */
					if (record.get(JIRAConstants.RUNMODE).equals(
							JIRAConstants.RUNMODE_VALUE_YES)
							&& StringUtils.isNotEmpty(record
									.get(JIRAConstants.RUNMODE))
							&& !record.get(JIRAConstants.RUNMODE).equals(
									JIRAConstants.NULL_VALUE)) {
						issue.update()
								.field(JIRAConstants.CUSTOMFIELD_RUNMODE,
										new ArrayList<Object>() {
											{
												add(record
														.get(JIRAConstants.RUNMODE));
											}
										}).execute();
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.SERVER))
								&& !record.get(JIRAConstants.SERVER).equals(
										JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_SERVER,
											record.get(JIRAConstants.SERVER))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.URL))
								&& !record.get(JIRAConstants.URL).equals(
										JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_URL,
											record.get(JIRAConstants.URL))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.METHOD_TYPE))
								&& !record.get(JIRAConstants.METHOD_TYPE)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_METHOD_TYPE,
											new ArrayList<Object>() {
												{
													add(record
															.get(JIRAConstants.METHOD_TYPE));
												}
											}).execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.HEADER_KEYS))
								&& !record.get(JIRAConstants.HEADER_KEYS)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_HEADER_KEYS,
											record.get(JIRAConstants.HEADER_KEYS))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.HEADER_VALUES))
								&& !record.get(JIRAConstants.HEADER_VALUES)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_HEADER_VALUES,
											record.get(JIRAConstants.HEADER_VALUES))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.PARAM_KEYS))
								&& !record.get(JIRAConstants.PARAM_KEYS)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_PARAM_KEYS,
											record.get(JIRAConstants.PARAM_KEYS))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.PARAM_VALUES))
								&& !record.get(JIRAConstants.PARAM_VALUES)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_PARAM_VALUES,
											record.get(JIRAConstants.PARAM_VALUES))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.EXPECTED_KEYS))
								&& !record.get(JIRAConstants.EXPECTED_KEYS)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_EXPECTED_KEYS,
											record.get(JIRAConstants.EXPECTED_KEYS))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.EXPECTED_VALUES))
								&& !record.get(JIRAConstants.EXPECTED_VALUES)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_EXPECTED_VALUES,
											record.get(JIRAConstants.EXPECTED_VALUES))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.EXPECTED_STATUS_CODE))
								&& !record.get(
										JIRAConstants.EXPECTED_STATUS_CODE)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_EXPECTED_STATUS_CODE,
											record.get(JIRAConstants.EXPECTED_STATUS_CODE))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.EXPECTED_SCHEMA))
								&& !record.get(JIRAConstants.EXPECTED_SCHEMA)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_EXPECTED_SCHEMA,
											record.get(JIRAConstants.EXPECTED_SCHEMA))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.SWITCHING_MODE))
								&& !record.get(JIRAConstants.SWITCHING_MODE)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_SWITCHING_MODE,
											record.get(JIRAConstants.SWITCHING_MODE))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.SWITCHING_MODE))
								&& !record.get(JIRAConstants.SWITCHING_MODE)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_SWITCHING_MODE,
											record.get(JIRAConstants.SWITCHING_MODE))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.TEST_RESULT_STATUS))
								&& !record
										.get(JIRAConstants.TEST_RESULT_STATUS)
										.equals(JIRAConstants.NULL_VALUE)) {
							if (record.get(JIRAConstants.TEST_RESULT_STATUS)
									.equals(JIRAConstants.PASS)) {
								issue.update()
										.field(JIRAConstants.CUSTOMFIELD_TEST_RESULT_STATUS,
												new ArrayList<Object>() {
													{
														add(JIRAConstants.PASS);
													}
												}).execute();
							} else {
								issue.update()
										.field(JIRAConstants.CUSTOMFIELD_TEST_RESULT_STATUS,
												new ArrayList<Object>() {
													{
														add(JIRAConstants.FAILED);
													}
												}).execute();
							}
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.RESPONSE_DESCRIPTION))
								&& !record.get(
										JIRAConstants.RESPONSE_DESCRIPTION)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_RESPONSE_DESCRIPTION,
											record.get(JIRAConstants.RESPONSE_DESCRIPTION))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.RESPONSE_TIME))
								&& !record.get(JIRAConstants.RESPONSE_TIME)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_RESPONSE_TIME,
											record.get(JIRAConstants.RESPONSE_TIME))
									.execute();
						}
						if (StringUtils.isNotEmpty(record
								.get(JIRAConstants.OUTPUT_VALUES))
								&& !record.get(JIRAConstants.OUTPUT_VALUES)
										.equals(JIRAConstants.NULL_VALUE)) {
							issue.update()
									.field(JIRAConstants.CUSTOMFIELD_OUTPUT_VALUES,
											record.get(JIRAConstants.OUTPUT_VALUES))
									.execute();
						}
					}
				} catch (Exception e) {
					errorMessage = "Error in Issue update!!!" + e.getMessage();
					return errorMessage;
				}

			}
			return "Data updated Successfully";

		} catch (Exception e) {
			errorMessage = "Error in CsvFileReader !!!" + e.getMessage();
			return errorMessage;
		} finally {
			try {
				// close the file reader object.
				fileReader.close();
			} catch (IOException e) {
				errorMessage = "Error while closing fileReader/csvFileParser !!!"
						+ e.getMessage();
				return errorMessage;
			}
		}
	}
}
