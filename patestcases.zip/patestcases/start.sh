#!/bin/bash 

echo "[CMD] Starting Cucumber Regression Test"
echo "[CMD] Static file"
# cd pa-refresh-auto
# java -cp pa-refresh-auto-0.0.1-SNAPSHOT.jar:pa-refresh-auto-0.0.1-SNAPSHOT-tests.jar:libs/* -Dbrowser=CHROME -Denvironment=PAACP -Dheadless=YES -Dostype=LINUX -Dexecutiontype=LOCAL "-Dcucumber.options=--tags @sample" org.testng.TestNG TestngCrossRun.xml
# mvn clean test -Dbrowser=CHROME -Denvironment=PAACP -Dheadless=YES -Dostype=LINUX -Dexecutiontype=LOCAL "-Dcucumber.options=--tags @sample"
mvn clean test "-Dconfig.file=confd/conf.d/Configuration.properties.toml" "-Dcucumber.options=--tags @sample"

#aws s3 cp ./pa-refresh-auto/custom_report/LatestReport/ s3://pauir-automationreports/UIReports
aws s3 cp ./pa-refresh-auto/custom_report/LatestReport/UM_Execution_Resultwss_Desktop.htm s3://pauir-automationreports/UIReports
