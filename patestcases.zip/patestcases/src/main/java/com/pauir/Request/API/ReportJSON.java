package com.pauir.Request.API;

import java.io.*;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.pauir.common.core.FileReaderManager;
import com.pauir.common.util.Constants;

import com.pauir.common.util.Xls_Reader;
import webdriver.main.Log;
import webdriver.main.UMReporter;



public class ReportJSON {
	public static String result_FolderName=null;
	public static App API;
	/**
	 * Constructor for initializing the Object.
	 * @throws IOException 
	 */
	public ReportJSON() throws IOException {
		// Initialize the 	
		API=new App();
	}
	public static void main(String[] arg) throws Exception {
		ReportJSON Rep=new ReportJSON();
		
		//Generate Testdata json from Excel
		JSONObject JsonGLBHeader = new JSONObject();
		JsonGLBHeader.put("content-type", "application/json");
		JsonGLBHeader.put("orgreferenceid", "d3d6bc4e-2bb1-41b2-865bList-52c0a6c23e75");
		JsonGLBHeader.put("authorization", "Bearer eyJraWQiOiJLNE9DelU5MG1Wd3IzRWJpeEFsQ2Y0ckZUb3RxSEJDZjBtVzVRMUl6S1hZPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI3OWEyNTY1Zi1iNzgwLTRlZTEtYWI4Yi04MmU5YWM2MWUyZTIiLCJ0b2tlbl91c2UiOiJhY2Nlc3MiLCJzY29wZSI6ImF3cy5jb2duaXRvLnNpZ25pbi51c2VyLmFkbWluIG9wZW5pZCBlbWFpbCIsImF1dGhfdGltZSI6MTU3ODM4NjE5MywiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tXC91cy1lYXN0LTFfT2hxQWVxalNkIiwiZXhwIjoxNTc4Mzg5Nzk2LCJpYXQiOjE1NzgzODYxOTYsInZlcnNpb24iOjIsImp0aSI6ImVmNzk3OTFiLWRmMTItNDExNi1iZmMyLTg4MjdiZjA1YmYzYSIsImNsaWVudF9pZCI6IjM2azI4dWNlZGV2bGZlNDJzMjRpODdya2swIiwidXNlcm5hbWUiOiJwYWFkbWluQHBlYXJzb24uY29tIn0.SRwylZC0tHb1kDkl5LvYCZs3-56wVUsToX6lDVpkoBeP7YkUZ9H8itV6CLhKfoNlJqavCDWV9s5XDn87QRekW3lzUVPLX45rZbR_56oo-_hHWQU9x0CqGqtHCHG3K4wSDSdsyVhJb4LBGzhHu7_7SKzIOIyPkUVVIYR6FeqEvL73_zn0lJp_dvXaGyAarUr3_WUqZctGO7awKDzwjhSh1Fe9zCZvsNhbsL6jHqWwEYYE-9bmyHrnZ1fkfY-PSP3qtgny6cruaMngMnfSdRg4xpvMmYOZFbAm_gp7aXcGa5kljw7MBVXWo5fVeJDjl2IisVgE26m-fBC_C9FDPB4gRg");
		
		String XlsxInputFile = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() +Constants.TEST_XLFILE;
	    String XLInputSheetName="APIRegressionSUITE"; //APIUserroleSUITE//APIRegressionSUITE//APIUserroleSUITE
		String Testdatafile = null;
		if (XLInputSheetName.equalsIgnoreCase("APIUserroleSUITE")) {
	    	Testdatafile=Constants.TEST_JSFILE_UserRole;
	    	Constants.TestingType=Constants.TEST_UserRoleType;
	    }
	    else if (XLInputSheetName.equalsIgnoreCase("APIRegressionSUITE")) {
	    	Testdatafile=Constants.TEST_JSFILE_Regression;
	    	Constants.TestingType=Constants.TEST_RegressionType;
	    }
	    else
	    {
	    	Testdatafile=Constants.TEST_JSFILE_Smoke;
	    	Constants.TestingType=Constants.TEST_SmokeType;
	    }
		//Get Excel into Json
		JSONObject JsonTestData =Rep.GenerateTestDataFromExcelData(XlsxInputFile,XLInputSheetName,JsonGLBHeader);
		//	System.out.println(JsonTestData.toString());
		
		//Store in Suite JSON file
	   String TestFilePath = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath()+Testdatafile;
	      try (FileWriter file = new FileWriter(TestFilePath)) {
	            file.write(JsonTestData.toString(4));
	            file.flush();
	      } catch (IOException e) {
	        	 System.err.println("Error: " + e.getMessage());
	      }
		
			//Generate html report from Outdata.json
//			File file = new File(System.getProperty("user.dir")+"\\downloads\\Response\\TestdataOutputData_202003261058.json"); 			
//			String jsoncontent = FileUtils.readFileToString(file, "utf-8");
//			JSONObject JsonTestData = new JSONObject(jsoncontent);
//			JSONObject jsonRep= Rep.BuildJSONReport(JsonTestData);
//			System.out.println(jsonRep.toString());
//			Rep.GeneratehtmlReport(jsonRep,"");
			
//			//Generate Swagger json into Excel Swagger
//			String XlsxInputFile = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() +Constants.TEST_XLFILE;
//		    String XLInputSheetName="APISwaggerSUITE";
//			GenerateExcelTestDataFromSwagger(XlsxInputFile,XLInputSheetName);
					
//			//Generate html report from Outdata.json
//			File file = new File(System.getProperty("user.dir")+"\\downloads\\Response\\TestdataOutputData_Admin_202010261033.json"); 			
//			String jsoncontent = FileUtils.readFileToString(file, "utf-8");
//			JSONObject JsonTestData = new JSONObject(jsoncontent);
//			JSONObject jsonRep= Rep.BuildUSERPERJSONReport(JsonTestData,Constants.UserRoleAdmin,"userole");
//			
//			file = new File(System.getProperty("user.dir")+"\\downloads\\Response\\TestdataReport_TestCoordinator_202010231245.json"); 			
//			jsoncontent = FileUtils.readFileToString(file, "utf-8");
//			JsonTestData = new JSONObject(jsoncontent);
//			jsonRep = Rep.UpdateBuildUSERPERJSONReport(jsonRep,JsonTestData,Constants.UserRoleTestCoordinator);
//			
//			file = new File(System.getProperty("user.dir")+"\\downloads\\Response\\TestdataReport_Teacher_202010231247.json"); 			
//			jsoncontent = FileUtils.readFileToString(file, "utf-8");
//			JsonTestData = new JSONObject(jsoncontent);
//			jsonRep = Rep.UpdateBuildUSERPERJSONReport(jsonRep,JsonTestData,Constants.UserRoleTeacher);
//			
//			file = new File(System.getProperty("user.dir")+"\\downloads\\Response\\TestdataReport_TestCoordinator_Interim_202010231247.json"); 			
//			jsoncontent = FileUtils.readFileToString(file, "utf-8");
//			JsonTestData = new JSONObject(jsoncontent);
//			jsonRep = Rep.UpdateBuildUSERPERJSONReport(jsonRep,JsonTestData,Constants.UserRoleTestCoordinatorInterim);
//			
//			System.out.println(jsonRep.toString());
//			Rep.GenerateUserRolesOverviewhtmlReport(jsonRep,null);    
	   
	      
//		File file = new File(System.getProperty("user.dir")+"\\downloads\\Response\\TestdataOutputData_SystemAdmin_202104051045.json"); 			
//		String jsoncontent = FileUtils.readFileToString(file, "utf-8");
//		JSONObject JsonTestData = new JSONObject(jsoncontent);
//		JSONObject jsonRep= Rep.BuildUSERPERJSONReportwithlength(JsonTestData,Constants.UserRoleAdmin,"userole");
//		System.out.println(jsonRep.toString());
//		
//		Rep.GenerateUserRolesOverviewhtmlReportLength(jsonRep,null);
	}

	/***************************************************************************************
 	 *  Function name 		: GenerateUserrolesOverview
 	 *  Reuse Function 		:  
 	 *  Description 		: To generate user roles Overview
 	/
	 * @throws Exception ****************************************************************************************/
	public void GenerateUserrolesOverview() throws Exception {
		if ((Constants.mapUserroleJsonOutputfiles.size()>2)&&(Constants.mapUserroleJsonReportfiles.size()>2)&&(Constants.mapUserrolehtmlReportfiles.size()>2)) {
			boolean isfirstReport=true;
			String sUserRoleOutputFile=null;
			JSONObject jsonRep=null;
			JSONObject JsonTestData =null;
			File file =null;
			System.out.println("mapUserroleJsonOutputfiles : " + Constants.mapUserroleJsonOutputfiles );
			System.out.println("mapUserroleJsonReportfiles : " + Constants.mapUserroleJsonReportfiles );
			for (Map.Entry<String,String> entry : Constants.mapUserroleJsonReportfiles.entrySet()){
	            System.out.println("Userrole  : " + entry.getKey() );
	            System.out.println("Userrole - File  : " + entry.getValue() );
	            String sUserRole= entry.getKey();
	            String sUserRoleFile= entry.getValue();
	            if (isfirstReport) {
	            	sUserRoleOutputFile= Constants.mapUserroleJsonOutputfiles.get(sUserRole);
	            	file = new File(sUserRoleOutputFile); 			
	    			String jsoncontent = FileUtils.readFileToString(file, "utf-8");
	    			JsonTestData = new JSONObject(jsoncontent);
	    			jsonRep= BuildUSERPERJSONReport(JsonTestData,sUserRole,"userole");
	    			isfirstReport=false;
	            }
	            else {
	            	file = new File(sUserRoleFile); 			
	    			String jsoncontent = FileUtils.readFileToString(file, "utf-8");
	    			JsonTestData = new JSONObject(jsoncontent);
	    			if (jsonRep!=null)
	    				jsonRep = UpdateBuildUSERPERJSONReport(jsonRep,JsonTestData,sUserRole);
	            }
			}
			//System.out.println(jsonRep.toString());
			API.StoreRespose("TestdataUserRolesReportData","json",jsonRep.toString());
			GenerateUserRolesOverviewhtmlReport(jsonRep,Constants.mapUserrolehtmlReportfiles);  
		}
	}

	/***************************************************************************************
 	 *  Function name 		: GenerateJSONReport
 	 *  Reuse Function 		:  
 	 *  Description 		: To generate excel testresult into JSON
 	/****************************************************************************************/ 
	public JSONObject UpdateBuildUSERPERJSONReport(JSONObject JsonTestReport,JSONObject JsonUserReport,String Userrole)
	{
	     //Initialize Test case summary Count    
		JSONObject jsReportData = new JSONObject(JsonTestReport.toString());
		JSONObject jsUserReportData = new JSONObject(JsonUserReport.toString());
		try{
			
			 JSONArray Suites = jsReportData.getJSONArray("suite");
			 JSONArray Suites1 = jsUserReportData.getJSONArray("suite");
			 JSONArray JsonUserroleTSuites = jsReportData.getJSONArray(Constants.JSUsersuite);

			  for(int currentSuiteID=0;currentSuiteID<Suites.length();currentSuiteID++){
				  JSONObject Suite = Suites.getJSONObject(currentSuiteID);
				  JSONObject Suite1 = Suites1.getJSONObject(currentSuiteID);
				  JSONObject JsonUserroleTSuite = new JSONObject();
				  
				  
				  JsonUserroleTSuite.put(Constants.JSProject, Suite1.getString(Constants.JSProject));
				  JsonUserroleTSuite.put(Constants.JSTestingType, Suite1.getString(Constants.JSTestingType));
				  JsonUserroleTSuite.put(Constants.JSExecutionDuration, Suite1.getString(Constants.JSExecutionDuration));
				  JsonUserroleTSuite.put(Constants.JSUserRole, Suite1.getString(Constants.JSUserRole));
				  
				  JSONArray TestSets = Suite.getJSONArray("tests");
				  JSONArray TestSets1 = Suite1.getJSONArray("tests");
				 
				  for(int currentTestCaseID=0;currentTestCaseID<TestSets.length();currentTestCaseID++){
					JSONObject TestSet = TestSets.getJSONObject(currentTestCaseID);
					JSONObject TestSet1 = TestSets1.getJSONObject(currentTestCaseID);
					
//					String TestCaseid=TestSet.getString(Constants.RepIssue_key);
//					TestCaseid=TestSet1.getString(Constants.RepIssue_key);
					
					//Update Testset Status
					String TestsetStatus=TestSet1.getString(Constants.RepTestResultStatus);
					TestSet.put(Userrole, TestsetStatus);
					
					JSONArray ArrDataSets = TestSet.getJSONArray(Constants.JSsuitDataSets);
					JSONArray ArrDataSets1 = TestSet1.getJSONArray(Constants.JSsuitDataSets);
					for(int currentDatSetID=0;currentDatSetID<ArrDataSets.length();currentDatSetID++){
						JSONObject TestDataSet = ArrDataSets.getJSONObject(currentDatSetID);
						JSONObject TestDataSet1 = ArrDataSets1.getJSONObject(currentDatSetID);
						
//						String DataTestsetid=TestDataSet.getString(Constants.DATASETID);
//						DataTestsetid=TestDataSet1.getString(Constants.DATASETID);
						
						//Update TestDataset Status
						String TestDatasetStatus=TestDataSet1.getString(Constants.RepTestResultStatus);
						TestDataSet.put(Userrole, TestDatasetStatus);
						
					}
				  }
				  
				  JsonUserroleTSuite.put(Constants.JSsuiteStatus, Suite1.getString(Constants.JSsuiteStatus));
				  JsonUserroleTSuite.put(Constants.JSsuiteNoOfTestCases, Suite1.get(Constants.JSsuiteNoOfTestCases));
				  JsonUserroleTSuite.put(Constants.JSsuiteNoOfPassed, Suite1.get(Constants.JSsuiteNoOfPassed));
				  JsonUserroleTSuite.put(Constants.JSsuiteNoOfFailed, Suite1.get(Constants.JSsuiteNoOfFailed));
				  JsonUserroleTSuite.put(Constants.JSsuitNoOfSkipped, Suite1.get(Constants.JSsuitNoOfSkipped));
				  JsonUserroleTSuites.put(JsonUserroleTSuite);
			   	}
			  
			  jsReportData.put(Constants.JSUsersuite, JsonUserroleTSuites);
		
			  // System.out.println("Input ReportData : \n"+JsonTestReport);
			  //System.out.println("Final ReportData : \n"+jsReportData);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	      return jsReportData;
	}
	
	/***************************************************************************************
 	 *  Function name 		: GenerateJSONReport
 	 *  Reuse Function 		:  
 	 *  Description 		: To generate excel testresult into JSON
 	/****************************************************************************************/ 
	public JSONObject BuildUSERPERJSONReport(JSONObject JsonTestReport,String Userrole, String TestingType)
	{
	     //Initialize Test case summary Count
		int iNoOfTestCase=0,iNoOfPass = 0,iNoOfFail=0,iNoOfSkip=0;    
		JSONObject jsTestData = new JSONObject(JsonTestReport.toString());
		JSONObject jsReportData = new JSONObject();
		try{
			
		//System.out.println("Input ReportData : "+JsonTestReport);
		//Create Report Folder
		Date d = new Date();
		String FS_Userrole=Userrole.replace(" ", "");
		 // Add test report details
		jsReportData.put(Constants.JSReportTitle, "PAUIR Automation API User roles Test Report");
		jsReportData.put(Constants.JSRunDate, d.toString());
		jsReportData.put(Constants.JSRunEnvironment, FileReaderManager.getInstance().getConfigReader().getEnvironment());
		jsReportData.put(Constants.JSTestingType, TestingType);
		jsReportData.put(Constants.JSUserRole, FS_Userrole);
	   
	      JSONArray JsonTSuites = new JSONArray();
	      JSONArray JsonUserroleTSuites = new JSONArray();
	      for (int iSuiteIter = 0; iSuiteIter < 1; iSuiteIter++)
	      {
	    	  String suite_result="";
		  // create a JsonTSuite
	      JSONObject JsonTSuite = new JSONObject();
	      JSONObject JsonUserroleTSuite = new JSONObject();
	      JsonTSuite.put(Constants.JSProject, Constants.JIRAProject);
	      JsonUserroleTSuite.put(Constants.JSProject, Constants.JIRAProject);
	      JsonTSuite.put(Constants.JSTestingType, TestingType);
	      JsonUserroleTSuite.put(Constants.JSTestingType, TestingType);
	      JsonTSuite.put(Constants.JSExecutionDuration, jsTestData.getString(Constants.JSExecutionDuration));
	      JsonUserroleTSuite.put(Constants.JSExecutionDuration, jsTestData.getString(Constants.JSExecutionDuration));
	      JsonTSuite.put(Constants.JSUserRole, FS_Userrole);
	      JsonUserroleTSuite.put(Constants.JSUserRole, FS_Userrole);
	      //Tests
	      JSONArray TestSets = (JSONArray) jsTestData.get("Tests");
        
	      //Tests Report
	      JSONArray RepTests = new JSONArray();
	      for (int iTestIter = 0; iTestIter < TestSets.length(); iTestIter++) {
        	JSONObject Testset = TestSets.getJSONObject(iTestIter);
        	JSONObject jsTestReps = new JSONObject();
        	jsTestReps.put(Constants.RepIssue_key, Testset.get(Constants.TCID).toString());
		  	jsTestReps.put(Constants.RepAPIMethodType, Testset.get(Constants.MethodType).toString());
		  	jsTestReps.put(Constants.RepAPIURL, Testset.get(Constants.RepAPIRequest).toString());
		  	jsTestReps.put(Constants.RepAPIDescription, Testset.get(Constants.Summary).toString());
		  	jsTestReps.put(Constants.RepTestResultStatus,  Testset.get(Constants.TestStatus).toString());
		  	jsTestReps.put(FS_Userrole,  Testset.get(Constants.TestStatus).toString());
		  	jsTestReps.put(Constants.UserPermissions,  Testset.get(Constants.UserPermissions).toString());
            //DataSets
		  	int iNoOfTestDS=0,iNoOfDSPass = 0,iNoOfDSFail=0,iNoOfDSSkip=0;
		  	JSONArray RepArrDataSets = new JSONArray();
            JSONArray DataSets = (JSONArray) Testset.get("Datasets");
            for (int iDataIter = 0; iDataIter < DataSets.length(); iDataIter++) {
            	JSONObject DataSet = DataSets.getJSONObject(iDataIter);
            	
            	JSONObject jsTestDSReps = new JSONObject();
            	
            	iNoOfTestCase=iNoOfTestCase+1;
            	iNoOfTestDS=iNoOfTestDS+1;
            	String TestResults=DataSet.getJSONObject("Output").get(Constants.RESULT).toString();
            	  if((TestResults.startsWith("Pass") || TestResults.startsWith("PASS"))){
					  iNoOfPass=iNoOfPass+1;
					  iNoOfDSPass=iNoOfDSPass+1;
				  }
				  else if((TestResults.startsWith("Fail") || TestResults.startsWith("FAIL"))){
					  iNoOfFail=iNoOfFail+1;
					  iNoOfDSFail=iNoOfDSFail+1;
					  if(suite_result.equals(""))
						  suite_result=Constants.KEYWORD_FAIL;
				  }
				  else if((TestResults.startsWith("Skip") ||TestResults.startsWith("skip")|| TestResults.startsWith("SKIP")||TestResults.isEmpty())){
					  TestResults=Constants.KEYWORD_SKIP;
					  iNoOfSkip=iNoOfSkip+1;
					  iNoOfDSSkip=iNoOfDSSkip+1;
				  }
            	
            	  jsTestDSReps.put(Constants.DATASET, DataSet.get(Constants.DATASET).toString());
            	  jsTestDSReps.put(Constants.UserPermissions, DataSet.get(Constants.UserPermissions).toString());
            	  jsTestDSReps.put(Constants.DataDescription, DataSet.get(Constants.DataDescription).toString());
            	  jsTestDSReps.put(Constants.RepAPIRequest, DataSet.get(Constants.RepAPIURL).toString());
            	  jsTestDSReps.put(Constants.RepTestResultStatus, TestResults);
            	  jsTestDSReps.put(FS_Userrole, TestResults);
            	  jsTestDSReps.put(Constants.RepStatusCode, DataSet.getJSONObject(Constants.output).get(Constants.RepStatusCode).toString());
            	  jsTestDSReps.put(Constants.RepResponseDescription, DataSet.getJSONObject(Constants.output).get(Constants.RepResponseDescription).toString());	  
            	  jsTestDSReps.put(Constants.RepResponseTime, DataSet.getJSONObject(Constants.output).get(Constants.RepResponseTime).toString());
            	 
            	
            	  RepArrDataSets.put(jsTestDSReps);
            }
            
            jsTestReps.put(Constants.JSsuitDataSets, RepArrDataSets);
            
            jsTestReps.put(Constants.JSsuiteNoOfTestCases, iNoOfTestDS);
            jsTestReps.put(Constants.JSsuiteNoOfPassed, iNoOfDSPass);
            jsTestReps.put(Constants.JSsuiteNoOfFailed, iNoOfDSFail);
            jsTestReps.put(Constants.JSsuitNoOfSkipped, iNoOfDSSkip);
  		  
            RepTests.put(jsTestReps);
           
	      	}
	      JsonTSuite.put(Constants.JSsuitTest, RepTests);
	      
	      if(suite_result.equals("FAIL")) {
			  JsonTSuite.put(Constants.JSsuiteStatus, "Fail");
			  JsonTSuite.put(FS_Userrole, "Fail");
			  JsonUserroleTSuite.put(Constants.JSsuiteStatus, "Fail");
			  
	      }
		  else {
			  JsonTSuite.put(Constants.JSsuiteStatus, "Pass");
			  JsonTSuite.put(FS_Userrole, "Pass");
			  JsonUserroleTSuite.put(Constants.JSsuiteStatus, "Pass");
		  }
	      
	      JsonTSuite.put(Constants.JSsuiteNoOfTestCases, iNoOfTestCase);
	      JsonUserroleTSuite.put(Constants.JSsuiteNoOfTestCases, iNoOfTestCase);
		  JsonTSuite.put(Constants.JSsuiteNoOfPassed, iNoOfPass);
		  JsonUserroleTSuite.put(Constants.JSsuiteNoOfPassed, iNoOfPass);
		  JsonTSuite.put(Constants.JSsuiteNoOfFailed, iNoOfFail);
		  JsonUserroleTSuite.put(Constants.JSsuiteNoOfFailed, iNoOfFail);
		  JsonTSuite.put(Constants.JSsuitNoOfSkipped, iNoOfSkip);
		  JsonUserroleTSuite.put(Constants.JSsuitNoOfSkipped, iNoOfSkip);
		  JsonTSuites.put(JsonTSuite);
		  JsonUserroleTSuites.put(JsonUserroleTSuite);
	      }
	      jsReportData.put(Constants.JSsuite, JsonTSuites);
	      jsReportData.put(Constants.JSUsersuite, JsonUserroleTSuites);
	      
	     // System.out.println("Input ReportData : \n"+JsonTestReport);
	      //System.out.println("Final ReportData : \n"+jsReportData);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	      return jsReportData;
	}
	

	public String GenerateUserRolesOverviewhtmlReportLength(JSONObject JsonTestReport,HashMap<String, String> mapReportfiles) throws Exception 
	{
		Log._logInfo("Generate HTML Report");
		// read suite.xls
		
		String reportsDirPath=null;
		Date d = new Date();
		reportsDirPath=UMReporter.getReportPath();
		if (reportsDirPath==null) {
		String path = "./custom_report/";
		String fileNamedate = new SimpleDateFormat("yyyyMMddhhmm").format(new Date());
		result_FolderName="Reports_API_"+fileNamedate;
		reportsDirPath=path + result_FolderName;
		new File(reportsDirPath).mkdirs();
		}
		
		
		System.out.println("Generates API Test Report: "+reportsDirPath);
		String environment=JsonTestReport.getString(Constants.JSRunEnvironment);
		String version=Constants.ReleaseType+"."+Constants.BuildReleaseVersion;
		String TestingType=JsonTestReport.getString(Constants.JSTestingType);
		String SuiteName=Constants.TEST_SHEET;
		String SuiteDescription="PA5 API "+TestingType+" Testing - ";
		String Filename="API_UserRolesSummary_Results.html";
		String reporthtmlfile="./"+Filename;
		
		// create index.html
		String indexHtmlPath=reportsDirPath+"/"+Filename;
		new File(indexHtmlPath).createNewFile();
		try{
			  
			  FileWriter fstream = new FileWriter(indexHtmlPath);
			  BufferedWriter out = new BufferedWriter(fstream);
			  out.write("<html><HEAD> <TITLE>Automation Test Overview</TITLE></HEAD>");
			  out.write("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">");
			  out.write("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>");
			  out.write("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>");
			  out.write("<script>");
			  out.write("$(function () {\r\n" + 
			  		"        $(\".resPopup\").click(function () {\r\n" + 
			  		"			   var getdataId = $(this).attr(\"data-id\");\r\n" + 
			  		"			document.getElementById(\"myModTitle\").innerHTML = getdataId;\r\n" + 
			  		"			  var getdatatext = $(this).attr(\"data-text\");\r\n" + 
			  		"			document.getElementById(\"myP\").innerHTML = getdatatext;" + 
			  		"            $(\"#myModal\").modal();\r\n" + 
			  		"        })\r\n" + 
			  		"    });");
			  out.write("$(document).ready(function(){\r\n" + 
			  		"    $(\".toggler\").click(function(e){\r\n" + 
			  		"        e.preventDefault();\r\n" + 
			  		"		$(this)\r\n" + 
			  		"        $('.testds'+$(this).attr('data-testds')).toggle();\r\n" + 
			  		"    });\r\n" + 
			  		"	$('.expandalltoggler').on('click', function(e){\r\n" + 
			  		"		var dataset = $('#mysuitestab tbody').find('tr[class^=\"testds\"]');\r\n" + 
			  		"		dataset.each(function(index) {\r\n" + 
			  		"		item = $(this);\r\n" + 
			  		"		item.toggle();\r\n" + 
			  		"	  });\r\n" + 
			  		"    });\r\n" + 
			  		"	$(\".totaltc\").click(function(e){\r\n" + 
			  		"	  var dataset = $('#mysuitestab tbody').find('tr.tcsuite');\r\n" + 
			  		"	  dataset.each(function(index) {\r\n" + 
			  		"		item = $(this);\r\n" + 
			  		"		item.show();\r\n" + 
			  		"	  });\r\n" + 
			  		"	});\r\n" + 
			  		"	\r\n" + 
			  		"	$(\".tcfilter\").click(function(e){\r\n" + 
			  		"		var selectstatus= $(this).attr('title');\r\n" + 
			  		"		console.log(selectstatus);\r\n" + 
			  		"		var dataset = $('#mysuitestab tbody').find('tr.tcsuite');\r\n" + 
			  		"		dataset.each(function(index) {\r\n" + 
			  		"		item = $(this);\r\n" + 
			  		"		item.hide();\r\n" + 
			  		"		var firstTd = item.find('td:nth-child(5)');\r\n" + 
			  		"		var text = firstTd.text();\r\n" + 
			  		"		var ids = text.split(',');\r\n" + 
			  		"		for (var i = 0; i < ids.length; i++)\r\n" + 
			  		"		{\r\n" + 
			  		"			if (ids[i] == selectstatus)\r\n" + 
			  		"			{\r\n" + 
			  		"			item.show();\r\n" + 
			  		"			}\r\n" + 
			  		"		}\r\n" + 
			  		"	  });\r\n" + 
			  		"	});\r\n" + 
			  		"	})");
			  out.write("</script>");
			  out.write("<body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u>API Automation User roles Summary</u></b></h4><table  border=1 cellspacing=1 cellpadding=1 ><tr><h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=250 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(d.toString());
			  out.write("</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Environment</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(environment);
			  out.write("</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>API Server</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(Constants.APIServer);
			  out.write("</b></td></tr><tr><td width=200 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Build Version</b></td><td width=300 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  out.write(version);
			  out.write("</b></td></tr><tr><td width=200 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Testing Type </b></td><td width=300 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  out.write(TestingType);
			  out.write("</b></td></tr></table><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>User Roles Report Summary:</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=5% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SNO</b></td><td width=15% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SUITE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>User Role</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Success rate</b></td>");
			  out.write("<td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of TestCases</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of Passed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Failed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Skipped</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Execution Time</b></td></tr>");
			  
			
			  String currentTestSuite=null;
			 
			  String suite_result="";
			  boolean IsAdmin=true;
			  boolean IsTestCoord=false;
			  boolean IsTestCoordInt=false;
			  boolean IsTestAdmin=false;
			  boolean IsTeacher=false;
			  boolean IsRepAdmin=false;
			  boolean IsHSAdmin=false;
			  boolean IsSysAdmin=false;
			  boolean IsTechSupport=false;
			  boolean IsCS1=false;
			  boolean IsCS2=false;
			  
			  JSONArray useroleSuites = JsonTestReport.getJSONArray("usersuites");
			  int iSuitid=0;
			  String strSuitid=null;
			  for(int currentSuiteID=0;currentSuiteID<useroleSuites.length();currentSuiteID++)
			   {
				  	currentTestSuite = SuiteName;
					JSONObject Suite = useroleSuites.getJSONObject(currentSuiteID);
					String userrole=Suite.getString(Constants.JSUserRole);
					String reportpath="";
					 out.write("<tr><td width=5% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
					 iSuitid=currentSuiteID+1;
					 strSuitid=String.valueOf(iSuitid);
					 out.write(strSuitid);
					 out.write("</b><td width=10% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
					  out.write("<a href="+reportpath+">"+currentTestSuite+"_"+userrole+"</a>");
					  out.write("</b></td><td width=25% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
					  out.write(SuiteDescription+userrole);
					  out.write("</b></td><td width=10% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
				
					  out.write(userrole);
					  if (userrole.equalsIgnoreCase(Constants.UserRoleAdmin))
						  IsAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTestCoordinator))
						  IsTestCoord=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTestCoordinatorInterim))
						  IsTestCoordInt=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTeacher))
						  IsTeacher=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTestAdministrator))
						  IsTestAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleReportingAdmin))
						  IsRepAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleHandScoreAdmin))
						  IsHSAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleSystemAdmin))
						  IsSysAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTechSupport))
						  IsTechSupport=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleCS1))
						  IsCS1=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleCS2))
						  IsCS2=true;
					  out.write("</b></td><td width=10% align=center  bgcolor=");
					  int totaltc=Suite.getInt("NoOfTestCases");
					  int passtc=Suite.getInt("NoOfPassed");
					  double TCPassspercent= passtc *100 ;
					  TCPassspercent=TCPassspercent/totaltc;
					  
					  DecimalFormat df2 = new DecimalFormat("#.##");
					  df2.setRoundingMode(RoundingMode.UP);
					  String SuccRate=df2.format(TCPassspercent);
				
					 // System.out.println("TCPassspercent : "+SuccRate);
					  suite_result=Suite.getString("Status");
						  if(suite_result.equals("FAIL"))
							  	out.write("red><FONT COLOR=153E7E FACE=Arial SIZE=2><b>FAIL</b></td>");
						  else
							  	out.write("green><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+SuccRate+"% </b></td>");
					 
						 
					  
					  out.write("<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value>"+Suite.get("NoOfTestCases").toString()+"</span></td>");
					  out.write("<td width=10% align=center  bgcolor=green><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+Suite.get("NoOfPassed").toString()+"</span></td>");
					  out.write("<td width=10% align=center  bgcolor=red><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+Suite.get("NoOfFailed").toString()+"</span></td>");
					  out.write("<td width=10% align=center  bgcolor=yellow><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+Suite.get("NoOfSkipped").toString()+"</span></td>");
					  out.write("<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+Suite.get("TimeTaken").toString()+"</b></td></tr>");
					  
					  
				   
			   }
			  //Close the output stream
			  out.write("</table>");
			 
			  JSONArray Suites = JsonTestReport.getJSONArray("suite");
			  for(int currentSuiteID=0;currentSuiteID<Suites.length();currentSuiteID++)
			   {
				  	currentTestSuite = SuiteName;
					JSONObject Suite = Suites.getJSONObject(currentSuiteID);
					
//			    	 String testSteps_file=reportsDirPath+"\\"+currentTestSuite+"_steps.html";
//					 new File(testSteps_file).createNewFile();						  
//					  FileWriter fstream_test_steps= new FileWriter(testSteps_file);
					  BufferedWriter out_test_steps=out;
					  
					  out_test_steps.write("<table id=\"mysuitestab\" width=100% border=1 cellspacing=1 cellpadding=1 >");
					  out_test_steps.write("<thead><tr><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>API User Role Permission Matrix :</u></br>");
					  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("<a href=\"#\" class=\"expandalltoggler\" data-testds=\"0\"><span FONT COLOR=#ffffff>+</span>");
					  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("TCNO");
					  out_test_steps.write("<td align= center width=30% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("OperationId");
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("AvgResponseTime");
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("AvgResponseLength");
					  if (IsAdmin) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("Admin");
					  }
					  if (IsTestCoord) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("Testcoord");
					  }
					  if (IsTestCoordInt) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("TestcoordInterim");
					  }
					  if (IsTeacher) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("Teacher");
					  }
					  if (IsTestAdmin) {
						  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
						  out_test_steps.write("TestAdmin");
					  }
					  if (IsRepAdmin) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("ReportingAdmin");
					  }
					  if (IsHSAdmin) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("HandscoreAdmin");
					  }
					  if (IsSysAdmin) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("SystemAdmin");
					  }
					  if (IsTechSupport) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("Techsupport");
					  }
					  if (IsCS1) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("CustomerSupport1");
					  }
					  if (IsCS2) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("CustomerSupport2");
					  }
					  out_test_steps.write("</b></tr></thead><tbody>");
					  
					  JSONArray TestSets = Suite.getJSONArray("tests");
					  int testid;
					  
					  String CTestid="";
					  String reqUrl;
					  String APIURL="";
					  String reqMethod;
					  String TestCaseid="";
					  String RespTime="";
					  int ifailedcnt=0;
					  int iskipedcnt=0;
					  String RequestbdyText="";
					  String HeaderText="";
					  for(int currentTestCaseID=0;currentTestCaseID<TestSets.length();currentTestCaseID++)
					   {
							JSONObject TestSet = TestSets.getJSONObject(currentTestCaseID);

							testid=currentTestCaseID+1;
							CTestid=String.valueOf(testid);
							out_test_steps.write("<tr class=\"tcsuite\">"); 
							out_test_steps.write("<td align= center><a href=\"#\" class=\"toggler\" data-testds=\""+CTestid+"\"><span>+</span></a>"); 
							out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							out_test_steps.write(CTestid);
							out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							TestCaseid=TestSet.getString(Constants.RepIssue_key);
							out_test_steps.write(TestCaseid);
							out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							RespTime=TestSet.getString(Constants.RepResponseTime).toString();
							out_test_steps.write(RespTime);
							String userper=TestSet.getString("Reponselength");
							Double Replen =Double.parseDouble(userper);
						   	
							if(Replen>40000){
								  out_test_steps.write("<td align= left bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							}
							else {
								out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							}
							out_test_steps.write(userper);
						   	
							if (IsAdmin) {
							
							String data=TestSet.getString(Constants.UserRoleAdmin);
						    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
								  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  }
							  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
								  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  if(suite_result.equals(""))
									  suite_result="FAIL";
							  }
							  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
								  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  }
							  else {
								  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  }
						    out_test_steps.write(data );
							}
							
							if (IsTestCoord) {
								
								String data=TestSet.getString(Constants.UserRoleTestCoordinator);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							
							if (IsTestCoordInt) {
								
								String data=TestSet.getString(Constants.UserRoleTestCoordinatorInterim);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							
							if (IsTeacher) {
								
								String data=TestSet.getString(Constants.UserRoleTeacher);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							
							if (IsTestAdmin) {
								String data=TestSet.getString(Constants.UserRoleTestAdministrator);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsRepAdmin) {
								
								String data=TestSet.getString(Constants.UserRoleReportingAdmin);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsHSAdmin) {
								
								String data=TestSet.getString(Constants.UserRoleHandScoreAdmin);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsSysAdmin) {
								
								String data=TestSet.getString(Constants.UserRoleSystemAdmin);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsTechSupport) {
								
								String data=TestSet.getString(Constants.UserRoleTechSupport);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							
							if (IsCS1) {
								
								String data=TestSet.getString(Constants.UserRoleCS1);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsCS2) {
								
								String data=TestSet.getString(Constants.UserRoleCS2);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
//						   	
							out_test_steps.write("</tr>");
							
							//DataSet Table

							out_test_steps.write("<tr class=\"testds"+CTestid+"\" style=\"display:none\">");
//							 out_test_steps.write("<table width=100% border=1 cellspacing=1 cellpadding=1 >");
//							  out_test_steps.write("<tr>");
							 out_test_steps.write("<td align= center width=5% bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(" - ");
							  out_test_steps.write("<td align= center width=5% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("DataID");
							  out_test_steps.write("<td align= center width=30% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("RequestURL");
							  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("ResponseTime");
							  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("ResponseLength");
							  if (IsAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("Admin");
							  }
							  if (IsTestCoord) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("Testcoord");
							  }
							  if (IsTestCoordInt) {
								out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  	out_test_steps.write("TestcoordInt");
							  }
							  if (IsTeacher) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("Teacher");
							  }
							  if (IsTestAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("TestAdmin");
							  }
							  if (IsRepAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("ReportingAdmin");
							  }
							  if (IsHSAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("HandscoreAdmin");
							  }
							  if (IsSysAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("SystemAdmin");
							  }
							  if (IsTechSupport) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("Techsupport");
							  }
							  if (IsCS1) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("CustomerSupport1");
							  }
							  if (IsCS2) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("CustomerSupport2");
							  }

							  out_test_steps.write("</b></tr>");
							  String DataTestsetid=null;
							  JSONArray ArrDataSets = TestSet.getJSONArray(Constants.JSsuitDataSets);
							 
							  for(int currentDatSetID=0;currentDatSetID<ArrDataSets.length();currentDatSetID++)
							   {
								  JSONObject TestDataSet = ArrDataSets.getJSONObject(currentDatSetID);
								  
								  
								  out_test_steps.write("<tr class=\"testds"+CTestid+"\" style=\"display:none\">");
									
									out_test_steps.write("<td align= center><span>-</span></a>");
									DataTestsetid=TestDataSet.getString(Constants.DATASETID);
									out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									out_test_steps.write(DataTestsetid);
									out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									//Constants.APIServer
								   	reqUrl=TestDataSet.getString(Constants.RepAPIRequest);
								   	APIURL= TestSet.getString(Constants.RepAPIURL);
								   	reqMethod=TestSet.getString(Constants.RepAPIMethodType).toUpperCase();
								   	out_test_steps.write(reqMethod+" "+APIURL);
									out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									RespTime=TestDataSet.getString(Constants.RepResponseTime);
									out_test_steps.write(RespTime);
									userper=TestDataSet.getString("Reponselength");
									Double Replen1 =Double.parseDouble(userper);
								   	
									if(Replen1>40000){
										  out_test_steps.write("<td align=left bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									}
									else {
										out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									}
									out_test_steps.write(userper);
//								   	userper=TestDataSet.getString("Reponselength");
//								   	out_test_steps.write(userper);
								   
									if (IsAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleAdmin);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsTestCoord) {
										String data = TestDataSet.getString(Constants.UserRoleTestCoordinator);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsTestCoordInt) {
										String data = TestDataSet.getString(Constants.UserRoleTestCoordinatorInterim);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsTeacher) {
										String data = TestDataSet.getString(Constants.UserRoleTeacher);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									
									if (IsTestAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleTestAdministrator);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsRepAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleReportingAdmin);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsHSAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleHandScoreAdmin);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsSysAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleSystemAdmin);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsTechSupport) {
										String data = TestDataSet.getString(Constants.UserRoleTechSupport);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsCS1) {
										String data = TestDataSet.getString(Constants.UserRoleCS1);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsCS2) {
										String data = TestDataSet.getString(Constants.UserRoleCS2);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									out_test_steps.write("</td>"); 
									out_test_steps.write("</tr>");
								  
							   }
//							  out_test_steps.write("</table>");
//							  out_test_steps.write("</tr>");
							  
				}					  
				  out_test_steps.write("</tbody>");
				  out_test_steps.write("</table>");  
				  
				  out_test_steps.write(" <!-- Modal -->\r\n" + 
				  		"    <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">\r\n" + 
				  		"        <div class=\"modal-dialog\" style=\"width:80%;height:80%;overflow:auto;\">\r\n" + 
				  		"            <!-- Modal content-->\r\n" + 
				  		"            <div class=\"modal-content\">\r\n" + 
				  		"                <div class=\"modal-header\">\r\n" + 
				  		"                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\r\n" + 
				  		"                    <h4 class=\"modal-title\" id=\"myModTitle\">Response</h4>\r\n" + 
				  		"                </div>\r\n" + 
				  		"                <div class=\"modal-body\"><FONT COLOR=#000000 FACE= Arial  SIZE=2>\r\n" + 
				  		"                    <p id=\"myP\">This is something response to display</p>\r\n" + 
				  		"                </div>\r\n" + 
				  		"                <div class=\"modal-footer\">\r\n" + 
				  		"                    <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\r\n" + 
				  		"                </div>\r\n" + 
				  		"            </div>\r\n" + 
				  		"\r\n" + 
				  		"        </div>\r\n" + 
				  		"    </div>\r\n" + 
				  		"</div>");  
				  out_test_steps.write("</body>");
				  out_test_steps.write("</html>");
				  out_test_steps.close();
				 
				
			
			     }
			   
		}
			  catch (Exception e){//Catch exception if any
			  System.err.println("Error: " + e.getMessage());
			  e.printStackTrace();
		  }
		return reporthtmlfile;
	}
	
	/***************************************************************************************
 	 *  Function name 		: GenerateJSONReport
 	 *  Reuse Function 		:  
 	 *  Description 		: To generate excel testresult into JSON
 	/****************************************************************************************/ 
	public JSONObject BuildUSERPERJSONReportwithlength(JSONObject JsonTestReport,String Userrole, String TestingType)
	{
	     //Initialize Test case summary Count
		int iNoOfTestCase=0,iNoOfPass = 0,iNoOfFail=0,iNoOfSkip=0;    
		JSONObject jsTestData = new JSONObject(JsonTestReport.toString());
		JSONObject jsReportData = new JSONObject();
		DecimalFormat format = new DecimalFormat("0.#");
		try{
			
		//System.out.println("Input ReportData : "+JsonTestReport);
		//Create Report Folder
		Date d = new Date();
		String FS_Userrole=Userrole.replace(" ", "");
		 // Add test report details
		jsReportData.put(Constants.JSReportTitle, "PAUIR Automation API User roles Test Report");
		jsReportData.put(Constants.JSRunDate, d.toString());
		jsReportData.put(Constants.JSRunEnvironment, FileReaderManager.getInstance().getConfigReader().getEnvironment());
		jsReportData.put(Constants.JSTestingType, TestingType);
		jsReportData.put(Constants.JSUserRole, FS_Userrole);
	   
	      JSONArray JsonTSuites = new JSONArray();
	      JSONArray JsonUserroleTSuites = new JSONArray();
	      for (int iSuiteIter = 0; iSuiteIter < 1; iSuiteIter++)
	      {
	    	  String suite_result="";
		  // create a JsonTSuite
	      JSONObject JsonTSuite = new JSONObject();
	      JSONObject JsonUserroleTSuite = new JSONObject();
	      JsonTSuite.put(Constants.JSProject, Constants.JIRAProject);
	      JsonUserroleTSuite.put(Constants.JSProject, Constants.JIRAProject);
	      JsonTSuite.put(Constants.JSTestingType, TestingType);
	      JsonUserroleTSuite.put(Constants.JSTestingType, TestingType);
	      JsonTSuite.put(Constants.JSExecutionDuration, jsTestData.getString(Constants.JSExecutionDuration));
	      JsonUserroleTSuite.put(Constants.JSExecutionDuration, jsTestData.getString(Constants.JSExecutionDuration));
	      JsonTSuite.put(Constants.JSUserRole, FS_Userrole);
	      JsonUserroleTSuite.put(Constants.JSUserRole, FS_Userrole);
	      //Tests
	      JSONArray TestSets = (JSONArray) jsTestData.get("Tests");
        
	      //Tests Report
	      JSONArray RepTests = new JSONArray();
	      for (int iTestIter = 0; iTestIter < TestSets.length(); iTestIter++) {
        	JSONObject Testset = TestSets.getJSONObject(iTestIter);
        	JSONObject jsTestReps = new JSONObject();
        	jsTestReps.put(Constants.RepIssue_key, Testset.get(Constants.TCID).toString());
		  	jsTestReps.put(Constants.RepAPIMethodType, Testset.get(Constants.MethodType).toString());
		  	jsTestReps.put(Constants.RepAPIURL, Testset.get(Constants.RepAPIRequest).toString());
		  	jsTestReps.put(Constants.RepAPIDescription, Testset.get(Constants.Summary).toString());
		  	jsTestReps.put(Constants.RepTestResultStatus,  Testset.get(Constants.TestStatus).toString());
		  	jsTestReps.put(FS_Userrole,  Testset.get(Constants.TestStatus).toString());
		  	jsTestReps.put(Constants.UserPermissions,  Testset.get(Constants.UserPermissions).toString());
            //DataSets
		  	int iNoOfTestDS=0,iNoOfDSPass = 0,iNoOfDSFail=0,iNoOfDSSkip=0;
		  	JSONArray RepArrDataSets = new JSONArray();
            JSONArray DataSets = (JSONArray) Testset.get("Datasets");
            int CumRespLen=0;
            int iSumRespTime=0;
            double AvgResplen=0;
            for (int iDataIter = 0; iDataIter < DataSets.length(); iDataIter++) {
            	JSONObject DataSet = DataSets.getJSONObject(iDataIter);
            	
            	JSONObject jsTestDSReps = new JSONObject();
            	
            	iNoOfTestCase=iNoOfTestCase+1;
            	iNoOfTestDS=iNoOfTestDS+1;
            	String TestResults=DataSet.getJSONObject("Output").get(Constants.RESULT).toString();
            	String ActResp=DataSet.getJSONObject("Output").get(Constants.Response).toString();
            	int reslen=ActResp.length();
            	CumRespLen=CumRespLen+reslen;
            	String Reponselen=String.valueOf(reslen);
            	  if((TestResults.startsWith("Pass") || TestResults.startsWith("PASS"))){
					  iNoOfPass=iNoOfPass+1;
					  iNoOfDSPass=iNoOfDSPass+1;
				  }
				  else if((TestResults.startsWith("Fail") || TestResults.startsWith("FAIL"))){
					  iNoOfFail=iNoOfFail+1;
					  iNoOfDSFail=iNoOfDSFail+1;
					  if(suite_result.equals(""))
						  suite_result=Constants.KEYWORD_FAIL;
				  }
				  else if((TestResults.startsWith("Skip") ||TestResults.startsWith("skip")|| TestResults.startsWith("SKIP")||TestResults.isEmpty())){
					  TestResults=Constants.KEYWORD_SKIP;
					  iNoOfSkip=iNoOfSkip+1;
					  iNoOfDSSkip=iNoOfDSSkip+1;
				  }
            	
            	  jsTestDSReps.put(Constants.DATASET, DataSet.get(Constants.DATASET).toString());
            	  
            	  jsTestDSReps.put(Constants.UserPermissions, DataSet.get(Constants.UserPermissions).toString());
            	  jsTestDSReps.put(Constants.DataDescription, DataSet.get(Constants.DataDescription).toString());
            	  jsTestDSReps.put(Constants.RepAPIRequest, DataSet.get(Constants.RepAPIURL).toString());
            	  jsTestDSReps.put(Constants.RepTestResultStatus, TestResults);
            	  jsTestDSReps.put(FS_Userrole, TestResults);
            	  jsTestDSReps.put("Reponselength", Reponselen);
            	  jsTestDSReps.put(Constants.RepStatusCode, DataSet.getJSONObject(Constants.output).get(Constants.RepStatusCode).toString());
            	  jsTestDSReps.put(Constants.RepResponseDescription, DataSet.getJSONObject(Constants.output).get(Constants.RepResponseDescription).toString());	  
            	  
            	  String RespTime=DataSet.getJSONObject(Constants.output).get(Constants.RepResponseTime).toString();
            	  
            	  String RecSplit[] = null;
            	  if (RespTime.indexOf(" ms")>=0) {
 					 RecSplit=RespTime.split(" ms");
 					if (RecSplit.length>=1)
 						if (StringUtils.isNumeric(RecSplit[0])) {
 							int iRespTime=Integer.parseInt(RecSplit[0]);
 							iSumRespTime=iSumRespTime+iRespTime;
 						}
            	  }
            	  jsTestDSReps.put(Constants.RepResponseTime, RespTime);
 				
            	 
            	  RepArrDataSets.put(jsTestDSReps);
            }
            
            jsTestReps.put(Constants.JSsuitDataSets, RepArrDataSets);
            AvgResplen=CumRespLen/iNoOfTestDS;
            
            jsTestReps.put(Constants.JSsuiteNoOfTestCases, iNoOfTestDS);
            jsTestReps.put(Constants.JSsuiteNoOfPassed, iNoOfDSPass);
            jsTestReps.put(Constants.JSsuiteNoOfFailed, iNoOfDSFail);
            jsTestReps.put(Constants.JSsuitNoOfSkipped, iNoOfDSSkip);
            String AvgReponselen=String.valueOf(format.format(AvgResplen));
            jsTestReps.put("Reponselength", AvgReponselen);
            AvgResplen=iSumRespTime/iNoOfTestDS;
            AvgReponselen=String.valueOf(format.format(AvgResplen));
            jsTestReps.put(Constants.RepResponseTime, AvgReponselen+" ms");
            RepTests.put(jsTestReps);
           
	      	}
	      JsonTSuite.put(Constants.JSsuitTest, RepTests);
	      
	      if(suite_result.equals("FAIL")) {
			  JsonTSuite.put(Constants.JSsuiteStatus, "Fail");
			  JsonTSuite.put(FS_Userrole, "Fail");
			  JsonUserroleTSuite.put(Constants.JSsuiteStatus, "Fail");
			  
	      }
		  else {
			  JsonTSuite.put(Constants.JSsuiteStatus, "Pass");
			  JsonTSuite.put(FS_Userrole, "Pass");
			  JsonUserroleTSuite.put(Constants.JSsuiteStatus, "Pass");
		  }
	      
	      JsonTSuite.put(Constants.JSsuiteNoOfTestCases, iNoOfTestCase);
	      JsonUserroleTSuite.put(Constants.JSsuiteNoOfTestCases, iNoOfTestCase);
		  JsonTSuite.put(Constants.JSsuiteNoOfPassed, iNoOfPass);
		  JsonUserroleTSuite.put(Constants.JSsuiteNoOfPassed, iNoOfPass);
		  JsonTSuite.put(Constants.JSsuiteNoOfFailed, iNoOfFail);
		  JsonUserroleTSuite.put(Constants.JSsuiteNoOfFailed, iNoOfFail);
		  JsonTSuite.put(Constants.JSsuitNoOfSkipped, iNoOfSkip);
		  JsonUserroleTSuite.put(Constants.JSsuitNoOfSkipped, iNoOfSkip);
		  JsonTSuites.put(JsonTSuite);
		  JsonUserroleTSuites.put(JsonUserroleTSuite);
	      }
	      jsReportData.put(Constants.JSsuite, JsonTSuites);
	      jsReportData.put(Constants.JSUsersuite, JsonUserroleTSuites);
	      
	     // System.out.println("Input ReportData : \n"+JsonTestReport);
	      //System.out.println("Final ReportData : \n"+jsReportData);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	      return jsReportData;
	}
	
	public String GenerateUserRolesOverviewhtmlReport(JSONObject JsonTestReport,HashMap<String, String> mapReportfiles) throws Exception 
	{
		Log._logInfo("Generate HTML Report");
		// read suite.xls
		
		String reportsDirPath=null;
		Date d = new Date();
		reportsDirPath=UMReporter.getReportPath();
		if (reportsDirPath==null) {
		String path = "./custom_report/";
		String fileNamedate = new SimpleDateFormat("yyyyMMddhhmm").format(new Date());
		result_FolderName="Reports_API_"+fileNamedate;
		reportsDirPath=path + result_FolderName;
		new File(reportsDirPath).mkdirs();
		}
		
		
		System.out.println("Generates API Test Report: "+reportsDirPath);
		String environment=JsonTestReport.getString(Constants.JSRunEnvironment);
		String version=Constants.ReleaseType+"."+Constants.BuildReleaseVersion;
		String TestingType=JsonTestReport.getString(Constants.JSTestingType);
		String SuiteName=Constants.TEST_SHEET;
		String SuiteDescription="PA5 API "+TestingType+" Testing - ";
		String Filename="API_UserRolesSummary_Results.html";
		String reporthtmlfile="./"+Filename;
		
		// create index.html
		String indexHtmlPath=reportsDirPath+"/"+Filename;
		new File(indexHtmlPath).createNewFile();
		try{
			  
			  FileWriter fstream = new FileWriter(indexHtmlPath);
			  BufferedWriter out = new BufferedWriter(fstream);
			  out.write("<html><HEAD> <TITLE>Automation Test Overview</TITLE></HEAD>");
			  out.write("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">");
			  out.write("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>");
			  out.write("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>");
			  out.write("<script>");
			  out.write("$(function () {\r\n" + 
			  		"        $(\".resPopup\").click(function () {\r\n" + 
			  		"			   var getdataId = $(this).attr(\"data-id\");\r\n" + 
			  		"			document.getElementById(\"myModTitle\").innerHTML = getdataId;\r\n" + 
			  		"			  var getdatatext = $(this).attr(\"data-text\");\r\n" + 
			  		"			document.getElementById(\"myP\").innerHTML = getdatatext;" + 
			  		"            $(\"#myModal\").modal();\r\n" + 
			  		"        })\r\n" + 
			  		"    });");
			  out.write("$(document).ready(function(){\r\n" + 
			  		"    $(\".toggler\").click(function(e){\r\n" + 
			  		"        e.preventDefault();\r\n" + 
			  		"		$(this)\r\n" + 
			  		"        $('.testds'+$(this).attr('data-testds')).toggle();\r\n" + 
			  		"    });\r\n" + 
			  		"	$('.expandalltoggler').on('click', function(e){\r\n" + 
			  		"		var dataset = $('#mysuitestab tbody').find('tr[class^=\"testds\"]');\r\n" + 
			  		"		dataset.each(function(index) {\r\n" + 
			  		"		item = $(this);\r\n" + 
			  		"		item.toggle();\r\n" + 
			  		"	  });\r\n" + 
			  		"    });\r\n" + 
			  		"	$(\".totaltc\").click(function(e){\r\n" + 
			  		"	  var dataset = $('#mysuitestab tbody').find('tr.tcsuite');\r\n" + 
			  		"	  dataset.each(function(index) {\r\n" + 
			  		"		item = $(this);\r\n" + 
			  		"		item.show();\r\n" + 
			  		"	  });\r\n" + 
			  		"	});\r\n" + 
			  		"	\r\n" + 
			  		"	$(\".tcfilter\").click(function(e){\r\n" + 
			  		"		var selectstatus= $(this).attr('title');\r\n" + 
			  		"		console.log(selectstatus);\r\n" + 
			  		"		var dataset = $('#mysuitestab tbody').find('tr.tcsuite');\r\n" + 
			  		"		dataset.each(function(index) {\r\n" + 
			  		"		item = $(this);\r\n" + 
			  		"		item.hide();\r\n" + 
			  		"		var firstTd = item.find('td:nth-child(5)');\r\n" + 
			  		"		var text = firstTd.text();\r\n" + 
			  		"		var ids = text.split(',');\r\n" + 
			  		"		for (var i = 0; i < ids.length; i++)\r\n" + 
			  		"		{\r\n" + 
			  		"			if (ids[i] == selectstatus)\r\n" + 
			  		"			{\r\n" + 
			  		"			item.show();\r\n" + 
			  		"			}\r\n" + 
			  		"		}\r\n" + 
			  		"	  });\r\n" + 
			  		"	});\r\n" + 
			  		"	})");
			  out.write("</script>");
			  out.write("<body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u>API Automation User roles Summary</u></b></h4><table  border=1 cellspacing=1 cellpadding=1 ><tr><h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=250 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(d.toString());
			  out.write("</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Environment</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(environment);
			  out.write("</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>API Server</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(Constants.APIServer);
			  out.write("</b></td></tr><tr><td width=200 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Build Version</b></td><td width=300 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  out.write(version);
			  out.write("</b></td></tr><tr><td width=200 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Testing Type </b></td><td width=300 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  out.write(TestingType);
			  out.write("</b></td></tr></table><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>User Roles Report Summary:</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=5% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SNO</b></td><td width=15% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SUITE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>User Role</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Success rate</b></td>");
			  out.write("<td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of TestCases</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of Passed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Failed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Skipped</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Execution Time</b></td></tr>");
			  
			
			  String currentTestSuite=null;
			 
			  String suite_result="";
			  boolean IsAdmin=true;
			  boolean IsTestCoord=false;
			  boolean IsTestCoordInt=false;
			  boolean IsTestAdmin=false;
			  boolean IsTeacher=false;
			  boolean IsRepAdmin=false;
			  boolean IsHSAdmin=false;
			  boolean IsSysAdmin=false;
			  boolean IsTechSupport=false;
			  boolean IsCS1=false;
			  boolean IsCS2=false;
			  
			  JSONArray useroleSuites = JsonTestReport.getJSONArray("usersuites");
			  int iSuitid=0;
			  String strSuitid=null;
			  for(int currentSuiteID=0;currentSuiteID<useroleSuites.length();currentSuiteID++)
			   {
				  	currentTestSuite = SuiteName;
					JSONObject Suite = useroleSuites.getJSONObject(currentSuiteID);
					String userrole=Suite.getString(Constants.JSUserRole);
					String reportpath=mapReportfiles.get(userrole);
					 out.write("<tr><td width=5% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
					 iSuitid=currentSuiteID+1;
					 strSuitid=String.valueOf(iSuitid);
					 out.write(strSuitid);
					 out.write("</b><td width=10% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
					  out.write("<a href="+reportpath+">"+currentTestSuite+"_"+userrole+"</a>");
					  out.write("</b></td><td width=25% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
					  out.write(SuiteDescription+userrole);
					  out.write("</b></td><td width=10% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
				
					  out.write(userrole);
					  if (userrole.equalsIgnoreCase(Constants.UserRoleAdmin))
						  IsAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTestCoordinator))
						  IsTestCoord=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTestCoordinatorInterim))
						  IsTestCoordInt=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTeacher))
						  IsTeacher=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTestAdministrator))
						  IsTestAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleReportingAdmin))
						  IsRepAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleHandScoreAdmin))
						  IsHSAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleSystemAdmin))
						  IsSysAdmin=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleTechSupport))
						  IsTechSupport=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleCS1))
						  IsCS1=true;
					  else if (userrole.equalsIgnoreCase(Constants.UserRoleCS2))
						  IsCS2=true;
					  out.write("</b></td><td width=10% align=center  bgcolor=");
					  int totaltc=Suite.getInt("NoOfTestCases");
					  int passtc=Suite.getInt("NoOfPassed");
					  double TCPassspercent= passtc *100 ;
					  TCPassspercent=TCPassspercent/totaltc;
					  
					  DecimalFormat df2 = new DecimalFormat("#.##");
					  df2.setRoundingMode(RoundingMode.UP);
					  String SuccRate=df2.format(TCPassspercent);
				
					 // System.out.println("TCPassspercent : "+SuccRate);
					  suite_result=Suite.getString("Status");
						  if(suite_result.equals("FAIL"))
							  	out.write("red><FONT COLOR=153E7E FACE=Arial SIZE=2><b>FAIL</b></td>");
						  else
							  	out.write("green><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+SuccRate+"% </b></td>");
					 
						 
					  
					  out.write("<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value>"+Suite.get("NoOfTestCases").toString()+"</span></td>");
					  out.write("<td width=10% align=center  bgcolor=green><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+Suite.get("NoOfPassed").toString()+"</span></td>");
					  out.write("<td width=10% align=center  bgcolor=red><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+Suite.get("NoOfFailed").toString()+"</span></td>");
					  out.write("<td width=10% align=center  bgcolor=yellow><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+Suite.get("NoOfSkipped").toString()+"</span></td>");
					  out.write("<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+Suite.get("TimeTaken").toString()+"</b></td></tr>");
					  
					  
				   
			   }
			  //Close the output stream
			  out.write("</table>");
			 
			  JSONArray Suites = JsonTestReport.getJSONArray("suite");
			  for(int currentSuiteID=0;currentSuiteID<Suites.length();currentSuiteID++)
			   {
				  	currentTestSuite = SuiteName;
					JSONObject Suite = Suites.getJSONObject(currentSuiteID);
					
//			    	 String testSteps_file=reportsDirPath+"\\"+currentTestSuite+"_steps.html";
//					 new File(testSteps_file).createNewFile();						  
//					  FileWriter fstream_test_steps= new FileWriter(testSteps_file);
					  BufferedWriter out_test_steps=out;
					  
					  out_test_steps.write("<table id=\"mysuitestab\" width=100% border=1 cellspacing=1 cellpadding=1 >");
					  out_test_steps.write("<thead><tr><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>API User Role Permission Matrix :</u></br>");
					  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("<a href=\"#\" class=\"expandalltoggler\" data-testds=\"0\"><span FONT COLOR=#ffffff>+</span>");
					  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("TCNO");
					  out_test_steps.write("<td align= center width=35% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("OperationId");
					  out_test_steps.write("<td align= center width=30% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("UserPermissions");
					  if (IsAdmin) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("Admin");
					  }
					  if (IsTestCoord) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("Testcoord");
					  }
					  if (IsTestCoordInt) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("TestcoordInterim");
					  }
					  if (IsTeacher) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("Teacher");
					  }
					  if (IsTestAdmin) {
						  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
						  out_test_steps.write("TestAdmin");
					  }
					  if (IsRepAdmin) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("ReportingAdmin");
					  }
					  if (IsHSAdmin) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("HandscoreAdmin");
					  }
					  if (IsSysAdmin) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("SystemAdmin");
					  }
					  if (IsTechSupport) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("Techsupport");
					  }
					  if (IsCS1) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("CustomerSupport1");
					  }
					  if (IsCS2) {
					  out_test_steps.write("<td align= center width=10% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("CustomerSupport2");
					  }
					  out_test_steps.write("</b></tr></thead><tbody>");
					  
					  JSONArray TestSets = Suite.getJSONArray("tests");
					  int testid;
					  
					  String CTestid="";
					  String reqUrl;
					  String APIURL="";
					  String reqMethod;
					  String TestCaseid="";
					  int ifailedcnt=0;
					  int iskipedcnt=0;
					  String RequestbdyText="";
					  String HeaderText="";
					  for(int currentTestCaseID=0;currentTestCaseID<TestSets.length();currentTestCaseID++)
					   {
							JSONObject TestSet = TestSets.getJSONObject(currentTestCaseID);

							testid=currentTestCaseID+1;
							CTestid=String.valueOf(testid);
							out_test_steps.write("<tr class=\"tcsuite\">"); 
							out_test_steps.write("<td align= center><a href=\"#\" class=\"toggler\" data-testds=\""+CTestid+"\"><span>+</span></a>"); 
							out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							out_test_steps.write(CTestid);
							out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							TestCaseid=TestSet.getString(Constants.RepIssue_key);
							out_test_steps.write(TestCaseid);
							out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							String userper=TestSet.getString(Constants.UserPermissions);
						   	userper=userper.replaceAll("\\[", "");
						   	userper=userper.replaceAll("\\]", "");
						   	userper=userper.replaceAll("\"", "");
							out_test_steps.write(userper);
						   	
							if (IsAdmin) {
							
							String data=TestSet.getString(Constants.UserRoleAdmin);
						    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
								  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  }
							  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
								  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  if(suite_result.equals(""))
									  suite_result="FAIL";
							  }
							  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
								  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  }
							  else {
								  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  }
						    out_test_steps.write(data );
							}
							
							if (IsTestCoord) {
								
								String data=TestSet.getString(Constants.UserRoleTestCoordinator);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							
							if (IsTestCoordInt) {
								
								String data=TestSet.getString(Constants.UserRoleTestCoordinatorInterim);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							
							if (IsTeacher) {
								
								String data=TestSet.getString(Constants.UserRoleTeacher);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							
							if (IsTestAdmin) {
								String data=TestSet.getString(Constants.UserRoleTestAdministrator);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsRepAdmin) {
								
								String data=TestSet.getString(Constants.UserRoleReportingAdmin);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsHSAdmin) {
								
								String data=TestSet.getString(Constants.UserRoleHandScoreAdmin);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsSysAdmin) {
								
								String data=TestSet.getString(Constants.UserRoleSystemAdmin);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsTechSupport) {
								
								String data=TestSet.getString(Constants.UserRoleTechSupport);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							
							if (IsCS1) {
								
								String data=TestSet.getString(Constants.UserRoleCS1);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
							if (IsCS2) {
								
								String data=TestSet.getString(Constants.UserRoleCS2);
							    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
									  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
									  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  if(suite_result.equals(""))
										  suite_result="FAIL";
								  }
								  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
									  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
								  else {
									  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  }
							    out_test_steps.write(data );
								}
//						   	
							out_test_steps.write("</tr>");
							
							//DataSet Table

							out_test_steps.write("<tr class=\"testds"+CTestid+"\" style=\"display:none\">");
//							 out_test_steps.write("<table width=100% border=1 cellspacing=1 cellpadding=1 >");
//							  out_test_steps.write("<tr>");
							 out_test_steps.write("<td align= center width=5% bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(" - ");
							  out_test_steps.write("<td align= center width=5% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("DataID");
							  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("RequestURL");
							  out_test_steps.write("<td align= center width=30% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("Permission");
							  if (IsAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("Admin");
							  }
							  if (IsTestCoord) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("Testcoord");
							  }
							  if (IsTestCoordInt) {
								out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  	out_test_steps.write("TestcoordInt");
							  }
							  if (IsTeacher) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("Teacher");
							  }
							  if (IsTestAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("TestAdmin");
							  }
							  if (IsRepAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("ReportingAdmin");
							  }
							  if (IsHSAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("HandscoreAdmin");
							  }
							  if (IsSysAdmin) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("SystemAdmin");
							  }
							  if (IsTechSupport) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("Techsupport");
							  }
							  if (IsCS1) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("CustomerSupport1");
							  }
							  if (IsCS2) {
								  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
								  out_test_steps.write("CustomerSupport2");
							  }

							  out_test_steps.write("</b></tr>");
							  String DataTestsetid=null;
							  JSONArray ArrDataSets = TestSet.getJSONArray(Constants.JSsuitDataSets);
							 
							  for(int currentDatSetID=0;currentDatSetID<ArrDataSets.length();currentDatSetID++)
							   {
								  JSONObject TestDataSet = ArrDataSets.getJSONObject(currentDatSetID);
								  
								  
								  out_test_steps.write("<tr class=\"testds"+CTestid+"\" style=\"display:none\">");
									
									out_test_steps.write("<td align= center><span>-</span></a>");
									DataTestsetid=TestDataSet.getString(Constants.DATASETID);
									out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									out_test_steps.write(DataTestsetid);
									out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									//Constants.APIServer
								   	reqUrl=TestDataSet.getString(Constants.RepAPIRequest);
								   	APIURL= TestSet.getString(Constants.RepAPIURL);
								   	reqMethod=TestSet.getString(Constants.RepAPIMethodType).toUpperCase();
									out_test_steps.write(reqMethod+" "+APIURL);
								   	out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								   	userper=TestDataSet.getString(Constants.UserPermissions);
									userper=userper.replaceAll("\\[", "");
								   	userper=userper.replaceAll("\\]", "");
								   	userper=userper.replaceAll("\"", "");
								   	out_test_steps.write(userper);
								   
									if (IsAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleAdmin);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsTestCoord) {
										String data = TestDataSet.getString(Constants.UserRoleTestCoordinator);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsTestCoordInt) {
										String data = TestDataSet.getString(Constants.UserRoleTestCoordinatorInterim);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsTeacher) {
										String data = TestDataSet.getString(Constants.UserRoleTeacher);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									
									if (IsTestAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleTestAdministrator);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsRepAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleReportingAdmin);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsHSAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleHandScoreAdmin);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsSysAdmin) {
										String data = TestDataSet.getString(Constants.UserRoleSystemAdmin);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsTechSupport) {
										String data = TestDataSet.getString(Constants.UserRoleTechSupport);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsCS1) {
										String data = TestDataSet.getString(Constants.UserRoleCS1);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									if (IsCS2) {
										String data = TestDataSet.getString(Constants.UserRoleCS2);
									    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
											  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
											  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
											  if(suite_result.equals(""))
												  suite_result="FAIL";
										  }
										  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
											  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
										  else {
											  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  }
									    out_test_steps.write(data );
									}
									out_test_steps.write("</td>"); 
									out_test_steps.write("</tr>");
								  
							   }
//							  out_test_steps.write("</table>");
//							  out_test_steps.write("</tr>");
							  
				}					  
				  out_test_steps.write("</tbody>");
				  out_test_steps.write("</table>");  
				  
				  out_test_steps.write(" <!-- Modal -->\r\n" + 
				  		"    <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">\r\n" + 
				  		"        <div class=\"modal-dialog\" style=\"width:80%;height:80%;overflow:auto;\">\r\n" + 
				  		"            <!-- Modal content-->\r\n" + 
				  		"            <div class=\"modal-content\">\r\n" + 
				  		"                <div class=\"modal-header\">\r\n" + 
				  		"                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\r\n" + 
				  		"                    <h4 class=\"modal-title\" id=\"myModTitle\">Response</h4>\r\n" + 
				  		"                </div>\r\n" + 
				  		"                <div class=\"modal-body\"><FONT COLOR=#000000 FACE= Arial  SIZE=2>\r\n" + 
				  		"                    <p id=\"myP\">This is something response to display</p>\r\n" + 
				  		"                </div>\r\n" + 
				  		"                <div class=\"modal-footer\">\r\n" + 
				  		"                    <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\r\n" + 
				  		"                </div>\r\n" + 
				  		"            </div>\r\n" + 
				  		"\r\n" + 
				  		"        </div>\r\n" + 
				  		"    </div>\r\n" + 
				  		"</div>");  
				  out_test_steps.write("</body>");
				  out_test_steps.write("</html>");
				  out_test_steps.close();
				 
				
			
			     }
			   
		}
			  catch (Exception e){//Catch exception if any
			  System.err.println("Error: " + e.getMessage());
			  e.printStackTrace();
		  }
		return reporthtmlfile;
	}
	
	/***************************************************************************************
 	 *  Function name 		: GenerateJSONReport
 	 *  Reuse Function 		:  
 	 *  Description 		: To generate excel testresult into JSON
 	/****************************************************************************************/ 
	public JSONObject NewBuildJSONReport(JSONObject JsonTestReport,String Userrole, String TestingType)
	{
	     //Initialize Test case summary Count
		int iNoOfTestCase=0,iNoOfPass = 0,iNoOfFail=0,iNoOfSkip=0;    
		JSONObject jsTestData = new JSONObject(JsonTestReport.toString());
		JSONObject jsReportData = new JSONObject();
		String FS_Userrole=Userrole.replace(" ", "");
		try{
			
		//System.out.println("Input ReportData : "+JsonTestReport);
		//Create Report Folder
		Date d = new Date();
		 // Add test report details
		jsReportData.put(Constants.JSReportTitle, "PAUIR Automation API Test Report");
		jsReportData.put(Constants.JSRunDate, d.toString());
		jsReportData.put(Constants.JSRunEnvironment, FileReaderManager.getInstance().getConfigReader().getEnvironment());
		jsReportData.put(Constants.JSTestingType, TestingType);
		jsReportData.put(Constants.JSUserRole, FS_Userrole);
        
	     // JsonArray JsonTSuites = new JsonArray();
	      JSONArray JsonTSuites = new JSONArray();
	      
	      for (int iSuiteIter = 0; iSuiteIter < 1; iSuiteIter++)
	      {
	    	  String suite_result="";
		  // create a JsonTSuite
	      JSONObject JsonTSuite = new JSONObject();
	      JsonTSuite.put(Constants.JSProject, Constants.JIRAProject);
	      JsonTSuite.put(Constants.JSTestingType, TestingType);
	      JsonTSuite.put(Constants.JSExecutionDuration, jsTestData.getString(Constants.JSExecutionDuration));	
	      JsonTSuite.put(Constants.JSUserRole, FS_Userrole);
	      //Tests
	      JSONArray TestSets = (JSONArray) jsTestData.get("Tests");
        
	      //Tests Report
	      JSONArray RepTests = new JSONArray();
	      for (int iTestIter = 0; iTestIter < TestSets.length(); iTestIter++) {
        	JSONObject Testset = TestSets.getJSONObject(iTestIter);
        	JSONObject jsTestReps = new JSONObject();
        	jsTestReps.put(Constants.RepIssue_key, Testset.get(Constants.TCID).toString());
		  	jsTestReps.put(Constants.RepAPIMethodType, Testset.get(Constants.MethodType).toString());
		  	jsTestReps.put(Constants.RepAPIURL, Testset.get(Constants.RepAPIRequest).toString());
		  	jsTestReps.put(Constants.RepAPIDescription, Testset.get(Constants.Summary).toString());
		  	jsTestReps.put(Constants.RepTestResultStatus,  Testset.get(Constants.TestStatus).toString());
            //DataSets
		  	int iNoOfTestDS=0,iNoOfDSPass = 0,iNoOfDSFail=0,iNoOfDSSkip=0;
		  	JSONArray RepArrDataSets = new JSONArray();
            JSONArray DataSets = (JSONArray) Testset.get("Datasets");
            for (int iDataIter = 0; iDataIter < DataSets.length(); iDataIter++) {
            	JSONObject DataSet = DataSets.getJSONObject(iDataIter);
            	
            	JSONObject jsTestDSReps = new JSONObject();
            	
            	iNoOfTestCase=iNoOfTestCase+1;
            	iNoOfTestDS=iNoOfTestDS+1;
            	String TestResults=DataSet.getJSONObject("Output").get(Constants.RESULT).toString();
            	  if((TestResults.startsWith("Pass") || TestResults.startsWith("PASS"))){
					  iNoOfPass=iNoOfPass+1;
					  iNoOfDSPass=iNoOfDSPass+1;
				  }
				  else if((TestResults.startsWith("Fail") || TestResults.startsWith("FAIL"))){
					  iNoOfFail=iNoOfFail+1;
					  iNoOfDSFail=iNoOfDSFail+1;
					  if(suite_result.equals(""))
						  suite_result=Constants.KEYWORD_FAIL;
				  }
				  else if((TestResults.startsWith("Skip") ||TestResults.startsWith("skip")|| TestResults.startsWith("SKIP")||TestResults.isEmpty())){
					  TestResults=Constants.KEYWORD_SKIP;
					  iNoOfSkip=iNoOfSkip+1;
					  iNoOfDSSkip=iNoOfDSSkip+1;
				  }
            	
            	  jsTestDSReps.put(Constants.DATASET, DataSet.get(Constants.DATASET).toString());
            	  jsTestDSReps.put(Constants.UserPermissions, DataSet.get(Constants.UserPermissions).toString());
            	  jsTestDSReps.put(Constants.DataDescription, DataSet.get(Constants.DataDescription).toString());
            	  jsTestDSReps.put(Constants.RepAPIRequest, DataSet.get(Constants.RepAPIURL).toString());
            	  jsTestDSReps.put(Constants.headers, DataSet.get(Constants.headers).toString());
            	  jsTestDSReps.put(Constants.RepInput_KeyValues, DataSet.getJSONObject("RequestParameters").getJSONObject(Constants.postbody).toString());
            	  jsTestDSReps.put(Constants.RepExpected, DataSet.get(Constants.RepExpected).toString());
            	  jsTestDSReps.put(Constants.RepTestResultStatus, TestResults);
            	  jsTestDSReps.put(Constants.RepStatusCode, DataSet.getJSONObject(Constants.output).get(Constants.RepStatusCode).toString());
            	  jsTestDSReps.put(Constants.RepResponseDescription, DataSet.getJSONObject(Constants.output).get(Constants.RepResponseDescription).toString());
            	  jsTestDSReps.put(Constants.RepOutput_Values, DataSet.getJSONObject(Constants.output).get(Constants.RepOutput_Values).toString());
            	  jsTestDSReps.put(Constants.RepResponseTime, DataSet.getJSONObject(Constants.output).get(Constants.RepResponseTime).toString());
            	  String ResponseText=  DataSet.getJSONObject(Constants.output).getString(Constants.RepResponse);
            	  jsTestDSReps.put(Constants.RepResponse, ResponseText);
            	  jsTestDSReps.put(Constants.ResponseFilePath, DataSet.getJSONObject(Constants.output).get("ResponseFilePath").toString());
            	
            	  RepArrDataSets.put(jsTestDSReps);
            }
            
            jsTestReps.put(Constants.JSsuitDataSets, RepArrDataSets);
            
            jsTestReps.put(Constants.JSsuiteNoOfTestCases, iNoOfTestDS);
            jsTestReps.put(Constants.JSsuiteNoOfPassed, iNoOfDSPass);
            jsTestReps.put(Constants.JSsuiteNoOfFailed, iNoOfDSFail);
            jsTestReps.put(Constants.JSsuitNoOfSkipped, iNoOfDSSkip);
  		  
            RepTests.put(jsTestReps);
           
	      	}
	      JsonTSuite.put(Constants.JSsuitTest, RepTests);
	      
	      if(suite_result.equals("FAIL"))
			  JsonTSuite.put(Constants.JSsuiteStatus, "Fail");
		  else
			  JsonTSuite.put(Constants.JSsuiteStatus, "Pass");
	      
	      JsonTSuite.put(Constants.JSsuiteNoOfTestCases, iNoOfTestCase);
		  JsonTSuite.put(Constants.JSsuiteNoOfPassed, iNoOfPass);
		  JsonTSuite.put(Constants.JSsuiteNoOfFailed, iNoOfFail);
		  JsonTSuite.put(Constants.JSsuitNoOfSkipped, iNoOfSkip);
		  JsonTSuites.put(JsonTSuite);
	      
	      }
	      jsReportData.put(Constants.JSsuite, JsonTSuites);
	      
	     // System.out.println("Input ReportData : \n"+JsonTestReport);
	      //System.out.println("Final ReportData : \n"+jsReportData);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	      return jsReportData;
	}
	
	/***************************************************************************************
 	 *  Function name 		: GenerateJSONReport
 	 *  Reuse Function 		:  
 	 *  Description 		: To generate excel testresult into JSON
 	/****************************************************************************************/ 
	public JSONObject BuildJSONReport(JSONObject JsonTestReport)
	{
	     //Initialize Test case summary Count
		int iNoOfTestCase=0,iNoOfPass = 0,iNoOfFail=0,iNoOfSkip=0;    
		JSONObject jsTestData = new JSONObject(JsonTestReport.toString());
		JSONObject jsReportData = new JSONObject();
		try{
			
		//System.out.println("Input ReportData : "+JsonTestReport);
		//Create Report Folder
		Date d = new Date();
		 // Add test report details
		jsReportData.put(Constants.JSReportTitle, "PAUIR Automation API Test Report");
		jsReportData.put(Constants.JSRunDate, d.toString());
		jsReportData.put(Constants.JSRunEnvironment, FileReaderManager.getInstance().getConfigReader().getEnvironment());
		jsReportData.put(Constants.JSTestingType, Constants.TestingType);
        
	     // JsonArray JsonTSuites = new JsonArray();
	      JSONArray JsonTSuites = new JSONArray();
	      
	      for (int iSuiteIter = 0; iSuiteIter < 1; iSuiteIter++)
	      {
	    	  String suite_result="";
		  // create a JsonTSuite
	      JSONObject JsonTSuite = new JSONObject();
	      JsonTSuite.put(Constants.JSProject, Constants.JIRAProject);
	      JsonTSuite.put(Constants.JSTestingType, Constants.TestingType);
	      //JsonTSuite.put(Constants.JSExecutionDuration, Constants.ExecutionDuration+Constants.TimeType);
	      JsonTSuite.put(Constants.JSExecutionDuration, jsTestData.getString(Constants.JSExecutionDuration));
	      //Tests
	      JSONArray TestSets = (JSONArray) jsTestData.get("Tests");
        
	      //Tests Report
	      JSONArray RepTests = new JSONArray();
	      for (int iTestIter = 0; iTestIter < TestSets.length(); iTestIter++) {
        	JSONObject Testset = TestSets.getJSONObject(iTestIter);
        	JSONObject jsTestReps = new JSONObject();
        	jsTestReps.put(Constants.RepIssue_key, Testset.get(Constants.TCID).toString());
		  	jsTestReps.put(Constants.RepAPIMethodType, Testset.get(Constants.MethodType).toString());
		  	jsTestReps.put(Constants.RepAPIURL, Testset.get(Constants.RepAPIRequest).toString());
		  	jsTestReps.put(Constants.RepAPIDescription, Testset.get(Constants.Summary).toString());
		  	jsTestReps.put(Constants.RepTestResultStatus,  Testset.get(Constants.TestStatus).toString());
            //DataSets
		  	int iNoOfTestDS=0,iNoOfDSPass = 0,iNoOfDSFail=0,iNoOfDSSkip=0;
		  	JSONArray RepArrDataSets = new JSONArray();
            JSONArray DataSets = (JSONArray) Testset.get("Datasets");
            for (int iDataIter = 0; iDataIter < DataSets.length(); iDataIter++) {
            	JSONObject DataSet = DataSets.getJSONObject(iDataIter);
            	
            	JSONObject jsTestDSReps = new JSONObject();
            	
            	iNoOfTestCase=iNoOfTestCase+1;
            	iNoOfTestDS=iNoOfTestDS+1;
            	String TestResults=DataSet.getJSONObject("Output").get(Constants.RESULT).toString();
            	  if((TestResults.startsWith("Pass") || TestResults.startsWith("PASS"))){
					  iNoOfPass=iNoOfPass+1;
					  iNoOfDSPass=iNoOfDSPass+1;
				  }
				  else if((TestResults.startsWith("Fail") || TestResults.startsWith("FAIL"))){
					  iNoOfFail=iNoOfFail+1;
					  iNoOfDSFail=iNoOfDSFail+1;
					  if(suite_result.equals(""))
						  suite_result=Constants.KEYWORD_FAIL;
				  }
				  else if((TestResults.startsWith("Skip") ||TestResults.startsWith("skip")|| TestResults.startsWith("SKIP")||TestResults.isEmpty())){
					  TestResults=Constants.KEYWORD_SKIP;
					  iNoOfSkip=iNoOfSkip+1;
					  iNoOfDSSkip=iNoOfDSSkip+1;
				  }
            	
            	  jsTestDSReps.put(Constants.DATASET, DataSet.get(Constants.DATASET).toString());
            	  jsTestDSReps.put(Constants.UserPermissions, DataSet.get(Constants.UserPermissions).toString());
            	  jsTestDSReps.put(Constants.DataDescription, DataSet.get(Constants.DataDescription).toString());
            	  jsTestDSReps.put(Constants.RepAPIRequest, DataSet.get(Constants.RepAPIURL).toString());
            	  jsTestDSReps.put(Constants.headers, DataSet.get(Constants.headers).toString());
            	  jsTestDSReps.put(Constants.RepInput_KeyValues, DataSet.getJSONObject("RequestParameters").getJSONObject(Constants.postbody).toString());
            	  jsTestDSReps.put(Constants.RepExpected, DataSet.get(Constants.RepExpected).toString());
            	  jsTestDSReps.put(Constants.RepTestResultStatus, TestResults);
            	  jsTestDSReps.put(Constants.RepStatusCode, DataSet.getJSONObject(Constants.output).get(Constants.RepStatusCode).toString());
            	  jsTestDSReps.put(Constants.RepResponseDescription, DataSet.getJSONObject(Constants.output).get(Constants.RepResponseDescription).toString());
            	  jsTestDSReps.put(Constants.RepOutput_Values, DataSet.getJSONObject(Constants.output).get(Constants.RepOutput_Values).toString());
            	  jsTestDSReps.put(Constants.RepResponseTime, DataSet.getJSONObject(Constants.output).get(Constants.RepResponseTime).toString());
            	  String ResponseText=  DataSet.getJSONObject(Constants.output).getString(Constants.RepResponse);
            	  jsTestDSReps.put(Constants.RepResponse, ResponseText);
            	  jsTestDSReps.put(Constants.ResponseFilePath, DataSet.getJSONObject(Constants.output).get("ResponseFilePath").toString());
            	
            	  RepArrDataSets.put(jsTestDSReps);
            }
            
            jsTestReps.put(Constants.JSsuitDataSets, RepArrDataSets);
            
            jsTestReps.put(Constants.JSsuiteNoOfTestCases, iNoOfTestDS);
            jsTestReps.put(Constants.JSsuiteNoOfPassed, iNoOfDSPass);
            jsTestReps.put(Constants.JSsuiteNoOfFailed, iNoOfDSFail);
            jsTestReps.put(Constants.JSsuitNoOfSkipped, iNoOfDSSkip);
  		  
            RepTests.put(jsTestReps);
           
	      	}
	      JsonTSuite.put(Constants.JSsuitTest, RepTests);
	      
	      if(suite_result.equals("FAIL"))
			  JsonTSuite.put(Constants.JSsuiteStatus, "Fail");
		  else
			  JsonTSuite.put(Constants.JSsuiteStatus, "Pass");
	      
	      JsonTSuite.put(Constants.JSsuiteNoOfTestCases, iNoOfTestCase);
		  JsonTSuite.put(Constants.JSsuiteNoOfPassed, iNoOfPass);
		  JsonTSuite.put(Constants.JSsuiteNoOfFailed, iNoOfFail);
		  JsonTSuite.put(Constants.JSsuitNoOfSkipped, iNoOfSkip);
		  JsonTSuites.put(JsonTSuite);
	      
	      }
	      jsReportData.put(Constants.JSsuite, JsonTSuites);
	      
	     // System.out.println("Input ReportData : \n"+JsonTestReport);
	      //System.out.println("Final ReportData : \n"+jsReportData);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	      return jsReportData;
	}
	

	public String GeneratehtmlReport(JSONObject JsonTestReport,String Userrole) throws Exception 
	{
		Log._logInfo("Generate HTML Report");
		// read suite.xls
		
		String reportsDirPath=null;
		Date d = new Date();
		reportsDirPath=UMReporter.getReportPath();
		if (reportsDirPath==null) {
		String path = "./custom_report/";
		String fileNamedate = new SimpleDateFormat("yyyyMMddhhmm").format(new Date());
		result_FolderName="Reports_API_"+fileNamedate;
		reportsDirPath=path + result_FolderName;
		new File(reportsDirPath).mkdirs();
		}
		
		
		System.out.println("Generates API Test Report: "+reportsDirPath);
		String environment=JsonTestReport.getString(Constants.JSRunEnvironment);
		String version=Constants.ReleaseType+"."+Constants.BuildReleaseVersion;
		String TestingType=JsonTestReport.getString(Constants.JSTestingType);
		String SuiteName=Constants.TEST_SHEET;
		String SuiteDescription="PA5 API "+TestingType+" Testing -"+Userrole;
		String Filename="API_Execution_Result.html";
		if (!Userrole.equalsIgnoreCase("SystemAdmin"))
			Filename="API_Execution_"+Userrole+"_Result.html";
		String reporthtmlfile="./"+Filename;
		
		// create index.html
		String indexHtmlPath=reportsDirPath+"/"+Filename;
		new File(indexHtmlPath).createNewFile();
		try{
			  
			  FileWriter fstream = new FileWriter(indexHtmlPath);
			  BufferedWriter out = new BufferedWriter(fstream);
			  out.write("<html><HEAD> <TITLE>Automation Test Results</TITLE></HEAD>");
			  out.write("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">");
			  out.write("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>");
			  out.write("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>");
			  out.write("<script>");
			  out.write("$(function () {\r\n" + 
			  		"        $(\".resPopup\").click(function () {\r\n" + 
			  		"			   var getdataId = $(this).attr(\"data-id\");\r\n" + 
			  		"			document.getElementById(\"myModTitle\").innerHTML = getdataId;\r\n" + 
			  		"			  var getdatatext = $(this).attr(\"data-text\");\r\n" + 
			  		"			document.getElementById(\"myP\").innerHTML = getdatatext;" + 
			  		"            $(\"#myModal\").modal();\r\n" + 
			  		"        })\r\n" + 
			  		"    });");
			  out.write("$(document).ready(function(){\r\n" + 
			  		"    $(\".toggler\").click(function(e){\r\n" + 
			  		"        e.preventDefault();\r\n" + 
			  		"		$(this)\r\n" + 
			  		"        $('.testds'+$(this).attr('data-testds')).toggle();\r\n" + 
			  		"    });\r\n" + 
			  		"	$('.expandalltoggler').on('click', function(e){\r\n" + 
			  		"		var dataset = $('#mysuitestab tbody').find('tr[class^=\"testds\"]');\r\n" + 
			  		"		dataset.each(function(index) {\r\n" + 
			  		"		item = $(this);\r\n" + 
			  		"		item.toggle();\r\n" + 
			  		"	  });\r\n" + 
			  		"    });\r\n" + 
			  		"	$(\".totaltc\").click(function(e){\r\n" + 
			  		"	  var dataset = $('#mysuitestab tbody').find('tr.tcsuite');\r\n" + 
			  		"	  dataset.each(function(index) {\r\n" + 
			  		"		item = $(this);\r\n" + 
			  		"		item.show();\r\n" + 
			  		"	  });\r\n" + 
			  		"	});\r\n" + 
			  		"	\r\n" + 
			  		"	$(\".tcfilter\").click(function(e){\r\n" + 
			  		"		var selectstatus= $(this).attr('title');\r\n" + 
			  		"		console.log(selectstatus);\r\n" + 
			  		"		var dataset = $('#mysuitestab tbody').find('tr.tcsuite');\r\n" + 
			  		"		dataset.each(function(index) {\r\n" + 
			  		"		item = $(this);\r\n" + 
			  		"		item.hide();\r\n" + 
			  		"		var firstTd = item.find('td:nth-child(5)');\r\n" + 
			  		"		var text = firstTd.text();\r\n" + 
			  		"		var ids = text.split(',');\r\n" + 
			  		"		for (var i = 0; i < ids.length; i++)\r\n" + 
			  		"		{\r\n" + 
			  		"			if (ids[i] == selectstatus)\r\n" + 
			  		"			{\r\n" + 
			  		"			item.show();\r\n" + 
			  		"			}\r\n" + 
			  		"		}\r\n" + 
			  		"	  });\r\n" + 
			  		"	});\r\n" + 
			  		"	})");
			  out.write("</script>");
			  out.write("<body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u>API Automation Test Report</u></b></h4><table  border=1 cellspacing=1 cellpadding=1 ><tr><h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=250 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(d.toString());
			  out.write("</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Environment</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(environment);
			  out.write("</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>API Server</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>");
			  out.write(Constants.APIServer);
			  out.write("</b></td></tr><tr><td width=200 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Build Version</b></td><td width=300 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  out.write(version);
			  out.write("</b></td></tr><tr><td width=200 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Testing Type </b></td><td width=300 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>");
			  out.write(TestingType);
			  out.write("</b></td></tr></table><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>Report Summary:</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=15% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SUITE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Success rate</b></td>");
			  out.write("<td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of TestCases</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of Passed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Failed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Skipped</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Execution Time</b></td></tr>");
			  
			
			  String currentTestSuite=null;
			 
			  String suite_result="";
			  
			
			  JSONArray Suites = JsonTestReport.getJSONArray("suite");
			  for(int currentSuiteID=0;currentSuiteID<Suites.length();currentSuiteID++)
			   {
				  	currentTestSuite = SuiteName;
					JSONObject Suite = Suites.getJSONObject(currentSuiteID);
					 out.write("<tr><td width=10% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
					  out.write(currentTestSuite);
					  out.write("</b></td><td width=25% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>");
					  out.write(SuiteDescription);
					  out.write("</b></td><td width=10% align=center  bgcolor=");
					  int totaltc=Suite.getInt("NoOfTestCases");
					  int passtc=Suite.getInt("NoOfPassed");
					  double TCPassspercent= passtc *100 ;
					  TCPassspercent=TCPassspercent/totaltc;
					  
					  DecimalFormat df2 = new DecimalFormat("#.##");
					  df2.setRoundingMode(RoundingMode.UP);
					  String SuccRate=df2.format(TCPassspercent);
				
					 // System.out.println("TCPassspercent : "+SuccRate);
					  suite_result=Suite.getString("Status");
						  if(suite_result.equals("FAIL"))
							  	out.write("red><FONT COLOR=153E7E FACE=Arial SIZE=2><b>FAIL</b></td>");
						  else
							  	out.write("green><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+SuccRate+"% </b></td>");
					 
						 
					  
					  out.write("<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><a href=\"#\" class=\"totaltc\" title=\"total\"><span value>"+Suite.get("NoOfTestCases").toString()+"</span></td>");
					  out.write("<td width=10% align=center  bgcolor=green><FONT COLOR=153E7E FACE=Arial SIZE=2><a href=\"#\" class=\"tcfilter\"  title=\"Pass\"><span>"+Suite.get("NoOfPassed").toString()+"</span></td>");
					  out.write("<td width=10% align=center  bgcolor=red><FONT COLOR=153E7E FACE=Arial SIZE=2><a href=\"#\" class=\"tcfilter\" title=\"Failed\"><span>"+Suite.get("NoOfFailed").toString()+"</span></a></td>");
					  out.write("<td width=10% align=center  bgcolor=yellow><FONT COLOR=153E7E FACE=Arial SIZE=2><a href=\"#\" class=\"tcfilter\" title=\"Skip\"><span>"+Suite.get("NoOfSkipped").toString()+"</span></a></td>");
					  out.write("<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+Suite.get("TimeTaken").toString()+"</b></td></tr>");
					  
					  
				    //Close the output stream
					  out.write("</table>");
					  

//			    	 String testSteps_file=reportsDirPath+"\\"+currentTestSuite+"_steps.html";
//					 new File(testSteps_file).createNewFile();						  
//					  FileWriter fstream_test_steps= new FileWriter(testSteps_file);
					  BufferedWriter out_test_steps=out;
					  
					  out_test_steps.write("<table id=\"mysuitestab\" width=100% border=1 cellspacing=1 cellpadding=1 >");
					  out_test_steps.write("<thead><tr><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>Detailed Test Results :</u></br>");
					  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("<a href=\"#\" class=\"expandalltoggler\" data-testds=\"0\"><span FONT COLOR=#ffffff>+</span>");
					  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("TCNO");
					  out_test_steps.write("<td align= center width=35% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("Suite/Description");
					  out_test_steps.write("<td align= center width=30% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("OperationId");
					  out_test_steps.write("<td align= center width=15% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("TestStatus");
					  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("No Of Datasets");
					  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("No Of Passed");
					  out_test_steps.write("<td align= center width=5% bgcolor=#153E7E><FONT COLOR=#ffffff FACE= Arial  SIZE=2><b>");
					  out_test_steps.write("No Of Fail/Skip");
					  
					  
					  out_test_steps.write("</b></tr></thead><tbody>");
					  
					  JSONArray TestSets = Suite.getJSONArray("tests");
					  int testid;
					  String CTestid="";
					  String reqUrl;
					  String APIURL="";
					  String reqMethod;
					  String TestCaseid="";
					  int ifailedcnt=0;
					  int iskipedcnt=0;
					  String RequestbdyText="";
					  String HeaderText="";
					  for(int currentTestCaseID=0;currentTestCaseID<TestSets.length();currentTestCaseID++)
					   {
							JSONObject TestSet = TestSets.getJSONObject(currentTestCaseID);

							testid=currentTestCaseID+1;
							CTestid=String.valueOf(testid);
							out_test_steps.write("<tr class=\"tcsuite\">"); 
							out_test_steps.write("<td align= center><a href=\"#\" class=\"toggler\" data-testds=\""+CTestid+"\"><span>+</span></a>"); 
							out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							out_test_steps.write(CTestid);
							out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							out_test_steps.write(TestSet.getString(Constants.RepAPIDescription));
						   	
							TestCaseid=TestSet.getString(Constants.RepIssue_key);
							out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							out_test_steps.write(TestCaseid);
						   	
							
							
							String data=TestSet.getString(Constants.RepTestResultStatus);
						    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
								  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  }
							  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
								  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								  if(suite_result.equals(""))
									  suite_result="FAIL";
							  }
							  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
								  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  }
							  else {
								  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							  }
						    out_test_steps.write(data );
							
//						   	out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
//							out_test_steps.write(TestSet.get("NoOfTestCases").toString());
//							
							out_test_steps.write("<td align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+TestSet.get("NoOfTestCases").toString()+"</b></td>");
							out_test_steps.write("<td align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+TestSet.get("NoOfPassed").toString()+"</b></td>");
							ifailedcnt=TestSet.getInt("NoOfFailed");
							iskipedcnt=TestSet.getInt("NoOfSkipped");
							ifailedcnt=ifailedcnt+iskipedcnt;
							out_test_steps.write("<td align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+ifailedcnt+"</b></td>");
							//out_test_steps.write("<td width=10% align=center  bgcolor=green><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+TestSet.get("NoOfPassed").toString()+"</b></td>");
							
							//out_test_steps.write("<td width=10% align=center  bgcolor=red><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+ifailedcnt+"</b></td>");
							//out_test_steps.write("<td width=10% align=center  bgcolor=yellow><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+TestSet.get("NoOfSkipped").toString()+"</b></td>");
							
							out_test_steps.write("</tr>");
							
							//DataSet Table

							out_test_steps.write("<tr class=\"testds"+CTestid+"\" style=\"display:none\">");
//							 out_test_steps.write("<table width=100% border=1 cellspacing=1 cellpadding=1 >");
//							  out_test_steps.write("<tr>");
							 out_test_steps.write("<td align= center width=5% bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write(" - ");
							  out_test_steps.write("<td align= center width=5% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("DataID");
							  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("DataDescription");
							  out_test_steps.write("<td align= center width=30% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("RequestURL");
							  out_test_steps.write("<td align= center width=15% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("TestDataStatus");
							  out_test_steps.write("<td align= center width=25% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("ResponseCode");
							  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("ResponseTime");
							  out_test_steps.write("<td align= center width=10% bgcolor=#FBA802><FONT COLOR=#000000 FACE= Arial  SIZE=2><b>");
							  out_test_steps.write("Response");

							  out_test_steps.write("</b></tr>");
							  String DataTestsetid=null;
							  JSONArray ArrDataSets = TestSet.getJSONArray(Constants.JSsuitDataSets);
							 
							  for(int currentDatSetID=0;currentDatSetID<ArrDataSets.length();currentDatSetID++)
							   {
								  JSONObject TestDataSet = ArrDataSets.getJSONObject(currentDatSetID);
								  
								  
								  out_test_steps.write("<tr class=\"testds"+CTestid+"\" style=\"display:none\">");
									
									out_test_steps.write("<td align= center><span>-</span></a>");
									DataTestsetid=TestDataSet.getString(Constants.DATASETID);
									out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									out_test_steps.write(DataTestsetid);
									out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									out_test_steps.write(TestDataSet.getString(Constants.DataDescription));
								   	out_test_steps.write("<td align= left bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
							
								   	//Constants.APIServer
								   	reqUrl=TestDataSet.getString(Constants.RepAPIRequest);
								   	APIURL= TestSet.getString(Constants.RepAPIURL);
								   	reqMethod=TestSet.getString(Constants.RepAPIMethodType).toUpperCase();
								   	
								   	
									//out_test_steps.write(reqUrl);
									RequestbdyText=TestDataSet.getString(Constants.RepInput_KeyValues);
									HeaderText=TestDataSet.getString(Constants.headers);
									//HeaderText="RequestHeader:"+HeaderText;
									reqUrl="RequestURL:"+reqUrl;
									if (RequestbdyText.length()>2) {
											//RequestbdyText="RequestBody:"+RequestbdyText;
											RequestbdyText=RequestbdyText.replaceAll("\\s", "'");
											out_test_steps.write("<a href=# class=\"resPopup\" data-id="+reqUrl+" data-text="+RequestbdyText+" >"+reqMethod +"</a> "+APIURL);
									}
									else {
										
										out_test_steps.write("<a href=# class=\"resPopup\" data-id="+reqUrl+" data-text="+HeaderText+" >"+reqMethod +"</a> "+APIURL);
										
									}
									
									data=TestDataSet.getString(Constants.RepTestResultStatus);
								    if((data.startsWith("Pass") || data.startsWith("PASS")) ){
										  out_test_steps.write("<td align=center bgcolor=green><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  }
									  else if((data.startsWith("Fail") || data.startsWith("FAIL")) ){
										  out_test_steps.write("<td align=center bgcolor=red><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
										  if(suite_result.equals(""))
											  suite_result="FAIL";
									  }
									  else if((data.startsWith("Skip") || data.startsWith("SKIP"))){
										  out_test_steps.write("<td align=center bgcolor=yellow><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  }
									  else {
										  out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									  }
								    out_test_steps.write(data );
								
								    out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
								    String RespDesc=TestDataSet.getString(Constants.RepResponseDescription);
								    String RespStatuscode=TestDataSet.getString(Constants.RepStatusCode);
								    //RespDesc=RespDesc.replace("\n", "<br>");
									//out_test_steps.write(RespDesc);
									
									if (RespDesc.length()>2) {
										//RequestbdyText="RequestBody:"+RequestbdyText;
										RespDesc=RespDesc.replaceAll("\\s", "'");
										out_test_steps.write("<a href=# class=\"resPopup\" data-id=\"ResponseDescription\" data-text=\""+RespDesc+"\" >"+RespStatuscode +"</a> ");
								}
								else {
									
									out_test_steps.write(RespStatuscode);
									
								}
									
									out_test_steps.write("<td align= center bgcolor=#ffffff><FONT COLOR=#000000 FACE= Arial  SIZE=2>");
									out_test_steps.write(TestDataSet.getString(Constants.RepResponseTime));
									out_test_steps.write("<td>");
									String ResponseText = TestDataSet.getString(Constants.RepResponse);
									String ResponseText1=null;
									String ResponseText2=null;
									String mwdataid=TestCaseid+" - "+DataTestsetid;
									if (ResponseText.length()>2)
										if (!ResponseText.contains("html")) {
											//Reduce report size
											if (ResponseText.length() > 60000) { 
												ResponseText2 = ResponseText.substring(0, 50000);
												ResponseText2=ResponseText2+"..."+
												"..."+
												"...";
												ResponseText=ResponseText2;
											}
											//Remove double quotes
											//  ResponseText2=ResponseText.replaceAll("\"", "'");
											//Remove spaces	
											ResponseText1=ResponseText.replaceAll("\\s", "'");
											mwdataid="Response:"+mwdataid;
											out_test_steps.write("<a href=# class=\"resPopup\" data-id="+mwdataid+" data-text="+ResponseText1+" >"+DataTestsetid +"</a>");
										}
										else 
											out_test_steps.write(DataTestsetid);
									
									else
										out_test_steps.write(DataTestsetid);
									
									out_test_steps.write("</td>"); 
									out_test_steps.write("</tr>");
								  
							   }
//							  out_test_steps.write("</table>");
//							  out_test_steps.write("</tr>");
							  
				}					  
				  out_test_steps.write("</tbody>");
				  out_test_steps.write("</table>");  
				  
				  out_test_steps.write(" <!-- Modal -->\r\n" + 
				  		"    <div class=\"modal fade\" id=\"myModal\" role=\"dialog\">\r\n" + 
				  		"        <div class=\"modal-dialog\" style=\"width:80%;height:80%;overflow:auto;\">\r\n" + 
				  		"            <!-- Modal content-->\r\n" + 
				  		"            <div class=\"modal-content\">\r\n" + 
				  		"                <div class=\"modal-header\">\r\n" + 
				  		"                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>\r\n" + 
				  		"                    <h4 class=\"modal-title\" id=\"myModTitle\">Response</h4>\r\n" + 
				  		"                </div>\r\n" + 
				  		"                <div class=\"modal-body\"><FONT COLOR=#000000 FACE= Arial  SIZE=2>\r\n" + 
				  		"                    <p id=\"myP\">This is something response to display</p>\r\n" + 
				  		"                </div>\r\n" + 
				  		"                <div class=\"modal-footer\">\r\n" + 
				  		"                    <button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Close</button>\r\n" + 
				  		"                </div>\r\n" + 
				  		"            </div>\r\n" + 
				  		"\r\n" + 
				  		"        </div>\r\n" + 
				  		"    </div>\r\n" + 
				  		"</div>");  
				  out_test_steps.write("</body>");
				  out_test_steps.write("</html>");
				  out_test_steps.close();
				 
				
			
			     }
			   
		}
			  catch (Exception e){//Catch exception if any
			  System.err.println("Error: " + e.getMessage());
			  e.printStackTrace();
		  }
		return reporthtmlfile;
	}
	
	
	

	public void GenerateTestDataJsonfromswagger() throws Exception 
	{
		Log._logInfo("Generate TestData Json from Swagger json file");
		
		File swagfile = new File(System.getProperty("user.dir")+"\\src\\main\\resources\\com\\pauir\\testDataResources\\swagger.json"); 			
		String jsonswagcontent = FileUtils.readFileToString(swagfile, "utf-8");
		JSONObject JsonswagData = new JSONObject(jsonswagcontent);
		
		JSONObject JsonTestData = null;
		JSONArray JsonArrTestData = new JSONArray();
		
		JSONObject Swagjson=JsonswagData.getJSONObject("paths");
   	    Iterator<String> keysItr = Swagjson.keys();
   	    while(keysItr.hasNext()) {
   	    	JsonTestData = new JSONObject();
   	    	JsonTestData.put(Constants.TESTRUNMODE, "No");
   	        String ReqUrl = keysItr.next();
   	        JsonTestData.put(Constants.URL, ReqUrl);
   	        //System.out.println("Req: " +key);
   	        JSONObject jsReqMethod = Swagjson.getJSONObject(ReqUrl);
   	        Iterator<String> keysItr1 = jsReqMethod.keys();
	   	    while(keysItr1.hasNext()) {
	   	    	String RegMethod = keysItr1.next();
	   	    	System.out.println("Req : " +RegMethod+" - "+ReqUrl);
	   	    	JsonTestData.put(Constants.MethodType, RegMethod);
	   	    	JSONObject reqdata = jsReqMethod.getJSONObject(RegMethod);
	   	    	if (reqdata.has(Constants.TCID))
	   	    		JsonTestData.put(Constants.TCID, reqdata.get(Constants.TCID));
	   	    	else
	   	    		JsonTestData.put(Constants.TCID, "");
	   	    	
	   	    	
	   	    	if (reqdata.has(Constants.Summary))
	   	    		JsonTestData.put(Constants.Summary, reqdata.get(Constants.Summary));
	   	    	else
	   	    		JsonTestData.put(Constants.Summary, "");
	   	    	
	   	    	if (RegMethod.equalsIgnoreCase("get"))
	   	    		JsonTestData.put(Constants.ExeTag, "@smoke,@regression");
	   	    	else
	   	    		JsonTestData.put(Constants.ExeTag, "@regression");
	   	    	
	   	    	JSONArray JsonArrDependentTest = new JSONArray();
	   	    	
	   	    	JsonTestData.put(Constants.Dependent, JsonArrDependentTest);
	   	    	
	   	    	//Dataset
	   	    	JSONObject JsonTestDataSet = new JSONObject();
	   			JSONArray JsonArrTestDataSets = new JSONArray();
	   			JSONObject Jsonheader =new JSONObject();
	   			JSONObject JsonTestParms =new JSONObject();
	   			JSONObject JsonExpected =new JSONObject();
	   			JSONObject JsonOuput =new JSONObject();
	   			
//	   			JsonTestDataSet.put(Constants.DATAFLAG, "Yes");
//	   			JsonTestDataSet.put(Constants.DATASETID, "DS01");
	   			Jsonheader.put("orgreferenceid", "{ref#environment|StateRefID}");
	   			JsonTestDataSet.put(Constants.headers, Jsonheader);
	   			
	   			JSONArray JsonArrParams = new JSONArray();
	   	    	if (reqdata.has(Constants.parameters)) {
	   	    		JsonArrParams=reqdata.getJSONArray(Constants.parameters);
	   	    		JsonTestParms = GetParameters(JsonArrParams);
	   	    	}
	   	    	else
	   	    		JsonTestParms = GetParameters(JsonArrParams);
	   	    	
	   	    	JsonTestDataSet.put(Constants.requestparameters, JsonTestParms);
	   	    		
	   	    JsonExpected.put("StatusCode", "200");
	   	    JsonExpected.put("Expected_Keys", "");
	   	    JsonExpected.put("Expected_Values", "");
	   	    JsonExpected.put("GetOutputKey", "");
	   	    JsonTestDataSet.put(Constants.expected, JsonExpected);
	   	    JsonOuput.put("TestResultStatus", "");
	   	    JsonOuput.put("StatusCode", "");
	   	    JsonOuput.put("Response", "");
	   	    JsonOuput.put("ResponseDescription", "");
	   	    JsonOuput.put("ResponseTime", "");
	   	    JsonOuput.put("ResponseFilePath", "");
	   	    JsonOuput.put("Output_Values", "");
	   	    JsonTestDataSet.put(Constants.output, JsonOuput);
	   	    
	   	    JsonArrTestDataSets.put(JsonTestDataSet);
	   	    
	   	 JsonTestData.put(Constants.DATASETS, JsonArrTestDataSets);
	   	  }
	   	    
	   	 JsonArrTestData.put(JsonTestData);
   	    }
   	    
   	 System.out.println("JsonArrTestData : "+JsonArrTestData);

	}
	
	 /*************************************************************************************************
	 *  Function name 		: GetParameters
	 *  Reuse Function 		: 
	 *  Description 		: Get the Parameter reference value from the Swagger  
	/**************************************************************************************************/   
	public static JSONObject GetParameters(JSONArray JsTestParameters){
		JSONObject JsonTestData = new JSONObject();
		JSONObject JsonPathParameter = new JSONObject();
		JSONObject JsonQueryParameter = new JSONObject();
		JSONObject JsonPostBody = new JSONObject();
		JSONArray TestParameters = JsTestParameters;
        for (int iTestIter = 0; iTestIter < TestParameters.length(); iTestIter++) {
        	JSONObject TestParameter = TestParameters.getJSONObject(iTestIter);
        	if (TestParameter.has("in")) {
        		if (TestParameter.getString("in").equalsIgnoreCase("path"))
        			JsonPathParameter.put(TestParameter.getString("name"), "");
        		if (TestParameter.getString("in").equalsIgnoreCase("query"))
        			JsonQueryParameter.put(TestParameter.getString("name"), "");
        	}
        	else
        		if (TestParameter.has("name")) 
        			JsonQueryParameter.put(TestParameter.getString("name"), "");
        		
        }
        
        JsonTestData.put(Constants.pathparameters, JsonPathParameter);
        JsonTestData.put(Constants.Queryparameters, JsonQueryParameter);
        JsonTestData.put(Constants.postbody, JsonPostBody);
    	return JsonTestData;
    }
	

	

	public static void GenerateExcelTestDataFromSwagger(String InputXLFileNmae, String InputSheetName ) throws Exception 
	{

		// Export Tests from Swagger File
		File swagfile = new File(System.getProperty("user.dir")+"\\src\\main\\resources\\com\\pauir\\testDataResources\\swagger.json"); 			
		String jsonswagcontent = FileUtils.readFileToString(swagfile, "utf-8");
		JSONObject JsonswagData = new JSONObject(jsonswagcontent);
		
		//Initialize test case sheer
		String XLFileNmae=InputXLFileNmae;
		String SheetName=InputSheetName;
		int NewRow=1;
		//System.out.println(SheetName+" : "+TCID+" : "+TestScenario+" : "+Description+" : "+InputDetails+" : "+Expected+" : "+Status+" : "+Actuals+" : "+Comments);
		Xls_Reader current_TestCase_xls=null;
        
  	 	current_TestCase_xls=new Xls_Reader(XLFileNmae);
	  	boolean SheetExist=current_TestCase_xls.isSheetExist(SheetName);
	  	//System.out.println("SheetName Exist"+SheetExist);
	  	if (SheetExist){
			JSONObject Swagjson=JsonswagData.getJSONObject("paths");
	   	    Iterator<String> keysItr = Swagjson.keys();
	   //	 int rowCount= current_TestCase_xls.getRowCount(SheetName);
	   	    while(keysItr.hasNext()) {
	   	        String ReqUrl = keysItr.next();
	   	        //System.out.println("Req: " +key);
	   	        JSONObject jsReqMethod = Swagjson.getJSONObject(ReqUrl);
	   	        Iterator<String> keysItr1 = jsReqMethod.keys();
		   	    while(keysItr1.hasNext()) {
		   	    	String RegMethod = keysItr1.next();
		   	    	System.out.println("Req : " +RegMethod+" - "+ReqUrl);
		   	    	NewRow=NewRow+1;
		   	    	current_TestCase_xls.setCellData(SheetName, "RunMode", NewRow, "No");
		   	    	current_TestCase_xls.setCellData(SheetName, "RequestURL", NewRow, ReqUrl);
		   	    	current_TestCase_xls.setCellData(SheetName, "MethodType", NewRow, RegMethod);
		   	    	JSONObject reqdata = jsReqMethod.getJSONObject(RegMethod);
		   	    	if (reqdata.has("operationId"))
		   	    		current_TestCase_xls.setCellData(SheetName, "operationId", NewRow, reqdata.get("operationId").toString());
		   	    	else
		   	    		current_TestCase_xls.setCellData(SheetName, "operationId", NewRow, "");

		   	    	if (reqdata.has("summary"))
		   	    		current_TestCase_xls.setCellData(SheetName, "summary", NewRow, reqdata.get("summary").toString());
		   	    	else
		   	    		current_TestCase_xls.setCellData(SheetName, "summary", NewRow, "");
		   	    	
		   	    	if (RegMethod.equalsIgnoreCase("get"))
		   	    		current_TestCase_xls.setCellData(SheetName, "tags", NewRow, "@smoke,@regression");
		   	    	else
		   	    		current_TestCase_xls.setCellData(SheetName, "tags", NewRow, "@regression");
		   	    	
		   	    	JSONArray JsonArrDependentTest = new JSONArray();
		   	    	
		   	    	current_TestCase_xls.setCellData(SheetName, "Dependent", NewRow,JsonArrDependentTest.toString());
		   			current_TestCase_xls.setCellData(SheetName, "DSFlag", NewRow, "Yes");
		   			current_TestCase_xls.setCellData(SheetName, "DatasetID", NewRow, "DS01");
		   			JSONArray JsonArrParams = new JSONArray();
		   	    	if (reqdata.has("parameters")) {
		   	    		JsonArrParams=reqdata.getJSONArray("parameters");
		   	    		Map<String,String> testCaseResult  = GetSetParameters(JsonArrParams);
		   	    		current_TestCase_xls.setCellData(SheetName, "PathParam_Keys", NewRow, testCaseResult.get("Pathparameters"));
		   	    		current_TestCase_xls.setCellData(SheetName, "QueryParam_Keys", NewRow, testCaseResult.get("Queryparameters"));
		   	    	}
		   
		   	  }
		   	 }
   	    
		  }
		 System.out.println("Swagger exported to excel - done ");

	}
	
	 /*************************************************************************************************
	 *  Function name 		: GetParameters
	 *  Reuse Function 		: 
	 *  Description 		: Get the Parameter reference value from the Swagger  
	/**************************************************************************************************/   
	public static Map<String,String> GetSetParameters(JSONArray JsTestParameters){
		
		JSONArray TestParameters = JsTestParameters;
		String PathParameter="";
		String QueryParameter="";
		 Map<String,String> testCaseResult = new HashMap<String,String>();
        for (int iTestIter = 0; iTestIter < TestParameters.length(); iTestIter++) {
        	JSONObject TestParameter = TestParameters.getJSONObject(iTestIter);
        	if (TestParameter.has("in")) {
        		if (TestParameter.getString("in").equalsIgnoreCase("path")) {
        			if (PathParameter.length()>1)
        				PathParameter=PathParameter+"|"+TestParameter.getString("name");
        			else
        				PathParameter=TestParameter.getString("name");
        				
        		}
        		if (TestParameter.getString("in").equalsIgnoreCase("query")) {
        			
        			if (QueryParameter.length()>1)
        				QueryParameter=QueryParameter+"|"+TestParameter.getString("name");
        			else
        				QueryParameter=TestParameter.getString("name");
        		}
        	}
        	else {
        		if (TestParameter.has("name")) {
        			if (QueryParameter.length()>1)
        				QueryParameter=QueryParameter+"|"+TestParameter.getString("name");
        			else
        				QueryParameter=TestParameter.getString("name");
        		}
        	}
        		
        }
        
     
        testCaseResult.put("Pathparameters", PathParameter);
        testCaseResult.put("Queryparameters", QueryParameter);
        testCaseResult.put("postbody", "{}");
    	return testCaseResult;
    	
    }
	
	
	
	/*************************************************************************************************
	 *  Function name 		: GenerateTestDataFromExcelData
	 *  Reuse Function 		: 
	 *  Description 		: Read the all the Excel values.Based on the inputs flow the functionality. 
	/
	 * @throws ProcessingException **************************************************************************************************/  
    public void GenerateUserroleTestDataFromExcelData(String XlFile, String XlSheet, String ColName)throws AbstractMethodError
    {
    	
    	Log._logInfo("Generate User role permission matrix from Excel Sheet");
        String TCID,RunMode1;
        String XLInputSheetName,XlsxInputFile = null;
        String UserdataPermissions;
        Xls_Reader current_TestCase_xls=null;
        //Get Input Sheet
        XlsxInputFile=XlFile;
	    XLInputSheetName=XlSheet;
	    //Set Input file name
	    current_TestCase_xls=new Xls_Reader(XlsxInputFile);
	 	int TEST_STEPS_rows= current_TestCase_xls.getRowCount(XLInputSheetName);			
		for(int rowNum=2;rowNum<=TEST_STEPS_rows;rowNum++)
		{
			
			//Test Iteration
			RunMode1=current_TestCase_xls.getCellData(XLInputSheetName, Constants.TESTRUNMODE, rowNum);
			TCID=current_TestCase_xls.getCellData(XLInputSheetName, Constants.TCID, rowNum);
			//UserPermissions=current_TestCase_xls.getCellData(XLInputSheetName, "Userpermissions", rowNum);
			UserdataPermissions=current_TestCase_xls.getCellData(XLInputSheetName, "DataUserpermissions", rowNum);
			
			//System.out.println("Column Wise "+MethodType+ParamKey+ParamValues+ExpectedKeys+ExpectedValues+RunMode1);
			//if (RunMode1.equalsIgnoreCase("YES"))
			if (RunMode1.length()>0)
			{
				List<String> LstUserPermissions =Rep_ExeTags(UserdataPermissions,null);
				List<String> TagsList = new ArrayList<String>();
				 try{
					 if (LstUserPermissions.size()>0) {
						 String RespStatus="";
						 if (LstUserPermissions.size()==1) {
							 if (Constants.PERMISSIONS.contains(LstUserPermissions.get(0))) { 
				        			RespStatus="Yes";
				        			TagsList.add(LstUserPermissions.get(0));
							 }
						 }
						 else {
							 for (String userpem:LstUserPermissions) {
								 if (Constants.PERMISSIONS.contains(userpem)) {
									 RespStatus="Yes";
									 TagsList.add(userpem);
								 }
							 }
						 }
						 System.out.println(TCID+" : "+RespStatus);
						 if (RespStatus.equalsIgnoreCase("Yes"))
							current_TestCase_xls.setCellData(XLInputSheetName,ColName, rowNum, RespStatus+" \n "+TagsList);
						 else
							current_TestCase_xls.setCellData(XLInputSheetName,ColName, rowNum, "No");
					 }	
				 }
				 catch(Exception e) {
					 System.out.println(e.getMessage()); 
				 }
			}
		
		}
		
	
		
      }
	
	/*************************************************************************************************
	 *  Function name 		: GenerateTestDataFromExcelData
	 *  Reuse Function 		: 
	 *  Description 		: Read the all the Excel values.Based on the inputs flow the functionality. 
	/
	 * @throws ProcessingException **************************************************************************************************/  
    public JSONObject GenerateTestDataFromExcelData(String XlFile, String XlSheet,JSONObject JsonGLBHeader)throws AbstractMethodError
    {
    	
    	Log._logInfo("Generate TestData from Excel Sheet");
        String Url,MethodType,PathParamKey,PathParamValues,QryParamKey,QryParamValues,BodyParamKey,ExpectedKeys,ExpectedValues,TCID,OpKey,RunMode1,ExpectedStatusCode;
        String Details,HeaderKey,HeaderValues;
       
        String XLInputSheetName,XlsxInputFile = null;
        String tags,Dependent,UserPermissions,DSFlag,DatasetID,DatasetTags,UserdataPermissions,DatasetDescription;
     
        Xls_Reader current_TestCase_xls=null;
        List<String> TestsList = new ArrayList<String>();
        JSONObject JsonFinalTestData  = new JSONObject();
        
    	Date d = new Date();
        // Add test report details
        JsonFinalTestData.put(Constants.JSReportTitle, "PAUIR Automation API Test Report");
        JsonFinalTestData.put(Constants.JSRunDate, d.toString());
        JsonFinalTestData.put(Constants.JSRunEnvironment, "PADEV");
		JsonFinalTestData.put(Constants.JSTestingType, Constants.TestingType);
		
		
//		JSONObject JsonGLBHeader = new JSONObject();
//		JsonGLBHeader.put("content-type", "application/json");
//		JsonGLBHeader.put("orgreferenceid", "d3d6bc4e-2bb1-41b2-865b-52c0a6c23e75");
//		JsonGLBHeader.put("authorization", "Bearer eyJraWQiOiJLNE9DelU5MG1Wd3IzRWJpeEFsQ2Y0ckZUb3RxSEJDZjBtVzVRMUl6S1hZPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI3OWEyNTY1Zi1iNzgwLTRlZTEtYWI4Yi04MmU5YWM2MWUyZTIiLCJ0b2tlbl91c2UiOiJhY2Nlc3MiLCJzY29wZSI6ImF3cy5jb2duaXRvLnNpZ25pbi51c2VyLmFkbWluIG9wZW5pZCBlbWFpbCIsImF1dGhfdGltZSI6MTU3Nzk2Njg5NywiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tXC91cy1lYXN0LTFfT2hxQWVxalNkIiwiZXhwIjoxNTc3OTcwNDk5LCJpYXQiOjE1Nzc5NjY4OTksInZlcnNpb24iOjIsImp0aSI6IjY4MWZmYTNhLWIwYTItNDQ5Zi05N2U0LWI0NjI1OGVhMWM2NCIsImNsaWVudF9pZCI6IjM2azI4dWNlZGV2bGZlNDJzMjRpODdya2swIiwidXNlcm5hbWUiOiJwYWFkbWluQHBlYXJzb24uY29tIn0.Qgu_EuRJbJimQ5KVwukJ8e-JSCBh0iFMQQ_IE8tz-DGp5WpODHBWqNx4ffwydxy_NDDon5lL2fhrTXVK45nxwzUoRsvNEE5zLHZyAYp3wpmXtdr6VLEo52Ar9WzVvzTmIFX89MVbmkIuquN8nMgQ-OwhiSo2P754b0ou3sregAaYdi72FZpd2eJv1nJAGXRHjzbfpyY_ar0HLD7YtP3Dxtzt-vMnrejh3mlmZvYd4GPWEXxo2WM1v5qwfkWRkfeRiEVx9fh0q7CSDZohJeQq-_HKiWxBQgEP8yXjuRWFZ42E-Q0ThaPx4OL1AvkMfw12WBenmqTPERTLbfY-khJPNQ");
//		
		JsonFinalTestData.put(Constants.GlobalHeader, JsonGLBHeader);
		
        JSONArray JsonArrTestData = new JSONArray();
	   
        //Get Input Sheet
        XlsxInputFile=XlFile;
	    XLInputSheetName=XlSheet;
	    //Set Input file name
	    current_TestCase_xls=new Xls_Reader(XlsxInputFile);
	 	int TEST_STEPS_rows= current_TestCase_xls.getRowCount(XLInputSheetName);			
		for(int rowNum=2;rowNum<=TEST_STEPS_rows;rowNum++)
		{
			tags=null;
			DatasetTags=null;
			//Test Iteration
			RunMode1=current_TestCase_xls.getCellData(XLInputSheetName, Constants.TESTRUNMODE, rowNum);
			MethodType=current_TestCase_xls.getCellData(XLInputSheetName,Constants.MethodType, rowNum);
			Url=current_TestCase_xls.getCellData(XLInputSheetName, Constants.URL, rowNum);
			TCID=current_TestCase_xls.getCellData(XLInputSheetName, Constants.TCID, rowNum);
			Details=current_TestCase_xls.getCellData(XLInputSheetName,Constants.Summary, rowNum);
			tags=current_TestCase_xls.getCellData(XLInputSheetName, "tags", rowNum);
			UserPermissions=current_TestCase_xls.getCellData(XLInputSheetName, "Userpermissions", rowNum);
			Dependent=current_TestCase_xls.getCellData(XLInputSheetName, "Dependent", rowNum);
			DSFlag=current_TestCase_xls.getCellData(XLInputSheetName, "DSFlag", rowNum);
			DatasetID=current_TestCase_xls.getCellData(XLInputSheetName, "DatasetID", rowNum);
			DatasetTags=current_TestCase_xls.getCellData(XLInputSheetName, "Datatags", rowNum);
			DatasetDescription=current_TestCase_xls.getCellData(XLInputSheetName, "DataDescription", rowNum);
			UserdataPermissions=current_TestCase_xls.getCellData(XLInputSheetName, "DataUserpermissions", rowNum);
			HeaderKey=current_TestCase_xls.getCellData(XLInputSheetName,"Header_Keys", rowNum);
			HeaderValues=current_TestCase_xls.getCellData(XLInputSheetName,"Header_Values", rowNum);
			PathParamKey=current_TestCase_xls.getCellData(XLInputSheetName, "PathParam_Keys", rowNum);
			PathParamValues=current_TestCase_xls.getCellData(XLInputSheetName, "PathParam_Values", rowNum);
			QryParamKey=current_TestCase_xls.getCellData(XLInputSheetName, "QueryParam_Keys", rowNum);
			QryParamValues=current_TestCase_xls.getCellData(XLInputSheetName, "QueryParam_Values", rowNum);
			BodyParamKey=current_TestCase_xls.getCellData(XLInputSheetName, "BodyParam_Keys", rowNum);
			
			OpKey=current_TestCase_xls.getCellData(XLInputSheetName, "GetOutputKey", rowNum);
			ExpectedKeys=current_TestCase_xls.getCellData(XLInputSheetName, "Expected_Keys", rowNum);
			ExpectedValues=current_TestCase_xls.getCellData(XLInputSheetName, "Expected_Values", rowNum);
			ExpectedStatusCode=current_TestCase_xls.getCellData(XLInputSheetName,"ExpectedStatusCode", rowNum);
			
			//System.out.println("Column Wise "+MethodType+ParamKey+ParamValues+ExpectedKeys+ExpectedValues+RunMode1);
			//if (RunMode1.equalsIgnoreCase("YES"))
			if (RunMode1.length()>0)
			{
				if (!TestsList.contains(TCID)){
				//Initialize test level variable
				
				JSONObject JsonTestData = null;
				
		   	    JsonTestData = new JSONObject();
		   	    JsonTestData.put(Constants.TESTRUNMODE, RunMode1);
		   	    JsonTestData.put(Constants.URL, Url);
			   	JsonTestData.put(Constants.MethodType, MethodType);
		    	JsonTestData.put(Constants.TCID, TCID);
			   	JsonTestData.put(Constants.Summary, Details);   	    	
				//JsonTestData.put(Constants.ExeTag, tags);
				
				TestsList.add(TCID);
				//Dependent
				JSONArray JsonArrDependentTest = new JSONArray();
				if (Dependent.length()>0)
					JsonArrDependentTest=Rep_DependentValues(Dependent);
				JsonTestData.put(Constants.Dependent, JsonArrDependentTest);
				
				//Datasets
				JSONArray JsonArrTestDataSets = new JSONArray();
				
				List<String> TagsList =Rep_ExeTags(tags,null);
				List<String> UserPersList =Rep_ExeTags(UserPermissions,null);
				JsonTestData.put(Constants.UserPermissions, UserPersList);
				
				List<String> DepTagsList =Rep_ExeTags(DatasetTags,TagsList);
				
				JsonTestData.put(Constants.ExeTag, DepTagsList);
			
				
				JSONObject JsonTestDataSet =SetDataset(DSFlag,DatasetID,DatasetTags,HeaderKey,HeaderValues,PathParamKey,PathParamValues,QryParamKey,QryParamValues,BodyParamKey,ExpectedStatusCode,ExpectedKeys, ExpectedValues,OpKey,UserdataPermissions,DatasetDescription);
				
		   	    JsonArrTestDataSets.put(JsonTestDataSet);
			   	JsonTestData.put(Constants.DATASETS, JsonArrTestDataSets);
			   	
			   	//System.out.println("Testset : "+JsonTestData);
			   	    
			   	JsonArrTestData.put(JsonTestData);
				
				//System.out.println("Testsets Array : "+JsonArrTestData);
				
			}
			else {
				for (int i=0; i<JsonArrTestData.length(); i++) {
				    JSONObject jstestitem = JsonArrTestData.getJSONObject(i);
				    String ExistingTCID = jstestitem.getString(Constants.TCID);
				    
				    List<String> TagsList =Rep_ExeTags(tags,null);
				    List<String> DepTagsList =Rep_ExeTags(DatasetTags,TagsList);
				    jstestitem.put(Constants.ExeTag, DepTagsList);
				    if (ExistingTCID.equalsIgnoreCase(TCID)) {
				    	JSONArray JsonArrExistingTestDataSets = jstestitem.getJSONArray("Datasets");
				    	JSONObject JsonTestDataSet =SetDataset(DSFlag,DatasetID,DatasetTags,HeaderKey,HeaderValues,PathParamKey,PathParamValues,QryParamKey,QryParamValues,BodyParamKey,ExpectedStatusCode,ExpectedKeys, ExpectedValues,OpKey,UserdataPermissions,DatasetDescription);
				    	
				    	JsonArrExistingTestDataSets.put(JsonTestDataSet);
				    }
				}
			}
		}
	 }
		
		JsonFinalTestData.put(Constants.Tests, JsonArrTestData);
		//System.out.println("TestData JSON : "+JsonFinalTestData);
		Log._logInfo("TestData generated Successfully");
		return JsonFinalTestData;
		
      }
    
    /**************************************************************************
   	 *  Function name 		: Rep_InputValues
   	 *  Reuse Function 		: 
   	 *  Description 		: Provide paired key values from  excel input key values    
   	 	/**********************************************************************/    
       public JSONObject SetDataset(String DSFlag,String DatasetID,String DatasetTags,String HeaderKey,String HeaderValues,String PathParamKey,String PathParamValues,String QryParamKey,String QryParamValues,String BodyParamKey,String ExpectedStatusCode,String ExpectedKeys,String ExpectedValues,String OpKey,String UserdataPermissions, String DatasetDescription) 
       {
   		
    	   int ExpStatusid=0;

    	//Dataset
	    	JSONObject JsonTestDataSet = new JSONObject();
		
			JSONObject Jsonheader =new JSONObject();
			JSONObject JsonTestParms =new JSONObject();
			JSONObject JsonExpected =new JSONObject();
			JSONObject JsonOuput =new JSONObject();
			JSONObject JsonPathParameter = new JSONObject();
			JSONObject JsonQueryParameter = new JSONObject();
			JSONObject JsonPostBody = new JSONObject();
			
			JsonTestDataSet.put(Constants.DATAFLAG, DSFlag);
			JsonTestDataSet.put(Constants.DATASETID, DatasetID);
			JsonTestDataSet.put(Constants.DataDescription, DatasetDescription);
			List<String> DepTagsList =Rep_ExeTags(DatasetTags,null);
			JsonTestDataSet.put(Constants.ExeTag, DepTagsList);
			
			List<String> DTUserPersList =Rep_ExeTags(UserdataPermissions,null);
			JsonTestDataSet.put(Constants.UserPermissions, DTUserPersList);
			
			//Header value
			if ((HeaderValues.length()>0))
				Jsonheader=Rep_InputValues(HeaderKey,HeaderValues);
			JsonTestDataSet.put(Constants.headers, Jsonheader);
			
			//Path Parameter input values
			if ((PathParamKey.length()>0))
				JsonPathParameter=Rep_InputValues(PathParamKey,PathParamValues);
			JsonTestParms.put(Constants.pathparameters, JsonPathParameter);
			
			// Query Parameter input values
			if ((QryParamKey.length()>0))
				JsonQueryParameter=Rep_InputValues(QryParamKey,QryParamValues);
			JsonTestParms.put(Constants.Queryparameters, JsonQueryParameter);
			
			// Body Parameter input values
			if ((BodyParamKey.length()>0)) {
				JsonPostBody= new JSONObject(BodyParamKey); 
				//JsonPostBody=Rep_InputValues(BodyParamKey,BodyParamValues);
			}
			JsonTestParms.put(Constants.postbody, JsonPostBody);
			
			JsonTestDataSet.put(Constants.requestparameters, JsonTestParms);
			if (ExpectedStatusCode.length()>0)
				ExpStatusid =(int) Double.parseDouble(ExpectedStatusCode);
	   	    JsonExpected.put("StatusCode",String.valueOf(ExpStatusid));
	   	    JsonExpected.put("Expected_Keys", ExpectedKeys);
	   	    JsonExpected.put("Expected_Values", ExpectedValues);
	   	    JsonExpected.put("GetOutputKey", OpKey);
	   	    JsonTestDataSet.put(Constants.expected, JsonExpected);
	   	    JsonOuput.put("TestResultStatus", "");
	   	    JsonOuput.put("StatusCode", "");
	   	    JsonOuput.put("Response", "");
	   	    JsonOuput.put("ResponseDescription", "");
	   	    JsonOuput.put("ResponseTime", "");
	   	    JsonOuput.put("ResponseFilePath", "");
	   	    JsonOuput.put("Output_Values", "");
	   	    JsonTestDataSet.put(Constants.output, JsonOuput);
	   	    
	   		return JsonTestDataSet;
   	}
    
    /**************************************************************************
	 *  Function name 		: Rep_InputValues
	 *  Reuse Function 		: 
	 *  Description 		: Provide paired key values from  excel input key values    
	 	/**********************************************************************/    
    public JSONObject Rep_InputValues(String PKeys,String PValues) 
    {
		JSONObject JsonTestParms =new JSONObject();
		String RetnString="";
		String sValue="";
		if ((PKeys.length()>0)&(PValues.length()>0))
		{
	        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
	        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
	        for(int i =0; i < ArKeys.length ; i++){
	        	
	        	if(i >= ArValues.length)
	        		sValue="";
	        	else
	        		sValue=ArValues[i];
	        	
	        	if (sValue.contains("_")) 
	        		sValue=sValue.replaceFirst("_","|");
	        	JsonTestParms.put(ArKeys[i], sValue);
	        	
	        	RetnString=RetnString+"\n "+ArKeys[i]+" : "+sValue;
	        }
		}
		return JsonTestParms;
	}
    
    /**************************************************************************
	 *  Function name 		: Rep_DependentValues
	 *  Reuse Function 		: 
	 *  Description 		: Provide paired key values from  excel input key values    
	 	/**********************************************************************/    
    public JSONArray Rep_DependentValues(String DependentIssues) 
    {
    	JSONArray JsonArrDependentTest = new JSONArray();
		JSONObject JsonTestParms =null;
		String RetnString="";
		if (DependentIssues.length()>0){
	        String[] ArKeys = DependentIssues.split(Constants.ValueDelimiter);
	        for(int i =0; i < ArKeys.length ; i++){
	        	JsonTestParms =new JSONObject();
	        	JsonTestParms.put(Constants.TCID,ArKeys[i]);
	        	RetnString=RetnString+"\n "+ArKeys[i];
	        	JsonArrDependentTest.put(JsonTestParms);
	        }
		}
		return JsonArrDependentTest;
	}
    
    /**************************************************************************
	 *  Function name 		: Rep_DependentValues
	 *  Reuse Function 		: 
	 *  Description 		: Provide paired key values from  excel input key values    
	 	/**********************************************************************/    
    public List<String> Rep_ExeTags(String extags,List<String> PriTagsList) 
    {
    	 List<String> TagsList = null;
    	if (PriTagsList==null) 
    		TagsList = new ArrayList<String>();
    	else 
    		TagsList=PriTagsList;
		if (extags.length()>0){
	        String[] ArKeys = extags.split(Constants.ValueDelimiter);
	        for(int i =0; i < ArKeys.length ; i++){
	        	TagsList.add(ArKeys[i]);
	        }
		}
    	
		return TagsList;
	}

}