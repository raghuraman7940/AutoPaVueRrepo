package com.pauir.Request.API;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.google.gson.JsonObject;
import com.pauir.Request.API.DriverScript;
import com.pauir.Request.API.App;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.util.CSV_Reader;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;

import webdriver.main.Log;

import io.restassured.path.json.JsonPath;

import webdriver.main.Log;

public class DriverScript {

	//App Object creation;
	public static App API;
	public static RequestMethod requests;
	public static WorkerTestSet wTestSet;
	public static ReportJSON RepJs;
	// properties
	//public static Properties CONFIG;
	public static List<String> DependentList;
	private static JSONObject jsonTestReportData;
	public static DriverScript test =null;
	public static CSV_Reader csvfreader;
	public static String contenttype="";
	public static String orgreferenceid="";
	public static String authorization="";
	
	/**
	 * 
	 * Constructor for initializing the log, properties and Object.
	 * 
	 */
	public DriverScript() throws NoSuchMethodException, SecurityException, IOException {
		// Initialize the app logs
		//Log._logInfo("Start API Automation testing");
		wTestSet=new WorkerTestSet();
		DependentList = new ArrayList<String>();
		jsonTestReportData = new JSONObject();	
		API=new App();
		RepJs=new ReportJSON();
		csvfreader= new CSV_Reader();
		
	}
	
	public static void main(String[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, NoSuchMethodException, SecurityException, ParseException {
	
		//Initialize objects
		API = new App();
		test = new DriverScript();
		requests=new RequestMethod();				
		
		//Set Header values
		contenttype= "application/json";
		orgreferenceid="d3d6bc4e-2bb1-41b2-865b-52c0a6c23e75";
		authorization="Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkpSY080bnhzNWpnYzhZZE43STJoTE80Vl9xbDFiZG9pTVhtY1lnSG00SHMifQ.eyJqdGkiOiI3dzRMdl9QOX5-QkttMFpnNWFCX0UiLCJzdWIiOiIxMTcwNTQ0MTgiLCJpc3MiOiJodHRwczovL3BhNW5vbnByZC5vbmVsb2dpbi5jb20vb2lkYy8yIiwiaWF0IjoxNjEyNTE0Njk0LCJleHAiOjE2MTI1MTQ5OTQsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwiLCJhdWQiOiI5NmI2MGNjMC1iMDBjLTAxMzgtZTVkNy0wNjMxMGI1NjhhZDIxNzQxNDAifQ.tC0fcgISfkE8vuMubWyE9mHP6eqra6C66_8am4rmSlyMNNefuAuk6td7aiOUxY0QrTGtthwXGlXVBpe820hnOlCB7hNxukTn6X4VCfuC7dxKq5gt3U85K9KQ-WTMW_NfEbL68LDUpWL5Qy5D4x1xinFsJZP5_WmXg9FvPujL0etQV5KSq4mKYEtM3EFZkWR1k2oEGX13Z4QkV5kDrEifvPa639OJzLNnv4MKEx5Y1fO51FsVYEn9XO1I1yFN2DyxBxKTzWeDtRB4wTRSRAFuDgVpw0Cx-eJq-3XwYJQJUm_A6tNkgsmOQV5v0aDHzL5j2IySpVO7Bm-Dd1DnKxrg0A";
		
		HashMap<String,Object> MapPerfLogs=  new HashMap<String,Object>();
		MapPerfLogs.put("Content-Type", contenttype);
		MapPerfLogs.put("authorization", authorization);
		MapPerfLogs.put("orgreferenceid", orgreferenceid);

//		//Automation Clean Up
//		test.AutomationDataCleanUp(MapPerfLogs);
//		requests.getOAuthTokenWithClientCredential("externaldev");

		Constants.APIServer=FileReaderManager.getInstance().getJsonReader().getApplicationUrl();

		String SelectedCustomer="VA";
		String LoginUser="thulasiram.marani+dev6@pearson.com";

//     For APIUserroleSUITE suite		
//	  	HashMap<String,Object> mapPermissions=requests.GetAccount_Permissions(MapPerfLogs,LoginUser,SelectedCustomer);
//		if (mapPermissions!=null) {
//			//driverscript.startDriverScript();
//			Constants.PERMISSIONS=(List<String>) mapPermissions.get("Permissions");
//		}	
		test.startNewDriverScript("excel","APIRegressionSUITE","System Admin","regression",MapPerfLogs.get("authorization").toString(),MapPerfLogs.get("orgreferenceid").toString(),Constants.PERMISSIONS); //APISmokeSUITE//APIRegressionSUITE//APIUserroleSUITE
	}
		
	/***************************************************************************************
  	 *  Function name 		: startDriverScript
  	 *  Reuse Function 		:  
  	 *  Description 		: Start Execution
  	/****************************************************************************************/ 
	public String startNewDriverScript(String InputType,String SuiteName, String userrole, String Testingtype,String AuthToken,String Orgrefid,List<String> UserPermissions) throws NoSuchMethodException, SecurityException, IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	
		// Initialize and execute
		JSONObject jsonRep=null;
		String GenReportname=null;
		String GenJsOutputReportfile=null;
		String GenJsOutputfile=null;
		String Testdatafile="";
		JSONObject JsonTestData =null;
		String Executiontime;
		Map<String,Object> ApiHeaders = new HashMap<String,Object>();
		String contenttype= "application/json";
		try {
			Log._logInfo("Start Driver Script with API Test suite : "+SuiteName);
			jsonTestReportData = new JSONObject();
		    //Reponse Folder
		    File ResponseDir= new File(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Response");
		    if (!ResponseDir.exists()) 
		    	ResponseDir.mkdirs();
		    
		    //Suite Setup
		    Constants.TEST_SHEET=SuiteName;
		    String userrole1=userrole.replace(" ", "");
	    	userrole=userrole1.replace("-", "_");
		    Constants.BuildReleaseVersion="525";
		    if (SuiteName.equalsIgnoreCase("APIUserroleSUITE")) {
		    	Testdatafile=Constants.TEST_JSFILE_UserRole;
		    }
		    else if (SuiteName.equalsIgnoreCase("APIRegressionSUITE")) {
		    	Testdatafile=Constants.TEST_JSFILE_Regression;
		    }
		    else{
		    	Testdatafile=Constants.TEST_JSFILE_Smoke;
		    }
		    
		    if (InputType.equalsIgnoreCase("excel")) {
		    	JSONObject JsonGLBHeader = new JSONObject();
			    JsonGLBHeader.put("content-type", contenttype);
				JsonGLBHeader.put("orgreferenceid", Orgrefid);
				JsonGLBHeader.put("authorization", AuthToken);
				ApiHeaders=CommonFunctions.toMap(JsonGLBHeader);
		    	//Export test from Excel
		        String XlsxInputFile = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() +Constants.TEST_XLFILE;	
				JsonTestData =RepJs.GenerateTestDataFromExcelData(XlsxInputFile,Constants.TEST_SHEET,JsonGLBHeader);
				//Export Input json to Response folder
				API.StoreRespose("TestdataInputData","json",JsonTestData.toString());
		    }
		    else {
		    	ApiHeaders.put("content-type", contenttype);
		    	ApiHeaders.put("orgreferenceid",Orgrefid);
		    	ApiHeaders.put("authorization",AuthToken);
				
		    	// Export Suite Tests from JSON File
			    String TestFilePath = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath()+Testdatafile;
				File file = new File(TestFilePath); 			
				String jsoncontent = FileUtils.readFileToString(file, "utf-8");
				JsonTestData = new JSONObject(jsoncontent);
		    }
			
		      	
			if (JsonTestData!=null) {
				//Get Start time taken
				long startTime = System.currentTimeMillis();
				// Main driver function, read from JSON/excel and execute
				JSONObject jsRepData=ReadJSON_Data(JsonTestData,ApiHeaders,UserPermissions);
			
				//Calculate execution time taken
				long endTime   = System.currentTimeMillis();

		    	long totalTime = endTime - startTime;
				System.out.println("Start:End:totalTime  ->"+startTime+":"+endTime+":"+totalTime);
		    	if (totalTime<120000) {
		    		Executiontime=Long.toString(TimeUnit.MILLISECONDS.toSeconds(totalTime))+" Secs";
		    		Constants.ExecutionDuration=Long.toString(TimeUnit.MILLISECONDS.toSeconds(totalTime));
		    		Constants.TimeType=" Secs";
		    	}
		    	else {
		    		Executiontime=Long.toString(TimeUnit.MILLISECONDS.toMinutes(totalTime))+" Mins";
		    		Constants.ExecutionDuration=Long.toString(TimeUnit.MILLISECONDS.toMinutes(totalTime));
		    		Constants.TimeType=" Mins";
		    	}
		    	
				//Generate report
		    	GenJsOutputfile=API.StoreRespose("TestdataOutputData_"+userrole,"json",jsRepData.toString());
		    	Constants.mapUserroleJsonOutputfiles.put(userrole, GenJsOutputfile);
		    	jsonRep= RepJs.NewBuildJSONReport(jsRepData,userrole,Testingtype);
		    	GenJsOutputReportfile=API.StoreRespose("TestdataReport_"+userrole,"json",jsonRep.toString());
		    	Constants.mapUserroleJsonReportfiles.put(userrole, GenJsOutputReportfile);
		    	GenReportname=RepJs.GeneratehtmlReport(jsonRep,userrole);
		    	Constants.mapUserrolehtmlReportfiles.put(userrole, GenReportname);
			}
		} 
		 catch (FileNotFoundException e) 
        {
			 System.out.println("FileNotFoundException: "+e.getMessage());
        	e.printStackTrace();
        } 
		catch (IOException e) 
        {
			System.out.println("IOException: "+e.getMessage());
        	e.printStackTrace();
        }  
		catch (Exception e) 
        {
			System.out.println("Exception: "+e.getMessage());
        	e.printStackTrace();
        }
		return GenReportname;
	}
	
	
	
	/***************************************************************************************
  	 *  Function name 		: startDriverScript
  	 *  Reuse Function 		:  
  	 *  Description 		: Start Execution
  	/****************************************************************************************/ 
	public String startDriverScript(String InputType,String SuiteName) throws NoSuchMethodException, SecurityException, IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	
		// Initialize and execute
		JSONObject jsonRep=null;
		String GenReportname=null;
		String userrole="";
		String Testdatafile="";
		JSONObject JsonTestData =null;
		List<String> UserPermissions=null;
		
		Map<String,Object> ApiHeaders = new HashMap<String,Object>();
		try {
			Log._logInfo("Start Driver Script with API Test suite : "+SuiteName);
			jsonTestReportData = new JSONObject();
		    //Reponse Folder
		    File ResponseDir= new File(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Response");
		    if (!ResponseDir.exists()) 
		    	ResponseDir.mkdirs();
		    
		    //Suite Setup
		    Constants.TEST_SHEET=SuiteName;
		    Constants.BuildReleaseVersion="525";
		    if (SuiteName.equalsIgnoreCase("APIUserroleSUITE")) {
		    	Testdatafile=Constants.TEST_JSFILE_UserRole;
		    	String userrole1=Constants.LOGGEDINUSERROLE.replace(" ", "");
		    	userrole=userrole1.replace("-", "_");
		    	userrole="_"+userrole;
		    	Constants.TestingType=Constants.TEST_UserRoleType;
		    }
		    else if (SuiteName.equalsIgnoreCase("APIRegressionSUITE")) {
		    	Testdatafile=Constants.TEST_JSFILE_Regression;
		    	Constants.TestingType=Constants.TEST_RegressionType;
		    }
		    else
		    {
		    	Testdatafile=Constants.TEST_JSFILE_Smoke;
		    	Constants.TestingType=Constants.TEST_SmokeType;
		    }
		    if (InputType.equalsIgnoreCase("excel")) {
		    	JSONObject JsonGLBHeader = new JSONObject();
			    JsonGLBHeader.put("content-type", contenttype);
				JsonGLBHeader.put("orgreferenceid", orgreferenceid);
				JsonGLBHeader.put("authorization", authorization);
				ApiHeaders=CommonFunctions.toMap(JsonGLBHeader);
		    	//Export test from Excel
		        String XlsxInputFile = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() +Constants.TEST_XLFILE;	
				JsonTestData =RepJs.GenerateTestDataFromExcelData(XlsxInputFile,Constants.TEST_SHEET,JsonGLBHeader);
				//Export Input json to Response folder
				API.StoreRespose("TestdataInputData","json",JsonTestData.toString());
		    }
		    else {
		    	// Export Suite Tests from JSON File
			    String TestFilePath = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath()+Testdatafile;
				File file = new File(TestFilePath); 			
				String jsoncontent = FileUtils.readFileToString(file, "utf-8");
				JsonTestData = new JSONObject(jsoncontent);
		    }
			
		      	
			if (JsonTestData!=null) {
				//Get Start time taken
				long startTime = System.currentTimeMillis();
				// Main driver function, read from JSON/excel and execute
				JSONObject jsRepData=ReadJSON_Data(JsonTestData,ApiHeaders,UserPermissions);
			
				//Calculate execution time taken
				long endTime   = System.currentTimeMillis();
		    	long totalTime = endTime - startTime;
		    	if (totalTime<350) {
		    		Constants.ExecutionDuration=Long.toString(TimeUnit.MILLISECONDS.toSeconds(totalTime));
		    		Constants.TimeType=" Secs";
		    	}
		    	else {
		    		Constants.ExecutionDuration=Long.toString(TimeUnit.MILLISECONDS.toMinutes(totalTime));
		    		Constants.TimeType=" Mins";
		    	}
		    	
				//Generate report
		    	API.StoreRespose("TestdataOutputData","json",jsRepData.toString());
		    	jsonRep= RepJs.BuildJSONReport(jsRepData);
		    	API.StoreRespose("TestdataReport","json",jsonRep.toString());
		    	GenReportname=RepJs.GeneratehtmlReport(jsonRep,userrole);
		    	
			}
	    	
		} 
		 catch (FileNotFoundException e) 
        {
			 System.out.println("FileNotFoundException: "+e.getMessage());
        	e.printStackTrace();
        } 
		catch (IOException e) 
        {
			System.out.println("IOException: "+e.getMessage());
        	e.printStackTrace();
        }  
		catch (Exception e) 
        {
			System.out.println("Exception: "+e.getMessage());
        	e.printStackTrace();
        }
		return GenReportname;
	}
	
	/*************************************************************************************************
	 *  Function name 		: ReadJSON_Data
	 *  Reuse Function 		: 
	 *  Description 		: Read the all the Excel values.Based on the inputs flow the functionality. 
	/
	 * @throws ProcessingException 
	 * @throws JiraException **************************************************************************************************/  
    public JSONObject ReadJSON_Data(JSONObject JsonTestData, Map<String,Object> ApiHeaders,List<String> UserPermissions)throws AbstractMethodError,  IOException
    {
        String TestCaseID,TestRunMode;
		JSONObject jsTestData = JsonTestData;
		String ExecuteType="Sequential";//Parallel//Sequential
		boolean bConExecution=false;
		long startTime =0;
		long endTime =0;
		long totalTime=0;
		String Authtokenid=ApiHeaders.get("authorization").toString();
		String Executiontime=null;
        ExecutorService executor = null;
		int iThread=Integer.parseInt("1");
		executor = Executors.newFixedThreadPool(iThread);
		List<String> DependentList = new ArrayList<String>();;
		JSONObject jsonTestReportData = new JSONObject();
		startTime = System.currentTimeMillis();
		jsonTestReportData.put(Constants.JSReportTitle, "API Automation Test Report");
		Date d = new Date();
		jsonTestReportData.put(Constants.JSRunDate, d.toString());
		JSONObject GLBHeader = jsTestData.getJSONObject(Constants.GlobalHeader);
		//Check wheather dependent or non dependent
		boolean bDependent=VerifyDependents(jsTestData,"Tests.Dependent.operationId","Tests.operationId");
		//Tests
        JSONArray TestSets = (JSONArray) jsTestData.get("Tests");
        for (int iTestIter = 0; iTestIter < TestSets.length(); iTestIter++) {
        	ApiHeaders.put("authorization", Authtokenid);
        	//System.out.println("DependentList : "+DependentList);
        	JSONObject Testset = TestSets.getJSONObject(iTestIter);
            TestRunMode = Testset.get(Constants.TESTRUNMODE).toString();
            TestCaseID = Testset.get(Constants.TCID).toString();
            if ((TestRunMode.equalsIgnoreCase("YES"))&&(!DependentList.contains(TestCaseID))){
            	
                //Execute Dependents Issues
                JSONArray DependentTests = (JSONArray) Testset.get("Dependent");
               // System.out.println("DependentTests Length: "+DependentTests.length());	
                if(DependentTests.length()>0){
	                for (int iDepenIter = 0; iDepenIter < DependentTests.length(); iDepenIter++) {
	                	JSONObject DependentTest = DependentTests.getJSONObject(iDepenIter);
	                	System.out.println("DependentTest : "+DependentTest.toString());	
	                	String FilterQuery="Tests.findAll{Tests->Tests.operationId==datefilter}";
	                	String FilterValue=DependentTest.get("operationId").toString();
	                	if (!DependentList.contains(FilterValue)){
	                		DependentList=DependentIssueExecution(jsTestData, FilterQuery,FilterValue,ApiHeaders,DependentList,UserPermissions);
	                	}
	                }
	                Log._logInfo("Execute Testset :"+TestCaseID);
	                //Sequential Execution
	                jsonTestReportData=wTestSet.TestExecution(jsonTestReportData,Testset,ApiHeaders,UserPermissions);
                	DependentList.add(TestCaseID);
					//System.out.println("Seq: "+jsonTestReportData);	
                }
                else{
                	if ((ExecuteType.contains("Parallel"))&(!bDependent)) {
                		// Execute Concurrent in Thread
                		bConExecution=true;
                		DependentList.add(TestCaseID);
						Runnable worker = new WorkerTestSet(Testset,"Testset");
						executor.execute(worker);// calling execute
						//System.out.println("Concurrent Report: "+jsonTestReportData);
                	}
                	else{
                		Log._logInfo("Execute Testset : "+TestCaseID);
                		System.out.println("DS ApiHeaders: "+ApiHeaders);
                		jsonTestReportData=wTestSet.TestExecution(jsonTestReportData,Testset,ApiHeaders,UserPermissions);
                		DependentList.add(TestCaseID);
                		//System.out.println("Sequential Report: "+jsonTestReportData);
					}
                }
            }
         }
        if ((ExecuteType.contains("Parallel"))&(bConExecution)) {
 			executor.shutdown();
 			// Wait Till all thread complete
 			while (!executor.isTerminated()) {
 			}
 			System.out.println(" DataSet Finished all threads");
	 	}
        endTime   = System.currentTimeMillis();
    	totalTime = endTime - startTime;
    	if (totalTime<120000) 
    		Executiontime=Long.toString(TimeUnit.MILLISECONDS.toSeconds(totalTime))+" Secs";
    	else 
    		Executiontime=Long.toString(TimeUnit.MILLISECONDS.toMinutes(totalTime))+" Mins";
    	
    	jsonTestReportData.put(Constants.JSExecutionDuration, Executiontime);
        //System.out.println(JsonTestData);
        return jsonTestReportData;
    }
    
    
	/*************************************************************************************************
	 *  Function name 		: DependentIssueExecution
	 *  Reuse Function 		: 
	 *  Description 		: Read the dependent issues and execute first. 
	/
	 * @throws ProcessingException 
	 * @throws JiraException **************************************************************************************************/ 
    public List<String> DependentIssueExecution(JSONObject JsonTestData, String FilterQuery,String FilterValue,Map<String,Object> ApiHeaders,List<String> DependentList,List<String> UserPermissions) throws IOException
    {
    	String TestCaseID = null;
        JSONArray Testsets = null;
        try{
         	if (!DependentList.contains(FilterValue)){
		        JsonPath jsonResponse = new JsonPath(JsonTestData.toString());
				List<JSONObject> jsText = jsonResponse.param("datefilter", FilterValue).get(FilterQuery);
				Testsets = new JSONArray(jsText);
				for (int iTestIter = 0;iTestIter < Testsets.length(); iTestIter++) {
					JSONObject Testset = Testsets.getJSONObject(iTestIter);
					 TestCaseID = Testset.get(Constants.TCID).toString();
		        	if (!DependentList.contains(TestCaseID)){
		        		JSONArray DependentTests = (JSONArray)Testset.get("Dependent");
		        		for (int iDepenIter = 0; iDepenIter < DependentTests.length(); iDepenIter++) {
		        			JSONObject DependentTest = DependentTests.getJSONObject(iDepenIter);
		        			String Query="Tests.findAll{Tests->Tests.operationId==datefilter}";
		        			String QueryValue=DependentTest.get("operationId").toString();
		        			if (!DependentList.contains(QueryValue)){
		        				DependentIssueExecution(JsonTestData, Query,QueryValue,ApiHeaders,DependentList,UserPermissions);
		        			}
		        		}
		        		Log._logInfo("Execute Dependent Test "+TestCaseID);
		        		//System.out.println("Exec Dependent : "+TestCaseID+" --- "+DependentList);	
		        		jsonTestReportData=wTestSet.TestExecution(jsonTestReportData,Testset,ApiHeaders,UserPermissions);
			        	DependentList.add(TestCaseID);
	        		}
				}
         	}
        }
        catch(Exception e){
        	e.printStackTrace();
        }
        return DependentList;
    }

    /*************************************************************************************************
	 *  Function name 		: VerifyDependents
	 *  Reuse Function 		: 
	 *  Description 		: Verify whether Dependents issues in test data
	/**************************************************************************************************/ 
	public static boolean VerifyDependents(JSONObject JsonTestData,String Key, String Key2)
    {   	
		Log._logInfo("Dependents checking ");
    	boolean retnValue=false;
	    try {
	    	JsonPath jsonResponse = new JsonPath(JsonTestData.toString());
	    	List<List<String>> jsText = jsonResponse.get(Key);
			 for (List<String> map :jsText) {
				 for(String Issuekey:map){
					 if(Issuekey.length()>0) {
						 retnValue=true;
//						 ReString=jsonResponse.getString(Key2);
//						 if(ReString.contains(Issuekey))
//						 {
//							 //System.out.println("Contains: "+s);
//						 }
					 }
				 }
			 }
	      } 
	      catch (Exception e){
	    	e.printStackTrace();
	      }        	      
     	  return retnValue;
      } 
	
	 /*************************************************************************************************
		 *  Function name 		: AutomationDataCleanUp
		 *  Reuse Function 		: 
		 *  Description 		: Automation Data Clean Up
		/**************************************************************************************************/ 
		public static void AutomationDataCleanUp(HashMap<String,Object> MapPerfLogs)
	    { 
			
			String orgrefid=null;
			String custrefid=null;
			
			
			
//			//Get Custom Labels
//			custrefid=CommonFunctions.getTestData("customerrefid");
//			Constants.mapCustomLabels=requests.GetEnv_CustomLabels(MapPerfLogs,"PearE2E2019");
//			System.out.println("Custom Labels Count  : "+Constants.mapCustomLabels.size());
//			System.out.println("Custom Labels  : "+Constants.mapCustomLabels);
//			
			
			//Get Demographics
//			String orgrefid=CommonFunctions.getTestData("schoolrefid");
//			String custrefid=CommonFunctions.getTestData("customerrefid");
//			List <Map<String,Object>> LstCustDemo=requests.Getcustomerdemographics(MapPerfLogs,custrefid,orgrefid);
//			System.out.println("customerdemographics  : "+LstCustDemo);

			//Delete Students
			orgrefid=CommonFunctions.getTestData("schoolrefid");
			HashMap<String,Object> mapStudsref=requests.GetAndDeleteStudents(MapPerfLogs,orgrefid,10,"Sample");
			System.out.println("Deleted Student Count  : "+mapStudsref.size());
			System.out.println("Deleted Student  : "+mapStudsref);
					
			//Delete Test admins
			orgrefid=CommonFunctions.getTestData("masteradminrefid");
			HashMap<String,Object> mapTstAdminref=requests.GetAndDeleteTestAdmins(MapPerfLogs,orgrefid,10,"TSTADMIN");
			System.out.println("Deleted TestAdmin Count  : "+mapTstAdminref.size());
			System.out.println("Deleted TestAdmin  : "+mapTstAdminref);
			
			//Delete Tests
			orgrefid=CommonFunctions.getTestData("masteradminrefid");
			HashMap<String,Object> mapTstsref=requests.GetAndDeleteTests(MapPerfLogs,orgrefid,10,"TSTADMIN");
			System.out.println("Deleted Tests Count  : "+mapTstsref.size());
			System.out.println("Deleted Tests  : "+mapTstsref);
			
			//Delete Formcode
			orgrefid=CommonFunctions.getTestData("masteradminrefid");
			HashMap<String,Object> mapformcoderef=requests.GetAndDeleteFormcode(MapPerfLogs,orgrefid,10,"TSTADMIN");
			System.out.println("Deleted Formcode Count  : "+mapformcoderef.size());
			System.out.println("Deleted Formcode  : "+mapformcoderef);
			
			//Delete Accommodations
			orgrefid=CommonFunctions.getTestData("masteradminrefid");
			HashMap<String,Object> mapAccommref=requests.GetAndDeleteAccommodations(MapPerfLogs,orgrefid,10,"TSTADMIN");
			System.out.println("Deleted Accomm Count  : "+mapAccommref.size());
			System.out.println("Deleted Accomm  : "+mapAccommref);
			
			//Delete Irregularity
			orgrefid=CommonFunctions.getTestData("masteradminrefid");
			HashMap<String,Object> mapIrr=requests.GetAndDeleteIrregularity(MapPerfLogs,orgrefid,10,"TestIrrAuto");
			System.out.println("Deleted Irregularity Count  : "+mapIrr.size());
			System.out.println("Deleted Irregularity  : "+mapIrr);
			
			//Delete IrregularityCategory
			orgrefid=CommonFunctions.getTestData("masteradminrefid");
			HashMap<String,Object> mapAccommref1=requests.GetAndDeleteIrregularitycategory(MapPerfLogs,orgrefid,10,"IrregAutoTest");
			System.out.println("Deleted Irregularitycategory Count  : "+mapAccommref1.size());
			System.out.println("Deleted Irregularitycategory  : "+mapAccommref1);
			
			//Delete TestNavConfig
			orgrefid=CommonFunctions.getTestData("masteradminrefid");
			HashMap<String,Object> mapAccommref2=requests.GetAndDeleteTestNavConfig(MapPerfLogs,orgrefid,10,"TestNavInt	");
			System.out.println("Deleted TestNavConfig Count  : "+mapAccommref2.size());
			System.out.println("Deleted TestNavConfig  : "+mapAccommref2);
			
			//Delete Permissions
			orgrefid=CommonFunctions.getTestData("masteradminrefid");
			HashMap<String,Object> mapAccommref3=requests.GetAndDeletePermissions(MapPerfLogs,orgrefid,10,"PERSTUAUTO");
			System.out.println("Deleted Permissions Count  : "+mapAccommref3.size());
			System.out.println("Deleted Permissions  : "+mapAccommref3);
					
			
			
			
			//Delete Sessions
			orgrefid=CommonFunctions.getTestData("schoolrefid");
			HashMap<String,Object> mapSesssref=requests.GetAndDeleteSessions(MapPerfLogs,orgrefid,100,"AutoSess");
			System.out.println("Deleted Session Count  : "+mapSesssref.size());
			System.out.println("Deleted Session  : "+mapSesssref);
			
			//Delete Class
			orgrefid=CommonFunctions.getTestData("schoolrefid");
			HashMap<String,Object> mapClassref=requests.GetAndDeleteOrgclass(MapPerfLogs,orgrefid,100,"AutoClass");
			System.out.println("Deleted Class Count  : "+mapClassref.size());
			System.out.println("Deleted Classes  : "+mapClassref);
			
			//Delete Organization- SCH
			orgrefid=CommonFunctions.getTestData("staterefid");
			HashMap<String,Object> mapOrgref=requests.GetAndDeleteOrg(MapPerfLogs,orgrefid,5,"SCH","OrgAuto");
			System.out.println("Deleted Sch Org Count  : "+mapOrgref.size());
			System.out.println("Deleted Sch  : "+mapOrgref);
			
			//Delete Organization- DIST
			mapOrgref=requests.GetAndDeleteOrg(MapPerfLogs,orgrefid,5,"DIST","OrgAuto");
			System.out.println("Deleted Dist Org Count  : "+mapOrgref.size());
			System.out.println("Deleted Dist  : "+mapOrgref);
			
			
	    }
	
	
	 
}