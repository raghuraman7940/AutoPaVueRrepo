package com.pauir.common.testDataTypes;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Testdata_Customers_APIDATA {

@SerializedName("customerrefid")
@Expose
private String customerrefid;
@SerializedName("staterefid")
@Expose
private String staterefid;
@SerializedName("learefid")
@Expose
private String learefid;
@SerializedName("districtrefid")
@Expose
private String districtrefid;
@SerializedName("schoolrefid")
@Expose
private String schoolrefid;
@SerializedName("adminrefid")
@Expose
private String adminrefid;
@SerializedName("testrefid")
@Expose
private String testrefid;

@SerializedName("producttyperefid")
@Expose
private String producttyperefid;

@SerializedName("studentrefid")
@Expose
private String studentrefid;
@SerializedName("classrefid")
@Expose
private String classrefid;
@SerializedName("sessionrefid")
@Expose
private String sessionrefid;
@SerializedName("userrefid")
@Expose
private String userrefid;
@SerializedName("dataimportsrefid")
@Expose
private String dataimportsrefid;
@SerializedName("teacherstudentrefid")
@Expose
private String teacherstudentrefid;
@SerializedName("teacherclassrefid")
@Expose
private String teacherclassrefid;
@SerializedName("teachersessionrefid")
@Expose
private String teachersessionrefid;
@SerializedName("teacheruserrefid")
@Expose
private String teacheruserrefid;
@SerializedName("lowstakesadminrefid")
@Expose
private String lowstakesadminrefid;
@SerializedName("lowstakessessionrefid")
@Expose
private String lowstakessessionrefid;
@SerializedName("highstakesadminrefid")
@Expose
private String highstakesadminrefid;
@SerializedName("highstakessessionrefid")
@Expose
private String highstakessessionrefid;
@SerializedName("masteradminrefid")
@Expose
private String masteradminrefid;
@SerializedName("lowstakesproducttyperefid")
@Expose
private String lowstakesproducttyperefid;
@SerializedName("highstakesproducttyperefid")
@Expose
private String highstakesproducttyperefid;
@SerializedName("productName")
@Expose
private String productName;
@SerializedName("testName")
@Expose
private String testName;

@SerializedName("providerconfigrefid")
@Expose
private String providerconfigrefid;

@SerializedName("gradeReferenceId")
@Expose
private String gradeReferenceId;

@SerializedName("subjectReferenceId")
@Expose
private String subjectReferenceId;

@SerializedName("productTypeProviderReferenceId")
@Expose
private String productTypeProviderReferenceId;


@SerializedName("courseReferenceId")
@Expose
private String courseReferenceId;


public String getcustomerRefID() {
return customerrefid;
}

public void setcustomerRefID(String customerrefid) {
this.customerrefid = customerrefid;
}

public String getStateRefID() {
return staterefid;
}

public void setStateRefID(String staterefid) {
this.staterefid = staterefid;
}

public String geLEARefID() {
return learefid;
}

public void setLEARefID(String learefid) {
this.learefid = learefid;
}

public String getDistrictRefID() {
return districtrefid;
}

public void setDistrictRefID(String districtrefid) {
this.districtrefid = districtrefid;
}

public String getSchoolRefID() {
return schoolrefid;
}

public void setSchoolRefID(String schoolrefid) {
this.schoolrefid = schoolrefid;
}

public String getadminRefId() {
return adminrefid;
}

public void setadminRefId(String adminrefid) {
this.adminrefid = adminrefid;
}

public String gettestrefid() {
return testrefid;
}

public void settestRefId(String testrefid) {
this.testrefid =testrefid;
}

public String getproducttyperefid() {
return producttyperefid;
}

public void setproducttypeRefId(String producttyperefid) {
this.producttyperefid =producttyperefid;
}
public String getstudentRefId() {
return studentrefid;
}

public void setstudentRefId(String studentrefid) {
this.studentrefid = studentrefid;
}

public String getclassRefId() {
return classrefid;
}

public void setclassRefId(String classrefid) {
this.classrefid = classrefid;
}

public String getsessionRefId() {
return sessionrefid;
}

public void setsessionRefId(String sessionrefid) {
this.sessionrefid = sessionrefid;
}

public String getuserRefId() {
return userrefid;
}

public void setuserRefId(String userrefid) {
this.userrefid = userrefid;
}

public String getdataimportsRefId() {
return dataimportsrefid;
}

public void setdataimportsRefId(String dataimportsrefid) {
this.dataimportsrefid = dataimportsrefid;
}

public String getteacherstudentrefid() {
return teacherstudentrefid;
}

public void setteacherstudentrefid(String teacherstudentrefid) {
this.teacherstudentrefid = teacherstudentrefid;
}

public String getteacherclassrefid() {
return teacherclassrefid;
}

public void setteacherclassrefid(String teacherclassrefid) {
this.teacherclassrefid = teacherclassrefid;
}

public String getteachersessionrefid() {
return teachersessionrefid;
}

public void setteachersessionrefid(String teachersessionrefid) {
this.teachersessionrefid = teachersessionrefid;
}

public String getteacheruserrefid() {
return teacheruserrefid;
}

public void setteacheruserrefid(String teacheruserrefid) {
this.teacheruserrefid = teacheruserrefid;
}

public String getlowstakesadminrefid() {
return lowstakesadminrefid;
}

public void setlowstakesadminrefid(String lowstakesadminrefid) {
this.lowstakesadminrefid = lowstakesadminrefid;
}

public String getlowstakessessionrefid() {
return lowstakessessionrefid;
}

public void setlowstakessessionrefid(String lowstakessessionrefid) {
this.lowstakessessionrefid = lowstakessessionrefid;
}

public String gethighstakesadminrefid() {
return highstakesadminrefid;
}

public void sethighstakesadminrefid(String highstakesadminrefid) {
this.highstakesadminrefid = highstakesadminrefid;
}

public String gethighstakessessionrefid() {
return highstakessessionrefid;
}

public void sethighstakessessionrefid(String highstakessessionrefid) {
this.highstakessessionrefid = highstakessessionrefid;
}

public String getmasteradminrefid() {
return masteradminrefid;
}

public void setmasteradminrefid(String masteradminrefid) {
this.masteradminrefid = masteradminrefid;
}
public String getlowstakesproducttyperefid() {
return lowstakesproducttyperefid;
}

public void setlowstakesproducttyperefid(String lowstakesproducttyperefid) {
this.lowstakesproducttyperefid = lowstakesproducttyperefid;
}
public String gethighstakesproducttyperefid() {
return highstakesproducttyperefid;
}

public void sethighstakesproducttyperefid(String highstakesproducttyperefid) {
this.highstakesproducttyperefid = highstakesproducttyperefid;
}

public String getTestName() {
return testName;
}
public void setTestName(String testName) {
this.testName = testName;
}

public String getproviderconfigrefid() {
return providerconfigrefid;
}

public void setproviderconfigrefid(String providerconfigrefid) {
this.providerconfigrefid = providerconfigrefid;
}

public String getgradeReferenceId() {
return gradeReferenceId;
}

public void setgradeReferenceId(String gradeReferenceId) {
this.gradeReferenceId = gradeReferenceId;
}

public String getsubjectReferenceId() {
return subjectReferenceId;
}

public void setsubjectReferenceId(String subjectReferenceId) {
this.subjectReferenceId = subjectReferenceId;
}

public String getproductTypeProviderReferenceId() {
return productTypeProviderReferenceId;
}

public void setproductTypeProviderReferenceId(String productTypeProviderReferenceId) {
this.productTypeProviderReferenceId = productTypeProviderReferenceId;
}


public String getcourseReferenceId() {
	return courseReferenceId;
}

}