
package com.pauir.common.testDataTypes;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Testdata_Customers_Searchtext {

@SerializedName("state")
@Expose
private String state;
@SerializedName("lea")
@Expose
private String lea;
@SerializedName("distict")
@Expose
private String distict;
@SerializedName("school")
@Expose
private String school;
@SerializedName("admin")
@Expose
private String admin;
@SerializedName("test")
@Expose
private String test;
@SerializedName("student")
@Expose
private String student;
@SerializedName("class")
@Expose
private String _class;
@SerializedName("session")
@Expose
private String session;
@SerializedName("papersession")
@Expose
private String papersession;
@SerializedName("user")
@Expose
private String user;
@SerializedName("dataimports")
@Expose
private String dataimports;
@SerializedName("producttype")
@Expose
private String producttype;
@SerializedName("course")
@Expose
private String course;
@SerializedName("grade")
@Expose
private String grade;
public String getState() {
return state;
}

public void setState(String state) {
this.state = state;
}

public String getLea() {
return lea;
}

public void setLea(String lea) {
this.lea = lea;
}

public String getDistict() {
return distict;
}

public void setDistict(String distict) {
this.distict = distict;
}

public String getSchool() {
return school;
}

public void setSchool(String school) {
this.school = school;
}

public String getAdmin() {
return admin;
}

public void setAdmin(String admin) {
this.admin = admin;
}

public String getTest() {
return test;
}

public void setTest(String test) {
this.test = test;
}

public String getStudent() {
return student;
}

public void setStudent(String student) {
this.student = student;
}

public String getClass_() {
return _class;
}

public void setClass_(String _class) {
this._class = _class;
}

public String getSession() {
return session;
}

public void setSession(String session) {
this.session = session;
}

public String getPaperSession() {
return papersession;
}

public void setPaperSession(String papersession) {
this.papersession = papersession;
}

public String getUser() {
return user;
}

public void setUser(String user) {
this.user = user;
}

public String getDataImports() {
return dataimports;
}

public void setDataImports(String dataimports) {
this.dataimports = dataimports;
}
public String getproducttype() {
return producttype;
}

public void setproducttype(String producttype) {
this.producttype = producttype;
}
public String getcourses() {
return course;
}

public void setcourse(String course) {
this.course = course;
}

public String getGrade() {
return grade;
} 

}