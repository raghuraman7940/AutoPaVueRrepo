package com.pauir.common.testDataTypes;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Studentfield {

@SerializedName("fieldname")
@Expose
private String fieldname;
@SerializedName("fieldtype")
@Expose
private String fieldtype;
@SerializedName("objectlocator")
@Expose
private String objectlocator;
@SerializedName("labletodisplay")
@Expose
private String labletodisplay;
@SerializedName("fieldvalue")
@Expose
private String fieldvalue;
@SerializedName("name")
@Expose
private String name;
@SerializedName("description")
@Expose
private String description;
@SerializedName("overrideLabel")
@Expose
private String overrideLabel;
@SerializedName("required")
@Expose
private String required;
@SerializedName("minLength")
@Expose
private String minLength;
@SerializedName("maxLength")
@Expose
private String maxLength;
@SerializedName("regex")
@Expose
private String regex;
@SerializedName("viewFieldOptions")
@Expose
private List<ViewFieldOption> viewFieldOptions = null;
@SerializedName("type")
@Expose
private String type;
@SerializedName("fielderrormsg")
@Expose
private String fielderrormsg;

public String getFieldname() {
return fieldname;
}

public void setFieldname(String fieldname) {
this.fieldname = fieldname;
}

public String getFieldtype() {
return fieldtype;
}

public void setFieldtype(String fieldtype) {
this.fieldtype = fieldtype;
}

public String getObjectlocator() {
return objectlocator;
}

public void setObjectlocator(String objectlocator) {
this.objectlocator = objectlocator;
}

public String getLabletodisplay() {
return labletodisplay;
}

public void setLabletodisplay(String labletodisplay) {
this.labletodisplay = labletodisplay;
}

public String getFieldvalue() {
return fieldvalue;
}

public void setFieldvalue(String fieldvalue) {
this.fieldvalue = fieldvalue;
}

public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}

public String getDescription() {
return description;
}

public void setDescription(String description) {
this.description = description;
}

public String getOverrideLabel() {
return overrideLabel;
}

public void setOverrideLabel(String overrideLabel) {
this.overrideLabel = overrideLabel;
}

public String getRequired() {
return required;
}

public void setRequired(String required) {
this.required = required;
}

public String getMinLength() {
return minLength;
}

public void setMinLength(String minLength) {
this.minLength = minLength;
}

public String getMaxLength() {
return maxLength;
}

public void setMaxLength(String maxLength) {
this.maxLength = maxLength;
}

public String getRegex() {
return regex;
}

public void setRegex(String regex) {
this.regex = regex;
}

public List<ViewFieldOption> getViewFieldOptions() {
return viewFieldOptions;
}

public void setViewFieldOptions(List<ViewFieldOption> viewFieldOptions) {
this.viewFieldOptions = viewFieldOptions;
}

public String getType() {
return type;
}

public void setType(String type) {
this.type = type;
}

public String getFielderrormsg() {
return fielderrormsg;
}

public void setFielderrormsg(String fielderrormsg) {
this.fielderrormsg = fielderrormsg;
}

}


