
package com.pauir.common.testDataTypes;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Configuration {

@SerializedName("Name")
@Expose
private String name;
@SerializedName("Program")
@Expose
private String program;
@SerializedName("Year")
@Expose
private String year;
@SerializedName("Admin")
@Expose
private String admin;
@SerializedName("State")
@Expose
private String state;
@SerializedName("School")
@Expose
private String school;
@SerializedName("Distict")
@Expose
private String distict;
@SerializedName("studentfields")
@Expose
private List<Studentfield> studentfields = null;
@SerializedName("userfields")
@Expose
private List<Userfield> userfields = null;
@SerializedName("organizationsfields")
@Expose
private List<Organizationsfield> organizationsfields = null;

@SerializedName("sessionfields")
@Expose
private List<Sessionfield> sessionfields = null;

@SerializedName("classfields")
@Expose
private List<Classfield> classfields = null;

@SerializedName("orgcontactfields")
@Expose
private List<OrgContactfield> orgcontactfields = null;

@SerializedName("coursefields")
@Expose
private List<Coursefield> coursefields = null;

@SerializedName("orderfields")
@Expose
private List<Ordersfield> ordersfields = null;


public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}

public String getProgram() {
return program;
}

public void setProgram(String program) {
this.program = program;
}

public String getYear() {
return year;
}

public void setYear(String year) {
this.year = year;
}

public String getAdmin() {
return admin;
}

public void setAdmin(String admin) {
this.admin = admin;
}

public String getState() {
return state;
}

public void setState(String state) {
this.state = state;
}

public String getSchool() {
return school;
}

public void setSchool(String school) {
this.school = school;
}

public String getDistict() {
return distict;
}

public void setDistict(String distict) {
this.distict = distict;
}

public List<Studentfield> getStudentfields() {
return studentfields;
}

public void setStudentfields(List<Studentfield> studentfields) {
this.studentfields = studentfields;
}

public List<Userfield> getUserfields() {
return userfields;
}

public void setUserfields(List<Userfield> userfields) {
this.userfields = userfields;
}

public List<Organizationsfield> getOrganizationsfields() {
return organizationsfields;
}

public void setOrganizationsfields(List<Organizationsfield> organizationsfields) {
this.organizationsfields = organizationsfields;
}

public List<Sessionfield> getSessionfields() {
return sessionfields;
}

public void setSessionfields(List<Sessionfield> sessionfields) {
this.sessionfields = sessionfields;
}

public List<OrgContactfield> getOrgContactfields() {
return orgcontactfields;
}

public void setOrgContactfields(List<OrgContactfield> orgcontactfields) {
this.orgcontactfields = orgcontactfields;
}

public List<Classfield> getClassfields() {
return classfields;
}

public void setClassfields(List<Classfield> classfields) {
this.classfields = classfields;
}

public void setCoursefields(List<Coursefield> coursefields) {
this.coursefields = coursefields;
}

public List<Coursefield> getCoursefields() {
return coursefields;
}

public void setOrdersfields(List<Ordersfield> ordersfields) {
this.ordersfields = ordersfields;
}

public List<Ordersfield> getOrdersfields() {
return ordersfields;
}

}
