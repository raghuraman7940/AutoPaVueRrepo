package com.pauir.common.util;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.pauir.common.core.FileReaderManager;

import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;

public class CSV_Reader {

//    public static void main(String[] args) {
//
//        String csvFile = "C:\\MyDrive\\Raghu\\MyWorkspace\\PearsonWorkspace\\test-cases\\pa-refresh-auto\\downloads\\Districts Registered for ELA in Virginia-1571038583605.csv";
//
//        List<List<String>> lstRecords =getExportedCSVContent(csvFile,2);
//        System.out.println("Downloaded CSV Content : " + lstRecords); 
//
//    }
    
	
  /***************************************************************************************
	 *  Function name 		: getLatestDownloadFile
	 *  Description 		: Get latest downloaded file
	/****************************************************************************************/  
	public File getLatestDownloadFile(String ext) {
		
		String downloadpath=FileReaderManager.getInstance().getConfigReader().getDownloadPath();
		//String downloadpath="\\downloads\\";
	    File theNewestFile = null;
	    File dir = new File(System.getProperty("user.dir")+downloadpath);
	    FileFilter fileFilter = new WildcardFileFilter("*." + ext);
	    File[] files = dir.listFiles(fileFilter);

	    if (files.length > 0) {
	        /** The newest file comes first **/
	        Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
	        theNewestFile = files[0];
//	        System.out.println("files[0] : "+files[0].getName());
//	        System.out.println("files[0] getAbsolutePath : "+files[0].getAbsolutePath());
	    }

	    return theNewestFile;
	}
    
    /***************************************************************************************
	 *  Function name 		: getExportedCSVContent
	 *  Description 		: Get exported file content
	/****************************************************************************************/    
	public List<List<String>> getExportedCSVContent(String csvFile,int rowcnt) 
	{

		List<String> lstCols = null;
		List<List<String>> lstRecords = null;
	    CSVReader reader = null;
	    int  rowcounter=0;
        try {
        	lstRecords=new ArrayList<List<String>>();
            reader = new CSVReader(new FileReader(csvFile));
            String[] line;
            while (((line = reader.readNext()) != null)&&(rowcounter<rowcnt)) {
            	rowcounter=rowcounter+1;
            	lstCols=new ArrayList<String>();
            	//System.out.println("line length= " + line.length);
        		for (int i=0; i<line.length; i++)
        			lstCols.add(line[i].trim());
            	lstRecords.add(lstCols);
            }
            
          //  System.out.println("lstRecords = " + lstRecords); 
            	
            
        } catch (IOException e) {
            e.printStackTrace();
        }
	    	return lstRecords;
	    	
	    }
	
	/***************************************************************************************
	 *  Function name 		: getExportedCSVContent
	 *  Description 		: Get exported file content
	/****************************************************************************************/    
	public List<List<String>> getExportedCSVContent(String csvFile,int rowcnt,List<String> ExcludeColumn) 
	{

		List<String> lstCols = null;
		List<List<String>> lstRecords = null;
		List<Integer> lstExCols = null;
	    CSVReader reader = null;
	    int  rowcounter=0;
        try {
        	lstRecords=new ArrayList<List<String>>();
        	lstExCols = new ArrayList<Integer>();
            reader = new CSVReader(new FileReader(csvFile));
            String[] line;
            boolean isfirstrecord=true;
            while (((line = reader.readNext()) != null)&&(rowcounter<rowcnt)) {
            	rowcounter=rowcounter+1;
            	lstCols=new ArrayList<String>();
            	if (isfirstrecord) {
            		for (int i=0; i<line.length; i++){
            			String datavalue=line[i].trim();
            			if (ExcludeColumn.contains(datavalue)) 
	        				lstExCols.add(i);
	        			else
	        				lstCols.add(datavalue);
            		}
	            	isfirstrecord=false;
	            	lstRecords.add(lstCols);
            	}
            	else{
            		//System.out.println("line length= " + line.length);
            		for (int i=0; i<line.length; i++)
            			if (!lstExCols.contains(i))
            				lstCols.add(line[i].trim());
            			lstRecords.add(lstCols);
            	}
            }
            
          //  System.out.println("lstRecords = " + lstRecords); 
            	
            
        } catch (IOException e) {
            e.printStackTrace();
        }
	    	return lstRecords;
	    	
	    }
    
	/***************************************************************************************
	 *  Function name 		: AppendCSVContent
	 *  Description 		: Append file content
	/****************************************************************************************/    
	public boolean AppendCSVContent(String csvFile,List<String> LstData) {
	    CSVWriter writer =null;
        try {
        	if (LstData.size()>0) {
             writer = new CSVWriter(new FileWriter(csvFile, true));
             for (String datarec:LstData) {
            	 String [] record = datarec.split(",");
            	 writer.writeNext(record);
             }
            writer.close();
        	}
          //  System.out.println("lstRecords = " + lstRecords); 
            
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
	 }

}