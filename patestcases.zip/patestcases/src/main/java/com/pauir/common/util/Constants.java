/**
 * Constants
 */

package  com.pauir.common.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Constants {

	public final static String KEYWORD = "Keyword";
	public final static String KEYWORD_PASS = "Pass";
	public final static String KEYWORD_FAIL = "Failed";
	public final static String KEYWORD_SKIP = "Skip";
	public final static String KEYWORD_REF = "ref#";
	public final static String DATA_SPLIT = "\\|";
	public final static Object POSITIVE_DATA = "Y";
	public final static String RANDOM_VALUE = "@random";
	public final static String SRC_RES_FILEPATH="/downloads/Response/";
	public final static String SRC_RES_EXPORTFILEPATH="/src/main/resources/com/pauir/ImportFiles/";
	
	//PAUIR Refresh data
	public final static String PROJECTNAME = "PAUIR Automation Test Report";
	public final static String REPORTTYPE = "Desktop";
	public final static String REPORTTESTDESC = "Regression Test - Scenarios";
	public final static String REPORTCROSSTESTDESC = "Cross Browser Test - Scenarios";
	public static String BROWSERTYPE = "Firefox";
	public static String OSTYPE = "Windows";
	public final static String PROGRAM = "PROGRAM";
	public final static String YEAR = "YEAR";
	public final static String ADMIN = "ADMIN";
	public static String SCOPE_PROGRAM = "CE Reference";
	public static String SCOPE_YEAR = "2018 - 2019";
	public static String SCOPE_ADMIN = "UI Refresh - Admin 1";
	public static String ORG_STATE = "Virginia";
	public static String popupdropdownlist="xpath|//kendo-popup/div/kendo-list/div/ul/li";
	public static String INVALID_DATA = "Invalid~!@#$";
	public static String APIFieldKeys[] =new String[]{ "code", "name","overrideLabel", "type","description", "required", "minLength", "maxLength", "viewFieldOptions","regex" };

	public static String LOGGEDIN_USER = "paadmin@pearson.com";
	public static String LOGGEDINUSERROLE = "System Admin";
	
	public static String VoidDNRStatus="pending|ready|void|dnr";
	
	public static String CREATESESSIONFAILUREMESSAGE = "Create an Session failed";
	public static String CREATECLASSFAILUREMESSAGE = "Create Class Failed";
	public static String CREATEORGANIZATIONSFAILUREMESSAGE = "Create Organization Failed";
	public static String CREATEUSERFAILUREMESSAGE = "Create User failed";
	public static String UPDATESTUDENTFAILUREMESSAGE = "Update Student Failed";
	public static String FIELDERROR = "Required Field";
	public static String UnenrollConfirmPopupTitle = " Please confirm";
	public static String DeleteOrgConfirmPopupTitle = "Delete Organization";
	public static String DeleteSessionConfirmPopupTitle = "Delete Session(s)";
	public static String DeleteClassConfirmPopupTitle = "Delete class(es)";
	public static String MergeSelectStudentPopupTitle = "Merge Selected Students?";
	public static String UpdateReportingSchoolPopupTitle = "Update Reporting School";
	public static String PrintingOptionsPopupTitle = "Select Print Options";
	public static String DeleteCourseConfirmPopupTitle = "Delete Course(s)";
	public static String DeleteUserConfirmPopupTitle = "Delete Users(s)";
	public static String EditAdminTimePopupTitle = "Edit Administration Time";
	public static String AssigntoStudentPopupTitle = "Assign to Student";

	public final static String SessionNameLabel = "Session Name";
	public final static String StudentListPageTitle = "Students";
	public final static String StudentDetailsPageTitle = "Student Details";
	public final static String OrgListPageTitle = "Organization Management";
	public final static String ClassListPageTitle = "Classes";
	public final static String OrgDstListPageTitle = "Districts";
	public final static String OrgSchListPageTitle = "Schools";
	public final static String StateDetailsPageTitle = "State Details";
	public final static String DistrictDetailsPageTitle = "District Details";
	public final static String SchoolDetailsPageTitle = "School Details";
	public final static String ClassDetailPageTitle = "Class Details";
	public final static String ViewSessionListPageTitle = "Sessions";
	public final static String SessionDetailsPageTitle = "Session Info";
	public final static String CreateSessionPageTitle = "Session Info";
	public final static String UserListPageTitle = "Users";
	public final static String CreateClassPageTitle = "Classes";
	public final static String UserDetailsPageTitle = "User Details";
	public final static String CreateDistrictPageTitle = "Create District";
	public final static String CreateSchoolPageTitle = "Create School";
	public final static String AddStudentstoSessionPageTitle = "Add Students to Session";
	public final static String AddStudentstoClassPageTitle = "Add Students";
	public final static String StudentCreatePageTitle = "Create Student";
	public static final String CreateUserPageTitle = "Users";
	public static final String CustomerManagementPageTitle = "Customer Management";
	public final static String MyAccountTitle = "My Account";
	public final static String LogoutTitle = "Sign out";
	public final static String ISRReportPageTitle = "Individual Student Report";
	public final static String DataImportPageTitle = "Imports/Exports";
	public static final String AccommodationListTitle = "ACCOMMODATIONS";
	public static final String AccommodationModalHeaderTitle = "Accommodations";
	public static final String AccommodationNeededHeader = "Accommodations Needed";
	public static final String AccommodationStudentHeader = "Students Accommodations";
	public static final String AccommodationProctorLogin_HR = "Human Read Aloud Log In";
	public static final String AccommodationProctorLogin_HS = "Human Signer Log In";
	public final static String ShipmentsPageTitle = "Shipments";
	public final static int MaxDeleteStudent = 20;
	public final static int MaxCreatedDateBefore = 5;
	public final static String ViewProductListPageTitle = "Tests";
	public final static String ViewTestListPageTitle = "Tests";
	public final static String ViewCourseListPageTitle = "Courses";
	public final static String StudentImportTemplate = "StudentImportTemplate";
	public final static String UserImportTemplate = "UserImportTemplate";
	public final static String CourseImportTemplate = "CourseImportTemplate";
	public final static String ClassImportTemplate = "ClassImportTemplate";
	public final static String DistrictImportTemplate = "DistrictImportTemplate";
	public final static String SchoolImportTemplate = "SchoolImportTemplate";
	public final static String CourseDetailPageTitle = "Course Details";
	public final static String TestDetailsPageTitle = "Test Details";
	public final static String FormPreviewTitle = "Form Preview";
	public final static String CreateCoursePageTitle = "Courses";
	public final static String CreateOrderPageTitle = "Create New Order";
	public final static String OrderDetailPageTitle = "Orders";
	public final static String OrderItemsPageTitle = "Add Items to Order";
	public static String FormCode = "Form Code";
	public static String TestCode = "Test Code";
	
	public static String FDStudName = "Student Name";
	public static String FDStatus = "Status";
	public static String FDStudID = "pa.core.student.search.column.title.state.student.id";
	public static String AddStudFDStudID = "pa.core.student.search.column.title.state.student.id";
	public static String StudDetFDStudID = "pa.core.session.details.student.column.title.student.id";
	public static String ClassFDStudID = "pa.core.student.search.column.title.state.student.id";
	
	public static String DDDistricts = "pa.core.nav.link.label.org.list.dist";
	public static String FDAOrderNum = "Order #";
	public static String FDAOrderItemDes = "Item Description";
	
//	public static String StudentStatusColumn = "Status";
	
	public static boolean Loggedinflag = false;
	public static ThreadLocal<Boolean> THLoggedinFlag = new ThreadLocal<Boolean>() {

	    @Override
	    protected Boolean initialValue() {
	        return Boolean.FALSE;
	    }

	};
	public static boolean Organiztionsflag = false;
	public static boolean Studentsflag = false;
	public static boolean Classflag = false;
	public static boolean Sessionsflag = false;
	public static boolean Usersflag = false;
	public static List<String> PERMISSIONS = Arrays.asList("ACCESS_TEST_SESSIONS","ACCESS_HIGH_STAKES","ACCESS_LOW_STAKES","DELETE_TEST_SESSIONS","CREATE_TEST_SESSIONS","SESSIONS_EDIT_SESSION","SESSIONS_ADD_STUDENTS","SESSIONS_REMOVE_STUDENTS","SESSIONS_UPDATE_STUDENT_TEST_STATUS","SESSIONS_PRINT_AUTH_TICKETS","SESSIONS_RESET_STUDENT_PASSWORD","SESSIONS_VIEW_STUDENT_PROFILE","SESSIONS_ACCESS_HAND_SCORE","SESSIONS_ACCESS_REPORTS","SESSIONS_DOWNLOAD_TEST_FORM","TEST_ATTEMPT_PROCTOR_STATUS_UPDATE","EXTERNAL_SYSTEM","ACCESS_STUDENT_TESTSESSIONS","CREATE_STUDENT_TEST_SESSION_IRREGULARITY","CREATE_UPDATE_ACCOM","VIEW_ACCOM_LIST","CREATE_IRREGULARITY","VIEW_ORGANIZATION_DETAILS",
			"CREATE_ORGANIZATION",
			"DELETE_ORGANIZATION",
			"VIEW_PRODUCT_LIST",
			"CREATE_ORG_CONTACT",
			"VIEW_ORG_CONTACT_DETAILS",
			"CREATE_CLASS",
			"CLASS_ADD_STUDENTS",
			"VIEW_STUDENT_PROFILE",
			"VIEW_STUDENT_PROFILE_RESTRICTED",
			"ACCESS_CLASSES",
			"ACCESS_CONTEXT",
			"VIEW_USER_DETAILS",
			"CREATE_BATCHNOTIFICATIONS",
			"ACCESS_CONTEXT",
			"ACCESS_BATCHNOTIFICATIONS",
			"CREATE_BATCHNOTIFICATIONS",
			"ACCESS_TESTMAP_FORMCODE_DOWNLOAD","VIEW_ORGANIZATIONS_LIST",
			"VIEW_COURSE_LIST",
			"ACCESS_IRREGULARITY","VIEW_USER_LIST","ACCESS_TESTMAP_FORMCODE_DOWNLOAD","PUBLISH_TEST");
	
	//public static List<String> PERMISSIONS = Arrays.asList("CREATE_STUDENT","DELETE_STUDENT", "VIEW_STUDENTS_LIST","VIEW_STUDENT_PROFILE_RESTRICTED", "ACCESS_CLASSES","CREATE_TEMPORARY_STUDENT","ACCESS_TEST_SESSIONS");
	//public static List<String> PERMISSIONS = Arrays.asList("CREATE_STUDENT","ACCESS_CLASSES", "ACCESS_CLASS_ALL","ACCESS_CLASS_ALL", "DELETE_CLASS","CLASS_REMOVE_STUDENTS", "CLASS_ADD_STUDENTS", "EDIT_CLASS");
	

	//Suite Sheet
	public static String SUITE_XLFILE="Suite.xlsx";
	public static final String SUITE_ID = "TestSuiteID";
	public static final String DESCRIPTION = "Description";
	public static String TEST_SUITE_SHEET = "TestSuite";
	public static String Test_Suite_ID = "TestSuiteID";
	public static String TEST_CASES_SHEET = "SuiteName";
	public static String RUNMODE = "RunMode";
	public static String RUNMODE_YES = "YES";
	
	//Input Sheet Column
	public static String TEST_XLFILE="APITestSuites.xlsx";
	public static String XLFILE_FILEPATH="\\src\\main\\resources\\com\\pauir\\testDataResources\\";
	public static String TEST_SHEET ="APISmokeSUITE";
	public static String TEST_JSFILE_Regression ="APIRegressionSuite.json";
	public static String TEST_JSFILE_Smoke ="APISmokeSuite.json";
	public static String TEST_JSFILE_UserRole ="APIUserroleSuite.json";
	public static String TEST_RegressionType ="Regression";
	public static String TEST_SmokeType ="Smoke";
	public static String TEST_UserRoleType ="User Role";
	public static String GlobalHeader="globalheaders";	
	public static String TCID = "operationId";
	public static String DATASET = "DatasetID";
	public static String TESTRUNMODE = "RunMode";
	public static String SERVER="Server";	
	public static String URL="RequestURL";	
	public static String Summary="summary";	
	public static String MethodType="MethodType";
	public static String headers="headers";
	public static String expected="Expected";
	public static String output="Output";
	public static String parameters="parameters";
	public static String requestparameters="RequestParameters";
	public static String pathparameters="Pathparameters";
	public static String Queryparameters="Queryparameters";
	public static String postbody="postbody";
	public static String Header_Keys="Header_Keys";	
	public static String Header_Values="Header_Values";	
	public static String Param_Keys="Param_Keys";	
	public static String Param_Values="Param_Values";
	public static String Expected_Keys="Expected_Keys";
	public static String Expected_Values="Expected_Values";
	public static String ExpectedStatusCode="ExpectedStatusCode";
	public static String ExpectedSchema="ExpectedSchema";
	public static String GetOutputKey="GetOutputKey";
	public static String SwitchingMode="SwitchingMode";
	public static String TestStatus = "TestStatus";
	public static String RESULT = "TestResultStatus";
	public static String ResponseDescription="ResponseDescription";
	public static String ResponseTime="ResponseTime";
	public static String Output_Values="Output_Values";
	public static String Response="Response";
	public static String ExeTag="tags";
	public static String Dependent="Dependent";
	public static String UserPermissions="Userpermissions";
	public static String DataDescription="DataDescription";
	
	public static String UserRoleAdmin="Admin";
	public static String UserRoleTestCoordinator="TestCoordinator";
	public static String UserRoleTestCoordinatorInterim="TestCoordinator_Interim";
	public static String UserRoleTeacher="Teacher";
	public static String UserRoleTestAdministrator="TestAdministrator";
	public static String UserRoleReportingAdmin="ReportingAdministrator";
	public static String UserRoleHandScoreAdmin="HandScoringAdministrator";
	public static String UserRoleSystemAdmin="SystemAdmin";
	public static String UserRoleTechSupport="TechnicalSupport";
	public static String UserRoleCS1="CustomerSupport1";
	public static String UserRoleCS2="CustomerSupport2";
	
	//TestResults
	public static String RepIssue_key="operationId";
	public static String RepAPIMethodType="MethodType";
	public static String RepAPIRequest="RequestURL";
	public static String RepAPIURL="APIURL";
	public static String RepAPIDescription="Summary";
	public static String RepInput_KeyValues="RequestParameter";
	public static String RepExpected="Expected";
	public static String RepTestResultStatus="TestResultStatus";
	public static String RepResponseDescription="ResponseDescription";
	public static String RepResponseTime="ResponseTime";
	public static String RepOutput_Values="Output_Values";
	public static String RepStatusCode="StatusCode";
	public static String RepResponse="Response";
	public static String ResponseFilePath="ResponseFilePath";
	
	//Others
	
	public static String KEYWORD_RANDOM = "#random";
	public static String DATA = "Data";
	public static String OBJECT = "Object";
	public static String DATA_START_COL = "col";
	
	public static String DATASET_SPLIT = "@";
	public static String BDD_VALUESEPERATOR = "~";
	public static String BDD_TABSEPERATOR = "|";
	
	public static String CONFIG = "config";
	
	
	
	///JiraConst
	
	// Csv File Header
		
		public static final String REFURLValue = "RefValue";
		public static final String METHOD_TYPE = "MethodType";
		public static final String HEADER_KEYS = "Header_Keys";
		public static final String HEADER_VALUES = "Header_Values";
		public static final String PARAM_KEYS = "Param_Keys";
		public static final String PARAM_VALUES = "Param_Values";
		public static final String EXPECTED_KEYS = "Expected_Keys";
		public static final String EXPECTED_VALUES = "Expected_Values";
		public static final String EXPECTED_STATUS_CODE = "ExpectedStatusCode";
		public static final String EXPECTED_SCHEMA = "ExpectedSchema";
		public static final String GET_OUTPUT_KEY = "GetOutputKey";
		public static final String SWITCHING_MODE = "SwitchingMode";
		public static final String TEST_RESULT_STATUS = "TestResultStatus";
		public static final String RESPONSE_DESCRIPTION = "ResponseDescription";
		public static final String RESPONSE_TIME = "ResponseTime";
		public static final String OUTPUT_VALUES = "Output_Values";
		public static final String PASS = "Pass";
		public static final String FAILED = "Failed";

		public static final String NULL_VALUE = "null";
		public static final String RUNMODE_VALUE_YES = "Yes";
		public static final String RUNMODE_VALUE_NO = "No";
		public static final String ISSUE_KEY_LIST = "Issue_key";
		public static final String ISSUE_KEY = "Issue_key";
	
		public static final String PROJECT = "Project_key";
		public static final String SPRINT = "Sprint";
		public static  final String FIXVERSION = "Version";
		public static final String FIXRELEASEDATE = "ReleaseDate";
		public static final String SUMMARY = "summary";
		public static final String DETAILS = "Details";
		public static final String INPUT_VALUES = "INPUT_VALUES";
		public static final String LABELS = "labels";
		public static final String FIX_VERSION = "Fix Version/s";
		public static final String TESTINGTYPE = "TestingType";

		public static final String INWARD_ISSUE = "inwardIssue";
		public static final String OUTWARD_ISSUE = "outwardIssue";
		
		public static final String RecordDelimiter = "\\r?\\n";
		public static final String NEWLineDelimiter = "\n";
		public static final String ValueDelimiter = ",";
		public static final String DATAFLAG = "DSFlag";
		public static final String DATASETID = "DatasetID";
		public static final String DATASETS = "Datasets";
		public static final String Tests = "Tests";
		public static final String DEPENDENTISSUES = "DependentIssues";
		public static final String EnvironmentData = "environment";
		public static final String CurrentSuiteData = "currentsuite";
		public static final String GenerateOauthToken = "generateoauthtoken";
		public static final String SecretKey = "PAAUTOMATIONSECKEY";
		

		//JSON Report TAG
		public static String JIRAProject = "Pearson Access";
		public static String JIRAIssueType = "Test";
		public static String JIRASprint = "Sprint-1";
		public static String TestingType = "Smoke";
		public static String ExecutionDuration = "30";
		public static String TimeType = "Mins";
		public static String ReleaseType = "Build";
		public static String BuildReleaseVersion = "271";
		public static String JIRAReleaseDate = "2017-03-31";
		//JSON Report TAG
		public static String JSReportTitle = "TestDataTitle";
		public static String JSRunDate = "RunDate";
		public static String JSRunEnvironment = "RunEnvironment";
		public static String JSTestingType = "TestingType";
		public static String JSReleaseVersion = "ReleaseVersion";
		public static String JSReleaseDate = "ReleaseDate";
		public static String JSVersion = "Version";
		public static String JSsuite = "suite";
		public static String JSsuiteTitle = "title";
		public static String JSsuiteName = "SUITENAME";
		public static String JSsuiteDes = "DESCRIPTION";
		public static String JSProject = "Project";
		public static String JSIssueType = "IssueType";
		public static String JSSprint = "Sprint";
		public static String JSsuiteStatus = "Status";
		public static String JSExecutionDuration = "TimeTaken";
		public static String JSsuiteNoOfTestCases = "NoOfTestCases";
		public static String JSsuiteNoOfPassed = "NoOfPassed";
		public static String JSsuiteNoOfFailed = "NoOfFailed";
		public static String JSsuitNoOfSkipped = "NoOfSkipped";
		public static String JSsuitTest = "tests";
		public static String JSsuitDataSets = "Datasets";
		public static String JSUserRole = "Userrole";
		public static String JSUsersuite = "usersuites";
		
//API
		public static HashMap<String, Object> APIheaders =null;
		public static HashMap<String, Object> SuiteAPIheaders=null;
		public static String OauthToken = null;
		public static String APIServer = "https://pa-dev-main.pearsonpathway.com";
		public static HashMap<String, String> mapCustomLabels =null;
		public static String UserroleOutputfile = null;
		public static HashMap<String, String> mapUserroleJsonOutputfiles =new HashMap<String,String>();
		public static HashMap<String, String> mapUserroleJsonReportfiles =new HashMap<String,String>();
		public static HashMap<String, String> mapUserrolehtmlReportfiles =new HashMap<String,String>();;

}
