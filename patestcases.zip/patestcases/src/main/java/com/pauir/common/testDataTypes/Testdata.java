package com.pauir.common.testDataTypes;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Testdata {

@SerializedName("environment")
@Expose
private String environment;
@SerializedName("url")
@Expose
private String url;
@SerializedName("adminurl")
@Expose
private String adminurl;

@SerializedName("customers")
@Expose
private List<Testdata_Customers> customers = null;

public String getEnvironment() {
return environment;
}

public void setEnvironment(String environment) {
this.environment = environment;
}

public String getUrl() {
return url;
}

public void setUrl(String url) {
this.url = url;
}

public String getAdminUrl() {
return adminurl;
}

public void setAdminUrl(String adminurl) {
this.adminurl = adminurl;
}

public List<Testdata_Customers> getCustomers() {
return customers;
}

public void setUsers(List<Testdata_Customers> customers) {
this.customers = customers;
}

}