package com.pauir.common.util;

import java.io.File;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;
import com.pauir.common.util.AESDesEncrypter;
import com.pauir.common.core.FileReaderManager;

import webdriver.main.CommonUtility;
import webdriver.main.Log;

public class EmailReports {
	public static List<Map<String , String>> lstAPIFailedSuite = new ArrayList<Map<String,String>>();
	public static List<Map<String , String>> lstUIFailedSuite = new ArrayList<Map<String,String>>();
	/**
	   Outgoing Mail (SMTP) Server
	   requires TLS or SSL: smtp.gmail.com (use authentication)
	   Use Authentication: Yes
	   Port for SSL: 465
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		EmailReports email=new EmailReports();
		
		//Compose and Send mail
		//email.ComposeEmailReports("regression");
		//email.getUIFailures();
		//email.getAPIFailures();
		List<Map<String , String>> lstReportresult  =parseDocforError();
		if (lstReportresult.size()>0) {
			String htmlcontent=GeneratehtmlforEmailReport(lstReportresult);
			System.out.println("htmlcontent:"+htmlcontent);
		}
		
	}
	
	/**
	 * Compose and Send email
	 * 	
	 */
	public void ComposeEmailReports(String Testingtype) throws Exception {
		String environment=FileReaderManager.getInstance().getConfigReader().getEnvironment();
		List<Map<String , String>> lstReportresult  =parseDocforError();
		String htmlcontent=null;
		Constants.TestingType=Testingtype;
		if (lstReportresult.size()>0) {
			htmlcontent=GeneratehtmlforEmailReport(lstReportresult);
			if (htmlcontent!=null)
				ComposeAndSendAWSEmailReport("AutomationReports","PA5 Automation Test Report Summary - "+environment+" - "+Testingtype,htmlcontent,Testingtype);
		}
		
	}

	/**
	 * Compose and Send email
	 * 
	 */
	public void ComposeAndSendAWSEmailReport(String Fromname,String MsgSubject,String MsgBody, String Testingtype) throws Exception {
		final String fromHostName = FileReaderManager.getInstance().getConfigReader().getMailHostname(); // can be any email hostname
		final String fromEmail = FileReaderManager.getInstance().getConfigReader().getMailSender(); //requires valid gmail id
		final String fromEmailUsername = FileReaderManager.getInstance().getConfigReader().getMailUsername(); //requires valid gmail id
		final String encptpassword = FileReaderManager.getInstance().getConfigReader().getMailPassword(); // correct password for gmail id
		final String fromEmailpassword = AESDesEncrypter.decrypt(encptpassword, Constants.SecretKey) ;
		String toEmail = null;

		if (Testingtype.equalsIgnoreCase("regression")) 
			toEmail = FileReaderManager.getInstance().getConfigReader().getMailRecipientsAddress(); // can be any email id
		else
			toEmail = FileReaderManager.getInstance().getConfigReader().getMailSecondarRecipientsAddress(); // can be any email id
		
        // Create a Properties object to contain connection configuration information.
    	Properties props = System.getProperties();
    	props.put("mail.transport.protocol", "smtp");
    	props.put("mail.smtp.port", 587); 
    	props.put("mail.smtp.starttls.enable", "true");
    	props.put("mail.smtp.auth", "true");

        // Create a Session object to represent a mail session with the specified properties. 
    	Session session = Session.getDefaultInstance(props);

        // Create a message with the specified information. 
        MimeMessage msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress(fromEmail,Fromname));
        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail, false));
        msg.setSubject(MsgSubject);
        msg.setContent(MsgBody,"text/html");
        
        // Create a transport.
        Transport transport = session.getTransport();
                    
        // Send the message.
        try
        {
			//Log._logInfo("Email Sending...");
			// Connect to Amazon SES using the SMTP username and password you specified above.
			transport.connect(fromHostName, fromEmailUsername, fromEmailpassword);
    	
			// Send the email.
			transport.sendMessage(msg, msg.getAllRecipients());
			//System.out.println("Email sent!"+toEmail);
			Log._logInfo("Email sent successfully to "+toEmail);
        }
        catch (Exception ex) {
            Log._logInfo("Email not sent with Error message "+ex.getMessage());
        }
        finally
        {
            // Close and terminate the connection.
            transport.close();
        }
	}
	
	
	/**
	 * Compose and Send email
	 * 
	 */
	public void ComposeAndSendEmailReport() throws Exception {
		final String fromHostName = FileReaderManager.getInstance().getConfigReader().getMailHostname(); // can be any email hostname
		final String fromEmail = FileReaderManager.getInstance().getConfigReader().getMailSender(); //requires valid gmail id
		final String fromEmailUsername = FileReaderManager.getInstance().getConfigReader().getMailUsername(); //requires valid gmail id
		final String encptpassword = FileReaderManager.getInstance().getConfigReader().getMailPassword(); // correct password for gmail id
		final String fromEmailpassword = AESDesEncrypter.decrypt(encptpassword, Constants.SecretKey) ;
		final String toEmail = FileReaderManager.getInstance().getConfigReader().getMailRecipientsAddress(); // can be any email id
		
		System.out.println(fromEmailUsername);
		System.out.println(fromEmailpassword);
		
//		System.out.println("TLSEmail Start");
		Properties props = new Properties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.host", fromHostName); //SMTP Host
		props.put("mail.smtp.port", "587"); //TLS Port
		props.put("mail.smtp.auth", "true"); //enable authentication
		props.put("mail.smtp.starttls.enable", "true"); //enable STARTTLS
    	
                //create Authenticator object to pass in Session.getInstance argument
		Authenticator auth = new Authenticator() {
			//override the getPasswordAuthentication method
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromEmail,fromEmailpassword);
			}
		};

		List<Map<String , String>> lstReportresult  =parseDocforError();
		if (lstReportresult.size()>0) {
			String htmlcontent=GeneratehtmlforEmailReport(lstReportresult);
			//System.out.println("htmlcontent: "+htmlcontent);
			Session session = Session.getInstance(props, auth);
			//System.out.println("Session created");
		    EmailUtil.sendEmail(session,fromEmail,fromEmailUsername, toEmail,"Automation Test Report",htmlcontent);	
		}
		
	}
	
	
	/**
	 * Generate Html for email report
	 * @param lstReportresult
	 * @return Htmlecontent
	 */
	public static String GeneratehtmlforEmailReport(List<Map<String , String>> lstReportresult) throws Exception 
	{
		Log._logInfo("Generate HTML Email Content");
		String Htmlecontent=null;
		Date date = new Date();
		String environment=FileReaderManager.getInstance().getConfigReader().getEnvironment();
		String s3reportloc = System.getProperty("reportloc");
		//String s3reportloc = "s3://pa-dev-main-regression/UIAutomationReports/2020-09-21/01-02/.";
		if (s3reportloc!=null) {
			String strArrObjLocs[] = CommonUtility._split(s3reportloc,"s3:/");
			if(strArrObjLocs.length>1)
				s3reportloc=strArrObjLocs[1];
		}
		String reportloc="https://s3.console.aws.amazon.com/s3/buckets"+s3reportloc;
		String TestingType=Constants.TestingType;
		try{
			  Htmlecontent="<html><HEAD> <TITLE>Automation Test Results</TITLE></HEAD>"
			  +"<body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u>PA5 Automation Test Report</u></b></h4>"
			     +"<table width='900' cellpadding='0' cellspacing='0' border='0'>"
                 +"<tr><td>"
                 +"<h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4>"
			  + "<table  border=1 cellspacing=1 cellpadding=1 ><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=250 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>"
			  +date.toString()
			  +"</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Environment</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>"
			  +environment
			  +"</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>APP Url</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>"
			  +Constants.APIServer
			  +"</b></td></tr><tr><td width=200 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Testing Type </b></td><td width=300 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>"
			  +TestingType
			  +"</b></td></tr></table><h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>Report Summary:</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=15% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SUITE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Success rate</b></td>"
			  +"<td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of TestCases</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of Passed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Failed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Skipped</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Execution Time</b></td></tr>";
			 
			  for (Map<String,String> resultdata:lstReportresult){
					Htmlecontent=Htmlecontent+"<tr><td width=10% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
							+resultdata.get("SUITE NAME")
					  +"</b></td><td width=25% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
					  +resultdata.get("DESCRIPTION")
					  +"</b></td>"
					  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value><b>"+resultdata.get("Success rate")+"</span></td>"
					  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value>"+resultdata.get("No Of TestCases")+"</span></td>"
					  +"<td width=10% align=center  bgcolor=green><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+resultdata.get("No Of Passed")+"</span></td>"
					  +"<td width=10% align=center  bgcolor=red><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+resultdata.get("No of Failed")+"</span></td>"
					  +"<td width=10% align=center  bgcolor=yellow><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+resultdata.get("No of Skipped")+"</span></td>"
					  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+resultdata.get("Execution Time")+"</b></td></tr>";
			  }
			  Htmlecontent=Htmlecontent+"</table>"
			  +"</td>"
			  +"</tr>"
			  +"</tr>"
			  +"<tr>"
			  +"<td height='6'></td>"
			  +"</tr>"
			  +"<tr>"
		       +"<td height='6'></td>"
		       +"</tr>"
			  +"<tr>"
			      +"<td class ='text12' width='100%'>To view detailed test reports placed in AWS S3 bucket:<a href="+reportloc+" style='font-weight: bolder;'>Click Here</a>."+"</td>"
			  +"</tr>"
			  +"<tr>"
			       +"<td height='15'></td>"
			  +"</tr><tr><td>";
			  if (lstAPIFailedSuite.size()>0) {
				  Htmlecontent=Htmlecontent+"<h3><FONT COLOR=660000 FACE= Arial  SIZE=2.5> <u>API Failed Suites:</u></h3><ul style=\"line-height:120%;list-style-type:none\">";
				  int iAPICount=1;
				  for (Map<String,String> apiFaileddata:lstAPIFailedSuite){
					  Htmlecontent=Htmlecontent+"<li><div style= \"border: 1px solid #eceff1;margin: 2px\"><FONT COLOR=Black FACE= Arial  SIZE=2> "+apiFaileddata.get("SuiteName")+" - "+apiFaileddata.get("TestRequestURL")+" - "+apiFaileddata.get("TestDesc")+" - <span style=\"background-color:red;color:White\">"+apiFaileddata.get("TestActualStatus")+"</span> Status</div></li>";
					  if((iAPICount+1)>10) {
						  Htmlecontent=Htmlecontent+"<li>"+(lstAPIFailedSuite.size()-iAPICount)+" More failures...</li>";
						  break;
					  }
					  iAPICount=iAPICount+1;
				   }
				  Htmlecontent=Htmlecontent+"</ul>";
			  }
			  if (lstUIFailedSuite.size()>0) {
				  Htmlecontent=Htmlecontent+"<h3><FONT COLOR=660000 FACE= Arial  SIZE=2.5> <u>UI Failed Scenarios:</u></h3><ul style=\"line-height:120%;list-style-type:none\">";
				  int iUICount=1;
				  for (Map<String,String> uiFaileddata:lstUIFailedSuite){
					  int failedsteps=Integer.parseInt(uiFaileddata.get("FailedStepCount"));
					  DecimalFormat formatter = new DecimalFormat("00");
					  String aFormattedfailedsteps = formatter.format(failedsteps);
					  Htmlecontent=Htmlecontent+"<li><div style= \"border: 1px solid #eceff1;margin: 2px\"><FONT COLOR=Black FACE= Arial  SIZE=2> "+uiFaileddata.get("Feature")+" - "+uiFaileddata.get("Scenario")+" - <span style=\"background-color:red;color:White\">"+aFormattedfailedsteps+"</span> Steps</div></li>";
					  if((iUICount+1)>10) {
						  Htmlecontent=Htmlecontent+"<li>"+(lstUIFailedSuite.size()-iUICount)+" More failures...	</li>";
						  break;
					  }
					  iUICount=iUICount+1;
				   }
				  Htmlecontent=Htmlecontent+"</ul>";
			  }
			  Htmlecontent=Htmlecontent+"</td></tr>"
			  +"<tr><td  class ='text12' width='100%'>"+"Regards"+"</td></tr>"
			  +"<tr><td  class ='text12' width='100%'>"+"PA5 QA Team</td></tr>"
			  +"</table>"
	           +"</body>"
	           +"</html>";   
		}
			  catch (Exception e){
			  e.printStackTrace();
		  }
		return Htmlecontent;
	}
	/**
	 * Generate Html for email report
	 * @param lstReportresult
	 * @return Htmlecontent
	 */
	public static String GeneratehtmlwithfailuresforEmailReport(List<Map<String , String>> lstReportresult) throws Exception 
	{
		Log._logInfo("Generate HTML Email Content");
		String Htmlecontent=null;
		String reportloc=null;
		Date date = new Date();
		String environment=FileReaderManager.getInstance().getConfigReader().getEnvironment();
		String s3reportloc = System.getProperty("reportloc");
		//String s3reportloc = "s3://pa-dev-main-regression/UIAutomationReports/2020-09-21/01-02/.";
		if (s3reportloc!=null) {
		String strArrObjLocs[] = CommonUtility._split(s3reportloc,"s3:/");
		if(strArrObjLocs.length>1)
			s3reportloc=strArrObjLocs[1];
			reportloc="https://s3.console.aws.amazon.com/s3/buckets"+s3reportloc;
		}
		String TestingType=Constants.TestingType;
		try{
			  Htmlecontent="<html><HEAD> <TITLE>Automation Test Results</TITLE></HEAD>"
			  +"<body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u>PA5 Automation Test Report</u></b></h4>"
			     +"<table width='900' cellpadding='0' cellspacing='0' border='0'>"
                 +"<tr><td>"
                 +"<h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4>"
			  + "<table  border=1 cellspacing=1 cellpadding=1 ><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=250 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>"
			  +date.toString()
			  +"</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Environment</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>"
			  +environment
			  +"</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>APP Url</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>"
			  +Constants.APIServer
			  +"</b></td></tr><tr><td width=200 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Testing Type </b></td><td width=300 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>"
			  +TestingType
			  +"</b></td></tr></table>";
			  
			  for (Map<String,String> resultdata:lstReportresult)
			   {
				  String APIorUI=resultdata.get("APIorUI");
				  Htmlecontent=Htmlecontent+"<h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>"+APIorUI+" Report Summary:</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=15% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SUITE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Success rate</b></td>"
						  +"<td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of TestCases</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of Passed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Failed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Skipped</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Execution Time</b></td></tr>"
						  +"<tr><td width=10% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
							+resultdata.get("SUITE NAME")
					  +"</b></td><td width=25% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
					  +resultdata.get("DESCRIPTION")
					  +"</b></td>"
					  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value><b>"+resultdata.get("Success rate")+"</span></td>"
					  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value>"+resultdata.get("No Of TestCases")+"</span></td>"
					  +"<td width=10% align=center  bgcolor=green><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+resultdata.get("No Of Passed")+"</span></td>"
					  +"<td width=10% align=center  bgcolor=red><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+resultdata.get("No of Failed")+"</span></td>"
					  +"<td width=10% align=center  bgcolor=yellow><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+resultdata.get("No of Skipped")+"</span></td>"
					  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+resultdata.get("Execution Time")+"</b></td></tr>"
				  	  +"</table>";
					  //+"</tr>";
				  if (APIorUI.contains("API")) {
					  if (lstAPIFailedSuite.size()>0) {
						  Htmlecontent=Htmlecontent+"<h3> <FONT COLOR=660000 FACE= Arial  SIZE=2.5> <u>"+APIorUI+" Failed Suites:</u></h3><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Test OperationId</b></td><td width=25% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Summary</b></td><td width=25% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>RequestURL</b></td>"
								  +"<td width=5% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Statuscode</b></td></tr>";
						  for (Map<String,String> apiFaileddata:lstAPIFailedSuite)
						   {
							  
							  Htmlecontent=Htmlecontent+"<tr><td width=10% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
										+apiFaileddata.get("SuiteName")
								  +"</b></td><td width=25% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
								  +apiFaileddata.get("TestDesc")
								  +"</b></td>"
								  +"<td width=10% align=Left ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value><b>"+apiFaileddata.get("TestRequestURL")+"</span></td>"
								  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value>"+apiFaileddata.get("TestActualStatus")+"</span></td></tr>";
							  	 
						   }
						  Htmlecontent=Htmlecontent+"</table>";
						  
					  }
				  }
				  else if (APIorUI.contains("UI")) {
					  if (lstUIFailedSuite.size()>0) {
						  Htmlecontent=Htmlecontent+"<h3><FONT COLOR=660000 FACE= Arial  SIZE=2.5> <u>"+APIorUI+" Failed Scenarios:</u></h3><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Features</b></td><td width=15% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Scenarios</b></td>"
						  		+ "<td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Total Steps</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Steps Failed</b></td>"
								  //+"<td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>FailedSteps</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>ActualResults</b></td>"
								  + "</tr>";
						  for (Map<String,String> uiFaileddata:lstUIFailedSuite)
						   {
							  
							  Htmlecontent=Htmlecontent+"<tr><td width=10% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
										+uiFaileddata.get("Feature")
								  +"</b></td><td width=25% align= Left><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
								  +uiFaileddata.get("Scenario")
								  +"</b></td>"
								  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value><b>"+uiFaileddata.get("TotalStepCount")+"</span></td>"
								  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value><b>"+uiFaileddata.get("FailedStepCount")+"</span></td>"
//								  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value>"+uiFaileddata.get("Steps")+"</span></td>"
//								  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value>"+uiFaileddata.get("ActualSteps")+"</span></td>"
								  + "</tr>";

						   }
						  Htmlecontent=Htmlecontent+"</table>";
						  
					  }
				  }
			     }
			  Htmlecontent=Htmlecontent+"<tr>"
			       +"<td height='6'></td>"
			  +"</tr>"
			  +"<tr>"
		       +"<td height='6'></td>"
		       +"</tr>"
			  +"<tr>"
			      +"<td class ='text12' width='100%'>To view detailed test reports placed in AWS S3 bucket:<a href="+reportloc+" style='font-weight: bolder;'>Click Here</a>."+"</td>"
			  +"</tr>"
			  +"<tr>"
			       +"<td height='15'></td>"
			  +"</tr>"
			  +"<tr><td  class ='text12' width='100%'>"+"Regards"+"</td></tr>"
			  +"<tr><td  class ='text12' width='100%'>"+"PA5 QA Team</td></tr>"
			  +"</table>"
	           +"</body>"
	           +"</html>";   
		}
			  catch (Exception e){
			  e.printStackTrace();
		  }
		return Htmlecontent;
	}
	
	/**
	 * Generate Html for email report
	 * @param lstReportresult
	 * @return Htmlecontent
	 */
	public static String GeneratehtmlwithfailuresforEmailReport2(List<Map<String , String>> lstReportresult) throws Exception 
	{
		Log._logInfo("Generate HTML Email Content");
		String Htmlecontent=null;
		String reportloc=null;
		Date date = new Date();
		String environment=FileReaderManager.getInstance().getConfigReader().getEnvironment();
		String s3reportloc = System.getProperty("reportloc");
		//String s3reportloc = "s3://pa-dev-main-regression/UIAutomationReports/2020-09-21/01-02/.";
		if (s3reportloc!=null) {
		String strArrObjLocs[] = CommonUtility._split(s3reportloc,"s3:/");
		if(strArrObjLocs.length>1)
			s3reportloc=strArrObjLocs[1];
			reportloc="https://s3.console.aws.amazon.com/s3/buckets"+s3reportloc;
		}
		String TestingType=Constants.TestingType;
		try{
			  Htmlecontent="<html><HEAD> <TITLE>Automation Test Results</TITLE></HEAD>"
			  +"<body><h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u>PA5 Automation Test Report</u></b></h4>"
			     +"<table width='900' cellpadding='0' cellspacing='0' border='0'>"
                 +"<tr><td>"
                 +"<h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4>"
			  + "<table  border=1 cellspacing=1 cellpadding=1 ><tr><td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td><td width=250 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>"
			  +date.toString()
			  +"</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Environment</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>"
			  +environment
			  +"</b></td></tr><tr><td width=200 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>APP Url</b></td><td width=300 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>"
			  +Constants.APIServer
			  +"</b></td></tr><tr><td width=200 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Testing Type </b></td><td width=300 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>"
			  +TestingType
			  +"</b></td></tr></table>";
			  
			  for (Map<String,String> resultdata:lstReportresult)
			   {
				  String APIorUI=resultdata.get("APIorUI");
				  Htmlecontent=Htmlecontent+"<h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>"+APIorUI+" Report Summary:</u></h4><table  border=1 cellspacing=1 cellpadding=1 width=100%><tr><td width=15% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>SUITE NAME</b></td><td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>DESCRIPTION</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Success rate</b></td>"
						  +"<td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of TestCases</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No Of Passed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Failed</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>No of Skipped</b></td><td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Execution Time</b></td></tr>"
						  +"<tr><td width=10% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
							+resultdata.get("SUITE NAME")
					  +"</b></td><td width=25% align= center><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
					  +resultdata.get("DESCRIPTION")
					  +"</b></td>"
					  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value><b>"+resultdata.get("Success rate")+"</span></td>"
					  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><span value>"+resultdata.get("No Of TestCases")+"</span></td>"
					  +"<td width=10% align=center  bgcolor=green><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+resultdata.get("No Of Passed")+"</span></td>"
					  +"<td width=10% align=center  bgcolor=red><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+resultdata.get("No of Failed")+"</span></td>"
					  +"<td width=10% align=center  bgcolor=yellow><FONT COLOR=153E7E FACE=Arial SIZE=2><span>"+resultdata.get("No of Skipped")+"</span></td>"
					  +"<td width=10% align=center ><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"+resultdata.get("Execution Time")+"</b></td></tr>"
				  	  +"</table>";
					  //+"</tr>";
				  if (APIorUI.contains("API")) {
					  if (lstAPIFailedSuite.size()>0) {
						  Htmlecontent=Htmlecontent+"<h3><FONT COLOR=660000 FACE= Arial  SIZE=2.5> <u>"+APIorUI+" Failed Suites:</u></h3><ul style=\"line-height:120%;list-style-type: none\">";
						  int iAPICount=1;
						  for (Map<String,String> apiFaileddata:lstAPIFailedSuite){
							  Htmlecontent=Htmlecontent+"<li><div style= \"border: 1px solid #eceff1;margin: 2px\"><FONT COLOR=Black FACE= Arial  SIZE=2> "+iAPICount+". "+apiFaileddata.get("SuiteName")+" - "+apiFaileddata.get("TestRequestURL")+" - "+apiFaileddata.get("TestDesc")+" - <span style=\"background-color:red;color:White\">"+apiFaileddata.get("TestActualStatus")+"</span></div></li>";
							  if(iAPICount>10) {
								  //Htmlecontent=Htmlecontent+"<li>..."+iAPICount+" out of "+lstAPIFailedSuite.size()+" errors displayed</li>";
								  Htmlecontent=Htmlecontent+"<li>...More</li>";
								  break;
							  }
							  iAPICount=iAPICount+1;
						   }
						  Htmlecontent=Htmlecontent+"</ul>";
					  }
				  }
				  else if (APIorUI.contains("UI")) {
					  if (lstUIFailedSuite.size()>0) {
						  Htmlecontent=Htmlecontent+"<h3><FONT COLOR=660000 FACE= Arial  SIZE=2.5> <u>"+APIorUI+" Failed Scenarios:</u></h3><ul style=\"line-height:120%;list-style-type: none\">";
						  int iUICount=1;
						  for (Map<String,String> uiFaileddata:lstUIFailedSuite){
							  Htmlecontent=Htmlecontent+"<li><div style= \"border: 1px solid #eceff1;margin: 2px\"><FONT COLOR=Black FACE= Arial  SIZE=2> "+iUICount+". "+uiFaileddata.get("Feature")+" - "+uiFaileddata.get("Scenario")+" - <span style=\"background-color:red;color:White\">"+uiFaileddata.get("FailedStepCount")+"</span></div></li>";
							  if(iUICount>10) {
								  Htmlecontent=Htmlecontent+"<li>...More</li>";
								  break;
							  }
							  iUICount=iUICount+1;
						   }
						  Htmlecontent=Htmlecontent+"</ul>";
					  }
				  }
			     }
			  Htmlecontent=Htmlecontent+"<tr>"
			       +"<td height='6'></td>"
			  +"</tr>"
			  +"<tr>"
		       +"<td height='6'></td>"
		       +"</tr>"
			  +"<tr>"
			      +"<td class ='text12' width='100%'>To view detailed test reports placed in AWS S3 bucket:<a href="+reportloc+" style='font-weight: bolder;'>Click Here</a>."+"</td>"
			  +"</tr>"
			  +"<tr>"
			       +"<td height='15'></td>"
			  +"</tr>"
			  +"<tr><td  class ='text12' width='100%'>"+"Regards"+"</td></tr>"
			  +"<tr><td  class ='text12' width='100%'>"+"PA5 QA Team</td></tr>"
			  +"</table>"
	           +"</body>"
	           +"</html>";   
		}
			  catch (Exception e){
			  e.printStackTrace();
		  }
		return Htmlecontent;
	}
	
	/**
	 * Get details from  Html report 
	 * @return lstReportresult
	 */
	public static List<Map<String , String>> parseDocforError() throws Exception {
		
		
		List<Map<String , String>> lstReportresult  = new ArrayList<Map<String,String>>();
		Map<String,String> resultdata = null;
		String destpath = "./custom_report/LatestReport/API_Execution_Result.html";
		File destDir = new File(destpath);
		resultdata = new HashMap<String,String>();
		if ((destDir.exists())&&(destDir.canRead())) {
			Document doc = Jsoup.parse(destDir, "UTF-8");
			resultdata.put("APIorUI", "API");
			Elements elements = doc.select("body > table:nth-child(5) > tbody > tr:nth-child(2) > td:nth-child(1)>font>b");
			resultdata.put("SUITE NAME", elements.text());
			elements = doc.select("body > table:nth-child(5) > tbody > tr:nth-child(2) > td:nth-child(2)>font>b");
			resultdata.put("DESCRIPTION", elements.text());
			elements = doc.select("body > table:nth-child(5) > tbody > tr:nth-child(2) > td:nth-child(3)>font>b");
			resultdata.put("Success rate", elements.text());
			elements = doc.select("body > table:nth-child(5) > tbody > tr:nth-child(2) > td:nth-child(4)>font>a>span");
			resultdata.put("No Of TestCases", elements.text());
			elements = doc.select("body > table:nth-child(5) > tbody > tr:nth-child(2) > td:nth-child(5)>font>a>span");
			resultdata.put("No Of Passed", elements.text());
			elements = doc.select("body > table:nth-child(5) > tbody > tr:nth-child(2) > td:nth-child(6)>font>a>span");
			String FailedAPICount=elements.text();
			int iFailedAPICnt=Integer.parseInt(FailedAPICount);
			if (iFailedAPICnt>0) {
				lstAPIFailedSuite=getAPIFailures(doc);
			}
			resultdata.put("No of Failed", elements.text());
			elements = doc.select("body > table:nth-child(5) > tbody > tr:nth-child(2) > td:nth-child(7)>font>a>span");
			resultdata.put("No of Skipped", elements.text());
			elements = doc.select("body > table:nth-child(5) > tbody > tr:nth-child(2) > td:nth-child(8)>font>b");
			resultdata.put("Execution Time", elements.text());
			
			lstReportresult.add(resultdata);
		}
		
		resultdata = new HashMap<String,String>();
		
		String destpath1 = "./custom_report/LatestReport/UM_Execution_Result_Desktop.htm";
		File destDir1 = new File(destpath1);
		if ((destDir1.exists())&&(destDir1.canRead())) {
			Document doc1 = Jsoup.parse(destDir1, "UTF-8");
			Elements elements1 = null;
			elements1 = doc1.select("#test-collection > li.test > div.test-heading > span.test-name");
			String featureName=elements1.text();
			if (featureName.contains("Regression"))
				featureName="Regression Suite";
			else if(featureName.contains("smoke"))
				featureName="Smoke Suite";
		   	else 
		   		featureName="Regression Test";
			resultdata.put("APIorUI", "UI");
			resultdata.put("SUITE NAME", "UI "+featureName);			
			resultdata.put("DESCRIPTION", "PA5 UI "+featureName+" Report");
			
			elements1 = doc1.select("#dashboard-view > div > div > div:nth-child(1) > div > div");
			
			String totnum=elements1.text();
			int tottc=Integer.parseInt(totnum);
			resultdata.put("No Of TestCases", totnum);
			elements1 = doc1.select("#charts-row > div:nth-child(1) > div > div:nth-child(3) > span > span");

			String passnum=elements1.text();
			int passtc=Integer.parseInt(passnum);
			resultdata.put("No Of Passed", passnum);
			
			double TCPassspercent= passtc *100 ;
			TCPassspercent=TCPassspercent/tottc;
			DecimalFormat df2 = new DecimalFormat("#.##");
			df2.setRoundingMode(RoundingMode.UP);
			String SuccRate=df2.format(TCPassspercent);
			resultdata.put("Success rate", SuccRate+"%");
			elements1 = doc1.select("#charts-row > div:nth-child(1) > div > div:nth-child(4) > span:nth-child(1)");
			
			String FailedUICount=elements1.text();
			int iFailedUICnt=Integer.parseInt(FailedUICount);
			if (iFailedUICnt>0) {
				lstUIFailedSuite=getUIFailures(doc1);
			}
			resultdata.put("No of Failed", FailedUICount);
			elements1 = doc1.select("#charts-row > div:nth-child(1) > div > div:nth-child(4) > span:nth-child(2)");
			resultdata.put("No of Skipped", elements1.text());
			elements1 = doc1.select("#dashboard-view > div > div > div:nth-child(5) > div > div");
			resultdata.put("Execution Time", elements1.text());
			
			lstReportresult.add(resultdata);
		}
		
		//System.out.println("lstReportresult: "+lstReportresult);
		
		return lstReportresult;
	}
	
	/**
	 * Get Failures details from  UI Html report
	 * @return lstReportresult
	 */
	public static List<Map<String , String>> getUIFailures(Document uidoc) throws Exception {
		List<Map<String , String>> lstReportresult  = new ArrayList<Map<String,String>>();
		Map<String,String> resultdata = null;
		Elements elements = uidoc.select("#test-collection > li[status=fail]");
		for (Element element : elements) {
			Element FtElement=element.select("div.test-heading > span.test-name").first();
		    String Featurename=FtElement.childNode(0).toString();
		    if (Featurename.contains("Feature Regression"))
		    	Featurename = Featurename.replace("Feature Regression", "");
		    else if (Featurename.contains("Feature smoke"))
		    	Featurename = Featurename.replace("Feature smoke", "");
		    //System.out.println("Feature Node text :"+element.childNode(0).toString());
		    Elements elements2 = element.select("div > ul > li[status=fail]");
		    System.out.println("Failed TC Count: "+elements2.size());
		    for (Element element2 : elements2) {
		    	resultdata = new HashMap<String,String>();	
		    	resultdata.put("Feature", Featurename);
		    	Element elements3 = element2.select("div > h5").first();
		    	String Scenario=elements3.childNode(0).toString();
		    	if (Scenario.contains("Scenario :"))
		    		Scenario = Scenario.replace("Scenario :", "");
		    	//System.out.println("Scenario: "+Scenario);
		    	resultdata.put("Scenario", Scenario);
		    	Elements TotalStepselements = element2.select("div > div > table > tbody > tr[status=info]");
		    	int stepcount= TotalStepselements.size();
		    	resultdata.put("TotalStepCount", String.valueOf(stepcount));
		    	Elements elements4 = element2.select("div > div > table > tbody > tr[status=fail]>td[class=step-details]");
		    	int Failedstepcount= elements4.size();
		    	resultdata.put("FailedStepCount", String.valueOf(Failedstepcount));
		    	List<String> Steps = new ArrayList<String>();
		    	List<String> Actuals = new ArrayList<String>();
		    	int setpcount=1;
		    	for (Element element4 : elements4) {
		    		 Element trFailedSuite = element4.parent().previousElementSiblings().select("tr[status=info]>td[class=step-details]").first();
		    		 Steps.add(setpcount+"- "+trFailedSuite.text());
		    		 Actuals.add(setpcount+"- "+element4.text());
				    //System.out.println("Stepinfo :"+trFailedSuite.text());
				    //System.out.println("StepActuals :"+element4.text());
		    		 setpcount=setpcount+1;
		    	}
		    	resultdata.put("Steps", Steps.toString());
		    	resultdata.put("ActualSteps", Actuals.toString());
		    	
		    	//System.out.println("resultdata :"+resultdata);
		    	lstReportresult.add(resultdata);
		    }
		}
		
		//lstReportresult.add(resultdata);
		System.out.println("UI Report Errors: "+lstReportresult);
		
		return lstReportresult;
	}
	
	/**
	 * Get Failures details from  API Html report 
	 * @return lstReportresult
	 */
	public static List<Map<String , String>> getAPIFailures(Document APIdoc) throws Exception {
		List<Map<String , String>> lstReportresult  = new ArrayList<Map<String,String>>();
		Map<String,String> resultdata = null;
		resultdata = new HashMap<String,String>();
		Elements elements = APIdoc.select("#mysuitestab > tbody > tr[class*=testds] > td[bgcolor=red]");
		System.out.println("Els Size: "+elements.size());
		for (Element element : elements) {
			resultdata = new HashMap<String,String>();
		    //System.out.println("Elements :"+element.text());
		    Element trFailedEle=element.parent();
		    Element trFailedSuite = trFailedEle.previousElementSiblings().select("tr.tcsuite> td[bgcolor=red]").first();
		    Element trFailedSuiteEle=trFailedSuite.parent();
		    Elements tdFailedSuite = trFailedSuiteEle.select("td:nth-child(2)");
		    //System.out.println("TCSuiteID:"+tdFailedSuite.text());
		    resultdata.put("SuiteID", tdFailedSuite.text());
		    tdFailedSuite = trFailedSuiteEle.select("td:nth-child(4)");
		    //System.out.println("TCSuiteName:"+tdFailedSuite.text());
		    resultdata.put("SuiteName", tdFailedSuite.text());
		    tdFailedSuite = trFailedSuiteEle.select("td:nth-child(3)");
		    //System.out.println("TCSuiteDesc:"+tdFailedSuite.text());
		    resultdata.put("SuiteDesc", tdFailedSuite.text());
		    
		    Elements trFailedRecord = trFailedEle.select("td:nth-child(3)");
		    //System.out.println("TD : "+trFailedRecord.text());
		    resultdata.put("TestDesc", trFailedRecord.text());
		    trFailedRecord = trFailedEle.select("td:nth-child(4)");
		    //System.out.println("TD : "+trFailedRecord.text());
		    resultdata.put("TestRequestURL", trFailedRecord.text());
		    trFailedRecord = trFailedEle.select("td:nth-child(6)");
		    resultdata.put("TestActualStatus", trFailedRecord.text());
		    //System.out.println("TD : "+trFailedRecord.text());
		    
		    //System.out.println("resultdata: "+resultdata);
		    lstReportresult.add(resultdata);
		}
		System.out.println("lstReportresult: "+lstReportresult);
		return lstReportresult;
	}

}