package com.pauir.common.testDataTypes;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Testdata_Customers_Oauthtoken {

@SerializedName("tokenname")
@Expose
private String tokenname;
@SerializedName("clientid")
@Expose
private String clientid;
@SerializedName("clientsecret")
@Expose
private String clientsecret;
@SerializedName("tokenurl")
@Expose
private String tokenurl;
@SerializedName("scope")
@Expose
private String scope;
@SerializedName("granttype")
@Expose
private String granttype;

public String gettokenname() {
return tokenname;
}

public void settokenname(String tokenname) {
this.tokenname = tokenname;
}

public String getclientid() {
return clientid;
}

public void setclientid(String clientid) {
this.clientid = clientid;
}

public String getclientsecret() {
return clientsecret;
}

public void setclientsecret(String clientsecret) {
this.clientsecret = clientsecret;
}

public String gettokenurl() {
return tokenurl;
}

public void settokenurl(String tokenurl) {
this.tokenurl = tokenurl;
}

public String getscope() {
return scope;
}

public void setscope(String scope) {
this.scope = scope;
}

public String getgranttype() {
return granttype;
}

public void setgranttype(String granttype) {
this.granttype = granttype;
}

}