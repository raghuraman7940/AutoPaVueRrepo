package com.pauir.PageDefinitions.Admin;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.common.core.CommonFunctions;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class TestManagementPage {

	// Form List page objects
	public static String TestMgmt_Form = "xpath|//pa-test-management/ul/li/a[contains(text(),'Forms')]";
	public static String FormListPage_verification="xpath|.//h5[contains(text(),'Test Management')]";
	
	public static String TestMgmt_FormTab="xpath|//pa-test-management/ul/li/a[contains(text(),'Forms')]";
	public static String TestMgmt_TestAdminTab="xpath|//pa-test-management/ul/li/a[contains(text(),'Test Admins')]";
	public static String TestMgmt_TestTab="xpath|//pa-test-management/ul/li/a[contains(text(),'Tests')]";
	
	public static String FormListTable="xpath|//pa-test-management-forms-form-list//kendo-grid//table/thead";
	public static String TestAdminListTable="xpath|//pa-test-management-testadmin-list//kendo-grid//table/thead";
	public static String TestListTable="xpath|//pa-test-management-tests-test-list//kendo-grid//table/thead";
	public static String FormListPage_Title="xpath|//pa-test-management//pa-app-forms//h5";
	public static String TableRecords="xpath|//pa-test-management//kendo-grid//kendo-grid-list//table/tbody";
	
	public static String FormRowPresent = "xpath|//pa-test-management//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String FormDatagridHeaderRow = "xpath|//pa-test-management//kendo-grid//table/thead/tr/th";
	public static String FormList="xpath|.//kendo-grid//table/thead/tr[1]/th[1]";
	public static String FormListDropDpwn = "xpath|.//label[contains(@class,'k-checkbox-label') and contains(@for,'k-grid0-check')]";
	public static String SearchInputFilter = "xpath|//pa-test-management//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li[1]/a[contains(.,'Home')]";
	
	/**
	 * Function Name :- FormListPageObjects<br>
	 * Description :- To set Form List Page Objects locator.
	 * 
	 * @return By
	 */
	public By FormListPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	/**
	 * Function Name :- verifyTestMgmtPageNavigation<br>
	 * Description :- To verify Test Management Page Navigation.
	 *
	 */
	public boolean verifyTestMgmtPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(2000);
		if (WebDriverMain._isElementVisible(FormListPageObjects(TestMgmt_Form))) {
			return true;
		} else {
			return false;
		}		
	}
	
	/**
	 * Function Name :- clickFormTab<br>
	 * Description :- To clicks Form Tab.
	 *
	 */
	public boolean clickFormTab() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean flag = false;
		if (!WebDriverMain._isElementVisible(FormListPageObjects(FormListTable))) {
			flag=LeftClick._click(FormListPageObjects(TestMgmt_FormTab));
			CommonUtility._sleepForGivenTime(2000);
		}
		else
			flag = true;
		return flag;
	}
	
	/**
	 * Function Name :- clickTestTab<br>
	 * Description :- To clicks Test Tab.
	 *
	 */
	public boolean clickTestTab() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean flag = false;
		if (!WebDriverMain._isElementVisible(FormListPageObjects(TestListTable))) {
			flag=LeftClick._click(FormListPageObjects(TestMgmt_TestTab));
			CommonUtility._sleepForGivenTime(2000);
		}
		else
			flag = true;
		return flag;
	}
	
	/**
	 * Function Name :- clickTestAdminTab<br>
	 * Description :- To clicks Test Admin Tab.
	 *
	 */
	public boolean clickTestAdminTab() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean flag = false;
		if (!WebDriverMain._isElementVisible(FormListPageObjects(TestAdminListTable))) {
			flag=LeftClick._click(FormListPageObjects(TestMgmt_TestAdminTab));
			CommonUtility._sleepForGivenTime(2000);
		}
		else
			flag = true;
			
		return flag;
	}
	/**
	 * Function Name :- IsFormListTableExist<br>
	 * Description :- To verify Form List Table
	 *
	 */
	public boolean IsFormListTableExist() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementVisible(FormListPageObjects(FormListTable)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- IsTestAdminListTableExist<br>
	 * Description :- To verify Test Admin List Table
	 *
	 */
	public boolean IsTestAdminListTableExist() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementVisible(FormListPageObjects(TestAdminListTable)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- IsTestListTableExist<br>
	 * Description :- To verify for table List Table
	 *
	 */
	public boolean IsTestListTableExist() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementVisible(FormListPageObjects(TestListTable)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- waitforTableRecordsExist<br>
	 * Description :- To wait Test List Table
	 *
	 */
	public boolean waitforTableRecordsExist() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		WebDriverMain._waitForElementVisible(FormListPageObjects(TableRecords));
		if (WebDriverMain._isElementVisible(FormListPageObjects(TableRecords)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- Searchfill_SearchText<br>
	 * Description :- To Fill Name  in Form list Page.
	 *
	 */
	public boolean Searchfill_SearchText(String SearchText) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(FormListPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(FormListPageObjects(SearchInputFilter), SearchText);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Form Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(FormListPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		
		boolean flag = WebDriverMain._isElementVisible(FormListPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(FormListPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- clickHomeBreadCrum<br>
	 * Description :- To click Home BreadCrum.
	 *
	 */
	public boolean clickHomeBreadCrum() throws IOException{
		boolean flag=LeftClick._click(FormListPageObjects(Breadcrumb_Home));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clickonFormName<br>
	 * Description :- To click Form Name hyperlink.
	 *
	 */
	public boolean clickonFormName(String Formname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(FormListPageObjects(FormRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//div[contains(text(),'" + Formname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	

	/**
	 * Function Name :- getFormSearchresultsDetails<br>
	 * Description :- To get Form search results Details.
	 *
	 */
	public HashMap<String, String> getFormSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(FormListPageObjects(FormRowPresent));
		System.out.println("Forms Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-test-management//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(FormListPageObjects(FormDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	

	/**
	 * Function Name :- getFormColumnHeaderDetails<br>
	 * Description :- To get Form table Column headers.
	 *
	 */
	public List<String> getFormColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(FormListPageObjects(FormDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	
		//return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifyFormSearchresultsDetails<br>
	 * Description :- To verify Form search results Details.
	 *
	 */
	public List<String> verifyFormSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(FormListPageObjects(FormRowPresent));
		System.out.println("Form Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(FormListPageObjects(FormDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-test-management//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyFormSearchresultsCheckbox<br>
	 * Description :- To verify Form search results checkbox .
	 *
	 */
	public List<String> verifyFormSearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(FormListPageObjects(FormRowPresent));
		System.out.println("Form Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(FormListPageObjects(FormDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-test-management//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-test-management//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey("Form Code")) {
							String SearchOrg=MapDgOrgRec.get("Form Code");
							MapDgOrgdetails.add(SearchOrg);
						}
					}
					
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	
	/**
	 * Function Name :- verifyFormSearchresultsSorting<br>
	 * Description :- To verify Form search results sorting .
	 *
	 */
	public List<String> verifyFormSearchresultsSorting(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(FormListPageObjects(FormRowPresent));
		System.out.println("Form Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(FormListPageObjects(FormDatagridHeaderRow));
		if ((lstheaderRow.size() >= 1)&&(lstOrgrRow.size() >= 2)) {
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//pa-test-management//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						CommonFunctions.PleaseWaitAndLoadingMessage();
						objlocator =CommonUtility._getObjectLocator("xpath=//pa-test-management//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	/**
	 * Function Name :- verifyFormSearchresultsDetailsfromtext<br>
	 * Description :- To verify Form search results Details.
	 *
	 */
	public List<String> verifyFormSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(FormListPageObjects(FormRowPresent));
		System.out.println("Form Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(FormListPageObjects(FormDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
			
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-test-management//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgOrgRec.containsKey("Form Code")) {
						String SearchOrg=MapDgOrgRec.get("Form Code");
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
						
					}
					
					
				
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	

	/**
	 * Function Name :- SelectonFormCheckbox<br>
	 * Description :- To click Form name Checkbox.
	 *
	 */
	public boolean SelectonFormCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(FormListPageObjects(FormRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}

}