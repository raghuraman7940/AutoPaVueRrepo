package com.pauir.PageDefinitions.Common;
import java.io.File;
/**
 * Imports and Exports
 */
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pauir.common.core.CommonFunctions;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class ImportExport {
	CommonFunctions common;
	//pa-session-create//form

	public static String AddstudentForm="xpath|//pa-student-create//form";
	public static String EditstudentForm="xpath|//pa-student-edit//form";
	public static String AddstudentPageForm="xpath|//pa-student-edit//form";
	
	public static String Import_Tab = "xpath|//kendo-tabstrip/ul/li";
	public static String Import_TabActive = "xpath|//kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
	
	public static String LnkDownloadTemplate = "xpath|//pa-import/form//a[contains(text(),'here')]";
	public static String ImportPath = "xpath|//input[@id='dataFile']";
	public static String BtnSubmit="xpath|//button[contains(text(),'Submit')]";
	public static String BtnCancel="xpath|//button[contains(text(),'Cancel')]";
	
	public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
	public static String SuccessLink="xpath|//pa-alerts//div[@role='alert']/p/span//div/a";
	
	/**
	 * Function Name :- ImportExportPageObjects<br>
	 * Description :- To set Import Export page locator.
	 * 
	 * @return By
	 */
	public By ImportExportPageObjects(String byStrgylocValue)
	{
		 By by = null;
		 by=CommonUtility._getByLocator(byStrgylocValue);
		 return by;
	}

	/**
	 * Function Name :- SelectTabOption<br>
	 * Description :- Select the Tab options
	 * 
	 * @param TabOption
	 * @throws IOException
	 */
	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean iActiveflag=false;
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//kendo-tabstrip/ul/li/span[contains(text(),'"+TabOption+"')]");
		if (WebDriverMain._isElementPresent(objlocator)) {
			iActiveflag=VerifyActiveTab(TabOption);
			if (!iActiveflag) {
				LeftClick._click(objlocator);
				CommonUtility._sleepForGivenTime(1000);
				return true;
			}
			else
				return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- VerifyTabOption_isVisible<br>
	 * Description :- To verify Tab
	 * @throws IOException 
	 */
	public boolean VerifyTabOption_isVisible(String TabOption) throws Exception{
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//kendo-tabstrip/ul/li/span[contains(text(),'"+TabOption+"')]");
		if (WebDriverMain._isElementPresent(objlocator)) 
			return true;
		else
			return true;

	}
	
	/**
	 * Function Name :- VerifyActiveTab<br>
	 * Description :- To verify Active Tab
	 * @throws IOException 
	 */
	public boolean VerifyActiveTab(String ActiveTab) throws IOException{
		try {
			CommonUtility._scrollup();
			CommonUtility._sleepForGivenTime(500);
			String textSuccess=WebDriverMain._getTextFromElement(ImportExportPageObjects(Import_TabActive));
			if(textSuccess.toLowerCase().contains(ActiveTab.toLowerCase())){
				return true;
			}else{
				return false;
			}
		}
		catch(Exception e) {
			return false;
		}
	}
/**
 * Function Name :- verifyDownloadTemplate<br>
 * Description :- To click Download Template.
 *
 */
public boolean clickDownloadTemplate() throws IOException{
	boolean flag=false;
	try {
		CommonUtility._scrollup();	
		flag=LeftClick._click(ImportExportPageObjects(LnkDownloadTemplate));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(8000);
	 }
	 catch(Exception e) {
	 		return false;
	 }
	return flag;
}

/**
 * Function Name :- verifyDownloadTemplate<br>
 * Description :- To verify the Download Template.
 *
 */
public boolean verifyDownloadTemplate() throws IOException{
	if (WebDriverMain._isElementVisible(ImportExportPageObjects(LnkDownloadTemplate)))
		return true;
	else
		return false;
}

/**
 * Function Name :- SetImportFilePath<br>
 * Description :- To Set the File
 *
 */
public boolean SetImportFilePath(String FilePath) throws Exception {

	boolean flag = WebDriverMain._isElementVisible(ImportExportPageObjects(ImportPath));
	if (flag) {
		flag = TextBox._setTextBox(ImportExportPageObjects(ImportPath), FilePath);
		CommonUtility._sleepForGivenTime(200);
	}
	return flag;

}


/**
 * Function Name :- checkFileExist<br>
 * Description :- To check the File exist.
 *
 */
public boolean checkFileExist(String FilePath) throws Exception {
	try {
		File SchmFile = new File(FilePath);
		if (SchmFile.exists())
			return true;
	}
	catch(Exception e) {
		return false;
	}
	return false;
}

/**
 * Function Name :- ClickSubmitButton<br>
 * Description :- To click the Submit Button.
 *
 */
public boolean ClickSubmitButton() throws IOException{
	if (WebDriverMain._isElementVisible(ImportExportPageObjects(BtnSubmit))) {
		LeftClick._click(ImportExportPageObjects(BtnSubmit));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(2000);
		return true;
	}
	return false;
}

/**
 * Function Name :- SubmitButton_isVisible<br>
 * Description :- To verify Submit button is visible
 */
public boolean SubmitButton_isVisible() throws Exception{
	if (WebDriverMain._isElementVisible(ImportExportPageObjects(BtnSubmit)))
		return true;
	else
		return false;
}

/**
 * Function Name :- CancelButton_isVisible<br>
 * Description :- To verify Cancel button is visible
 */
public boolean CancelButton_isVisible() throws Exception{
	if (WebDriverMain._isElementVisible(ImportExportPageObjects(BtnCancel)))
		return true;
	else
		return false;

}

/**
 * Function Name :- ClickCancelButton<br>
 * Description :- To click the Cancel Button.
 *
 */
public void ClickCancelButton() throws IOException{
	CommonUtility._sleepForGivenTime(2000);
	LeftClick._click(ImportExportPageObjects(BtnCancel));
	CommonFunctions.PleaseWaitAndLoadingMessage();
}

/**
 * Function Name :- verifySuccessMessageExist<br>
 * Description :- To verify the SuccessMessage
 *
 */
public boolean verifySuccessMessageExist() throws IOException{
	if (WebDriverMain._isElementPresent(ImportExportPageObjects(Success_Message)))
		return true;
	else
		return false;
	}

/**
 * Function Name :- verifySuccessMessageExist<br>
 * Description :- To verify the SuccessMessage
 *
 */
public boolean verifySuccessMessage(String successmessage) throws IOException{
	String textSuccess=WebDriverMain._getTextFromElement(ImportExportPageObjects(Success_Message));
	if(textSuccess.contains(successmessage)){
		return true;
	}else{
		return false;
		}
	}

/**
 * Function Name :- GetSuccessMessage<br>
 * Description :- To get the SuccessMessage
 *
 */
public String GetSuccessMessage() throws IOException{
	String textSuccess=null;
	try {
	 textSuccess=WebDriverMain._getTextFromElement(ImportExportPageObjects(Success_Message));
	}
	catch(Exception e) {
		return null;
	}
	return textSuccess;
}

/**
 * Function Name :- Close_Alerts<br>
 * Description :- To close the Message
 *
 */
public boolean Close_Alerts() throws IOException{
	List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(ImportExportPageObjects(CloseAlerts));
	for (WebElement AlertEle : lstAlertsRow) {
		if (WebDriverMain._isElementClickable(AlertEle)) {
			AlertEle.click();
		}
	}
	return true;
}

/**
 * Function Name :- ClickSuccessLink<br>
 * Description :- To click the SuccessMessage hyperlink
 *
 */
public void ClickSuccessLink() throws Exception{
	LeftClick._click(ImportExportPageObjects(SuccessLink));
	common.PleaseWaitAndLoadingMessage();
	CommonUtility._sleepForGivenTime(6000);
}

/**
 * Function Name :- GetSuccessMessage<br>
 * Description :- To get the SuccessMessage
 *
 */
public String GetSuccesshyperlinks() throws IOException{
	String textSuccess=null;
	try {
	 textSuccess=WebDriverMain._getTextFromElement(ImportExportPageObjects(SuccessLink));
	}
	catch(Exception e) {
		return null;
	}
	return textSuccess;
}

/**
 * Function Name :- verifyExportButton_isVisible<br>
 * Description :- To verify the export hyperlink
 *
 */
public boolean verifyExportButton_isVisible(String ExportBtn) throws Exception{
	By objlocator = CommonUtility
			._getObjectLocator("xpath=//pa-grid-actions/button[contains(text(),'"+ExportBtn+"')]");
	if (WebDriverMain._isElementVisible(objlocator))
		return true;
	else
		return false;

}

/**
 * Function Name :- clickExportButton<br>
 * Description :- To click the Export button hyperlink
 *
 */
public boolean clickExportButton(String ExportBtn) throws IOException{	
	By objlocator = CommonUtility
			._getObjectLocator("xpath=//pa-grid-actions/button[contains(text(),'"+ExportBtn+"')]");
	if (WebDriverMain._isElementPresent(objlocator)) {
			LeftClick._click(objlocator);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
			return true;
	}
	return false;
}

}