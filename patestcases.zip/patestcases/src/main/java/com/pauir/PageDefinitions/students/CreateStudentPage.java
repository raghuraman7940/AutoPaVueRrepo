package com.pauir.PageDefinitions.students;
/**
 * CreateStudentPage
 */

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.testDataTypes.Sessionfield;
import com.pauir.common.testDataTypes.Studentfield;
import com.pauir.common.util.Constants;
import webdriver.main.CommonUtility;
import webdriver.main.KendoDropdown;
import webdriver.main.LeftClick;
import webdriver.main.SelectDropdown;
import webdriver.main.TextBox;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class CreateStudentPage {
	CommonFunctions common;
	//pa-session-create//form

	public static String AddstudentForm="xpath|//pa-student-create//form";
	public static String EditstudentForm="xpath|//pa-student-edit//form";
	public static String AddstudentPageForm="xpath|//pa-student-edit//form";
	public static String CreateStudent="xpath|//span[contains(text(),'Create Student')]";
	public static String EditStudent="xpath|//a/span[contains(text(),'Edit')]";
	public static String SaveStudent="xpath|//button[contains(text(),'Save')]";
	public static String CancelStudent="xpath|//button[contains(text(),'Cancel')]";
	public static String StudentCreatepage_Title="xpath|//pa-title/div[@class='breadcrumb-title']//h1";
	public static String StudentCreateTab_Title="xpath|//span[contains(text(),'Create Student')]";
	public static String Organizationdropdown="xpath|//kendo-multiselect[@id='enrollment']//kendo-searchbar/input";	
	public static String OrganizationdropdownSelected="xpath|//kendo-multiselect[@id='enrollment']//kendo-taglist/ul/li/span[1]";
	public static String OrganizationdropdownSelectedRemove="xpath|//kendo-multiselect[@id='enrollment']//kendo-taglist/ul/li/span[@class='k-select']/span[@class='k-icon k-i-close']";
	
	//Create Organization page objects
	public static String CreateStudentspage_Title="xpath|.//pa-breadcrumb//h1[contains(@class,'breadcrumb-title')]";
	public static String CreateStudentForm="xpath|//pa-org-edit//form";
	public static String Inline_Message="xpath|//div[@id='alerts']/div['alert']/span";
	public static String Error_Message="xpath|//div[@id='alerts']/div['alert']/span/h1";
	public static String Field_Control_Error_Message="xpath|//pa-field-messages//div[contains(@class,'form-control-error')]";
	public static String AddBtn="xpath|//button[contains(text(),'Add')]";
	public static String EditBtn="xpath|//a/span[contains(text(),'Edit')]";
	public static String CancelBtn="xpath|//button[contains(text(),'Cancel')]";
	public static String SaveBtn="xpath|//button[contains(text(),'Save')]";
	public static String popupdropdownlist="xpath|//kendo-popup/div/kendo-list/div/ul/li";
	public static String Proceedbtn="xpath|//button[contains(text(),'Proceed')]";
	public static String Resetbtn="xpath|//button[contains(text(),'Reset')]";
	public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
	public static String SuccessLink="xpath|//button[contains(text(),'View the new student now')]";
	public static String CreateStudentBtn="xpath|//button[contains(text(),'Create Student')]";
	
	public static String Students_Tab = "xpath|//pa-student-tabs/kendo-tabstrip/ul/li";
	public static String StudentList_Tab = "xpath|//pa-student-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Students List')]";
	public static String StudentImport_Tab = "xpath|//pa-student-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Import Students')]";
	public static String CreateStudent_Tab = "xpath|//pa-student-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Create Student')]";
	public static String StudentActive_Tab = "xpath|//pa-student-tabs/kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
	
	public static String stuAccomInclude="xpath|//input[@id='studentAccomChkbx']";
	public static String stuAccomhead="xpath|//pa-student-create//form//div[@class='card-header']//h2";
	public static String stuAccombody="xpath|//pa-student-create//form//div[@class='card-body']";
	
	public static String LnkDownloadTemplate = "xpath|//pa-import/form//a[contains(text(),'here')]";
	public static String ImportPath = "xpath|//input[@id='dataFile']";
	public static String BtnSubmit="xpath|//button[contains(text(),'Submit')]";
	public static String BtnCancel="xpath|//button[contains(text(),'Cancel')]";
	
	public static String StudDemographics_Title="xpath|//pa-student-create//form//h2[contains(text(),'Demographics')]";
	
	public static String studentinfoexpandup="xpath|//pa-student-create//div[contains(@class,'card-header')]//h2[contains(text(),'Student Info')]/../..//i[contains(@class,'fa-angle-up')]";
	public static String studentinfocollapsedown="xpath|//pa-student-create//div[contains(@class,'card-header')]//h2[contains(text(),'Student Info')]/../..//i[contains(@class,'fa-angle-down')]";
	public static String studentinfobody="xpath|//pa-student-create//div[contains(@class,'card-header')]//h2[contains(text(),'Student Info')]/../../../../div[contains(@class,'card-body')]";
	
	public static String studentdemographicsexpandup="xpath|//pa-student-create//div[contains(@class,'card-header')]//h2[contains(text(),'Demographics')]/../../..//i[contains(@class,'fa-angle-up')]";
	public static String studentdemographicscollapsedown="xpath|//pa-student-create//div[contains(@class,'card-header')]//h2[contains(text(),'Demographics')]/../../..//i[contains(@class,'fa-angle-down')]";
	public static String studentdemographicsbody="xpath|//pa-student-create//div[contains(@class,'card-header')]//h2[contains(text(),'Demographics')]/../../../../div[contains(@class,'card-body')]";
	
	public static String studentaccom="xpath|//pa-student-create//form//h2";
	public static String studentaccomexpandup="xpath|//pa-student-create//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]/../../..//i[contains(@class,'fa-angle-up')]";
	public static String studentaccomcollapsedown="xpath|//pa-student-create//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]/../../..//i[contains(@class,'fa-angle-down')]";
	public static String studentaccombody="xpath|//pa-student-create//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]/../../../../div[contains(@class,'card-body')]";
	
	
	/**
	 * Function Name :- CreateStudentPageObjects<br>
	 * Description :- To set Create Organization page locator.
	 * 
	 * @return By
	 */
	public By CreateStudentPageObjects(String byStrgylocValue)
	{
		 By by = null;
		 by=CommonUtility._getByLocator(byStrgylocValue);
		 return by;
	}

	/**
	 * Function Name :- verifyStudentCreateNavigation<br>
	 * Description :- To verify Student Create Page Navigation.
	 *
	 */
	public boolean verifyStudentCreateNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(2000);
		String PageTitle=WebDriverMain._getTextFromElement(CreateStudentPageObjects(StudentCreatepage_Title));
		String PageTitle1=WebDriverMain._getTextFromElement(CreateStudentPageObjects(StudentCreateTab_Title));
		if ((PageTitle.contains(Constants.StudentListPageTitle))||(PageTitle1.contains(Constants.StudentCreatePageTitle)))
			return true;
		else
			return false;
	}
	
	/**Function Name :- VerifyFieldLabel<br/>
	 * Description   :- VerifyFieldLabel
	 * @param fieldType Labelfor Label
	 * @return boolean
	 */
	public static boolean VerifyFieldLabel(String fieldType, String Label) {
		
		boolean flag =true;
		String strLocator=null;
		By objlocator =null;
		try{
//			if(Label.equalsIgnoreCase("Organization")){
//				strLocator="xpath=//pa-student-edit//form//h3[contains(text(),'Enrollment')]";
//				objlocator = CommonUtility._getObjectLocator(strLocator);
//				if(WebDriverMain._isElementVisible(objlocator)){
//					return true;
//				}
//				else {
//					return false;
//				}
//			}
//			else if(Label.equalsIgnoreCase("Sex")){
//				CommonUtility._scrollup();
//				
//			}
			//Set by locator object for label
			strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label
			flag=WebDriverMain._containText(objlocator,Label);
//			if (flag)
//				CommonUtility._scrollElement(element);
			
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	
	/**Function Name :- VerifyFieldLabel<br/>
	 * Description   :- VerifyFieldLabel
	 * @param fieldType Labelfor Label
	 * @return boolean
	 */
	public static boolean VerifyFieldLabel(String Label) {
		
		boolean flag =true;
		String strLocator=null;
		By objlocator =null;
		try{
			if(Label.equalsIgnoreCase("Organization")){
				strLocator="xpath=//pa-student-edit//form//h2[contains(text(),'ENROLLMENT')]";
				objlocator = CommonUtility._getObjectLocator(strLocator);
				if(WebDriverMain._isElementVisible(objlocator)){
					return true;
				}
				else {
					return false;
				}
			}
			//Set by locator object for label
			strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label
			flag=WebDriverMain._containText(objlocator,Label);
//			if (flag)
//				CommonUtility._scrollElement(element);
			
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	
	/**Function Name :- VerifyFieldLabel<br/>
	 * Description   :- VerifyFieldLabel
	 * @param fieldType Labelfor Label
	 * @return boolean
	 */
	public static boolean VerifyFieldLabelExist(String Label) {
		
		boolean flag =true;
		String strLocator=null;
		By objlocator =null;
		try{
			if(Label.equalsIgnoreCase("Organization")){
				strLocator="xpath=//pa-student-edit//form//h2[contains(text(),'ENROLLMENT')]";
				objlocator = CommonUtility._getObjectLocator(strLocator);
				if(WebDriverMain._isElementVisible(objlocator)){
					return true;
				}
				else {
					return false;
				}
			}
			//Set by locator object for label
			strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label is exist
			flag=WebDriverMain._isElementVisible(objlocator);
			
//			if (flag)
//				CommonUtility._scrollElement(element);
			
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	/**
	 * Function Name :- PageDataFieldValidation<br>
	 * Description :- To validate the student fields in Edit page
	 * @throws IOException 
	 */
	public HashMap<String,String> PageDataFieldValidation(List<Studentfield> studentfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean flag =false;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapStuFilledFields=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		By objcontrlerr=null;
		//Iterate each field values
		for (Studentfield field : studentfields)
			    
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			String sFieldminLength=field.getMinLength();
			String sFieldmaxLength=field.getMaxLength();
			String sFieldregex=field.getRegex();
			String sFieldErrorMsg=field.getFielderrormsg();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
					
					//Field Validation on textbox and list
					if(sFieldType.equalsIgnoreCase("textbox")){
					//Validate the field for MinLength, MaxLength, Regex
					flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					
					WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
					
					if (targetElement != null) {
						targetElement.sendKeys(Keys.BACK_SPACE);
						CommonUtility._sleepForGivenTime(500);
						
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						
					}
					
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("dropdownlist")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
					}
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("datepicker")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "03032019", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					}
					//Fill the Value base fieldtype, locator, value
					FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapStuFilledFields.put(sFieldLabel,FilledFieldValue);
				
			}
			}
		}
		return MapStuFilledFields;
	}
	
	/**
	 * Function Name :- VerifyAddstudentForm<br>
	 * Description :- To verify the Add student in student create page.
	 *
	 */
	public boolean VerifyAddstudentForm() throws IOException{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean isDisplayed=WebDriverMain._isElementPresent(CreateStudentPageObjects(AddstudentForm));
		if (!isDisplayed)
			isDisplayed=WebDriverMain._isElementPresent(CreateStudentPageObjects(AddstudentPageForm));
		//CommonUtility._sleepForGivenTime(2000);
		return isDisplayed;
		
	}

	
	/**
	 * Function Name :- VerifyeditstudentForm<br>
	 * Description :- To verify the Edit student in student create page.
	 *
	 */
	public boolean VerifyEditstudentForm() throws IOException{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean isDisplayed=WebDriverMain._isElementPresent(CreateStudentPageObjects(EditstudentForm));
		if (!isDisplayed)
			isDisplayed=WebDriverMain._isElementPresent(CreateStudentPageObjects(EditstudentForm));
		//CommonUtility._sleepForGivenTime(2000);
		return isDisplayed;
		
	}
	
	
	/**
	 * Function Name :- FillEidtStudentField<br>
	 * Description :- To fill Student field depends on field type  on student create page
	 * @throws IOException 
	 */
	public String FillStuContactField(Studentfield field, String FieldValue) throws IOException{

			
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		String sFieldValue=null;
		By objlocator=null;
		By objsublocator=null;
		//field values
		String sFieldName = field.getFieldname();
		String sFieldLocator = field.getObjectlocator();
		String sFieldType=field.getFieldtype();
		String sFieldLabel=field.getLabletodisplay();
		String sFieldrequired=field.getRequired();
		
		if (sFieldLabel.indexOf("^")>=0)
			sFieldLabel=Constants.mapCustomLabels.get(sFieldLabel.substring(1));
		
		//Set input value
		if(FieldValue.equalsIgnoreCase(null))
			sFieldValue =field.getFieldvalue();
		else
			sFieldValue=FieldValue;
		
		objsublocator=null;
		//Call to verify the field label 
		FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
		if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				

				//Field Validation on textbox and list
				if(sFieldType.equalsIgnoreCase("dropdownlist")){
					CommonUtility._sleepForGivenTime(1000);
				}
		}
		return FilledFieldValue;
	}
	
	
	/**
	 * Function Name :- studnetcrateButton_isVisible<br>
	 * Description :- To verify create student button is visible
	 */
	public boolean RemoveStudenEnrollment(String strValue,String ModalActionButton) throws Exception{
		boolean flag=false;
		By objlocator = null;
		String SelectString=null;
		int iLastOrg=1;
    	try{
    		//CommonUtility._scrolldown();
    		objlocator = CommonUtility._getObjectLocator("xpath=//span[@class='k-select']/span[@class='k-icon k-i-close']");
    		if (WebDriverMain._isElementVisible(CreateStudentPageObjects(Organizationdropdown))) {
    			List<WebElement> SelectedElements = WebDriverMain._getElementsWithWait(CreateStudentPageObjects(OrganizationdropdownSelected));
    			if ((SelectedElements != null)&&(SelectedElements.size() >= 1)) {
    				iLastOrg=SelectedElements.size()-1;
	        		for (int iCol = 0; iCol < SelectedElements.size(); iCol++) {
	        			WebElement SelectSingleEle=SelectedElements.get(iCol);
	        			SelectString=SelectSingleEle.getText();
	        			System.out.println("SelectString :"+SelectString);
	        			if (SelectString.contains(strValue)) {
	        				WebElement SelRemoveEle=SelectSingleEle.findElement(objlocator);
	        				if (SelRemoveEle != null) {
	        					SelRemoveEle.click();
	        					return true;
	        				}
	        				if (iCol==iLastOrg) {
	        					if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
	        						CommonFunctions.ConfirmPopupActionBtn(ModalActionButton);
	        						return true;
	        					}
	        				}
	        				//return flag;
	        			}
	        		}
	        	}
    		}
    	}catch(NoSuchElementException e){
    		//Log._logWarning("No options are selected.");
    		UMReporter.log(Status.FAIL, "Selected value is unable to retrive");
    	}
		
		return false;
	
	}
	
	
	/**
	 * Function Name :- RemoveAllStudentEnrollment<br>
	 * Description :- To remove all student enrollments
	 */
	public boolean RemoveAllStudentEnrollment() throws Exception{
		boolean flag=false;
    	try{
    		CommonUtility._scrolldown();
    		flag =KendoDropdown._removeMultiSelected(CreateStudentPageObjects(OrganizationdropdownSelectedRemove));
    	}
    	catch(NoSuchElementException e){
    		UMReporter.log(Status.FAIL, "Selected value is unable to retrive");
    	}
		return flag;
	}
	
	/**
	 * Function Name :- studnetcrateButton_isVisible<br>
	 * Description :- To verify create student button is visible
	 */
	public boolean StudentCreateButton_isVisible() throws Exception{
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(CreateStudentPageObjects(CreateStudent)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- StudentCancelButton_isVisible<br>
	 * Description :- To verify Cancel student button is visible
	 */
	public boolean StudentCancelButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(CreateStudentPageObjects(CancelStudent)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- clickCreateStudentButton<br>
	 * Description :- To click the Create Student Button.
	 *
	 */
	public void ClickCreateStudentButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		CommonUtility._scrollup();
		LeftClick._click(CreateStudentPageObjects(CreateStudentBtn));
		CommonUtility._sleepForGivenTime(2000);
		common.PleaseWaitAndLoadingMessage();
	}
	/**
	 * Function Name :- clickCancelStudentButton<br>
	 * Description :- To click the Cancel Student Button.
	 *
	 */
	public void ClickCancelStudentButton() throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		LeftClick._click(CreateStudentPageObjects(CancelStudent));
		common.PleaseWaitAndLoadingMessage();
	}
	
	/**
	 * Function Name :- clickSaveStudentButton<br>
	 * Description :- To click the Save Student Button.
	 *
	 */
	public void ClickSaveStudentButton() throws IOException{
		boolean flag=false;
		CommonUtility._scrolldown();
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(CreateStudentPageObjects(SaveStudent))) {
			flag=LeftClick._click(CreateStudentPageObjects(SaveStudent));
			common.PleaseWaitAndLoadingMessage();
			if ((flag)&&(CommonFunctions.VerifyConfirmPopupDisplayed())) {
				CommonFunctions.ConfirmPopupActionBtn("Confirm");
				common.PleaseWaitAndLoadingMessage();
			}
			CommonUtility._sleepForGivenTime(2000);
		}
	}
		
	/**
	 * Function Name :- clickEditStudentButton<br>
	 * Description :- To click the Edit Student Button.
	 *
	 */
	public void ClickEditStudentButton() throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
		WebDriverMain._waitForElementClickable(CreateStudentPageObjects(EditStudent));
		LeftClick._click(CreateStudentPageObjects(EditStudent));
		common.PleaseWaitAndLoadingMessage();
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify the Edit Student Button.
	 *
	 */
	public boolean EditButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(CreateStudentPageObjects(EditBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- StudentCreateButton_isEnabled<br>
	 * Description :- To verify Create Student Button is enabled
	 *
	 */
	public boolean StudentCreateButton_isEnabled() throws IOException{
		
		WebElement delete = WebDriverMain._getElementWithWait(CreateStudentPageObjects(CreateStudentBtn));
		String attributeText = delete.getAttribute("outerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- StudentCancelButton_isEnabled<br>
	 * Description :- To verify Cancel Button is enabled
	 *
	 */
	public boolean StudentCacncelButton_isEnabled() throws IOException{
		if (WebDriverMain._isElementClickable(CreateStudentPageObjects(CancelStudent)))
			return true;
		else
			return false;
	}
	
	
	
	
	/**
	 * Function Name :- StudentSaveButton_isEnabled<br>
	 * Description :- To verify Save Student Button is enabled
	 *
	 */
	public boolean StudentSaveButton_isEnabled() throws IOException{
		if (WebDriverMain._isElementClickable(CreateStudentPageObjects(SaveStudent)))
			return true;
		else
			return false;
	}

	
	/**
	 * Function Name :- StudentSaveButton_isVisible<br>
	 * Description :- To verify Save student button is visible
	 */
	public boolean StudentSaveButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(CreateStudentPageObjects(SaveStudent)))
			return true;
		else
			return false;
	
	}
	
	public void ClickProceedButton() throws Exception{
		LeftClick._click(CreateStudentPageObjects(Proceedbtn));
	}
	
	
	public void ClickCancelButton() throws Exception{
		LeftClick._click(CreateStudentPageObjects(CancelBtn));
	}
	
	public boolean StudentResetButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(CreateStudentPageObjects(Resetbtn)))
			return true;
		else
			return false;
	
	}
	
public boolean StudentResetButton_isEnabled() throws IOException{
		
		WebElement delete = WebDriverMain._getElementWithWait(CreateStudentPageObjects(Resetbtn));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
public boolean verifySuccessMessage(String successmessage) throws IOException{
	String textSuccess=WebDriverMain._getTextFromElement(CreateStudentPageObjects(Success_Message));
	if(textSuccess.contains(successmessage)){
		return true;
	}else{
		return false;
		}
	}

public String GetSuccessMessage() throws IOException{
	String textSuccess=null;
	try {
	 textSuccess=WebDriverMain._getTextFromElement(CreateStudentPageObjects(Success_Message));
	}
	catch(Exception e) {
		return null;
	}
	return textSuccess;
}

public boolean Close_Alerts() throws IOException{
	List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(CreateStudentPageObjects(CloseAlerts));
	for (WebElement AlertEle : lstAlertsRow) {
		if (WebDriverMain._isElementClickable(AlertEle)) {
			AlertEle.click();
		}
	}
	return true;
}

public void ClickSuccessLink() throws Exception{
	LeftClick._click(CreateStudentPageObjects(SuccessLink));
	common.PleaseWaitAndLoadingMessage();
	CommonUtility._sleepForGivenTime(6000);
}

public void ClickResetBtn() throws Exception{
	LeftClick._click(CreateStudentPageObjects(Resetbtn));
}

public void ClickCreateStudentTab() throws IOException{
	LeftClick._click(CreateStudentPageObjects(CreateStudent));
	common.PleaseWaitAndLoadingMessage();
	
}
public boolean studentProceedButton_isVisible() throws Exception{
	if (WebDriverMain._isElementVisible(CreateStudentPageObjects(Proceedbtn)))
		return true;
	else
		return false;

}

public boolean CreateStudentTab_isVisible() throws Exception{
	if (WebDriverMain._isElementVisible(CreateStudentPageObjects(CreateStudent_Tab)))
		return true;
	else
		return false;

}

/**
 * Function Name :- SelectTabOption<br>
 * Description :- Select the Tab options
 * 
 * @param TabOption
 * @throws IOException
 */
public boolean SelectTabOption(String TabOption) throws IOException {
	boolean iActiveflag=false;
	if (WebDriverMain._isElementPresent(CreateStudentPageObjects(Students_Tab))) {
		switch (TabOption.toLowerCase()) {
			case "student list":
				iActiveflag=VerifyActiveTab(TabOption);
				if (!iActiveflag) {
					LeftClick._click(CreateStudentPageObjects(StudentList_Tab));
					CommonUtility._sleepForGivenTime(1000);
					return true;
				}
				else
					return true;
			case "import students":
				iActiveflag=VerifyActiveTab(TabOption);
				if (!iActiveflag) {
					LeftClick._click(CreateStudentPageObjects(StudentImport_Tab));
					CommonUtility._sleepForGivenTime(1000);
					return true;
				}
				else
					return true;
				
			case "create student":
				iActiveflag=VerifyActiveTab(TabOption);
				if (!iActiveflag) {
					LeftClick._click(CreateStudentPageObjects(CreateStudent_Tab));
					CommonUtility._sleepForGivenTime(1000);
					return true;
				}
				else
					return true;
			default:
				LeftClick._click(CreateStudentPageObjects(StudentList_Tab));
				CommonUtility._sleepForGivenTime(1000);
				break;
		}
	}
	return false;
}

/**
 * Function Name :- VerifyActiveTab<br>
 * Description :- To verify Active Tab
 * @throws IOException 
 */
public boolean VerifyActiveTab(String ActiveTab) throws IOException{
	CommonUtility._scrollup();
	CommonUtility._sleepForGivenTime(1000);
	if (WebDriverMain._isElementPresent(CreateStudentPageObjects(StudentActive_Tab))) {
		String textSuccess=WebDriverMain._getTextFromElement(CreateStudentPageObjects(StudentActive_Tab));
		if(textSuccess.contains(ActiveTab))
			return true;
	}
	return false;
}

/**
 * Function Name :- StudentAccomInclude<br>
 * Description :- To Expand/Collapse StudentAccom.
 *
 */
public boolean StudentAccomInclude(String strValue) throws IOException{
	boolean flag=false;
	try {
		if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
			if (WebDriverMain._isElementPresent(CreateStudentPageObjects(stuAccomInclude))) {
				if (WebDriverMain._isElementVisible(CreateStudentPageObjects(stuAccombody)))
					return true;//Display Accom info if collapse
				else {
					flag = LeftClick.clickByJS(CreateStudentPageObjects(stuAccomInclude));
					//CommonUtility._sleepForGivenTime(2000);
					WebDriverMain._waitForElementVisible(CreateStudentPageObjects(stuAccombody));
					if (WebDriverMain._isElementVisible(CreateStudentPageObjects(stuAccombody)))
						return true;//Display Accom info if collapse
				}
			}
		}
		else {
			if (WebDriverMain._isElementPresent(CreateStudentPageObjects(stuAccomInclude))) {
				if (!WebDriverMain._isElementVisible(CreateStudentPageObjects(stuAccombody)))
					return true;//Not display session info if collapse
			}
			else if (WebDriverMain._isElementPresent(CreateStudentPageObjects(stuAccomInclude))){
				flag = LeftClick.clickByJS(CreateStudentPageObjects(stuAccomInclude));
				CommonUtility._sleepForGivenTime(1000);
				WebDriverMain._waitForElementVisible(CreateStudentPageObjects(stuAccombody));
				if (!WebDriverMain._isElementVisible(CreateStudentPageObjects(stuAccombody)))
					return true; //Not display session info if collapse
			}
		}
	 }
	 catch(Exception e) {
	 		return false;
	 }
	return flag;
}

/**
 * Function Name :- VerifyStudentAccommodationForm<br>
 * Description :- To verify the student accom in student create page.
 *
 */
public boolean VerifyStudentAccommodationForm() throws IOException{
	CommonFunctions.PleaseWaitAndLoadingMessage();
	boolean isDisplayed=WebDriverMain._isElementPresent(CreateStudentPageObjects(studentaccom));
	if (!isDisplayed)
		isDisplayed=WebDriverMain._isElementPresent(CreateStudentPageObjects(studentaccombody));
	return isDisplayed;
	
}

/**Function Name :- VerifyAccommodationsLabel<br/>
 * Description   :- VerifyAccommodationsLabel
 * @param fieldType Labelfor Accmodations
 * @return boolean
 */
public static boolean VerifyAccommodationsLabel(String Label) {
	
	boolean flag =true;
	String strLocator=null;
	By objlocator =null;
	try{
		//Set by locator object for label
		strLocator="xpath=//label[contains(text(),'"+Label+"')]";
		objlocator = CommonUtility._getObjectLocator(strLocator);
		if(WebDriverMain._isElementPresent(objlocator))
			flag =true;
		else
			flag =false;
	
	}catch(Exception e){
		return flag;
	}
	return flag;	
}

/**
 * Function Name :- FillAccommodationsField<br>
 * Description :- To fill Student Accommodations field depends on field type  on student create page
 * @throws IOException 
 */
public boolean FillAccommodationsField(String fieldname,String fieldsubject, String FieldValue) throws IOException{

	//Intialize Function variable
	boolean FilledFieldFalg =false;
	By objlocator=null;
	String strLocator=null;
	try{
		//null or blank value return
		if(FieldValue.equalsIgnoreCase(null)){
			return FilledFieldFalg;
		}
		strLocator="xpath=//label[contains(text(),'"+fieldname+"')]/following-sibling::div//strong[contains(text(),'"+fieldsubject+"')]/../following-sibling::div//input[@type='radio']";
		objlocator = CommonUtility._getObjectLocator(strLocator);
		//radio
		if(WebDriverMain._isElementPresent(objlocator)) {
			strLocator="xpath=//label[contains(text(),'"+fieldname+"')]/following-sibling::div//strong[contains(text(),'"+fieldsubject+"')]/../following-sibling::div//label[contains(text(),'"+FieldValue+"')]";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			FilledFieldFalg = LeftClick.clickByJS(objlocator);
		}
		else
		{
			//Text field
			strLocator="xpath=//label[contains(text(),'"+fieldname+"')]/following-sibling::div//strong[contains(text(),'"+fieldsubject+"')]/../following-sibling::div//input[@type='text']";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			if(WebDriverMain._isElementPresent(objlocator)) 
				FilledFieldFalg = TextBox._setTextBox(objlocator, FieldValue.trim());
		}
		
	}catch(NullPointerException nullE){
		return false;
	}
	catch(Exception e){
		return false;
	}
	
		
	
	return FilledFieldFalg;
}

/**
 * Function Name :- VerifyStudentDemographicsForm<br>
 * Description :- To verify the student demographics in student create page.
 *
 */
public boolean VerifyStudentDemographicsForm() throws IOException{
	CommonFunctions.PleaseWaitAndLoadingMessage();
	boolean isDisplayed=WebDriverMain._isElementPresent(CreateStudentPageObjects(StudDemographics_Title));
	return isDisplayed;
	
}

/**
 * Function Name :- FillDemographicsFields<br>
 * Description :- To fill Demographis fields depends on Customer demographics
 * @throws IOException 
 */
public HashMap<String,String> FillDemographicsFields(List <Map<String,Object>> LstCustDemo, String filltype) throws IOException{
	//Intialize Function variable
	String FilledFieldValue =null;
	String strLocator=null;
	boolean FieldLabelflag =false;
	HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
	By objlocator=null;
	By objsublocator=null;
	try {
		//Iterate each field values
		for (Map<String,Object> MapSetField: LstCustDemo)
		{
			String sFieldLocator = null;
			String sInputFieldType=null;
			String sFieldType=MapSetField.get("demographicType").toString();
			String sFieldLabel=MapSetField.get("demographicDisplayCode").toString();
			String sFieldValue=MapSetField.get("val").toString();
			String sFieldAllValues=MapSetField.get("customerDemographicValidValues").toString();
			objsublocator=null;
			System.out.println("DemographicsFields => "+sFieldLabel+" = "+sFieldValue);
			//Call to verify the field label 
			FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
				switch(sFieldType){
				case "MULTI_CHOICE":				
					//String Validvalues[]=(String[]) MapSetField.get("customerDemographicValidValues");
					List<String> Validvalues =(List<String>) MapSetField.get("customerDemographicValidValues");
					if (Validvalues.size()>5) {
						sFieldLocator="xpath=//h2[contains(text(),'Demographics')]/../../../../div[contains(@class,'card-body')]//div//label[contains(text(),'"+sFieldLabel+"')]/..//kendo-dropdownlist//span[@class='k-input']";
						objlocator = CommonUtility._getObjectLocator(sFieldLocator);
						sInputFieldType="dropdownlist";
					}
					else {
						sFieldLocator="xpath=//h2[contains(text(),'Demographics')]/../../../../div[contains(@class,'card-body')]//div//label[contains(text(),'"+sFieldLabel+"')]/..//span[contains(@class,'pa-radio')]/label[contains(text(),'"+sFieldValue+"')]";
						objlocator = CommonUtility._getObjectLocator(sFieldLocator);
						sInputFieldType="radio";
					}
					break;
				case "NUMERIC":				
					sFieldLocator="xpath=//h2[contains(text(),'Demographics')]/../../../../div[contains(@class,'card-body')]//div//label[contains(text(),'"+sFieldLabel+"')]/..//input[@type='text']";
					objlocator = CommonUtility._getObjectLocator(sFieldLocator);
					sInputFieldType="textbox";
					break;
				case "TEXT":				
					sFieldLocator="xpath=//h2[contains(text(),'Demographics')]/../../../../div[contains(@class,'card-body')]//div//label[contains(text(),'"+sFieldLabel+"')]/..//input[@type='text']";
					objlocator = CommonUtility._getObjectLocator(sFieldLocator);
					sInputFieldType="textbox";
					break;
				case "BOOLEAN":
					sFieldLocator="xpath=//h2[contains(text(),'Demographics')]/../../../../div[contains(@class,'card-body')]//div//label[contains(text(),'"+sFieldLabel+"')]/..//span[contains(@class,'pa-radio')]/label[contains(text(),'"+sFieldValue+"')]";
					objlocator = CommonUtility._getObjectLocator(sFieldLocator);
					sInputFieldType="radio";
					break;
				case "DATE":
					sFieldLocator="xpath=//h2[contains(text(),'Demographics')]/../../../../div[contains(@class,'card-body')]//div//label[contains(text(),'"+sFieldLabel+"')]/..//kendo-datepicker//kendo-dateinput//input";
					objlocator = CommonUtility._getObjectLocator(sFieldLocator);
					sInputFieldType="datepicker";
					break;
				}
				
			
			if (filltype.equalsIgnoreCase("required")){
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sInputFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				
			}
			//Provide input to all field 
			else {
				//radio
				if(sInputFieldType.contains("radio")) {
					if(WebDriverMain._isElementPresent(objlocator)) {
						boolean FilledFieldFalg = LeftClick.clickByJS(objlocator);
						if (FilledFieldFalg)
							FilledFieldValue=sFieldValue;
					}
						
				}
				else {
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sInputFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				CommonUtility._sleepForGivenTime(1000);
				
			}
			}
		}
	}
	catch(Exception e) {
		return MapFilledOrgsField;
	}
	return MapFilledOrgsField;
}

/**
 * Function Name :- StudentInfoExpand<br>
 * Description :- To Expand/Collapse this Student Info.
 *
 */
public boolean StudentInfoExpand(String strValue) throws IOException{
	boolean flag=false;
	try {
		if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
			if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentinfoexpandup))) {
				if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentinfobody)))
					return true;//Display session info if collapse
			}
			else if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentinfocollapsedown))){
				flag = LeftClick._click(CreateStudentPageObjects(studentinfocollapsedown));
				CommonUtility._sleepForGivenTime(1000);
				if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentinfobody)))
					return true;//Display session info if collapse
			}
		}
		else {
			if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentinfocollapsedown))) {
				if (!WebDriverMain._isElementVisible(CreateStudentPageObjects(studentinfobody)))
					return true;//Not display session info if collapse
			}
			else if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentinfoexpandup))){
				flag = LeftClick._click(CreateStudentPageObjects(studentinfoexpandup));
				CommonUtility._sleepForGivenTime(1000);
				if (!WebDriverMain._isElementVisible(CreateStudentPageObjects(studentinfobody)))
					return true; //Not display session info if collapse
			}
			
		}
				

	 }
	 catch(Exception e) {
	 		return false;
	 }
	return flag;
}

/**
 * Function Name :- StudentDemographicsBladeExpand<br>
 * Description :- To Expand/Collapse the Student Demographics Blade.
 *
 */
public boolean StudentDemographicsBladeExpand(String strValue) throws IOException{
	boolean flag=false;
	try {
		if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
			if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentdemographicsexpandup))) {
				if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentdemographicsbody)))
					return true;//Display session info if collapse
			}
			else if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentdemographicscollapsedown))){
				flag = LeftClick._click(CreateStudentPageObjects(studentdemographicscollapsedown));
				CommonUtility._sleepForGivenTime(1000);
				if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentdemographicsbody)))
					return true;//Display session info if collapse
			}
		}
		else {
			if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentdemographicscollapsedown))) {
				if (!WebDriverMain._isElementVisible(CreateStudentPageObjects(studentdemographicsbody)))
					return true;//Not display session info if collapse
			}
			else if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentdemographicsexpandup))){
				flag = LeftClick._click(CreateStudentPageObjects(studentdemographicsexpandup));
				CommonUtility._sleepForGivenTime(1000);
				if (!WebDriverMain._isElementVisible(CreateStudentPageObjects(studentdemographicsbody)))
					return true; //Not display session info if collapse
			}
			
		}
				

	 }
	 catch(Exception e) {
	 		return false;
	 }
	return flag;
}

/**
 * Function Name :- Verify_Student_Info_Blade<br>
 * Description :- To verify Student Infp info section is visible
 *
 */
public boolean Verify_Student_Info_Blade() throws IOException{
	if (WebDriverMain._isElementPresent(CreateStudentPageObjects(studentinfobody)))
		return true;
	else
		return false; 
}

/**
 * Function Name :- Verify_Student_Demographics_Blade<br>
 * Description :- To verify Student Demographics info section is visible
 *
 */
public boolean Verify_Student_Demographics_Blade() throws IOException{
	if (WebDriverMain._isElementPresent(CreateStudentPageObjects(studentdemographicsbody)))
		return true;
	else
		return false; 
}

/**
 * Function Name :- StudentAccommodationBladeExpand<br>
 * Description :- To Expand/Collapse the Student Accommodation Blade.
 *
 */
public boolean StudentAccommodationBladeExpand(String strValue) throws IOException{
	boolean flag=false;
	try {
		if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
			if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentaccomexpandup))) {
				if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentaccombody)))
					return true;//Display session info if collapse
			}
			else if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentaccomcollapsedown))){
				flag = LeftClick._click(CreateStudentPageObjects(studentaccomcollapsedown));
				CommonUtility._sleepForGivenTime(1000);
				if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentaccombody)))
					return true;//Display session info if collapse
			}
		}
		else {
			if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentaccomcollapsedown))) {
				if (!WebDriverMain._isElementVisible(CreateStudentPageObjects(studentaccombody)))
					return true;//Not display session info if collapse
			}
			else if (WebDriverMain._isElementVisible(CreateStudentPageObjects(studentaccomexpandup))){
				flag = LeftClick._click(CreateStudentPageObjects(studentaccomexpandup));
				CommonUtility._sleepForGivenTime(1000);
				if (!WebDriverMain._isElementVisible(CreateStudentPageObjects(studentaccombody)))
					return true; //Not display session info if collapse
			}
		}
	 }
	 catch(Exception e) {
	 		return false;
	}
	return flag;
}

/**
 * Function Name :- Verify_Student_Accommodations_Blade<br>
 * Description :- To verify StudentAccomodations info section is visible
 *
 */
public boolean Verify_Student_Accommodations_Blade() throws IOException{
	if (WebDriverMain._isElementPresent(CreateStudentPageObjects(studentaccombody)))
		return true;
	else
		return false; 
}


}
