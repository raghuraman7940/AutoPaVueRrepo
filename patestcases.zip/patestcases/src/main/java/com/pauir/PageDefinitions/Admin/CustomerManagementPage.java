package com.pauir.PageDefinitions.Admin;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class CustomerManagementPage {
	// Initialize
	CommonFunctions common;

	// Customer List page objects
	
	public static String CustListPage_verification="xpath|.//h5[contains(text(),'Customer Management')]";
	public static String CustMgmt_CustomerTab="xpath|//pa-customer-management/ul/li/a[contains(text(),'Customers')]";
	public static String CustListTable="xpath|//pa-customer-management-customers-customer-list//kendo-grid//table/thead";
	public static String CustListPage_Title="xpath|//pa-customer-management//pa-app-Customers//h5";
	public static String TableRecords="xpath|//pa-customer-management//kendo-grid//kendo-grid-list//table/tbody";
	
	public static String CustomerRowPresent = "xpath|//pa-customer-management//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String CustomerDatagridHeaderRow = "xpath|//pa-customer-management//kendo-grid//table/thead/tr/th";
	public static String SearchInputFilter = "xpath|//pa-customer-management//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li[1]/a[contains(.,'Home')]";
	
	/**
	 * Function Name :- CustListPageObjects<br>
	 * Description :- To set Customer List Page Objects locator.
	 * 
	 * @return By
	 */
	public By CustMgmtPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	/**
	 * Function Name :- verifyCustMgmtPageNavigation<br>
	 * Description :- To verify Test Management Page Navigation.
	 *
	 */
	public boolean verifyCustMgmtPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(2000);
		if (WebDriverMain._getTextFromElement(CustMgmtPageObjects(CustListPage_Title)).contains(Constants.CustomerManagementPageTitle)) {
			return true;
		} else {
			return false;
		}		
	}
	
	/**
	 * Function Name :- clickCustomerTab<br>
	 * Description :- To clicks Customer Tab.
	 *
	 */
	public boolean clickCustomerTab() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean flag = false;
		if (!WebDriverMain._isElementVisible(CustMgmtPageObjects(CustListTable))) {
			flag=LeftClick._click(CustMgmtPageObjects(CustMgmt_CustomerTab));
			CommonUtility._sleepForGivenTime(2000);
		}
		else
			flag = true;
		return flag;
	}
	
	/**
	 * Function Name :- IsCustListTableExist<br>
	 * Description :- To verify Customer List Table
	 *
	 */
	public boolean IsCustListTableExist() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementVisible(CustMgmtPageObjects(CustListTable)))
			return true;
		else
			return false;
	}
		
	/**
	 * Function Name :- waitforTableRecordsExist<br>
	 * Description :- To wait Test List Table
	 *
	 */
	public boolean waitforTableRecordsExist() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		WebDriverMain._waitForElementVisible(CustMgmtPageObjects(TableRecords));
		if (WebDriverMain._isElementVisible(CustMgmtPageObjects(TableRecords)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- Searchfill_SearchText<br>
	 * Description :- To Fill Name  in Customer list Page.
	 *
	 */
	public boolean Searchfill_SearchText(String SearchText) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(CustMgmtPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(CustMgmtPageObjects(SearchInputFilter), SearchText);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Customer Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(CustMgmtPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks Search icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		
		boolean flag = WebDriverMain._isElementVisible(CustMgmtPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(CustMgmtPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- clickHomeBreadCrum<br>
	 * Description :- To click Home BreadCrum.
	 *
	 */
	public boolean clickHomeBreadCrum() throws IOException{
		boolean flag=LeftClick._click(CustMgmtPageObjects(Breadcrumb_Home));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clickonCustomerName<br>
	 * Description :- To click Customer Name hyperlink.
	 *
	 */
	public boolean clickonCustomerName(String Customername) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(CustMgmtPageObjects(CustomerRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//div[contains(text(),'" + Customername + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	

	/**
	 * Function Name :- getCustomerSearchresultsDetails<br>
	 * Description :- To get Customer search results Details.
	 *
	 */
	public HashMap<String, String> getCustomerSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CustMgmtPageObjects(CustomerRowPresent));
		System.out.println("Customers Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-customer-management//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(CustMgmtPageObjects(CustomerDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	

	/**
	 * Function Name :- getCustomerColumnHeaderDetails<br>
	 * Description :- To get Customer table Column headers.
	 *
	 */
	public List<String> getCustomerColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(CustMgmtPageObjects(CustomerDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	
		//return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifyCustomerSearchresultsDetails<br>
	 * Description :- To verify Customer search results Details.
	 *
	 */
	public List<String> verifyCustomerSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CustMgmtPageObjects(CustomerRowPresent));
		System.out.println("Customer Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CustMgmtPageObjects(CustomerDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-customer-management//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyCustomerSearchresultsCheckbox<br>
	 * Description :- To verify Customer search results checkbox .
	 *
	 */
	public List<String> verifyCustomerSearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CustMgmtPageObjects(CustomerRowPresent));
		System.out.println("Customer Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CustMgmtPageObjects(CustomerDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-customer-management//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-customer-management//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey("Customer Name")) {
							String SearchOrg=MapDgOrgRec.get("Customer Name");
							MapDgOrgdetails.add(SearchOrg);
						}
					}
					
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	
	/**
	 * Function Name :- verifyCustomerSearchresultsSorting<br>
	 * Description :- To verify Customer search results sorting .
	 *
	 */
	public List<String> verifyCustomerSearchresultsSorting(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CustMgmtPageObjects(CustomerRowPresent));
		System.out.println("Customer Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CustMgmtPageObjects(CustomerDatagridHeaderRow));
		if ((lstheaderRow.size() >= 1)&&(lstOrgrRow.size() >= 2)) {
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//pa-customer-management//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						CommonFunctions.PleaseWaitAndLoadingMessage();
						objlocator =CommonUtility._getObjectLocator("xpath=//pa-customer-management//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	/**
	 * Function Name :- verifyCustomerSearchresultsDetailsfromtext<br>
	 * Description :- To verify Customer search results Details.
	 *
	 */
	public List<String> verifyCustomerSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CustMgmtPageObjects(CustomerRowPresent));
		System.out.println("Customer Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CustMgmtPageObjects(CustomerDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
			
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-customer-management//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgOrgRec.containsKey("Customer Name")) {
						String SearchOrg=MapDgOrgRec.get("Customer Name");
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
					}
					
					
				
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	

	/**
	 * Function Name :- SelectonCustomerCheckbox<br>
	 * Description :- To click Customer name Checkbox.
	 *
	 */
	public boolean SelectonCustomerCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(CustMgmtPageObjects(CustomerRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}

}