/**
 * Order Detail Page
 */
package com.pauir.PageDefinitions.orders;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.aventstack.extentreports.Status;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.KendoGrid;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class OrderDetailPage {
	// Order Details page objects
	public static String OrderDetailspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String btnEdit="xpath|.//a/span[contains(text(),'Edit')]";
	public static String OrderHeader_Section="xpath|//pa-order-edit//div[@class='card-header']";
	public static String Order_ItemList="xpath|//pa-order-edit//kendo-grid//kendo-grid-list";
	public static String Deletebtn="xpath|//button[contains(text(),'Delete Order')]";
	public static String Confirmbtn="xpath|//button[contains(text(),'Confirm')]";
	public static String Cancelbtn="xpath|//button[contains(text(),'Cancel')]";
	public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span/span";
	public static String Releasebtn="xpath|//button[contains(text(),'Release Order')]";
	
	// Item List page objects
	public static String ItemRowPresent = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String ItemDatagridHeaderRow = "xpath|//kendo-grid//table/thead/tr/th";
	public static String SearchInputFilter = "xpath|//pa-order-edit//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String SaveBtn="xpath|//button[contains(text(),'Save')]";
	public static String btnAddEditItem="xpath|//pa-grid-actions/button[contains(text(),'Add or Edit Items')]";
	public static String ItemList="xpath|//pa-order-add-item//kendo-grid//kendo-grid-list";
	public static String OrderDetailsBtn="xpath|//button[contains(text(),'Order Details')]";
	
	/**
	 * Function Name :- OrderDetailPageObjects<br>
	 * Description :- To set Order Details Page Objects locator.
	 * 
	 * @return By
	 */
	public By OrderDetailPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyOrderDetailsNavigation<br>
	 * Description :- To verify Order Detail Page Navigation.
	 *
	 */
	public boolean verifyOrderDetailsNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(OrderDetailPageObjects(OrderDetailspage_Title)).contains(Constants.OrderDetailPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify edit button is visible
	 *
	 */
	public boolean EditButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(OrderDetailPageObjects(btnEdit)))
			return true;
		else
			return false; 
	}

	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit button.
	 *
	 */
	public boolean clickEditButton() throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
		boolean flag=LeftClick._click(OrderDetailPageObjects(btnEdit));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}


	/**
	 * Function Name :- Verify_OrderHeader_Section<br>
	 * Description :- To verify Order Header section is visible
	 *
	 */
	public boolean Verify_OrderHeader_Section() throws IOException{
		if (WebDriverMain._isElementVisible(OrderDetailPageObjects(OrderHeader_Section)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_Order_ItemList<br>
	 * Description :- To verify Order Item List  is visible
	 *
	 */
	public boolean Verify_Order_ItemList() throws IOException{
		if (WebDriverMain._isElementVisible(OrderDetailPageObjects(Order_ItemList))) {
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(OrderDetailPageObjects(OrderHeader_Section));
			if (WebDriverMain._isElementVisible(elmStudentlst)) {
				CommonUtility._scrollElement(elmStudentlst);
				return true;
			}
			return true;
		}
		else
			return false; 
	}
	
	/**
	 * Function Name :- verifyViewOrderDetails<br>
	 * Description :- To verify the view Order details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewOrderDetails(HashMap<String,String> MapFilledField) throws IOException{
		boolean verifedFlag=true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            if (sFieldLabel.length()>1) {
	            
		            if (sFieldLabel.equalsIgnoreCase("updated by")) {
		            	sFieldLabel="Ordered By";
		            	String NumericSplit[] = sFieldValue.split(",");
						if (NumericSplit.length >= 1) 
							sFieldValue = NumericSplit[1].trim();
		            }
		            else if (sFieldLabel.equalsIgnoreCase("District")) {
		            	String NumericSplit[] = sFieldValue.split("\\(");
						if (NumericSplit.length >= 1) 
							sFieldValue = NumericSplit[0].trim();
		            }
		            else if (sFieldLabel.equalsIgnoreCase("School")) {
		            	sFieldLabel="Ordering School";
		            	String NumericSplit[] = sFieldValue.split("\\(");
						if (NumericSplit.length >= 1) 
							sFieldValue = NumericSplit[0].trim();
		            }	
		            else if  (sFieldLabel.toLowerCase().contains("order")) {
		            	sFieldLabel="";
		            }
		            //objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//label[contains(text(),'"+sFieldLabel+"')]");
					boolean isFieldLabelPresent=verifyOrderHeaderLabel(sFieldLabel);
					if (isFieldLabelPresent) {
						if(sFieldValue.length()>1) { 
							
							MapDgStuRec.put(sFieldLabel, sFieldValue);
							if (sFieldLabel.length()<1) 
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//h2[contains(text(),'"+sFieldValue+"')]");
							else
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//span[contains(text(),'"+sFieldValue+"')]");
							boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//p[contains(text(),'"+sFieldValue+"')]");
								isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
								if (!isFieldValuePresent) {
									verifedFlag=false;
									UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
								}
							}
						}
					}
	            }
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		
		if (verifedFlag)
			UMReporter.log(Status.PASS,"User have access to view the Class field value in Class details page :"+MapDgStuRec);
		return verifedFlag;
	}
	
	/**
	 * Function Name :- verifyOrderNum<br>
	 * Description :- To verify the Order number in  Order details Page 
	 * @throws IOException 
	 */	
	public boolean verifyOrderNum(String OrderName) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//h2[contains(text(),'"+OrderName+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	
	}
	/**
	 * Function Name :- verifyOrderHeaderLabel<br>
	 * Description :- To verify the label on Order Header details page.
	 *
	 */
	public boolean verifyOrderHeaderLabel(String labelmessage) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//label[contains(text(),'"+labelmessage+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else {
			objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//h2[contains(text(),'"+labelmessage+"')]");
			if (WebDriverMain._isElementVisible(objlocator))
				return true;
			else
				return false;
		}
	}
	
	
	
	/**
	 * Function Name :- Searchfill_Orders<br>
	 * Description :- To Fill order Name Filter in Order details Page.
	 *
	 */
	public boolean Searchfill_Orders(String Ordername) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(OrderDetailPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(OrderDetailPageObjects(SearchInputFilter), Ordername);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Order Details Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(OrderDetailPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks Search icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		
		boolean flag = WebDriverMain._isElementVisible(OrderDetailPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(OrderDetailPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	
	
	

	/**
	 * Function Name :- getItemssearchresultsDetails<br>
	 * Description :- To get Items search results Details.
	 *
	 */
	public HashMap<String, String> getItemssearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
		System.out.println("Order Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(OrderDetailPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex == Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-order-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(OrderDetailPageObjects(ItemDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	

	/**
	 * Function Name :- getItemsColumnHeaderDetails<br>
	 * Description :- To get Item list Col header Details.
	 *
	 */
	public List<String> getItemsColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}
	
	/**
	 * Function Name :- hasItemlist<br>
	 * Description :- To check item results Details.
	 *
	 */
	public boolean hasItemlist() throws IOException {
		boolean flag=false;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(OrderDetailPageObjects(NoRecords)))
				flag=true;	
		} 
		else
			flag=false;
		return flag;
	}
	/**
	 * Function Name :- verifyItemsearchresultsDetails<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public List<String> verifyItemsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
		System.out.println("Items Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(OrderDetailPageObjects(ItemDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	/**
	 * Function Name :- verifyItemGridPagination<br>
	 * Description :- To verify Item grid pagination.
	 *
	 */
	public int verifyItemGridPagination() throws IOException {
		int maxpage=0;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
		System.out.println("Items Row Count : " + lstOrgrRow.size());
		maxpage=KendoGrid.GetMaxPageNum();		
		System.out.println("Item Page : " + maxpage);
		if (maxpage>29) {
			//Select Next Page
			KendoGrid.SelectNextPage();
			lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
			System.out.println("Item Next Row Count : " + lstOrgrRow.size());
			//Select First Page
			KendoGrid.SelectFirstPage();
		}
		return maxpage;
	}
	
	
	
	
	/**
	 * Function Name :- verifyItemSearchresultsDetailsfromtext<br>
	 * Description :- To get Item search results Details.
	 *
	 */
	public List<String> verifyItemSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
		System.out.println("Item Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(OrderDetailPageObjects(ItemDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(OrderDetailPageObjects(NoRecords))){
			
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey(Constants.FDAOrderItemDes)) {
							String SearchOrg=MapDgOrgRec.get(Constants.FDAOrderItemDes);
							if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
								MapDgOrgdetails.add(SearchOrg);
						}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyClassSearchresultsDetailsfromtext<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public List<String> verifyClassSearchresultsDetailsfromlist(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(OrderDetailPageObjects(NoRecords))){
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td[2]");
						WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
						if (dataRec!=null) {
							String sDGStuName = dataRec.getText().trim();
							if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase()))
								MapDgOrgdetails.add(sDGStuName);
							//return MapDgOrgdetails;
						}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- SelectonItemCheckbox<br>
	 * Description :- To select item search results checkbox Details.
	 *
	 */
	public List<String> SelectonItemCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(OrderDetailPageObjects(ItemDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey(Constants.FDAOrderItemDes)) {
							String SearchOrg=MapDgOrgRec.get(Constants.FDAOrderItemDes);
								MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	
	
	
	/**
	 * Function Name :- SelectOrderItemRecord<br>
	 * Description :- To select Order Item results Details.
	 *
	 */
	public HashMap<String, String> SelectOrderItemRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
		System.out.println("Item Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(OrderDetailPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(OrderDetailPageObjects(ItemDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/button");
						WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
						if (tsElm!=null) {
							if (WebDriverMain._isElementClickable(tsElm)) {
								tsElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								return MapDgOrgRec;
							}
						}
						
							
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

	/**
	 * Function Name :- clickSaveButton<br>
	 * Description :- To click the Save Class button.
	 *
	 */
	public boolean clickSaveButton() throws IOException{
		
		//CommonUtility._scrollup();
		boolean flag=LeftClick._click(OrderDetailPageObjects(SaveBtn));
		CommonUtility._sleepForGivenTime(4000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- GetOrderPopupLabel<br>
	 * Description :- To get the pop up on Order Header details page.
	 *
	 */
	public String GetOrderPopupLabel(String labelmessage) throws IOException{
		String Content=null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-order-edit//div[contains(@class,'card-body')]//div[contains(@class,'btn-link')][contains(text(),'"+labelmessage+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			boolean flag=LeftClick._click(objlocator);
			CommonUtility._sleepForGivenTime(2000);
			Content=CommonFunctions.GetDailogContent1();
			CommonFunctions.CloseDialog();
			CommonUtility._sleepForGivenTime(1000);
			return Content;
		}
		else 
			return Content;
	}
	
	/**
	 * Function Name :- AddEditItemButton_isVisible<br>
	 * Description :- To verify AddEditItem button is visible
	 *
	 */
	public boolean AddEditItemButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(OrderDetailPageObjects(btnAddEditItem)))
			return true;
		else
			return false; 
	}

	/**
	 * Function Name :- clickAddEditItemButton<br>
	 * Description :- To click the AddEditItem button.
	 *
	 */
	public boolean clickAddEditItemButton() throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
		boolean flag=LeftClick._click(OrderDetailPageObjects(btnAddEditItem));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- verifyOrderItemsDetailsNavigation<br>
	 * Description :- To verify Order Items Detail Page Navigation.
	 *
	 */
	public boolean verifyOrderItemsDetailsNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(OrderDetailPageObjects(OrderDetailspage_Title)).contains(Constants.OrderItemsPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- Verify_ItemList<br>
	 * Description :- To verify Order Item List  is visible
	 *
	 */
	public boolean Verify_ItemList() throws IOException{
		if (WebDriverMain._isElementVisible(OrderDetailPageObjects(ItemList))) 
				return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- SetItemsQuantity<br>
	 * Description :- To set Items Quantity.
	 *
	 */
	public List<HashMap<String, String>> SetItemsQuantity(int rowindex, int Itemvalue) throws IOException {
		By objlocator, objlocator1 = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemRowPresent));
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(OrderDetailPageObjects(ItemDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			// if have Records
			if (!WebDriverMain._isElementVisible(OrderDetailPageObjects(NoRecords))) {
				MapDgdetails = new ArrayList<HashMap<String, String>>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/input[contains(@class,'order-item-count-textbox')]");
						WebElement chbxele = WebDriverMain._getElementWithWait(objlocator1);
						if (chbxele != null) {
							TextBox._setTextBox(objlocator1,Integer.toString(Itemvalue));
							CommonUtility._sleepForGivenTime(2000);
							objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								if (sDGColmnName.equalsIgnoreCase("Quantity"))
									sDGColmnValue=Integer.toString(Itemvalue);
								
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							MapDgdetails.add(MapDgOrgRec);
						}
					}
				}
				return MapDgdetails;
			}
		} else
			System.out.println("No record found");
		return MapDgdetails;
	}
	
	/**
	 * Function Name :- clickOrderDetailsButton<br>
	 * Description :- To click the Order Details button.
	 *
	 */
	public boolean clickOrderDetailsButton() throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
		boolean flag=LeftClick._click(OrderDetailPageObjects(OrderDetailsBtn));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
		
	/**
		 * Function Name :- clickDeleteOrderButton<br>
		 * Description :- To click the Delete Order button.
		 *
		 */
	public boolean clickDeleteOrderButton() throws IOException{
			CommonUtility._scrollup();
			CommonUtility._sleepForGivenTime(500);
			boolean flag=LeftClick._click(OrderDetailPageObjects(Deletebtn));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return flag;
	}

	/**
	 * Function Name :- clickConfirmButton<br>
	 * Description :- To click the Delete Order Confirm button.
	 *
	 */
public boolean clickConfirmButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		boolean flag=LeftClick._click(OrderDetailPageObjects(Confirmbtn));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
}

/**
 * Function Name :- clickCancelButton<br>
 * Description :- To click the Delete Order Cancel button.
 *
 */
public boolean clickCancelButton() throws IOException{
	CommonUtility._scrollup();
	CommonUtility._sleepForGivenTime(500);
	boolean flag=LeftClick._click(OrderDetailPageObjects(Cancelbtn));
	CommonFunctions.PleaseWaitAndLoadingMessage();
	return flag;
}


/**
 * Function Name :- Verify SuccessMessage<br>
 * Description :- To Verify Success Message
 * @throws IOException 
 */

public boolean Verify_SuccessMessage() throws IOException{
	CommonUtility._sleepForGivenTime(1000);
	if (WebDriverMain._isElementVisible(OrderDetailPageObjects(Success_Message))) 
			return true;
	else
		return false; 
}

public boolean clickReleaseOrderButton() throws IOException{
	CommonUtility._scrollup();
	CommonUtility._sleepForGivenTime(500);
	boolean flag=LeftClick._click(OrderDetailPageObjects(Releasebtn));
	CommonFunctions.PleaseWaitAndLoadingMessage();
	return flag;
}

}



