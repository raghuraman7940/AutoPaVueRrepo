package com.pauir.PageDefinitions.sessions;
/**
 * CreateSessionPage
 */

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.testDataTypes.Sessionfield;
import com.pauir.common.util.Constants;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class CreateSessionPage {
	CommonFunctions common;

		//Create Session page objects
		
		public static String CreateSessionspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
		public static String CreateSessionspage_SubTitle="xpath|//pa-session-create//form/div[1]//h3";
		public static String CreateSessionForm="xpath|//pa-session-create//form";
		public static String EditSessionForm="xpath|//pa-session-details-info//form";
		public static String Inline_Message="xpath|//div[@id='alerts']/p/palib-alert/div/span/div/div[2]";
		public static String Error_Message="xpath|//palib-alert//div[contains(@class,'col pa-alert-col')]";

		public static String Field_Error_Message="xpath|//pa-field-messages/div[@class='controls error']/div[@class='alert alert-danger pa-alert-field-error']";
		public static String Field_Control_Error_Message="xpath|//pa-field-messages//div[contains(@class,'form-control-error')]";
		public static String CreateSessionBtn="xpath|//button[contains(text(),'Create Session')]";
		public static String EditBtn="xpath|//button/span[contains(text(),'Edit')]";
		public static String CancelBtn="xpath|//button/span[contains(text(),'Cancel')]";
		public static String popupdropdownlist="xpath|//kendo-popup/div/kendo-list/div/ul/li";
		public static String lodingspinner="xpath|//pa-root/div[contains(@class,'d-flex')]";
		
		
	/**
	 * Function Name :- CreateSessionPageObjects<br>
	 * Description :- To set Create Session page locator.
	 * 
	 * @return By
	 */
	public By CreateSessionPageObjects(String byStrgylocValue)
	{
		 By by = null;
		 by=CommonUtility._getByLocator(byStrgylocValue);
		 return by;
	}

	/**
	 * Function Name :- verifySessionDetailsNavigation<br>
	 * Description :- To verify Session Detail Page Navigation.
	 *
	 */
	public boolean verifyCreateSessionPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(CreateSessionPageObjects(CreateSessionspage_SubTitle)).contains(Constants.CreateSessionPageTitle))
			return true;
		else
			return false;
	}
	
	
	/**
	 * Function Name :- VerifyCreateSessionForm<br>
	 * Description :- To verify the Create Session page form.
	 *
	 */
	public boolean VerifyCreateSessionForm() throws IOException{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean isDisplayed=WebDriverMain._isElementPresent(CreateSessionPageObjects(CreateSessionForm));
		//CommonUtility._sleepForGivenTime(2000);
		return isDisplayed;
		
	}
	
	/**
	 * Function Name :- CreateSessionButton_isVisible<br>
	 * Description :- To verify CreateSession button is visible
	 *
	 */
	public boolean CreateSessionButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateSessionPageObjects(CreateSessionBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- CreateSessionButton_isEnabled<br>
	 * Description :- To verify CreateSession button is enabled
	 *
	 */
	public boolean CreateSessionButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(CreateSessionPageObjects(CreateSessionBtn));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- clickCreateSessionButton<br>
	 * Description :- To click the Create Session button.
	 *
	 */
	public boolean clickCreateSessionButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		boolean flag=LeftClick._click(CreateSessionPageObjects(CreateSessionBtn));
		CommonUtility._sleepForGivenTime(2000);
		common.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- waitLoadingspinner_Invisible<br>
	 * Description :- To wait Loadingspinner is not visible
	 */
	public boolean waitLoadingspinner_Invisible() throws Exception{
		int timer=0;
		int maxtimer=20;
		while((WebDriverMain._isElementVisible(CreateSessionPageObjects(lodingspinner)))&&(timer<maxtimer))
		{
			CommonUtility._sleepForGivenTime(1000);
			timer=timer+1;
		}
		if (WebDriverMain._isElementVisible(CreateSessionPageObjects(lodingspinner)))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit button.
	 *
	 */
	public void clickEditButton() throws IOException{
		LeftClick._click(CreateSessionPageObjects(EditBtn));
		common.PleaseWaitAndLoadingMessage();
	}
	
	/**
	 * Function Name :- clickCancelButton<br>
	 * Description :- To Click the cancel button on Create Session page form.
	 *
	 */
	public void clickCancelButton() throws IOException{
		LeftClick._click(CreateSessionPageObjects(CancelBtn));
		common.PleaseWaitAndLoadingMessage();
	}
	
	/**
	 * Function Name :- verifySessionSuccessMessage<br>
	 * Description :- To verify the success message on Create Session page form.
	 *
	 */
	public boolean verifySessionSuccessMessage(String successmessage) throws IOException{
		String ActualText=WebDriverMain._getTextFromElement(CreateSessionPageObjects(Inline_Message));
		if(ActualText.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Function Name :- verifyFailureMessage<br>
	 * Description :- To verify the failure message on Create Session page form.
	 *
	 */
	public boolean verifyFailureMessage(String failuremessage) throws IOException{
		String text1=WebDriverMain._getTextFromElement(CreateSessionPageObjects(Inline_Message));
		if(text1.contains(failuremessage)){
			//Log._logInfo("Successfully Verify error message");
			return true;
		}else
			return false;
	}
	
	/**
	 * Function Name :- verifyErrorMessage<br>
	 * Description :- To verify the error message on Create Session page form.
	 *
	 */
	public boolean verifyErrorMessage(String FieldLabel) throws IOException{
		String ErrorText=WebDriverMain._getTextFromElement(CreateSessionPageObjects(Error_Message));
		if (ErrorText.length()>1) {
			System.out.println("Error Message: "+ErrorText);
			if(ErrorText.contains(Constants.CREATESESSIONFAILUREMESSAGE)){
				return true;
			}else
				UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" has the actual error message :" +ErrorText);
				return false;
		}
		else
		{
			UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" error mesage is not displayed");
		}
		return false;
	}

	/**
	 * Function Name :- verifyFieldErrorMessage<br>
	 * Description :- To verify the field error message on Create Session page form.
	 *
	 */
	public boolean verifyFieldErrorMessage(String FieldLabel, String failuremessage) throws IOException{
		String ErrorText=WebDriverMain._getTextFromElement(CreateSessionPageObjects(Field_Error_Message));
		if (ErrorText.length()>1) {
			System.out.println("Field Error Message: "+ErrorText);
			if(failuremessage.contains(ErrorText)){
				//UMReporter.log(Status.PASS, "The Field "+FieldLabel+" has the expected field error message :" +ErrorText);
				return true;
			}else
				UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" has the actual error message :" +ErrorText);
				return false;
		}
		else
		{
			UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" error mesage is not displayed");
		}
		return false;
	}
	
	
	/**
	 * Function Name :- verifyFieldControlErrorMessage<br>
	 * Description :- To verify the field control error message on Create Session page form.
	 *
	 */
	public boolean verifyFieldControlErrorMessage(String failuremessage) throws IOException{
		String ErrorText=WebDriverMain._getTextFromElement(CreateSessionPageObjects(Field_Control_Error_Message));
		System.out.println("Field Error Message: "+ErrorText);
		if(ErrorText.contains(failuremessage)){
			//Log._logInfo("Successfully Verify error message");
			UMReporter.log(Status.PASS, "The Field control error matched the expected error message :" +failuremessage);
			return true;
		}else
			return false;
	}
	
	/**
	 * Function Name :- FillSessionFields<br>
	 * Description :- To fill session fields depends on fieldtype  on create session page
	 * @throws IOException 
	 */
	public HashMap<String,String> FillSessionFields(List<Sessionfield> sessionfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		//Iterate each field values
		for (Sessionfield field : sessionfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
						//Fill the Value base fieldtype, locator, value
						FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				CommonUtility._sleepForGivenTime(1000);
				
			}
			}
		}
		return MapFilledOrgsField;
	}
	
	
	
	/**
	 * Function Name :- FillSessionField<br>
	 * Description :- To fill session field depends on fieldtype  on create session page
	 * @throws IOException 
	 */
	public String FillSessionField(Sessionfield field, String FieldValue) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		String sFieldValue=null;
		By objlocator=null;
		By objsublocator=null;
		//field values
		String sFieldName = field.getFieldname();
		String sFieldLocator = field.getObjectlocator();
		String sFieldType=field.getFieldtype();
		String sFieldLabel=field.getLabletodisplay();
		String sFieldrequired=field.getRequired();
		
		if (sFieldLabel.indexOf("^")>=0)
			sFieldLabel=Constants.mapCustomLabels.get(sFieldLabel.substring(1));
		
//		if(sFieldLabel.equalsIgnoreCase("TH"))
//			sFieldLabel="T";
//		else if (sFieldLabel.equalsIgnoreCase("SA"))
//			sFieldLabel="S";
		
		//Set input value
		if(FieldValue.equalsIgnoreCase(null))
			sFieldValue =field.getFieldvalue();
		else
			sFieldValue=FieldValue;
		
		objsublocator=null;
		//Call to verify the field label 
		FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
		if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				

				//Field Validation on textbox and list
				if(sFieldType.equalsIgnoreCase("dropdownlist")){
					CommonUtility._sleepForGivenTime(2000);
				}
		}
		return FilledFieldValue;
	}
	
	/**
	 * Function Name :- PageDataFieldValidation<br>
	 * Description :- To validate the Session fields  on create Session page
	 * @throws IOException 
	 */
	public HashMap<String,String> PageDataFieldValidation(List<Sessionfield> sessionfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean flag =false;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		By objcontrlerr=null;
		//Iterate each field values
		for (Sessionfield field : sessionfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			String sFieldminLength=field.getMinLength();
			String sFieldmaxLength=field.getMaxLength();
			String sFieldregex=field.getRegex();
			String sFieldErrorMsg=field.getFielderrormsg();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=CheckFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
					
					//Field Validation on textbox and list
					if(sFieldType.equalsIgnoreCase("textbox")){
					//Validate the field for MinLength, MaxLength, Regex
					flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					
					WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
					
					if (targetElement != null) {
						targetElement.sendKeys(Keys.BACK_SPACE);
						CommonUtility._sleepForGivenTime(500);
						
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						
					}
					
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("dropdownlist")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
					}
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("datepicker")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "03032019", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					}
					//Fill the Value base fieldtype, locator, value
					FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				
			}
			}
		}
		return MapFilledOrgsField;
	}
	


	/**
	 * Function Name :- VerifyRequiredFieldValidation<br>
	 * Description :- To verify the required fields  on create Session page
	 * @throws IOException 
	 */
	public boolean VerifyRequiredFieldValidation(List<Sessionfield> sessionfields) throws IOException{
		
		boolean flag =false;
		By objlocator=null;
		
		for (Sessionfield field : sessionfields)
		{
			String sFieldName = field.getFieldname();
			
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			//Provide input to mandatory fields only
			if (sFieldrequired.equalsIgnoreCase("true")) {
				//Set by locator object for label
				String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/../../../div[@class='form-control-error']";
				//Verify Organization have different label
				if (sFieldName.equalsIgnoreCase("organizations")){
					strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[@class='form-control-error']";
				}
				objlocator = CommonUtility._getObjectLocator(strLocator);
				//Verify the label
				flag=WebDriverMain._containText(objlocator,Constants.FIELDERROR);
				
			}
		}
		return flag;
	}
	
	
	/**
	 * Function Name :- VerifyFilledSessionsFields<br>
	 * Description :- To verify the Sessions fields  on create Session page
	 * @throws IOException 
	 */
	public boolean VerifyFilledSessionsFields(List<Sessionfield> sessionfields, HashMap<String,String> MapFilledUserField) throws IOException{
		
		//Intialize Function variable
		boolean flag =false;
		boolean FieldValueflag =false;
		boolean FieldLabelflag =false;
		By objlocator=null;
		By objModifiedlocator=null;
		By objsublocator=CreateSessionPageObjects(popupdropdownlist);
		
		//Iterate each field values
		for (Sessionfield field : sessionfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			if (MapFilledUserField.containsKey(sFieldLabel)){
				//Call to verify the field label 
				FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
				//Set by locator object from configuration
				String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
				if(strArrObjLocs.length==1){
					objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
					objModifiedlocator=objlocator;
				}
				else if(strArrObjLocs.length==2){
					objModifiedlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
					objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
				}
				
				//Fill the Value base fieldtype, locator, value
				FieldValueflag=common.FieldDataValidationswitchCase(sFieldType, objModifiedlocator,objsublocator, MapFilledUserField.get(sFieldLabel), sFieldLabel);
			
				if (FieldLabelflag&&FieldValueflag)
					flag=true;
				else
					UMReporter.log(Status.FAIL, "The field " +sFieldLabel+ "  value is not matched with provided input value :" +MapFilledUserField.get(sFieldLabel));
			}
			
		}
		return flag;
	}
	
	/**Function Name :- VerifyFieldLabel<br/>
	 * Description   :- VerifyFieldLabel
	 * @param fieldType Labelfor Label
	 * @return boolean
	 */
	public static boolean VerifyFieldLabel(String fieldType, String Label) {
		boolean flag =true;
		String strLocator=null;
		By objlocator =null;
		try{
			if(fieldType.equalsIgnoreCase("checkbox")){
				strLocator="xpath=//div[@formgroupname='daysOfTheWeekGroup']//span[contains(text(),'"+Label+"')]";
				objlocator = CommonUtility._getObjectLocator(strLocator);
				String strLabel=WebDriverMain._getTextFromElement(objlocator);
				if(strLabel.contains(Label)){
					return true;
				}
				else {
					UMReporter.log(Status.FAIL, "The Actual Text " +strLabel+ " is not matched with expected text " +Label);
					return false;
				}
			}
			else if(fieldType.equalsIgnoreCase("radio")){
				strLocator="xpath=//h3[contains(text(),'"+Label+"')]";
				objlocator = CommonUtility._getObjectLocator(strLocator);
				if (WebDriverMain._isElementPresent(objlocator)) {
					String strLabel=WebDriverMain._getTextFromElement(objlocator);
					if(strLabel.contains(Label))
						return true;
				}
			}
			//Set by locator object for label
			strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label
			flag=WebDriverMain._containText(objlocator,Label);
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	
	/**Function Name :- CheckFieldLabel<br/>
	 * Description   :- CheckFieldLabel
	 * @param fieldType Label for Label
	 * @return boolean
	 */
	public static boolean CheckFieldLabel(String fieldType, String Label) {
		
		boolean flag =true;
		String strLocator=null;
		By objlocator =null;
		try{
			if(fieldType.equalsIgnoreCase("checkbox")){
				strLocator="xpath=//div[@formgroupname='daysOfTheWeekGroup']//span[contains(text(),'"+Label+"')]";
				objlocator = CommonUtility._getObjectLocator(strLocator);
				String strLabel=WebDriverMain._getTextFromElement(objlocator);
				if(strLabel.contains(Label)){
					return true;
				}
				else {
					//UMReporter.log(Status.FAIL, "The Actual Text " +strLabel+ " is not matched with expected text " +Label);
					return false;
				}
			}
			//Set by locator object for label
			strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label
			flag=WebDriverMain._containText(objlocator,Label);
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	/**
	 * Function Name :- verifyViewOrgsDetails<br>
	 * Description :- To verify the view  Orgs details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewOrgsDetails(HashMap<String,String> MapFilledOrgField) throws IOException{
		boolean verifedFlag=true;
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledOrgField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            if (sFieldLabel.contains("Region Code")) {
	        		String strArrObjLocs[] = CommonUtility._split(sFieldValue," ");
	      			if(strArrObjLocs.length>1)				
	      				sFieldValue = strArrObjLocs[1];
		          
	            }
	            else if (sFieldLabel.contains("School Type")) {
	        		String strArrObjLocs[] = CommonUtility._split(sFieldValue," ");
	      			if(strArrObjLocs.length>1)				
	      				sFieldValue = strArrObjLocs[0].toLowerCase();
		          
	            }
	            objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//form//label[contains(text(),'"+sFieldLabel+"')]");
				boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
				if (isFieldLabelPresent) {
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//form//P[contains(text(),'"+sFieldValue+"')]");
					boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
					if (!isFieldValuePresent) {
						verifedFlag=false;
						UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
					}
				}
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		return verifedFlag;
	}
	
	/**
	 * Function Name :- VerifyEditSessionForm<br>
	 * Description :- To verify the Edit Session page form.
	 *
	 */
	public boolean VerifyEditSessionForm() throws IOException{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean isDisplayed=WebDriverMain._isElementPresent(CreateSessionPageObjects(EditSessionForm));
		//CommonUtility._sleepForGivenTime(2000);
		return isDisplayed;
		
	}

}
