/**
 * User Detail Page
 */
package com.pauir.PageDefinitions.users;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.home.Home;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class UserDetailPage {
	// Initialize
	Login login = new Login(WebDriverMain._getDriver());
	CommonFunctions common;
	Home home = new Home();

	// User Details page objects
	public static String UserRowPresent = "xpath|//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String UserDetailspage_Title="xpath|//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String UserInfo_Section="xpath|//pa-user-edit//div[@class='card-body']";
	public static String UserDatagridHeaderRow = "xpath|//pa-user-list//kendo-grid//table/thead/tr/th";
	public static String UserdetailsDatagridHeaderRow = "xpath|//pa-user-edit//kendo-grid//table/thead/tr/th";
	public static String UserLastUpdated="xpath|//pa-user-edit//span[contains(text(),'Last Modified')]";
	public static String EditUser="xpath|//pa-user-edit//a/span[contains(text(),'Edit')]";
	public static String SaveBtn="xpath|//button[contains(text(),'Save')]";
	public static String Breadcrumb_usermang = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Users')]";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	
	
		
	//
	/**
	 * Function Name :- UserDetailPageObjects<br>
	 * Description :- To set User Details Page Objects locator.
	 * 
	 * @return By
	 */
	public By UserDetailPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	
	
	/**
	 * Function Name :- clickonUserame<br>
	 * Description :- To click User Name filter.
	 *
	 */
	public boolean clickonUserame(String Username) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(UserDetailPageObjects(UserRowPresent));
		
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator("xpath=//td/div/button[contains(text(),'" + Username + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	
	/**
	 * Function Name :- verifyUserDetailsNavigation<br>
	 * Description :- To verify User Detail Page Navigation.
	 *
	 */
	public boolean verifyUserDetailsNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(UserDetailPageObjects(UserDetailspage_Title)).contains(Constants.UserDetailsPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- Verify_User_Info<br>
	 * Description :- To verify User info section is visible
	 *
	 */
	public boolean Verify_User_Info() throws IOException{
		if (WebDriverMain._isElementVisible(UserDetailPageObjects(UserInfo_Section)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- verifyUserLabel<br>
	 * Description :- To verify the label on User details page form.
	 *
	 */
	public boolean verifyUserLabel(String labelmessage) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-edit//label[contains(text(),'"+labelmessage+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- GetValueforUserLabel<br>
	 * Description :- To get the value for label on User details page form.
	 *
	 */
	public String GetValueforUserLabel(String labelmessage) throws IOException{
		String LabelValue=null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-edit//label[contains(text(),'"+labelmessage+"')]/./following-sibling::span");
		if (WebDriverMain._isElementVisible(objlocator)) {
			LabelValue=WebDriverMain._getTextFromElement(objlocator);
			return LabelValue;
		
		}
		return LabelValue;
	}
	
	/**
	 * Function Name :- getUsersearchresultsDetails<br>
	 * Description :- To get User search results Details.
	 *
	 */
	public HashMap<String, String> getusersearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(UserDetailPageObjects(UserRowPresent));
		System.out.println("User Row Count : " + lstUserrRow.size());
		if (lstUserrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(UserDetailPageObjects(UserDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	
	/**
	 * Function Name :- getuserdetailsColumnHeaderDetails<br>
	 * Description :- To get user Col header Details.
	 *
	 */
	public List<String> getUserdeailsColumnHeaderDetails() throws IOException {
//		CommonUtility._scrolldown();
		List<String> MapDgUserColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(UserDetailPageObjects(UserdetailsDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgUserColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgUserColHeader.add(sDGColmnName);
			}
		}
		return MapDgUserColHeader;
	}
	
	/**
	 * Function Name :- verifyLastUpdatedLabel<br>
	 * Description :- To verify the last updated on Org details page form.
	 *
	 */
	public String verifyLastUpdatedLabel() throws IOException{
		String LstUpdatedDate=null;
		if (WebDriverMain._isElementVisible(UserDetailPageObjects(UserLastUpdated))) {
			LstUpdatedDate=WebDriverMain._getTextFromElement(UserDetailPageObjects(UserLastUpdated));
			return LstUpdatedDate;
		}
		else
			return LstUpdatedDate;
	}
	/**
	 * Function Name :- UserEditButton_isVisible<br>
	 * Description :- To verify Edit user button is visible
	 */
	public boolean UserEditButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(UserDetailPageObjects(EditUser)))
			return true;
		else
			return false;
	
	}
	
	
	/**
	 * Function Name :- UserEditButton_isEnabled<br>
	 * Description :- To verify User Edit button is enabled
	 *
	 */
	public boolean EditUserButton_isEnabled() throws IOException{
		
		WebElement delete = WebDriverMain._getElementWithWait(UserDetailPageObjects(EditUser));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
		
	}
	
	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit User button.
	 *
	 */
	public boolean clickEditButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(UserDetailPageObjects(EditUser));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit User button.
	 *
	 */
	public boolean clickSaveButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(UserDetailPageObjects(SaveBtn));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}

	/**
	 * Function Name :- clickManageUserBreadCrum<br>
	 * Description :- To click Manage User BreadCrum.
	 *
	 */
	public boolean clickUserMgmtBreadCrum() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			WebDriverMain._isElementVisible(UserDetailPageObjects(Breadcrumb_usermang));
			flag=LeftClick._click(UserDetailPageObjects(Breadcrumb_usermang));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(500);
			
			
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	/**
	 * Function Name :- verifyViewUserDetails<br>
	 * Description :- To verify the view  User details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewUserDetails(HashMap<String,String> MapFilledField) throws IOException{
		boolean verifedFlag=true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            
	            if (sFieldLabel.length()>1) {
		            objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-edit//label[contains(text(),'"+sFieldLabel+"')]");
					boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if(sFieldValue.length()>1) { 
							
							MapDgStuRec.put(sFieldLabel, sFieldValue);
							if (sFieldLabel.length()<1) 
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-edit//h2[contains(text(),'"+sFieldValue+"')]");
							else
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-edit//span[contains(text(),'"+sFieldValue+"')]");
							boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								verifedFlag=false;
								UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
							}
						}
					}
	            }
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		
		if (verifedFlag)
			UMReporter.log(Status.PASS,"User have access to View User field value in User details page :"+MapDgStuRec);
		return verifedFlag;
	}
	
	
	
	/**
	 * Function Name :- verifyUserName<br>
	 * Description :- To verify the User name in  Student details Page 
	 * @throws IOException 
	 */	
	public boolean verifyUserName(String UserName) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-edit//h2[contains(text(),'"+ UserName +"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- verifyUserName<br>
	 * Description :- To verify the User name in  Student details Page 
	 * @throws IOException 
	 */	
	public boolean verifyUserName(String FirstName,String LastName) throws IOException{
		By objlocatorFN = CommonUtility._getObjectLocator("xpath=//pa-user-edit//h2[contains(text(),'"+ FirstName +"')]");
		By objlocatorLN = CommonUtility._getObjectLocator("xpath=//pa-user-edit//h2[contains(text(),'"+ LastName +"')]");
		String str=WebDriverMain._getTextFromElement(objlocatorFN);
		System.out.println("Username FN :"+str);
		str=WebDriverMain._getTextFromElement(objlocatorLN);
		System.out.println("Username LN:"+str);
		if ((WebDriverMain._isElementVisible(objlocatorFN))&&(WebDriverMain._isElementVisible(objlocatorLN))) {
			return true;
		}
		else
			return false;
	
	}
	
	/**
	 * Function Name :- Selectuserlist<br>
	 * Description :- To select User search results Details.
	 *
	 */
	public HashMap<String, String> Selectuserlist() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(UserDetailPageObjects(UserRowPresent));
		System.out.println("User Row Count : " + lstUserrRow.size());
		if (lstUserrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(UserDetailPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(UserDetailPageObjects(UserDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						objlocator =  CommonUtility
								._getObjectLocator("xpath=//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td//button");
						WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
						if (WebDriverMain._isElementClickable(tsElm)) {
							tsElm.click();
							CommonFunctions.PleaseWaitAndLoadingMessage();
							return MapDgOrgRec;
						}
						return MapDgOrgRec;
					}
				}
			}
			else
				System.out.println("No record found");
		}
		else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	

}
