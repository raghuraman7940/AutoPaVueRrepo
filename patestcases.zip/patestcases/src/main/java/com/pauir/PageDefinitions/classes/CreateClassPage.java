package com.pauir.PageDefinitions.classes;
/**
 * CreateClassPage
 */

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.testDataTypes.Classfield;
import com.pauir.common.util.Constants;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class CreateClassPage {
	CommonFunctions common;

	//Create Class page objects
	public static String CreateClassspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String CreateClassForm="xpath|//pa-class-info//form";
	public static String Inline_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String Error_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String Field_Control_Error_Message="xpath|//pa-field-messages//div[contains(@class,'form-control-error')]";
	public static String CreateBtn="xpath|//button[contains(text(),'Create Class')]";
	public static String EditBtn="xpath|//button[contains(text(),'Edit')]";
	public static String CancelBtn="xpath|//button[contains(text(),'Cancel')]";
	public static String SaveBtn="xpath|//button[contains(text(),'Save')]";
	public static String popupdropdownlist="xpath|//kendo-popup/div/kendo-list/div/ul/li";
	
	/**
	 * Function Name :- CreateClassPageObjects<br>
	 * Description :- To set Create Class page locator.
	 * 
	 * @return By
	 */
	public By CreateClassPageObjects(String byStrgylocValue)
	{
		 By by = null;
		 by=CommonUtility._getByLocator(byStrgylocValue);
		 return by;
	}

	/**
	 * Function Name :- verifyClassDetailsNavigation<br>
	 * Description :- To verify Class Detail Page Navigation.
	 *
	 */
	public boolean verifyCreateClassPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(CreateClassPageObjects(CreateClassspage_Title)).contains(Constants.CreateClassPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- VerifyCreateClassForm<br>
	 * Description :- To verify the Create Class page form.
	 *
	 */
	public boolean VerifyCreateClassForm() throws IOException{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean isDisplayed=WebDriverMain._isElementPresent(CreateClassPageObjects(CreateClassForm));
		//CommonUtility._sleepForGivenTime(2000);
		return isDisplayed;
		
	}
	
	/**
	 * Function Name :- CreateClassButton_isVisible<br>
	 * Description :- To verify CreateClass button is visible
	 *
	 */
	public boolean CreateClassButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateClassPageObjects(CreateBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- CreateClassButton_isEnabled<br>
	 * Description :- To verify CreateClass button is enabled
	 *
	 */
	public boolean CreateClassButton_isEnabled() throws IOException
	{
		WebElement btnelm = WebDriverMain._getElementWithWait(CreateClassPageObjects(CreateBtn));
		String attributeText = btnelm.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- clickCreateClassButton<br>
	 * Description :- To click the Create Class button.
	 *
	 */
	public void clickCreateClassButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(CreateClassPageObjects(CreateBtn));
		CommonUtility._sleepForGivenTime(2000);
		common.PleaseWaitAndLoadingMessage();
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify Edit button is visible
	 *
	 */
	public boolean EditButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateClassPageObjects(EditBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- EditButton_isEnabled<br>
	 * Description :- To verify CreateClass button is enabled
	 *
	 */
	public boolean EditButton_isEnabled() throws IOException
	{
		WebElement btnelm = WebDriverMain._getElementWithWait(CreateClassPageObjects(EditBtn));
		String attributeText = btnelm.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- SaveButton_isVisible<br>
	 * Description :- To verify Save button is visible
	 *
	 */
	public boolean SaveButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateClassPageObjects(SaveBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- SaveButton_isEnabled<br>
	 * Description :- To verify CreateClass button is enabled
	 *
	 */
	public boolean SaveButton_isEnabled() throws IOException
	{
		WebElement btnelm = WebDriverMain._getElementWithWait(CreateClassPageObjects(SaveBtn));
		String attributeText = btnelm.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickSaveButton<br>
	 * Description :- To click the Save Class button.
	 *
	 */
	public boolean clickSaveButton() throws IOException{
		
		CommonUtility._scrollup();
		boolean flag=LeftClick._click(CreateClassPageObjects(SaveBtn));
		CommonUtility._sleepForGivenTime(4000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- CancelButton_isVisible<br>
	 * Description :- To verify Cancel button is visible
	 *
	 */
	public boolean CancelButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(CreateClassPageObjects(CancelBtn)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit button.
	 *
	 */
	public boolean clickEditButton() throws IOException{
		boolean flag=LeftClick._click(CreateClassPageObjects(EditBtn));
		common.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- clickCancelButton<br>
	 * Description :- To Click the cancel button on Create Class page form.
	 *
	 */
	public boolean clickCancelButton() throws IOException{
		boolean flag=LeftClick._click(CreateClassPageObjects(CancelBtn));
		common.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- verifyClassSuccessMessage<br>
	 * Description :- To verify the success message on Create Class page form.
	 *
	 */
	public boolean verifyClassSuccessMessage(String successmessage) throws IOException{
		String ActualText=WebDriverMain._getTextFromElement(CreateClassPageObjects(Inline_Message));
		if(ActualText.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Function Name :- verifyFailureMessage<br>
	 * Description :- To verify the failure message on Create Class page form.
	 *
	 */
	public boolean verifyFailureMessage(String failuremessage) throws IOException{
		String text1=WebDriverMain._getTextFromElement(CreateClassPageObjects(Inline_Message));
		if(text1.contains(failuremessage)){
			//Log._logInfo("Successfully Verify error message");
			return true;
		}else
			return false;
	}
	
	/**
	 * Function Name :- verifyErrorMessage<br>
	 * Description :- To verify the error message on Create Class page form.
	 *
	 */
	public boolean verifyErrorMessage(String FieldLabel) throws IOException{
		String ErrorText=WebDriverMain._getTextFromElement(CreateClassPageObjects(Error_Message));
		if (ErrorText.length()>1) {
			System.out.println("Error Message: "+ErrorText);
			if(ErrorText.contains(Constants.CREATECLASSFAILUREMESSAGE)){
				return true;
			}else
				UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" has the actual error message :" +ErrorText);
				return false;
		}
		else
		{
			UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" error mesage is not displayed");
		}
		return false;
	}
	
	/**
	 * Function Name :- verifyFieldControlErrorMessage<br>
	 * Description :- To verify the field control error message on Create Class page form.
	 *
	 */
	public boolean verifyFieldControlErrorMessage(String failuremessage) throws IOException{
		String ErrorText=WebDriverMain._getTextFromElement(CreateClassPageObjects(Field_Control_Error_Message));
		System.out.println("Field Error Message: "+ErrorText);
		if(ErrorText.contains(failuremessage)){
			//Log._logInfo("Successfully Verify error message");
			UMReporter.log(Status.PASS, "The Field control error matched the expected error message :" +failuremessage);
			return true;
		}else
			return false;
	}
	
	/**
	 * Function Name :- FillClassFields<br>
	 * Description :- To fill Class fields depends on fieldtype  on create Class page
	 * @throws IOException 
	 */
	public HashMap<String,String> FillClassFields(List<Classfield> Classfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		//Iterate each field values
		for (Classfield field : Classfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
						//Fill the Value base fieldtype, locator, value
						FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				CommonUtility._sleepForGivenTime(1000);
				
			}
			}
		}
		return MapFilledOrgsField;
	}
	
	
	
	/**
	 * Function Name :- FillClassField<br>
	 * Description :- To fill Class field depends on fieldtype  on create Class page
	 * @throws IOException 
	 */
	public String FillClassField(Classfield field, String FieldValue) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		String sFieldValue=null;
		By objlocator=null;
		By objsublocator=null;
		//field values
		String sFieldName = field.getFieldname();
		String sFieldLocator = field.getObjectlocator();
		String sFieldType=field.getFieldtype();
		String sFieldLabel=field.getLabletodisplay();
		String sFieldrequired=field.getRequired();
		//Set input value
		if(FieldValue.equalsIgnoreCase(null))
			sFieldValue =field.getFieldvalue();
		else
			sFieldValue=FieldValue;
		
		objsublocator=null;
		//Call to verify the field label 
		FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
		if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			
			//Wait for Teacher Field
			if(sFieldLabel.equalsIgnoreCase("Teacher(s)"))
				CommonUtility._sleepForGivenTime(3000);
			
			//Fill the Value base fieldtype, locator, value
			FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			
			//Field Validation on textbox and list
			if(sFieldType.equalsIgnoreCase("dropdownlist"))
				CommonUtility._sleepForGivenTime(3000);
		}
		return FilledFieldValue;
	}
	
	/**
	 * Function Name :- PageDataFieldValidation<br>
	 * Description :- To validate the Class fields  on create Class page
	 * @throws IOException 
	 */
	public HashMap<String,String> PageDataFieldValidation(List<Classfield> Classfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean flag =false;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		By objcontrlerr=null;
		//Iterate each field values
		for (Classfield field : Classfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			String sFieldminLength=field.getMinLength();
			String sFieldmaxLength=field.getMaxLength();
			String sFieldregex=field.getRegex();
			String sFieldErrorMsg=field.getFielderrormsg();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=CheckFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
					
					//Field Validation on textbox and list
					if(sFieldType.equalsIgnoreCase("textbox")){
					//Validate the field for MinLength, MaxLength, Regex
					flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					
					WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
					
					if (targetElement != null) {
						targetElement.sendKeys(Keys.BACK_SPACE);
						CommonUtility._sleepForGivenTime(500);
						
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						
					}
					
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("dropdownlist")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						//flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
					}
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("datepicker")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "03032019", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					}
					//Fill the Value base fieldtype, locator, value
					FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				
				//Field Validation on textbox and list
				if(sFieldType.equalsIgnoreCase("textbox")){
				//Validate the field for MinLength, MaxLength, Regex
				flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
				
				WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
				
				if (targetElement != null) {
					targetElement.sendKeys(Keys.BACK_SPACE);
					CommonUtility._sleepForGivenTime(500);
					
					}
					//Set by locator object for label
					String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
					objcontrlerr = CommonUtility._getObjectLocator(strLocator);
					//Verify the label
					flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
					
				}
				
				//Field Validation on textbox and list
				else if(sFieldType.equalsIgnoreCase("dropdownlist")){
					
					CommonUtility._sleepForGivenTime(1000);
					//Validate the field for MinLength, MaxLength, Regex
					flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					
					objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
					WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
					if (targetElement1 != null) {
						targetElement1.click();
						CommonUtility._sleepForGivenTime(500);
					}
					//Set by locator object for label
					String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
					objcontrlerr = CommonUtility._getObjectLocator(strLocator);
					//Verify the label
					//flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
				}
				//Field Validation on textbox and list
				else if(sFieldType.equalsIgnoreCase("datepicker")){
					
					CommonUtility._sleepForGivenTime(1000);
					//Validate the field for MinLength, MaxLength, Regex
					flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "04042019", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					
					if(sFieldName.equalsIgnoreCase("StartDate")) {
						clickSaveButton();
						verifyErrorMessage(sFieldLabel);
					}
				}
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				
			}
			}
		}
		return MapFilledOrgsField;
	}
	


	/**
	 * Function Name :- VerifyRequiredFieldValidation<br>
	 * Description :- To verify the required fields  on create Class page
	 * @throws IOException 
	 */
	public boolean VerifyRequiredFieldValidation(List<Classfield> Classfields) throws IOException{
		
		boolean flag =false;
		By objlocator=null;
		
		for (Classfield field : Classfields)
		{
			String sFieldName = field.getFieldname();
			
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			//Provide input to mandatory fields only
			if (sFieldrequired.equalsIgnoreCase("true")) {
				//Set by locator object for label
				String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/../../../div[@class='form-control-error']";
				//Verify Organization have different label
				if (sFieldName.equalsIgnoreCase("organizations")){
					strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[@class='form-control-error']";
				}
				objlocator = CommonUtility._getObjectLocator(strLocator);
				//Verify the label
				flag=WebDriverMain._containText(objlocator,Constants.FIELDERROR);
				
			}
		}
		return flag;
	}
	
	
	/**
	 * Function Name :- VerifyFilledClasssFields<br>
	 * Description :- To verify the Classs fields  on create Class page
	 * @throws IOException 
	 */
	public boolean VerifyFilledClasssFields(List<Classfield> Classfields, HashMap<String,String> MapFilledUserField) throws IOException{
		
		//Intialize Function variable
		boolean flag =false;
		boolean FieldValueflag =false;
		boolean FieldLabelflag =false;
		By objlocator=null;
		By objModifiedlocator=null;
		By objsublocator=CreateClassPageObjects(popupdropdownlist);
		
		//Iterate each field values
		for (Classfield field : Classfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			if (MapFilledUserField.containsKey(sFieldLabel)){
				//Call to verify the field label 
				FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
				//Set by locator object from configuration
				String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
				if(strArrObjLocs.length==1){
					objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
					objModifiedlocator=objlocator;
				}
				else if(strArrObjLocs.length==2){
					objModifiedlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
					objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
				}
				
				//Fill the Value base fieldtype, locator, value
				FieldValueflag=common.FieldDataValidationswitchCase(sFieldType, objModifiedlocator,objsublocator, MapFilledUserField.get(sFieldLabel), sFieldLabel);
			
				if (FieldLabelflag&&FieldValueflag)
					flag=true;
				else
					UMReporter.log(Status.FAIL, "The field " +sFieldLabel+ "  value is not matched with provided input value :" +MapFilledUserField.get(sFieldLabel));
			}
			
		}
		return flag;
	}
	
	/**Function Name :- VerifyFieldLabel<br/>
	 * Description   :- VerifyFieldLabel
	 * @param fieldType Labelfor Label
	 * @return boolean
	 */
	public static boolean VerifyFieldLabel(String fieldType, String Label) {
		
		boolean flag =true;
		try{
			
			//Set by locator object for label
			String strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			By objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label
			flag=WebDriverMain._containText(objlocator,Label);
			
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	/**Function Name :- CheckFieldLabel<br/>
	 * Description   :- CheckFieldLabel
	 * @param fieldType,Label
	 * @return boolean
	 */
	public static boolean CheckFieldLabel(String fieldType, String Label) {
		
		boolean flag =false;
		try{
			
			//Set by locator object for label
			String strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			By objlocator = CommonUtility._getObjectLocator(strLocator);
			String ActualText=WebDriverMain._getTextFromElement(objlocator);
			if(ActualText.contains(Label)){
				return true;
			}
			
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	
	/**
	 * Function Name :- verifyViewOrgsDetails<br>
	 * Description :- To verify the view  Orgs details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewOrgsDetails(HashMap<String,String> MapFilledOrgField) throws IOException{
		boolean verifedFlag=true;
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledOrgField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            if (sFieldLabel.contains("Region Code")) {
	        		String strArrObjLocs[] = CommonUtility._split(sFieldValue," ");
	      			if(strArrObjLocs.length>1)				
	      				sFieldValue = strArrObjLocs[1];
		          
	            }
	            else if (sFieldLabel.contains("School Type")) {
	        		String strArrObjLocs[] = CommonUtility._split(sFieldValue," ");
	      			if(strArrObjLocs.length>1)				
	      				sFieldValue = strArrObjLocs[0].toLowerCase();
		          
	            }
	            objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//form//label[contains(text(),'"+sFieldLabel+"')]");
				boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
				if (isFieldLabelPresent) {
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//form//P[contains(text(),'"+sFieldValue+"')]");
					boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
					if (!isFieldValuePresent) {
						verifedFlag=false;
						UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
					}
				}
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		return verifedFlag;
	}

}
