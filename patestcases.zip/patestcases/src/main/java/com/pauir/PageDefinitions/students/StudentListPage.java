/**
 * StudentListPage
 */
package com.pauir.PageDefinitions.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.pauir.PageDefinitions.home.Home;
import webdriver.main.CommonUtility;
import webdriver.main.KendoGrid;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class StudentListPage {
	// Initialize
	Login login = new Login(WebDriverMain._getDriver());
	CommonFunctions common;
	Home home = new Home();

	// Student List page objects
	public static String StudentListpage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String CreateOrg="xpath|.//button[@id='createOrg']";
	public static String DeleteOrg="xpath|.//button[@id='deleteOrg']";
	public static String StuRowPresent = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String StuDatagridHeaderRow = "xpath|//kendo-grid//table/thead/tr/th";
	public static String StuList="xpath|.//kendo-grid//table/thead/tr[1]/th[1]";
	public static String TableRecords="xpath|//kendo-grid//kendo-grid-list//table/tbody";
	public static String Name="xpath|.//palib-grid-column-sort[contains(text(),'Name')]";
	public static String Code="xpath|.//palib-grid-column-sort[contains(text(),'Code')]";
	public static String Type="xpath|.//palib-grid-column-sort[contains(text(),'Type')]";
	public static String ParentOrg="xpath|.//palib-grid-column-sort[contains(text(),'Parent Organization')]";
	public static String Participating="xpath|.//palib-grid-column-sort[contains(text(),'Participating')]";
	public static String OrgListDropDpwn = "xpath|.//label[contains(@class,'k-checkbox-label') and contains(@for,'k-grid0-check')]";
	public static String SearchInputFilter = "xpath|//input[@placeholder=\"Search\"]";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li[1]/a[contains(.,'home')]";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String Morelink= "xpath|//pa-session-add-students//button[contains(text(),'More')]";
	public static String AccommodationListDialogbox_Title="xpath|//div[contains(@class,'k-window-title k-dialog-title')]";
	public static String closeButton ="xpath|//*[@class=\"k-icon k-i-x\"]";
	public static String btnMergeStudent="xpath|//pa-grid-actions/button[contains(text(),'Merge Students')]";
	public static String btnDeleteStudent="xpath|//pa-grid-actions/button[contains(text(),'Delete Students')]";
	public static String Progressbar="xpath|//pa-progress-bar/kendo-dialog/div[contains(@class,'k-dialog')]";

		
	/**
	 * Function Name :- StudentListPageObjects<br>
	 * Description :- To set Student Lists Page Objects locator.
	 * 
	 * @return By
	 */
	public By StudentListPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyStudentListNavigation<br>
	 * Description :- To verify Student List Page Navigation.
	 *
	 */
	public boolean verifyStudentListNavigation() throws IOException {
	//	CommonUtility._sleepForGivenTime(5000);
		if (WebDriverMain._getTextFromElement(StudentListPageObjects(StudentListpage_Title)).contains(Constants.StudentListPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- Searchfill_StudName<br>
	 * Description :- To Fill Name Filter in Student Page.
	 *
	 */
	public boolean Searchfill_StudName(String Studname) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(StudentListPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(StudentListPageObjects(SearchInputFilter), Studname);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;
	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Organization Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(StudentListPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(500);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 * @throws Exception 
	 *
	 */
	public boolean clicksearchicon() throws Exception {
		boolean flag = WebDriverMain._isElementVisible(StudentListPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(StudentListPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonFunctions.waitUntilLoadingSpinner(10);
		}
		return flag;
	}
	
	/**
	 * Function Name :- clickManageOrganizationsBreadCrum<br>
	 * Description :- To click Manage Organizations BreadCrum.
	 *
	 */
	public boolean clickHomeBreadCrum() throws IOException{
		boolean flag=LeftClick._click(StudentListPageObjects(Breadcrumb_Home));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- waitforTableRecordsExist<br>
	 * Description :- To wait Table list to load
	 *
	 */
	public boolean waitforTableRecordsExist() throws IOException {
		//WebDriverMain._waitForElementVisible(StudentListPageObjects(TableRecords));
		if (WebDriverMain._isElementVisible(StudentListPageObjects(TableRecords)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- getStudsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public boolean hasStudentRecords() throws IOException {
		if (!WebDriverMain._isElementVisible(StudentListPageObjects(NoRecords))) {
			return true;
		}
		return false;
	}
		

	/**
	 * Function Name :- getStudsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public HashMap<String, String> getStudsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	
	/**
	 * Function Name :- getPermanentStudsearchresultsDetails<br>
	 * Description :- To select Student details in search results checkbox Details.
	 *
	 */
	public HashMap<String, String> getPermanentStudsNotTempid(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
				System.out.println("Sess Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementVisible(StudentListPageObjects(NoRecords))) {
						MapDgOrgRec = new HashMap<String, String>();
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
								String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
								if (!sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
									if (rowindex >= selectcnt) {
										//Select Matched Session
										objlocator = CommonUtility
												._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
														+ Irow + "]/td");
										List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
										
										for (int iCol1 = 0; iCol1 < dataRec.size(); iCol1++) {
											String sDGColmnName1 = lstheaderRow.get(iCol1).getText();
											String sDGColmnValue1 = dataRec.get(iCol1).getText();
											MapDgOrgRec.put(sDGColmnName1, sDGColmnValue1);
										}
										selectcnt=selectcnt+1;
										return MapDgOrgRec;
									}
								}	
						}
				}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgRec;
	}
	
	
	
	/**
	 * Function Name :- getTempStudsearchresultsDetails<br>
	 * Description :- To select Student details in search results Details.
	 *
	 */
	public HashMap<String, String> getTempStudsearchresultsDetails(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
				System.out.println("Sess Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementVisible(StudentListPageObjects(NoRecords))) {
						MapDgOrgRec = new HashMap<String, String>();
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
								String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
								if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
									if (rowindex >= selectcnt) {
										//Select Matched Session
										objlocator = CommonUtility
												._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
														+ Irow + "]/td");
										List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
										
										for (int iCol1 = 0; iCol1 < dataRec.size(); iCol1++) {
											String sDGColmnName1 = lstheaderRow.get(iCol1).getText();
											String sDGColmnValue1 = dataRec.get(iCol1).getText();
											MapDgOrgRec.put(sDGColmnName1, sDGColmnValue1);
										}
										selectcnt=selectcnt+1;
										return MapDgOrgRec;
									}
								}	
						}
				}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgRec;
	}
	
	

	/**
	 * Function Name :- getStuColumnHeaderDetails<br>
	 * Description :- To get Students Col header Details.
	 *
	 */
	public List<String> getStuColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifyStusearchresultsDetails<br>
	 * Description :- To get Students search results Details.
	 *
	 */
	public List<String> verifyStusearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyStuGridPagination<br>
	 * Description :- To verify Students grid pagination.
	 *
	 */
	public int verifyStuGridPagination() throws IOException {
		int maxpage=0;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		maxpage=KendoGrid.GetShowingMaxItems();		
		System.out.println("Stu Page : " + maxpage);
		if (maxpage>29) {
			//Select Next Page
			KendoGrid.SelectNextPage();
			waitforTableRecordsExist();
			lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
			System.out.println("Stu Next Row Count : " + lstOrgrRow.size());
			//Select First Page
			KendoGrid.SelectPreviousPage();
			waitforTableRecordsExist();
		}
		return maxpage;
	}
	
	
	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> verifyStusearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.FDStudID))) {
							String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.FDStudID);
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	
	/**
	 * Function Name :- verifyStuGridHyperlinks<br>
	 * Description :- To verify Students results hyperlink Details.
	 *
	 */
	public List<String> verifyStuGridHyperlinks(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/button[contains(@class,'btn-link')]");

					if (WebDriverMain._isElementPresent(objlocator1)) {
						if (rowindex >= Irow) {
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.FDStudID))) {
								String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.FDStudID);
								MapDgOrgdetails.add(SearchOrg);
							}
						}
					}
				}
				return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyStuGridNoHyperlinks<br>
	 * Description :- To verify Students results not hyperlink Details.
	 *
	 */
	public List<String> verifyStuGridNoHyperlinks(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/button[contains(@class,'btn-link')]");
//					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (!WebDriverMain._isElementPresent(objlocator1)) {
						if (rowindex >= Irow) {
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.FDStudID))) {
								String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.FDStudID);
								MapDgOrgdetails.add(SearchOrg);
							}
						}
					}
				}
				return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	/**
	 * Function Name :- verifyStudSearchresultsDetailsfromtext<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public List<String> verifyStudSearchresultsDetailsfromtext(int rowindex,String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(StudentListPageObjects(NoRecords))) {
				MapDgOrgdetails=new ArrayList<String>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						if (rowindex >= Irow) {
							objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.FDStudID))) {
								String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.FDStudID);
								if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
									MapDgOrgdetails.add(SearchOrg);
							}
						}
				}
				return MapDgOrgdetails;
			}
			else
				System.out.println("No record found");
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyStudentSearchresultsSorting<br>
	 * Description :- To verify Student search results sorting .
	 * @throws Exception 
	 *
	 */
	public List<String> verifyStudentSearchresultsSorting(String ColName) throws Exception {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Student Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		if ((lstOrgrRow.size() >= 2)) {
			for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						//CommonUtility._sleepForGivenTime(1000);
						CommonFunctions.waitUntilLoadingSpinner(5);
						objlocator =CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	

	/**
	 * Function Name :- SelectonStuCheckbox<br>
	 * Description :- To click Student Checkbox.
	 *
	 */
	public boolean SelectonStuCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}


	/**
	 * Function Name :- checkfirstrecord<br>
	 * Description :- To select the first record from the data grid
	 *
	 */
	public void checkfirstrecord(int count) throws IOException {
		{
			List<WebElement> orglist = WebDriverMain._getElementsWithWait(StudentListPageObjects(OrgListDropDpwn));
			int listCount = orglist.size();
//			int inputcount = Integer.parseInt(count);
			
			System.out.println("listcount :" + listCount);
			System.out.println("inputcount :" + count);

			for (int i = 0; i < listCount; i++) {
				WebElement e = orglist.get(i);

				if (i == count) {

					break;
				}

				else {

					LeftClick.clickByWebElementJS(e);
					CommonUtility._sleepForGivenTime(1000);

				}
			}
		}
	}

	
	/**
	 * Function Name :- clickonStudName<br>
	 * Description :- To click Student Name hyperlink.
	 *
	 */
	public boolean clickonStudName(String Studname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//td/button[contains(text(),'" + Studname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- createButton_isVisible<br>
	 * Description :- To verify create button is visible
	 */
	public boolean createButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(StudentListPageObjects(CreateOrg)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- createButton_isEnabled<br>
	 * Description :- To verify create button is enabled
	 *
	 */
	public boolean createButton_isEnabled() throws IOException{
		if (WebDriverMain._isElementClickable(StudentListPageObjects(CreateOrg)))
			return true;
		else
			return false;
	}
	
	
	/**
	 * Function Name :- deleteButton_isVisible<br>
	 * Description :- To verify delete button is visible
	 *
	 */
	public boolean deleteButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(StudentListPageObjects(DeleteOrg)))
			return true;
		else
			return false; 
	}
	
	
	/**
	 * Function Name :- deleteButton_isEnabled<br>
	 * Description :- To verify delete button is enabled
	 *
	 */
	public boolean deleteButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(StudentListPageObjects(DeleteOrg));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- SelectonStuCheckbox<br>
	 * Description :- To select Students checkbox Details.
	 *
	 */
	public List<String> SelectonStuCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					if (WebDriverMain._isElementPresent(objlocator1)) {
						WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
						if (chbxele!=null) {
							LeftClick.clickByWebElementJS(chbxele);
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							MapDgdetails.add(MapDgOrgRec);
							if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.FDStudID))) {
								String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.FDStudID);
								MapDgOrgdetails.add(SearchOrg);
							}
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- SelectStudentRecord<br>
	 * Description :- To select Student record results Details.
	 *
	 */
	public HashMap<String, String> SelectStudentRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(StudentListPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/button");
						WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
						if (tsElm!=null) {
							if (WebDriverMain._isElementClickable(tsElm)) {
								tsElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								return MapDgOrgRec;
							}
						}
						
							
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	public boolean clickMoreLink() throws Exception {
		boolean flag = WebDriverMain._isElementVisible(StudentListPageObjects(Morelink));
		if (flag) {
			flag=LeftClick._click(StudentListPageObjects(Morelink));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	public boolean verifyAccommodationList() throws IOException {
	//	CommonUtility._sleepForGivenTime(5000);
		if (WebDriverMain._getTextFromElement(StudentListPageObjects(AccommodationListDialogbox_Title)).contains(Constants.AccommodationListTitle))
			return true;
		else
			return false;
	}
		
	public boolean closeAccommodationList() throws Exception {
		boolean flag = WebDriverMain._isElementVisible(StudentListPageObjects(closeButton));
		if (flag) {
			flag=LeftClick._click(StudentListPageObjects(closeButton));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- SelectonStudentCheckboxWithMatchedColValue<br>
	 * Description :- To select Student in search results checkbox Details.
	 *
	 */
	public List<String> SelectonStudentCheckboxWithMatchedColValue(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
				System.out.println("Sess Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					MapDgOrgdetails=new ArrayList<String>();
					MapDgdetails=new ArrayList<HashMap<String, String>>();
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							MapDgOrgRec = new HashMap<String, String>();
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
							String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
							if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
								if (rowindex >= selectcnt) {
									//Select Matched Checkbox
									objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/input[contains(@type,'checkbox')]");
									WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
									if (chbxele!=null) {
										LeftClick.clickByWebElementJS(chbxele);
										objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td[2]");
										String sDGSessValue = WebDriverMain._getTextFromElement(objlocator);
										MapDgOrgdetails.add(sDGSessValue);
										selectcnt=selectcnt+1;
									}
								}
							}	
					}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- SelectonStudentCheckboxWithNotMatchedColValue<br>
	 * Description :- To select Student in search results checkbox Details.
	 *
	 */
	public List<String> SelectonStudentCheckboxWithNotMatchedColValue(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
				System.out.println("Sess Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					MapDgOrgdetails=new ArrayList<String>();
					MapDgdetails=new ArrayList<HashMap<String, String>>();
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							MapDgOrgRec = new HashMap<String, String>();
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
							String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
							if (!sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
								if (rowindex >= selectcnt) {
									//Select Matched Checkbox
									objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/input[contains(@type,'checkbox')]");
									WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
									if (chbxele!=null) {
										LeftClick.clickByWebElementJS(chbxele);
										objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td[2]");
										String sDGSessValue = WebDriverMain._getTextFromElement(objlocator);
										MapDgOrgdetails.add(sDGSessValue);
										selectcnt=selectcnt+1;
									}
								}
							}	
					}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- MergeStudents_isVisible<br>
	 * Description :- To verify MergeStudents button is visible
	 */
	public boolean MergeStudents_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(StudentListPageObjects(btnMergeStudent)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- MergeStudents_isEnabled<br>
	 * Description :- To verify MergeStudents button is enabled
	 *
	 */
	public boolean MergeStudents_isEnabled() throws IOException{
		if (WebDriverMain._isElementClickable(StudentListPageObjects(btnMergeStudent)))
			return true;
		else
			return false;
	}


	
	/**
	 * Function Name :- clickMergeStudents<br>
	 * Description :- To click the MergeStudents button.
	 *
	 */
	public boolean clickMergeStudents() throws IOException{
		boolean flag=LeftClick._click(StudentListPageObjects(btnMergeStudent));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :-DeleteStudents_isVisible<br>
	 * Description :- To verify DeleteStudents button is visible
	 */
	public boolean DeleteStudents_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(StudentListPageObjects(btnDeleteStudent)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- DeleteStudents_isEnabled<br>
	 * Description :- To verify DeleteStudents button is enabled
	 *
	 */
	public boolean DeleteStudents_isEnabled() throws IOException{
		if (WebDriverMain._isElementClickable(StudentListPageObjects(btnDeleteStudent)))
			return true;
		else
			return false;
	}


	
	/**
	 * Function Name :- clickDeleteStudents<br>
	 * Description :- To click the DeleteStudents button.
	 *
	 */
	public boolean clickDeleteStudents() throws IOException{
		boolean flag=LeftClick._click(StudentListPageObjects(btnDeleteStudent));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	
	/**
	 * Function Name :- SelectStudentWithMatchedColValue<br>
	 * Description :- To select Student in search results Details.
	 *
	 */
	public HashMap<String, String> SelectStudentWithMatchedColValue(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
				System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
						String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
						if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
							if (rowindex >= selectcnt) {
								//Select Matched Record
								objlocator = CommonUtility
										._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td");
								List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							
								for (int iCol1 = 0; iCol1 < dataRec.size(); iCol1++) {
									String sDGColmnName1 = lstheaderRow.get(iCol1).getText();
									String sDGColmnValue1 = dataRec.get(iCol1).getText();
									MapDgOrgRec.put(sDGColmnName1, sDGColmnValue1);
								}
								
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/button[contains(@class,'btn-link')]");
								WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
								if (tsElm!=null) {
									if (WebDriverMain._isElementClickable(tsElm)) {
										tsElm.click();
										CommonFunctions.PleaseWaitAndLoadingMessage();
										return MapDgOrgRec;
									}
								}
							}
						}	
					}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgRec;
	}
	
	
	/**
	 * Function Name :- SelectStudentWithNotMatchedColValue<br>
	 * Description :- To select Student in search results Details.
	 *
	 */
	public HashMap<String, String> SelectStudentWithNotMatchedColValue(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
				System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
						String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
						if (!sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
							if (rowindex >= selectcnt) {
								//Select Matched Record
								objlocator = CommonUtility
										._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td");
								List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							
								for (int iCol1 = 0; iCol1 < dataRec.size(); iCol1++) {
									String sDGColmnName1 = lstheaderRow.get(iCol1).getText();
									String sDGColmnValue1 = dataRec.get(iCol1).getText();
									MapDgOrgRec.put(sDGColmnName1, sDGColmnValue1);
								}
								
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/button[contains(@class,'btn-link')]");
								WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
								if (tsElm!=null) {
									if (WebDriverMain._isElementClickable(tsElm)) {
										tsElm.click();
										CommonFunctions.PleaseWaitAndLoadingMessage();
										return MapDgOrgRec;
									}
								}
							}
						}	
					}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- SelectStudentWithAccomCapsule<br>
	 * Description :- To select Student Accom Capsule in search results Details.
	 *
	 */
	public HashMap<String, String> SelectStudentWithAccomCapsule(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentListPageObjects(StuRowPresent));
				System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]/button[contains(@class,'btn-capsule')]");
						
						if (WebDriverMain._isElementPresent(objlocator)) {
								//Select Matched Record
								objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td");
								List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator1);
								for (int iCol1 = 0; iCol1 < dataRec.size(); iCol1++) {
									String sDGColmnName1 = lstheaderRow.get(iCol1).getText();
									String sDGColmnValue1 = dataRec.get(iCol1).getText();
									MapDgOrgRec.put(sDGColmnName1, sDGColmnValue1);
								}
								//Click Capsule
								//objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]/button[contains(@class,'btn-capsule')]");
								WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
								if (tsElm!=null) {
									if (WebDriverMain._isElementClickable(tsElm)) {
										tsElm.click();
										CommonFunctions.PleaseWaitAndLoadingMessage();
										CommonUtility._sleepForGivenTime(4000);
										return MapDgOrgRec;
									}
								}
							
						}	
					}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- waitForProgressbarVisible<br>
	 * Description :- To wait Progress bar is visible
	 */
	public boolean waitForProgressbarVisible(int maxtimeout) throws Exception{
		int count=0;
		while((WebDriverMain._isElementVisible(StudentListPageObjects(Progressbar)))&&(count<maxtimeout))
		{
			CommonUtility._sleepForGivenTime(1000);
			count=count+1;
		}
		if (!WebDriverMain._isElementVisible(StudentListPageObjects(Progressbar)))
			return true;
		else
			return false;
		
	}
	

}
