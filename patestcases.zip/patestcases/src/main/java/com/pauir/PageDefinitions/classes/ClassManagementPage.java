package com.pauir.PageDefinitions.classes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.pauir.PageDefinitions.home.Home;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class ClassManagementPage {
	// Initialize
	Login login = new Login(WebDriverMain._getDriver());
	Home home = new Home();

	// Manage User page objects
		public static String ClassManagePage_verification="xpath|.//h5[contains(text(),'Organizations')]";
		public static String ClassManagePage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
		public static String btnMoreActions="xpath|.//button[@id='moreActions']";
		public static String btnDelete="xpath|.//button[contains(.,'Delete')]";
		public static String btnCreate="xpath|.//button[contains(.,'Add')]";
		public static String ClassRowPresent = "xpath|//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr";
		public static String ClassDatagridHeaderRow = "xpath|//pa-class-list//kendo-grid//table/thead/tr/th";
		public static String ClassList="xpath|.//kendo-grid//table/thead/tr[1]/th[1]";
		public static String ClassListDropDpwn = "xpath|.//label[contains(@class,'k-checkbox-label') and contains(@for,'k-grid0-check')]";
		public static String SearchInputFilter = "xpath|//pa-class-list//pa-grid-search//input";
		public static String searchicon = "xpath|.//i[@class='fa fa-search']";
		public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li[1]/a[contains(.,'home')]";
		public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
		public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
		public static String Progressbar="xpath|//pa-progress-bar/kendo-dialog/div[contains(@class,'k-dialog')]";
		
		public static String Classes_Tab = "xpath|//pa-class-tabs/kendo-tabstrip/ul/li";
		public static String ClassList_Tab = "xpath|//pa-class-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Class List')]";
		public static String CreateClass_Tab = "xpath|//pa-class-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Create Class')]";
		public static String ClassActive_Tab = "xpath|//pa-class-tabs/kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
		public static String ImportClasses_Tab = "xpath|//pa-class-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Import Classes')]";
		public static String btnExportClasses="xpath|.//button[contains(.,'Export Classes')]";
		public static String SuccessLink="xpath|//button[contains(text(),'View the new class now')]";

	/**
	 * Function Name :- ClassManagementPageObjects<br>
	 * Description :- To set Class Management Page Objects locator.
	 * 
	 * @return By
	 */
	public By ClassManagementPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyClassMgmtPageNavigation<br>
	 * Description :- To verify ClassMgmt Page Navigation.
	 *
	 */
	public boolean verifyClassMgmtPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(ClassManagementPageObjects(ClassManagePage_Title)).contains(Constants.ClassListPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- Searchfill_ClassName<br>
	 * Description :- To Fill Name Filter in Class Page.
	 *
	 */
	public boolean Searchfill_ClassName(String Classname) throws Exception {
		
		boolean flag = WebDriverMain._isElementPresent(ClassManagementPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(ClassManagementPageObjects(SearchInputFilter), Classname);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Class Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(ClassManagementPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean flag = WebDriverMain._isElementPresent(ClassManagementPageObjects(SearchInputFilter));
		if (flag)
			flag=LeftClick._click(ClassManagementPageObjects(searchicon));
		
		CommonUtility._sleepForGivenTime(2000);
		return flag;
	}
	
	
	
	/**
	 * Function Name :- clickonClassame<br>
	 * Description :- To click Class Name filter.
	 *
	 */
	public boolean clickonClassName(String Classname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//button[contains(text(),'" + Classname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	

	/**
	 * Function Name :- getClassSearchresultsDetails<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public HashMap<String, String> getClassSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(ClassManagementPageObjects(ClassDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	
	
	/**
	 * Function Name :- getClassSearchresultsDetails<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public boolean hasClasslist() throws IOException {
		boolean flag=false;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ClassManagementPageObjects(NoRecords)))
				flag=true;	
		} 
		else
			flag=false;
		return flag;
	}

	/**
	 * Function Name :- getClassColumnHeaderDetails<br>
	 * Description :- To get Class Col header Details.
	 *
	 */
	public List<String> getClassColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	
		//return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifyClassSearchresultsDetails<br>
	 * Description :- To verify Class search results Details.
	 *
	 */
	public List<String> verifyClassSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		System.out.println("Class Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ClassManagementPageObjects(ClassDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyClassSearchresultsCheckbox<br>
	 * Description :- To verify Class search results checkbox Details.
	 *
	 */
	public List<String> verifyClassSearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		System.out.println("Class Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ClassManagementPageObjects(ClassDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey("Class Name")) {
							String SearchOrg=MapDgOrgRec.get("Class Name");
							MapDgOrgdetails.add(SearchOrg);
						}
					}
					
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyClassSearchresultsDetailsfromtext<br>
	 * Description :- To verify Class search results Details.
	 *
	 */
	public List<String> verifyClassSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		System.out.println("Class Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ClassManagementPageObjects(ClassDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
			
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgOrgRec.containsKey("Class Name")) {
						String SearchOrg=MapDgOrgRec.get("Class Name");
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
						
					}
					
					
				
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	

	/**
	 * Function Name :- SelectonClassCheckbox<br>
	 * Description :- To click Class name Checkbox.
	 *
	 */
	public boolean SelectonClassCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}

	
	/**
	 * Function Name :- checkfirstrecord<br>
	 * Description :- To select the first record from the data grid
	 *
	 */
	public void checkfirstrecord(int count) throws IOException {
		{
			List<WebElement> orglist = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassListDropDpwn));
			int listCount = orglist.size();
//			int inputcount = Integer.parseInt(count);
			
			System.out.println("listcount :" + listCount);
			System.out.println("inputcount :" + count);

			for (int i = 0; i < listCount; i++) {
				WebElement e = orglist.get(i);

				if (i == count) {

					break;
				}

				else {

					LeftClick.clickByWebElementJS(e);
					CommonUtility._sleepForGivenTime(1000);

				}
			}
		}
	}
	
	/**
	 * Function Name :- MoreActionsButton_isVisible<br>
	 * Description :- To verify MoreActions button is visible
	 */
	public boolean MoreActionsButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(ClassManagementPageObjects(btnMoreActions)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- MoreActionsButton_isEnabled<br>
	 * Description :- To verify MoreActions button is enabled
	 *
	 */
	public boolean MoreActionsButton_isEnabled() throws IOException{
		WebElement delete = WebDriverMain._getElementWithWait(ClassManagementPageObjects(btnMoreActions));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	
	/**
	 * Function Name :- deleteButton_isVisible<br>
	 * Description :- To verify delete button is visible
	 *
	 */
	public boolean deleteButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(ClassManagementPageObjects(btnDelete)))
			return true;
		else
			return false; 
	}
	
	
	/**
	 * Function Name :- deleteButton_isEnabled<br>
	 * Description :- To verify delete button is enabled
	 *
	 */
	public boolean deleteButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(ClassManagementPageObjects(btnDelete));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	
	/**
	 * Function Name :- CreateButton_isVisible<br>
	 * Description :- To verify Create button is visible
	 *
	 */
	public boolean CreateButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(ClassManagementPageObjects(btnCreate)))
			return true;
		else
			return false; 
	}
	
	
	/**
	 * Function Name :- CreateButton_isEnabled<br>
	 * Description :- To verify Create button is enabled
	 *
	 */
	public boolean CreateButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(ClassManagementPageObjects(btnCreate));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickCreateButton<br>
	 * Description :- To click Create Button BreadCrum.
	 *
	 */
	public boolean clickCreateButton() throws IOException{
		boolean flag=LeftClick._click(ClassManagementPageObjects(btnCreate));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clickDeleteButton<br>
	 * Description :- To click Delete Button.
	 *
	 */
	public boolean clickDeleteButton() throws IOException{
		boolean flag=LeftClick._click(ClassManagementPageObjects(btnDelete));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- Verify_Progressbar_Visible<br>
	 * Description :- To verify Progressbar is visible
	 */
	public boolean Verify_Progressbar_Visible() throws Exception{
		if (WebDriverMain._isElementVisible(ClassManagementPageObjects(Progressbar)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- waitForProgressbarVisible<br>
	 * Description :- To wait Progress bar is visible
	 */
	public boolean waitForProgressbarVisible(int maxtimeout) throws Exception{
		int count=0;
		while((WebDriverMain._isElementVisible(ClassManagementPageObjects(Progressbar)))&&(count<maxtimeout))
		{
			CommonUtility._sleepForGivenTime(1000);
			count=count+1;
		}
		if (!WebDriverMain._isElementVisible(ClassManagementPageObjects(Progressbar)))
			return true;
		else
			return false;
		
	}
	/**
	 * Function Name :- SelectonClassCheckbox<br>
	 * Description :- To verify Class search results checkbox Details.
	 *
	 */
	public List<String> SelectonClassCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		System.out.println("Class Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ClassManagementPageObjects(ClassDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					if (WebDriverMain._isElementPresent(objlocator1)) {
						WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey("Class Name")) {
							String SearchOrg=MapDgOrgRec.get("Class Name");
							MapDgOrgdetails.add(SearchOrg);
						}
					}
					else
					{
						return MapDgOrgdetails;
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- verifyClassSearchresultsDetailsfromlist<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public List<String> verifyClassSearchresultsDetailsfromlist(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(ClassManagementPageObjects(NoRecords))){
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td[2]");
						WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
						if (dataRec!=null) {
							String sDGStuName = dataRec.getText().trim();
							if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase()))
								MapDgOrgdetails.add(sDGStuName);
							//return MapDgOrgdetails;
						}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	/**
	 * Function Name :- verifySuccessMessage<br>
	 * Description :- To verify Success Message
	 * @throws IOException 
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess=WebDriverMain._getTextFromElement(ClassManagementPageObjects(Success_Message));
		if(textSuccess.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Function Name :- SelectTabOption<br>
	 * Description :- Select the Tab options
	 * 
	 * @param TabOption
	 * @throws IOException
	 */
	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean flag=false;
		boolean iActiveflag=false;
		if (WebDriverMain._isElementPresent(ClassManagementPageObjects(Classes_Tab))) {
			switch (TabOption.toLowerCase()) {
				case "class list":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						flag=LeftClick._click(ClassManagementPageObjects(ClassList_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				case "create class":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						flag=LeftClick._click(ClassManagementPageObjects(CreateClass_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				case "import classes":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						flag=LeftClick._click(ClassManagementPageObjects(ImportClasses_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				default:
					flag=LeftClick._click(ClassManagementPageObjects(ClassList_Tab));
					CommonUtility._sleepForGivenTime(1000);
					break;
			}
		}
		else
			return false;
		
		iActiveflag=VerifyActiveTab(TabOption);
		if (iActiveflag) {
			return true;
		}
		return false;


	}
	
	/**
	 * Function Name :- VerifyTabOption_isVisible<br>
	 * Description :- To verify Tab
	 * @throws IOException 
	 */
	public boolean VerifyTabOption_isVisible(String TabOption) throws Exception{
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//kendo-tabstrip/ul/li/span[contains(text(),'"+TabOption+"')]");
		if (WebDriverMain._isElementPresent(objlocator)) 
			return true;
		else
			return true;

	}
	
	/**
	 * Function Name :- VerifyActiveTab<br>
	 * Description :- To verify Active Tab
	 * @throws IOException 
	 */
	public boolean VerifyActiveTab(String ActiveTab) throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementPresent(ClassManagementPageObjects(ClassActive_Tab))) {
		String textSuccess=WebDriverMain._getTextFromElement(ClassManagementPageObjects(ClassActive_Tab));
		if(textSuccess.contains(ActiveTab))
			return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- SelectClasslistRecord<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public HashMap<String, String> SelectClasslistRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassManagementPageObjects(ClassRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ClassManagementPageObjects(ClassDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ClassManagementPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-class-list//kendo-grid//kendo-grid-list//table/tbody/tr["+Irow +"]/td/button");
						WebElement tsElm = WebDriverMain._getElementWithWait(objlocator);
						if (tsElm!=null) {
							tsElm.click();
							CommonFunctions.PleaseWaitAndLoadingMessage();
							return MapDgOrgRec;
						}
						return MapDgOrgRec;
					}
				}
		}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

	public boolean clickExportClasses() throws IOException{
		boolean flag=LeftClick._click(ClassManagementPageObjects(btnExportClasses));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	public boolean verifyExportClasses_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(ClassManagementPageObjects(btnExportClasses)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- ClickSuccessLink<br>
	 * Description :- To click Success Link.
	 *
	 */
	public boolean ClickSuccessLink() throws IOException{
		boolean flag=LeftClick._click(ClassManagementPageObjects(SuccessLink));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
}
