package com.pauir.PageDefinitions.courses;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pauir.common.core.CommonFunctions;
import com.pauir.common.testDataTypes.Classfield;
import com.pauir.common.testDataTypes.Coursefield;
import com.pauir.common.util.Constants;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.WebDriverMain;

public class CreateCoursePage {
	CommonFunctions common;
	
	//Create Course page objects
	public static String CreateCoursespage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String CreateCourseForm="xpath|.//pa-course-edit//form";
	public static String SaveBtn="xpath|//button[contains(text(),'Save')]";
	public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String SuccessLink="xpath|//button[contains(text(),'View the new course now')]";
	public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
	
	/**
	 * Function Name :- CreateCoursePageObjects<br>
	 * Description :- To set Create Course page locator.
	 * 
	 * @return By
	 */
	public By CreateCoursePageObjects(String byStrgylocValue)
	{
		 By by = null;
		 by=CommonUtility._getByLocator(byStrgylocValue);
		 return by;
	}
	
	
	
	/**
	 * Function Name :- verifyCreateCoursePageNavigation<br>
	 * Description :- To verify Create Course Page Navigation.
	 *
	 */
	public boolean verifyCreateCoursePageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(CreateCoursePageObjects(CreateCoursespage_Title)).contains(Constants.CreateCoursePageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- VerifyCreateCourseForm<br>
	 * Description :- To verify the Create Course page form.
	 *
	 */
	public boolean VerifyCreateCourseForm() throws IOException{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean isDisplayed=WebDriverMain._isElementPresent(CreateCoursePageObjects(CreateCourseForm));
		//CommonUtility._sleepForGivenTime(2000);
		return isDisplayed;
		
	}
	
	
	/**Function Name :- VerifyFieldLabel<br/>
	 * Description   :- VerifyFieldLabel
	 * @param fieldType Label for Label
	 * @return boolean
	 */
	public static boolean VerifyFieldLabel(String fieldType, String Label) {
		
		boolean flag =true;
		try{
			
			//Set by locator object for label
			String strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			By objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label
			flag=WebDriverMain._containText(objlocator,Label);
			
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	
	
	/**
	 * Function Name :- FillCourseField<br>
	 * Description :- To fill Course field depends on fieldtype  on create Course page
	 * @throws IOException 
	 */
	public String FillCourseField(Coursefield field, String FieldValue) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		String sFieldValue=null;
		By objlocator=null;
		By objsublocator=null;
		//field values
		String sFieldName = field.getFieldname();
		String sFieldLocator = field.getObjectlocator();
		String sFieldType=field.getFieldtype();
		String sFieldLabel=field.getLabletodisplay();
		String sFieldrequired=field.getRequired();
		//Set input value
		if(FieldValue.equalsIgnoreCase(null))
			sFieldValue =field.getFieldvalue();
		else
			sFieldValue=FieldValue;
		
		objsublocator=null;
		//Call to verify the field label 
		FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
		if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			
			
			//Fill the Value base fieldtype, locator, value
			FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
		
				CommonUtility._sleepForGivenTime(3000);
		}
		return FilledFieldValue;
	}
	
	/**
	 * Function Name :- clickSaveButton<br>
	 * Description :- To click the Save Class button.
	 *
	 */
	public boolean clickSaveButton() throws IOException{
		
		CommonUtility._scrollup();
		boolean flag=LeftClick._click(CreateCoursePageObjects(SaveBtn));
		CommonUtility._sleepForGivenTime(4000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- clickViewNewCourseLink<br>
	 * Description :- To click the View New Course button.
	 *
	 */
	public boolean clickViewNewCourseLink() throws IOException{
		
		CommonUtility._scrollup();
		boolean flag=LeftClick._click(CreateCoursePageObjects(SuccessLink));
		CommonUtility._sleepForGivenTime(4000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- GetSuccessMessage<br>
	 * Description :- To get the success message.
	 *
	 */
	public String GetSuccessMessage() throws IOException{
		String textSuccess=null;
		try {
		 textSuccess=WebDriverMain._getTextFromElement(CreateCoursePageObjects(Success_Message));
		}
		catch(Exception e) {
			return null;
		}
		return textSuccess;
	}
	/**
	 * Function Name :- Close_Alerts<br>
	 * Description :- To close the alerts.
	 *
	 */
	public boolean Close_Alerts() throws IOException{
		List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(CreateCoursePageObjects(CloseAlerts));
		for (WebElement AlertEle : lstAlertsRow) {
			if (WebDriverMain._isElementClickable(AlertEle)) {
				AlertEle.click();
			}
		}
		return true;
	}

}

