package com.pauir.PageDefinitions.products;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pauir.common.core.CommonFunctions;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class RejectedTestListPage {

	public static String TableRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody";
	public static String RejectedTestListPage_verification = "xpath|.//h5[contains(text(),'Rejected Tests')]";
	public static String RejectedTestListTable = "xpath|//pa-orphan-test-list//kendo-grid//table/thead";
	public static String RejectedTestListPage_Title = "xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String RejectedTestList_Tab = "xpath|//pa-orphan-test-tabs//kendo-tabstrip/ul/li/span[contains(text(),'Rejected Tests List')]";
	public static String RejectedTestActive_Tab = "xpath|//pa-orphan-test-tabs//kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
	public static String RejectedTestDatagridHeaderRow = "xpath|//pa-orphan-test-list//kendo-grid//table/thead/tr/th";
	public static String SearchInputFilter = "xpath|//input[@placeholder='Search']";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String RejectedTestRowPresent = "xpath|//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String AssignStudentbtn = "xpath|//pa-orphan-test-list//button[contains(text(),'Assign to Student')]";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String btnAddNote="xpath|//button[contains(.,'Add Note')]";
	public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String Progressbar="xpath|//pa-progress-bar/kendo-dialog/div[contains(@class,'k-dialog')]";
	public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
	
	public static String btnAssigntoStudent = "xpath|//pa-orphan-test-list//pa-grid-actions/button[contains(text(),'Assign to Student')]";
	public static String ATS_ModalWindow = "xpath|//pa-orphan-test-list//kendo-dialog/div[contains(@class,'k-dialog')]";
	public static String ATS_ModalWindowTitle = "xpath|//pa-orphan-test-list//kendo-dialog/div[contains(@class,'k-dialog')]//kendo-dialog-titlebar//h3";
	public static String ATS_ModalWindowNotes = "xpath|//pa-orphan-test-list//kendo-dialog//div[contains(@class,'k-dialog-content')]//div/b";
	public static String ATS_ModalWindowContent = "xpath|//pa-orphan-test-list//kendo-dialog//div[contains(@class,'k-dialog-content')]//div[@class='kendo-tab-content']";
	public static String ATS_StudentList = "xpath|//pa-orphan-test-list//kendo-dialog//kendo-grid[@pagridparamsdatabinding]";
	public static String ATS_StudentTestList = "xpath|//pa-orphan-test-list//kendo-dialog//kendo-grid[@pastudentprofilesessiondatabindingdirective]";
	public static String ATS_StuRowPresent = "xpath|//pa-orphan-test-list//kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String ATS_StuDatagridHeaderRow = "xpath|//pa-orphan-test-list//kendo-dialog//kendo-grid//table/thead/tr/th";
	public static String ATS_StuList="xpath|//pa-orphan-test-list//kendo-dialog//kendo-grid//table/thead/tr[1]/th[1]";
	public static String ATS_NoRecords = "xpath|//pa-orphan-test-list//kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String ATS_SearchInputFilter = "xpath|//pa-orphan-test-list//kendo-dialog//input[@placeholder='Search']";
	public static String ATS_searchicon = "xpath|//pa-orphan-test-list//kendo-dialog//i[@class='fa fa-search']";
	public static String ATS_BtnCancel = "xpath|//pa-orphan-test-list//kendo-dialog//button[contains(text(),'Cancel')]";
	public static String ATS_BtnAssign = "xpath|//pa-orphan-test-list//kendo-dialog//button[contains(text(),'Assign')]";
	
	
	public By RejectedTestListPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	public boolean waitforTableRecordsExist() throws IOException {
		if (WebDriverMain._isElementVisible(RejectedTestListPageObjects(TableRecords)))
			return true;
		else
			return false;
	}

	public boolean IsRejectedTestListTableExist() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementVisible(RejectedTestListPageObjects(RejectedTestListTable))) {
			waitforTableRecordsExist();
			return true;
		} else
			return false;
	}

	public boolean VerifyActiveTab(String ActiveTab) throws IOException {
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess = WebDriverMain._getTextFromElement(RejectedTestListPageObjects(RejectedTestActive_Tab));
		if (textSuccess.toLowerCase().contains(ActiveTab.toLowerCase())) {
			return true;
		} else {
			return false;
		}
	}

	public List<String> getRejectedTestColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(RejectedTestListPageObjects(RejectedTestDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader = new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;

		// return MapDgOrgColHeader;
	}

	public boolean Searchfill_SearchValue(String SearchValue) throws Exception {

		boolean flag = WebDriverMain._isElementVisible(RejectedTestListPageObjects(SearchInputFilter));
		if (flag) {
			flag = TextBox._setTextBox(RejectedTestListPageObjects(SearchInputFilter), SearchValue);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}

	public boolean clicksearchicon() throws Exception {

		boolean flag = WebDriverMain._isElementVisible(RejectedTestListPageObjects(SearchInputFilter));
		if (flag) {
			flag = LeftClick._click(RejectedTestListPageObjects(searchicon));
			CommonFunctions.waitUntilLoadingSpinner(10);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- hasRejectedTestRecords<br>
	 * Description :- To check RejectedTest records.
	 *
	 */
	public boolean hasRejectedTestRecords() throws IOException {
		if (!WebDriverMain._isElementVisible(RejectedTestListPageObjects(NoRecords))) {
			return true;
		}
		return false;
	}

	public List<String> verifyRejectedTestSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(RejectedTestRowPresent));
		System.out.println("Rejected Tests Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(RejectedTestListPageObjects(RejectedTestDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {

				MapDgOrgRec = new HashMap<String, String>();
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td");
				List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
				for (int iCol = 0; iCol < dataRec.size(); iCol++) {
					String sDGColmnName = lstheaderRow.get(iCol).getText();
					String sDGColmnValue = dataRec.get(iCol).getText();
					MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
				}
				if (MapDgOrgRec.containsKey("Status")) {
					String SearchOrg = MapDgOrgRec.get("Status");
					if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
						MapDgOrgdetails.add(SearchOrg);

				}

			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	public boolean ClearSearchText() throws Exception {
		boolean flag = TextBox._setTextBox(RejectedTestListPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(500);
		return flag;
	}
	
	/**
	 * Function Name :- verifyRejectedTestResultsDetails<br>
	 * Description :- To get search results Details.
	 *
	 */
	public List<String> verifyRejectedTestResultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgUserdetails = null;
		HashMap<String, String> MapDgUserRec = null;
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(RejectedTestRowPresent));
		System.out.println("Rejected Tests Row Count : " + lstUserrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(RejectedTestListPageObjects(RejectedTestDatagridHeaderRow));
		if (lstUserrRow.size() >= 1) {
			MapDgUserdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgUserRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgUserdetails.add(MapDgUserRec.toString());
				}
			}
			return MapDgUserdetails;
		} else
			System.out.println("No record found");
		return MapDgUserdetails;
	}
	
	/**
	 * Function Name :- verifyAssignStudent_isVisible<br>
	 * Description :- To verify AssignStudent button is visible
	 *
	 */
	public boolean verifyAssignStudent_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(RejectedTestListPageObjects(AssignStudentbtn)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- clickAssignStudent<br>
	 * Description :- To click on Assign Student button
	 *
	 */
	
	public boolean clickAssignStudent() throws IOException{
		boolean flag=LeftClick._click(RejectedTestListPageObjects(AssignStudentbtn));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	
	
	/**
	 * Function Name :- SelectRejectedTestRecord<br>
	 * Description :- To select RejectedTest record results Details.
	 *
	 */
	public HashMap<String, String> SelectRejectedTestRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(RejectedTestRowPresent));
		System.out.println("RejectedTest Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(RejectedTestListPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(RejectedTestListPageObjects(RejectedTestDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/button");
						WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
						if (tsElm!=null) {
							if (WebDriverMain._isElementClickable(tsElm)) {
								tsElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								return MapDgOrgRec;
							}
						}
						
							
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	
	
	/**
	 * Function Name :- SelectonRejectedTestCheckbox<br>
	 * Description :- To verify RejectedTest search results checkbox Details.
	 *
	 */
	public List<String> SelectonRejectedTestCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(RejectedTestRowPresent));
		System.out.println("RejectedTest Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(RejectedTestListPageObjects(RejectedTestDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(RejectedTestListPageObjects(NoRecords))){
				MapDgOrgdetails=new ArrayList<String>();
				MapDgdetails=new ArrayList<HashMap<String, String>>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
						if (WebDriverMain._isElementPresent(objlocator1)) {
							WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
							LeftClick.clickByWebElementJS(chbxele);
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							MapDgdetails.add(MapDgOrgRec);
							if (MapDgOrgRec.containsKey("Course Name")) {
								String SearchOrg=MapDgOrgRec.get("Course Name");
								MapDgOrgdetails.add(SearchOrg);
							}
						}
						else
						{
							return MapDgOrgdetails;
						}
					}
				}
				return MapDgOrgdetails;
			}
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- SelectStudentWithMatchedColValue<br>
	 * Description :- To select Student in search results Details.
	 *
	 */
	public HashMap<String, String> SelectStudentCheckboxWithMatchedColValue(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(RejectedTestDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(RejectedTestRowPresent));
				System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementVisible(RejectedTestListPageObjects(NoRecords))){
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
						String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
						if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
							if (rowindex >= selectcnt) {
								//Select Matched Record
								objlocator = CommonUtility
										._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td");
								List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							
								for (int iCol1 = 0; iCol1 < dataRec.size(); iCol1++) {
									String sDGColmnName1 = lstheaderRow.get(iCol1).getText();
									String sDGColmnValue1 = dataRec.get(iCol1).getText();
									MapDgOrgRec.put(sDGColmnName1, sDGColmnValue1);
								}
								objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/input[contains(@type,'checkbox')]");
								WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
								if (chbxele!=null) {
									LeftClick.clickByWebElementJS(chbxele);
									return MapDgOrgRec;
								}
							}
						}	
					}
			return MapDgOrgRec;
		}
			}
			else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgRec;
	}
	
	
	
	/**
	 * Function Name :- SelectonStudentCheckboxWithMatchedColValue<br>
	 * Description :- To select Student in search results checkbox Details.
	 *
	 */
	public List<String> SelectonStudentCheckboxWithMatchedColValue(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(RejectedTestDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(RejectedTestRowPresent));
				System.out.println("Sess Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					MapDgOrgdetails=new ArrayList<String>();
					MapDgdetails=new ArrayList<HashMap<String, String>>();
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							MapDgOrgRec = new HashMap<String, String>();
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
							String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
							if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
								if (rowindex >= selectcnt) {
									//Select Matched Checkbox
									objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/input[contains(@type,'checkbox')]");
									WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
									if (chbxele!=null) {
										LeftClick.clickByWebElementJS(chbxele);
										objlocator = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td[2]");
										String sDGSessValue = WebDriverMain._getTextFromElement(objlocator);
										MapDgOrgdetails.add(sDGSessValue);
										selectcnt=selectcnt+1;
									}
								}
							}	
					}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifySelectedRejectedTestInlist<br>
	 * Description :- To get RejectedTest search results Details.
	 *
	 */
	public List<String> verifySelectedRejectedTestInlist(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(RejectedTestRowPresent));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(RejectedTestListPageObjects(NoRecords))){
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td[2]");
						WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
						if (dataRec!=null) {
							String sDGStuName = dataRec.getText().trim();
							if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase()))
								MapDgOrgdetails.add(sDGStuName);
							//return MapDgOrgdetails;
						}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- AddNoteButton_isVisible<br>
	 * Description :- To verify AddNote button is visible
	 *
	 */
	public boolean AddNoteButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(RejectedTestListPageObjects(btnAddNote)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- clickAddNoteButton<br>
	 * Description :- To click AddNote Button.
	 *
	 */
	public boolean clickAddNoteButton() throws IOException{
		boolean flag=LeftClick._click(RejectedTestListPageObjects(btnAddNote));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	/**
	 * Function Name :- GetSuccessMessage<br>
	 * Description :- To get Success Message
	 * @throws IOException 
	 */
	public String GetSuccessMessage() throws IOException{
		String textSuccess=null;
		try {
		 textSuccess=WebDriverMain._getTextFromElement(RejectedTestListPageObjects(Success_Message));
		}
		catch(Exception e) {
			return null;
		}
		return textSuccess;
	}
	/**
	 * Function Name :- verifySuccessMessage<br>
	 * Description :- To verify Success Message
	 * @throws IOException 
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess=WebDriverMain._getTextFromElement(RejectedTestListPageObjects(Success_Message));
		if(textSuccess.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Function Name :- waitForProgressbarVisible<br>
	 * Description :- To wait Progress bar is visible
	 */
	public boolean waitForProgressbarVisible(int maxtimeout) throws Exception{
		int count=0;
		while((WebDriverMain._isElementVisible(RejectedTestListPageObjects(Progressbar)))&&(count<maxtimeout))
		{
			CommonUtility._sleepForGivenTime(1000);
			count=count+1;
		}
		if (!WebDriverMain._isElementVisible(RejectedTestListPageObjects(Progressbar)))
			return true;
		else
			return false;
		
	}
	/**
	 * Function Name :- Close_Alerts<br>
	 * Description :- To close alert Message
	 * @throws IOException 
	 */
	public boolean Close_Alerts() throws IOException{
		List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(CloseAlerts));
		for (WebElement AlertEle : lstAlertsRow) {
			if (WebDriverMain._isElementClickable(AlertEle)) {
				AlertEle.click();
			}
		}
		return true;
	}
	
	/**
	 * Function Name :- AssigntoStudentButton_isVisible<br>
	 * Description :- To verify Assign to Student button is visible
	 *
	 */
	public boolean AssigntoStudentButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(RejectedTestListPageObjects(btnAssigntoStudent)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- clickAssigntoStudentt<br>
	 * Description :- To click Assign to Student.
	 *
	 */
	public boolean clickAssigntoStudent() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			flag=LeftClick._click(RejectedTestListPageObjects(btnAssigntoStudent));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- Verify_AssigntoStudentWindow<br>
	 * Description :- To verify AssigntoStudent Window is visible
	 *
	 */
	public boolean Verify_AssigntoStudentWindow() throws IOException{
		if (WebDriverMain._isElementVisible(RejectedTestListPageObjects(ATS_ModalWindow)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_AssigntoStudentWindowTitle<br>
	 * Description :- To verify the AssigntoStudentWindowTitle.
	 *
	 */
	public boolean Verify_AssigntoStudentWindowTitle(String titlemessage) throws IOException{
		try {
			String text1=WebDriverMain._getTextFromElement(RejectedTestListPageObjects(ATS_ModalWindowTitle));
			if(text1.contains(titlemessage))
				return true;
		}
		catch(Exception e) {
	 		return false;
		}
		return false;
	}
	
	/**
	 * Function Name :- Verify_AssigntoStudentWindowTitleNotes<br>
	 * Description :- To verify the AssigntoStudentWindowTitle.
	 *
	 */
	public boolean Verify_AssigntoStudentWindowNotes(String titlemessage) throws IOException{
		try {
			String text1=WebDriverMain._getTextFromElement(RejectedTestListPageObjects(ATS_ModalWindowNotes));
			if(text1.contains(titlemessage))
				return true;
		}
		catch(Exception e) {
	 		return false;
		}
		return false;
	}
	
	/**
	 * Function Name :- Verify_AssigntoStudentWindowTitleNotes<br>
	 * Description :- To verify the AssigntoStudentWindowTitle.
	 *
	 */
	public boolean Verify_AssigntoStudentWindowContent(String titlemessage) throws IOException{
		try {
			String text1=WebDriverMain._getTextFromElement(RejectedTestListPageObjects(ATS_ModalWindowContent));
			if(text1.contains(titlemessage))
				return true;
		}
		catch(Exception e) {
	 		return false;
		}
		return false;
	}

	/**
	 * Function Name :- Verify_AssigntoStudent_StudentList<br>
	 * Description :- To verify Reassign Test StudentList Table is visible
	 *
	 */
	public boolean Verify_AssigntoStudent_StudentList() throws IOException{
		if (WebDriverMain._isElementVisible(RejectedTestListPageObjects(ATS_StudentList)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- AssignButton_isEnabled<br>
	 * Description :- To verify Assign button is enabled
	 *
	 */
	public boolean AssignButton_isEnabled() throws IOException{
		WebElement delete = WebDriverMain._getElementWithWait(RejectedTestListPageObjects(ATS_BtnAssign));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickAssignButton<br>
	 * Description :- To click Assign Button.
	 *
	 */
	public boolean clickAssignButton() throws IOException{
		boolean flag=false;
		try {
			flag=LeftClick._click(RejectedTestListPageObjects(ATS_BtnAssign));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(3000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- clickCancelButton<br>
	 * Description :- To click Cancel Button.
	 *
	 */
	public boolean clickCancelButton() throws IOException{
		boolean flag=false;
		try {
			flag=LeftClick._click(RejectedTestListPageObjects(ATS_BtnCancel));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- Searchfill_ATSSearchValue<br>
	 * Description :- To fill Search value
	 *
	 */
	public boolean Searchfill_ATSSearchValue(String SearchValue) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(RejectedTestListPageObjects(ATS_SearchInputFilter));
		if (flag) {
			flag = TextBox._setTextBox(RejectedTestListPageObjects(ATS_SearchInputFilter), SearchValue);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}

	/**
	 * Function Name :- clickATSsearchicon<br>
	 * Description :- To click Search icon
	 *
	 */
	public boolean clickATSsearchicon() throws Exception {
		boolean flag = WebDriverMain._isElementVisible(RejectedTestListPageObjects(ATS_SearchInputFilter));
		if (flag) {
			flag = LeftClick._click(RejectedTestListPageObjects(ATS_searchicon));
			CommonFunctions.waitUntilLoadingSpinner(10);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- getStuColumnHeaderDetails<br>
	 * Description :- To get Students Col header Details.
	 *
	 */
	public List<String> getStuColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(ATS_StuDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}

	
	/**
	 * Function Name :- GetStudentListDetails<br>
	 * Description :- To get search results Details.
	 *
	 */
	public List<String> GetStudentListDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgUserdetails = null;
		HashMap<String, String> MapDgUserRec = null;
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(ATS_StuRowPresent));
		System.out.println("Students Row Count : " + lstUserrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(RejectedTestListPageObjects(ATS_StuDatagridHeaderRow));
		if (lstUserrRow.size() >= 1) {
			MapDgUserdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgUserRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgUserdetails.add(MapDgUserRec.toString());
				}
			}
			return MapDgUserdetails;
		} else
			System.out.println("No record found");
		return MapDgUserdetails;
	}
	
	/**
	 * Function Name :- SelectonStuCheckbox<br>
	 * Description :- To select Students checkbox Details.
	 *
	 */
	public HashMap<String, String> SelectonStuCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(RejectedTestListPageObjects(ATS_StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(RejectedTestListPageObjects(ATS_StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(RejectedTestListPageObjects(ATS_NoRecords))) {
				MapDgOrgdetails=new ArrayList<String>();
				MapDgdetails=new ArrayList<HashMap<String, String>>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
						if (WebDriverMain._isElementPresent(objlocator1)) {
							WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
							if (chbxele!=null) {
								LeftClick.clickByWebElementJS(chbxele);
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-orphan-test-list//kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td");
								List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
								for (int iCol = 0; iCol < dataRec.size(); iCol++) {
									String sDGColmnName = lstheaderRow.get(iCol).getText();
									String sDGColmnValue = dataRec.get(iCol).getText();
									MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
								}
							}
						}
					}
				}
				return MapDgOrgRec;
			}
		}else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

}
