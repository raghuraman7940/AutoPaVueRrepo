package com.pauir.PageDefinitions.shipments;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;
import com.pauir.PageDefinitions.home.Home;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class ShipmentsPage {

	// Shipments page objects
	public static String Shipmentspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String ShipRowPresent = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String ShipDatagridHeaderRow = "xpath|//kendo-grid//table/thead/tr/th";
	public static String SearchInputFilter = "xpath|//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String Errormsg = "xpath|//pa-alerts//div[@role ='alert']/p/span";
	public static String Shipments_Tab = "xpath|//pa-shipment-tabs/kendo-tabstrip/ul/li/span";
	public static String ShipmentOBList_Tab = "xpath|//pa-shipment-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Ship to District/School')]";
	public static String ShipmentIBList_Tab = "xpath|//pa-shipment-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Ship to Pearson')]";
	public static String ShipmentActive_Tab = "xpath|//pa-shipment-tabs/kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
	public static String Orderspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String AOList_Tab = "xpath|//kendo-tabstrip/ul/li/span[contains(text(),'Additional Orders')]";
	public static String Success_Message = "xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
	/**
	 * Function Name :- ShipmentsPageObjects<br>
	 * Description :- To set Shipments Page Objects locator.
	 * 
	 * @return By
	 */
	public By ShipmentsPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyShipmentsPageNavigation<br>
	 * Description :- To verify Shipments Page Navigation.
	 *
	 */
	public boolean verifyShipmentsPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		String TitleText=WebDriverMain._getTextFromElement(ShipmentsPageObjects(Shipmentspage_Title));
		if ((TitleText.contains(Constants.ShipmentsPageTitle))||(TitleText.contains(Constants.OrderDetailPageTitle)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- getColumnHeaderDetails<br>
	 * Description :- To get Column header Details.
	 *
	 */
	public List<String> getColumnHeaderDetails() throws IOException {
		List<String> MapDgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgColHeader.add(sDGColmnName);
			}
		}
		return MapDgColHeader;
	}

	/**
	 * Function Name :- verifysearchresultsDetails<br>
	 * Description :- To get search results Details.
	 *
	 */
	public List<String> verifysearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgUserdetails = null;
		HashMap<String, String> MapDgUserRec = null;
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipRowPresent));
		System.out.println("Row Count : " + lstUserrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ShipmentsPageObjects(ShipDatagridHeaderRow));
		if (lstUserrRow.size() >= 1) {
			MapDgUserdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgUserRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgUserdetails.add(MapDgUserRec.toString());
				}
				
			}
			return MapDgUserdetails;
		} else
			System.out.println("No record found");
		return MapDgUserdetails;
	}


	/**
	 * Function Name :- SelectonShipmentsCheckbox<br>
	 * Description :- To select Shipments Checkbox.
	 *
	 */
	public boolean SelectonShipmentsCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- SelectonShipmentsCheckbox<br>
	 * Description :- To select search results checkbox Details.
	 *
	 */
	public List<String> SelectonShipmentsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipRowPresent));
		//System.out.println("Ship Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ShipmentsPageObjects(ShipDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-shipment-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey("Tracking Number")) {
							String SearchOrg=MapDgOrgRec.get("Tracking Number");
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	

	/**
	 * Function Name :- FillSearchInput<br>
	 * Description :- To Fill Name Filter in User Page.
	 *
	 */
	public boolean FillSearchInput(String Searchtext) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(ShipmentsPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(ShipmentsPageObjects(SearchInputFilter), Searchtext);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}

	/**
	 * Function Name :- hasShipmentslist<br>
	 * Description :- To get  search results Details.
	 *
	 */
	public boolean hasShipmentslist() throws IOException {
		boolean flag=false;
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipRowPresent));
		if (lstUserrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ShipmentsPageObjects(NoRecords)))
				flag=true;	
		} 
		return flag;
	}
	
	/**
	 * Function Name :- verifysearchresultsDetailsfromtext<br>
	 * Description :- To get search results Details.
	 *
	 */
	public List<String> verifysearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgUserdetails = null;
		HashMap<String, String> MapDgUserRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipRowPresent));
		//System.out.println("Ship Row Count : " + lstUserrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ShipmentsPageObjects(ShipDatagridHeaderRow));
		if (lstUserrRow.size() >= 1) {
			MapDgUserdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
					MapDgUserRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgUserRec.containsKey("Tracking Number")&&(MapDgUserRec.containsKey("Status"))) {
						String SearchUser=MapDgUserRec.get("Tracking Number")+" - "+MapDgUserRec.get("Status");
						if (SearchUser.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgUserdetails.add(SearchUser);
						
					}
			}
			return MapDgUserdetails;
		} else
			System.out.println("No record found");
		return MapDgUserdetails;
	}
	
	/**
	 * Function Name :- verifySearchresultsSorting<br>
	 * Description :- To verify search results sorting .
	 * @throws Exception 
	 *
	 */
	public List<String> verifySearchresultsSorting(String ColName) throws Exception {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipRowPresent));
		System.out.println("Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ShipmentsPageObjects(ShipDatagridHeaderRow));
		if ((lstheaderRow.size() >= 1)&&(lstOrgrRow.size() >= 2)) {
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						CommonFunctions.waitUntilLoadingSpinner(10);
						objlocator =CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	
	/**
	 * Function Name :- SelectShipmentList<br>
	 * Description :- To verify Shipment search results Details.
	 *
	 */
	public HashMap<String, String> SelectShipmentList() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipRowPresent));
		System.out.println("Shipments Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ShipmentsPageObjects(ShipDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ShipmentsPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td//a");
						WebElement tsElm = WebDriverMain._getElementWithWait(objlocator);
						if (WebDriverMain._isElementClickable(tsElm)) {
							tsElm.click();
							CommonFunctions.PleaseWaitAndLoadingMessage();
							return MapDgOrgRec;
						}
						
					}
					
				}
			}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- SelectCourseRecord<br>
	 * Description :- To select Course record results Details.
	 *
	 */
	public HashMap<String, String> SelectOrderRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipRowPresent));
		System.out.println("Order Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ShipmentsPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(ShipmentsPageObjects(ShipDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td//button");
						WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
						if (tsElm!=null) {
							if (WebDriverMain._isElementClickable(tsElm)) {
								tsElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								return MapDgOrgRec;
							}
						}
						
							
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in User Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(ShipmentsPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}

	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks search icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {

		boolean flag = WebDriverMain._isElementVisible(ShipmentsPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(ShipmentsPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- verify Shipments ErrorMessage<br>
	 * Description :- To verify Shipments ErrorMessage
	 * @throws IOException 
	 */
	public boolean verify_errorMessge(String Errormessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
	    String textmessage=WebDriverMain._getTextFromElement(ShipmentsPageObjects(Errormsg));
	  
		if(textmessage.contains(Errormessage)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Function Name :- SelectTabOption<br>
	 * Description :- Select the Tab options
	 * 
	 * @param TabOption
	 * @throws IOException
	 */
	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean iActiveflag=false;
		if (WebDriverMain._isElementPresent(ShipmentsPageObjects(Shipments_Tab))) {
			switch (TabOption.toLowerCase()) {
				case "ship to district/school":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						LeftClick._click(ShipmentsPageObjects(ShipmentOBList_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				case "ship to pearson":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						LeftClick._click(ShipmentsPageObjects(ShipmentIBList_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				case "additional orders":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						LeftClick._click(ShipmentsPageObjects(AOList_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				default:
					LeftClick._click(ShipmentsPageObjects(ShipmentOBList_Tab));
					CommonUtility._sleepForGivenTime(1000);
					break;
			}
		}
		else
			return false;
		
		iActiveflag=VerifyActiveTab(TabOption);
		if (iActiveflag) {
			return true;
		}
		return false;
	}

	/**
	 * Function Name :- VerifyActiveTab<br>
	 * Description :- To verify Active Tab
	 * @throws IOException 
	 */
	public boolean VerifyActiveTab(String ActiveTab) throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess=WebDriverMain._getTextFromElement(ShipmentsPageObjects(ShipmentActive_Tab));
		if(textSuccess.toLowerCase().contains(ActiveTab.toLowerCase())){
			return true;
		}else{
			return false;
		}
	}
	
	
	public boolean verifyOrdersPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(ShipmentsPageObjects(Shipmentspage_Title)).contains(Constants.OrderDetailPageTitle))
			return true;
		else
			return false;
	}
	
	public List<String> verifyAOsearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgUserdetails = null;
		HashMap<String, String> MapDgUserRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(ShipRowPresent));
		//System.out.println("Ship Row Count : " + lstUserrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ShipmentsPageObjects(ShipDatagridHeaderRow));
		if (lstUserrRow.size() >= 1) {
			MapDgUserdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
					MapDgUserRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgUserRec.containsKey("Order #")&&(MapDgUserRec.containsKey("Status"))) {
						String SearchUser=MapDgUserRec.get("Order #")+" - "+MapDgUserRec.get("Status");
						if (SearchUser.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgUserdetails.add(SearchUser);
					}
			}
			return MapDgUserdetails;
		} else
			System.out.println("No record found");
		return MapDgUserdetails;
	}
	
	/**
	 * Function Name :- verifySuccessMessageVisible<br>
	 * Description :- To verify Success Message
	 * 
	 * @throws IOException
	 */
	public boolean verifySuccessMessageVisible() throws IOException {
		if (WebDriverMain._isElementVisible(ShipmentsPageObjects(Success_Message))) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Function Name :- verifySuccessMessageExist<br>
	 * Description :- To verify the SuccessMessage
	 *
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException{
		String textSuccess=WebDriverMain._getTextFromElement(ShipmentsPageObjects(Success_Message));
		if(textSuccess.contains(successmessage)){
			return true;
		}else{
			return false;
			}
		}
	
	/**
	 * Function Name :- Close_Alerts<br>
	 * Description :- To close the Message
	 *
	 */
	public boolean Close_Alerts() throws IOException{
		List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(ShipmentsPageObjects(CloseAlerts));
		for (WebElement AlertEle : lstAlertsRow) {
			if (WebDriverMain._isElementClickable(AlertEle)) {
				AlertEle.click();
			}
		}
		return true;
	}
}
	