package com.pauir.PageDefinitions.home;


import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.util.Constants;
import webdriver.main.CommonUtility;
import webdriver.main.KendoGrid;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class DrilldownPage {
	
	// Drilldown Student page objects
	public static String Page_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String Page_SubTitle="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]/h2";
//	public static String Breadcrumb = "xpath|//pa-breadcrumb//div[contains(@class,'btn-dark')]";
	public static String Breadcrumb = "xpath|//pa-breadcrumb//button[@class='btn btn-dark right']";
	public static String Progressbar="xpath|//pa-progress-bar/kendo-dialog/div[contains(@class,'k-dialog')]";
	public static String StuRowPresent = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String StuDatagridHeaderRow = "xpath|//kendo-grid//table/thead/tr/th";
	public static String SearchInputFilter = "xpath|//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";	
	public static String TableRecords="xpath|//kendo-grid//kendo-grid-list//table/tbody";
	public static String SelectItemsPage="xpath|//kendo-grid/kendo-pager/kendo-pager-page-sizes/select";
	public static String LstSessions="xpath|//pa-org-registration-students//kendo-popup//div[@class='popover-body']//div[contains(@class,'popover-item')]/button";
	public static String LnkExporttoCSV = "xpath|//button[contains(text(),'Export to CSV')]";
	public static String TableCheckBox = "xpath|//kendo-grid//table/thead/tr/th[1]/label[contains(@class,'k-checkbox-label')]";
	public static String ClearButton = "xpath|//button[contains(@aria-label,'Clear Search')]";
	//
	/**
	 * Function Name :- DrilldownPageObjects<br>
	 * Description :- To set Student list Page Objects locator.
	 * 
	 * @return By
	 */
	public By DrilldownPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	/**
	 * Function Name :- verifyPageNavigation<br>
	 * Description :- To verify Page Navigation.
	 *
	 */
	public boolean verifyPageNavigation(String PageTitle) throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		CommonUtility._scrollup();
		String StrPageHeader=WebDriverMain._getTextFromElement(DrilldownPageObjects(Page_Title));
		if (StrPageHeader.contains(PageTitle))
			return true;
		else
			return false;
	}
	
	
	/**
	 * Function Name :- verifyPageNavigation<br>
	 * Description :- To verify Page Navigation.
	 *
	 */
	public boolean verifyPageSubtitle(String PageSubTitle) throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		CommonUtility._scrollup();
		String StrPageHeader=WebDriverMain._getTextFromElement(DrilldownPageObjects(Page_SubTitle));
		if (StrPageHeader.contains(PageSubTitle))
			return true;
		else
			return false;
	}
	/**
	 * Function Name :- verifyBreadcrumb<br>
	 * Description :- To verify Breadcrumb Page Navigation.
	 *
	 */
	public boolean verifyBreadcrumb(String Breadcrumbtext) throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		CommonUtility._scrollup();
		String StrPageHeader=WebDriverMain._getTextFromElement(DrilldownPageObjects(Breadcrumb));
		if (StrPageHeader.contains(Breadcrumbtext))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- clickBreadcrumb<br>
	 * Description :- To click Breadcrumb.
	 *
	 */
	public boolean clickBreadcrumb() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();	
			flag=LeftClick._click(DrilldownPageObjects(Breadcrumb));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	
	/**
	 * Function Name :- Searchfill_StudName<br>
	 * Description :- To Fill Name Filter in Class details Page.
	 *
	 */
	public boolean Searchfill_StudName(String Studname) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(DrilldownPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(DrilldownPageObjects(SearchInputFilter), Studname);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}
	
//	/**
//	 * Function Name :- ClearSearchText<br>
//	 * Description :- To Clear Text in Class Details Page.
//	 *
//	 */
//	public boolean ClearSearchText() throws Exception {
//		boolean flag =TextBox._setTextBox(DrilldownPageObjects(SearchInputFilter), "");
//		CommonUtility._sleepForGivenTime(1000);
//		return flag;
//	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
//		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean flag = WebDriverMain._isElementVisible(DrilldownPageObjects(SearchInputFilter));
		if (flag)
			flag=LeftClick._click(DrilldownPageObjects(searchicon));
		
		CommonUtility._sleepForGivenTime(3000);
		return flag;
	}
	
	/**
	 * Function Name :- getStudsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public HashMap<String, String> getStudsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	

	/**
	 * Function Name :- getStuColumnHeaderDetails<br>
	 * Description :- To get Students Col header Details.
	 *
	 */
	public List<String> getStuColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifyStusearchresultsDetails<br>
	 * Description :- To get Students search results Details.
	 *
	 */
	public List<String> verifyStusearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	
	/**
	 * Function Name :- verifyStudentSearchresultsSorting<br>
	 * Description :- To verify Student search results sorting .
	 *
	 */
	public List<String> verifyStudentSearchresultsbyCol(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Student Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
		if ((lstOrgrRow.size() >= 1)) {
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.equals(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					objlocator =CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iColval = 0; iColval < dataRec.size(); iColval++) {
						String sDGColmnValue = dataRec.get(iColval).getText();
						MapDgColValues.add(sDGColmnValue);
					}
					
				}
			}
		}
		return MapDgColValues;
	}
	
	
	/**
	 * Function Name :- verifyStuGridPagination<br>
	 * Description :- To verify Students grid pagination.
	 *
	 */
	public int verifyStuGridPagination() throws IOException {
		int maxpage=0;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		maxpage=KendoGrid.GetShowingMaxItems();		
		System.out.println("Stu Page : " + maxpage);
		if (maxpage>29) {
			//Select Next Page
			maxpage=KendoGrid.GetShowingMaxItems();
			return maxpage;
//			KendoGrid.SelectNextPage();
//			waitforTableRecordsExist();
//			lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
//			System.out.println("Stu Next Row Count : " + lstOrgrRow.size());
//			//Select First Page
//			KendoGrid.SelectFirstPage();
//			waitforTableRecordsExist();
		}
		return maxpage;
	}
	
	
	/**
	 * Function Name :- verifyStuGridPagination<br>
	 * Description :- To verify Students grid pagination.
	 * @throws Exception 
	 *
	 */
	public int verifyStuCountGridPagination(int stucnt) throws Exception {
		int maxpage=0;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		maxpage=lstOrgrRow.size();		
		System.out.println("Stu Page : " + maxpage);
		if (maxpage>=29) {
			KendoGrid.SelectItemsPerPage("200");
			CommonUtility._sleepForGivenTime(2000);
			CommonFunctions.waitUntilLoadingSpinner(10);
			lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
			maxpage=lstOrgrRow.size();	
			if (maxpage>=198) 
				return stucnt;
			else 
				return maxpage;
		}
		else
			return maxpage;
	}
	
	/**
	 * Function Name :- verifyStudentSearchresultsSorting<br>
	 * Description :- To verify Student search results sorting .
	 *
	 */
	public List<String> verifyStudentSearchresultsSorting(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Student Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
		if ((lstOrgrRow.size() >= 2)) {
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.equals(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						objlocator =CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	
	/**
	 * Function Name :- verifyStudSearchresultsDetailsfromtext<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public List<String> verifyStudSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		int Marxrowindex=5;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (Marxrowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.FDStudID))) {
						String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.FDStudID);
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	

	
	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> SelectonStuCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-session-add-students//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-add-students//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.FDStudID))) {
							String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.FDStudID);
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- clickonStudCount<br>
	 * Description :- To click Student count hyperlink.
	 *
	 */
	public boolean clickonStudCount(String Studcnt) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//td/a[contains(text(),'" + Studcnt + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	
//	/**
//	 * Function Name :- clickonSchCount<br>
//	 * Description :- To click School count hyperlink.
//	 *
//	 */
//	public boolean clickonSchCount(String Schcnt) throws IOException {
//		By objlocator = null;
//		CommonUtility._sleepForGivenTime(1000);
//		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
//		for (WebElement UserRow : lstUserRow) {
//			objlocator = CommonUtility._getObjectLocator(
//					"xpath=//td/a");
//					//"xpath=//td/a[contains(text(),'" + Schcnt + "')]");
//			WebElement tsElm = UserRow.findElement(objlocator);
//			if (WebDriverMain._isElementClickable(tsElm)) {
//				tsElm.click();
//				CommonFunctions.PleaseWaitAndLoadingMessage();
//				return true;
//			}
//		}
//		return false;
//	}
	
	
	/**
	 * Function Name :- clickonSchCount<br>
	 * Description :- To click School count hyperlink.
	 *
	 */
	public boolean clickonSchCount(String Schcnt) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//td/a[text()=" + Schcnt + "]");
					//"xpath=//td/a[contains(text(),'" + Schcnt + "')]") //td/a;
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- waitforTableRecordsExist<br>
	 * Description :- To wait Table list to load
	 *
	 */
	public boolean waitforTableRecordsExist() throws IOException {
		//WebDriverMain._waitForElementVisible(StudentListPageObjects(TableRecords));
		if (WebDriverMain._isElementVisible(DrilldownPageObjects(TableRecords)))
			return true;
		else
			return false;
	}
	
	
	
	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<HashMap<String, String>> SelectViewSessions(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<String> MapSessionlist = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapSessionlist=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-org-registration-students//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td//button[contains(text(),'View Session(s)')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						LeftClick._click(chbxele);
						CommonUtility._sleepForGivenTime(2000);
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-registration-students//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapSessionlist=GetSessionListfromViewSessions();
						if (MapSessionlist!=null)
							MapDgOrgRec.put("Sessions", MapSessionlist.toString());
						MapDgdetails.add(MapDgOrgRec);
					}
				}
			}
			return MapDgdetails;
		} else
			System.out.println("No record found");
		return MapDgdetails;
	}
	
	/**
	 * Function Name :- GetSessionListfromViewSessions<br>
	 * Description :- To get session list from view sessions.
	 *
	 */
	public List<String> GetSessionListfromViewSessions() throws IOException{
		List<String> MapDgColValues = null;
		try {
		
			if (WebDriverMain._isElementVisible(DrilldownPageObjects(LstSessions)))
			{
				List<WebElement> dataRec = WebDriverMain._getElementsWithWait(DrilldownPageObjects(LstSessions));
				MapDgColValues=new ArrayList<String>();
				for (int iCol = 0; iCol < dataRec.size(); iCol++) {
					String sDGColmnValue = dataRec.get(iCol).getText();
					MapDgColValues.add(sDGColmnValue);
				}
			}
		 }
		 catch(Exception e) {
		 		return MapDgColValues;
		 }
		return MapDgColValues;
	}
	
	/**
	 * Function Name :- getPageTitleForDownload<br>
	 * Description :- To get Page download.
	 *
	 */
	public String getPageTitleForDownload() throws IOException {
		CommonUtility._scrollup();
		String StrPageHeader=WebDriverMain._getTextFromElement(DrilldownPageObjects(Page_Title));
		return StrPageHeader;
	}
	
	/**
	 * Function Name :- clickExporttoCSV<br>
	 * Description :- To click ExporttoCSV.
	 *
	 */
	public boolean clickExporttoCSV() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();	
			flag=LeftClick._click(DrilldownPageObjects(LnkExporttoCSV));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(6000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- verifyExporttoCSV<br>
	 * Description :- To verify the ExporttoCSV.
	 *
	 */
	public boolean verifyExporttoCSV() throws IOException{
		if (WebDriverMain._isElementVisible(DrilldownPageObjects(LnkExporttoCSV)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- getDrilldownrecords<br>
	 * Description :- To get drill down table results Details.
	 *
	 */
	public List<List<String>> getDrilldownrecords(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = new ArrayList<String>();
		List<List<String>> lstRecords =new ArrayList<List<String>>();
		
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
		for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			if (sDGColmnName.length()>1)
				MapDgOrgdetails.add(sDGColmnName);
		}
		lstRecords.add(MapDgOrgdetails);
		
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Drilldown Row Count : " + lstOrgrRow.size());
		
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgdetails=new ArrayList<String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					
					int initcol=0;
					if (WebDriverMain._isElementPresent(DrilldownPageObjects(TableCheckBox)))
						initcol=1;
					
					for (int iCol = initcol; iCol < dataRec.size(); iCol++) {
						String sDGColmnValue = dataRec.get(iCol).getText();
						if (!sDGColmnValue.equalsIgnoreCase("View Session(s)")) {
							if (sDGColmnValue.equalsIgnoreCase("Exception")) 
								sDGColmnValue="true";
							MapDgOrgdetails.add(sDGColmnValue);
						}
					}
					
					
					lstRecords.add(MapDgOrgdetails);
				}
				
			}
			return lstRecords;
		} else
			System.out.println("No record found");
		return lstRecords;
	}
	
	/**
	 * Function Name :- getStudsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public HashMap<String, String> SelectDrillResultsCount() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DrilldownPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (Irow == 1) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(DrilldownPageObjects(StuDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					
					objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/a");
					WebElement tsElm = WebDriverMain._getElementWithWait(objlocator);
					if (WebDriverMain._isElementClickable(tsElm)) {
						tsElm.click();
						CommonFunctions.PleaseWaitAndLoadingMessage();
						return MapDgOrgRec;
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Class Details Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		
		if(LeftClick._click(DrilldownPageObjects(ClearButton)))
		{
			CommonUtility._sleepForGivenTime(2000);
		   return true;
		}
		else
		{
			return false;
		}
		
	}

}
