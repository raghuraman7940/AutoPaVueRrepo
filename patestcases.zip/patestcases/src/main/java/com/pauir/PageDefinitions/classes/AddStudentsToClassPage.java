package com.pauir.PageDefinitions.classes;



import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import webdriver.main.CommonUtility;
import webdriver.main.KendoGrid;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class AddStudentsToClassPage {
	// AddStudent to Class page objects
	public static String AddStudent_Classpage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String btnEdit="xpath|.//button[@id='editStudent']";
	public static String Breadcrumb_ClassDetails = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Class Details')]";

	// Student List page objects
	public static String StudentListpage_verification="xpath|.//h5[contains(text(),'Student Management')]";
	public static String SelectedStudentCount="xpath|//pa-class-add-students//div[contains(text(),'Students Selected')]";
	public static String StudentListpage_Title="xpath|.//pa-breadcrumb//h1[contains(@class,'breadcrumb-title')]";
	public static String btnAdd="xpath|.//button[contains(text(),'Add')]";
	public static String btnCancel="xpath|.//button[contains(text(),'Cancel')]";
	public static String Progressbar="xpath|//pa-progress-bar/kendo-dialog/div[contains(@class,'k-dialog')]";
	public static String StuRowPresent = "xpath|//pa-class-add-students//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String StuDatagridHeaderRow = "xpath|//pa-class-add-students//kendo-grid//table/thead/tr/th";
	public static String StuList="xpath|.//kendo-grid//table/thead/tr[1]/th[1]";
	public static String SearchInputFilter = "xpath|//pa-class-add-students//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String Class_StudentList_Section="xpath|//pa-class-add-students//h2[contains(.,'Student List')]";
	public static String Alert_Message="xpath|//pa-class-add-students//div[@role='alert']/div[contains(@class,'alert-message')]";
	public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	
	/**
	 * Function Name :- ClassDetailPageObjects<br>
	 * Description :- To set Class Details Page Objects locator.
	 * 
	 * @return By
	 */
	public By AddStudentPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	/**
	 * Function Name :- verifyAddStudentsToClassNavigation<br>
	 * Description :- To verify Class Detail Page Navigation.
	 *
	 */
	public boolean verifyAddStudentsToClassNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		CommonUtility._scrollup();
		String StrPageHeader=WebDriverMain._getTextFromElement(AddStudentPageObjects(AddStudent_Classpage_Title));
		if (StrPageHeader.contains(Constants.AddStudentstoClassPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- AddButton_isVisible<br>
	 * Description :- To verify Add button is visible
	 */
	public boolean AddButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(AddStudentPageObjects(btnAdd)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- AddButton_isEnabled<br>
	 * Description :- To verify Add Button is enabled
	 *
	 */
	public boolean AddButton_isEnabled() throws IOException{
		WebElement delete = WebDriverMain._getElementWithWait(AddStudentPageObjects(btnAdd));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickAddButton<br>
	 * Description :- To click the Add button.
	 *
	 */
	public boolean clickAddButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(AddStudentPageObjects(btnAdd));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- AddButton_isVisible<br>
	 * Description :- To verify Add button is visible
	 */
	public boolean Verify_Progressbar_Visible() throws Exception{
		if (WebDriverMain._isElementVisible(AddStudentPageObjects(Progressbar)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- CancelButton_isVisible<br>
	 * Description :- To verify Cancel button is visible
	 *
	 */
	public boolean CancelButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(AddStudentPageObjects(btnCancel)))
			return true;
		else
			return false; 
	}
	
	
	/**
	 * Function Name :- CancelButton_isEnabled<br>
	 * Description :- To verify Cancel button is enabled
	 *
	 */
	public boolean CancelButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(AddStudentPageObjects(btnCancel));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	

	/**
	 * Function Name :- clickCancelButton<br>
	 * Description :- To click the Cacenl button.
	 *
	 */
	public boolean clickCancelButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(AddStudentPageObjects(btnCancel));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- verifyAlertMessage<br>
	 * Description :- To verify alert Message
	 * @throws IOException 
	 */
	public boolean verifyAlertMessage(String successmessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess=WebDriverMain._getTextFromElement(AddStudentPageObjects(Alert_Message));
		if(textSuccess.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}
	
	
	
	/**
	 * Function Name :- verifySuccessMessage<br>
	 * Description :- To verify Success Message
	 * @throws IOException 
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess=WebDriverMain._getTextFromElement(AddStudentPageObjects(Success_Message));
		if(textSuccess.toLowerCase().contains(successmessage.toLowerCase())){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Function Name :- clickClassDetilsBreadcrumb<br>
	 * Description :- To click Class Details Breadcrumb.
	 *
	 */
	public boolean clickClassDetilsBreadcrumb() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();	
			flag=LeftClick._click(AddStudentPageObjects(Breadcrumb_ClassDetails));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- Verify_Class_StudentList<br>
	 * Description :- To verify Class Student List is visible
	 *
	 */
	public boolean Verify_Class_StudentList() throws IOException{
		if (WebDriverMain._isElementVisible(AddStudentPageObjects(Class_StudentList_Section)))
		{
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(AddStudentPageObjects(Class_StudentList_Section));
			CommonUtility._scrollElement(elmStudentlst);
			return true;
		}
		else
			return false; 
	}
	
	/**
	 * Function Name :- Searchfill_StudName<br>
	 * Description :- To Fill Name Filter in Class details Page.
	 *
	 */
	public boolean Searchfill_StudName(String Studname) throws Exception {
		WebDriverMain._waitForElementClickable(AddStudentPageObjects(SearchInputFilter));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean flag =TextBox._setTextBox(AddStudentPageObjects(SearchInputFilter), Studname);
		CommonUtility._sleepForGivenTime(500);
		return flag;

	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Class Details Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(AddStudentPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean flag = WebDriverMain._isElementVisible(AddStudentPageObjects(SearchInputFilter));
		if (flag)
			flag=LeftClick._click(AddStudentPageObjects(searchicon));
		
		CommonUtility._sleepForGivenTime(2000);
		return flag;
	}
	
	/**
	 * Function Name :- getStudsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public HashMap<String, String> getStudsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() > 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-class-add-students//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(AddStudentPageObjects(StuDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	

	/**
	 * Function Name :- getStuColumnHeaderDetails<br>
	 * Description :- To get Students Col header Details.
	 *
	 */
	public List<String> getStuColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifyStusearchresultsDetails<br>
	 * Description :- To get Students search results Details.
	 *
	 */
	public List<String> verifyStusearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(AddStudentPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-add-students//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	
	/**
	 * Function Name :- verifyStuGridPagination<br>
	 * Description :- To verify Students grid pagination.
	 *
	 */
	public int verifyStuGridPagination() throws IOException {
		int maxpage=0;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		maxpage=KendoGrid.GetShowingMaxItems();		
		System.out.println("Stu Page : " + maxpage);
		if (maxpage>29) {
			//Select Next Page
			KendoGrid.SelectNextPage();
			lstOrgrRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
			System.out.println("Stu Next Row Count : " + lstOrgrRow.size());
			//Select First Page
			KendoGrid.SelectPreviousPage();
		}
		return maxpage;
	}
	
	/**
	 * Function Name :- verifyStudentSearchresultsSorting<br>
	 * Description :- To verify Student search results sorting .
	 * @throws Exception 
	 *
	 */
	public List<String> verifyStudentSearchresultsSorting(String ColName) throws Exception {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
		System.out.println("Student Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(AddStudentPageObjects(StuDatagridHeaderRow));
		if ((lstOrgrRow.size() >= 2)) {
			for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//pa-class-add-students//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						CommonFunctions.waitUntilLoadingSpinner(10);
						objlocator =CommonUtility._getObjectLocator("xpath=//pa-class-add-students//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	
	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> verifyStusearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(AddStudentPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-class-add-students//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-add-students//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.ClassFDStudID))) {
							String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.ClassFDStudID);
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyStudSearchresultsDetailsfromtext<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public List<String> verifyStudSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(AddStudentPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-add-students//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.ClassFDStudID))) {
						String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.ClassFDStudID);
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
					}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	

	/**
	 * Function Name :- SelectonStuCheckbox<br>
	 * Description :- To click Student Checkbox.
	 *
	 */
	public boolean SelectonStuCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> SelectonStuCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(AddStudentPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-class-add-students//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-add-students//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.ClassFDStudID))) {
							String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.ClassFDStudID);
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- clickonStudName<br>
	 * Description :- To click Student Name hyperlink.
	 *
	 */
	public boolean clickonStudName(String Studname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(AddStudentPageObjects(StuRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//td/a[contains(text(),'" + Studname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	

	/**
	 * Function Name :- Verify_SelectedStudentCount<br>
	 * Description :- To verify the Selected student count.
	 *
	 */
	public boolean Verify_SelectedStudentCount(String StuCount) throws IOException{
		if (WebDriverMain._isElementVisible(AddStudentPageObjects(SelectedStudentCount))) {
			if (WebDriverMain._getTextFromElement(AddStudentPageObjects(SelectedStudentCount)).contains(StuCount))
				return true;
			else
				return false;
			
		}
		else
			return false;
	
	}
	
	

}
