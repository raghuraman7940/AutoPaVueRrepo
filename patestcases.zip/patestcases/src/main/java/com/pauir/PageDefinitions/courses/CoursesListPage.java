package com.pauir.PageDefinitions.courses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pauir.common.core.CommonFunctions;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class CoursesListPage {

	public static String TableRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody";
	public static String CoursesListPage_verification = "xpath|.//h5[contains(text(),'Courses')]";
	public static String CoursesListTable = "xpath|//pa-course-list//kendo-grid//table/thead";
	public static String CoursesListPage_Title = "xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String CoursesList_Tab = "xpath|//pa-course-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Courses List')]";
	public static String CoursesActive_Tab = "xpath|//pa-course-tabs/kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
	public static String CourseDatagridHeaderRow = "xpath|//pa-course-list//kendo-grid//table/thead/tr/th";
	public static String SearchInputFilter = "xpath|//input[@placeholder=\"Search\"]";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String CourseRowPresent = "xpath|//pa-course-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String ImportCoursesTab = "xpath|//pa-course-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Import Courses')]";
	public static String ExportCoursesbtn = "xpath|//pa-course-list//button[contains(text(),'Export Courses')]";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String btnDelete="xpath|//button[contains(.,'Delete')]";
	public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String Progressbar="xpath|//pa-progress-bar/kendo-dialog/div[contains(@class,'k-dialog')]";
	public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
	
	public By CoursesListPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	public boolean waitforTableRecordsExist() throws IOException {
		if (WebDriverMain._isElementVisible(CoursesListPageObjects(TableRecords)))
			return true;
		else
			return false;
	}

	public boolean IsCoursesListTableExist() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementVisible(CoursesListPageObjects(CoursesListTable))) {
			waitforTableRecordsExist();
			return true;
		} else
			return false;
	}

	public boolean VerifyActiveTab(String ActiveTab) throws IOException {
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess = WebDriverMain._getTextFromElement(CoursesListPageObjects(CoursesActive_Tab));
		if (textSuccess.toLowerCase().contains(ActiveTab.toLowerCase())) {
			return true;
		} else {
			return false;
		}
	}

	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean flag = false;
		boolean iActiveflag = false;
		if (WebDriverMain._isElementPresent(CoursesListPageObjects(CoursesList_Tab))) {
			switch (TabOption.toLowerCase()) {
			case "courses list":
				iActiveflag = VerifyActiveTab(TabOption);
				if (!iActiveflag) {
					flag = LeftClick._click(CoursesListPageObjects(CoursesList_Tab));
					CommonUtility._sleepForGivenTime(1000);
				} else
					return true;
				break;
			case "import courses":
				iActiveflag = VerifyActiveTab(TabOption);
				if (!iActiveflag) {
					flag = LeftClick._click(CoursesListPageObjects(ImportCoursesTab));
					CommonUtility._sleepForGivenTime(1000);
				} else
					return true;
				break;
			default:
				flag = LeftClick._click(CoursesListPageObjects(CoursesList_Tab));
				CommonUtility._sleepForGivenTime(1000);
				break;
			}
		} else
			return false;

		iActiveflag = VerifyActiveTab(TabOption);
		if (iActiveflag) {
			return true;
		}
		return false;
	}

	public List<String> getCoursesColumnHeaderDetails() throws IOException {
		By objlocator = null;
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CoursesListPageObjects(CourseDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader = new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;

		// return MapDgOrgColHeader;
	}

	public boolean Searchfill_CourseName(String CourseName) throws Exception {

		boolean flag = WebDriverMain._isElementVisible(CoursesListPageObjects(SearchInputFilter));
		if (flag) {
			flag = TextBox._setTextBox(CoursesListPageObjects(SearchInputFilter), CourseName);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}

	public boolean clicksearchicon() throws Exception {

		boolean flag = WebDriverMain._isElementVisible(CoursesListPageObjects(SearchInputFilter));
		if (flag) {
			flag = LeftClick._click(CoursesListPageObjects(searchicon));
			CommonFunctions.waitUntilLoadingSpinner(10);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- hasCourseRecords<br>
	 * Description :- To check course records.
	 *
	 */
	public boolean hasCourseRecords() throws IOException {
		if (!WebDriverMain._isElementVisible(CoursesListPageObjects(NoRecords))) {
			return true;
		}
		return false;
	}

	public List<String> verifyCourseSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		String OrgName = null, OrgCode = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CoursesListPageObjects(CourseRowPresent));
		System.out.println("Course Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CoursesListPageObjects(CourseDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {

				MapDgOrgRec = new HashMap<String, String>();
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//pa-course-list//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td");
				List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
				for (int iCol = 0; iCol < dataRec.size(); iCol++) {
					String sDGColmnName = lstheaderRow.get(iCol).getText();
					String sDGColmnValue = dataRec.get(iCol).getText();
					MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
				}
				if (MapDgOrgRec.containsKey("Course Name")) {
					String SearchOrg = MapDgOrgRec.get("Course Name");
					if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
						MapDgOrgdetails.add(SearchOrg);

				}

			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	public boolean ClearSearchText() throws Exception {
		boolean flag = TextBox._setTextBox(CoursesListPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(500);
		return flag;
	}
	
	/**
	 * Function Name :- verifyCoursesResultsDetails<br>
	 * Description :- To get search results Details.
	 *
	 */
	public List<String> verifyCoursesResultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgUserdetails = null;
		HashMap<String, String> MapDgUserRec = null;
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(CoursesListPageObjects(CourseRowPresent));
		System.out.println("Courses Row Count : " + lstUserrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CoursesListPageObjects(CourseDatagridHeaderRow));
		if (lstUserrRow.size() >= 1) {
			MapDgUserdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgUserRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-course-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgUserdetails.add(MapDgUserRec.toString());
				}
				
			}
			return MapDgUserdetails;
		} else
			System.out.println("No record found");
		return MapDgUserdetails;
	}
	
	/**
	 * Function Name :- verifyExportCourses_isVisible<br>
	 * Description :- To verify Export Courses button is visible
	 *
	 */
	
	public boolean verifyExportCourses_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(CoursesListPageObjects(ExportCoursesbtn)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- clickExportCourses<br>
	 * Description :- To click on Export Courses button
	 *
	 */
	
	public boolean clickExportCourses() throws IOException{
		boolean flag=LeftClick._click(CoursesListPageObjects(ExportCoursesbtn));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- SelectCourseRecord<br>
	 * Description :- To select Course record results Details.
	 *
	 */
	public HashMap<String, String> SelectCourseRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CoursesListPageObjects(CourseRowPresent));
		System.out.println("Course Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(CoursesListPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-course-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(CoursesListPageObjects(CourseDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-course-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/button");
						WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
						if (tsElm!=null) {
							if (WebDriverMain._isElementClickable(tsElm)) {
								tsElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								return MapDgOrgRec;
							}
						}
						
							
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- SelectonCourseCheckbox<br>
	 * Description :- To verify course search results checkbox Details.
	 *
	 */
	public List<String> SelectonCourseCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CoursesListPageObjects(CourseRowPresent));
		System.out.println("Course Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CoursesListPageObjects(CourseDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(CoursesListPageObjects(NoRecords))){
				MapDgOrgdetails=new ArrayList<String>();
				MapDgdetails=new ArrayList<HashMap<String, String>>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-course-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
						if (WebDriverMain._isElementPresent(objlocator1)) {
							WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
							LeftClick.clickByWebElementJS(chbxele);
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-course-list//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							MapDgdetails.add(MapDgOrgRec);
							if (MapDgOrgRec.containsKey("Course Name")) {
								String SearchOrg=MapDgOrgRec.get("Course Name");
								MapDgOrgdetails.add(SearchOrg);
							}
						}
						else
						{
							return MapDgOrgdetails;
						}
					}
				}
				return MapDgOrgdetails;
			}
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifySelectedCourseInlist<br>
	 * Description :- To get Course search results Details.
	 *
	 */
	public List<String> verifySelectedCourseInlist(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CoursesListPageObjects(CourseRowPresent));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(CoursesListPageObjects(NoRecords))){
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-course-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td[2]");
						WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
						if (dataRec!=null) {
							String sDGStuName = dataRec.getText().trim();
							if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase()))
								MapDgOrgdetails.add(sDGStuName);
							//return MapDgOrgdetails;
						}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- DeleteButton_isVisible<br>
	 * Description :- To verify Delete button is visible
	 *
	 */
	public boolean DeleteButton_isVisible() throws IOException
	{
		if (WebDriverMain._isElementVisible(CoursesListPageObjects(btnDelete)))
			return true;
		else
			return false;
	}
	
	
	/**
	 * Function Name :- clickDeleteButton<br>
	 * Description :- To click Delete Button.
	 *
	 */
	public boolean clickDeleteButton() throws IOException{
		boolean flag=LeftClick._click(CoursesListPageObjects(btnDelete));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	/**
	 * Function Name :- GetSuccessMessage<br>
	 * Description :- To get Success Message
	 * @throws IOException 
	 */
	public String GetSuccessMessage() throws IOException{
		String textSuccess=null;
		try {
		 textSuccess=WebDriverMain._getTextFromElement(CoursesListPageObjects(Success_Message));
		}
		catch(Exception e) {
			return null;
		}
		return textSuccess;
	}
	/**
	 * Function Name :- verifySuccessMessage<br>
	 * Description :- To verify Success Message
	 * @throws IOException 
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess=WebDriverMain._getTextFromElement(CoursesListPageObjects(Success_Message));
		if(textSuccess.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Function Name :- waitForProgressbarVisible<br>
	 * Description :- To wait Progress bar is visible
	 */
	public boolean waitForProgressbarVisible(int maxtimeout) throws Exception{
		int count=0;
		while((WebDriverMain._isElementVisible(CoursesListPageObjects(Progressbar)))&&(count<maxtimeout))
		{
			CommonUtility._sleepForGivenTime(1000);
			count=count+1;
		}
		if (!WebDriverMain._isElementVisible(CoursesListPageObjects(Progressbar)))
			return true;
		else
			return false;
		
	}
	/**
	 * Function Name :- Close_Alerts<br>
	 * Description :- To close alert Message
	 * @throws IOException 
	 */
	public boolean Close_Alerts() throws IOException{
		List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(CoursesListPageObjects(CloseAlerts));
		for (WebElement AlertEle : lstAlertsRow) {
			if (WebDriverMain._isElementClickable(AlertEle)) {
				AlertEle.click();
			}
		}
		return true;
	}

}
