package com.pauir.PageDefinitions.dataimports;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;
import com.pauir.PageDefinitions.home.Home;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class DataImportPage {

	// Data Import page objects
	public static String DataImportpage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String lnkDownloadImport="xpath|//pa-grid-actions/button[contains(text(),'Download Initial Import')]";
	public static String lnkDownloadResults="xpath|//pa-grid-actions/button[contains(text(),'Download Results')]";
	public static String lnkDownloadExport="xpath|//pa-grid-actions/button[contains(text(),'Download Export')]";
	public static String DIRowPresent = "xpath|//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String DIDatagridHeaderRow = "xpath|//pa-batchnotification-list//kendo-grid//table/thead/tr/th";
	public static String SearchInputFilter = "xpath|//pa-batchnotification-list//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String SuccessMsg = "xpath|//pa-alerts//div[@role ='alert']/p/span";
	public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
	

	/**
	 * Function Name :- DataImportPageObjects<br>
	 * Description :- To set Data Import Page Objects locator.
	 * 
	 * @return By
	 */
	public By DataImportPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyDataImportsPageNavigation<br>
	 * Description :- To verify Data Import Page Navigation.
	 *
	 */
	public boolean verifyDataImportsPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(DataImportPageObjects(DataImportpage_Title)).contains(Constants.DataImportPageTitle))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- DownloadImport_isVisible<br>
	 * Description :- To verify DownloadImport button is visible
	 */
	public boolean DownloadImport_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(DataImportPageObjects(lnkDownloadImport)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- clickDownloadImportButton<br>
	 * Description :- To click the DownloadImport button.
	 *
	 */
	public boolean clickDownloadImportButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(DataImportPageObjects(lnkDownloadImport));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}


	/**
	 * Function Name :- DownloadResultsButton_isVisible<br>
	 * Description :- To verify DownloadResults button is visible
	 *
	 */
	public boolean DownloadResultsButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(DataImportPageObjects(lnkDownloadResults)))
			return true;
		else
			return false; 
	}


	/**
	 * Function Name :- clickDownloadResultsButton<br>
	 * Description :- To click the DownloadResults button.
	 *
	 */
	public boolean clickDownloadResultsButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(DataImportPageObjects(lnkDownloadResults));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	

	/**
	 * Function Name :- getColumnHeaderDetails<br>
	 * Description :- To get Column header Details.
	 *
	 */
	public List<String> getColumnHeaderDetails() throws IOException {
		List<String> MapDgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(DIDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgColHeader.add(sDGColmnName);
			}
		}
		return MapDgColHeader;
	}

	/**
	 * Function Name :- verifysearchresultsDetails<br>
	 * Description :- To get search results Details.
	 *
	 */
	public List<String> verifysearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgUserdetails = null;
		HashMap<String, String> MapDgUserRec = null;
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(DIRowPresent));
		System.out.println("Row Count : " + lstUserrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DataImportPageObjects(DIDatagridHeaderRow));
		if (lstUserrRow.size() >= 1) {
			MapDgUserdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgUserRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgUserdetails.add(MapDgUserRec.toString());
				}
				
			}
			return MapDgUserdetails;
		} else
			System.out.println("No record found");
		return MapDgUserdetails;
	}


	

	/**
	 * Function Name :- clickonTestlink<br>
	 * Description :- To click Test Name hyper link.
	 *
	 */
	public boolean SelectonUserCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(DIRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- SelectonImportCheckbox<br>
	 * Description :- To select search results checkbox Details.
	 *
	 */
	public List<String> SelectonImportCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(DIRowPresent));
		System.out.println("Sess Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DataImportPageObjects(DIDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey("Batch Number")) {
							String SearchOrg=MapDgOrgRec.get("Batch Number");
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	

	/**
	 * Function Name :- Searchfill_SearchText<br>
	 * Description :- To Fill Name Filter in Imports/Exports Page.
	 *
	 */
	public boolean Searchfill_SearchText(String SearchText) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(DataImportPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(DataImportPageObjects(SearchInputFilter), SearchText);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}

	/**
	 * Function Name :- hasImportlist<br>
	 * Description :- To get  search results Details.
	 *
	 */
	public boolean hasImportlist() throws IOException {
		boolean flag=false;
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(DIRowPresent));
		if (lstUserrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(DataImportPageObjects(NoRecords)))
				flag=true;	
		} 
		return flag;
	}
	
	/**
	 * Function Name :- verifysearchresultsDetailsfromtext<br>
	 * Description :- To get search results Details.
	 *
	 */
	public List<String> verifysearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgUserdetails = null;
		HashMap<String, String> MapDgUserRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(DIRowPresent));
		System.out.println("User Row Count : " + lstUserrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DataImportPageObjects(DIDatagridHeaderRow));
		if (lstUserrRow.size() >= 1) {
			MapDgUserdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
			
					MapDgUserRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgUserRec.containsKey("Batch Number")&&(MapDgUserRec.containsKey("Import Date / Time"))) {
						String SearchUser=MapDgUserRec.get("Batch Number")+" - "+MapDgUserRec.get("Import Date / Time");
						if (SearchUser.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgUserdetails.add(SearchUser);
						
					}
			
				
			}
			return MapDgUserdetails;
		} else
			System.out.println("No record found");
		return MapDgUserdetails;
	}
	
	/**
	 * Function Name :- verifySearchresultsSorting<br>
	 * Description :- To verify search results sorting .
	 *
	 */
	public List<String> verifySearchresultsSorting(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(DIRowPresent));
		System.out.println("Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(DataImportPageObjects(DIDatagridHeaderRow));
		if ((lstheaderRow.size() >= 1)&&(lstOrgrRow.size() >= 2)) {
			for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						objlocator =CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in User Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(DataImportPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}

	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks search icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {

		boolean flag = WebDriverMain._isElementVisible(DataImportPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(DataImportPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- verify DataImports ErrorMessage<br>
	 * Description :- To verify DataImports ErrorMessage
	 * @throws IOException 
	 */
	public boolean verify_errorMessge(String Errormessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
	    String textmessage=WebDriverMain._getTextFromElement(DataImportPageObjects(SuccessMsg));
		if(textmessage.contains(Errormessage)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Function Name :- Close_Alerts<br>
	 * Description :- To close alerts in DataImports
	 * @throws IOException 
	 */
	public boolean Close_Alerts() throws IOException{
		List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(CloseAlerts));
		for (WebElement AlertEle : lstAlertsRow) {
			if (WebDriverMain._isElementClickable(AlertEle)) {
				AlertEle.click();
			}
		}
		return true;
	}
	
	/**
	 * Function Name :- GetSuccessMessage<br>
	 * Description :- To get DataImports ErrorMessage
	 * @throws IOException 
	 */
	public String GetSuccessMessage() throws IOException{
		String textSuccess=null;
		try {
		 textSuccess=WebDriverMain._getTextFromElement(DataImportPageObjects(SuccessMsg));
		}
		catch(Exception e) {
			return null;
		}
		return textSuccess;
	}
	
	/**
	 * Function Name :- SelectonBatchCheckboxWithMatchedColValue<br>
	 * Description :- To select batchnotifications in search results checkbox Details.
	 *
	 */
	public List<String> SelectonBatchCheckboxWithMatchedColValue(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(DIDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(DataImportPageObjects(DIRowPresent));
				System.out.println("Batch Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					MapDgOrgdetails=new ArrayList<String>();
					MapDgdetails=new ArrayList<HashMap<String, String>>();
					if (!WebDriverMain._isElementVisible(DataImportPageObjects(NoRecords))) {
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
								MapDgOrgRec = new HashMap<String, String>();
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
								String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
								if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
									if (rowindex >= selectcnt) {
										//Select Matched Checkbox
										objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/input[contains(@type,'checkbox')]");
										WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
										if (chbxele!=null) {
											LeftClick.clickByWebElementJS(chbxele);
											objlocator = CommonUtility._getObjectLocator("xpath=//pa-batchnotification-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td[2]");
											String sDGSessValue = WebDriverMain._getTextFromElement(objlocator);
											MapDgOrgdetails.add(sDGSessValue);
											selectcnt=selectcnt+1;
										}
									}
								}	
						}
				return MapDgOrgdetails;
				}
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- DownloadExportButton_isVisible<br>
	 * Description :- To verify DownloadExport button is visible
	 *
	 */
	public boolean DownloadExportButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(DataImportPageObjects(lnkDownloadExport)))
			return true;
		else
			return false; 
	}

	/**
	 * Function Name :- clickDownloadExportButton<br>
	 * Description :- To click the DownloadExport button.
	 *
	 */
	public boolean clickDownloadExportButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(DataImportPageObjects(lnkDownloadExport));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
}
	