/**
 * Course Detail Page
 */
package com.pauir.PageDefinitions.courses;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.aventstack.extentreports.Status;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.KendoGrid;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class CourseDetailPage {
	// Course Details page objects
	public static String CourseDetailspage_Title = "xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String btnEdit = "xpath|.//a/span[contains(text(),'Edit')]";
	public static String CourseHeader_Section = "xpath|//pa-course-edit//div[@class='card-header']";
	public static String Course_ClassList_Section = "xpath|//kendo-tabstrip/ul/li[contains(.,'Class List')]";
	public static String Course_ClasstList = "xpath|//pa-course-edit//kendo-grid//kendo-grid-list";
	public static String LastUpdated = "xpath|//pa-course-edit//span[contains(text(),'Last Modified')]";

	// Class List page objects
	public static String btnAddClass = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Add')]";
	public static String btnRemoveClass = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Remove')]";
	public static String btnDelete = "xpath|.//button[contains(text(),'Delete')]";
	public static String ClassRowPresent = "xpath|//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String ClassDatagridHeaderRow = "xpath|//pa-course-edit//kendo-grid//table/thead/tr/th";
	public static String SearchInputFilter = "xpath|//pa-course-edit//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String SaveBtn = "xpath|//button[contains(text(),'Save')]";

	// Student list page object
	public static String Course_StudentList_Section = "xpath|//kendo-tabstrip/ul/li[contains(.,'Student List')]";
	public static String StuRowPresent = "xpath|//pa-course-student-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String StuDatagridHeaderRow = "xpath|//pa-course-student-list//kendo-grid//table/thead/tr/th";
	public static String StudentRowPresent = "xpath|//pa-course-student-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String StudentDatagridHeaderRow = "xpath|//pa-course-student-list//kendo-grid//table/thead/tr/th";

	/**
	 * Function Name :- CourseDetailPageObjects<br>
	 * Description :- To set Class Details Page Objects locator.
	 * 
	 * @return By
	 */
	public By CourseDetailPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	/**
	 * Function Name :- verifyCourseDetailsNavigation<br>
	 * Description :- To verify Course Detail Page Navigation.
	 *
	 */
	public boolean verifyCourseDetailsNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(CourseDetailPageObjects(CourseDetailspage_Title))
				.contains(Constants.CourseDetailPageTitle))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify edit button is visible
	 *
	 */
	public boolean EditButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(CourseDetailPageObjects(btnEdit)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- EditButton_isEnabled<br>
	 * Description :- To verify Edit button is enabled
	 *
	 */
	public boolean EditButton_isEnabled() throws IOException {
		WebElement delete = WebDriverMain._getElementWithWait(CourseDetailPageObjects(btnEdit));
		String attributeText = delete.getAttribute("innerHTML");
		if (attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit button.
	 *
	 */
	public boolean clickEditButton() throws IOException {
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
		boolean flag = LeftClick._click(CourseDetailPageObjects(btnEdit));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- Verify_CourseHeader_Section<br>
	 * Description :- To verify Course Header section is visible
	 *
	 */
	public boolean Verify_CourseHeader_Section() throws IOException {
		if (WebDriverMain._isElementVisible(CourseDetailPageObjects(CourseHeader_Section)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- Verify_Course_ClassList<br>
	 * Description :- To verify Course Class List is visible
	 *
	 */
	public boolean Verify_Course_ClassList() throws IOException {
		if (WebDriverMain._isElementVisible(CourseDetailPageObjects(Course_ClassList_Section))) {
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(CourseDetailPageObjects(LastUpdated));
			if (WebDriverMain._isElementVisible(elmStudentlst)) {
				CommonUtility._scrollElement(elmStudentlst);
				return true;
			}
			return true;
		} else
			return false;

	}

	/**
	 * Function Name :- verifyViewCourseDetails<br>
	 * Description :- To verify the view Course details Page
	 * 
	 * @throws IOException
	 */
	public boolean verifyViewCourseDetails(HashMap<String, String> MapFilledField) throws IOException {
		boolean verifedFlag = true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try {

			By objlocator = null;
			for (Map.Entry<String, String> entry : MapFilledField.entrySet()) {
				System.out.println("INFO ViewMap - Fields  : " + entry.getKey());
				String sFieldLabel = entry.getKey();
				String sFieldValue = entry.getValue();

				if (sFieldLabel.length() > 1) {

					if (sFieldLabel.toLowerCase().contains("teachers")) {
						sFieldLabel = "Teacher(s)";
						String lines[] = sFieldValue.split("\\r?\\n");
						sFieldValue = lines[0];
					}
					// Class Name value is present without label
					if (sFieldLabel.toLowerCase().contains("class name")) {
						sFieldLabel = "";
					}
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-course-edit//label[contains(text(),'" + sFieldLabel + "')]");
					boolean isFieldLabelPresent = WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if (sFieldValue.length() > 1) {

							MapDgStuRec.put(sFieldLabel, sFieldValue);
							if (sFieldLabel.length() < 1)
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-course-edit//h2[contains(text(),'" + sFieldValue + "')]");
							else
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-course-edit//span[contains(text(),'" + sFieldValue + "')]");
							boolean isFieldValuePresent = WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								verifedFlag = false;
								UMReporter.log(Status.FAIL, "The field " + sFieldLabel
										+ " not matched with expected value : " + sFieldValue);
							}
						}
					}
				}
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}

		if (verifedFlag)
			UMReporter.log(Status.PASS,
					"User have access to view the Class field value in Class details page :" + MapDgStuRec);
		return verifedFlag;
	}

	/**
	 * Function Name :- verifyCourseName<br>
	 * Description :- To verify the Course name in Course details Page
	 * 
	 * @throws IOException
	 */
	public boolean verifyCourseName(String ClsName) throws IOException {
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//pa-course-edit//h2[contains(text(),'" + ClsName + "')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;

	}

	/**
	 * Function Name :- verifyLastUpdatedLabel<br>
	 * Description :- To verify the last updated on Class details page form.
	 *
	 */
	public String verifyLastUpdatedLabel() throws IOException {
		String LstUpdatedDate = null;
		if (WebDriverMain._isElementVisible(CourseDetailPageObjects(LastUpdated))) {
			LstUpdatedDate = WebDriverMain._getTextFromElement(CourseDetailPageObjects(LastUpdated));
			return LstUpdatedDate;
		} else
			return LstUpdatedDate;
	}

	/**
	 * Function Name :- verifyCourseHeaderLabel<br>
	 * Description :- To verify the label on Course Header details page.
	 *
	 */
	public boolean verifyCourseHeaderLabel(String labelmessage) throws IOException {
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//pa-course-edit//label[contains(text(),'" + labelmessage + "')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- Searchfill_ClassName<br>
	 * Description :- To Fill Class Name Filter in Course details Page.
	 *
	 */
	public boolean Searchfill_ClassName(String Classname) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(CourseDetailPageObjects(SearchInputFilter));
		if (flag) {
			flag = TextBox._setTextBox(CourseDetailPageObjects(SearchInputFilter), Classname);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}

	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Course Details Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag = TextBox._setTextBox(CourseDetailPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}

	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks Search icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {

		boolean flag = WebDriverMain._isElementVisible(CourseDetailPageObjects(SearchInputFilter));
		if (flag) {
			flag = LeftClick._click(CourseDetailPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}

	/**
	 * Function Name :- getClasssearchresultsDetails<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public HashMap<String, String> getClasssearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		System.out.println("Class Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(CourseDetailPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex == Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(CourseDetailPageObjects(ClassDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

	/**
	 * Function Name :- getClassColumnHeaderDetails<br>
	 * Description :- To get Class list Col header Details.
	 *
	 */
	public List<String> getClassColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CourseDetailPageObjects(ClassDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader = new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- getClassSearchresultsDetails<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public boolean hasClasslist() throws IOException {
		boolean flag = false;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(CourseDetailPageObjects(NoRecords)))
				flag = true;
		} else
			flag = false;
		return flag;
	}

	/**
	 * Function Name :- verifyClasssearchresultsDetails<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public List<String> verifyClasssearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		System.out.println("Class Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CourseDetailPageObjects(ClassDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}

			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- verifyClassGridPagination<br>
	 * Description :- To verify Class grid pagination.
	 *
	 */
	public int verifyClassGridPagination() throws IOException {
		int maxpage = 0;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		System.out.println("Class Row Count : " + lstOrgrRow.size());
		maxpage = KendoGrid.GetMaxPageNum();
		System.out.println("Class Page : " + maxpage);
		if (maxpage > 29) {
			// Select Next Page
			KendoGrid.SelectNextPage();
			lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
			System.out.println("Class Next Row Count : " + lstOrgrRow.size());
			// Select First Page
			KendoGrid.SelectFirstPage();
		}
		return maxpage;
	}

	/**
	 * Function Name :- verifyClasssearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> verifyClasssearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CourseDetailPageObjects(ClassDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			// if have Records
			if (!WebDriverMain._isElementVisible(CourseDetailPageObjects(NoRecords))) {

				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator(
								"xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
										+ "]/td/label[contains(@class,'k-checkbox-label')]");
						WebElement chbxele = WebDriverMain._getElementWithWait(objlocator1);
						if (chbxele != null) {
							objlocator = CommonUtility._getObjectLocator(
									"xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
											+ "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							if (MapDgOrgRec.containsKey(Constants.FDStudName)
									&& (MapDgOrgRec.containsKey(Constants.ClassFDStudID))) {
								String SearchOrg = MapDgOrgRec.get(Constants.FDStudName) + " - "
										+ MapDgOrgRec.get(Constants.ClassFDStudID);
								MapDgOrgdetails.add(SearchOrg);
							}
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- verifyStudSearchresultsDetailsfromtext<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public List<String> verifyClassSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CourseDetailPageObjects(ClassDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			// if have Records
			if (!WebDriverMain._isElementVisible(CourseDetailPageObjects(NoRecords))) {

				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgOrgRec.containsKey(Constants.FDStudName)
							&& (MapDgOrgRec.containsKey(Constants.ClassFDStudID))) {
						String SearchOrg = MapDgOrgRec.get(Constants.FDStudName) + " - "
								+ MapDgOrgRec.get(Constants.ClassFDStudID);
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- verifyClassSearchresultsDetailsfromtext<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public List<String> verifyClassSearchresultsDetailsfromlist(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			// if have Records
			if (!WebDriverMain._isElementVisible(CourseDetailPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td[2]");
					WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
					if (dataRec != null) {
						String sDGStuName = dataRec.getText().trim();
						if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase()))
							MapDgOrgdetails.add(sDGStuName);
						// return MapDgOrgdetails;
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- SelectonClassCheckbox<br>
	 * Description :- To click Student Checkbox.
	 *
	 */
	public boolean SelectonClassCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator("xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm != null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> SelectonClassCheckbox(int rowindex) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CourseDetailPageObjects(ClassDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			MapDgdetails = new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility
							._getObjectLocator("xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele = WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele != null) {
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey(Constants.FDStudName)
								&& (MapDgOrgRec.containsKey(Constants.ClassFDStudID))) {
							String SearchOrg = MapDgOrgRec.get(Constants.FDStudName) + " - "
									+ MapDgOrgRec.get(Constants.ClassFDStudID);
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- clickonClassName<br>
	 * Description :- To click Class Name hyperlink.
	 *
	 */
	public boolean clickonClassName(String Classname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator("xpath=//button[contains(text(),'" + Classname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (tsElm != null) {
				if (WebDriverMain._isElementClickable(tsElm)) {
					tsElm.click();
					CommonFunctions.PleaseWaitAndLoadingMessage();
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Function Name :- AddClassButton_isVisible<br>
	 * Description :- To verify AddClass button is visible
	 */
	public boolean AddClassButton_isVisible() throws Exception {
		if (WebDriverMain._isElementVisible(CourseDetailPageObjects(btnAddClass)))
			return true;
		else
			return false;

	}

	/**
	 * Function Name :- AddClassButton_isEnabled<br>
	 * Description :- To verify AddClass button is enabled
	 *
	 */
	public boolean AddClassButton_isEnabled() throws IOException {
		WebElement delete = WebDriverMain._getElementWithWait(CourseDetailPageObjects(btnAddClass));
		String attributeText = delete.getAttribute("innerHTML");
		if (attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- clickAddClassButton<br>
	 * Description :- To click the Add Classes button.
	 *
	 */
	public boolean clickAddClassButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(CourseDetailPageObjects(btnAddClass));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}

	/**
	 * Function Name :- RemoveClassesButton_isVisible<br>
	 * Description :- To verify Remove Classes button is visible
	 */
	public boolean RemoveClassesButton_isVisible() throws Exception {
		if (WebDriverMain._isElementVisible(CourseDetailPageObjects(btnRemoveClass)))
			return true;
		else
			return false;

	}

	/**
	 * Function Name :- RemoveClassesButton_isEnabled<br>
	 * Description :- To verify Remove Classes button is enabled
	 *
	 */
	public boolean RemoveClassesButton_isEnabled() throws IOException {
		WebElement delete = WebDriverMain._getElementWithWait(CourseDetailPageObjects(btnRemoveClass));
		String attributeText = delete.getAttribute("innerHTML");
		if (attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- clickRemoveClassesButton<br>
	 * Description :- To click the Remove Classes button.
	 *
	 */
	public boolean clickRemoveClassesButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(CourseDetailPageObjects(btnRemoveClass));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}

	/**
	 * Function Name :- deleteButton_isVisible<br>
	 * Description :- To verify delete button is visible
	 *
	 */
	public boolean deleteButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(CourseDetailPageObjects(btnDelete)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- deleteButton_isEnabled<br>
	 * Description :- To verify delete button is enabled
	 *
	 */
	public boolean deleteButton_isEnabled() throws IOException {
		WebElement delete = WebDriverMain._getElementWithWait(CourseDetailPageObjects(btnDelete));
		String attributeText = delete.getAttribute("innerHTML");
		if (attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- SelectCourseClassRecord<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public HashMap<String, String> SelectCourseClassRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(ClassRowPresent));
		System.out.println("Class Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(CourseDetailPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(CourseDetailPageObjects(ClassDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}

						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-course-edit//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
										+ "]/td/button");
						WebElement tsElm = WebDriverMain._getElementWithWait(objlocator);
						if (tsElm != null) {
							if (WebDriverMain._isElementClickable(tsElm)) {
								tsElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								return MapDgOrgRec;
							}
						}

						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

	/**
	 * Function Name :- clickSaveButton<br>
	 * Description :- To click the Save Class button.
	 *
	 */
	public boolean clickSaveButton() throws IOException {

		CommonUtility._scrollup();
		boolean flag = LeftClick._click(CourseDetailPageObjects(SaveBtn));
		CommonUtility._sleepForGivenTime(4000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- VerifyActiveTab<br>
	 * Description :- To verify Active Tab
	 * 
	 * @throws IOException
	 */
	public boolean VerifyActiveTab(String ActiveTab) throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess = WebDriverMain._getTextFromElement(CourseDetailPageObjects(Course_ClassList_Section));
		if (textSuccess.toLowerCase().contains(ActiveTab.toLowerCase())) {
			return true;
		} else {
			return false;
		}
	}

	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean flag = false;
		boolean iActiveflag = false;
		if (WebDriverMain._isElementPresent(CourseDetailPageObjects(Course_ClassList_Section))) {
			switch (TabOption.toLowerCase()) {
			case "class list":
				iActiveflag = VerifyActiveTab(TabOption);
				if (!iActiveflag) {
					flag = LeftClick._click(CourseDetailPageObjects(Course_ClassList_Section));
					CommonUtility._sleepForGivenTime(1000);
				} else
					return true;
				break;
			case "student list":
				iActiveflag = VerifyActiveTab(TabOption);
				if (!iActiveflag) {
					flag = LeftClick._click(CourseDetailPageObjects(Course_StudentList_Section));
					CommonUtility._sleepForGivenTime(1000);
				} else
					return true;
				break;
			default:
				flag = LeftClick._click(CourseDetailPageObjects(Course_ClassList_Section));
				CommonUtility._sleepForGivenTime(1000);
				break;
			}
		} else
			return false;

		if (flag) {
			return true;
		}
		return false;
	}

	/**
	 * Function Name :- Verify_Course_StudentList<br>
	 * Description :- To verify Course Student List is visible
	 *
	 */
	public boolean Verify_Course_StudentList() throws IOException {

		WebElement elmStudentlst = WebDriverMain
				._getElementWithWait(CourseDetailPageObjects(Course_StudentList_Section));
		if (WebDriverMain._isElementVisible(elmStudentlst)) {
			CommonUtility._scrollElement(elmStudentlst);
			return true;
		}

		else {
			return false;
		}

	}

	/**
	 * Function Name :- verifyStudentsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public List<String> verifyStudentsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(StudentRowPresent));
		System.out.println("Student Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CourseDetailPageObjects(StudentDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-course-student-list//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
									+ "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}

			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- clickonStudName<br>
	 * Description :- To click Student Name hyperlink.
	 *
	 */
	public boolean clickonStudName(String Studname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(StuRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator("xpath=//td/button[contains(text(),'" + Studname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}

	/**
	 * Function Name :- getStudentColumnHeaderDetails<br>
	 * Description :- To get Student list Col header Details.
	 *
	 */
	public List<String> getStudentColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(CourseDetailPageObjects(ClassDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader = new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- getStudsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public HashMap<String, String> getStudsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(CourseDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-course-student-list//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
									+ "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(CourseDetailPageObjects(StuDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;

	}

}
