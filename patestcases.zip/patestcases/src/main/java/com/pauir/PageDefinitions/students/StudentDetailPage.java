/**
 * StudentDetailPage
 */
package com.pauir.PageDefinitions.students;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.home.Home;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class StudentDetailPage {
	// Initialize
	Login login = new Login(WebDriverMain._getDriver());
	CommonFunctions common;
	Home home = new Home();

	// Student Details page objects
	public static String StudentDetailpage_verification="xpath|.//h5[contains(text(),'Student Details')]";
	public static String StudentDetailspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String btnEdit="xpath|//a/span[contains(text(),'Edit')]";
	public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Home')]";
	public static String Breadcrumb_StudentList = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Students')]";
	
	public static String StudentInfo_Section="xpath|//pa-student-edit//span[contains(text(),'Last updated')]";
	public static String StudentDemographics_Section="xpath|//pa-student-edit//h2[contains(text(),'Demographics')]";
	public static String StudentEnrollment_Section="xpath|//pa-student-edit//h3[contains(text(),'Enrolled')]";
	public static String StudentStatus_Section="xpath|//pa-student-edit//h2";
	public static String StudentLastUpdated="xpath|//pa-student-edit//span[contains(text(),'Last updated')]";
	public static String StudentLastNameField="xpath|//pa-student-edit//form//label[contains(text(),'Student Last Name')]";
	public static String Inline_Message="xpath|//pa-alerts//div[@role='alert']//span";
	public static String Error_Message="xpath|//pa-alerts//div[@role='alert']//span";
	public static String Error_Contents="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String OrganizationList="xpath|//pa-student-edit//h3[contains(text(),'Enrolled')]/../../ul/div/li";	
	
	public static String StudentSessionList_Section="xpath|//pa-student-edit//h2[contains(text(),'Session List')]";
	public static String SearchInputFilter = "xpath|//pa-student-edit//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String SessionRowPresent = "xpath|//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String SessionDatagridHeaderRow = "xpath|//pa-student-edit//kendo-grid//table/thead/tr/th";
	public static String SessionList="xpath|.//kendo-grid//table/thead/tr[1]/th[1]";
	public static String TableRecords="xpath|//kendo-grid//kendo-grid-list//table/tbody";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	
	public static String StudentsDet_Tab = "xpath|//pa-student-edit//kendo-tabstrip/ul/li";
	public static String SessionList_Tab = "xpath|//pa-student-edit//kendo-tabstrip/ul/li/span[contains(text(),'Session List')]";
	public static String ClassList_Tab = "xpath|//pa-student-edit//kendo-tabstrip/ul/li/span[contains(text(),'Class List')]";
	public static String StudDetActive_Tab = "xpath|//pa-student-edit//kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
	public static String ReportPage_Title="xpath|//pa-session-reports/h2";
	public static String Breadcrumb_StudentDetail = "xpath|//pa-breadcrumb//div[contains(@class,'btn')][contains(.,'Student Details')]";
	public static String ReportSpinner="xpath|//app-root/app-isr-layout//div[contains(@class,'spinner-cell')]";
	public static String ISRReportData="xpath|//app-student-isr//div[@id='item1Header']";
	
	
	public static String studentdetailspage="xpath|//pa-student-edit//div[contains(@class,'card-header')]//span[contains(text(),'Last updated')]";
	
	public static String studentinfoexpandup="xpath|//pa-student-edit//div[contains(@class,'card-header')]//span[contains(text(),'Last updated')]/../..//i[contains(@class,'fa-angle-up')]";
	public static String studentinfocollapsedown="xpath|//pa-student-edit//div[contains(@class,'card-header')]//span[contains(text(),'Last updated')]/../..//i[contains(@class,'fa-angle-down')]";
	public static String studentinfobody="xpath|//pa-student-edit//div[contains(@class,'card-header')]//span[contains(text(),'Last updated')]/../../../../div[contains(@class,'card-body')]";
	
	public static String studentdemographicsexpandup="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Demographics')]/../../..//i[contains(@class,'fa-angle-up')]";
	public static String studentdemographicscollapsedown="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Demographics')]/../../..//i[contains(@class,'fa-angle-down')]";
	public static String studentdemographicsbody="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Demographics')]/../../../../div[contains(@class,'card-body')]";
	
	public static String studentaccom="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]";
	public static String studentaccomexpandup="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]/../../..//i[contains(@class,'fa-angle-up')]";
	public static String studentaccomcollapsedown="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]/../../..//i[contains(@class,'fa-angle-down')]";
	public static String studentaccombody="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]/../../../../div[contains(@class,'card-body')]";
	
	public static String btnReportingSchool = "xpath|//div[@role='tabpanel']//pa-grid-actions//button[contains(text(),'Update Reporting School')]";
	public static String btnReportingSchool_MenuOptions = "xpath|//div[@class='popover-body']//button";
	
	public static String btnReassignTest = "xpath|//a/span[contains(text(),'Reassign Test')]";
	public static String RT_ModalWindow = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog/div[contains(@class,'k-dialog')]";
	public static String RT_ModalWindowTitle = "xpath|//pa-student-edit/pa-student-merge//kendo-dialog-titlebar//h3";
	public static String RT_ModalWindowNotes = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//div[contains(@class,'k-dialog-content')]/div";
	public static String RT_StudentList = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid[@pastudentdatabinding]";
	
	public static String RT_StudentTestList = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid[@pastudentprofilesessiondatabindingdirective]";
	public static String RT_StuRowPresent = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String RT_StuDatagridHeaderRow = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid//table/thead/tr/th";
	public static String RT_StuList="xpath|//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid//table/thead/tr[1]/th[1]";
	public static String RT_NoRecords = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String RT_SearchInputFilter = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//input[@placeholder='Search']";
	public static String RT_searchicon = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//i[@class='fa fa-search']";
	public static String RT_BtnNext = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//kendo-dialog-actions/button[contains(text(),'Next')]";
	public static String RT_BtnCancel = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//kendo-dialog-actions/button[contains(text(),'Cancel')]";
	public static String RT_BtnReassign = "xpath|//pa-student-edit/pa-student-merge/kendo-dialog//kendo-dialog-actions/button[contains(text(),'Reassign')]";
	  
	/**
	 * Function Name :- StudentDetailPageObjects<br>
	 * Description :- To set Student Details Page Objects locator.
	 * 
	 * @return By
	 */
	public By StudentDetailPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyStudentDetailsNavigation<br>
	 * Description :- To verify Student Detail Page Navigation.
	 *
	 */
	public boolean verifyStudentDetailsNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(StudentDetailPageObjects(StudentDetailspage_Title)).contains(Constants.StudentDetailsPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify edit button is visible
	 *
	 */
	public boolean verifyStudentDetails() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentdetailspage)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify edit button is visible
	 *
	 */
	public boolean EditButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(btnEdit)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- EditButton_isEnabled<br>
	 * Description :- To verify Edit button is enabled
	 *
	 */
	public boolean EditButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(StudentDetailPageObjects(btnEdit));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- Verify_Student_Info<br>
	 * Description :- To verify Student info button is visible
	 *
	 */
	public boolean Verify_Student_Info() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(StudentInfo_Section)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_Student_Enrollment<br>
	 * Description :- To verify Student info button is visible
	 *
	 */
	public boolean Verify_Student_Enrollment() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(StudentEnrollment_Section)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_Student_Demographics<br>
	 * Description :- To verify Student demographics button is visible
	 *
	 */
	public boolean Verify_Student_Demographics() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(StudentDemographics_Section)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- verifyViewStudentDetails<br>
	 * Description :- To verify the view  Student details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewStudentDetails(HashMap<String,String> MapFilledStuTestField) throws IOException{
		boolean verifedFlag=true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledStuTestField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            
	            if (sFieldLabel.length()>1) {
		            if (sFieldLabel.equalsIgnoreCase("School")) {
		            	sFieldLabel="School(s) Enrolled";
		            }
		            objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//label[contains(text(),'"+sFieldLabel+"')]");
					boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if(sFieldValue.length()>1) { 
							MapDgStuRec.put(sFieldLabel, sFieldValue);
							if (sFieldLabel.equalsIgnoreCase("Organization")) {
								CommonUtility._scrolldown();
								List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(OrganizationList));
				            	if (lstOrgrRow!=null) {
				            		for(WebElement OrgEnEle:lstOrgrRow) {
				            			String FieldValuePresent=OrgEnEle.getText();
				            			if (FieldValuePresent.contains(sFieldValue)) 
				            				verifedFlag=true;
				            		}		
		            				if (!verifedFlag) 
										UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);		
				            	}
				            }
							else if (sFieldLabel.equalsIgnoreCase("Accom")) {
							
				            }
							else {
//								if ((sFieldLabel.equalsIgnoreCase("First Name"))||(sFieldLabel.equalsIgnoreCase("Last Name")))
//									objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//p[contains(text(),'"+sFieldValue+"')]");
//								else	
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//span[contains(text(),'"+sFieldValue+"')]");
								
								boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
								if (!isFieldValuePresent) {
									verifedFlag=false;
									UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
								}
							}
						}
					}
	            }
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		
		if (verifedFlag)
			UMReporter.log(Status.PASS,"User have access to View the Student field value in Student details page :"+MapDgStuRec);
		return verifedFlag;
	}
	
	
	/**
	 * Function Name :- verifyViewStudentAccomodations<br>
	 * Description :- To verify the view  Student Accommodations Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewStudentAccomodations(HashMap<String,String> MapFilledStuTestField) throws IOException{
		boolean verifedFlag=true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try{
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledStuTestField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            if ((sFieldLabel.length()>1)&&(sFieldLabel.contains(" - "))) {
	            	String AccomSubjectSplit[]=sFieldLabel.split(" - ");
		            objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//label[contains(text(),'"+AccomSubjectSplit[0].trim()+"')]");
					boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if(sFieldValue.length()>1) { 
							MapDgStuRec.put(sFieldLabel, sFieldValue);
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//label[contains(text(),'"+AccomSubjectSplit[0].trim()+"')]/following-sibling::ul/li/span[contains(text(),'"+sFieldValue+"')]/strong[contains(text(),'"+AccomSubjectSplit[1].trim()+"')]");
							boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								verifedFlag=false;
								UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
							}
						}
					}
	            }
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		
		if (verifedFlag)
			UMReporter.log(Status.PASS,"User have access to View the Student Accommodations field value in Student details page :"+MapDgStuRec);
		return verifedFlag;
	}
	
	
	/**
	 * Function Name :- verifyStudentName<br>
	 * Description :- To verify the student name in  Student details Page 
	 * @throws IOException 
	 */	
	public boolean verifyStudentName(String StudName) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//h2[contains(text(),'"+StudName+"')]");
		if (WebDriverMain._isElementPresent(objlocator))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- verifyLastUpdatedLabel<br>
	 * Description :- To verify the last updated on Student details page form.
	 *
	 */
	public String verifyLastUpdatedLabel() throws IOException{
		String LstUpdatedDate=null;
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(StudentLastUpdated))) {
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(StudentDetailPageObjects(StudentLastUpdated));
			LstUpdatedDate=elmStudentlst.getText();
			CommonUtility._scrollElement(elmStudentlst);
			return LstUpdatedDate;
		}
		else
			return LstUpdatedDate;
	}
	
	
	/**
	 * Function Name :- verifyEditFormFirstField<br>
	 * Description :- To verify the last updated on Student details page form.
	 *
	 */
	public String verifyEditFormFirstField() throws IOException{
		String LstUpdatedDate=null;
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(StudentLastNameField))) {
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(StudentDetailPageObjects(StudentLastNameField));
			LstUpdatedDate=elmStudentlst.getText();
			CommonUtility._scrollElement(elmStudentlst);
			return LstUpdatedDate;
		}
		else
			return LstUpdatedDate;
	}
	
	/**
	 * Function Name :- verifyStudentLabel<br>
	 * Description :- To verify the Student label on Student details page form.
	 *
	 */
	public boolean verifyStudentLabel(String labelmessage) throws IOException{
		By objlocator =null;
		if (labelmessage.contains("Enrolled"))
			objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//h3[contains(text(),'"+labelmessage+"')]");
		else
			objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//label[contains(text(),'"+labelmessage+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- GetValueforStudentLabel<br>
	 * Description :- To get the value for label on Student details page form.
	 *
	 */
	public String GetValueforStudentLabel(String labelmessage) throws IOException{
		String LabelValue=null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//label[contains(text(),'"+labelmessage+"')]/./following-sibling::span");
		if (WebDriverMain._isElementPresent(objlocator)) {
			LabelValue=WebDriverMain._getTextFromElement(objlocator);
			return LabelValue;
			
		}
		return LabelValue;
	}
	
	/**
	 * Function Name :- GetValueforStudentOrganiztionLabel<br>
	 * Description :- To get the value for label on Student details page form.
	 *
	 */
	public String GetValueforStudentOrganiztionLabel(String labelmessage) throws IOException{
		String LabelValue=null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//h3[contains(text(),'"+labelmessage+"')]/./../../ul/div/li");
		if (WebDriverMain._isElementVisible(objlocator)) {
			LabelValue=WebDriverMain._getTextFromElement(objlocator);
			return LabelValue;
		
		}
		return LabelValue;
	}
	
	/**
	 * Function Name :- clickStudentListBreadcrumb<br>
	 * Description :- To click Student List Breadcrumb.
	 *
	 */
	public boolean clickStudentListBreadcrumb() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			flag=LeftClick._click(StudentDetailPageObjects(Breadcrumb_StudentList));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	/**
	 * Function Name :- verifyFailureMessage<br>
	 * Description :- To verify the failure message on Student page form.
	 *
	 */
	public boolean verifyFailureMessage(String failuremessage) throws IOException{
		String text1=WebDriverMain._getTextFromElement(StudentDetailPageObjects(Error_Contents));
		if(text1.contains(failuremessage)){
			//Log._logInfo("Successfully Verify error message");
			return true;
		}else
			return false;
	}
	
	/**
	 * Function Name :- verifyErrorMessage<br>
	 * Description :- To verify the error message on Create User page form.
	 *
	 */
	public boolean verifyErrorMessage(String FieldLabel) throws IOException{
		String ErrorText=WebDriverMain._getTextFromElement(StudentDetailPageObjects(Error_Message));
		if (ErrorText.length()>1) {
			System.out.println("Error Message: "+ErrorText);
			if(ErrorText.contains(Constants.UPDATESTUDENTFAILUREMESSAGE)){
				return true;
			}else
				UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" has the actual error message :" +ErrorText);
				return false;
		}
		else
		{
			UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" error mesage is not displayed");
		}
		return false;
	}
	
	/**
	 * Function Name :- Verify_Student_SessionList<br>
	 * Description :- To verify Student Session List  is visible
	 *
	 */
	public boolean Verify_Student_SessionList() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(SessionList_Tab)))
		{
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(StudentDetailPageObjects(StudentEnrollment_Section));
			CommonUtility._scrollElement(elmStudentlst);
			return true;
		}
		else
			return false; 
	}
	
	/**
	 * Function Name :- Searchfill_SessName<br>
	 * Description :- To Fill Name Filter in Student details Page.
	 *
	 */
	public boolean Searchfill_SessionName(String Sessname) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(StudentDetailPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(StudentDetailPageObjects(SearchInputFilter), Sessname);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Class Details Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(StudentDetailPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		
		boolean flag = WebDriverMain._isElementVisible(StudentDetailPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(StudentDetailPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- clickonSessionName<br>
	 * Description :- To click Session Name hyperlink.
	 *
	 */
	public boolean clickonSessionName(String Sessionname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(SessionRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//button[contains(text(),'" + Sessionname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	

	/**
	 * Function Name :- getSessionSearchresultsDetails<br>
	 * Description :- To get Session search results Details.
	 *
	 */
	public HashMap<String, String> getSessionSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(SessionRowPresent));
		System.out.println("Sessions Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(NoRecords))){
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex == Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(StudentDetailPageObjects(SessionDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						return MapDgOrgRec;
					}
				}
			}
		}
		else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	

	/**
	 * Function Name :- getSessionColumnHeaderDetails<br>
	 * Description :- To get Session table Column headers.
	 *
	 */
	public List<String> getSessionColumnHeaderDetails() throws IOException {
		By objlocator = null;
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(SessionDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	
		//return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifySessionSearchresultsDetails<br>
	 * Description :- To verify Session search results Details.
	 *
	 */
	public List<String> verifySessionSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(SessionRowPresent));
		System.out.println("Session Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentDetailPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	

	/**
	 * Function Name :- verifySessionSearchresultsSorting<br>
	 * Description :- To verify Session search results sorting .
	 *
	 */
	public List<String> verifySessionSearchresultsSorting(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(SessionRowPresent));
		System.out.println("Session Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentDetailPageObjects(SessionDatagridHeaderRow));
		if ((lstheaderRow.size() >= 1)&&(lstOrgrRow.size() > 2)) {
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						objlocator =CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	/**
	 * Function Name :- verifySessionSearchresultsDetailsfromtext<br>
	 * Description :- To verify Session search results Details.
	 *
	 */
	public List<String> verifySessionSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		String OrgName=null,OrgCode=null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(SessionRowPresent));
		System.out.println("Session Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentDetailPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
			
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgOrgRec.containsKey("Session Name")) {
						String SearchOrg=MapDgOrgRec.get("Session Name");
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
						
					}
					
					
				
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- SelectTabOption<br>
	 * Description :- Select the Tab options
	 * 
	 * @param TabOption
	 * @throws IOException
	 */
	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean flag=false;
		boolean iActiveflag=false;
		if (WebDriverMain._isElementPresent(StudentDetailPageObjects(StudentsDet_Tab))) {
			switch (TabOption.toLowerCase()) {
				case "session list":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						flag=LeftClick._click(StudentDetailPageObjects(SessionList_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				case "class list":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						flag=LeftClick._click(StudentDetailPageObjects(ClassList_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				default:
					flag=LeftClick._click(StudentDetailPageObjects(SessionList_Tab));
					CommonUtility._sleepForGivenTime(1000);
					break;
			}
		}
		else
			return false;
		
		iActiveflag=VerifyActiveTab(TabOption);
		if (iActiveflag) {
			return true;
		}
		return false;


	}
	
	/**
	 * Function Name :- VerifyActiveTab<br>
	 * Description :- To verify Active Tab
	 * @throws IOException 
	 */
	public boolean VerifyActiveTab(String ActiveTab) throws IOException{
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess=WebDriverMain._getTextFromElement(StudentDetailPageObjects(StudDetActive_Tab));
		if(textSuccess.toLowerCase().contains(ActiveTab.toLowerCase())){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Function Name :- Verify_Student_ClassList<br>
	 * Description :- To verify Student Class List  is visible
	 *
	 */
	public boolean Verify_Student_ClassList() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(ClassList_Tab)))
		{
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(StudentDetailPageObjects(StudentEnrollment_Section));
			CommonUtility._scrollElement(elmStudentlst);
			return true;
		}
		else
			return false; 
	}
	
	/**
	 * Function Name :- SelectViewISRReport<br>
	 * Description :- To select View ISR Report in Session list .
	 *
	 */
	public HashMap<String, String> SelectViewISRReport() throws IOException {
		By objlocator,objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(SessionRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentDetailPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(NoRecords))){
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/button[contains(.,'View ISR')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						//Click View ISR
						LeftClick._click(chbxele);
						return MapDgOrgRec;
					}
				}
				return MapDgOrgRec;
			}
		}
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- verifyReportNavigation<br>
	 * Description :- To verify ISR Report Page Navigation.
	 *
	 */
	public boolean verifyReportNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(StudentDetailPageObjects(ReportPage_Title)).contains(Constants.ISRReportPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- clickStudentDetailsBreadcrumb<br>
	 * Description :- To click Student Details Breadcrumb.
	 *
	 */
	public boolean clickStudentDetailsBreadcrumb() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			flag=LeftClick._click(StudentDetailPageObjects(Breadcrumb_StudentDetail));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- waitForSpinnerVisible<br>
	 * Description :- To wait Spinner bar is visible
	 */
	public boolean waitForSpinnerVisible(int maxtimeout) throws Exception{
		int count=0;
		while((WebDriverMain._isElementVisible(StudentDetailPageObjects(ReportSpinner)))&&(count<maxtimeout))
		{
			CommonUtility._sleepForGivenTime(1000);
			count=count+1;
		}
		if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(ReportSpinner)))
			return true;
		else
			return false;
		
	}
	
	/**
	 * Function Name :- verifyViewReportDetails<br>
	 * Description :- To verify the view  Report details Page 
	 * @throws IOException 
	 */	
	public HashMap<String, String> verifyViewReportDetails(HashMap<String,String> MapFilledField) throws IOException{
		HashMap<String, String> MapDgOrgRec = null;
		try{
			String ReportData=WebDriverMain._getTextFromElement(StudentDetailPageObjects(ISRReportData));
			if (ReportData.length()>10) {
				for (Map.Entry<String,String> entry : MapFilledField.entrySet()){
					MapDgOrgRec = new HashMap<String, String>();
		            String sFieldLabel= entry.getKey();
		            String sFieldValue= entry.getValue();
		            if (sFieldValue.length()>=1) 
		            	if(ReportData.contains(sFieldValue))
		            		MapDgOrgRec.put(sFieldLabel, sFieldValue);
				}
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- Verify_StudentHasSessions<br>
	 * Description :- To verify Student Class List  is visible
	 *
	 */
	public boolean Verify_StudentHasSessions() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(NoRecords)))
			return false;
		else
			return true; 
	}
	
	/**
	 * Function Name :- verifySessionHyperlink<br>
	 * Description :- To verify Session hyperlink to view details.
	 *
	 */
	public List<String> verifySessionHyperlink(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(SessionRowPresent));
		System.out.println("Session Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentDetailPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(NoRecords))){
				MapDgOrgdetails=new ArrayList<String>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td[1]/button");
						if (WebDriverMain._isElementPresent(objlocator)) {
							MapDgOrgdetails.add(MapDgOrgRec.toString());
						}
						
					}
					
				}
				return MapDgOrgdetails;
		}
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	/**
	 * Function Name :- StudentInfoExpand<br>
	 * Description :- To Expand/Collapse this Student Info.
	 *
	 */
	public boolean StudentInfoExpand(String strValue) throws IOException{
		boolean flag=false;
		try {
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
				if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentinfoexpandup))) {
					if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentinfobody)))
						return true;//Display session info if collapse
				}
				else if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentinfocollapsedown))){
					flag = LeftClick._click(StudentDetailPageObjects(studentinfocollapsedown));
					CommonUtility._sleepForGivenTime(1000);
					if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentinfobody)))
						return true;//Display session info if collapse
				}
			}
			else {
				if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentinfocollapsedown))) {
					if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(studentinfobody)))
						return true;//Not display session info if collapse
				}
				else if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentinfoexpandup))){
					flag = LeftClick._click(StudentDetailPageObjects(studentinfoexpandup));
					CommonUtility._sleepForGivenTime(1000);
					if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(studentinfobody)))
						return true; //Not display session info if collapse
				}
				
			}
					

		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- StudentDemographicsBladeExpand<br>
	 * Description :- To Expand/Collapse the Student Demographics Blade.
	 *
	 */
	public boolean StudentDemographicsBladeExpand(String strValue) throws IOException{
		boolean flag=false;
		try {
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
				if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentdemographicsexpandup))) {
					if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentdemographicsbody)))
						return true;//Display session info if collapse
				}
				else if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentdemographicscollapsedown))){
					flag = LeftClick._click(StudentDetailPageObjects(studentdemographicscollapsedown));
					CommonUtility._sleepForGivenTime(1000);
					if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentdemographicsbody)))
						return true;//Display session info if collapse
				}
			}
			else {
				if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentdemographicscollapsedown))) {
					if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(studentdemographicsbody)))
						return true;//Not display session info if collapse
				}
				else if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentdemographicsexpandup))){
					flag = LeftClick._click(StudentDetailPageObjects(studentdemographicsexpandup));
					CommonUtility._sleepForGivenTime(1000);
					if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(studentdemographicsbody)))
						return true; //Not display session info if collapse
				}
				
			}
					

		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- Verify_Student_Info_Blade<br>
	 * Description :- To verify Student Infp info section is visible
	 *
	 */
	public boolean Verify_Student_Info_Blade() throws IOException{
		if (WebDriverMain._isElementPresent(StudentDetailPageObjects(studentinfobody)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_Student_Demographics_Blade<br>
	 * Description :- To verify Student Demographics info section is visible
	 *
	 */
	public boolean Verify_Student_Demographics_Blade() throws IOException{
		if (WebDriverMain._isElementPresent(StudentDetailPageObjects(studentdemographicsbody)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- StudentAccommodationBladeExpand<br>
	 * Description :- To Expand/Collapse the Student Accommodation Blade.
	 *
	 */
	public boolean StudentAccommodationBladeExpand(String strValue) throws IOException{
		boolean flag=false;
		try {
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
				if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentaccomexpandup))) {
					if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentaccombody)))
						return true;//Display session info if collapse
				}
				else if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentaccomcollapsedown))){
					flag = LeftClick._click(StudentDetailPageObjects(studentaccomcollapsedown));
					CommonUtility._sleepForGivenTime(1000);
					if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentaccombody)))
						return true;//Display session info if collapse
				}
			}
			else {
				if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentaccomcollapsedown))) {
					if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(studentaccombody)))
						return true;//Not display session info if collapse
				}
				else if (WebDriverMain._isElementVisible(StudentDetailPageObjects(studentaccomexpandup))){
					flag = LeftClick._click(StudentDetailPageObjects(studentaccomexpandup));
					CommonUtility._sleepForGivenTime(1000);
					if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(studentaccombody)))
						return true; //Not display session info if collapse
				}
			}
		 }
		 catch(Exception e) {
		 		return false;
		}
		return flag;
	}
	
	/**
	 * Function Name :- Verify_Student_Accommodations_Blade<br>
	 * Description :- To verify StudentAccomodations info section is visible
	 *
	 */
	public boolean Verify_Student_Accommodations_Blade() throws IOException{
		if (WebDriverMain._isElementPresent(StudentDetailPageObjects(studentaccombody)))
			return true;
		else
			return false; 
	}
	

	/**
	 * Function Name :- verifyEditStudentAccomTitle<br>
	 * Description :- To verify Student Detail Accomodation Page Navigation.
	 *
	 */
	public boolean verifyEditStudentAccomTitle() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementPresent(StudentDetailPageObjects(studentaccombody)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- SelectonSessionCheckbox<br>
	 * Description :- To select Session checkbox.
	 *
	 */
	public List<String> SelectonSessionCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(SessionRowPresent));
		System.out.println("Sess Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentDetailPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					if (WebDriverMain._isElementPresent(objlocator1)) {
						WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
						if (chbxele!=null) {
							LeftClick.clickByWebElementJS(chbxele);
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							MapDgdetails.add(MapDgOrgRec);
							if (MapDgOrgRec.containsKey("Session Name")&&(MapDgOrgRec.containsKey("School"))) {
								String SearchOrg=MapDgOrgRec.get("Session Name")+" - "+MapDgOrgRec.get("School");
								MapDgOrgdetails.add(SearchOrg);
							}
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- updateReportingSchool_isVisible<br>
	 * Description :- To verify Update Reporting School button is visible
	 *
	 */
	public boolean updateReportingSchool_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(btnReportingSchool)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- GetReportingSchoolList<br>
	 * Description :- To Get Reporting school for student
	 *
	 */
	public List<String> GetReportingSchoolList() throws IOException {
		List<String> MapDgColValues = null;
		try {
			if (LeftClick._click(StudentDetailPageObjects(btnReportingSchool))) {
				CommonUtility._sleepForGivenTime(2000);
				if (WebDriverMain._isElementVisible(StudentDetailPageObjects(btnReportingSchool_MenuOptions))) {
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(btnReportingSchool_MenuOptions));
					MapDgColValues = new ArrayList<String>();
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgColValues.add(sDGColmnValue);
					}
				}
				LeftClick._click(StudentDetailPageObjects(btnReportingSchool));
			}
		} catch (Exception e) {
			return MapDgColValues;
		}
		return MapDgColValues;
	}
	
	/**
	 * Function Name :- SelectReportingSchoolFromList<br>
	 * Description :- To select Reporting School from list.
	 *
	 */
	public boolean SelectReportingSchoolFromList(String Schoolname) throws IOException {
		boolean flag = false;
		try {
			if (WebDriverMain._isElementVisible(StudentDetailPageObjects(btnReportingSchool))) {
				LeftClick._click(StudentDetailPageObjects(btnReportingSchool));
				CommonUtility._sleepForGivenTime(2000);
				if (WebDriverMain._isElementVisible(StudentDetailPageObjects(btnReportingSchool_MenuOptions))) {
					List<WebElement> dataRec = WebDriverMain
							._getElementsWithWait(StudentDetailPageObjects(btnReportingSchool_MenuOptions));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnValue = dataRec.get(iCol).getText();
						if (sDGColmnValue.toLowerCase().contains(Schoolname.toLowerCase())) {
							dataRec.get(iCol).click();
							flag = true;
							return flag;
						}
					}
				}
				LeftClick._click(StudentDetailPageObjects(btnReportingSchool));
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}
	
	/**
	 * Function Name :- verifySessRepSchoolfromlist<br>
	 * Description :-To verify Session Reporting School from results Details.
	 */
	public HashMap<String, String> verifySessRepSchoolfromlist(int rowindex, String ColName, String MatchValues)
			throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		// Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentDetailPageObjects(SessionDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			// Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter = iCol + 1;
				List<WebElement> lstOrgrRow = WebDriverMain
						._getElementsWithWait(StudentDetailPageObjects(SessionRowPresent));
				System.out.println("Session Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(NoRecords))) {
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							MapDgOrgRec = new HashMap<String, String>();
							if (rowindex >= rowindex) {
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td[" + datacounter + "]");
								String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
								if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
									// Select Matched Checkbox
									objlocator = CommonUtility._getObjectLocator(
											"xpath=//pa-student-edit//kendo-grid//kendo-grid-list//table/tbody/tr["
													+ Irow + "]/td[2]");
									String sDGStudNameValue = WebDriverMain._getTextFromElement(objlocator);
									if (MapDgOrgRec.containsKey(sDGStudNameValue))
										MapDgOrgRec.put(sDGStudNameValue + "|" + Irow, sDGColmnValue);
									else
										MapDgOrgRec.put(sDGStudNameValue, sDGColmnValue);
									

								}
							}
						}
						return MapDgOrgRec;

					} else
						System.out.println("No record found");

				} else
					System.out.println("No record found");
			}
		}
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- ReassignTestButton_isVisible<br>
	 * Description :- To verify ReassignTest button is visible
	 *
	 */
	public boolean ReassignTestButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(btnReassignTest)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- clickReassignTest<br>
	 * Description :- To click Reassign Tests.
	 *
	 */
	public boolean clickReassignTest() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			flag=LeftClick._click(StudentDetailPageObjects(btnReassignTest));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- Verify_ReassignTestWindow<br>
	 * Description :- To verify Reassign Test Window is visible
	 *
	 */
	public boolean Verify_ReassignTestWindow() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(RT_ModalWindow)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_ReassignTestWindowTitle<br>
	 * Description :- To verify the ReassignTestWindowTitle.
	 *
	 */
	public boolean Verify_ReassignTestWindowTitle(String titlemessage) throws IOException{
		try {
			String text1=WebDriverMain._getTextFromElement(StudentDetailPageObjects(RT_ModalWindowTitle));
			if(text1.contains(titlemessage))
				return true;
		}
		catch(Exception e) {
	 		return false;
		}
		return false;
	}
	
	/**
	 * Function Name :- Verify_ReassignTestWindowTitleNotes<br>
	 * Description :- To verify the ReassignTestWindowTitle.
	 *
	 */
	public boolean Verify_ReassignTestWindowTitleNotes(String titlemessage) throws IOException{
		try {
			String text1=WebDriverMain._getTextFromElement(StudentDetailPageObjects(RT_ModalWindowNotes));
			if(text1.contains(titlemessage))
				return true;
		}
		catch(Exception e) {
	 		return false;
		}
		return false;
	}

	/**
	 * Function Name :- Verify_ReassignTest_StudentList<br>
	 * Description :- To verify Reassign Test StudentList Table is visible
	 *
	 */
	public boolean Verify_ReassignTest_StudentList() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(RT_StudentList)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_ReassignTest_StudentTestList<br>
	 * Description :- To verify Reassign Test Student Test List Table is visible
	 *
	 */
	public boolean Verify_ReassignTest_StudentTestList() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(RT_StudentTestList)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- NextButton_isVisible<br>
	 * Description :- To verify Next button is visible
	 *
	 */
	public boolean NextButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(StudentDetailPageObjects(RT_BtnNext)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- NextButton_isEnabled<br>
	 * Description :- To verify Next button is enabled
	 *
	 */
	public boolean NextButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(StudentDetailPageObjects(RT_BtnNext));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickNextButton<br>
	 * Description :- To click Next Button.
	 *
	 */
	public boolean clickNextButton() throws IOException{
		boolean flag=false;
		try {
			flag=LeftClick._click(StudentDetailPageObjects(RT_BtnNext));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- clickReassignButton<br>
	 * Description :- To click Reassign Button.
	 *
	 */
	public boolean clickReassignButton() throws IOException{
		boolean flag=false;
		try {
			flag=LeftClick._click(StudentDetailPageObjects(RT_BtnReassign));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(3000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- clickCancelButton<br>
	 * Description :- To click Cancel Button.
	 *
	 */
	public boolean clickCancelButton() throws IOException{
		boolean flag=false;
		try {
			flag=LeftClick._click(StudentDetailPageObjects(RT_BtnCancel));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	
	/**
	 * Function Name :- getStuColumnHeaderDetails<br>
	 * Description :- To get Students Col header Details.
	 *
	 */
	public List<String> getStuColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(RT_StuDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}

	
	/**
	 * Function Name :- SelectonStuCheckbox<br>
	 * Description :- To select Students checkbox Details.
	 *
	 */
	public HashMap<String, String> SelectonStuCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(RT_StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentDetailPageObjects(RT_StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(RT_NoRecords))) {
				MapDgOrgdetails=new ArrayList<String>();
				MapDgdetails=new ArrayList<HashMap<String, String>>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
						if (WebDriverMain._isElementPresent(objlocator1)) {
							WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
							if (chbxele!=null) {
								LeftClick.clickByWebElementJS(chbxele);
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td");
								List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
								for (int iCol = 0; iCol < dataRec.size(); iCol++) {
									String sDGColmnName = lstheaderRow.get(iCol).getText();
									String sDGColmnValue = dataRec.get(iCol).getText();
									MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
								}
							}
						}
					}
				}
				return MapDgOrgRec;
			}
		}else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

	
	/**
	 * Function Name :- SelectonStuCheckbox<br>
	 * Description :- To select Students checkbox Details.
	 *
	 */
	public List<HashMap<String, String>> SelectonStuTestSessionCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(StudentDetailPageObjects(RT_StuRowPresent));
		System.out.println("Stu Test Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(StudentDetailPageObjects(RT_StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(StudentDetailPageObjects(RT_NoRecords))) {
				MapDgdetails=new ArrayList<HashMap<String, String>>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
						if (WebDriverMain._isElementPresent(objlocator1)) {
							WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
							if (chbxele!=null) {
								LeftClick.clickByWebElementJS(chbxele);
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit/pa-student-merge/kendo-dialog//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td");
								List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
								for (int iCol = 0; iCol < dataRec.size(); iCol++) {
									String sDGColmnName = lstheaderRow.get(iCol).getText();
									String sDGColmnValue = dataRec.get(iCol).getText();
									MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
								}
								MapDgdetails.add(MapDgOrgRec);
							}
						}
					}
				}
				return MapDgdetails;
			}
		}else
			System.out.println("No record found");
		return MapDgdetails;
	}
	
	
	/**
	 * Function Name :- GetMoveFromConfirmReassignment<br>
	 * Description :- To get the MoveFrom ConfirmReassignmen form.
	 *
	 */
	public String GetMoveFromConfirmReassignment() throws IOException{
		String LabelValue=null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit/pa-student-merge/kendo-dialog//div[contains(@class,'k-dialog-content')]/div/div[1]");
		if (WebDriverMain._isElementPresent(objlocator)) {
			LabelValue=WebDriverMain._getTextFromElement(objlocator);
			return LabelValue;
		}
		return LabelValue;
	}
	
	/**
	 * Function Name :- GetMoveToConfirmReassignment<br>
	 * Description :- To get the MoveTo ConfirmReassignmen form.
	 *
	 */
	public String GetMoveToConfirmReassignment() throws IOException{
		String LabelValue=null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-student-edit/pa-student-merge/kendo-dialog//div[contains(@class,'k-dialog-content')]/div/div[3]");
		if (WebDriverMain._isElementPresent(objlocator)) {
			LabelValue=WebDriverMain._getTextFromElement(objlocator);
			return LabelValue;
		}
		return LabelValue;
	}
}
