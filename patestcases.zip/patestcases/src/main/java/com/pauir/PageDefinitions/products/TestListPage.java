package com.pauir.PageDefinitions.products;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class TestListPage {

	public static String TestListTable = "xpath|//pa-product-type-test-list//kendo-grid//table/thead";
	public static String SearchInputFilter = "xpath|//input[@placeholder=\"Search\"]";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String TableRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody";
	public static String TestListPage_Title = "xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String TestListPage_SubTitle = "xpath|.//pa-product-type-test-tabs/h3";
	public static String TestRowPresent = "xpath|//pa-product-type-test-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String TestDatagridHeaderRow = "xpath|//pa-product-type-test-list//kendo-grid//table/thead/tr/th";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String testRowPresent = "xpath|//pa-product-type-test-list//table/tbody/tr";
	public static String testDatagridHeaderRow = "xpath|//pa-product-type-test-list//table/thead/tr/th";

	public By TestListPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	public boolean verifyTestListPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(TestListPageObjects(TestListPage_Title))
				.contains(Constants.ViewTestListPageTitle))
			return true;
		else
			return false;
	}

	public String verifyTestListSubtitle() throws IOException {

		return WebDriverMain._getTextFromElement(TestListPageObjects(TestListPage_SubTitle));
	}

	public boolean IsTestListTableExist() throws IOException {
		if (WebDriverMain._isElementVisible(TestListPageObjects(TestListTable))) {
			waitforTableRecordsExist();
			return true;
		} else
			return false;
	}

	public boolean Searchfill_TestName(String TestName) throws Exception {

		boolean flag = WebDriverMain._isElementVisible(TestListPageObjects(SearchInputFilter));
		if (flag) {
			flag = TextBox._setTextBox(TestListPageObjects(SearchInputFilter), TestName);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}

	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Test Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag = TextBox._setTextBox(TestListPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(500);
		return flag;
	}

	public boolean hasTestlist() throws IOException {
		boolean flag = false;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(TestListPageObjects(TestRowPresent));
		if (lstOrgrRow.size() >= 1) {
			// if have Records
			if (!WebDriverMain._isElementVisible(TestListPageObjects(NoRecords)))
				flag = true;
		}
		return flag;
	}

	public boolean clicksearchicon() throws IOException {

		boolean flag = WebDriverMain._isElementVisible(TestListPageObjects(SearchInputFilter));
		if (flag) {
			flag = LeftClick._click(TestListPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		return flag;
	}

	public HashMap<String, String> getTestSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(TestListPageObjects(TestRowPresent));
		System.out.println("Tests Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-product-type-test-list//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
									+ "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(TestListPageObjects(TestDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

	/**
	 * Function Name :- waitforTableRecordsExist<br>
	 * Description :- To wait Table list to load
	 *
	 */
	public boolean waitforTableRecordsExist() throws IOException {
		if (WebDriverMain._isElementVisible(TestListPageObjects(TableRecords)))
			return true;
		else
			return false;
	}

	public boolean Searchfill_testName(String testName) throws Exception {

		boolean flag = WebDriverMain._isElementVisible(TestListPageObjects(SearchInputFilter));
		if (flag) {
			flag = TextBox._setTextBox(TestListPageObjects(SearchInputFilter), testName);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}

	public List<String> verifyTestSearchresultsDetailsfromtext(String searchText) throws Exception {
		By objlocator = null;
		String OrgName = null, OrgCode = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(TestListPageObjects(testRowPresent));
		System.out.println("Tests Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(TestListPageObjects(testDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {

				MapDgOrgRec = new HashMap<String, String>();
				objlocator = CommonUtility
						._getObjectLocator("xpath=//pa-product-type-test-tabs//table/tbody/tr[" + Irow + "]/td");
				List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
				for (int iCol = 0; iCol < dataRec.size(); iCol++) {
					String sDGColmnName = lstheaderRow.get(iCol).getText();
					String sDGColmnValue = dataRec.get(iCol).getText();
					MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
				}
				if (MapDgOrgRec.containsKey("Test")) {
					String SearchOrg = MapDgOrgRec.get("Test");
					if (SearchOrg.toLowerCase().contains(searchText.toLowerCase()))
						MapDgOrgdetails.add(SearchOrg);

				}

			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	public List<String> verifyTestSearchresultsSorting(String ColName) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(TestListPageObjects(testRowPresent));
		System.out.println("Test Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(TestListPageObjects(testDatagridHeaderRow));
		if ((lstheaderRow.size() >= 1) && (lstOrgrRow.size() >= 2)) {
			for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues = new ArrayList<String>();
					int datacounter = iCol + 1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 = CommonUtility
								._getObjectLocator("xpath=//pa-product-type-test-list//table/thead/tr/th[" + datacounter
										+ "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-product-type-test-list//kendo-grid//kendo-grid-list//table/tbody/tr/td[" + datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	
	/**
	 * Function Name :- SelectTestRecord<br>
	 * Description :- To select Test record results Details.
	 *
	 */
	public HashMap<String, String> SelectTestRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(TestListPageObjects(TestRowPresent));
		System.out.println("Test Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(TestListPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-product-type-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(TestListPageObjects(testDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-product-type-test-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/button");
						WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
						if (tsElm!=null) {
							if (WebDriverMain._isElementClickable(tsElm)) {
								tsElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								return MapDgOrgRec;
							}
						}
						
							
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

}