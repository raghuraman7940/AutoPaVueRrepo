/**
 * DRSHome page
 */
package com.pauir.PageDefinitions.home;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.testDataTypes.Userfield;
import com.pauir.common.util.Constants;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.UMReporter;
import webdriver.main.KendoDropdown;
import webdriver.main.WebDriverMain;

public class DRSHome {
	/*
	 * // Initialize variable WebDriver driver; CommonFunctions common;
	 */
	public static String LEA_MenuSelection="//div[@class='section-name menu-group required control-label text-dark']";
	/*
	 * public static String USERDROPDOWN =
	 * "xpath|//div[@id='navbarContentUser']//kendo-dropdownbutton/button[@role='menu']/span[contains(@class,'fa fa-user')]"
	 * ; public static String Logout = "xpath|//span[contains(text(),'Sign out')]";
	 * 
	 */
	public static String USERDROPDOWN = "xpath|//button[contains(@class,'k-button-icon k-button k-flat')]";
	public static String Logout = "xpath|//span[@class='btn'][contains(.,'Sign out')]";
	public static String Menuoption_Home = "xpath|//div[contains(text(),'REPORTING HOME')]";
	public static String HomeComponent = "xpath|//app-dynamic-report-layout/div[contains(.,'REPORTING HOME')]";
	public static String btnGetReport = "xpath|//app-dynamic-report-layout//button[contains(.,' Get Report')]";
	
	/**
	 * Constructor Description :- To initialize the values.
	 * 
	 * @return boolean
	 */
	public DRSHome() {

		// PageFactory.initElements(driver, this);
	}

	/**
	 * Function Name :- HomePageObjects<br>
	 * Description :- To set homepage page locator.
	 * 
	 * @return By
	 */
	public By HomePageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	/**
	 * Function Name :- clickGetReportButton<br>
	 * Description :- To click the Get Report Button.
	 * @throws Exception 
	 *
	 */
	public void ClickGetReportButton() throws Exception{
		CommonUtility._scrolldown();
		CommonUtility._sleepForGivenTime(500);
		WebDriverMain._waitForElementClickable(HomePageObjects(btnGetReport));
		LeftClick._click(HomePageObjects(btnGetReport));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.waitUntilCreatingLoadingSpinner(10);
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify the Edit Student Button.
	 *
	 */
	public boolean GetReportButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(HomePageObjects(btnGetReport)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- GetReportButton_isEnabled<br>
	 * Description :- To verify Create Student Button is enabled
	 *
	 */
	public boolean GetReportButton_isEnabled() throws IOException{
		WebElement eleGetRep = WebDriverMain._getElementWithWait(HomePageObjects(btnGetReport));
		String attributeText = eleGetRep.getAttribute("outerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- VerifyLoggedinHomePage<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean WaitDRSHomePage() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementVisible(HomePageObjects(HomeComponent))) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean VerifyMenuOtion(String Primary) throws IOException {
		boolean MenuFlag=false;
		
		CommonUtility._sleepForGivenTime(5000);
		/*objlocator =CommonUtility._getObjectLocator("xpath=//div[@class='section-name menu-group required control-label text-dark'][contains(.,'LEA')]");
		//LeftClick._click(objlocator);*/
		By objlocator =null;
		switch (Primary.toLowerCase()) {
			case "lea":
				objlocator = CommonUtility._getObjectLocator("xpath=//div[@class='section-name menu-group required control-label text-dark'][contains(.,'LEA')]");
				LeftClick._click(objlocator);
				break;
			case "subject":
				objlocator = CommonUtility._getObjectLocator("xpath=//div[@class='section-name menu-group required control-label text-dark'][contains(.,'Subject')]");
				LeftClick._click(objlocator);
				break;
			case "academicyear":
				objlocator = CommonUtility._getObjectLocator("xpath=//div[@class='section-name menu-group required control-label text-dark'][contains(.,'Academic Year')]");
				LeftClick._click(objlocator);
				break;
			case "reporttype":
				//app-dynamic-report-layout//app-left-menu//div[contains(@class,'menu-container')]/div[contains(@class,'filter-section')][2]/div
				By objlocator1 = CommonUtility._getObjectLocator("xpath=//app-dynamic-report-layout//app-left-menu//div[contains(@class,'menu-container')]/div[contains(@class,'filter-section')]/div/b[contains(.,'WHAT')]");
				WebElement WidEle=WebDriverMain._getElementWithWait(objlocator1);
				CommonUtility._scrollElement(WidEle);
				objlocator = CommonUtility._getObjectLocator("xpath=//div[@class='section-name menu-group required control-label text-dark'][contains(.,'Report Type')]");
				LeftClick._click(objlocator);
				break;
				
		
		
	}
		if (objlocator!=null)
			MenuFlag=WebDriverMain._isElementPresent(objlocator);  

		return MenuFlag;
	}
	/**
	 * Function Name :- DRS website Logout<br>
	 * Description :- To Click logout from user dropdown.
	 *
	 */
	public boolean Logout() throws IOException {
		LeftClick._click(HomePageObjects(USERDROPDOWN));
		if (WebDriverMain._isElementPresent(HomePageObjects(USERDROPDOWN))) {
			LeftClick._click(HomePageObjects(Logout));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	
	
}
