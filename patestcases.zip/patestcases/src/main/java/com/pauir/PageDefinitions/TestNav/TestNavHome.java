package com.pauir.PageDefinitions.TestNav;

/**
 * Home  page
 */

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class TestNavHome {

	// Home page locators
	public static String HOME = "xpath|//pa-context-bar/div/pa-title/span[@class='d-inline-block']";
	public static String HomeComponent = "xpath|//pa-home/span";
	public static String WelcomeName = "xpath|//div[@id='content']//div[contains(@class,'alert')]//h2";
	public static String USERICON = "xpath|//div[@id='userMenu']//button[@id='menuDrop']";
	public static String Logout = "xpath|//ul[@id='userMenuDropDown']/li/a[@id='dropdown_logout']";
	public static String UserName = "xpath|//div[@id='userName']/span";
	public static String BtnSelect = "xpath|//div[@id='content']//div[@class='settings-container']//button[contains(text(),'Select')]";
	public static String BtnStart = "xpath|//div[@id='content']//button[contains(text(),'Start')]";
	public static String BtnResume = "xpath|//div[@id='content']//button[contains(text(),'Resume')]";
	public static String TestName = "xpath|//div[@id='content']//div[contains(@class,'startTestCell ')]/span";
	public static String BtnStartSection = "xpath|//div[@id='section-start']//button[contains(text(),'Start')]";
	public static String Progressbar = "xpath|//div[@id='progress-title']";
	public static String lstBtnReview = "xpath|//div[@id='btnOverview']/button/span[contains(text(),'Review')]";
	public static String lstReviewOptions = "xpath|//div[@class='review-dropdown']//div[@role='menu']/div[@role='menuitem']";
	public static String BtnNext = "xpath|//div[@class='container']//button[@id='btnNext']";
	public static String BtnPrevious = "xpath|//div[@class='container']//button[@id='btnPrevious']";
	public static String lstReviewEndOptions = "xpath|//div[@class='review-dropdown']//div[@role='menu']/div[@role='menuitem'][contains(text(),'End of Section')]";
	public static String BtnSubmitFinal = "xpath|//div[@id='section-end']//button[contains(text(),'Submit Final Answers')]";
	public static String SubmitMsg = "xpath|//div[@id='section-end']//div[contains(.,'Congratulations')]";
	public static String BtnBacktoSignIn = "xpath|//div[@id='content']//button[@id='login-link']";
	
	
	/**
	 * Function Name :- HomePageObjects<br>
	 * Description :- To set homepage page locator.
	 * 
	 * @return By
	 */
	public By HomePageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	/**
	 * Function Name :- VerifyLoggedinHomePage<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean WaitLoggedinAdminHomePage() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(2000);
		if (WebDriverMain._isElementVisible(HomePageObjects(UserName))) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Function Name :- waitForProgressbarVisible<br>
	 * Description :- To wait Progress bar is visible
	 */
	public boolean waitForProgressbarVisible(int maxtimeout) throws Exception{
		int count=0;
		while((WebDriverMain._isElementVisible(HomePageObjects(Progressbar)))&&(count<maxtimeout))
		{
			CommonUtility._sleepForGivenTime(1000);
			count=count+1;
		}
		if (!WebDriverMain._isElementVisible(HomePageObjects(Progressbar)))
			return true;
		else
			return false;
		
	}

	/**
	 * Function Name :- VerifyWelcomeUser<br>
	 * Description :- To verify the Logged Name text.
	 *
	 */
	public boolean VerifyWelcomeUser(String username) throws IOException {
		String ActualText = WebDriverMain._getTextFromElement(HomePageObjects(WelcomeName));
		if (ActualText.contains(username)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- VerifyLoggedInUserIcon<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean VerifyLoggedInUserIcon() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		if (WebDriverMain._isElementPresent(HomePageObjects(USERICON))) {
			if (WebDriverMain._isElementPresent(HomePageObjects(Logout))) 
				return true;
		}
		return false;
	}

	/**
	 * Function Name :- Logout<br>
	 * Description :- To Click logput from user dropdown.
	 *
	 */
	public boolean Logout() throws IOException {
		LeftClick._click(HomePageObjects(USERICON));
		if (WebDriverMain._isElementPresent(HomePageObjects(Logout))) {
			LeftClick._click(HomePageObjects(Logout));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- ClickSelect<br>
	 * Description :- To Click Select
	 *
	 */
	public boolean ClickSelect() throws IOException {
		if (WebDriverMain._isElementPresent(HomePageObjects(BtnSelect))) {
			LeftClick._click(HomePageObjects(BtnSelect));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- VerifyTestName<br>
	 * Description :- To verify the Test Name text.
	 *
	 */
	public boolean VerifyTestName(String test) throws IOException {
		try {
			String ActualText = WebDriverMain._getTextFromElement(HomePageObjects(TestName));
			if (ActualText.contains(test)) {
				return true;
			} else {
				return false;
			}
		}
		catch(Exception e){
			return false;
		}
	}
	
	/**
	 * Function Name :- ClickSelect<br>
	 * Description :- To Click Select
	 *
	 */
	public boolean ClickStart() throws IOException {
		if (WebDriverMain._isElementPresent(HomePageObjects(BtnStart))) {
			LeftClick._click(HomePageObjects(BtnStart));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}

	
	/**
	 * Function Name :- ClickResume<br>
	 * Description :- To Click Resume
	 *
	 */
	public boolean ClickResume() throws IOException {
		if (WebDriverMain._isElementPresent(HomePageObjects(BtnResume))) {
			LeftClick._click(HomePageObjects(BtnResume));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	/**
	 * Function Name :- ClickStartSection<br>
	 * Description :- To Click Start Section
	 *
	 */
	public boolean ClickStartSection() throws IOException {
		if (WebDriverMain._isElementPresent(HomePageObjects(BtnStartSection))) {
			LeftClick._click(HomePageObjects(BtnStartSection));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- SelectEndReviewOptions<br>
	 * Description :- To Click End of Section from review dropdown.
	 *
	 */
	public boolean SelectEndReviewOptions() throws IOException {
		LeftClick._click(HomePageObjects(lstBtnReview));
		if (WebDriverMain._isElementPresent(HomePageObjects(lstReviewOptions))) {
			LeftClick._click(HomePageObjects(lstReviewEndOptions));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- ClickSubmitFinalAnswers<br>
	 * Description :- To Click Submit Final Answer
	 *
	 */
	public boolean ClickSubmitFinalAnswers() throws IOException {
		if (WebDriverMain._isElementPresent(HomePageObjects(BtnSubmitFinal))) {
			LeftClick._click(HomePageObjects(BtnSubmitFinal));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- VerifyCongratsMsg<br>
	 * Description :- To verify the Congrats text.
	 *
	 */
	public boolean VerifyCongratsMsg(String message) throws IOException {
		String ActualText = WebDriverMain._getTextFromElement(HomePageObjects(SubmitMsg));
		if (ActualText.contains(message)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Function Name :- ConfirmSubmitPopupActionBtn<br>
	 * Description :- To Confirm Popup string.
	 * 
	 * @return boolean
	 */
	public boolean ConfirmSubmitPopupActionBtn(String ModalActionButton) throws IOException {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//div[@id='exitAlertModal']/div[@role='document']");
		By ModalActnBtnlocator = CommonUtility._getObjectLocator("xpath=//button[contains(text(),'"+ModalActionButton+"')]");
		WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
		if (targetElement != null) {
			try{
				if(targetElement.isDisplayed()){
					
					//Verify Modal Action
					if (ModalActionButton.length()>1) {
						WebElement ModalBtnEle =targetElement.findElement(ModalActnBtnlocator);
						if (ModalBtnEle != null) {
							if (LeftClick._click(ModalBtnEle)) 
								flag=true;
								//UMReporter.log(Status.Pass, "The Confirm popup action button "+ModalBtnEle);
							 else 
								UMReporter.log(Status.FAIL, "The Confirm popup action button is not exist "+ModalActionButton);
						}
					}
					
				}
			}
			catch(Exception e){
				return false;
			}
		}
		return flag;
		
	}
	
	/**
	 * Function Name :- ConfirmExitPopupActionBtn<br>
	 * Description :- To Confirm Popup string.
	 * 
	 * @return boolean
	 */
	public boolean ConfirmExitPopupActionBtn(String ModalActionButton) throws IOException {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//div[@id='save-exit-test-modal']/div[@role='document']");
		By ModalActnBtnlocator = CommonUtility._getObjectLocator("xpath=//button[contains(text(),'"+ModalActionButton+"')]");
		WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
		if (targetElement != null) {
			try{
				if(targetElement.isDisplayed()){
					//Verify Modal Action
					if (ModalActionButton.length()>1) {
						WebElement ModalBtnEle =targetElement.findElement(ModalActnBtnlocator);
						if (ModalBtnEle != null) {
							if (LeftClick._click(ModalBtnEle)) 
								flag=true;
							 else 
								UMReporter.log(Status.FAIL, "The Confirm popup action button is not exist "+ModalActionButton);
						}
					}
					
				}
			}
			catch(Exception e){
				return false;
			}
		}
		return flag;
		
	}
	
	/**
	 * Function Name :- VerifyBackToSign<br>
	 * Description :- To verify the BackToSign text.
	 *
	 */
	public boolean VerifyBackToSign() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		if (WebDriverMain._isElementPresent(HomePageObjects(BtnBacktoSignIn))) {
			return true;
		} else {
			return false;
		}
	}
	
}
