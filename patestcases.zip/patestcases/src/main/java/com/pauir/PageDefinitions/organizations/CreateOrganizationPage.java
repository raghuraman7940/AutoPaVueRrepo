package com.pauir.PageDefinitions.organizations;
/**
 * CreateOrganizationPage
 */

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.testDataTypes.Organizationsfield;
import com.pauir.common.util.Constants;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class CreateOrganizationPage {
	CommonFunctions common;

	//Create Organization page objects
	public static String CreateOrganizationspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String CreateOrganizationspage_Info="xpath|//pa-org-edit//form//h5[contains(text(),'Info')]";
	public static String CreateOrganizationForm="xpath|//pa-org-edit//form";
	public static String Inline_Message="xpath|//pa-alerts//div['alert']//span";
	public static String Error_Message="xpath|//pa-alerts//div['alert']//span";
	public static String Field_Control_Error_Message="xpath|//pa-field-messages//div[contains(@class,'form-control-error')]";
	public static String AddBtn="xpath|//pa-grid-actions/button[contains(text(),'Add')]";
	public static String EditBtn="xpath|//a/span[contains(text(),'Edit')]";
	public static String CancelBtn="xpath|//button[contains(text(),'Cancel')]";
	public static String SaveBtn="xpath|//button[contains(text(),'Save')]";
	public static String popupdropdownlist="xpath|//kendo-popup/div/kendo-list/div/ul/li";
	public static String shipCoordInclude="xpath|//input[@id='shipCoordChkbx']";
	public static String shipCoordbody="xpath|//input[@id='contactName']";
	
	/**
	 * Function Name :- CreateOrganizationPageObjects<br>
	 * Description :- To set Create Organization page locator.
	 * 
	 * @return By
	 */
	public By CreateOrganizationPageObjects(String byStrgylocValue)
	{
		 By by = null;
		 by=CommonUtility._getByLocator(byStrgylocValue);
		 return by;
	}

	/**
	 * Function Name :- verifyCreateOrganizationPageNavigation<br>
	 * Description :- To verify Create Organization Page Navigation.
	 *
	 */
	public boolean verifyCreateOrganizationPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		String OrgPageTitle=WebDriverMain._getTextFromElement(CreateOrganizationPageObjects(CreateOrganizationspage_Info));
//		if ((OrgPageTitle.contains(Constants.CreateDistrictPageTitle))||(OrgPageTitle.contains(Constants.CreateSchoolPageTitle)))
		if ((OrgPageTitle.contains(Constants.mapCustomLabels.get("pa.core.org.district.info.label")))||(OrgPageTitle.contains(Constants.mapCustomLabels.get("pa.core.org.school.info.label"))))			
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- VerifyCreateOrganizationForm<br>
	 * Description :- To verify the Create Organization page form.
	 *
	 */
	public boolean VerifyCreateOrganizationForm() throws IOException{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean isDisplayed=WebDriverMain._isElementVisible(CreateOrganizationPageObjects(CreateOrganizationForm));
		//CommonUtility._sleepForGivenTime(2000);
		return isDisplayed;
		
	}
	
	/**
	 * Function Name :- AddButton_isVisible<br>
	 * Description :- To verify Add button is visible
	 *
	 */
	public boolean AddButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateOrganizationPageObjects(AddBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- AddButton_isEnabled<br>
	 * Description :- To verify Add button is enabled
	 *
	 */
	public boolean AddButton_isEnabled() throws IOException
	{
		WebElement btnelm = WebDriverMain._getElementWithWait(CreateOrganizationPageObjects(AddBtn));
		String attributeText = btnelm.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- clickAddButton<br>
	 * Description :- To click the Add button.
	 *
	 */
	public boolean clickAddButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(CreateOrganizationPageObjects(AddBtn));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify Edit button is visible
	 *
	 */
	public boolean EditButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateOrganizationPageObjects(EditBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- EditButton_isEnabled<br>
	 * Description :- To verify CreateOrganization button is enabled
	 *
	 */
	public boolean EditButton_isEnabled() throws IOException
	{
		WebElement btnelm = WebDriverMain._getElementWithWait(CreateOrganizationPageObjects(EditBtn));
		String attributeText = btnelm.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- SaveButton_isVisible<br>
	 * Description :- To verify Save button is visible
	 *
	 */
	public boolean SaveButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateOrganizationPageObjects(SaveBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- SaveButton_isEnabled<br>
	 * Description :- To verify CreateOrganization button is enabled
	 *
	 */
	public boolean SaveButton_isEnabled() throws IOException
	{
		WebElement btnelm = WebDriverMain._getElementWithWait(CreateOrganizationPageObjects(SaveBtn));
		String attributeText = btnelm.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickSaveButton<br>
	 * Description :- To click the Save Organization button.
	 *
	 */
	public boolean clickSaveButton() throws IOException{
		
		CommonUtility._scrolldown();
		CommonUtility._sleepForGivenTime(500);
		boolean flag=LeftClick._click(CreateOrganizationPageObjects(SaveBtn));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- CancelButton_isVisible<br>
	 * Description :- To verify Cancel button is visible
	 *
	 */
	public boolean CancelButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(CreateOrganizationPageObjects(CancelBtn)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit button.
	 *
	 */
	public boolean clickEditButton() throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
		boolean flag=LeftClick._click(CreateOrganizationPageObjects(EditBtn));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- clickCancelButton<br>
	 * Description :- To Click the cancel button on Create Organization page form.
	 *
	 */
	public boolean clickCancelButton() throws IOException{
		boolean flag=LeftClick._click(CreateOrganizationPageObjects(CancelBtn));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- verifyOrganizationSuccessMessage<br>
	 * Description :- To verify the success message on Create Organization page form.
	 *
	 */
	public boolean verifyOrganizationSuccessMessage(String successmessage) throws IOException{
		String ActualText=WebDriverMain._getTextFromElement(CreateOrganizationPageObjects(Inline_Message));
		if(ActualText.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Function Name :- verifyFailureMessage<br>
	 * Description :- To verify the failure message on Create Organization page form.
	 *
	 */
	public boolean verifyFailureMessage(String failuremessage) throws IOException{
		String text1=WebDriverMain._getTextFromElement(CreateOrganizationPageObjects(Inline_Message));
		if(text1.contains(failuremessage)){
			//Log._logInfo("Successfully Verify error message");
			return true;
		}else
			return false;
	}
	
	/**
	 * Function Name :- verifyErrorMessage<br>
	 * Description :- To verify the error message on Create Organization page form.
	 *
	 */
	public boolean verifyErrorMessage(String FieldLabel) throws IOException{
		String ErrorText=WebDriverMain._getTextFromElement(CreateOrganizationPageObjects(Error_Message));
		if (ErrorText.length()>1) {
			System.out.println("Error Message: "+ErrorText);
			if(ErrorText.contains(Constants.CREATEORGANIZATIONSFAILUREMESSAGE)){
				return true;
			}else
				UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" has the actual error message :" +ErrorText);
				return false;
		}
		else
		{
			UMReporter.log(Status.FAIL, "The Field "+FieldLabel+" error mesage is not displayed");
		}
		return false;
	}
	
	/**
	 * Function Name :- verifyFieldControlErrorMessage<br>
	 * Description :- To verify the field control error message on Create Organization page form.
	 *
	 */
	public boolean verifyFieldControlErrorMessage(String failuremessage) throws IOException{
		String ErrorText=WebDriverMain._getTextFromElement(CreateOrganizationPageObjects(Field_Control_Error_Message));
		System.out.println("Field Error Message: "+ErrorText);
		if(ErrorText.contains(failuremessage)){
			//Log._logInfo("Successfully Verify error message");
			UMReporter.log(Status.PASS, "The Field control error matched the expected error message :" +failuremessage);
			return true;
		}else
			return false;
	}
	
	/**
	 * Function Name :- FillOrganizationFields<br>
	 * Description :- To fill Organization fields depends on fieldtype  on create Organization page
	 * @throws IOException 
	 */
	public HashMap<String,String> FillOrganizationFields(List<Organizationsfield> Organizationfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		//Iterate each field values
		for (Organizationsfield field : Organizationfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
						//Fill the Value base fieldtype, locator, value
						FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				CommonUtility._sleepForGivenTime(1000);
				
			}
			}
		}
		return MapFilledOrgsField;
	}
	
	
	
	/**
	 * Function Name :- FillOrganizationField<br>
	 * Description :- To fill Organization field depends on fieldtype  on create Organization page
	 * @throws IOException 
	 */
	public String FillOrganizationField(Organizationsfield field, String FieldValue) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		String sFieldValue=null;
		By objlocator=null;
		By objsublocator=null;
		//field values
		String sFieldName = field.getFieldname();
		String sFieldLocator = field.getObjectlocator();
		String sFieldType=field.getFieldtype();
		String sFieldLabel=field.getLabletodisplay();
		String sFieldrequired=field.getRequired();
		//Set Field Label
		if (sFieldLabel.indexOf("^")>=0)
			sFieldLabel=Constants.mapCustomLabels.get(sFieldLabel.substring(1));
		
		
		//Set input value
		if(FieldValue.equalsIgnoreCase(null))
			sFieldValue =field.getFieldvalue();
		else
			sFieldValue=FieldValue;
		
		objsublocator=null;
		
		//Call to verify the field label 
		FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
		if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				

				//Field Validation on textbox and list
				if(sFieldType.equalsIgnoreCase("dropdownlist")){
					CommonUtility._sleepForGivenTime(1000);
				}
		}
		return FilledFieldValue;
	}
	
	/**
	 * Function Name :- PageDataFieldValidation<br>
	 * Description :- To validate the Organization fields  on create Organization page
	 * @throws IOException 
	 */
	public HashMap<String,String> PageDataFieldValidation(List<Organizationsfield> Organizationfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean flag =false;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		By objcontrlerr=null;
		//Iterate each field values
		for (Organizationsfield field : Organizationfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			String sFieldminLength=field.getMinLength();
			String sFieldmaxLength=field.getMaxLength();
			String sFieldregex=field.getRegex();
			String sFieldErrorMsg=field.getFielderrormsg();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
					
					//Field Validation on textbox and list
					if(sFieldType.equalsIgnoreCase("textbox")){
					//Validate the field for MinLength, MaxLength, Regex
					flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					
					WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
					
					if (targetElement != null) {
						targetElement.sendKeys(Keys.BACK_SPACE);
						CommonUtility._sleepForGivenTime(500);
						
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						
					}
					
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("dropdownlist")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						//flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
					}
					
					//Fill the Value base fieldtype, locator, value
					FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				
				//Field Validation on textbox and list
				if(sFieldType.equalsIgnoreCase("textbox")){
				//Validate the field for MinLength, MaxLength, Regex
				flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
				
				WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
				
				if (targetElement != null) {
					targetElement.sendKeys(Keys.BACK_SPACE);
					CommonUtility._sleepForGivenTime(500);
					
				}
				//Set by locator object for label
				String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
				objcontrlerr = CommonUtility._getObjectLocator(strLocator);
				//Verify the label
				flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
					
			}
				
			//Field Validation on textbox and list
			else if(sFieldType.equalsIgnoreCase("dropdownlist")){
				
				CommonUtility._sleepForGivenTime(1000);
				//Validate the field for MinLength, MaxLength, Regex
				flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
				
				objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
				WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
				if (targetElement1 != null) {
					targetElement1.click();
					CommonUtility._sleepForGivenTime(500);
				}
				//Set by locator object for label
				String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
				objcontrlerr = CommonUtility._getObjectLocator(strLocator);
				//Verify the label
				//flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
			}
			//Fill the Value base fieldtype, locator, value
			FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
		}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				
			}
			}
		}
		return MapFilledOrgsField;
	}
	


	/**
	 * Function Name :- VerifyRequiredFieldValidation<br>
	 * Description :- To verify the required fields  on create Organization page
	 * @throws IOException 
	 */
	public boolean VerifyRequiredFieldValidation(List<Organizationsfield> Organizationfields) throws IOException{
		
		boolean flag =false;
		By objlocator=null;
		
		for (Organizationsfield field : Organizationfields)
		{
			String sFieldName = field.getFieldname();
			
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			//Provide input to mandatory fields only
			if (sFieldrequired.equalsIgnoreCase("true")) {
				//Set by locator object for label
				String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/../../../div[@Organization='form-control-error']";
				//Verify Organization have different label
				if (sFieldName.equalsIgnoreCase("organizations")){
					strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[@Organization='form-control-error']";
				}
				objlocator = CommonUtility._getObjectLocator(strLocator);
				//Verify the label
				flag=WebDriverMain._containText(objlocator,Constants.FIELDERROR);
				
			}
		}
		return flag;
	}
	
	
	/**
	 * Function Name :- VerifyFilledOrganizationsFields<br>
	 * Description :- To verify the Organizations fields  on create Organization page
	 * @throws IOException 
	 */
	public boolean VerifyFilledOrganizationsFields(List<Organizationsfield> Organizationfields, HashMap<String,String> MapFilledUserField) throws IOException{
		
		//Intialize Function variable
		boolean flag =false;
		boolean FieldValueflag =false;
		boolean FieldLabelflag =false;
		By objlocator=null;
		By objModifiedlocator=null;
		By objsublocator=CreateOrganizationPageObjects(popupdropdownlist);
		
		//Iterate each field values
		for (Organizationsfield field : Organizationfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			if (MapFilledUserField.containsKey(sFieldLabel)){
				//Call to verify the field label 
				FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
				//Set by locator object from configuration
				String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
				if(strArrObjLocs.length==1){
					objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
					objModifiedlocator=objlocator;
				}
				else if(strArrObjLocs.length==2){
					objModifiedlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
					objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
				}
				
				//Fill the Value base fieldtype, locator, value
				FieldValueflag=common.FieldDataValidationswitchCase(sFieldType, objModifiedlocator,objsublocator, MapFilledUserField.get(sFieldLabel), sFieldLabel);
			
				if (FieldLabelflag&&FieldValueflag)
					flag=true;
				else
					UMReporter.log(Status.FAIL, "The field " +sFieldLabel+ "  value is not matched with provided input value :" +MapFilledUserField.get(sFieldLabel));
			}
			
		}
		return flag;
	}
	
	/**Function Name :- VerifyFieldLabel<br/>
	 * Description   :- VerifyFieldLabel
	 * @param fieldType Labelfor Label
	 * @return boolean
	 */
	public static boolean VerifyFieldLabel(String fieldType, String Label) {
		boolean flag =true;
		String strLocator=null;
		By objlocator =null;
		try{
			if(fieldType.equalsIgnoreCase("checkbox")){
				strLocator="xpath=//div[@formgroupname='daysOfTheWeekGroup']//span[contains(text(),'"+Label+"')]";
				objlocator = CommonUtility._getObjectLocator(strLocator);
				String strLabel=WebDriverMain._getTextFromElement(objlocator);
				if(strLabel.contains(Label)){
					return true;
				}
				else {
					UMReporter.log(Status.FAIL, "The Actual Text " +strLabel+ " is not matched with expected text " +Label);
					return false;
				}
			}
			//Set by locator object for label
			strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label
			flag=WebDriverMain._containText(objlocator,Label);
			
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	
	
	/**
	 * Function Name :- verifyViewOrgsDetails<br>
	 * Description :- To verify the view  Orgs details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewOrgsDetails(HashMap<String,String> MapFilledOrgField) throws IOException{
		boolean verifedFlag=true;
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledOrgField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            if (sFieldLabel.contains("Region Code")) {
	        		String strArrObjLocs[] = CommonUtility._split(sFieldValue," ");
	      			if(strArrObjLocs.length>1)				
	      				sFieldValue = strArrObjLocs[1];
		          
	            }
	            else if (sFieldLabel.contains("School Type")) {
	        		String strArrObjLocs[] = CommonUtility._split(sFieldValue," ");
	      			if(strArrObjLocs.length>1)				
	      				sFieldValue = strArrObjLocs[0].toLowerCase();
		          
	            }
	            objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//form//label[contains(text(),'"+sFieldLabel+"')]");
				boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
				if (isFieldLabelPresent) {
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//form//P[contains(text(),'"+sFieldValue+"')]");
					boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
					if (!isFieldValuePresent) {
						verifedFlag=false;
						UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
					}
				}
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		return verifedFlag;
	}
	
	/**
	 * Function Name :- ShippingCoordInclude<br>
	 * Description :- To Expand/Collapse Shipping Coord.
	 *
	 */
	public boolean ShippingCoordInclude(String strValue) throws IOException{
		boolean flag=false;
		try {
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
				if (WebDriverMain._isElementPresent(CreateOrganizationPageObjects(shipCoordInclude))) {
					if (WebDriverMain._isElementVisible(CreateOrganizationPageObjects(shipCoordbody)))
						return true;//Display Accom info if collapse
					else {
						flag = LeftClick.clickByJS(CreateOrganizationPageObjects(shipCoordInclude));
						//CommonUtility._sleepForGivenTime(2000);
						WebDriverMain._waitForElementVisible(CreateOrganizationPageObjects(shipCoordbody));
						if (WebDriverMain._isElementVisible(CreateOrganizationPageObjects(shipCoordbody)))
							return true;//Display Accom info if collapse
					}
				}
			}
			else {
				if (WebDriverMain._isElementPresent(CreateOrganizationPageObjects(shipCoordInclude))) {
					if (!WebDriverMain._isElementVisible(CreateOrganizationPageObjects(shipCoordbody)))
						return true;//Not display session info if collapse
				}
				else if (WebDriverMain._isElementPresent(CreateOrganizationPageObjects(shipCoordInclude))){
					flag = LeftClick.clickByJS(CreateOrganizationPageObjects(shipCoordInclude));
					CommonUtility._sleepForGivenTime(1000);
					WebDriverMain._waitForElementVisible(CreateOrganizationPageObjects(shipCoordbody));
					if (!WebDriverMain._isElementVisible(CreateOrganizationPageObjects(shipCoordbody)))
						return true; //Not display session info if collapse
				}
			}
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}

}
