package com.pauir.PageDefinitions.products;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class TestDetailsPage {

	// Test Details page objects
	public static String TestDetailsHeader_Section = "xpath|//pa-product-type-test-view//div[@class='card']";
	public static String Test_FormList_Section = "xpath|//kendo-tabstrip/ul/li[contains(. ,'Form List')]";
	public static String FormDatagridHeaderRow = "xpath|//kendo-grid//table/thead/tr/th";
	public static String SearchInputFilter = "xpath|//pa-grid-search//input";
	public static String Searchicon = "xpath|//button[@aria-label='Search']";
	public static String FormRowsPresent = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String ClearBtn = "xpath|//button[@aria-label='Clear Search']";

	/**
	 * Function Name :- TestDetailPageObjects<br>
	 * Description :- To set Test Details Page Objects locator.
	 * 
	 * @return By
	 */
	public By TestDetailsPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	/**
	 * Function Name :- Verify_TestDetails_Section<br>
	 * Description :- To Test Details Section is visible
	 *
	 */
	public boolean Verify_TestDetails_Section() throws IOException {
		if (WebDriverMain._isElementVisible(TestDetailsPageObjects(TestDetailsHeader_Section)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- verifyTestDetailsHeaderLabel<br>
	 * Description :- To verify the label on Test details page.
	 *
	 */
	public boolean verifyTestDetailsHeaderLabel(String labelmessage) throws IOException {
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//pa-product-type-test-view//label[contains(text(),'" + labelmessage + "')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- verifyViewTestDetails<br>
	 * Description :- To verify the view Test details Page
	 * 
	 * @throws IOException
	 */
	public boolean verifyViewTestDetails(HashMap<String, String> MapFilledField) throws IOException {
		boolean verifedFlag = true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try {

			By objlocator = null;
			for (Map.Entry<String, String> entry : MapFilledField.entrySet()) {
				System.out.println("INFO ViewMap - Fields  : " + entry.getKey());
				String sFieldLabel = entry.getKey();
				String sFieldValue = entry.getValue();

				if (sFieldLabel.length() > 1) {

					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-product-type-test-view//label[contains(text(),'" + sFieldLabel + "')]");
					boolean isFieldLabelPresent = WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if (sFieldValue.length() > 1) {

							MapDgStuRec.put(sFieldLabel, sFieldValue);
							if (sFieldLabel.length() < 1) {
								objlocator = CommonUtility
										._getObjectLocator("xpath=//pa-product-type-test-view//h2[contains(text(),'"
												+ sFieldValue + "')]");
							}

							else if (sFieldLabel.contains("On Grade") || sFieldLabel.contains("Off Grade")) {

								objlocator = CommonUtility
										._getObjectLocator("xpath=//pa-product-type-test-view//span/child::span");

							} else
								objlocator = CommonUtility
										._getObjectLocator("xpath=//pa-product-type-test-view//span[contains(text(),'"
												+ sFieldValue + "')]");
							boolean isFieldValuePresent = WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								verifedFlag = false;
								UMReporter.log(Status.FAIL, "The field " + sFieldLabel
										+ " not matched with expected value : " + sFieldValue);
							}
						}
					}
				}
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}

		if (verifedFlag)
			UMReporter.log(Status.PASS,
					"User have access to view the Test field value in Test details page :" + MapDgStuRec);
		return verifedFlag;
	}

	/**
	 * Function Name :- Verify_Test_FormList<br>
	 * Description :- To verify Test Form List is visible
	 *
	 */
	public boolean Verify_Test_FormList() throws IOException {
		if (WebDriverMain._isElementVisible(TestDetailsPageObjects(Test_FormList_Section))) {
			return true;
		}

		else
			return false;

	}

	/**
	 * Function Name :- getFormColumnHeaderDetails<br>
	 * Description :- To get Form list Column header Details.
	 *
	 */
	public List<String> getFormColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(TestDetailsPageObjects(FormDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader = new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifyFormFieldSorting<br>
	 * Description :- To verify form fields are sortable.
	 *
	 */

	public List<String> verifyFormFieldSorting(String ColName) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(TestDetailsPageObjects(FormRowsPresent));
		System.out.println("Form Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(TestDetailsPageObjects(FormDatagridHeaderRow));
		if ((lstheaderRow.size() >= 1) && (lstOrgrRow.size() >= 2)) {
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues = new ArrayList<String>();
					int datacounter = iCol + 1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 = CommonUtility._getObjectLocator("xpath=//kendo-grid//table/thead/tr/th["
								+ datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//kendo-grid//kendo-grid-list//table//tbody/tr/td[" + datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}

	/**
	 * Function Name :- Searchfill<br>
	 * Description :- To Filter result in Test details Page.
	 *
	 */
	public boolean Searchfill(String SearchString) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(TestDetailsPageObjects(SearchInputFilter));
		if (flag) {
			flag = TextBox._setTextBox(TestDetailsPageObjects(SearchInputFilter), SearchString);
			CommonUtility._sleepForGivenTime(1000);
		}
		return flag;

	}

	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks Search icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {

		boolean flag = WebDriverMain._isElementVisible(TestDetailsPageObjects(SearchInputFilter));
		if (flag) {
			flag = LeftClick._click(TestDetailsPageObjects(Searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}

	/**
	 * Function Name :- verifyFormSearchresultsDetails<br>
	 * Description :- To get form search results Details.
	 *
	 */
	public List<String> verifyFormSearchresultsDetails(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(TestDetailsPageObjects(FormRowsPresent));
		System.out.println("Form Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(TestDetailsPageObjects(FormDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			// if have Records
			if (!WebDriverMain._isElementVisible(TestDetailsPageObjects(NoRecords))) {

				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgOrgRec.containsKey(Constants.FormCode) && (MapDgOrgRec.containsKey(Constants.TestCode))) {
						String SearchOrg = MapDgOrgRec.get(Constants.FormCode) + " - "
								+ MapDgOrgRec.get(Constants.TestCode);
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- clearTextFromSearchBox<br>
	 * Description :- To clear text from search box
	 *
	 */
	public boolean clearTextFromSearchBox() throws IOException {

		if (LeftClick._click(TestDetailsPageObjects(ClearBtn))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- SelectFormRecord<br>
	 * Description :- To select Form record results Details.
	 *
	 */
	public HashMap<String, String> SelectFormRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(TestDetailsPageObjects(FormRowsPresent));
		System.out.println("Form Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(TestDetailsPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-product-type-test-view//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
										+ "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(TestDetailsPageObjects(FormDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}

						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-product-type-test-view//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
										+ "]/td/button");
						WebElement tsElm = WebDriverMain._getElementWithWait(objlocator);
						if (tsElm != null) {
							if (WebDriverMain._isElementClickable(tsElm)) {
								tsElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								return MapDgOrgRec;
							}
						}

						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

}
