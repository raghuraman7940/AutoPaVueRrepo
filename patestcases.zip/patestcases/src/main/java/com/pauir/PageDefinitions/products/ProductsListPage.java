package com.pauir.PageDefinitions.products;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.WebDriverMain;

public class ProductsListPage {
	public static String ProductListPage_Title = "xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String ProductButtonPresent = "xpath|//pa-product-type-list//button";

	public By ProductListPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	public boolean verifyProductListPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(ProductListPageObjects(ProductListPage_Title))
				.contains(Constants.ViewProductListPageTitle))
			return true;
		else
			return false;
	}

	public void clickProduct(String productName) throws IOException {

		LeftClick._click(ProductListPageObjects("xpath=//button[contains(text(),'" + productName + "')]"));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);

	}

	public boolean isProductListButtonsExist() throws Exception {
		try {
			CommonUtility._sleepForGivenTime(1000);
			List<WebElement> btnsProd = WebDriverMain._getElementsWithWait(ProductListPageObjects(ProductButtonPresent));
			if (btnsProd != null)
				return true;
			else
				return false;
		}
		catch(Exception e) {
			return false;
		}
	}

	public boolean clickOnProductName(String prodName) throws Exception {
		By objlocator = null;
		objlocator = CommonUtility._getObjectLocator("xpath=//button/span[contains(text(),'" + prodName + "')]");
		if (WebDriverMain._isElementPresent(objlocator)) {
			LeftClick._click(objlocator);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		} else {
			return false;
		}

	}

}