package com.pauir.PageDefinitions.users;
/**
 * CreateUserPage
 */
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.testDataTypes.Userfield;
import com.pauir.common.util.Constants;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class CreateUserPage {
	CommonFunctions common;

	//Create User page objects
	public static String CreateUserspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String CreateUserForm="xpath|//pa-user-edit//form";
	public static String Inline_Message="xpath|//div[@id='alerts']/div['alert']/span";
	public static String Error_Message="xpath|//div[@id='alerts']/div['alert']/span/h1";
	public static String Field_Control_Error_Message="xpath|//pa-field-messages//div[contains(@class,'form-control-error')]";
	public static String AddBtn="xpath|//button[contains(text(),'Add')]";
	public static String EditBtn="xpath|//button[contains(text(),'Edit')]";
	public static String CancelBtn="xpath|//button[contains(text(),'Cancel')]";
	public static String CreateUserBtn="xpath|//button[contains(text(),'Create User')]";
	public static String popupdropdownlist="xpath|//kendo-popup/div/kendo-list/div/ul/li";
	public static String Alert_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
	
	
	/**
	 * Function Name :- CreateUserPageObjects<br>
	 * Description :- To set Create User page locator.
	 * 
	 * @return By
	 */
	public By CreateUserPageObjects(String byStrgylocValue)
	{
		 By by = null;
		 by=CommonUtility._getByLocator(byStrgylocValue);
		 return by;
	}

	/**
	 * Function Name :- verifyUserDetailsNavigation<br>
	 * Description :- To verify User Detail Page Navigation.
	 *
	 */
	public boolean verifyCreateUserPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(CreateUserPageObjects(CreateUserspage_Title)).contains(Constants.CreateUserPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- VerifyCreateUserForm<br>
	 * Description :- To verify the Create User page form.
	 *
	 */
	public boolean VerifyCreateUserForm() throws IOException{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean isDisplayed=WebDriverMain._isElementPresent(CreateUserPageObjects(CreateUserForm));
		//CommonUtility._sleepForGivenTime(2000);
		return isDisplayed;
		
	}
	
	/**
	 * Function Name :- AddButton_isVisible<br>
	 * Description :- To verify Add button is visible
	 *
	 */
	public boolean AddButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateUserPageObjects(AddBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- AddButton_isEnabled<br>
	 * Description :- To verify Add button is enabled
	 *
	 */
	public boolean AddButton_isEnabled() throws IOException
	{
		WebElement btnelm = WebDriverMain._getElementWithWait(CreateUserPageObjects(AddBtn));
		String attributeText = btnelm.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- clickAddButton<br>
	 * Description :- To click the Add button.
	 *
	 */
	public void clickAddButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(CreateUserPageObjects(AddBtn));
		CommonUtility._sleepForGivenTime(2000);
		common.PleaseWaitAndLoadingMessage();
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify Edit button is visible
	 *
	 */
	public boolean EditButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateUserPageObjects(EditBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- EditButton_isEnabled<br>
	 * Description :- To verify CreateUser button is enabled
	 *
	 */
	public boolean EditButton_isEnabled() throws IOException
	{
		WebElement btnelm = WebDriverMain._getElementWithWait(CreateUserPageObjects(EditBtn));
		String attributeText = btnelm.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- CreateUserButton_isVisible<br>
	 * Description :- To verify Save button is visible
	 *
	 */
	public boolean CreateUserButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(CreateUserPageObjects(CreateUserBtn)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- SaveButton_isEnabled<br>
	 * Description :- To verify CreateUser button is enabled
	 *
	 */
	public boolean CreateUserButton_isEnabled() throws IOException
	{
		WebElement btnelm = WebDriverMain._getElementWithWait(CreateUserPageObjects(CreateUserBtn));
		String attributeText = btnelm.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickCreateUserButton<br>
	 * Description :- To click the CreateUser button.
	 *
	 */
	public boolean clickCreateUserButton() throws IOException{
		
		CommonUtility._scrollup();
		boolean flag=LeftClick._click(CreateUserPageObjects(CreateUserBtn));
		CommonUtility._sleepForGivenTime(4000);
		common.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- CancelButton_isVisible<br>
	 * Description :- To verify Cancel button is visible
	 *
	 */
	public boolean CancelButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(CreateUserPageObjects(CancelBtn)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit button.
	 *
	 */
	public boolean clickEditButton() throws IOException{
		boolean flag=LeftClick._click(CreateUserPageObjects(EditBtn));
		common.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- clickCancelButton<br>
	 * Description :- To Click the cancel button on Create User page form.
	 *
	 */
	public boolean clickCancelButton() throws IOException{
		boolean flag=LeftClick._click(CreateUserPageObjects(CancelBtn));
		common.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- verifyUserSuccessMessage<br>
	 * Description :- To verify the success message on Create User page form.
	 *
	 */
	public boolean verifyUserSuccessMessage(String successmessage) throws IOException{
		String ActualText=WebDriverMain._getTextFromElement(CreateUserPageObjects(Inline_Message));
		if(ActualText.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Function Name :- verifyFailureMessage<br>
	 * Description :- To verify the failure message on Create User page form.
	 *
	 */
	public boolean verifyFailureMessage(String failuremessage) throws IOException{
		String text1=WebDriverMain._getTextFromElement(CreateUserPageObjects(Inline_Message));
		if(text1.contains(failuremessage)){
			//Log._logInfo("Successfully Verify error message");
			return true;
		}else
			return false;
	}
	
	/**
	 * Function Name :- verifyErrorMessage<br>
	 * Description :- To verify the error message on Create User page form.
	 *
	 */
	public boolean verifyErrorMessage(String FieldLabel) throws IOException{
		if (WebDriverMain._isElementVisible(CreateUserPageObjects(Error_Message))) {
			String ErrorText=WebDriverMain._getTextFromElement(CreateUserPageObjects(Error_Message));
			if (ErrorText.length()>1) {
				System.out.println("Error Message: "+ErrorText);
				if(ErrorText.contains(Constants.CREATEUSERFAILUREMESSAGE)){
					return true;
				}else
					return false;
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- verifyFieldControlErrorMessage<br>
	 * Description :- To verify the field control error message on Create User page form.
	 *
	 */
	public boolean verifyFieldControlErrorMessage(String failuremessage) throws IOException{
		String ErrorText=WebDriverMain._getTextFromElement(CreateUserPageObjects(Field_Control_Error_Message));
		System.out.println("Field Error Message: "+ErrorText);
		if(ErrorText.contains(failuremessage)){
			//Log._logInfo("Successfully Verify error message");
			UMReporter.log(Status.PASS, "The Field control error matched the expected error message :" +failuremessage);
			return true;
		}else
			return false;
	}
	
	/**
	 * Function Name :- FillUserFields<br>
	 * Description :- To fill User fields depends on fieldtype  on create User page
	 * @throws IOException 
	 */
	public HashMap<String,String> FillUserFields(List<Userfield> Userfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		//Iterate each field values
		for (Userfield field : Userfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
						//Fill the Value base fieldtype, locator, value
						FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				CommonUtility._sleepForGivenTime(1000);
				
			}
			}
		}
		return MapFilledOrgsField;
	}
	
	
	
	/**
	 * Function Name :- FillUserField<br>
	 * Description :- To fill User field depends on fieldtype  on create User page
	 * @throws IOException 
	 */
	public String FillUserField(Userfield field, String FieldValue) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		String sFieldValue=null;
		By objlocator=null;
		By objsublocator=null;
		//field values
		String sFieldName = field.getFieldname();
		String sFieldLocator = field.getObjectlocator();
		String sFieldType=field.getFieldtype();
		String sFieldLabel=field.getLabletodisplay();
		String sFieldrequired=field.getRequired();
		//Set input value
		if(FieldValue.equalsIgnoreCase(null))
			sFieldValue =field.getFieldvalue();
		else
			sFieldValue=FieldValue;
		
		objsublocator=null;
		//Call to verify the field label 
		FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
		if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				

				//Field Validation on textbox and list
				if(sFieldType.equalsIgnoreCase("dropdownlist")){
					CommonUtility._sleepForGivenTime(1000);
				}
		}
		return FilledFieldValue;
	}
	
	/**
	 * Function Name :- PageDataFieldValidation<br>
	 * Description :- To validate the User fields  on create User page
	 * @throws IOException 
	 */
	public HashMap<String,String> PageDataFieldValidation(List<Userfield> Userfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean flag =false;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		By objcontrlerr=null;
		//Iterate each field values
		for (Userfield field : Userfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			String sFieldminLength=field.getMinLength();
			String sFieldmaxLength=field.getMaxLength();
			String sFieldregex=field.getRegex();
			String sFieldErrorMsg=field.getFielderrormsg();
			objsublocator=null;
			if (!sFieldLabel.equalsIgnoreCase("Locked")) {
				//Call to verify the field label 
				FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
				if (FieldLabelflag) {
				//Set by locator object from configuration
				String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
				if(strArrObjLocs.length==1){
					objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				}
				else if(strArrObjLocs.length==2){
					objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
					objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
				}
				if (filltype.equalsIgnoreCase("required")){
					//Provide input to mandatory fields only
					if (sFieldrequired.equalsIgnoreCase("true")) {	
						
						//Field Validation on textbox and list
						if(sFieldType.equalsIgnoreCase("textbox")){
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						
						WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
						
						if (targetElement != null) {
							targetElement.sendKeys(Keys.BACK_SPACE);
							CommonUtility._sleepForGivenTime(500);
							
							}
							//Set by locator object for label
							String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
							objcontrlerr = CommonUtility._getObjectLocator(strLocator);
							//Verify the label
							flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
							
						}
						
						
						//Fill the Value base fieldtype, locator, value
						FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
					}
				}
				//Provide input to all field 
				else {
					
					//Field Validation on textbox and list
					if(sFieldType.equalsIgnoreCase("textbox")){
					//Validate the field for MinLength, MaxLength, Regex
					flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					
					WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
					
					if (targetElement != null) {
						targetElement.sendKeys(Keys.BACK_SPACE);
						CommonUtility._sleepForGivenTime(500);
						
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						
					}
					
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("dropdownlist")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						//flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
					}
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("datepicker")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "04042019", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						
						if(sFieldName.equalsIgnoreCase("StartDate")) {
							clickCreateUserButton();
							verifyErrorMessage(sFieldLabel);
						}
					}
					//Fill the Value base fieldtype, locator, value
					FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
				//Check Label verified and filled field value
				if (FilledFieldValue!=null) {
					//Filled label and value stored for validation in confirmation page
					MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
					
				}
				}
			}
		}
		return MapFilledOrgsField;
	}
	


	/**
	 * Function Name :- VerifyRequiredFieldValidation<br>
	 * Description :- To verify the required fields  on create User page
	 * @throws IOException 
	 */
	public boolean VerifyRequiredFieldValidation(List<Userfield> Userfields) throws IOException{
		
		boolean flag =false;
		By objlocator=null;
		
		for (Userfield field : Userfields)
		{
			String sFieldName = field.getFieldname();
			
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			//Provide input to mandatory fields only
			if (sFieldrequired.equalsIgnoreCase("true")) {
				//Set by locator object for label
				String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/../../../div[@class='form-control-error']";
				//Verify Organization have different label
				if (sFieldName.equalsIgnoreCase("organizations")){
					strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[@class='form-control-error']";
				}
				objlocator = CommonUtility._getObjectLocator(strLocator);
				//Verify the label
				flag=WebDriverMain._containText(objlocator,Constants.FIELDERROR);
				
			}
		}
		return flag;
	}
	
	
	/**
	 * Function Name :- VerifyFilledUsersFields<br>
	 * Description :- To verify the Users fields  on create User page
	 * @throws IOException 
	 */
	public boolean VerifyFilledUsersFields(List<Userfield> Userfields, HashMap<String,String> MapFilledUserField) throws IOException{
		
		//Intialize Function variable
		boolean flag =false;
		boolean FieldValueflag =false;
		boolean FieldLabelflag =false;
		By objlocator=null;
		By objModifiedlocator=null;
		By objsublocator=CreateUserPageObjects(popupdropdownlist);
		
		//Iterate each field values
		for (Userfield field : Userfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			if (MapFilledUserField.containsKey(sFieldLabel)){
				//Call to verify the field label 
				FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
				//Set by locator object from configuration
				String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
				if(strArrObjLocs.length==1){
					objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
					objModifiedlocator=objlocator;
				}
				else if(strArrObjLocs.length==2){
					objModifiedlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
					objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
				}
				
				//Fill the Value base fieldtype, locator, value
				FieldValueflag=common.FieldDataValidationswitchCase(sFieldType, objModifiedlocator,objsublocator, MapFilledUserField.get(sFieldLabel), sFieldLabel);
			
				if (FieldLabelflag&&FieldValueflag)
					flag=true;
				else
					UMReporter.log(Status.FAIL, "The field " +sFieldLabel+ "  value is not matched with provided input value :" +MapFilledUserField.get(sFieldLabel));
			}
			
		}
		return flag;
	}
	
	/**Function Name :- VerifyFieldLabel<br/>
	 * Description   :- VerifyFieldLabel
	 * @param fieldType Labelfor Label
	 * @return boolean
	 */
	public static boolean VerifyFieldLabel(String fieldType, String Label) {
		
		boolean flag =true;
		try{
			
			//Set by locator object for label
			String strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			By objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label
			flag=WebDriverMain._containText(objlocator,Label);
			
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	
	
	/**
	 * Function Name :- verifyViewOrgsDetails<br>
	 * Description :- To verify the view  Orgs details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewOrgsDetails(HashMap<String,String> MapFilledOrgField) throws IOException{
		boolean verifedFlag=true;
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledOrgField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            if (sFieldLabel.contains("Region Code")) {
	        		String strArrObjLocs[] = CommonUtility._split(sFieldValue," ");
	      			if(strArrObjLocs.length>1)				
	      				sFieldValue = strArrObjLocs[1];
		          
	            }
	            else if (sFieldLabel.contains("School Type")) {
	        		String strArrObjLocs[] = CommonUtility._split(sFieldValue," ");
	      			if(strArrObjLocs.length>1)				
	      				sFieldValue = strArrObjLocs[0].toLowerCase();
		          
	            }
	            objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//form//label[contains(text(),'"+sFieldLabel+"')]");
				boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
				if (isFieldLabelPresent) {
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//form//P[contains(text(),'"+sFieldValue+"')]");
					boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
					if (!isFieldValuePresent) {
						verifedFlag=false;
						UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
					}
				}
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		return verifedFlag;
	}
	
	/**
	 * Function Name :- getAlertMessage<br>
	 * Description :- To get alert Message
	 * @throws IOException 
	 */
	public String getAlertMessage() throws IOException{
		String textSuccess=null;
		if (WebDriverMain._isElementVisible(CreateUserPageObjects(Alert_Message)))
			textSuccess=WebDriverMain._getTextFromElement(CreateUserPageObjects(Alert_Message));
			return textSuccess;
		
	}
	
	/**
	 * Function Name :- verifySuccessMessage<br>
	 * Description :- To verify Success Message
	 * @throws IOException 
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess=WebDriverMain._getTextFromElement(CreateUserPageObjects(Success_Message));
		if(textSuccess.toLowerCase().contains(successmessage.toLowerCase())){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Function Name :- Verify_Session_StudentList<br>
	 * Description :- To verify Session Student List  is visible
	 *
	 */
	public boolean Close_Alerts() throws IOException{
		
		List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(CreateUserPageObjects(CloseAlerts));
		for (WebElement AlertEle : lstAlertsRow) {
			if (WebDriverMain._isElementClickable(AlertEle)) {
				//CommonUtility._scrollElement(AlertEle);
				CommonUtility._sleepForGivenTime(300);
				AlertEle.click();
				CommonUtility._sleepForGivenTime(1000);
			}
		}
		return true;
	}

}
