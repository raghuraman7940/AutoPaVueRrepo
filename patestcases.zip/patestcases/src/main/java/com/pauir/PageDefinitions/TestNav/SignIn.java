package com.pauir.PageDefinitions.TestNav;
/**
 * SignIn Page
 */

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;


public class SignIn {
	//Initialize variable
	WebDriver driver;
	
	//Sign In page locators
	public static String SigninForm="xpath|//form[@id='loginForm']";
	public static String username="xpath|//form[@id='loginForm']//input[@name='email']";
	public static String password="xpath|//form[@id='loginForm']//input[@name='password']";
	public static String SignInButton="xpath|//form[@id='loginForm']//button[@type='submit']";
	public static String Customer="xpath|//form[@id='loginForm']//div[@id='customerName']";
	public static String PearsonLogo="xpath|//img[@src='/cas/themes/pearson/images/pearson-logo-horizontal-2.svg']";
	public static String Menuoption="xpath|//ul[@id='userMenuDropDown']/li/a[@id='dropdown_signin']";
	public static String Alert_Message="xpath|//form[@id='loginForm']//div[@role='alert']/p";
	public static String CloseAlerts="xpath|//div[@role='alert']//button[@class='close']";
	
	/**
	 * Constructor
	 * Description :- To initialize the values.
	 * 
	 * @return boolean
	 */
	public SignIn(WebDriver driver) {
		this.driver = driver;

	}

	/**
	 * Function Name :- LoginPageObjects<br>
	 * Description :- To set Login page locator.
	 * 
	 * @return By
	 */
	public By LoginPageObjects(String byStrgylocValue)
	{
		 By by = null;
		 by=CommonUtility._getByLocator(byStrgylocValue);
		 return by;
	}

	/**
	 * Function Name :- typerUsername<br>
	 * Description :- To set Username field.
	 * @throws IOException 
	 * 
	 */
	public void typerUsername(String Username) throws IOException {
		TextBox._setTextBox(LoginPageObjects(username), Username);
	}
	/**
	 * Function Name :- IsUsernameFieldExist<br>
	 * Description :- To set Username field.
	 * @throws IOException 
	 * 
	 */
	public boolean IsUsernameFieldExist() throws IOException {
		boolean flag =WebDriverMain._isElementVisible(LoginPageObjects(username));
		return flag;
	}

	/**
	 * Function Name :- typePassword<br>
	 * Description :- To set password field.
	 * @throws IOException 
	 * 
	 */
	public void typePassword(String Password) throws IOException {
		TextBox._setTextBox(LoginPageObjects(password), Password);
	}

	/**
	 * Function Name :- Click_On_SignInButton<br>
	 * Description :- To click the signInButton
	 * @throws IOException 
	 * 
	 */
	public void Click_On_SignInButton() throws IOException {
		if(LeftClick._click(LoginPageObjects(SignInButton))){
			CommonUtility._sleepForGivenTime(500);
			CommonFunctions.PleaseWaitAndLoadingMessage();
		}
	}

	/**
	 * Function Name :- Click_On_SignInButton<br>
	 * Description :- To click the signInButton
	 * @throws IOException 
	 * 
	 */
	public boolean IsSignInButtonExist() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(SignInButton));
		return flag;
	}
	
	/**
	 * Function Name :- IsSignInHeaderExist<br>
	 * Description :- To verify the signIn to account
	 * @throws IOException 
	 * 
	 */
	public boolean IsSignInFormExist() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(SigninForm));
		return flag;
	}
	
	/**
	 * Function Name :- NavigatetoURL<br>
	 * Description :- To Navigate to given URL
	 * @throws IOException 
	 * 
	 */
	public void NavigatetoTestNavURL() throws IOException
	{
		String URL;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		URL=FileReaderManager.getInstance().getJsonReader().getTestNavUrl();
		WebDriverMain._get(URL) ;
		
	}
	/**
	 * Function Name :- doLogin<br>
	 * Description :- To login to given URL
	 * @throws IOException 
	 * 
	 */
	public void doLogin(String GivenUsername, String GivenPassword) throws IOException {
		//Sign In
		String Username;
		String Password;
		Username = GivenUsername;
		Password = GivenPassword;
		System.out.println("Username is:"+Username);
		System.out.println("Password is:"+Password);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		IsSignInFormExist();
		if (IsUsernameFieldExist()) {
			typerUsername(Username);
			typePassword(Password);
			//Click Login
			Click_On_SignInButton();
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
	}
	
	/**
	 * Function Name :- getAlertMessage<br>
	 * Description :- To get alert Message
	 * @throws IOException 
	 */
	public String getAlertMessage() throws IOException{
		String textSuccess=null;
		if (WebDriverMain._isElementVisible(LoginPageObjects(Alert_Message)))
			textSuccess=WebDriverMain._getTextFromElement(LoginPageObjects(Alert_Message));
			return textSuccess;
		
	}
	/**
	 * Function Name :- Verify_Session_StudentList<br>
	 * Description :- To verify Session Student List  is visible
	 *
	 */
	public boolean Close_Alerts() throws IOException{
	
			if (WebDriverMain._isElementVisible(LoginPageObjects(Alert_Message))) {
				LeftClick._click(LoginPageObjects(CloseAlerts));
				CommonUtility._sleepForGivenTime(1000);
				return true;
			}
			else
				return false;
	}

}

