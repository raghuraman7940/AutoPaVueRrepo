package com.pauir.PageDefinitions.Admin;
/**
 * Admin Home page
 */

import java.io.IOException;
import org.openqa.selenium.By;
import com.pauir.common.core.CommonFunctions;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.WebDriverMain;

public class AdminHome {

	// Home page locators
	public static String HOME = "xpath|//pa-context-bar/div/pa-title/span[@class='d-inline-block']";
	public static String HomeComponent = "xpath|//pa-home/span";
	public static String AdminHome = "xpath|//pa-main/main/pa-home/p";
	public static String USERICON = "xpath|//li[@class='profile-icon']/button/i[@class='fa fa-user']";
	public static String USERDROPDOWN = "xpath|//div[@id='navbarContent']/ul/div/li/kendo-popup";
	public static String Logout = "xpath|//kendo-popup//ul/li[contains(text(),'Logout')]";
	public static String YourAccount = "xpath|//kendo-popup//ul/li[contains(text(),'Your Account')]";
	public static String Menuoption = "xpath|//button/i[@class='fa fa-bars']";
	public static String Menuoption_Home = "xpath|//pa-navlinks//ul/li/a[contains(text(),'Home')]";
	public static String Menuoption_SystemConfig = "xpath|//pa-navlinks//ul/li/a[contains(text(),'System Configuration')]";
	public static String Menuoption_SystemConfig_RolesPerm = "xpath|//pa-navlinks//ul/ul/li/a[contains(.,'Roles and Permission')]";
	public static String Menuoption_PrdMgmt = "xpath|//pa-navlinks//ul/li/a[contains(text(),'Product Management')]";
	public static String Menuoption_PrdMgmt_TstMgmt = "xpath|//pa-navlinks//ul/ul/li/a[contains(.,'Test Management')]";
	public static String Menuoption_CustMgmt = "xpath|//pa-navlinks//ul/li/a[contains(text(),'Customer Management')]";
	public static String Menuoption_CustMgmt_TstMgmt = "xpath|//pa-navlinks//ul/ul/li/a[contains(.,'Test Management')]";
	
	public static String TestMgmt_Form = "xpath|//pa-test-management/ul/li/a[contains(text(),'Forms')]";
	public static String CustMgmtPage_Title="xpath|.//h5[contains(text(),'Customer Management')]";
	

	/**
	 * Function Name :- HomePageObjects<br>
	 * Description :- To set homepage page locator.
	 * 
	 * @return By
	 */
	public By HomePageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	/**
	 * Function Name :- VerifyLoggedinHomePage<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean WaitLoggedinAdminHomePage() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(2000);
		if (WebDriverMain._isElementVisible(HomePageObjects(AdminHome))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- VerifyLoggedinAdminHomePage<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean VerifyLoggedinAdminHomePage() throws IOException {
		String ActualText = WebDriverMain._getTextFromElement(HomePageObjects(AdminHome));
		if (ActualText.contains("Admin")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- VerifyLoggedinHomePage<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean VerifyAdminUserIcon() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		if (WebDriverMain._isElementPresent(HomePageObjects(USERICON))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- Logout<br>
	 * Description :- To Click logput from user dropdown.
	 *
	 */
	public boolean Logout() throws IOException {
		LeftClick._click(HomePageObjects(USERICON));
		if (WebDriverMain._isElementPresent(HomePageObjects(USERDROPDOWN))) {
			LeftClick._click(HomePageObjects(Logout));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- verifyTestMgmtPageNavigation<br>
	 * Description :- To verify Test Management Page Navigation.
	 *
	 */
	public boolean verifyTestMgmtPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(2000);
		if (WebDriverMain._isElementVisible(HomePageObjects(TestMgmt_Form))) {
			return true;
		} else {
			return false;
		}
		
	}
	
	/**
	 * Function Name :- verifyCustMgmtPageNavigation<br>
	 * Description :- To verify Customer Management Page Navigation.
	 *
	 */
	public boolean verifyCustMgmtPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(2000);
		if (WebDriverMain._isElementVisible(HomePageObjects(CustMgmtPage_Title))) {
			return true;
		} else {
			return false;
		}
		
	}
	
	/**
	 * Function Name :- MenuOtion<br>
	 * Description :- Select the menu options
	 * 
	 * @param Primary,
	 * @param Secondary
	 * @throws IOException
	 */
	public void MenuOtion(String Primary, String Secondary) throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		if (!WebDriverMain._isElementVisible(HomePageObjects(Menuoption_Home))) {
			LeftClick._click(HomePageObjects(Menuoption));
			CommonFunctions.PleaseWaitAndLoadingMessage();
		}
		switch (Primary.toLowerCase()) {
		case "home":
			LeftClick._click(HomePageObjects(Menuoption_Home));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			break;
		case "system configuration":
			LeftClick._click(HomePageObjects(Menuoption_SystemConfig));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			switch (Secondary.toLowerCase()) {
			case "roles and permission":
				LeftClick._click(HomePageObjects(Menuoption_SystemConfig_RolesPerm));
				CommonFunctions.PleaseWaitAndLoadingMessage();
				CommonUtility._sleepForGivenTime(5000);
				break;
			}
			break;
		case "product management":
			LeftClick._click(HomePageObjects(Menuoption_PrdMgmt));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			switch (Secondary.toLowerCase()) {
			case "test management":
				LeftClick._click(HomePageObjects(Menuoption_PrdMgmt_TstMgmt));
				CommonFunctions.PleaseWaitAndLoadingMessage();
				CommonUtility._sleepForGivenTime(5000);
				break;
			}
			break;
		case "customer management":
			LeftClick._click(HomePageObjects(Menuoption_CustMgmt));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			switch (Secondary.toLowerCase()) {
				case "customer details":
					LeftClick._click(HomePageObjects(Menuoption_CustMgmt));
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(5000);
					break;

			}
			break;
		}
		LeftClick._click(HomePageObjects(Menuoption));

	}
}
