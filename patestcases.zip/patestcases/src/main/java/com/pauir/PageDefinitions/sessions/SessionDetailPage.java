package com.pauir.PageDefinitions.sessions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.aventstack.extentreports.Status;
import webdriver.main.CommonUtility;
import webdriver.main.KendoDropdown;
import webdriver.main.KendoGrid;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class SessionDetailPage {
	// Initialize
	CommonFunctions common;

	// Session Details page objects
	public static String SessionDetailspage_Title = "xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String btnEdit = "xpath|//a/span[contains(text(),'Edit')]";
	public static String btnSave = "xpath|//button[contains(text(),'Save')]";
	public static String btnCancel = "xpath|//button[contains(text(),'Cancel')]";
	public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'home')]";
	public static String Breadcrumb_ViewSessions = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Sessions')]";
	public static String SessionDetails_Section = "xpath|//pa-session-details-container//form/div[1]/div[1]//h2";
	public static String LnkWatchSession = "xpath|//pa-session-details-container//a[contains(text(),'Watch this session')]";
	public static String LnkStopWatchSession = "xpath|//pa-session-details-container//a[contains(text(),'Stop watching this session')]";
	public static String LnkWatchers = "xpath|//pa-session-details-container//label[contains(text(),'Active Watchers')]/following-sibling::span/button";
	public static String LstWatchers = "xpath|//ngb-popover-window//ul/li";
	public static String Watchersdropdown = "xpath|//kendo-dropdownlist[@id='user']//span[@class='k-input']";
	public static String WatchersdropdownInput = "xpath|//kendo-popup//input";
	public static String AddWatchersLnk = "xpath|//kendo-dropdownlist[@id='user']/.././following-sibling::div/button[contains(text(),'Add')]";
	public static String CloseAlerts = "xpath|//pa-alerts//button[@class='close']";
	// Student List page objects
	public static String StudentListpage_Title = "xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]/h1";
	public static String btnAddStudent = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Add Student')]";
	public static String btnDelete = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Remove')]";
	public static String btnRefresh = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Refresh')]";
	public static String btnHandScore = "xpath|//div[@role='tabpanel']//pa-grid-actions//button[contains(text(),'Teacher Hand Scoring')]";
	public static String btnPrintTicker = "xpath|//div[@role='tabpanel']//pa-grid-actions//button[contains(text(),'Print')]";
	public static String btnPrintAllTicker = "xpath|//div[@role='tabpanel']//pa-grid-actions//button[contains(text(),'Print Testing Ticket')]";
	public static String StuRowPresent = "xpath|//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String StuDatagridHeaderRow = "xpath|//pa-session-details-container//kendo-grid//table/thead/tr/th";
	public static String StuList = "xpath|.//kendo-grid//table/thead/tr[1]/th[1]";
	public static String SearchInputFilter = "xpath|//pa-session-details-container//input[@placeholder='Search']";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String Session_StudentList_Section = "xpath|//pa-session-details-container//kendo-tabstrip/ul/li/span[contains(.,'Student List')]";
	public static String Session_StudentListSection = "xpath|//pa-session-details-container//kendo-tabstrip";
	public static String btnResetpswd = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Reset Student Password')]";
	public static String btnPrintAllTickets = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Print all testing ticket(s)')]";
	public static String btnPrintSelectedTickets = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Print selected testing ticket(s)')]";
	public static String cntStudentInSession = "xpath|//div[contains(text(),'Total Students:')]";
	public static String studentTestTicket = "xpath|//pa-print-student-test-ticket//div[contains(@class,'container-fluid')]";

	public static String btnUpdateStatus = "xpath|//div[@role='tabpanel']//pa-grid-actions//button[contains(text(),'Update Status')]";
	public static String btnUpdateStatus_MenuOptions = "xpath|//div[@class='popover-body']//button";
	public static String Success_Message = "xpath|//pa-alerts//div[@role='alert']/p/span";
	public static String Field_Control_Error_Message = "xpath|//pa-field-messages//div[contains(@class,'form-control-error')]";
	public static String lblWatchingSession = "xpath|//pa-session-details-container//label[contains(text(),'Watching this session')]";
	public static String rSwitchWatchingSession = "xpath|//pa-session-details-container//label[contains(text(),'Watching this session')]/./following-sibling::kendo-switch[contains(@class,'k-switch')]/span[@class='k-switch-container']";
	public static String rSwitchOn = "xpath|//pa-session-details-container//label[contains(text(),'Watching this session')]/./following-sibling::kendo-switch[contains(@class,'k-switch-on')]";
	public static String rSwitchOff = "xpath|//pa-session-details-container//label[contains(text(),'Watching this session')]/./following-sibling::kendo-switch[contains(@class,'k-switch-off')]";
	public static String sessStudStatusbar = "xpath|//pa-session-details-container//pa-levels";
	public static String SuccessMessage = "xpath|//pa-alerts//div[@role='alert']/p/span";

	public static String btnReports = "xpath|//div[@role='tabpanel']//pa-grid-actions//button[contains(text(),'Reports')]";
	public static String LstReports = "xpath|//pa-grid-actions//div[@class='popover-body']//div[contains(@class,'popover-item')]/button";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String SelectAllRecords = "xpath|//kendo-grid//table/thead/tr/th/label[contains(@for ,'select-all')]";
	public static String ViewAllStatus = "xpath|//pa-session-details-container//button[contains(.,'view all')]";

	public static String btnDownloadTest = "xpath|//button[contains(text(),'Download Test')]";
	public static String SessionDetailbtn = "xpath|//pa-breadcrumb//button[contains(text(),'Session Info')]";
	public static String lbludpateDate = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Session:')]/following-sibling::span";

	public static String btnTHS_MenuOptions = "xpath|//div[@class='popover-body']//button";

	public static String optHandScore = "xpath|//pa-grid-actions//div[@class='popover-body']//div[contains(@class,'popover-item')]//button[contains(text(),'Hand Score')]";
	public static String optSubmit = "xpath|//pa-grid-actions//div[@class='popover-body']//div[contains(@class,'popover-item')]//button[contains(text(),'Submit')]";
	public static String submitMsg = "xpath|//pa-alerts//div[@role='alert']/p/span";

	public static String sessioninfoexpandup = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Session:')]/../..//i[contains(@class,'fa-angle-up')]";
	public static String sessioninfocollapsedown = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Session:')]/../..//i[contains(@class,'fa-angle-down')]";
	public static String sessioninfobody = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Session:')]/../../../../div[contains(@class,'card-body')]";

	public static String sessionstatusexpandup = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Session Status')]/../..//i[contains(@class,'fa-angle-up')]";
	public static String sessionstatuscollapsedown = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Session Status')]/../..//i[contains(@class,'fa-angle-down')]";
	public static String sessionstatusbody = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Session Status')]/../../../../div[contains(@class,'card-body')]";

	public static String btnPrintAccomm = "xpath|//pa-session-details-container//button[contains(text(),'Print Accommodations')]";
	public static String btnViewAccomm = "xpath|//pa-session-details-container//button[contains(text(),'View Accommodations')]";
	public static String scrAccommSummary = "xpath|//pa-session-details-container//div[contains(@class,'ng-trigger-dialogSlideInAppear')]//div[contains(@class,'k-dialog-title')]//h3[contains(text(),'Accommodations')]";
	public static String accommList = "xpath|//pa-session-details-container//pa-print-accommodations-modal//kendo-pdf-export/div/div[1]";
	public static String accommStudList = "xpath|//pa-session-details-container//pa-print-accommodations-modal//kendo-pdf-export/div/div[2]";
	public static String downloadLink = "xpath|//kendo-dialog-titlebar[contains(@class,'k-window-titlebar')]//a[contains(text(),'Download')]";
	public static String closeAccommSummary = "xpath|//kendo-dialog-titlebar[contains(@class,'k-window-titlebar')]//div[contains(@class,'k-window-actions')]//a[@aria-label='Close']";
	public static String sessionprogress = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Section Progress')]";
	public static String sessionprogressexpandup = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Section Progress')]/../..//i[contains(@class,'fa-angle-up')]";
	public static String sessionprogresscollapsedown = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Section Progress')]/../..//i[contains(@class,'fa-angle-down')]";
	public static String sessionprogressbody = "xpath|//pa-session-details-container//div[contains(@class,'card-header')]//h2[contains(text(),'Section Progress')]/../../../../div[contains(@class,'card-body')]";

	public static String winAccomRowPresent = "xpath|//pa-print-accommodations-modal//kendo-grid//table/tbody/tr";
	public static String winAccomDatagridHeaderRow = "xpath|//pa-print-accommodations-modal//kendo-grid//table/thead/tr/th";
	public static String winNoAccomRecords = "xpath|//kendo-grid//table/tbody/tr[contains(@class,'norecords')]";
	// pa-print-accommodations-modal//kendo-grid//table/thead/tr/th

	public static String btnUnsubmit = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Unsubmit')]";

	public static String btnMove = "xpath|//button[contains(text(),'Move')]";
	public static String moveClosebtn = "xpath|//pa-placeholder//kendo-dialog-titlebar//span[@class =\"k-icon k-i-x\"]";
	public static String promptDrpdown = "xpath|//kendo-dialog//span[@class=\"k-i-arrow-s k-icon\"]";
	public static String sessionRow = "xpath|//pa-root//div//kendo-list/div/ul/li[1]";
	public static String DropdownMoveSession = "xpath|//kendo-dropdownlist[@id='moveToSession']//span[@class='k-input']";
	public static String DropdownMoveSessionAutoPop = "xpath|//kendo-popup//input";
	public static String movebtn = "xpath|//pa-session-details-student-list//kendo-dialog-actions//button[contains(text(), \"Move\")]";
	public static String cancelbtn = "xpath|//pa-session-details-student-list//kendo-dialog-actions//button[contains(text(), \"Cancel\")]";
	public static String addirrgularitiesbtn = "xpath|//pa-grid-actions//button[contains(text(),'Enter Exception')]";
	public static String irregularitieswindow = "xpath|//kendo-dialog//div[contains(@class,'ng-trigger-dialogSlideInAppear')]//h2";
	public static String commentbox = "xpath|//kendo-dialog//textarea";
	public static String RemoveIrregCheckbox = "xpath|//kendo-dialog//pa-session-irregularity-modal//form//ul//li//input";
	public static String btnEditIrregWindow = "xpath|//kendo-dialog//kendo-dialog-titlebar//a/span[contains(text(),'Edit')]";
	public static String saveandclosebtn = "xpath|//kendo-dialog//button[contains(text(),'Save & Close')]";
	public static String savechangesbtn = "xpath|//kendo-dialog//button[contains(text(),'Save Changes')]";
	public static String cancelbtnonirregwindow = "xpath|//kendo-dialog//button[contains(text(),'Cancel')]";
	public static String textonirregwindow = "xpath|//kendo-dialog//pa-session-irregularity-modal//div[@class='ng-star-inserted']//h3";
	public static String irregcapsule = "xpath|//kendo-grid-list//table//button[contains(text(),'Exception')]";
	public static String irregularitieslabels = "xpath|//pa-session-irregularity-modal//li[@class='ng-star-inserted']//div[@class='text-left']";
	public static String closeirregularitieswindow = "xpath|//kendo-dialog//div[contains(@class,'k-window-actions')]//a[@role='button']";
	public static String studname = "xpath|//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr/td/button[contains(@class,'btn-link')]";

	public static String iframePreview = "xpath|//pa-session-preview-form//iframe";
	public static String  answerSheet= "xpath|//div[@id='content']";
	public static String btnPrintAnswerSheet = "xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Print Answer Sheet(s)')]";
	public static String DropdownTicketsPage = "xpath|//pa-print-student-test-ticket/div[contains(@class,'fixed-bar')]//kendo-dropdownlist//span[@class='k-input']";
	public static String ProceedtoPrintbtn = "xpath|//pa-print-student-test-ticket/div[contains(@class,'fixed-bar')]//button[contains(text(),'Print')]";
	public static String LnkExporttoCSV = "xpath|//button[contains(text(),'Export to CSV')]";
	public static String lblSessionName = "xpath|//pa-session-details-container//span[contains(text(),'Last updated')]/../h2";
	public static String PrintingOption_Bar = "xpath|//pa-print-student-test-ticket/div[contains(@class,'fixed-bar')]";
	public static String PrintingOption_Bar_title = "xpath|//pa-print-student-test-ticket/div[contains(@class,'fixed-bar')]//h5";
	
	public static String Rep_DownloadReport = "xpath|//app-student-isr//app-primarybutton/button/span";
	
	/**
	 * Function Name :- SessionDetailPageObjects<br>
	 * Description :- To set Session Details Page Objects locator.
	 * 
	 * @return By
	 */
	public By SessionDetailPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	/**
	 * Function Name :- verifySessionDetailsNavigation<br>
	 * Description :- To verify Session Detail Page Navigation.
	 *
	 */
	public boolean verifySessionDetailsNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._getTextFromElement(SessionDetailPageObjects(SessionDetailspage_Title))
				.contains(Constants.SessionDetailsPageTitle))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify edit button is visible
	 *
	 */
	public boolean EditButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnEdit)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- EditButton_isEnabled<br>
	 * Description :- To verify Edit button is enabled
	 *
	 */
	public boolean EditButton_isEnabled() throws IOException {
		WebElement delete = WebDriverMain._getElementWithWait(SessionDetailPageObjects(btnEdit));
		String attributeText = delete.getAttribute("innerHTML");
		if (attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- Verify_Session_Info<br>
	 * Description :- To verify Session info section is visible
	 *
	 */
	public boolean Verify_Session_Info() throws IOException {

//		WebElement delete = WebDriverMain._getElementWithWait(SessionDetailPageObjects(sessioninfobody));
//		String attributeText = delete.getAttribute("innerHTML");
//		if(attributeText.contains("disabled"))
//			return false;
//		else
//			return true;
//		
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessioninfobody)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- verifyViewSessionDetails<br>
	 * Description :- To verify the view Session details Page
	 * 
	 * @throws IOException
	 */
	public boolean verifyViewSessionDetails(HashMap<String, String> MapFilledField) throws IOException {
		boolean verifedFlag = true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try {

			By objlocator = null;
			for (Map.Entry<String, String> entry : MapFilledField.entrySet()) {
				System.out.println("INFO ViewMap - Fields  : " + entry.getKey());
				String sFieldLabel = entry.getKey();
				String sFieldValue = entry.getValue();
				if (sFieldLabel.length() >= 1) {
					// Testing days validation
					switch (sFieldLabel.toLowerCase()) {
					case "su":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "Su";
						else
							sFieldValue = "";
						break;
					case "m":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "M";
						else
							sFieldValue = "";
						break;
					case "tu":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "Tu";
						else
							sFieldValue = "";
						break;
					case "w":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "W";
						else
							sFieldValue = "";
						break;
					case "th":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "Th";
						else
							sFieldValue = "";
						break;
					case "f":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "F";
						else
							sFieldValue = "";
						break;
					case "sa":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "Sa";
						else
							sFieldValue = "";
						break;

					case "watchers":
						sFieldLabel = "Active Watchers";
						sFieldValue = "";
						break;
					case "created date":
						if (sFieldValue.substring(0, 1).equalsIgnoreCase("0"))
							sFieldValue = sFieldValue.substring(1);
						break;
					}
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-session-details-container//label[contains(text(),'" + sFieldLabel + "')]");
					boolean isFieldLabelPresent = WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if (sFieldValue.length() > 1) {
							MapDgStuRec.put(sFieldLabel, sFieldValue);
							objlocator = CommonUtility._getObjectLocator(
									"xpath=//pa-session-details-container//label[contains(text(),'" + sFieldLabel
											+ "')]/following-sibling::span[contains(text(),'" + sFieldValue + "')]");
							boolean isFieldValuePresent = WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								verifedFlag = false;
								UMReporter.log(Status.FAIL, "The field " + sFieldLabel
										+ " not matched with expected value : " + sFieldValue);
							}
						}
					}
				}
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}

		if (verifedFlag)
			UMReporter.log(Status.PASS,
					"User have access to view Session field value in Session details page :" + MapDgStuRec);
		return verifedFlag;
	}

	/**
	 * Function Name :- verifySessionName<br>
	 * Description :- To verify the Session name in Session details Page
	 * 
	 * @throws IOException
	 */
	public boolean verifySessionName(String SessionName) throws IOException {
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//pa-session-details-container//h2[contains(text(),'"+SessionName+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;

	}

	/**
	 * Function Name :- verifySessionDetailsLabel<br>
	 * Description :- To verify the Session label on Session details page form.
	 *
	 */
	public boolean verifySessionDetailsLabel(String labelmessage) throws IOException {
		By objlocator = CommonUtility._getObjectLocator(
				"xpath=//pa-session-details-container//label[contains(text(),'" + labelmessage + "')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- GetValueforSessionLabel<br>
	 * Description :- To get the value for label on Session details page form.
	 *
	 */
	public String GetValueforSessionLabel(String labelmessage) throws IOException {
		String LabelValue = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-details-container//label[contains(text(),'"
				+ labelmessage + "')]/./following-sibling::span");
		if (WebDriverMain._isElementVisible(objlocator)) {
			LabelValue = WebDriverMain._getTextFromElement(objlocator);
			return LabelValue;

		}
		return LabelValue;
	}

	/**
	 * Function Name :- clickViewSessionBreadcrumb<br>
	 * Description :- To click View session Breadcrumb.
	 *
	 */
	public boolean clickViewSessionBreadcrumb() throws IOException {
		boolean flag = false;
		try {
			CommonUtility._scrollup();
			flag = LeftClick._click(SessionDetailPageObjects(Breadcrumb_ViewSessions));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		} catch (Exception e) {
			return false;
		}
		return flag;
	}

	/**
	 * Function Name :- waitForautorefresh<br>
	 * Description :- To wait for auto refresh bar is visible
	 */
	public void waitForautorefresh(int maxtimeout) throws Exception {
		int count = 0;
		System.out.print("Wait for " + (maxtimeout / 60) + " mins auto-refresh...");
		while ((WebDriverMain._isElementVisible(SessionDetailPageObjects(sessStudStatusbar))) && (count < maxtimeout)) {
			System.out.print(".");
			CommonUtility._sleepForGivenTime(1000);
			count = count + 1;

		}
		System.out.println("wait done");

	}

	/**
	 * Function Name :- clickWatchThisSession<br>
	 * Description :- To click Watch this session.
	 *
	 */
	public boolean clickWatchThisSession() throws IOException {
		boolean flag = false;
		try {
			CommonUtility._scrollup();
			flag = LeftClick._click(SessionDetailPageObjects(LnkWatchSession));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		} catch (Exception e) {
			return false;
		}
		return flag;
	}

	/**
	 * Function Name :- clickStopWatchThisSession<br>
	 * Description :- To click Stop Watch this session.
	 *
	 */
	public boolean clickStopWatchThisSession() throws IOException {
		boolean flag = false;
		try {
			CommonUtility._scrollup();
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(LnkStopWatchSession))) {
				flag = LeftClick._click(SessionDetailPageObjects(LnkStopWatchSession));
				CommonFunctions.PleaseWaitAndLoadingMessage();
				CommonUtility._sleepForGivenTime(1000);
				return true;
			}
		} catch (Exception e) {
			return false;
		}
		return flag;
	}

	/**
	 * Function Name :- SetWatchingSession<br>
	 * Description :- To Set Watch this session.
	 *
	 */
	public boolean SetWatchingSession(String strValue) throws IOException {
		boolean flag = false;
		try {
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(lblWatchingSession))) {
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(rSwitchWatchingSession))) {
					CommonUtility._scrollup();
					if (strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")) {
						if (WebDriverMain._isElementVisible(SessionDetailPageObjects(rSwitchOn)))
							return true;
						else if (WebDriverMain._isElementVisible(SessionDetailPageObjects(rSwitchOff))) {
							flag = LeftClick._click(SessionDetailPageObjects(rSwitchWatchingSession));
							CommonFunctions.PleaseWaitAndLoadingMessage();
							CommonUtility._sleepForGivenTime(1000);
							return flag;
						}
					} else {
						if (WebDriverMain._isElementVisible(SessionDetailPageObjects(rSwitchOff)))
							return true;
						else if (WebDriverMain._isElementVisible(SessionDetailPageObjects(rSwitchOn))) {
							flag = LeftClick._click(SessionDetailPageObjects(rSwitchWatchingSession));
							CommonFunctions.PleaseWaitAndLoadingMessage();
							CommonUtility._sleepForGivenTime(1000);
							return flag;
						}

					}

				}

			}
		} catch (Exception e) {
			return false;
		}
		return flag;
	}

	/**
	 * Function Name :- SessionInfoExpand<br>
	 * Description :- To Expand/Collapse Watch this session.
	 *
	 */
	public boolean SessionInfoExpand(String strValue) throws IOException {
		boolean flag = false;
		try {
			if (strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")) {
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessioninfoexpandup))) {
					if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessioninfobody)))
						return true;// Display session info if collapse
				} else if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessioninfocollapsedown))) {
					flag = LeftClick._click(SessionDetailPageObjects(sessioninfocollapsedown));
					CommonUtility._sleepForGivenTime(1000);
					if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessioninfobody)))
						return true;// Display session info if collapse
				}
			} else {
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessioninfocollapsedown))) {
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(sessioninfobody)))
						return true;// Not display session info if collapse
				} else if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessioninfoexpandup))) {
					flag = LeftClick._click(SessionDetailPageObjects(sessioninfoexpandup));
					CommonUtility._sleepForGivenTime(1000);
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(sessioninfobody)))
						return true; // Not display session info if collapse
				}

			}

		} catch (Exception e) {
			return false;
		}
		return flag;
	}

	/**
	 * Function Name :- SessionStatusBladeExpand<br>
	 * Description :- To Expand/Collapse Watch this session status.
	 *
	 */
	public boolean SessionStatusBladeExpand(String strValue) throws IOException {
		boolean flag = false;
		try {
			if (strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")) {
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionstatusexpandup))) {
					if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionstatusbody)))
						return true;// Display session info if collapse
				} else if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionstatuscollapsedown))) {
					flag = LeftClick._click(SessionDetailPageObjects(sessionstatuscollapsedown));
					CommonUtility._sleepForGivenTime(1000);
					if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionstatusbody)))
						return true;// Display session info if collapse
				}
			} else {
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionstatuscollapsedown))) {
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionstatusbody)))
						return true;// Not display session info if collapse
				} else if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionstatusexpandup))) {
					flag = LeftClick._click(SessionDetailPageObjects(sessionstatusexpandup));
					CommonUtility._sleepForGivenTime(1000);
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionstatusbody)))
						return true; // Not display session info if collapse
				}

			}

		} catch (Exception e) {
			return false;
		}
		return flag;
	}

	/**
	 * Function Name :- Verify_Session_Info<br>
	 * Description :- To verify Session info section is visible
	 *
	 */
	public boolean Verify_Session_Status_Blade() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionstatusbody)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- VerifyWatchList<br>
	 * Description :- To verify Watch this session.
	 *
	 */
	public List<String> VerifyWatchList() throws IOException {
		boolean flag = false;
		List<String> MapDgColValues = null;
		String watchers = null;
		int wCount = 0;
		try {
			CommonUtility._scrollup();
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(LnkWatchers))) {
				watchers = WebDriverMain._getTextFromElement(SessionDetailPageObjects(LnkWatchers));
				if (CommonUtility.isNumeric(watchers))
					wCount = Integer.parseInt(watchers);
				if (wCount > 0) {
					flag = LeftClick._click(SessionDetailPageObjects(LnkWatchers));
					CommonUtility._sleepForGivenTime(2000);
					if (WebDriverMain._isElementVisible(SessionDetailPageObjects(LstWatchers))) {
						List<WebElement> dataRec = WebDriverMain
								._getElementsWithWait(SessionDetailPageObjects(LstWatchers));
						MapDgColValues = new ArrayList<String>();
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		} catch (Exception e) {
			return MapDgColValues;
		}
		return MapDgColValues;
	}

	/**
	 * Function Name :- VerifyWatchList<br>
	 * Description :- To verify Watch this session.
	 *
	 */
	public List<String> VerifyWatchList(String Watchers) throws IOException {
		boolean flag = false;
		List<String> MapDgColValues = null;
		String watchers = null;
		int wCount = 0;
		try {
			CommonUtility._scrollup();
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(LnkWatchers))) {
				watchers = WebDriverMain._getTextFromElement(SessionDetailPageObjects(LnkWatchers));
				if (CommonUtility.isNumeric(watchers))
					wCount = Integer.parseInt(watchers);
				if (wCount > 0) {
					flag = LeftClick._click(SessionDetailPageObjects(LnkWatchers));
					CommonUtility._sleepForGivenTime(2000);
					if (WebDriverMain._isElementVisible(SessionDetailPageObjects(LstWatchers))) {
						List<WebElement> dataRec = WebDriverMain
								._getElementsWithWait(SessionDetailPageObjects(LstWatchers));
						MapDgColValues = new ArrayList<String>();
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnValue = dataRec.get(iCol).getText();

							if (sDGColmnValue.toLowerCase().contains(Watchers.toLowerCase())) {
								MapDgColValues.add(sDGColmnValue);
								return MapDgColValues;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			return MapDgColValues;
		}
		return MapDgColValues;
	}

	/**
	 * Function Name :- VerifyWatchList<br>
	 * Description :- To verify Watch this session.
	 *
	 */
	public String AddWatchList(String Watchers) throws IOException {
		boolean flag = false;
		String FilledFieldValue = null;
		try {
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(Watchersdropdown))) {
				// Fill the Value base fieldtype, locator, valueWatchersdropdown
				FilledFieldValue = common.FillInputswitchCase("dropdownlist",
						SessionDetailPageObjects(Watchersdropdown), SessionDetailPageObjects(WatchersdropdownInput),
						Watchers, "Watchers");
				if (FilledFieldValue != null) {
					CommonUtility._sleepForGivenTime(1500);
					// Filled label and value stored for validation in confirmation page
					flag = LeftClick._click(SessionDetailPageObjects(AddWatchersLnk));
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);

				}

			}
		} catch (Exception e) {
			return FilledFieldValue;
		}
		return FilledFieldValue;
	}

	/**
	 * Function Name :- Verify_Session_StudentList<br>
	 * Description :- To verify Session Student List is visible
	 *
	 */
	public boolean Verify_Session_StudentList() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(Session_StudentList_Section))) {
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(SessionDetailPageObjects(lbludpateDate));
			CommonUtility._scrollElement(elmStudentlst);
			return true;
		} else
			return false;
	}

	/**
	 * Function Name :- Searchfill_StudName<br>
	 * Description :- To Fill Name Filter in Class details Page.
	 *
	 */
	public boolean Searchfill_StudName(String Studname) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(SessionDetailPageObjects(SearchInputFilter));
		if (flag) {
			flag = TextBox._setTextBox(SessionDetailPageObjects(SearchInputFilter), Studname);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}

	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Class Details Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag = TextBox._setTextBox(SessionDetailPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}

	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		WebElement targetElement = WebDriverMain._getElementWithWait(SessionDetailPageObjects(lbludpateDate));
		CommonUtility._scrollElement(targetElement);
		CommonUtility._sleepForGivenTime(3000);
		boolean flag = WebDriverMain._isElementVisible(SessionDetailPageObjects(SearchInputFilter));
		if (flag) {
			flag = LeftClick._click(SessionDetailPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		return flag;
	}

	/**
	 * Function Name :- getStudsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public HashMap<String, String> getStudsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() > 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
									+ "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

	/**
	 * Function Name :- getStuColumnHeaderDetails<br>
	 * Description :- To get Students Col header Details.
	 *
	 */
	public List<String> getStuColumnHeaderDetails() throws IOException {
		By objlocator = null;
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader = new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifyStusearchresultsDetails<br>
	 * Description :- To get Students search results Details.
	 *
	 */
	public List<String> verifyStusearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
									+ "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}

			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- verifyStuGridHyperlinks<br>
	 * Description :- To verify Students results hyperlink Details.
	 *
	 */
	public List<String> verifyStuGridHyperlinks(int rowindex) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				MapDgOrgRec = new HashMap<String, String>();
				objlocator1 = CommonUtility._getObjectLocator(
						"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
								+ "]/td/div[contains(@class,'btn-link')]");

				if (WebDriverMain._isElementPresent(objlocator1)) {
					if (rowindex >= Irow) {
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey(Constants.FDStudName)
								&& (MapDgOrgRec.containsKey(Constants.StudDetFDStudID))) {
							String SearchOrg = MapDgOrgRec.get(Constants.FDStudName) + " - "
									+ MapDgOrgRec.get(Constants.StudDetFDStudID);
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- verifyStuGridNoHyperlinks<br>
	 * Description :- To verify Students results not hyperlink Details.
	 *
	 */
	public List<String> verifyStuGridNoHyperlinks(int rowindex) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				MapDgOrgRec = new HashMap<String, String>();
				objlocator1 = CommonUtility._getObjectLocator(
						"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
								+ "]/td/div[contains(@class,'btn-link')]");
//					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
				if (!WebDriverMain._isElementPresent(objlocator1)) {
					if (rowindex >= Irow) {
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey(Constants.FDStudName)
								&& (MapDgOrgRec.containsKey(Constants.StudDetFDStudID))) {
							String SearchOrg = MapDgOrgRec.get(Constants.FDStudName) + " - "
									+ MapDgOrgRec.get(Constants.StudDetFDStudID);
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- GetStudentDetails<br>
	 * Description :- To get Students Details.
	 *
	 */
	public HashMap<String, String> GetStudentDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						return MapDgOrgRec;
					}
				}
			}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

	/**
	 * Function Name :- verifyStuGridPagination<br>
	 * Description :- To verify Students grid pagination.
	 *
	 */
	public int verifyStuGridPagination() throws IOException {
		int maxpage = 0;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		maxpage = KendoGrid.GetShowingMaxItems();
		System.out.println("Stu Page : " + maxpage);
		if (maxpage > 29) {
			// Select Next Page
			KendoGrid.SelectNextPage();
			lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
			System.out.println("Stu Next Row Count : " + lstOrgrRow.size());
			// Select First Page
			KendoGrid.SelectPreviousPage();
		}
		return maxpage;
	}

	/**
	 * Function Name :- verifyStudentSearchresultsSorting<br>
	 * Description :- To verify Student search results sorting .
	 *
	 */
	public List<String> verifyStudentSearchresultsSorting(String ColName) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Student Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if ((lstOrgrRow.size() >= 2)) {
			for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues = new ArrayList<String>();
					int datacounter = iCol + 1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-container//kendo-grid//table/thead/tr/th[" + datacounter
										+ "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr/td["
										+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}

	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> verifyStusearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator(
							"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
									+ "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele = WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele != null) {
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey(Constants.FDStudName)
								&& (MapDgOrgRec.containsKey(Constants.StudDetFDStudID))) {
							String SearchOrg = MapDgOrgRec.get(Constants.FDStudName) + " - "
									+ MapDgOrgRec.get(Constants.StudDetFDStudID);
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- verifyStudSearchresultsDetailsfromtext<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public List<String> verifyStudSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails = new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				MapDgOrgRec = new HashMap<String, String>();
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
								+ "]/td");
				List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
				for (int iCol = 0; iCol < dataRec.size(); iCol++) {
					String sDGColmnName = lstheaderRow.get(iCol).getText();
					String sDGColmnValue = dataRec.get(iCol).getText();
					MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
				}
				if (MapDgOrgRec.containsKey(Constants.FDStudName)
						&& (MapDgOrgRec.containsKey(Constants.StudDetFDStudID))) {
					String SearchOrg = MapDgOrgRec.get(Constants.FDStudName) + " - "
							+ MapDgOrgRec.get(Constants.StudDetFDStudID);
					if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
						MapDgOrgdetails.add(SearchOrg);
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- verifyStudSearchresultsDetailsfromtext<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public List<String> verifyStudSearchresultsDetailsfromlist(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		// CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(NoRecords))) {
				MapDgOrgdetails = new ArrayList<String>();
				MapDgOrgRec = new HashMap<String, String>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
									+ "]/td[2]");
					WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
					if (dataRec != null) {
						String sDGStuName = dataRec.getText().trim();
						if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase())) {
							List<WebElement> lstheaderRow = WebDriverMain
									._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
							objlocator = CommonUtility._getObjectLocator(
									"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> seldataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < seldataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = seldataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							MapDgOrgdetails.add(MapDgOrgRec.toString());
							return MapDgOrgdetails;
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- getStudStatusfromlist<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public String getStudStatusfromlist(int rowindex, String ColName, String SearchText) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		String RetnStuStatus = null;
		// Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			// Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter = iCol + 1;
				List<WebElement> lstOrgrRow = WebDriverMain
						._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
				System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(NoRecords))) {
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							MapDgOrgdetails = new ArrayList<String>();
							if (rowindex >= rowindex) {
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td[2]");
								String sDGStudNameValue = WebDriverMain._getTextFromElement(objlocator);

								if (SearchText.toLowerCase().contains(sDGStudNameValue.toLowerCase())) {
									objlocator = CommonUtility._getObjectLocator(
											"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
													+ Irow + "]/td[" + datacounter + "]");
									WebElement dataStatusRec = WebDriverMain._getElementWithWait(objlocator);
									if (dataStatusRec != null) {
										RetnStuStatus = dataStatusRec.getText().trim();
										String SearchStuStatus = sDGStudNameValue + " - " + RetnStuStatus;
										MapDgOrgdetails.add(SearchStuStatus);
										return RetnStuStatus;
									}
								}

							}
						}
						return RetnStuStatus;
					} else
						System.out.println("No record found");

				} else
					System.out.println("No record found");
			}
		}
		return RetnStuStatus;
	}

	/**
	 * Function Name :- getStudStatusfromlist<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public HashMap<String, String> getStudStatusfromlist(int rowindex, String ColName) throws IOException {
		By objlocator, objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		// Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			// Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter = iCol + 1;
				List<WebElement> lstOrgrRow = WebDriverMain
						._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
				System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(NoRecords))) {
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							MapDgOrgRec = new HashMap<String, String>();
							if (rowindex >= rowindex) {
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td[" + datacounter + "]");
								String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td[2]");
								String sDGStudNameValue = WebDriverMain._getTextFromElement(objlocator);
								if (MapDgOrgRec.containsKey(sDGStudNameValue))
									MapDgOrgRec.put(sDGStudNameValue + "|" + Irow, sDGColmnValue);
								else
									MapDgOrgRec.put(sDGStudNameValue, sDGColmnValue);
							}
						}
						return MapDgOrgRec;
					} else
						System.out.println("No record found");

				} else
					System.out.println("No record found");
			}
		}
		return MapDgOrgRec;
	}

	/**
	 * Function Name :- SelectonStuCheckbox<br>
	 * Description :- To click Student Checkbox.
	 *
	 */
	public boolean SelectonStuCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator("xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm != null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> SelectonStuCheckbox(int rowindex) throws IOException {
		By objlocator, objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			// if have Records
			if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(NoRecords))) {
				MapDgOrgdetails = new ArrayList<String>();
				MapDgdetails = new ArrayList<HashMap<String, String>>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
						WebElement chbxele = WebDriverMain._getElementWithWait(objlocator1);
						if (chbxele != null) {
							LeftClick.clickByWebElementJS(chbxele);
							objlocator = CommonUtility._getObjectLocator(
									"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							MapDgdetails.add(MapDgOrgRec);
							if (MapDgOrgRec.containsKey(Constants.FDStudName)
									&& (MapDgOrgRec.containsKey(Constants.StudDetFDStudID))
									&& (MapDgOrgRec.containsKey(Constants.FDStatus))) {
								String SearchOrg = MapDgOrgRec.get(Constants.FDStudName) + " - "
										+ MapDgOrgRec.get(Constants.StudDetFDStudID) + " - "
										+ MapDgOrgRec.get(Constants.FDStatus);
								MapDgOrgdetails.add(SearchOrg);
							}
						}
					}
				}
				return MapDgOrgdetails;
			}
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- UnSelectAllStuCheckbox<br>
	 * Description :- To unselect Students search results checkbox Details.
	 *
	 */
	public boolean UnSelectAllStuCheckbox() throws IOException {
		WebElement chbxele = WebDriverMain._getElementWithWait(SessionDetailPageObjects(SelectAllRecords));
		if (chbxele != null) {
			LeftClick.clickByWebElementJS(chbxele);
			return true;
		}
		return false;
	}

	/**
	 * Function Name :- clickonStudName<br>
	 * Description :- To click Student Name hyperlink.
	 *
	 */
	public boolean clickonStudName(String Studname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator("xpath=//td/a[contains(text(),'" + Studname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}

	/**
	 * Function Name :- AddStudentsButton_isVisible<br>
	 * Description :- To verify AddStudents button is visible
	 */
	public boolean AddStudentsButton_isVisible() throws Exception {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnAddStudent)))
			return true;
		else
			return false;

	}

	/**
	 * Function Name :- AddStudentsButton_isEnabled<br>
	 * Description :- To verify AddStudents button is enabled
	 *
	 */
	public boolean AddStudentsButton_isEnabled() throws IOException {
		WebElement delete = WebDriverMain._getElementWithWait(SessionDetailPageObjects(btnAddStudent));
		String attributeText = delete.getAttribute("innerHTML");
		if (attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- clickAddStudentsButton<br>
	 * Description :- To click the Add Students button.
	 *
	 */
	public boolean clickAddStudentsButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Add Students");
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnAddStudent));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- clickDeleteButton<br>
	 * Description :- To click the Delete button.
	 *
	 */
	public boolean clickDeleteButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Delete");
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnDelete));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- deleteButton_isVisible<br>
	 * Description :- To verify delete button is visible
	 *
	 */
	public boolean deleteButton_isVisible() throws IOException {

		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnDelete)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- deleteButton_isEnabled<br>
	 * Description :- To verify delete button is enabled
	 *
	 */
	public boolean deleteButton_isEnabled() throws IOException {
		WebElement delete = WebDriverMain._getElementWithWait(SessionDetailPageObjects(btnDelete));
		String attributeText = delete.getAttribute("innerHTML");
		if (attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- clickAddStudentsButton<br>
	 * Description :- To click the Add Students button.
	 *
	 */
	public boolean clickRefreshButton() throws IOException {
		boolean flag = false;
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(btnRefresh))) {
			flag = LeftClick._click(SessionDetailPageObjects(btnRefresh));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
		}
		return flag;
	}

	/**
	 * Function Name :- verifySuccessMessageVisible<br>
	 * Description :- To verify Success Message
	 * 
	 * @throws IOException
	 */
	public boolean verifySuccessMessageVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(Success_Message))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- verifySuccessMessage<br>
	 * Description :- To verify Success Message
	 * 
	 * @throws IOException
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException {

		try {
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(SessionDetailPageObjects(lbludpateDate));
			if (elmStudentlst != null) {
				CommonUtility._scrollElement(elmStudentlst);
				CommonUtility._sleepForGivenTime(1000);
			}
			CommonUtility._sleepForGivenTime(2000);
			String textSuccess = WebDriverMain._getTextFromElement(SessionDetailPageObjects(Success_Message));
			System.out.println("Actual Success message : " + textSuccess);
			if (textSuccess.toLowerCase().contains(successmessage.toLowerCase())) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Function Name :- verifyFieldControlErrorMessage<br>
	 * Description :- To verify the field control error message on Create
	 * Organization page form.
	 *
	 */
	public String getFieldControlErrorMessage() throws IOException {
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(Field_Control_Error_Message))) {
			String ErrorText = WebDriverMain._getTextFromElement(SessionDetailPageObjects(Field_Control_Error_Message));
			System.out.println("Field Error Message: " + ErrorText);
			return ErrorText;
		}
		return null;

	}
	
	/**
	 * Function Name :- getErrorMessage<br>
	 * Description :- To verify the error message on Create
	 * Organization page form.
	 *
	 */
	public String getErrorMessage() throws IOException {
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(Success_Message))) {
			String ErrorText = WebDriverMain._getTextFromElement(SessionDetailPageObjects(Success_Message));
			System.out.println("Field Error Message: " + ErrorText);
			return ErrorText;
		}
		return null;

	}

	/**
	 * Function Name :- SelectMoreActions<br>
	 * Description :- To Select the More Action on Session details page.
	 *
	 */
	public boolean SelectMoreActions(String actions) throws IOException {
		LeftClick._click(SessionDetailPageObjects(btnUpdateStatus));
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnUpdateStatus_MenuOptions))) {
			By objlocator = CommonUtility._getObjectLocator(
					"xpath=//div[contains(@class,'palib-dropdown-menu')]/a[contains(text(),'" + actions + "')]");
			if (WebDriverMain._isElementVisible(objlocator)) {
				WebElement DropdownEle = WebDriverMain._getElementWithWait(objlocator);
				String attributeText = DropdownEle.getAttribute("class");
				if (attributeText.contains("disabled"))
					return false;
				LeftClick._click(objlocator);
				CommonUtility._sleepForGivenTime(2000);
				common.PleaseWaitAndLoadingMessage();
				return true;
			} else
				return false;
		}
		return false;
	}

	/**
	 * Function Name :- Close_Alerts<br>
	 * Description :- To Close Alerts
	 *
	 */
	public boolean Close_Alerts() throws IOException {

		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(CloseAlerts))) {
			List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(CloseAlerts));
			for (WebElement AlertEle : lstAlertsRow) {
				WebElement elmStudentlst = WebDriverMain._getElementWithWait(SessionDetailPageObjects(lbludpateDate));
				CommonUtility._scrollElement(elmStudentlst);
				CommonUtility._sleepForGivenTime(1000);
				if (WebDriverMain._isElementClickable(AlertEle)) {
					AlertEle.click();
				}
			}
		}
		return true;
	}

	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit User button.
	 *
	 */
	public boolean clickEditButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnEdit))) {
			LeftClick._click(SessionDetailPageObjects(btnEdit));
			CommonUtility._sleepForGivenTime(2000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		} else
			return false;

	}

	/**
	 * Function Name :- CanceltButton_isVisible<br>
	 * Description :- To verify Cancel button is visible
	 */
	public boolean CanceltButton_isVisible() throws Exception {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnCancel)))
			return true;
		else
			return false;

	}

	/**
	 * Function Name :- clickCancelButton<br>
	 * Description :- To click the Cancel User button.
	 *
	 */
	public boolean clickCancelButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(SessionDetailPageObjects(btnCancel));
		// CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}

	/**
	 * Function Name :- SaveButton_isVisible<br>
	 * Description :- To verify Save button is visible
	 */
	public boolean SaveButton_isVisible() throws Exception {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnSave)))
			return true;
		else
			return false;

	}

	/**
	 * Function Name :- SaveButton_isEnabled<br>
	 * Description :- To verify Edit button is enabled
	 *
	 */
	public boolean SaveButton_isEnabled() throws IOException {

		WebElement delete = WebDriverMain._getElementWithWait(SessionDetailPageObjects(btnSave));
		String attributeText = delete.getAttribute("outerHTML");
		if (attributeText.contains("disabled"))
			return false;
		else
			return true;

	}

	/**
	 * Function Name :- clickSaveButton<br>
	 * Description :- To click the Edit User button.
	 *
	 */
	public boolean clickSaveButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(SessionDetailPageObjects(btnSave));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}

	/**
	 * Function Name :- VerifyReportsList<br>
	 * Description :- To verify Reports this session.
	 *
	 */
	public List<String> VerifyReportsList() throws IOException {
		List<String> MapDgColValues = null;
		try {
			if (LeftClick._click(SessionDetailPageObjects(btnReports))) {
				CommonUtility._sleepForGivenTime(2000);
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(LstReports))) {
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(LstReports));
					MapDgColValues = new ArrayList<String>();
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgColValues.add(sDGColmnValue);
					}
				}
				LeftClick._click(SessionDetailPageObjects(btnReports));
			}
		} catch (Exception e) {
			return MapDgColValues;
		}
		return MapDgColValues;
	}

	/**
	 * Function Name :- SelectReportFromList<br>
	 * Description :- To select Reports this session.
	 *
	 */
	public boolean SelectReportFromList(String ReportName) throws IOException {
		List<String> MapDgColValues = null;
		boolean flag = false;
		try {
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnReports))) {
				LeftClick._click(SessionDetailPageObjects(btnReports));
				CommonUtility._sleepForGivenTime(2000);
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(LstReports))) {
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(LstReports));
					MapDgColValues = new ArrayList<String>();
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnValue = dataRec.get(iCol).getText();
						if (sDGColmnValue.toLowerCase().contains(ReportName.toLowerCase())) {
							dataRec.get(iCol).click();
							CommonUtility._sleepForGivenTime(1000);
							CommonFunctions.PleaseWaitAndLoadingMessage();
							CommonUtility._sleepForGivenTime(2000);
							MapDgColValues.add(sDGColmnValue);
							flag = true;
							return flag;
						}
						MapDgColValues.add(sDGColmnValue);
					}
				}
				LeftClick._click(SessionDetailPageObjects(btnReports));
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}

	/**
	 * Function Name :- ReportsButton_isVisible<br>
	 * Description :- To verify Reports button is visible
	 */
	public boolean ReportsButton_isVisible() throws Exception {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnReports)))
			return true;
		else
			return false;

	}

	/**
	 * Function Name :- clickReststudentPasswordButton<br>
	 * Description :- To click the ReststudentPassword button.
	 *
	 */
	public boolean clickReststudentPasswordButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Delete");
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnResetpswd));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- resetpasswordButton_isVisible<br>
	 * Description :- To verify reset password button is visible
	 *
	 */
	public boolean resetpasswordButton_isVisible() throws IOException {

		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnResetpswd)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- clickPrintButton<br>
	 * Description :- To click the Print button.
	 *
	 */
	public boolean clickPrintButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnPrintTicker));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- printAllTicketsButton_isVisible<br>
	 * Description :- To Verify the printAllTicketsButton.
	 *
	 */
	public boolean printAllTicketsButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnPrintAllTickets)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- printSelectedTicketsButton_isVisible<br>
	 * Description :- To Verify the printSelectedTicketsButton.
	 *
	 */
	public boolean printSelectedTicketsButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnPrintSelectedTickets)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- clickPrintAllTicketsButton<br>
	 * Description :- To click the PrintAllTicketsButton.
	 *
	 */
	public boolean clickPrintAllTicketsButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Delete");
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnPrintAllTickets));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- clickPrintSelectedTicketsButton<br>
	 * Description :- To click the PrintSelectedTicketsButton.
	 *
	 */
	public boolean clickPrintSelectedTicketsButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Delete");
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnPrintSelectedTickets));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- getStudentInSessionCnt<br>
	 * Description :- To get the Student In Session.
	 *
	 */
	public int getStudentInSessionCnt() throws IOException {
		int cnt = 0;
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(cntStudentInSession))) {
			String studentsInSession = WebDriverMain._getTextFromElement(SessionDetailPageObjects(cntStudentInSession));
			if (studentsInSession.contains(":")) {
				String TotStudSplit[] = studentsInSession.split(":");
				cnt = Integer.parseInt(TotStudSplit[1].trim());
			}
		}
		return cnt;

	}

	/**
	 * Function Name :- getPrintedTicketCnt<br>
	 * Description :- To get the PrintedTicket Count.
	 *
	 */
	public int getPrintedTicketCnt() throws IOException {
		int cnt = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(studentTestTicket)).size();
		return cnt;
	}

	public boolean clickDownloadTestButton() throws Exception {
		CommonUtility._sleepForGivenTime(500);
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnDownloadTest));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	public boolean downloadTest_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnDownloadTest)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- clicksessiondetailsnaviagtion<br>
	 * Description :- To clicks session detail navigation.
	 *
	 */
	public boolean clicksessiondetailnavigationtbtn() throws IOException {
		boolean flag = WebDriverMain._isElementVisible(SessionDetailPageObjects(SessionDetailbtn));
		if (flag) {
			flag = LeftClick._click(SessionDetailPageObjects(SessionDetailbtn));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}

	/**
	 * Function Name :- updateStatusButton_isVisible<br>
	 * Description :- To verify Update button is visible
	 *
	 */
	public boolean updateStatusButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnUpdateStatus)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- GetUpdateStatusActions<br>
	 * Description :- To Get the Update Status on Session details page.
	 *
	 */
	public List<String> GetUpdateStatusActions() throws IOException {
		List<String> MapDgStatus = null;
		LeftClick._click(SessionDetailPageObjects(btnUpdateStatus));
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnUpdateStatus_MenuOptions))) {
			List<WebElement> lstStatusRow = WebDriverMain
					._getElementsWithWait(SessionDetailPageObjects(btnUpdateStatus_MenuOptions));
			MapDgStatus = new ArrayList<String>();
			for (WebElement StatusEle : lstStatusRow) {
				String sDGColmnValue = StatusEle.getText();
				MapDgStatus.add(sDGColmnValue);
			}
		}
		LeftClick._click(SessionDetailPageObjects(btnUpdateStatus));
		return MapDgStatus;
	}

	/**
	 * Function Name :- SelectStatusFromList<br>
	 * Description :- To select status from list.
	 *
	 */
	public boolean SelectStatusFromList(String Statusname) throws IOException {
		boolean flag = false;
		try {
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnUpdateStatus))) {
				LeftClick._click(SessionDetailPageObjects(btnUpdateStatus));
				CommonUtility._sleepForGivenTime(2000);
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnUpdateStatus_MenuOptions))) {
					List<WebElement> dataRec = WebDriverMain
							._getElementsWithWait(SessionDetailPageObjects(btnUpdateStatus_MenuOptions));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnValue = dataRec.get(iCol).getText();
						if (sDGColmnValue.toLowerCase().contains(Statusname.toLowerCase())) {
							dataRec.get(iCol).click();
							flag = true;
							return flag;
						}
					}
				}
				LeftClick._click(SessionDetailPageObjects(btnUpdateStatus));
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}

	/**
	 * Function Name :- TeacherHandScoreButton_isVisible<br>
	 * Description :- To verify Teacher Hand Score button is visible
	 *
	 */
	public boolean HandScoreButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnHandScore)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- Handscoreoption_isVisible<br>
	 * Description :- To verify Handscore option is visible
	 */
	public boolean Handscoreoption_isVisible() throws Exception {
		LeftClick._click(SessionDetailPageObjects(btnHandScore));
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(optHandScore))) {
			LeftClick._click(SessionDetailPageObjects(btnHandScore));
			return true;
		} else
			return false;

	}

	/**
	 * Function Name :- Submitoption_isVisible<br>
	 * Description :- To verify Submit option is visible
	 */
	public boolean Submitoption_isVisible() throws Exception {
		LeftClick._click(SessionDetailPageObjects(btnHandScore));
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(optSubmit))) {
			LeftClick._click(SessionDetailPageObjects(btnHandScore));
			return true;
		} else
			return false;

	}

	/**
	 * Function Name :- Select_Handscore<br>
	 * Description :- To verify Handscore option is able to select
	 */
	public boolean Select_opt_handscore() throws Exception {
		LeftClick._click(SessionDetailPageObjects(btnHandScore));
		CommonUtility._sleepForGivenTime(500);
		boolean flag = WebDriverMain._isElementVisible(SessionDetailPageObjects(optHandScore));
		if (flag) {
			flag = LeftClick._click(SessionDetailPageObjects(optHandScore));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return flag;
		} else {
			LeftClick._click(SessionDetailPageObjects(btnHandScore));
			return flag = false;
		}

	}

	/**
	 * Function Name :- Select_Submit<br>
	 * Description :- To verify Submit option is able to select
	 */
	public boolean Select_opt_submit() throws Exception {
		LeftClick._click(SessionDetailPageObjects(btnHandScore));
		CommonUtility._sleepForGivenTime(500);
		boolean flag = WebDriverMain._isElementVisible(SessionDetailPageObjects(optSubmit));
		if (flag) {
			flag = LeftClick._click(SessionDetailPageObjects(optSubmit));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return flag;
		} else {
			LeftClick._click(SessionDetailPageObjects(btnHandScore));
			return flag = false;
		}

	}

	/**
	 * Function Name :- VerifyTHSFromList<br>
	 * Description :- To verify THS from list.
	 *
	 */
	public boolean VerifyTHSFromList(String option) throws IOException {
		boolean flag = false;
		try {
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnHandScore))) {
				LeftClick._click(SessionDetailPageObjects(btnHandScore));
				CommonUtility._sleepForGivenTime(2000);
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnUpdateStatus_MenuOptions))) {
					List<WebElement> dataRec = WebDriverMain
							._getElementsWithWait(SessionDetailPageObjects(btnTHS_MenuOptions));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnValue = dataRec.get(iCol).getText();
						if (sDGColmnValue.toLowerCase().contains(option.toLowerCase())) {
							LeftClick._click(SessionDetailPageObjects(btnHandScore));
							return true;
						}
					}
				}
				LeftClick._click(SessionDetailPageObjects(btnHandScore));
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}

	/**
	 * Function Name :- SelectTHSFromList<br>
	 * Description :- To select status from list.
	 *
	 */
	public boolean SelectTHSFromList(String option) throws IOException {
		boolean flag = false;
		try {
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnHandScore))) {
				LeftClick._click(SessionDetailPageObjects(btnHandScore));
				CommonUtility._sleepForGivenTime(2000);
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnUpdateStatus_MenuOptions))) {
					List<WebElement> dataRec = WebDriverMain
							._getElementsWithWait(SessionDetailPageObjects(btnTHS_MenuOptions));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnValue = dataRec.get(iCol).getText();
						if (sDGColmnValue.toLowerCase().contains(option.toLowerCase())) {
							dataRec.get(iCol).click();
							flag = true;
							return flag;
						}
					}
				}
				LeftClick._click(SessionDetailPageObjects(btnHandScore));
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}

	/**
	 * Function Name :- verify Submit SuccessMessage<br>
	 * Description :- To verify Submit Success Message
	 * 
	 * @throws IOException
	 */
	public boolean verifySubmitmsg(String submitmessage) throws IOException {
		CommonUtility._sleepForGivenTime(2000);
		String textmessage = WebDriverMain._getTextFromElement(SessionDetailPageObjects(submitMsg));
//	    System.out.println("textmessage :"+textmessage);
//	    System.out.println("submitmessage :"+submitmessage);
//	    System.out.println("Check :"+textmessage.contains(submitmessage));
		if (textmessage.toLowerCase().contains(submitmessage.toLowerCase())) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- GetStatusProgressBarContent<br>
	 * Description :- Get Status Progress Bar Content.
	 * 
	 * @return Map<String, String>
	 */
	public HashMap<String, String> GetStatusProgressBarContent() throws IOException {
		HashMap<String, String> mapWidCard = null;
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//div[contains(@class,'student-progress-status')]//pa-levels");
		if (WebDriverMain._isElementPresent(objlocator)) {
			WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
			if (targetElement != null) {
				try {
					By CardBodylocator = CommonUtility._getObjectLocator(
							"xpath=//pa-levels//div[contains(@class,'dataviz-label-container')]//div[contains(@class,'dataviz-label')]");
					// Get list of subjects
					List<WebElement> lstCardElement = WebDriverMain._getElementsWithWait(CardBodylocator);
					if (lstCardElement != null) {
						// mapWidCard = new HashMap<String, String>();
						mapWidCard = new HashMap<String, String>();
						// for (WebElement CardElement:lstCardElement) {
						for (int icardCnt = 1; icardCnt <= lstCardElement.size(); icardCnt++) {
							String strStatusName = null;
							String strStatusCnt = null;
							// Get Status Count
							By StatusCountlocator = CommonUtility._getObjectLocator(
									"xpath=//pa-levels//div[contains(@class,'dataviz-label-container')]//div[contains(@class,'dataviz-label')]["
											+ icardCnt + "]//div[contains(@class,'dataviz-level-name')]");
							WebElement statusCntElement = WebDriverMain._getElementWithWait(StatusCountlocator);
							if (statusCntElement != null) {
								strStatusCnt = statusCntElement.getText();
								strStatusCnt = strStatusCnt.trim();
								// System.out.println("strStatusCnt : "+strStatusCnt);
								// Split the status count from student
								String NumericSplit[] = strStatusCnt.split(" ");
								// System.out.println("NumericSplit Count : "+NumericSplit.length);
								if (NumericSplit.length >= 1) {
									strStatusCnt = NumericSplit[0];
									// if (CommonFunctions.isNumeric(strStatusCnt))
									// System.out.println("strStatusCnt : "+strStatusCnt);
									//
									// Get Status Names

									strStatusName = NumericSplit[1];
									System.out.println(
											"Bar Status " + icardCnt + " : " + strStatusCnt + " " + strStatusName);
									mapWidCard.put(strStatusName, strStatusCnt);

								}
							}
						}
						System.out.println("Map Status details : " + mapWidCard);
					}

				} catch (Exception e) {
					return mapWidCard;
				}
			}
		}
		return mapWidCard;
	}

	/**
	 * Function Name :- SelectStatusInProgressBar<br>
	 * Description :- Select Status Progress Bar Content.
	 * 
	 * @return Map<String, String>
	 */
	public int SelectStatusInProgressBar(String StatusName) throws IOException {
		HashMap<String, String> mapWidCard = null;
		int retnStudCnt = 0;
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//div[contains(@class,'student-progress-status')]//pa-levels");
		if (WebDriverMain._isElementPresent(objlocator)) {
			WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
			if (targetElement != null) {
				try {
					By CardBodylocator = CommonUtility._getObjectLocator(
							"xpath=//pa-levels//div[contains(@class,'dataviz-label-container')]//div[contains(@class,'dataviz-label')]");
					// Get list of subjects
					List<WebElement> lstCardElement = WebDriverMain._getElementsWithWait(CardBodylocator);
					if (lstCardElement != null) {
						mapWidCard = new HashMap<String, String>();
						for (int icardCnt = 1; icardCnt <= lstCardElement.size(); icardCnt++) {
							String strStatusName = null;
							String strStatusCnt = null;
	
							// Get Status Name
							By StatusNamelocator = CommonUtility._getObjectLocator(
									"xpath=//pa-levels//div[contains(@class,'dataviz-label-container')]//div[contains(@class,'dataviz-label')]["
											+ icardCnt + "]//div[contains(@class,'dataviz-level-name')]");
	
							WebElement statusNameElement = WebDriverMain._getElementWithWait(StatusNamelocator);
							if (statusNameElement != null) {
								strStatusName = statusNameElement.getText();
								strStatusName = strStatusName.trim();
								System.out.println("strStatusName : " + strStatusName);
								if ((strStatusName.equalsIgnoreCase(StatusName)) || (StatusName.length() < 1)
										|| (strStatusName.toLowerCase().contains(StatusName.toLowerCase()))) {
									// Select Status
									statusNameElement.click();
									CommonUtility._sleepForGivenTime(1000);
									CommonFunctions.PleaseWaitAndLoadingMessage();
									String NumericSplit[] = strStatusName.split(" ");
									if (NumericSplit.length >= 1) {
										strStatusCnt = NumericSplit[0];
										if (CommonFunctions.isNumeric(strStatusCnt)) {
											retnStudCnt = Integer.parseInt(strStatusCnt);
											return retnStudCnt;
										}
									}
	
								}
							}
							mapWidCard.put(strStatusName, strStatusCnt);
						}
						System.out.println("Map Status details : " + mapWidCard);
					}
	
				} catch (Exception e) {
					return retnStudCnt;
				}
			}
		}
		return retnStudCnt;
	}
	
	public boolean VerifyStatusAvailableInStatusBar(String Statusname) throws IOException {
		// Get Status Name
		By StatusNamelocator = CommonUtility._getObjectLocator(
				"xpath=//pa-levels//div[contains(@class,'dataviz-label-container')]//div[contains(@class,'dataviz-label')]//div[contains(@class,'dataviz-level-name')][contains(text(),'"+Statusname+"')]");
		if (WebDriverMain._isElementVisible(StatusNamelocator))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- verifyStuGridPagination<br>
	 * Description :- To verify Students grid pagination.
	 *
	 */
	public int verifyStuCountGridPagination(int stucnt) throws IOException {
		int maxpage = 0;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		maxpage = lstOrgrRow.size();
		System.out.println("Stu Page : " + maxpage);
		if (maxpage >= 29) {
			KendoGrid.SelectItemsPerPage("200");
			CommonUtility._sleepForGivenTime(2000);
			lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
			maxpage = lstOrgrRow.size();
			if (maxpage >= 198)
				return stucnt;
			else
				return maxpage;
		} else
			return maxpage;
	}

	/**
	 * Function Name :- verifyStudStatusfromlist<br>
	 * Description :-To verify Student search results Details.
	 */
	public HashMap<String, String> verifyStudStatusfromlist(int rowindex, String ColName, String MatchValues)
			throws IOException {
		By objlocator, objlocator1 = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt = 1;
		// Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			// Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter = iCol + 1;
				List<WebElement> lstOrgrRow = WebDriverMain
						._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
				System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(NoRecords))) {
						MapDgdetails = new ArrayList<HashMap<String, String>>();
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							MapDgOrgRec = new HashMap<String, String>();
							if (rowindex >= rowindex) {
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td[" + datacounter + "]");
								String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
								if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
									// Select Matched Checkbox
									objlocator = CommonUtility._getObjectLocator(
											"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
													+ Irow + "]/td[2]");
									String sDGStudNameValue = WebDriverMain._getTextFromElement(objlocator);
									if (MapDgOrgRec.containsKey(sDGStudNameValue))
										MapDgOrgRec.put(sDGStudNameValue + "|" + Irow, sDGColmnValue);
									else
										MapDgOrgRec.put(sDGStudNameValue, sDGColmnValue);

								}
							}
						}
						return MapDgOrgRec;

					} else
						System.out.println("No record found");

				} else
					System.out.println("No record found");
			}
		}
		return MapDgOrgRec;
	}

	public boolean PrintAccommButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnPrintAccomm)))
			return true;
		else
			return false;
	}

	public boolean ViewAccommButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnViewAccomm)))
			return true;
		else
			return false;
	}

	public boolean clickPrintAccommButton() throws IOException {
		boolean flag = false;
		flag = LeftClick._click(SessionDetailPageObjects(btnPrintAccomm));
		return flag;
	}

	public boolean clickViewAccommButton() throws IOException {
		boolean flag = false;
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
		flag = LeftClick._click(SessionDetailPageObjects(btnViewAccomm));
		return flag;
	}

	public boolean accommSummary_isVisible() throws IOException {
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(scrAccommSummary)))
			return true;
		else
			return false;
	}

	public boolean accommList_isVisible() throws IOException {
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(accommList)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- SessionProgressBladeExpand<br>
	 * Description :- To Expand/Collapse Session Section Progress.
	 *
	 */
	public boolean SessionProgressBladeExpand(String strValue) throws IOException {
		boolean flag = false;
		try {
			if (strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")) {
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogressexpandup))) {
					if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogressbody)))
						return true;// Display session info if collapse
				} else if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogresscollapsedown))) {
					flag = LeftClick._click(SessionDetailPageObjects(sessionprogresscollapsedown));
					CommonUtility._sleepForGivenTime(1000);
					if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogressbody)))
						return true;// Display session info if collapse
				}
			} else {
				if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogresscollapsedown))) {
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogressbody)))
						return true;// Not display session info if collapse
				} else if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogressexpandup))) {
					flag = LeftClick._click(SessionDetailPageObjects(sessionprogressexpandup));
					CommonUtility._sleepForGivenTime(1000);
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogressbody)))
						return true; // Not display session info if collapse
				}

			}

		} catch (Exception e) {
			return false;
		}
		return flag;
	}

	/**
	 * Function Name :- Verify_Session_Progress_Blade<br>
	 * Description :- To verify Session Progress section is visible
	 *
	 */
	public boolean Verify_Session_Progress_Blade() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogress)))
			return true;
		else
			return false;
	}

	public boolean accommStudList_isVisible() throws IOException {
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(accommStudList)))
			return true;
		else
			return false;
	}

	public boolean downloadLink_isVisible() throws IOException {
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(downloadLink)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- clickdownloadAccommodations<br>
	 * Description :- To click Download.
	 *
	 */
	public boolean clickdownloadAccommodations() throws IOException {
		boolean flag = false;
		try {
			flag = LeftClick._click(SessionDetailPageObjects(downloadLink));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(6000);
		} catch (Exception e) {
			return false;
		}
		return flag;
	}

	/**
	 * Function Name :- Verify_Session_Progress_Blade<br>
	 * Description :- To verify Session Progress section is visible
	 *
	 */
	public boolean Check_Session_Progress_Blade_expand() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogressbody)))
			return true;
		else
			return false;
	}

	public boolean clickAccommSummaryCloseBtn() throws IOException {
		boolean flag = false;
		flag = LeftClick._click(SessionDetailPageObjects(closeAccommSummary));
		return flag;
	}

	/**
	 * Function Name :- GetSectionContent<br>
	 * Description :- Get Section Progress Content.
	 * 
	 * @return boolean
	 */
	public List<Map<String, String>> GetSectionContent() throws IOException {
		boolean flag = false;

		Map<String, String> mapWidCard = null;
		List<Map<String, String>> lstWidCards = null;
		try {
			// Check if No data to display
			if (WebDriverMain._isElementVisible(SessionDetailPageObjects(sessionprogressbody))) {
				By CardBodylocator = CommonUtility._getObjectLocator(
						"xpath=//pa-session-details-section//div[contains(@class,'section-container')]");
				// Get list of subjects
				List<WebElement> lstCardElement = WebDriverMain._getElementsWithWait(CardBodylocator);
				if (lstCardElement != null) {
					// mapWidCard = new HashMap<String, String>();
					lstWidCards = new ArrayList<Map<String, String>>();
//						for (WebElement CardElement:lstCardElement) {
					for (int icardCnt = 1; icardCnt <= lstCardElement.size(); icardCnt++) {
						mapWidCard = new HashMap<String, String>();
						System.out.println("icardCnt : " + icardCnt);
						By CardTitlelocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-section//div[contains(@class,'section-container')]["
										+ icardCnt + "]//div[@class='section-title']");
						WebElement CardTitleElement = WebDriverMain._getElementWithWait(CardTitlelocator);
						String strCardtitle = CardTitleElement.getText();
						mapWidCard.put("section", strCardtitle);
						
						By CardSecCodelocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-section//div[contains(@class,'section-container')]["
										+ icardCnt + "]//div[contains(@class,'section-code')]");
						
						WebElement CardSecCodeElement = WebDriverMain._getElementWithWait(CardSecCodelocator);
						String strCardSeCode = CardSecCodeElement.getText();
						mapWidCard.put("sectioncode", strCardSeCode);
						
						//Not Started
						By CardStatuslocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-section//div[contains(@class,'section-container')]["
										+ icardCnt + "]//div[contains(@class,'section-progress')][1]");
						By CardCountlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-section//div[contains(@class,'section-container')]["
										+ icardCnt + "]//div[contains(@class,'section-progress')][1]/Strong");

						
						
						// Not started Section
						String strStatuslink ="";
						String strCardCount = "0";
						if (WebDriverMain._isElementPresent(CardStatuslocator)) {
							WebElement CardStatusElement = WebDriverMain._getElementWithWait(CardStatuslocator);
							strStatuslink = CardStatusElement.getText();
							if (WebDriverMain._isElementPresent(CardCountlocator)) {
								WebElement CardCountElement = WebDriverMain._getElementWithWait(CardCountlocator);
								strCardCount = CardCountElement.getText();
								
							}
							mapWidCard.put("notstarted", strCardCount);
							mapWidCard.put("notstartedstatus", strStatuslink);
							
						}
						
						CardStatuslocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-section//div[contains(@class,'section-container')]["
										+ icardCnt + "]//div[contains(@class,'section-progress')][2]");
						CardCountlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-section//div[contains(@class,'section-container')]["
										+ icardCnt + "]//div[contains(@class,'section-progress')][2]/Strong");
						//Started Section
						strStatuslink ="";
						strCardCount = "0";
						if (WebDriverMain._isElementPresent(CardStatuslocator)) {
							WebElement CardStatusElement = WebDriverMain._getElementWithWait(CardStatuslocator);
							strStatuslink = CardStatusElement.getText();
							if (WebDriverMain._isElementPresent(CardCountlocator)) {
								WebElement CardCountElement = WebDriverMain._getElementWithWait(CardCountlocator);
								strCardCount = CardCountElement.getText();
								
							}
							mapWidCard.put("started", strCardCount);
							mapWidCard.put("startedstatus", strStatuslink);
							
						}
						
						//Completed Section
						CardStatuslocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-section//div[contains(@class,'section-container')]["
										+ icardCnt + "]//div[contains(@class,'section-progress')][3]");
						CardCountlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-section//div[contains(@class,'section-container')]["
										+ icardCnt + "]//div[contains(@class,'section-progress')][3]/Strong");

						strStatuslink ="";
						strCardCount = "0";
						if (WebDriverMain._isElementPresent(CardStatuslocator)) {
							WebElement CardStatusElement = WebDriverMain._getElementWithWait(CardStatuslocator);
							strStatuslink = CardStatusElement.getText();
							if (WebDriverMain._isElementPresent(CardCountlocator)) {
								WebElement CardCountElement = WebDriverMain._getElementWithWait(CardCountlocator);
								strCardCount = CardCountElement.getText();
							}
							mapWidCard.put("completed", strCardCount);
							mapWidCard.put("completedstatus", strStatuslink);
							
						}
						System.out.println("mapWidCard : " + mapWidCard);
						lstWidCards.add(mapWidCard);
					}
					System.out.println("Lst Card details : " + lstWidCards);
				}
			} else
				// No data to display
				return lstWidCards;

		} catch (Exception e) {
			return lstWidCards;
		}
		return lstWidCards;

	}

	/**
	 * Function Name :- VerifyConfirmPopupContent<br>
	 * Description :- Verify Popup string.
	 * 
	 * @return boolean
	 */
	public boolean VerifyAccommHeadersContent(String ModalTitleTxt, String ModalBodyHeader1, String ModalBodyHeader2, String ModalBodyHeader3, String ModalBodyHeader4)
			throws IOException {
		boolean flag = false;
		By ModalHeaderlocator = CommonUtility
				._getObjectLocator("xpath=//kendo-dialog-titlebar/div[contains(@class,'k-dialog-title')]//h3");
		By Modalbodylocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'k-dialog-content')]//h3");

		try {
			if (VerifyAccomModalDisplayed()) {
				// Verify Modal TitleWebDriverMain._getElementWithWait(objlocator)
				WebElement ModalTitleElement = WebDriverMain._getElementWithWait(ModalHeaderlocator);
				if (ModalTitleElement != null) {
					String ModalTitile = ModalTitleElement.getText();
					if (ModalTitile.toUpperCase().trim().contains(ModalTitleTxt.toUpperCase().trim()))
						flag = true;
					// UMReporter.log(Status.Pass, "The Confirm popup title is matched with expected
					// value "+ModalTitleTxt);
					else
						UMReporter.log(Status.FAIL,
								"The Confirm popup title is mismatched with expected value " + ModalTitleTxt);
				}

				// Verify Modal Body
				List<WebElement> LstModalBodyEle = WebDriverMain._getElementsWithWait(Modalbodylocator);
				if (LstModalBodyEle != null) {
					for (WebElement ModalBodyEle : LstModalBodyEle) {
						String ModalBody = ModalBodyEle.getText();
						ModalBody = ModalBody.toUpperCase().trim();
						if ((ModalBody.contains(ModalBodyHeader1.toUpperCase()))
								|| (ModalBody.contains(ModalBodyHeader2.toUpperCase()))
									|| (ModalBody.contains(ModalBodyHeader3.toUpperCase()))
										|| (ModalBody.contains(ModalBodyHeader4.toUpperCase())))
							flag = true;
						// UMReporter.log(Status.Pass, "The Confirm popup title is matched with expected
						// value "+ModalTitleTxt);
//						else
//							UMReporter.log(Status.FAIL,
//									"The Accommodatation modal message is mismatched with expected value "
//											+ ModalBodyHeader1 + ModalBodyHeader2);

					}
				}

			}
		} catch (Exception e) {
			return false;
		}

		return flag;

	}

	/**
	 * Function Name :- GetAccomNeededModalContent<br>
	 * Description :- Get Accommodations Needed Modal Popup string.
	 * 
	 * @return boolean
	 */
	public List<String> GetAccomNeededModalContent() throws IOException {
		boolean flag = false;
		List<String> LstAccomodations = null;
		By Modalbodylocator = CommonUtility
				._getObjectLocator("xpath=//div[contains(@class,'k-dialog-content')]//h3/following-sibling::div//p");
		try {
			if (VerifyAccomModalDisplayed()) {
				// Verify Modal Body
				if (WebDriverMain._isElementPresent(Modalbodylocator)) {
					List<WebElement> LstModalBodyEle = WebDriverMain._getElementsWithWait(Modalbodylocator);
					if (LstModalBodyEle != null) {
						LstAccomodations = new ArrayList<String>();
						for (WebElement ModalBodyEle : LstModalBodyEle) {
							String ModalBody = ModalBodyEle.getText().trim();
							LstAccomodations.add(ModalBody);
						}
					}
				}
			}
		} catch (Exception e) {
			return LstAccomodations;
		}

		return LstAccomodations;

	}

	/**
	 * Function Name :- GetStudentAccomsModalContent<br>
	 * Description :- Get Students Accommodations Needed Modal Popup string.
	 * 
	 * @return boolean
	 */
	public List<HashMap<String, String>> GetStudentAccomsModalContent(int rowindex) throws IOException {
		boolean flag = false;
		List<HashMap<String, String>> LstAccomodations = null;
		HashMap<String, String> MapStuAccoms = null;
		By objlocator = null;
		try {
			if (VerifyAccomModalDisplayed()) {
				List<WebElement> lstOrgrRow = WebDriverMain
						._getElementsWithWait(SessionDetailPageObjects(winAccomRowPresent));
				System.out.println("Stu Accomm Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(winNoAccomRecords))) {
						LstAccomodations = new ArrayList<HashMap<String, String>>();
						;
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(SessionDetailPageObjects(winAccomDatagridHeaderRow));
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							if (rowindex >= Irow) {
								MapStuAccoms = new HashMap<String, String>();
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-print-accommodations-modal//kendo-grid//table/tbody/tr[" + Irow
												+ "]/td");
								List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
								for (int iCol = 0; iCol < dataRec.size(); iCol++) {
									String sDGColmnName = lstheaderRow.get(iCol).getText();
									String sDGColmnValue = dataRec.get(iCol).getText();
									MapStuAccoms.put(sDGColmnName, sDGColmnValue);
								}
								LstAccomodations.add(MapStuAccoms);
							}

						}
						return LstAccomodations;
					} else
						System.out.println("No record found");
				} else
					System.out.println("No record found");

			}
		} catch (Exception e) {
			return LstAccomodations;
		}

		return LstAccomodations;

	}

	/**
	 * Function Name :- VerifyAccomModalDisplayed<br>
	 * Description :- To Verify Accom Popup displayed.
	 * 
	 * @return boolean
	 */
	public boolean VerifyAccomModalDisplayed() throws IOException {
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog/div[contains(@class,'k-dialog')]");
		if (WebDriverMain._isElementPresent(objlocator)) {
			WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
			if (targetElement != null) {
				try {
					if (targetElement.isDisplayed())
						return true;
				} catch (Exception e) {
					return false;
				}
			}
		}
		return false;
	}

	public boolean unsubmitButton_isVisible() throws IOException {

		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnUnsubmit)))
			return true;
		else
			return false;
	}

	public boolean clickUnsubmitButton() throws IOException {
		// CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Delete");
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnUnsubmit));
		// CommonUtility._sleepForGivenTime(1000);
		// CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- clickMoveoption<br>
	 * Description :- To click the Move option.
	 *
	 */
	public boolean moveButton_isVisible() throws IOException {

		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnMove)))
			return true;
		else
			return false;
	}
	/**
	 * Function Name :- clickMoveoption<br>
	 * Description :- To click the Move option.
	 *
	 */
	public boolean clickMoveoption() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Move");
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnMove));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- clickCloseIcon<br>
	 * Description :- To click the Close icon.
	 *
	 */
	public boolean clickCloseIcon() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Closeicon");
		boolean flag = LeftClick._click(SessionDetailPageObjects(moveClosebtn));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- clickPromptdropdown<br>
	 * Description :- To click the dropdown icon.
	 *
	 */
	public boolean clickPromptdropdown() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("dropdown");
		boolean flag = LeftClick._click(SessionDetailPageObjects(promptDrpdown));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- clicksessionRow<br>
	 * Description :- To click the sessionRow icon.
	 *
	 */
	public boolean clicksessionRow() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("sessionRow");
		boolean flag = LeftClick._click(SessionDetailPageObjects(sessionRow));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- MovetoSessionDropdown<br>
	 * Description :- To move the sessionRow icon.
	 *
	 */
	public boolean MovetoSessionDropdown(String SessSearchText) throws IOException {
		boolean flag = false;
		By objPopupListlocator=CommonUtility._getByLocator(Constants.popupdropdownlist);
		flag = KendoDropdown._selectByValue(SessionDetailPageObjects(DropdownMoveSession), objPopupListlocator,SessionDetailPageObjects(DropdownMoveSessionAutoPop), SessSearchText);
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}

	/**
	 * Function Name :- clickMovebutton<br>
	 * Description :- To click the move button.
	 *
	 */
	public boolean clickMovebutton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Movebutton");
		boolean flag = LeftClick._click(SessionDetailPageObjects(movebtn));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- clickCancelbutton<br>
	 * Description :- To click the Cancel button.
	 *
	 */
	public boolean clickCancelbutton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Cancelbutton");
		boolean flag = LeftClick._click(SessionDetailPageObjects(cancelbtn));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}

	/**
	 * Function Name :- verifyAddIrregularityButtonAndClickOnit<br>
	 * Description :- To click the Add Irregularity button.
	 *
	 */
	public boolean verifyAddIrregularityButtonAndClickOnit() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		boolean flag = LeftClick._click(SessionDetailPageObjects(addirrgularitiesbtn));
		return flag;
	}
	
	/**
	 * Function Name :- verifyEnterIrregularityButton<br>
	 * Description :- To Verify the Enter Irregularity button.
	 *
	 */
	public boolean verifyEnterIrregularityButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(addirrgularitiesbtn)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- verifyIrregularitiesModalWindowOpened<br>
	 * Description :- To verify Irregularities modal window is opened
	 *
	 */
	public boolean verifyIrregularitiesModalWindowOpened() throws IOException {
		//CommonUtility._sleepForGivenTime(3000);
		boolean flag =false;
		try {
			WebDriverMain._waitForElementVisible(SessionDetailPageObjects(irregularitieswindow));
			flag = WebDriverMain._isElementVisible(SessionDetailPageObjects(irregularitieswindow));
		}
		catch(Exception e){
			return false;
		}
		return flag;
	}

	/**
	 * Function Name :- VerifyIrregularitiesLabel<br>
	 * Description :- To verify Irregularities labels
	 *
	 */

	public boolean VerifyIrregularitiesLabel(String label) throws IOException {
		boolean flag = true;
		String strLocator = null;
		By objlocator = null;
		try {
			// Set by locator object for label
			strLocator = "xpath=//div[contains(@class,'pa-check-label') and contains(text(),'" + label + "')]";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			if (WebDriverMain._isElementPresent(objlocator))
				flag = true;
			else
				flag = false;

		} catch (Exception e) {
			return flag;
		}
		return flag;
	}

	/**
	 * Function Name :- FillIrregularities<br>
	 * Description :- To fill the irregularities
	 *
	 */

	public boolean FillIrregularities(String fieldname) throws IOException {

		// Intialize Function variable
		boolean FilledFieldFalg = false;
		By objlocator = null;
		String strLocator = null;
		try {

			strLocator = "xpath=//div[contains(@class,'pa-check-label') and contains(text(),'" + fieldname
					+ "')]/parent::label/parent::div/input";
			objlocator = CommonUtility._getObjectLocator(strLocator);
			// radio
			if (WebDriverMain._isElementPresent(objlocator)) {
				FilledFieldFalg = LeftClick.clickByJS(objlocator);
			}

		} catch (NullPointerException nullE) {
			return false;
		} catch (Exception e) {
			return false;
		}

		return FilledFieldFalg;
	}

	/**
	 * Function Name :- verifyTextOnIrregWindow<br>
	 * Description :- Verify text on Irregularities window
	 *
	 */
	public boolean verifyTextOnIrregWindow(String headertext) throws IOException {
		CommonUtility._sleepForGivenTime(500);
		String actualText = WebDriverMain._getTextFromElement(SessionDetailPageObjects(textonirregwindow));
		System.out.println("actualText : "+actualText);
		System.out.println("headertext : "+headertext);
		if (actualText.contains(headertext)) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * Function Name :- fillCommentBox<br>
	 * Description :- To fill the comment in comment box
	 *
	 */
	public boolean fillCommentBox(String comment) throws IOException {
		CommonUtility._sleepForGivenTime(500);
		WebElement commentBox = WebDriverMain._getElementWithWait(SessionDetailPageObjects(commentbox));
		CommonUtility._scrollElement(commentBox);
		boolean flag = WebDriverMain._isElementVisible(SessionDetailPageObjects(commentbox));
		if (flag) {
			TextBox._setTextBox(SessionDetailPageObjects(commentbox), comment);
		}
		return flag;
	}

	/**
	 * Function Name :- verifyCancelButton<br>
	 * Description :- To verify cancel button is visible and clickable
	 *
	 */
	public boolean verifyCancelButtonVisibleAndClickable() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(cancelbtnonirregwindow))) {
			if (WebDriverMain._isElementClickable(SessionDetailPageObjects(cancelbtnonirregwindow))) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}

	}
	

	/**
	 * Function Name :- clickSaveAndCloseButton<br>
	 * Description :- To save the irregularities
	 *
	 */
	public boolean clickSaveAndCloseButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		if (LeftClick._click(SessionDetailPageObjects(saveandclosebtn))) {
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		} else {
			return false;
		}

	}

	/**
	 * Function Name :- verifySuccessMessageafteraddingirreg<br>
	 * Description :- To verify the success message after adding irregularities
	 *
	 */

	public boolean verifySuccessMessageafteraddingirreg(String successmessage) throws IOException {
		CommonUtility._sleepForGivenTime(3000);
		String textSuccess = WebDriverMain._getTextFromElement(SessionDetailPageObjects(Success_Message));
		if (textSuccess.contains(successmessage)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- verifyIrregCapsuleVisibleAndClickable<br>
	 * Description :- To verify the irreg capsule is visible and click on it
	 *
	 */

	public boolean verifyIrregCapsuleVisibleAndClickable() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(irregcapsule))) {
//			WebElement irregcapsuleelement = WebDriverMain._getElementWithWait(SessionDetailPageObjects(irregcapsule));
//			CommonUtility._scrollElement(irregcapsuleelement);
			if (LeftClick._click(SessionDetailPageObjects(irregcapsule))) {
				CommonUtility._sleepForGivenTime(2000);
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			} 
		}
		return false;
	}

	/**
	 * Function Name :- listOfIrregularities<br>
	 * Description :- To get the list of irregularities
	 *
	 */

	public List<String> listOfIrregularities() throws IOException {
		List<String> list = WebDriverMain._getListOfTextFromElements(SessionDetailPageObjects(irregularitieslabels));
		Collections.sort(list);
		return list;
	}
	
	

	/**
	 * Function Name :- closeIrregularitesWindow<br>
	 * Description :- To close Irregularities modal window
	 *
	 */
	public boolean closeIrregularitesWindow() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		if (LeftClick._click(SessionDetailPageObjects(closeirregularitieswindow))) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * Function Name :- getStudentName<br>
	 * Description :- To get the student name
	 *
	 */
	public String getStudentName(int rowindex) throws IOException {

		By objlocator, objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		String StudName = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				MapDgOrgRec = new HashMap<String, String>();
				objlocator1 = CommonUtility._getObjectLocator(
						"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr[" + Irow
								+ "]/td/button[contains(@class,'btn-link')]");

				if (WebDriverMain._isElementPresent(objlocator1)) {
					if (rowindex >= Irow) {
						objlocator = CommonUtility._getObjectLocator(
								"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}

						for (Map.Entry entry : MapDgOrgRec.entrySet()) {
						    if(entry.getKey().equals("Student Name")) {
						        System.out.println(entry.getKey() + ":" + entry.getValue());
						         StudName = entry.getValue().toString();
						       
						    }           
						}
					}
				}
			}
			
		
			return StudName;
		} else
			System.out.println("No record found");	
		return StudName;
	}
	
	
	/**
	 * Function Name :- GetStudAccommfromlist<br>
	 * Description :-To get Student Accom search results Details.
	 */
	public HashMap<String, String> GetStudAccommfromlist(int rowindex, String ColName)
			throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<String> accomlist=null;
		int selectcnt=1;
		// Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			// Match Column Name
			if (sDGColmnName.contains(ColName)) {
			///	System.out.println("Column Name : " + sDGColmnName);
				int datacounter = iCol + 1;
				List<WebElement> lstOrgrRow = WebDriverMain
						._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
			//	System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementPresent(SessionDetailPageObjects(NoRecords))) {
						MapDgOrgRec = new HashMap<String, String>();
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							if (rowindex >= selectcnt) {
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td[" + datacounter + "]");
								String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
								if (sDGColmnValue.length()>2) {
										if (sDGColmnValue.contains("More")) {
											objlocator = CommonUtility._getObjectLocator(
													"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
															+ Irow + "]/td[" + datacounter + "]//button[contains(text(),'More')]");
											if (LeftClick._click(objlocator)) {
												CommonUtility._sleepForGivenTime(1000);
												accomlist=GetMoreAccommWindow();
											}
											sDGColmnValue=accomlist.toString();
										}
										objlocator = CommonUtility._getObjectLocator(
												"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
														+ Irow + "]/td[2]");
										String sDGStudNameValue = WebDriverMain._getTextFromElement(objlocator);
										if (MapDgOrgRec.containsKey(sDGStudNameValue))
											MapDgOrgRec.put(sDGStudNameValue + "|" + Irow, sDGColmnValue);
										else
											MapDgOrgRec.put(sDGStudNameValue, sDGColmnValue);
										selectcnt=selectcnt+1;
									}
								}
							return MapDgOrgRec;
						}
					} else
						System.out.println("No record found");

				} else
					System.out.println("No record found");
			}
		}
		return MapDgOrgRec;
	}
	
	
	/**
	 * Function Name :- SelectStudAccommfromlist<br>
	 * Description :-To Select Student Accom search results Details.
	 */
	public HashMap<String, String> SelectStudAccommfromlist(int rowindex, String ColName, String MatchValues)
			throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		boolean selectedaccom=false;
		int selectcnt = 1;
		// Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			// Match Column Name
			if (sDGColmnName.contains(ColName)) {
			///	System.out.println("Column Name : " + sDGColmnName);
				int datacounter = iCol + 1;
				List<WebElement> lstOrgrRow = WebDriverMain
						._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
			//	System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementPresent(SessionDetailPageObjects(NoRecords))) {
						MapDgOrgRec = new HashMap<String, String>();
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							if (rowindex >= selectcnt) {
							objlocator = CommonUtility._getObjectLocator(
									"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td[" + datacounter + "]");
							String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
							if (sDGColmnValue.length()>2) {
								objlocator = CommonUtility._getObjectLocator(
										"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
												+ Irow + "]/td[2]");
								String sDGStudNameValue = WebDriverMain._getTextFromElement(objlocator);
								if (sDGColmnValue.contains("More")) {
									objlocator = CommonUtility._getObjectLocator(
											"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
													+ Irow + "]/td[" + datacounter + "]//button[contains(text(),'More')]");
									if (LeftClick._click(objlocator)) {
										CommonUtility._sleepForGivenTime(1000);
										selectedaccom=SelectMoreAccommWindow(MatchValues);
									}
								}
								else if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
									objlocator = CommonUtility._getObjectLocator(
											"xpath=//pa-session-details-container//kendo-grid//kendo-grid-list//table/tbody/tr["
													+ Irow + "]/td[" + datacounter + "]//a[contains(text(),'"+MatchValues+"')]");
									if (WebDriverMain._isElementPresent(objlocator)) {
										selectedaccom= LeftClick._click(objlocator);
										CommonUtility._sleepForGivenTime(2000);
										CommonFunctions.PleaseWaitAndLoadingMessage();
									}
								}
								if (selectedaccom) {
									if (MapDgOrgRec.containsKey(sDGStudNameValue))
										MapDgOrgRec.put(sDGStudNameValue + "|" + Irow, sDGColmnValue);
									else
										MapDgOrgRec.put(sDGStudNameValue, sDGColmnValue);
									selectcnt=selectcnt+1;
									return MapDgOrgRec;
								}
								}
						}
							}
						return MapDgOrgRec;
					} else
						System.out.println("No record found");

				} else
					System.out.println("No record found");
			}
		}
		return MapDgOrgRec;
	}
	
	
	
	/**
	 * Function Name :- GetMoreAccommWindow<br>
	 * Description :- To Get Accommodations modal window
	 *
	 */
	public List<String> GetMoreAccommWindow() throws IOException {
		List<String> accomlist=null;
		if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
			accomlist=CommonFunctions.GetDailogContent();
			CommonFunctions.CloseDialog();
		}
		return accomlist;

	}
	
	/**
	 * Function Name :- SelectMoreAccommWindow<br>
	 * Description :- To Select Accommodations modal window
	 *
	 */
	public boolean SelectMoreAccommWindow(String AccommValue) throws IOException {
		boolean selectedaccom=false;
		if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
			selectedaccom=CommonFunctions.SelectDailogContent(AccommValue);
			if (selectedaccom)
				return selectedaccom;
			else
				CommonFunctions.CloseDialog();
		}
		return selectedaccom;

	}
	
	/**
	 * Function Name :- updateStatusButton_isVisible<br>
	 * Description :- To verify Update button is visible
	 *
	 */
	public boolean PrviewTestIframe_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(iframePreview))) {
			CommonUtility._sleepForGivenTime(3000);
			return true;
		}
		else
			return false;
	}
	
	public boolean clickPrintAnswerSheetsButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		// boolean flag=SelectMoreActions("Delete");
		boolean flag = LeftClick._click(SessionDetailPageObjects(btnPrintAnswerSheet));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	public boolean PrintAnswerSheets_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnPrintAnswerSheet)))
			return true;
		else
			return false;
	}
	
	public boolean answerSheet_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(answerSheet)))
			return true;
		else
			return false;
	}

	
	
	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit User button.
	 *
	 */
	public boolean clickEditIrreguButton() throws IOException {
		CommonUtility._sleepForGivenTime(500);
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(btnEditIrregWindow))) {
			LeftClick._click(SessionDetailPageObjects(btnEditIrregWindow));
			CommonUtility._sleepForGivenTime(2000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		} else
			return false;

	}
	
	/**
	 * Function Name :- Close_Alerts<br>
	 * Description :- To Close Alerts
	 *
	 */
	public boolean RemoveIrregularityCheckbox() throws IOException {
		
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(RemoveIrregCheckbox))) {
			List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(RemoveIrregCheckbox));
			for (WebElement AlertEle : lstAlertsRow) {
				LeftClick.clickByWebElementJS(AlertEle);
				CommonUtility._sleepForGivenTime(1000);
			}
		}
		return true;
	}
	
	/**
	 * Function Name :- clickSaveChangesButton<br>
	 * Description :- To save the irregularities
	 *
	 */
	public boolean clickSaveChangesButton() throws IOException {
		if (LeftClick._click(SessionDetailPageObjects(savechangesbtn))) {
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		} else {
			return false;
		}

	}
	
	/**
	 * Function Name :- SelectTicketsPerPageDropdown<br>
	 * Description :- To select the tickets per page.
	 *
	 */
	public boolean SelectTicketsPerPageDropdown(String SessSearchText) throws IOException {
		boolean flag = false;
		By objPopupListlocator=CommonUtility._getByLocator(Constants.popupdropdownlist);
		flag = KendoDropdown._selectByValue(SessionDetailPageObjects(DropdownTicketsPage), objPopupListlocator, SessSearchText);
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- SelectPageLayout<br>
	 * Description :- To select the page layout options.
	 *
	 */
	public boolean SelectPageLayout(String format) throws IOException {
		boolean flag = false;
		String strLocator="xpath=//pa-print-student-test-ticket/div[contains(@class,'fixed-bar')]//label[contains(text(),'"+format+"')]/../input[@type='radio']";		
		By objlocator = CommonUtility._getObjectLocator(strLocator);
		//radio
		if(WebDriverMain._isElementPresent(objlocator)) {
			objlocator = CommonUtility._getObjectLocator(strLocator);
			flag = LeftClick.clickByJS(objlocator);
		}
		return flag;
	}
	
	/**
	 * Function Name :- clickProceedtoPrintButton<br>
	 * Description :- To Click the Proceed to Print
	 *
	 */
	public boolean clickProceedtoPrintButton() throws IOException {
		if (LeftClick._click(SessionDetailPageObjects(ProceedtoPrintbtn))) {
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		} else {
			return false;
		}

	}
	
	/**
	 * Function Name :- ProceedtoPrintButton_isVisible<br>
	 * Description :- To verify the Proceed to Print
	 *
	 */
	public boolean ProceedtoPrintButton_isVisible() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(ProceedtoPrintbtn)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- verifyPrintingOPtions<br>
	 * Description :- To verify the Printing OPtions Bar message
	 *
	 */

	public boolean verifyPrintingOptionTitle(String successmessage) throws IOException {
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess = WebDriverMain._getTextFromElement(SessionDetailPageObjects(PrintingOption_Bar_title));
		if (textSuccess.contains(successmessage)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Function Name :- VerifyPrintingOptionsBar<br>
	 * Description :- To verify the Printing Options Bar
	 *
	 */
	public boolean VerifyPrintingOptionsBar() throws IOException {
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(PrintingOption_Bar)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- GetSessionName<br>
	 * Description :- To get the session name.
	 *
	 */
	public String GetSessionName() throws IOException {
		String LabelValue = null;
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(lblSessionName))) {
			LabelValue = WebDriverMain._getTextFromElement(SessionDetailPageObjects(lblSessionName));
			if (LabelValue.contains("Session: "))
				LabelValue=LabelValue.replace("Session: ", "");
			return LabelValue;
		}
		return LabelValue;
	}
	
	/**
	 * Function Name :- hasStudentlist<br>
	 * Description :- To verify Student list.
	 *
	 */
	public boolean hasStudentlist() throws IOException {
		boolean flag=false;	
		try {
			//CommonUtility._sleepForGivenTime(8000);
			CommonFunctions.waitUntilLoadingSpinner(120);
			WebDriverMain._waitForElementVisible(SessionDetailPageObjects(StuRowPresent));
			List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
			if (lstOrgrRow.size() >= 1) {
				//if have Records
				if (!WebDriverMain._isElementVisible(SessionDetailPageObjects(NoRecords)))
					flag=true;
			} 
		}
		catch(Exception e) {
			return false;
		}
		return flag;
	}
	
	
	/**
	 * Function Name :- clickExporttoCSV<br>
	 * Description :- To click ExporttoCSV.
	 *
	 */
	public boolean clickExporttoCSV() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();	
			flag=LeftClick._click(SessionDetailPageObjects(LnkExporttoCSV));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(6000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- verifyExporttoCSV<br>
	 * Description :- To verify the ExporttoCSV.
	 *
	 */
	public boolean verifyExporttoCSV() throws IOException{
		if (WebDriverMain._isElementVisible(SessionDetailPageObjects(LnkExporttoCSV)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- getStudentListrecords<br>
	 * Description :- To get Student list table results Details.
	 *
	 */
	public List<List<String>> getStudentListrecords(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = new ArrayList<String>();
		List<List<String>> lstRecords =new ArrayList<List<String>>();
		
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionDetailPageObjects(StuDatagridHeaderRow));
		for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			if (sDGColmnName.length()>1) {
				if (sDGColmnName.equalsIgnoreCase("Exception"))
					System.out.println("sDGColmnName: " + sDGColmnName);
				else if (sDGColmnName.equalsIgnoreCase("Accom")) 
					System.out.println("sDGColmnName : " +sDGColmnName);
				else
					MapDgOrgdetails.add(sDGColmnName);
			
			}
		}
		lstRecords.add(MapDgOrgdetails);
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionDetailPageObjects(StuRowPresent));
		System.out.println("Student Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgdetails=new ArrayList<String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					int initcol=1;
					for (int iCol1 = initcol; iCol1 < dataRec.size(); iCol1++) {
						String sDGColmnName = lstheaderRow.get(iCol1).getText();
						String sDGColmnValue = dataRec.get(iCol1).getText();
						if (sDGColmnName.equalsIgnoreCase("Exception"))
							System.out.println("sDGColmnName: " + sDGColmnName);
						else if (sDGColmnName.equalsIgnoreCase("Accom")) 
							System.out.println("sDGColmnName : " +sDGColmnName);
						else if (sDGColmnName.equalsIgnoreCase("Status")) {
							//System.out.println("sDGColmnName : " +sDGColmnName);
							sDGColmnValue=sDGColmnValue.replace("Status ", "");
							MapDgOrgdetails.add(sDGColmnValue);
							System.out.println("sDGColmnValue : " +sDGColmnValue);
						}
						else
							MapDgOrgdetails.add(sDGColmnValue);
					}
					lstRecords.add(MapDgOrgdetails);
				}
				
			}
			return lstRecords;
		} else
			System.out.println("No record found");
		return lstRecords;
	}
	
	/**
	 * Function Name :- Report_BtnDownloadReport_isVisible<br>
	 * Description :- To verify Download Report is Visible.
	 *
	 */
	public boolean Report_BtnDownloadReport_isVisible() throws IOException {
		if (WebDriverMain._isElementPresent(SessionDetailPageObjects(Rep_DownloadReport)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- GetReportingUrl<br>
	 * Description :- To get the Reporting url.
	 *
	 */
	public String GetReportingUrl() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		String URL=WebDriverMain._getDriver().getCurrentUrl();
		CommonUtility._sleepForGivenTime(2000);
		return URL;
	}
	
	/**
	 * Function Name :- verifySessionDetailsinStudentTestingTicket<br>
	 * Description :- To verify the view Session details in Testing ticketsPage
	 * 
	 * @throws IOException
	 */
	public boolean verifySessionDetailsinStudentTestingTicket(HashMap<String, String> MapFilledField) throws IOException {
		boolean verifedFlag = true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try {

			By objlocator = null;
			for (Map.Entry<String, String> entry : MapFilledField.entrySet()) {
				System.out.println("INFO ViewMap - Fields  : " + entry.getKey());
				String sFieldLabel = entry.getKey();
				String sFieldValue = entry.getValue();
				if (sFieldLabel.length() >= 1) {
					// Testing days validation
					switch (sFieldLabel.toLowerCase()) {
					case "su":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "Su";
						else
							sFieldValue = "";
						break;
					case "m":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "M";
						else
							sFieldValue = "";
						break;
					case "tu":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "Tu";
						else
							sFieldValue = "";
						break;
					case "w":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "W";
						else
							sFieldValue = "";
						break;
					case "th":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "Th";
						else
							sFieldValue = "";
						break;
					case "f":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "F";
						else
							sFieldValue = "";
						break;
					case "sa":
						sFieldLabel = "Testing Schedule";
						if (sFieldValue.equalsIgnoreCase("Yes"))
							sFieldValue = "Sa";
						else
							sFieldValue = "";
						break;

					case "watchers":
						sFieldLabel = "Active Watchers";
						sFieldValue = "";
						break;
					case "created date":
						if (sFieldValue.substring(0, 1).equalsIgnoreCase("0"))
							sFieldValue = sFieldValue.substring(1);
						break;
					}
					objlocator = CommonUtility._getObjectLocator(
							"xpath=//pa-print-student-test-ticket//div[contains(@class,'session-info page_section')]/div//div[contains(text(),'" + sFieldLabel + "')]");
					boolean isFieldLabelPresent = WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if (sFieldValue.length() > 1) {
							MapDgStuRec.put(sFieldLabel, sFieldValue);
							objlocator = CommonUtility._getObjectLocator(
									"xpath=//pa-print-student-test-ticket//div[contains(@class,'session-info page_section')]/div//div[contains(text(),'" + sFieldLabel
											+ "')]/following-sibling::span[contains(text(),'" + sFieldValue + "')]");
							boolean isFieldValuePresent = WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								verifedFlag = false;
								UMReporter.log(Status.FAIL, "The field " + sFieldLabel
										+ " not matched with expected value : " + sFieldValue);
							}
						}
					}
				}
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}

		if (verifedFlag)
			UMReporter.log(Status.PASS,
					"Verified the Session Info details in Student Testing tickets page :" + MapDgStuRec);
		return verifedFlag;
	}
	
	/**
	 * Function Name :- verifySectionSealcodesinStudentTestingTicket<br>
	 * Description :- To verify the Section Seal codes in Student Testing Page
	 * 
	 * @throws IOException
	 */
	public boolean verifySectionSealcodesinStudentTestingTicket(List<Map<String, String>> lstSectionCards) throws IOException {
		boolean verifedFlag = true;
		By objlocator = null;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try {

			for (Map<String, String> MapSectioncard:lstSectionCards ) {
				String sFieldLabel=MapSectioncard.get("section");
				String sFieldValue=MapSectioncard.get("sectioncode");
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//pa-print-student-test-ticket//div[contains(@class,'session-info page_section')]/div[2]//h3[contains(text(),'" + sFieldLabel + "')]");
				boolean isFieldLabelPresent = WebDriverMain._isElementPresent(objlocator);
				if (isFieldLabelPresent) {
					if (sFieldValue.length() > 1) {
						String SecValue = WebDriverMain._getTextFromElement(objlocator);
						if (SecValue.contains(sFieldValue))
							MapDgStuRec.put(sFieldLabel, sFieldValue);
						else {
							verifedFlag = false;
							UMReporter.log(Status.FAIL, "The field " + sFieldLabel
									+ " not matched with expected value : " + sFieldValue);
						}
					}
				}
			}


		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}

		if (verifedFlag)
			UMReporter.log(Status.PASS,
					"Verified Section details in Student Testing tickets page :" + MapDgStuRec);
		return verifedFlag;
	}

}
