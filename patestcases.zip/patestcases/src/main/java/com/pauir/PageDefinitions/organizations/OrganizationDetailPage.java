/**
 * Organization Detail Page
 */
package com.pauir.PageDefinitions.organizations;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.testDataTypes.OrgContactfield;
import com.pauir.common.util.Constants;
import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.home.Home;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class OrganizationDetailPage {
	// Initialize
	Login login = new Login(WebDriverMain._getDriver());
	CommonFunctions common;
	Home home = new Home();

	// Organization Details page objects
	public static String OrganizationDetailspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String btnEdit="xpath|//a/span[contains(text(),'Edit')]";
	public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Home')]";
	public static String Breadcrumb_OrganizationList = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Organization Management')]";
	public static String Breadcrumb_DistrictsList = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Districts')]";
	public static String Breadcrumb_SchoolsList = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Schools')]";
	public static String OrgInfo_Section="xpath|//pa-org-edit//h5[contains(text(),'Info')]";
	public static String OrgAddress_Section="xpath|//pa-org-edit//h5[contains(text(),'Address')]";
	public static String OrgContact_Section="xpath|//pa-org-edit//h5[contains(text(),'Contact')]";
	public static String OrgLastUpdated="xpath|//pa-org-edit//span[contains(text(),'Last Modified')]";
	public static String CreateorgcontactForm="xpath|//pa-org-edit//form";
	public static String Addcontact="xpath|//button[contains(text(),'Add')]";
	public static String Savecontact="xpath|//pa-org-edit//button[contains(text(),'Save')]";
	public static String SaveForm="xpath|//pa-org-edit//button[contains(text(),'Save')]/../../../form";
	public static String ContactType1="xpath|//pa-org-edit//form//label[contains(text(),'Parent Organization Code')]";
	public static String FaxLabel="xpath|//pa-org-edit//form//label[contains(text(),'Fax')]";
	//
	public static String Editcontact="xpath|//pa-org-edit//div[1]/i";
	public static String Deletecontact="xpath|//pa-org-edit//div[2]/i";
	public static String Editcancel="xpath|//button[contains(text(),'Cancel')]";
	public static String OrgRowPresent = "xpath|//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String OrgDatagridHeaderRow = "xpath|//pa-org-list//kendo-grid//table/thead/tr/th";
	public static String AddcontactForm="xpath|//pa-org-edit//form";
	public static String Breadcrumb_orgmang = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Organization Management')]";
	
	public static String OrgReport_Tab = "xpath|//kendo-tabstrip/ul/li";
	public static String OrgReport_TabActive = "xpath|//kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
	public static String OrgReportDatagridHeaderRow = "xpath|//pa-org-report-list//kendo-grid//table/thead/tr/th";
	public static String OrgReportRowPresent = "xpath|//pa-org-report-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	public static String LstReports = "xpath|//pa-grid-actions//div[@class='popover-body']//div[contains(@class,'popover-item')]/button";
	
	/**
	 * Function Name :- OrganizationDetailPageObjects<br>
	 * Description :- To set Organization Details Page Objects locator.
	 * 
	 * @return By
	 */
	public By OrganizationDetailPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyOrganizationDetailsNavigation<br>
	 * Description :- To verify Organization Detail Page Navigation.
	 *
	 */
	public boolean verifyOrganizationDetailsNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		String OrgPageTitle=WebDriverMain._getTextFromElement(OrganizationDetailPageObjects(OrganizationDetailspage_Title));
		if ((OrgPageTitle.contains(Constants.mapCustomLabels.get("pa.core.org.state.details.title")))||(OrgPageTitle.contains(Constants.mapCustomLabels.get("pa.core.org.district.details.title")))||(OrgPageTitle.contains(Constants.mapCustomLabels.get("pa.core.org.school.details.title"))))
		//if ((OrgPageTitle.contains(Constants.StateDetailsPageTitle))||(OrgPageTitle.contains(Constants.DistrictDetailsPageTitle))||(OrgPageTitle.contains(Constants.SchoolDetailsPageTitle)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify edit button is visible
	 *
	 */
	public boolean EditButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(btnEdit)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- EditButton_isEnabled<br>
	 * Description :- To verify Edit button is enabled
	 *
	 */
	public boolean EditButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(OrganizationDetailPageObjects(btnEdit));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}

	/**
	 * Function Name :- Verify_Organization_Info<br>
	 * Description :- To verify Organization info section is visible
	 *
	 */
	public boolean Verify_Organization_Info() throws IOException{
		if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(OrgInfo_Section)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_Organization_Address<br>
	 * Description :- To verify Organization Address info  is visible
	 *
	 */
	public boolean Verify_Organization_Address() throws IOException{
		if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(OrgAddress_Section)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_Organization_Contact<br>
	 * Description :- To verify Organization Contacts info  is visible
	 *
	 */
	public boolean Verify_Organization_Contact() throws IOException{
		if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(OrgContact_Section)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- verifyViewOrganizationDetails<br>
	 * Description :- To verify the view  Organization details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewOrganizationDetails(HashMap<String,String> MapFilledStuTestField) throws IOException{
		boolean verifedFlag=true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledStuTestField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	           
	            
	            if (sFieldLabel.length()>1) {
//		            if (sFieldLabel.toLowerCase().contains("school")) {
//		            	sFieldLabel="Organization";
//		            }
		            objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//label[contains(text(),'"+sFieldLabel+"')]");
					boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if(sFieldValue.length()>1) { 
							MapDgStuRec.put(sFieldLabel, sFieldValue);
							 if ((sFieldLabel.equalsIgnoreCase("organization name"))||(sFieldLabel.equalsIgnoreCase("district name"))||(sFieldLabel.equalsIgnoreCase("school name"))) 
								 objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//h2[contains(text(),'"+sFieldValue+"')]");
							 else
								 objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//span[contains(text(),'"+sFieldValue+"')]");
							boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								verifedFlag=false;
								UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
							}
						}
					}
	            }
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		
		if (verifedFlag)
			UMReporter.log(Status.PASS,"User have access to View Organization field value in Organization details page :"+MapDgStuRec);
		return verifedFlag;
	}
	
	
	/**
	 * Function Name :- verifyOrgName<br>
	 * Description :- To verify the Organization name in  Student details Page 
	 * @throws IOException 
	 */	
	public boolean verifyOrgName(String OrgName) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//h2[contains(text(),'"+OrgName+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- verifyLastUpdatedLabel<br>
	 * Description :- To verify the last updated on Org details page form.
	 *
	 */
	public String verifyLastUpdatedLabel() throws IOException{
		String LstUpdatedDate=null;
		if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(OrgLastUpdated))) {
			LstUpdatedDate=WebDriverMain._getTextFromElement(OrganizationDetailPageObjects(OrgLastUpdated));
			return LstUpdatedDate;
		}
		else
			return LstUpdatedDate;
	}
	
	
	/**
	 * Function Name :- verifyOrganizationLabel<br>
	 * Description :- To verify the label on Organization details page form.
	 *
	 */
	public boolean verifyOrganizationLabel(String labelmessage) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//label[contains(text(),'"+labelmessage+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- GetValueforOrganizationLabel<br>
	 * Description :- To get the value for label on Organization details page form.
	 *
	 */
	public String GetValueforOrganizationLabel(String labelmessage) throws IOException{
		String LabelValue=null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-edit//label[contains(text(),'"+labelmessage+"')]/./following-sibling::span/span");
		if (WebDriverMain._isElementVisible(objlocator)) {
			LabelValue=WebDriverMain._getTextFromElement(objlocator);
			return LabelValue;
		
		}
		return LabelValue;
	}
	
	/**
	 * Function Name :- clickOrgListBreadcrumb<br>
	 * Description :- To click Org List Breadcrumb.
	 *
	 */
	public boolean clickOrgListBreadcrumb() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			flag=LeftClick._click(OrganizationDetailPageObjects(Breadcrumb_OrganizationList));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}	
	
	/**
	 * Function Name :- clickDistrictsBreadcrumb<br>
	 * Description :- To click Districts List Breadcrumb.
	 *
	 */
	public boolean clickDistrictsBreadcrumb() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			flag=LeftClick._click(OrganizationDetailPageObjects(Breadcrumb_DistrictsList));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- clickDistrictsBreadcrumb<br>
	 * Description :- To click Districts List Breadcrumb.
	 *
	 */
	public boolean clickSchoolsBreadcrumb() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			flag=LeftClick._click(OrganizationDetailPageObjects(Breadcrumb_SchoolsList));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
// Add contacts
	

	
	/**Function Name :- VerifyFieldLabel<br/>
	 * Description   :- VerifyFieldLabel
	 * @param fieldType Labelfor Label
	 * @return boolean
	 */
	public static boolean VerifyFieldLabel(String fieldType, String Label) {
		
		boolean flag =true;
		try{
			
			//Set by locator object for label
			String strLocator="xpath=//label[contains(text(),'"+Label+"')]";
			By objlocator = CommonUtility._getObjectLocator(strLocator);
			//Verify the label
			flag=WebDriverMain._containText(objlocator,Label);
			
		}catch(Exception e){
			return flag;
		}
		return flag;	
	}
	
	/**
	 * Function Name :- contactaddButton_isVisible<br>
	 * Description :- To verify add contact button is visible
	 */
	public boolean contactaddButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(Addcontact)))
			return true;
		else
			return false;
	
	}
	/**
	 * Function Name :- contactDeleteButton_isVisible<br>
	 * Description :- To verify Delete contact button is visible
	 */
	public boolean contactDeleteButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(Deletecontact)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- clickAddcontactButton<br>
	 * Description :- To click the Add contact button.
	 *
	 */
	public void clickaddcontactButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		WebElement targetElement = WebDriverMain._getElementWithWait(OrganizationDetailPageObjects("xpath|//pa-org-edit/div/div/div[1]"));
		if (targetElement!=null) {
			CommonUtility._scrollElement(targetElement);
			CommonUtility._sleepForGivenTime(500);
		}
		LeftClick._click(OrganizationDetailPageObjects(Addcontact));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
	}
	/**
	 * Function Name :- clickDeletecontactButton<br>
	 * Description :- To click the Delete contact button.
	 *
	 */
	public void clickDeletecontactButton() throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		LeftClick._click(OrganizationDetailPageObjects(Deletecontact));
//		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
	}
	/**
	 * Function Name :- clickcontactsaveButton<br>
	 * Description :- To click the save button.
	 *
	 */
	public void clickcontactsaveButton() throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(3000);
		WebElement targetElement = WebDriverMain._getElementWithWait(OrganizationDetailPageObjects(FaxLabel));
		CommonUtility._scrollElement(targetElement);
		CommonUtility._sleepForGivenTime(3000);
		LeftClick._click(OrganizationDetailPageObjects(Savecontact));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
	}
	
	/**
	 * Function Name :- clickcontacteditButton<br>
	 * Description :- To click the edit button.
	 *
	 */
	public void clickcontacteditButton() throws IOException{
			
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(OrganizationDetailPageObjects(Editcontact));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
	}
	
	
	
	/**
	 * Function Name :- contactaddButton_isEnabled<br>
	 * Description :- To verify add contactcreate button is enabled
	 *
	 */
	public boolean contactaddButton_isEnabled() throws IOException{
		if (WebDriverMain._isElementClickable(OrganizationDetailPageObjects(Addcontact)))
			return true;
		else
			return false;
	}

	/**
	 * Function Name :- contactdeleteButton_isEnabled<br>
	 * Description :- To verify delete button is enabled
	 *
	 */
	public boolean contactDeleteButton_isEnabled() throws IOException{
		if (WebDriverMain._isElementClickable(OrganizationDetailPageObjects(Deletecontact)))
			return true;
		else
			return false;
	}
	
	
	/**
	 * Function Name :- PageDataFieldValidation<br>
	 * Description :- To validate the contact fields in org detail page
	 * @throws IOException 
	 */
	public HashMap<String,String> PageDataFieldValidation(List<OrgContactfield> orgcontactfield, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean flag =false;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		By objcontrlerr=null;
		//Iterate each field values
		for (OrgContactfield field : orgcontactfield)
			    
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			String sFieldminLength=field.getMinLength();
			String sFieldmaxLength=field.getMaxLength();
			String sFieldregex=field.getRegex();
			String sFieldErrorMsg=field.getFielderrormsg();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
					
					//Field Validation on textbox and list
					if(sFieldType.equalsIgnoreCase("textbox")){
					//Validate the field for MinLength, MaxLength, Regex
					flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					
					WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
					
					if (targetElement != null) {
						targetElement.sendKeys(Keys.BACK_SPACE);
						CommonUtility._sleepForGivenTime(500);
						
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						
					}
					
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("dropdownlist")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "InvalidStringData", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
					}
					//Field Validation on textbox and list
					else if(sFieldType.equalsIgnoreCase("datepicker")){
						
						CommonUtility._sleepForGivenTime(1000);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
						objcontrlerr = CommonUtility._getObjectLocator("xpath=//label[contains(.,'"+sFieldLabel+"')]");
						WebElement targetElement1 = WebDriverMain._getElementWithWait(objcontrlerr);
						if (targetElement1 != null) {
							targetElement1.click();
							CommonUtility._sleepForGivenTime(500);
						}
						//Set by locator object for label
						String strLocator="xpath=//label[contains(.,'"+sFieldLabel+"')]/..//div[contains(@class,'form-control-error')]";
						objcontrlerr = CommonUtility._getObjectLocator(strLocator);
						//Verify the label
						flag=WebDriverMain._containText(objcontrlerr,Constants.FIELDERROR);
						//Validate the field for MinLength, MaxLength, Regex
						flag=common.FieldValidationswitchCase(sFieldType, objlocator,objsublocator, "03032019", sFieldLabel,sFieldminLength,sFieldmaxLength,sFieldregex);
					}
					//Fill the Value base fieldtype, locator, value
					FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				
			}
			}
		}
		return MapFilledOrgsField;
	}

	
	
	/**
	 * Function Name :- getOrgSearchresultsDetails<br>
	 * Description :- To get org search results Details.
	 *
	 */
	public HashMap<String, String> getOrgSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrganizationDetailPageObjects(OrgRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() > 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(OrganizationDetailPageObjects(OrgDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	
	/**
	 * Function Name :- FillcontactFields<br>
	 * Description :- To fill contact fields on add contact org detail page page
	 * @throws IOException 
	 */
	public HashMap<String, String> FillContactFields(List<OrgContactfield> contactfields, String filltype) throws IOException{
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		HashMap<String,String> MapFilledOrgsField=  new HashMap<String,String>();
		By objlocator=null;
		By objsublocator=null;
		//Iterate each field values
		for (OrgContactfield field : contactfields)
		{
			String sFieldName = field.getFieldname();
			String sFieldLocator = field.getObjectlocator();
			String sFieldType=field.getFieldtype();
			String sFieldLabel=field.getLabletodisplay();
			String sFieldrequired=field.getRequired();
			String sFieldValue=field.getFieldvalue();
			objsublocator=null;
			//Call to verify the field label 
			FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
			if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
			if (filltype.equalsIgnoreCase("required")){
				//Provide input to mandatory fields only
				if (sFieldrequired.equalsIgnoreCase("true")) {	
						//Fill the Value base fieldtype, locator, value
						FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				}
			}
			//Provide input to all field 
			else {
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
			}
			//Check Label verified and filled field value
			if (FilledFieldValue!=null) {
				//Filled label and value stored for validation in confirmation page
				MapFilledOrgsField.put(sFieldLabel,FilledFieldValue);
				CommonUtility._sleepForGivenTime(1000);
				
			}
			}
		}
		return MapFilledOrgsField;
	}
	
	
	/**
	 * Function Name :- VerifyaddcontactForm<br>
	 * Description :- To verify the Add contacts in org detail page.
	 *
	 */
	public boolean VerifyAddcontactForm() throws IOException{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		boolean isDisplayed=WebDriverMain._isElementPresent(OrganizationDetailPageObjects(AddcontactForm));
		//CommonUtility._sleepForGivenTime(2000);
		return isDisplayed;
		
	}
	

	/**
	 * Function Name :- FillOrgContactField<br>
	 * Description :- To fill Contact field depends on fieldtype  on org detail page
	 * @throws IOException 
	 */
	public String FillOrgContactField(OrgContactfield field, String FieldValue) throws IOException{

			
		//Intialize Function variable
		String FilledFieldValue =null;
		boolean FieldLabelflag =false;
		String sFieldValue=null;
		By objlocator=null;
		By objsublocator=null;
		//field values
		String sFieldName = field.getFieldname();
		String sFieldLocator = field.getObjectlocator();
		String sFieldType=field.getFieldtype();
		String sFieldLabel=field.getLabletodisplay();
		String sFieldrequired=field.getRequired();
		//Set input value
		if(FieldValue.equalsIgnoreCase(null))
			sFieldValue =field.getFieldvalue();
		else
			sFieldValue=FieldValue;
		
		objsublocator=null;
		//Call to verify the field label 
		FieldLabelflag=VerifyFieldLabel(sFieldType,sFieldLabel);
		if (FieldLabelflag) {
			//Set by locator object from configuration
			String strArrObjLocs[] = CommonUtility._split(sFieldLocator,";");
			if(strArrObjLocs.length==1){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
			}
			else if(strArrObjLocs.length==2){
				objlocator = CommonUtility._getObjectLocator(strArrObjLocs[0]);
				objsublocator = CommonUtility._getObjectLocator(strArrObjLocs[1]);
			}
				//Fill the Value base fieldtype, locator, value
				FilledFieldValue=common.FillInputswitchCase(sFieldType, objlocator,objsublocator, sFieldValue, sFieldLabel);
				

				//Field Validation on textbox and list
				if(sFieldType.equalsIgnoreCase("dropdownlist")){
					CommonUtility._sleepForGivenTime(1000);
				}
		}
		return FilledFieldValue;
	}

	/**
	 * Function Name :- clickManageOrganizationsBreadCrum<br>
	 * Description :- To click Manage Organizations BreadCrum.
	 *
	 */
	public boolean clickOrgMgmtBreadCrum() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			WebDriverMain._isElementVisible(OrganizationDetailPageObjects(Breadcrumb_orgmang));
			flag=LeftClick._click(OrganizationDetailPageObjects(Breadcrumb_orgmang));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(500);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- SelectTabOption<br>
	 * Description :- Select the Tab options
	 * 
	 * @param TabOption
	 * @throws IOException
	 */
	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean iActiveflag=false;
		By objlocator = CommonUtility
				._getObjectLocator("xpath=//kendo-tabstrip/ul/li/span[contains(text(),'"+TabOption+"')]");
		if (WebDriverMain._isElementPresent(objlocator)) {
			iActiveflag=VerifyActiveTab(TabOption);
			if (!iActiveflag) {
				LeftClick._click(objlocator);
				CommonUtility._sleepForGivenTime(1000);
				return true;
			}
			else
				return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- VerifyActiveTab<br>
	 * Description :- To verify Active Tab
	 * @throws IOException 
	 */
	public boolean VerifyActiveTab(String ActiveTab) throws IOException{
		CommonUtility._scrolldown();
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess=WebDriverMain._getTextFromElement(OrganizationDetailPageObjects(OrgReport_TabActive));
		if(textSuccess.contains(ActiveTab)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Function Name :- getOrgReportColumnHeaderDetails<br>
	 * Description :- To get Org Report table Column headers.
	 *
	 */
	public List<String> getOrgReportColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(OrganizationDetailPageObjects(OrgReportDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	
		//return MapDgOrgColHeader;
	}
	
	/**
	 * Function Name :- Verify_OrgHasReports<br>
	 * Description :- To verify Org has Report List  is visible
	 *
	 */
	public boolean Verify_OrgHasReports() throws IOException{
		if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(NoRecords)))
			return false;
		else
			return true; 
	}

	/**
	 * Function Name :- verifyOrgReportResultsDetails<br>
	 * Description :- To verify OrgReport search results Details.
	 *
	 */
	public List<String> verifyOrgReportResultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrganizationDetailPageObjects(OrgReportRowPresent));
		System.out.println("OrgReport Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(OrganizationDetailPageObjects(OrgReportDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-report-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyOrgReportSearchresultsSorting<br>
	 * Description :- To verify OrgReport search results sorting .
	 *
	 */
	public List<String> verifyOrgReportSearchresultsSorting(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrganizationDetailPageObjects(OrgReportRowPresent));
		System.out.println("OrgReport Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(OrganizationDetailPageObjects(OrgReportDatagridHeaderRow));
		if ((lstheaderRow.size() >= 1)&&(lstOrgrRow.size() > 2)) {
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//pa-org-report-list//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						objlocator =CommonUtility._getObjectLocator("xpath=//pa-org-report-list//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	/**
	 * Function Name :- SelectonReportsCheckbox<br>
	 * Description :- To verify Reports checkbox Details.
	 *
	 */
	public List<String> SelectonReportsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(OrganizationDetailPageObjects(OrgReportRowPresent));
		System.out.println("Reports Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(OrganizationDetailPageObjects(OrgReportDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			if (!WebDriverMain._isElementVisible(OrganizationDetailPageObjects(NoRecords))){
				MapDgdetails=new ArrayList<HashMap<String, String>>();
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-org-report-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
						if (WebDriverMain._isElementPresent(objlocator1)) {
							WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
							LeftClick.clickByWebElementJS(chbxele);
							CommonUtility._sleepForGivenTime(2000);
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-report-list//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							MapDgdetails.add(MapDgOrgRec);
							if (MapDgOrgRec.containsKey("Academic Year")&&MapDgOrgRec.containsKey("Administration")) {
								String SearchOrg=MapDgOrgRec.get("Academic Year")+" - "+MapDgOrgRec.get("Administration");
								MapDgOrgdetails.add(SearchOrg);
							}
						}
						else
						{
							return MapDgOrgdetails;
						}
					}
				}
				return MapDgOrgdetails;
			}
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- VerifyReportsList<br>
	 * Description :- To verify Reports this session.
	 *
	 */
	public List<String> VerifyReportsList(String ActionButtons) throws IOException {
		List<String> MapDgColValues = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//div[@role='tabpanel']//pa-grid-actions//button[contains(text(),'"+ActionButtons+"')]");
		try {
			if (WebDriverMain._isElementPresent(objlocator)) {
				if (LeftClick._click(objlocator)) {
					CommonUtility._sleepForGivenTime(2000);
					if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(LstReports))) {
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(OrganizationDetailPageObjects(LstReports));
						MapDgColValues = new ArrayList<String>();
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
					LeftClick._click(objlocator);
				}
			}
		} catch (Exception e) {
			return MapDgColValues;
		}
		return MapDgColValues;
	}
	
	/**
	 * Function Name :- SelectReportFromList<br>
	 * Description :- To select Reports this session.
	 *
	 */
	public boolean SelectReportFromList(String ActionButtons,String ReportName) throws IOException {
		List<String> MapDgColValues = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//div[@role='tabpanel']//pa-grid-actions//button[contains(text(),'"+ActionButtons+"')]");
		
		boolean flag = false;
		try {
			if (WebDriverMain._isElementVisible(objlocator)) {
				LeftClick._click(objlocator);
				CommonUtility._sleepForGivenTime(2000);
				if (WebDriverMain._isElementVisible(OrganizationDetailPageObjects(LstReports))) {
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(OrganizationDetailPageObjects(LstReports));
					MapDgColValues = new ArrayList<String>();
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnValue = dataRec.get(iCol).getText();
						if (sDGColmnValue.toLowerCase().contains(ReportName.toLowerCase())) {
							dataRec.get(iCol).click();
							CommonUtility._sleepForGivenTime(1000);
							CommonFunctions.PleaseWaitAndLoadingMessage();
							CommonUtility._sleepForGivenTime(2000);
							MapDgColValues.add(sDGColmnValue);
							flag = true;
							return flag;
						}
						MapDgColValues.add(sDGColmnValue);
					}
				}
				LeftClick._click(objlocator);
			}
		} catch (Exception e) {
			return flag;
		}
		return flag;
	}

	/**
	 * Function Name :- ReportsButton_isVisible<br>
	 * Description :- To verify Reports button is visible
	 */
	public boolean ReportsButton_isVisible(String ActionButtons) throws Exception {
		By objlocator = CommonUtility._getObjectLocator("xpath=//div[@role='tabpanel']//pa-grid-actions//button[contains(text(),'"+ActionButtons+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;

	}


}
