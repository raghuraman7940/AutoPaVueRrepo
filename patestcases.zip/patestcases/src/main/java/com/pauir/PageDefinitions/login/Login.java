/**
 * Login Page
 */
package com.pauir.PageDefinitions.login;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.util.Constants;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;


public class Login {
	//Initialize variable
	WebDriver driver;
	
	//Login page locators
	public static String SigninHeader="xpath|//div[@class='modal-dialog']/div[2]//form[@name='cognitoSignInForm']";
	public static String SigninButton="xpath|//pa-login/button";
	public static String username="xpath|//div[@class='modal-dialog']/div[2]//form[@name='cognitoSignInForm']//input[@name='username']";
	public static String password="xpath|//div[@class='modal-dialog']/div[2]//form[@name='cognitoSignInForm']//input[@name='password']";
	public static String LoginButton="xpath|//div[@class='modal-dialog']/div[2]//form[@name='cognitoSignInForm']//input[@name='signInSubmitButton']";
	public static String PearsonLogo="xpath|//img[@src='/cas/themes/pearson/images/pearson-logo-horizontal-2.svg']";
	public static String Menuoption="xpath|.//span[contains(@class,'fa fa-bars')]";
	
	public static String SignInDiffUser="xpath|//div[@class='modal-dialog']/div[2]//form[@name='cognitoSignInForm']//div[@id='div-logout']/p/a[contains(text(),'Sign in as a different user')]";
	public static String SignInSameUser="xpath|//div[@class='modal-dialog']/div[2]//form[@name='cognitoSignInForm']//button/span[contains(text(),'Sign In as')]";
	
	public static String Viewhtml="TAGNAME|html";

	public static String TCPage= "xpath|//pa-terms-conditions/kendo-dialog";
	public static String All_Tabs = "xpath|//pa-terms-conditions/kendo-dialog//kendo-tabstrip/ul/li";
	public static String TermCond_Tab = "xpath|//pa-terms-conditions/kendo-dialog//kendo-tabstrip/ul/li/span[contains(text(),'Terms & Conditions')]";
	public static String PvtPrcy_Tab = "xpath|//pa-terms-conditions/kendo-dialog//kendo-tabstrip/ul/li/span[contains(text(),'Privacy Policy')]";
	public static String TCActive_Tab = "xpath|//pa-terms-conditions/kendo-dialog//kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
	
	public static String DownLoadTC = "xpath|//div[@role='tabpanel']//button[contains(.,'Download Terms & Conditions')]";
	public static String DownLoadPvtPcy = "xpath|//div[@role='tabpanel']//button[contains(.,'Download Privacy Policy')]";
	public static String FrameTCPvtPcy = "xpath|//div[@role='tabpanel']//iframe";
	
	public static String btnAccept = "xpath|//div[@role='tabpanel']//button[contains(.,'Accept')]";
	public static String btnDecline = "xpath|//div[@role='tabpanel']//button[contains(.,'Decline')]";
	
	public static String closepage = "xpath|//div//span[@class = 'k-icon k-i-x']";
	public static String LnkLogintoPA="xpath|//pa-system-check//button[contains(text(),'Sign in to Pearson Access')]";
	public static String H1BrowserCheck="xpath|//pa-system-check//h1";
	
	public static String oneloginusername="xpath|//div[@id='root']//input[@id='username']";
	public static String oneloginpassword="xpath|//div[@id='root']//input[@id='password']";
	public static String oneloginContinue="xpath|//div[@id='root']//button/span[contains(text(),'Continue')]";
	
	
	/**
	 * Constructor
	 * Description :- To initialize the values.
	 * 
	 * @return boolean
	 */
	public Login(WebDriver driver) {
		this.driver = driver;

	}

	/**
	 * Constructor
	 * Description :- To initialize the values.
	 * 
	 * @return boolean
	 */
	public Login() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Function Name :- LoginPageObjects<br>
	 * Description :- To set Login page locator.
	 * 
	 * @return By
	 */
	public By LoginPageObjects(String byStrgylocValue)
	{
		 By by = null;
		 by=CommonUtility._getByLocator(byStrgylocValue);
		 return by;
	}

	/**
	 * Function Name :- typerUsername<br>
	 * Description :- To set Username field.
	 * @throws IOException 
	 * 
	 */
	public void typerUsername(String Username) throws IOException {
		TextBox._setTextBox(LoginPageObjects(username), Username);
	}
	
	/**
	 * Function Name :- IsUsernameFieldExist<br>
	 * Description :- To set Username field.
	 * @throws IOException 
	 * 
	 */
	public boolean IsUsernameFieldExist() throws IOException {
		boolean flag =WebDriverMain._isElementVisible(LoginPageObjects(username));
		return flag;
	}

	/**
	 * Function Name :- typePassword<br>
	 * Description :- To set password field.
	 * @throws IOException 
	 * 
	 */
	public void typePassword(String Password) throws IOException {
		TextBox._setTextBox(LoginPageObjects(password), Password);
	}

	/**
	 * Function Name :- Click_On_SignInButton<br>
	 * Description :- To click the signInButton
	 * @throws IOException 
	 * 
	 */
	public void Click_On_SignInButton() throws IOException {
		if(LeftClick._click(LoginPageObjects(SigninButton))){
			CommonUtility._sleepForGivenTime(500);
			CommonFunctions.PleaseWaitAndLoadingMessage();
		}
	}

	/**
	 * Function Name :- Click_On_SignInButton<br>
	 * Description :- To click the signInButton
	 * @throws IOException 
	 * 
	 */
	public boolean IsSignInButtonExist() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(SigninButton));
		return flag;
	}
	
	/**
	 * Function Name :- IsSignInHeaderExist<br>
	 * Description :- To verify the signIn to account
	 * @throws IOException 
	 * 
	 */
	public boolean IsSignInHeaderExist() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(SigninHeader));
		return flag;
	}
	/**
	 * Function Name :- Click_On_LoginButton<br>
	 * Description :- To click the LoginInButton
	 * @throws IOException 
	 * 
	 */
	public void Click_On_LoginButton() throws IOException {
		LeftClick._click(LoginPageObjects(LoginButton));
	}
	/**
	 * Function Name :- After_SignIn_PearsonLogo_visible<br>
	 * Description :- To verify the PearsonLogo
	 * @throws IOException 
	 * 
	 */
	public boolean After_SignIn_PearsonLogo_visible() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(PearsonLogo));
//		if (flag)
//			LeftClick._click(LoginPageObjects(PearsonLogo));
		
		return flag;
	}
	
	/**
	 * Function Name :- Click_On_MenuOption<br>
	 * Description :- To click menu option
	 * @throws IOException 
	 * 
	 */
	public void Click_On_MenuOption() throws IOException
	{
		CommonFunctions.PleaseWaitAndLoadingMessage();
		LeftClick._click(LoginPageObjects(Menuoption));
		
	}
	
	/**
	 * Function Name :- NavigatetoURL<br>
	 * Description :- To Navigate to given URL
	 * @throws IOException 
	 * 
	 */
	public String NavigatetoURL() throws IOException
	{
		String URL=null;
		String BrwTitle=null;
		try {
			CommonFunctions.PleaseWaitAndLoadingMessage();
			URL=FileReaderManager.getInstance().getJsonReader().getApplicationUrl();
			System.out.println("Loading Url : "+URL);  
			WebDriverMain._get(URL) ;
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(5000);
			BrwTitle=WebDriverMain._getDriver().getTitle();
			if (BrwTitle.length()>2) {
				Constants.APIServer=URL;
				System.out.println("Browser Title URL : "+BrwTitle);
			}
			else {
				System.out.println("Browser URL loading failed ");
			    WebElement lsttextelms=WebDriverMain._getElementWithWait(LoginPageObjects(Viewhtml));
			    if (lsttextelms!=null)
			      System.out.println("Browser HTML :"+lsttextelms.getAttribute("outerHTML"));
			}
		    
		}
		catch(Exception e) {
			System.out.println("URL loading failed ");
			e.printStackTrace();
			System.out.println("URL do refresh");
			WebDriverMain._getDriver().navigate().refresh();
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(5000);
			URL=null;
		}
		return URL;
		//UMReporter.log(Status.PASS,"User Navigated to "+URL+" Successfully");
		
	}
	
	

	/**
	 * Function Name :- NavigatetoTestURL<br>
	 * Description :- To Navigate to test URL
	 * @throws IOException 
	 * 
	 */
	public String NavigatetoTestURL() throws IOException
	{
		String URL=null;
		try {
			CommonFunctions.PleaseWaitAndLoadingMessage();
//			URL="https://int-tn8.pearsondev.com/client/index.html";
//			System.out.println("Browser loading Check for : "+URL);  
//			WebDriverMain._get(URL);
//			CommonFunctions.PleaseWaitAndLoadingMessage();
//			System.out.println("Browser Title URL : "+WebDriverMain._getDriver().getTitle());
//			
//			URL="https://uat.pearsonaccess.com";
			URL="https://pa-dev-main.pearsonpathway.com";
			System.out.println("Browser loading Check for : "+URL);  
			WebDriverMain._get(URL);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(5000);
			System.out.println("Browser Title URL : "+WebDriverMain._getDriver().getTitle());
			
			//System.out.println("Browser Title URL : "+WebDriverMain._getDriver().getTitle());
		    WebElement lsttextelms=WebDriverMain._getElementWithWait(LoginPageObjects(Viewhtml));
		    if (lsttextelms!=null)
		      System.out.println("HTML Tags :"+lsttextelms.getAttribute("outerHTML"));
		}
		catch(Exception e) {
			System.out.println("URL loading failed ");
			e.printStackTrace();
//			System.out.println("URL do refresh");
//			WebDriverMain._getDriver().navigate().refresh();
//			CommonFunctions.PleaseWaitAndLoadingMessage();
//			CommonUtility._sleepForGivenTime(5000);
			URL=null;
		}
		return URL;
		//UMReporter.log(Status.PASS,"User Navigated to "+URL+" Successfully");
		
	}
	
	/**
	 * Function Name :- doSignIn Function<br>
	 * Description :- To click SignIn button
	 * @throws IOException 
	 * 
	 */
	public void doSignIn() throws IOException  
	{
		//Sign In
		//CommonFunctions.PleaseWaitAndLoadingMessage();
		if (IsSignInButtonExist()) {
			Click_On_SignInButton();
			
		}				
	}
	/**
	 * Function Name :- doLogin Function<br>
	 * Description :- To provide Username , Password and click login button
	 * @param Username
	 * @param Password		
	 * @throws IOException 
	 * 
	 */
	public String doLogin() throws IOException  
	{

		//Sign In
		String Username;
		String Password;
		String RetnString=null;
		Username = FileReaderManager.getInstance().getJsonReader().getApplicationUsername();
		Password = FileReaderManager.getInstance().getJsonReader().getApplicationPassword();
		//CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(500);
		IsSignInHeaderExist();
		if (IsUsernameFieldExist()) {
			RetnString="Username :"+Username;
			System.out.println("LogIn Details : "+RetnString); 
			Constants.LOGGEDIN_USER=Username;
			typerUsername(Username);
			typePassword(Password);
			//Click Login
			Click_On_LoginButton();
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
			  	
		}
		else if (IsSignIn_ExistingUser()) 
		{
			Username=SignIn_ExistingUser();
			RetnString="Existing User :"+Username;
			System.out.println("LogIn Details : "+RetnString);   
		}
		else {
			System.out.println("Unable to find Sign In page : "); 
			
		}
		return RetnString;
		//UMReporter.log(Status.PASS,"User Entered with username "+Username+" and Password "+Password+" and logged in successfully");

	}
	
	
	/**
	 * Function Name :- NavigatetoAdminURL<br>
	 * Description :- To Navigate to given Admin URL
	 * @throws IOException 
	 * 
	 */
	public void NavigatetoAdminURL() throws IOException
	{
		String URL;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		URL=FileReaderManager.getInstance().getJsonReader().getAdminApplicationUrl();
		WebDriverMain._get(URL) ;
		//UMReporter.log(Status.PASS,"User Navigated to "+URL+" Successfully");
		
	}
	
	
	/**
	 * Function Name :- doAdminLogin Function<br>
	 * Description :- To provide Username , Password and click login button
	 * @param Username
	 * @param Password		
	 * @throws IOException 
	 * 
	 */
	public void doAdminLogin() throws IOException  
	{

		//Sign In
		String Username;
		String Password;
		Username = FileReaderManager.getInstance().getJsonReader().getApplicationUsername();
		Password = FileReaderManager.getInstance().getJsonReader().getApplicationPassword();
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		IsSignInHeaderExist();
		
		if (IsUsernameFieldExist()) {
			typerUsername(Username);
			typePassword(Password);
			//Click Login
			Click_On_LoginButton();
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}				
		//UMReporter.log(Status.PASS,"User Entered with username "+Username+" and Password "+Password+" and logged in successfully");

	}

	public void doLogin(String GivenUsername, String GivenPassword) throws IOException  
	{

		//Sign In
		String Username;
		String Password;
		Username = GivenUsername;
		Password = GivenPassword;
		System.out.println("Username is:"+Username);
		
		CommonFunctions.PleaseWaitAndLoadingMessage();
		IsSignInHeaderExist();
		if (IsUsernameFieldExist()) {
			Constants.LOGGEDIN_USER=Username;
			typerUsername(Username);
			typePassword(Password);
			//Click Login
			Click_On_LoginButton();
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		else if (IsSignIn_ExistingUser()) 
		{
			SignIn_DifferentUser();
			if (IsUsernameFieldExist()) {
				typerUsername(Username);
				typePassword(Password);
				//Click Login
				Click_On_LoginButton();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				CommonUtility._sleepForGivenTime(1000);
			}
		}
		//UMReporter.log(Status.PASS,"User Entered with UN "+Username+" and Password "+Password+" and logged in successfully");

	}
	
	public String doLogin(String Userrole) throws IOException  
	{

		//Sign In
		String Username;
		String Password;
		Username=FileReaderManager.getInstance().getJsonReader().getUserNamebyRole(Userrole);
		Password = FileReaderManager.getInstance().getJsonReader().getPasswordbyRole(Userrole);;
		System.out.println("Username is:"+Username);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		IsSignInHeaderExist();
		if (IsUsernameFieldExist()) {
			typerUsername(Username);
			typePassword(Password);
			//Click Login
			Click_On_LoginButton();
			Constants.LOGGEDIN_USER=Username;
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		else if (IsSignIn_ExistingUser()) 
		{
			SignIn_DifferentUser();
			if (IsUsernameFieldExist()) {
				typerUsername(Username);
				typePassword(Password);
				//Click Login
				Click_On_LoginButton();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				CommonUtility._sleepForGivenTime(1000);
			}
		}
		return Username;
		//UMReporter.log(Status.PASS,"User Entered with UN "+Username+" and Password "+Password+" and logged in successfully");

	}
	
	/**
	 * Function Name :- SignIn_DifferentUser<br>
	 * Description :- To Sign In with Different User
	 * @throws IOException 
	 * 
	 */
	public boolean SignIn_DifferentUser() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(SignInDiffUser));
		if (flag) {
			LeftClick._click(LoginPageObjects(SignInDiffUser));
			CommonFunctions.PleaseWaitAndLoadingMessage();
		}
		return flag;
	}
	
	/**
	 * Function Name :- SignIn_ExistingUser<br>
	 * Description :- To Sign In with Existing User
	 * @throws IOException 
	 * 
	 */
	public String SignIn_ExistingUser() throws IOException {
		String StrUsername=null;
		String Username = FileReaderManager.getInstance().getConfigReader().getApplicationUsername();
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(SignInSameUser));
		if (flag){
			StrUsername=WebDriverMain._getTextFromElement(LoginPageObjects(SignInSameUser));
			if (StrUsername.contains(Username)) {
				flag=LeftClick._click(LoginPageObjects(SignInSameUser));
				CommonFunctions.PleaseWaitAndLoadingMessage();
			}
		}
		return StrUsername;
	}
	
	/**
	 * Function Name :- SignIn_ExistingUser<br>
	 * Description :- To Sign In with Existing User
	 * @throws IOException 
	 * 
	 */
	public boolean SignIn_ExistingUser(String Username) throws IOException {
		String StrUsername=null;
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(SignInSameUser));
		if (flag) {
			StrUsername=WebDriverMain._getTextFromElement(LoginPageObjects(SignInSameUser));
			if (StrUsername.contains(Username)) {
				Constants.LOGGEDIN_USER=Username;
				flag=LeftClick._click(LoginPageObjects(SignInSameUser));
				CommonFunctions.PleaseWaitAndLoadingMessage();
				CommonUtility._sleepForGivenTime(1000);
			}
		}
		return flag;
	}
	
	/**
	 * Function Name :- SignIn_ExistingUser<br>
	 * Description :- To Sign In with Existing User
	 * @throws IOException 
	 * 
	 */
	public boolean IsSignIn_ExistingUser() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(SignInSameUser));
		return flag;
	}
	
	/**
	 * Function Name :- IsTcPageExist<br>
	 * Description :- To Verify TC Page 
	 * @throws IOException 
	 * 
	 */
	public boolean IsTcPageExist() throws IOException {
		
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(TCPage));
		return flag;
	}
	
	/**
	 * Function Name :- SelectTabOption<br>
	 * Description :- Select the Tab options
	 * 
	 * @param TabOption
	 * @throws IOException
	 */
	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean iActiveflag=false;
		if (WebDriverMain._isElementPresent(LoginPageObjects(All_Tabs))) {
			switch (TabOption.toLowerCase()) {
				case "terms & conditions":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						iActiveflag=LeftClick._click(LoginPageObjects(TermCond_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				case "privacy policy":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						iActiveflag=LeftClick._click(LoginPageObjects(PvtPrcy_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				default:
					iActiveflag=LeftClick._click(LoginPageObjects(TermCond_Tab));
					CommonUtility._sleepForGivenTime(1000);
					break;
			}
		}
		else
			return false;
		iActiveflag=VerifyActiveTab(TabOption);
		if (iActiveflag) {
			return true;
		}
		return false;


	}
	
	/**
	 * Function Name :- VerifyActiveTab<br>
	 * Description :- To verify Active Tab
	 * @throws IOException 
	 */
	public boolean VerifyActiveTab(String ActiveTab) throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess=WebDriverMain._getTextFromElement(LoginPageObjects(TCActive_Tab));
		if(textSuccess.contains(ActiveTab)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Function Name :- DownloadTCs<br>
	 * Description :- To Download Terms and Conditions
	 * @throws IOException 
	 * 
	 */
	public boolean DownloadTCs() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(DownLoadTC));
		if (flag) {
			LeftClick._click(LoginPageObjects(DownLoadTC));
			CommonFunctions.PleaseWaitAndLoadingMessage();
		}
		return flag;
	}
	
	/**
	 * Function Name :- DownloadPvtPlcy<br>
	 * Description :- To Download Private policy
	 * @throws IOException 
	 * 
	 */
	public boolean DownloadPvtPlcy() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(DownLoadPvtPcy));
		if (flag) {
			LeftClick._click(LoginPageObjects(DownLoadPvtPcy));
			CommonFunctions.PleaseWaitAndLoadingMessage();
		}
		return flag;
	}
	
	/**
	 * Function Name :- VerifyDownloadTcs<br>
	 * Description :- To Verify Tc
	 * @throws IOException 
	 * 
	 */
	public boolean VerifyDownloadTcs() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(DownLoadTC));
		return flag;
	}

	/**
	 * Function Name :- VerifyDownloadPvtPlcy<br>
	 * Description :- To Verify Private policy
	 * @throws IOException 
	 * 
	 */
	public boolean VerifyDownloadPvtPlcy() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(DownLoadPvtPcy));
		return flag;
	}
	
	/**
	 * Function Name :- VerifyIframe<br>
	 * Description :- To Verify Iframe
	 * @throws IOException 
	 * 
	 */
	public boolean VerifyIframe() throws IOException {
		
	
	    boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(FrameTCPvtPcy));
	    CommonUtility._sleepForGivenTime(2000);
	    CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- SelectAccept<br>
	 * Description :- To select Accept
	 * @throws IOException 
	 * 
	 */
	public boolean SelectAccept() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(btnAccept));
		if (flag) {
			LeftClick._click(LoginPageObjects(btnAccept));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- SelectDecline<br>
	 * Description :- To select Decline
	 * @throws IOException 
	 * 
	 */
	public boolean SelectDecline() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(btnDecline));
		if (flag) {
			LeftClick._click(LoginPageObjects(btnDecline));
			CommonFunctions.PleaseWaitAndLoadingMessage();
		}
		return flag;
	}
	
	
	/**
	 * Function Name :- Selectclose<br>
	 * Description :- To select close
	 * @throws IOException 
	 * 
	 */

public boolean Selectclose() throws IOException {
		boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(closepage));
		if (flag) {
			LeftClick._click(LoginPageObjects(closepage));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}

/**
 * Function Name :- ClickLoginToPA<br>
 * Description :- To click the Login In Pearson Access
 * @throws IOException 
 * 
 */
public void ClickLoginToPA() throws IOException {
	if(LeftClick._click(LoginPageObjects(LnkLogintoPA))){
		CommonUtility._sleepForGivenTime(500);
		CommonFunctions.PleaseWaitAndLoadingMessage();
	}
}

/**
 * Function Name :- IsLoginToPAExist<br>
 * Description :- To Check Login To Pearson Access Link exist
 * @throws IOException 
 * 
 */
public boolean IsLoginToPAExist() throws IOException {
	boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(LnkLogintoPA));
	return flag;
}

/**
 * Function Name :- GetBrowserHeaderSysCheck<br>
 * Description :- To Get System Check Browser Heading
 * @throws IOException 
 * 
 */
public String GetBrowserHeaderSysCheck() throws IOException {
	String StrUsername=null;
	boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(H1BrowserCheck));
	if (flag)
		StrUsername=WebDriverMain._getTextFromElement(LoginPageObjects(H1BrowserCheck));
	return StrUsername;
}

/**
 * Function Name :- typeOneLoginUsername<br>
 * Description :- To set Username field.
 * @throws IOException 
 * 
 */
public void typeOneLoginUsername(String Username) throws IOException {
	TextBox._setTextBox(LoginPageObjects(oneloginusername), Username);
}

/**
 * Function Name :- IsUsernameFieldExist<br>
 * Description :- To set Username field.
 * @throws IOException 
 * 
 */
public boolean IsOneLoginUsernameFieldExist() throws IOException {
	boolean flag =WebDriverMain._isElementVisible(LoginPageObjects(oneloginusername));
	return flag;
}

/**
 * Function Name :- IsUsernameFieldExist<br>
 * Description :- To set Username field.
 * @throws IOException 
 * 
 */
public boolean IsOneLoginPasswordFieldExist() throws IOException {
	boolean flag =WebDriverMain._isElementVisible(LoginPageObjects(oneloginpassword));
	return flag;
}

/**
 * Function Name :- typeOneLoginPassword<br>
 * Description :- To set password field.
 * @throws IOException 
 * 
 */
public void typeOneLoginPassword(String Password) throws IOException {
	TextBox._setTextBox(LoginPageObjects(oneloginpassword), Password);
}

/**
 * Function Name :- Click_OneLoginContinueButton<br>
 * Description :- To click the Onelogin Continue
 * @throws IOException 
 * 
 */
public void Click_OneLoginContinueButton() throws IOException {
	if(LeftClick._click(LoginPageObjects(oneloginContinue))){
		CommonUtility._sleepForGivenTime(500);
		CommonFunctions.PleaseWaitAndLoadingMessage();
	}
}

/**
 * Function Name :- IsOneLoginContinueButtonExist<br>
 * Description :- To click the Continue
 * @throws IOException 
 * 
 */
public boolean IsOneLoginContinueButtonExist() throws IOException {
	boolean flag= WebDriverMain._isElementPresent(LoginPageObjects(oneloginContinue));
	return flag;
}

/**
 * Function Name :- doOneLogin Function<br>
 * Description :- To provide Username , Password and click login button
 * @param Username
 * @param Password		
 * @throws IOException 
 * 
 */
public String doOneLogin() throws IOException  
{

	//Sign In
	String Username;
	String Password;
	String RetnString=null;
	Username = FileReaderManager.getInstance().getJsonReader().getApplicationUsername();
	Password = FileReaderManager.getInstance().getJsonReader().getApplicationPassword();
	//CommonFunctions.PleaseWaitAndLoadingMessage();
	CommonUtility._sleepForGivenTime(500);
	IsSignInHeaderExist();
	if (IsOneLoginUsernameFieldExist()) {
		RetnString=Username;
		System.out.println("LogIn Details : "+RetnString); 
		Constants.LOGGEDIN_USER=Username;
		typeOneLoginUsername(Username);
		Click_OneLoginContinueButton();
		if (IsOneLoginPasswordFieldExist()) {
			typeOneLoginPassword(Password);
			Click_OneLoginContinueButton();
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		else
			System.out.println("Unable to find Password field in Sign In page : ");
	}
	else {
		System.out.println("Unable to find Username field in Sign In page : "); 
		
	}
	return RetnString;
	//UMReporter.log(Status.PASS,"User Entered with username "+Username+" and Password "+Password+" and logged in successfully");

}

public String doOneLogin(String Userrole) throws IOException  
{

	//Sign In
	String Username;
	String Password;
	String RetnString=null;
	Username=FileReaderManager.getInstance().getJsonReader().getUserNamebyRole(Userrole);
	Password = FileReaderManager.getInstance().getJsonReader().getPasswordbyRole(Userrole);;
	System.out.println("Username is:"+Username);
	IsSignInHeaderExist();
	if (IsOneLoginUsernameFieldExist()) {
		RetnString=Username;
		System.out.println("LogIn Details : "+RetnString); 
		Constants.LOGGEDIN_USER=Username;
		typeOneLoginUsername(Username);
		Click_OneLoginContinueButton();
		if (IsOneLoginPasswordFieldExist()) {
			typeOneLoginPassword(Password);
			Click_OneLoginContinueButton();
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		else
			System.out.println("Unable to find Password field in Sign In page : ");
	}
	else {
		System.out.println("Unable to find Username field in Sign In page : "); 
		
	}
	return RetnString;
	//UMReporter.log(Status.PASS,"User Entered with UN "+Username+" and Password "+Password+" and logged in successfully");

}
	
}

