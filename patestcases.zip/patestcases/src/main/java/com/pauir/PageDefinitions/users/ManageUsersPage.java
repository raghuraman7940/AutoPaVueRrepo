/**
 * ManageUsersPage
 */
package com.pauir.PageDefinitions.users;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.pauir.PageDefinitions.home.Home;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class ManageUsersPage {
	// Initialize
	Login login = new Login(WebDriverMain._getDriver());
	CommonFunctions common;
	Home home = new Home();

	// Manage User page objects
		public static String ManageUserspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
		public static String CreateUser="xpath|.//button[@id='moreActions']";
		public static String DeleteUser="xpath|.//button[contains(.,'Delete')]";
		public static String btnResendInvite="xpath|.//button[contains(.,'Resend User Invite')]";
		public static String UserRowPresent = "xpath|//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr";
		public static String UserDatagridHeaderRow = "xpath|//pa-user-list//kendo-grid//table/thead/tr/th";
		public static String Name="xpath|.//palib-grid-column-sort[contains(text(),'Name')]";
		public static String Code="xpath|.//palib-grid-column-sort[contains(text(),'Code')]";
		public static String Type="xpath|.//palib-grid-column-sort[contains(text(),'Type')]";
		public static String Participating="xpath|.//palib-grid-column-sort[contains(text(),'Participating')]";
		public static String SearchInputFilter = "xpath|//pa-user-list//pa-grid-search//input";
		public static String searchicon = "xpath|.//i[@class='fa fa-search']";
		public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Home')]";
		public static String Breadcrumb = "xpath|//pa-breadcrumb/ol";
		public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
		public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
		public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
		public static String Progressbar="xpath|//pa-progress-bar/kendo-dialog/div[contains(@class,'k-dialog')]";

	/**
	 * Function Name :- ManageUsersPageObjects<br>
	 * Description :- To set Manage Users Page Objects locator.
	 * 
	 * @return By
	 */
	public By ManageUsersPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyManageUsersPageNavigation<br>
	 * Description :- To verify ManageUsers Page Navigation.
	 *
	 */
	public boolean verifyManageUsersPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(ManageUsersPageObjects(ManageUserspage_Title)).contains(Constants.UserListPageTitle))
			return true;
		else
			return false;
	}

/**
 * Function Name :- createButton_isVisible<br>
 * Description :- To verify create button is visible
 */
public boolean createButton_isVisible() throws Exception{
	if (WebDriverMain._isElementVisible(ManageUsersPageObjects(CreateUser)))
		return true;
	else
		return false;

}

/**
 * Function Name :- ResendInvite_isVisible<br>
 * Description :- To verify ResendInvite button is visible
 */
public boolean ResendInvite_isVisible() throws Exception{
	if (WebDriverMain._isElementVisible(ManageUsersPageObjects(btnResendInvite)))
		return true;
	else
		return false;

}


/**
 * Function Name :- createButton_isEnabled<br>
 * Description :- To verify create button is enabled
 *
 */
public boolean createButton_isEnabled() throws IOException{
	WebElement delete = WebDriverMain._getElementWithWait(ManageUsersPageObjects(CreateUser));
	String attributeText = delete.getAttribute("innerHTML");
	if(attributeText.contains("disabled"))
		return false;
	else
		return true;
}

/**
 * Function Name :- clickCreateUserButton<br>
 * Description :- To click the Create User button.
 *
 */
public boolean clickCreateUserButton() throws IOException{
	CommonUtility._sleepForGivenTime(500);
	LeftClick._click(ManageUsersPageObjects(CreateUser));
	CommonUtility._sleepForGivenTime(2000);
	CommonFunctions.PleaseWaitAndLoadingMessage();
	return true;
}


/**
 * Function Name :- deleteButton_isVisible<br>
 * Description :- To verify delete button is visible
 *
 */
public boolean deleteButton_isVisible() throws IOException{

	if (WebDriverMain._isElementVisible(ManageUsersPageObjects(DeleteUser)))
		return true;
	else
		return false; 
}


/**
 * Function Name :- deleteButton_isEnabled<br>
 * Description :- To verify delete button is enabled
 *
 */
public boolean deleteButton_isEnabled() throws IOException
{
	WebElement delete = WebDriverMain._getElementWithWait(ManageUsersPageObjects(DeleteUser));
	String attributeText = delete.getAttribute("innerHTML");
	if(attributeText.contains("disabled"))
		return false;
	else
		return true;
}

/**
 * Function Name :- clickDeleteButton<br>
 * Description :- To click the Delete button.
 *
 */
public boolean clickDeleteButton() throws IOException{
	LeftClick._click(ManageUsersPageObjects(DeleteUser));
	CommonUtility._sleepForGivenTime(2000);
	CommonFunctions.PleaseWaitAndLoadingMessage();
	return true;
}

/**
 * Function Name :- getuserColumnHeaderDetails<br>
 * Description :- To get user Col header Details.
 *
 */
public List<String> getUserColumnHeaderDetails() throws IOException {
	List<String> MapDgUserColHeader = null;
	List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(ManageUsersPageObjects(UserDatagridHeaderRow));
	if (lstheaderRow.size() >= 1) {
		MapDgUserColHeader=new ArrayList<String>();
		for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			MapDgUserColHeader.add(sDGColmnName);
		}
	}
	return MapDgUserColHeader;
}

/**
 * Function Name :- verifyUsersearchresultsDetails<br>
 * Description :- To get User search results Details.
 *
 */
public List<String> verifyUsersearchresultsDetails(int rowindex) throws IOException {
	By objlocator = null;
	List<String> MapDgUserdetails = null;
	HashMap<String, String> MapDgUserRec = null;
	List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(ManageUsersPageObjects(UserRowPresent));
	System.out.println("User Row Count : " + lstUserrRow.size());
	List<WebElement> lstheaderRow = WebDriverMain
			._getElementsWithWait(ManageUsersPageObjects(UserDatagridHeaderRow));
	if (lstUserrRow.size() >= 1) {
		MapDgUserdetails=new ArrayList<String>();
		for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
			if (rowindex >= Irow) {
				MapDgUserRec = new HashMap<String, String>();
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td");
				List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
				for (int iCol = 0; iCol < dataRec.size(); iCol++) {
					String sDGColmnName = lstheaderRow.get(iCol).getText();
					String sDGColmnValue = dataRec.get(iCol).getText();
					MapDgUserRec.put(sDGColmnName, sDGColmnValue);
				}
				MapDgUserdetails.add(MapDgUserRec.toString());
			}
			
		}
		return MapDgUserdetails;
	} else
		System.out.println("No record found");
	return MapDgUserdetails;
}


/**
 * Function Name :- verifyusersearchresultsCheckbox<br>
 * Description :- To verify user search results checkbox Details.
 *
 */
public List<String> verifyUsersearchresultsCheckbox(int rowindex) throws IOException {
	By objlocator,objlocator1 = null;
	List<String> MapDgUserdetails = null;
	HashMap<String, String> MapDgUserRec = null;
	List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(ManageUsersPageObjects(UserRowPresent));
	System.out.println("User Row Count : " + lstUserrRow.size());
	List<WebElement> lstheaderRow = WebDriverMain
			._getElementsWithWait(ManageUsersPageObjects(UserDatagridHeaderRow));
	if (lstUserrRow.size() >= 1) {
		MapDgUserdetails=new ArrayList<String>();
		for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
			if (rowindex >= Irow) {
				MapDgUserRec = new HashMap<String, String>();
				objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr["
						+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
				WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
				if (chbxele!=null) {
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgUserRec.containsKey("Name")&&(MapDgUserRec.containsKey("Email / Username"))) {
						String SearchUser=MapDgUserRec.get("Name")+" - "+MapDgUserRec.get("Email / Username");
						MapDgUserdetails.add(SearchUser);
					}
				}
				
			}
		}
		return MapDgUserdetails;
	} else
		System.out.println("No record found");
	return MapDgUserdetails;
}

/**
 * Function Name :- clickonTestlink<br>
 * Description :- To click Test Name hyper link.
 *
 */
public boolean SelectonUserCheckbox() throws IOException {
	By objlocator = null;
	CommonUtility._sleepForGivenTime(1000);
	List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(ManageUsersPageObjects(UserRowPresent));
	if (lstUserRow.size() >= 1) {
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//label[contains(@class,'k-checkbox-label')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (tsElm!=null) {
				LeftClick.clickByWebElementJS(tsElm);
				CommonFunctions.PleaseWaitAndLoadingMessage();
				CommonUtility._sleepForGivenTime(2000);
				return true;
			}
		}
	}
	return false;
}

/**
 * Function Name :- clickManageUsersBreadCrum<br>
 * Description :- To click Manage Users BreadCrum.
 *
 */
public boolean clickHomeBreadCrum() throws IOException{
	boolean flag=false;
	try {
		CommonUtility._scrollup();
		WebDriverMain._isElementVisible(ManageUsersPageObjects(Breadcrumb_Home));
		flag=LeftClick._click(ManageUsersPageObjects(Breadcrumb_Home));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(500);
	 }
	 catch(Exception e) {
	 		return false;
	 }
	return flag;
}

/**
 * Function Name :- Searchfill_UserName<br>
 * Description :- To Fill Name Filter in User Page.
 *
 */
public boolean Searchfill_UserName(String Username) throws Exception {
	boolean flag = WebDriverMain._isElementVisible(ManageUsersPageObjects(SearchInputFilter));
	if (flag){
		flag =TextBox._setTextBox(ManageUsersPageObjects(SearchInputFilter), Username);
		CommonUtility._sleepForGivenTime(200);
	}
	return flag;

}

/**
 * Function Name :- hasUserlist<br>
 * Description :- To get User search results Details.
 *
 */
public boolean hasUserlist() throws IOException {
	boolean flag=false;
	List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(ManageUsersPageObjects(UserRowPresent));
	if (lstUserrRow.size() >= 1) {
		if (!WebDriverMain._isElementVisible(ManageUsersPageObjects(NoRecords)))
			flag=true;	
	} 
	return flag;
}
/**
 * Function Name :- verifyUsersearchresultsDetailsfromtext<br>
 * Description :- To get User search results Details.
 *
 */
public List<String> verifyUsersearchresultsDetailsfromtext(String SearchText) throws IOException {
	By objlocator = null;
	List<String> MapDgUserdetails = null;
	HashMap<String, String> MapDgUserRec = null;
	CommonFunctions.PleaseWaitAndLoadingMessage();
	List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(ManageUsersPageObjects(UserRowPresent));
	System.out.println("User Row Count : " + lstUserrRow.size());
	List<WebElement> lstheaderRow = WebDriverMain
			._getElementsWithWait(ManageUsersPageObjects(UserDatagridHeaderRow));
	if (lstUserrRow.size() >= 1) {
		MapDgUserdetails=new ArrayList<String>();
		for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
		
				MapDgUserRec = new HashMap<String, String>();
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-User-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td");
				List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
				for (int iCol = 0; iCol < dataRec.size(); iCol++) {
					String sDGColmnName = lstheaderRow.get(iCol).getText();
					String sDGColmnValue = dataRec.get(iCol).getText();
					MapDgUserRec.put(sDGColmnName, sDGColmnValue);
				}
				if (MapDgUserRec.containsKey("Name")&&(MapDgUserRec.containsKey("Email / Username"))) {
					String SearchUser=MapDgUserRec.get("Name")+" - "+MapDgUserRec.get("Email / Username");
					if (SearchUser.toLowerCase().contains(SearchText.toLowerCase()))
						MapDgUserdetails.add(SearchUser);
					
				}
		
			
		}
		return MapDgUserdetails;
	} else
		System.out.println("No record found");
	return MapDgUserdetails;
}
/**
 * Function Name :- ClearSearchText<br>
 * Description :- To Clear Text in User Page.
 *
 */
public boolean ClearSearchText() throws Exception {
	boolean flag =TextBox._setTextBox(ManageUsersPageObjects(SearchInputFilter), "");
	CommonUtility._sleepForGivenTime(1000);
	return flag;
}

/**
 * Function Name :- clicksearchicon<br>
 * Description :- To clicks search icon.
 *
 */
public boolean clicksearchicon() throws IOException {

	boolean flag = WebDriverMain._isElementVisible(ManageUsersPageObjects(SearchInputFilter));
	if (flag) {
		flag=LeftClick._click(ManageUsersPageObjects(searchicon));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(2000);
	}
	return flag;
}

/**
 * Function Name :- SelectUserListCheckbox<br>
 * Description :- To Select user search results checkbox Details.
 *
 */
public List<String> SelectUserListCheckbox(int rowindex) throws IOException {
	By objlocator,objlocator1 = null;
	List<String> MapDgUserdetails = null;
	HashMap<String, String> MapDgUserRec = null;
	List<WebElement> lstUserrRow = WebDriverMain._getElementsWithWait(ManageUsersPageObjects(UserRowPresent));
	System.out.println("User Row Count : " + lstUserrRow.size());
	List<WebElement> lstheaderRow = WebDriverMain
			._getElementsWithWait(ManageUsersPageObjects(UserDatagridHeaderRow));
	if (lstUserrRow.size() >= 1) {
		MapDgUserdetails=new ArrayList<String>();
		for (int Irow = 1; Irow <= lstUserrRow.size(); Irow++) {
			if (rowindex >= Irow) {
				MapDgUserRec = new HashMap<String, String>();
				objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr["
						+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
				WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
				if (chbxele!=null) {
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgUserRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgUserRec.containsKey("Name")&&(MapDgUserRec.containsKey("Username / Email Address"))) {
						String SearchUser=MapDgUserRec.get("Name")+" - "+MapDgUserRec.get("Username / Email Address");
						MapDgUserdetails.add(SearchUser);
					}
					LeftClick.clickByWebElementJS(chbxele);
					CommonUtility._sleepForGivenTime(1000);
				}
				
			}
		}
		return MapDgUserdetails;
	} else
		System.out.println("No record found");
	return MapDgUserdetails;
}

/**
 * Function Name :- verifySelectedUserInlist<br>
 * Description :- To get User search results Details.
 *
 */
public List<String> verifySelectedUserInlist(String SearchText) throws IOException {
	By objlocator = null;
	List<String> MapDgOrgdetails = null;
	CommonFunctions.PleaseWaitAndLoadingMessage();
	List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ManageUsersPageObjects(UserRowPresent));
	if (lstOrgrRow.size() >= 1) {
		MapDgOrgdetails=new ArrayList<String>();
		//if have Records
		if (!WebDriverMain._isElementVisible(ManageUsersPageObjects(NoRecords))){
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-user-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td[2]");
					WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
					if (dataRec!=null) {
						String sDGStuName = dataRec.getText().trim();
						if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase()))
							MapDgOrgdetails.add(sDGStuName);
						//return MapDgOrgdetails;
					}
			}
		}
		return MapDgOrgdetails;
	} else
		System.out.println("No record found");
	return MapDgOrgdetails;
}

/**
 * Function Name :- GetSuccessMessage<br>
 * Description :- To get Success Message
 * @throws IOException 
 */
public String GetSuccessMessage() throws IOException{
	String textSuccess=null;
	try {
	 textSuccess=WebDriverMain._getTextFromElement(ManageUsersPageObjects(Success_Message));
	}
	catch(Exception e) {
		return null;
	}
	return textSuccess;
}
/**
 * Function Name :- Close_Alerts<br>
 * Description :- To close alert Message
 * @throws IOException 
 */
public boolean Close_Alerts() throws IOException{
	List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(ManageUsersPageObjects(CloseAlerts));
	for (WebElement AlertEle : lstAlertsRow) {
		if (WebDriverMain._isElementClickable(AlertEle)) {
			AlertEle.click();
		}
	}
	return true;
}

/**
 * Function Name :- waitForProgressbarVisible<br>
 * Description :- To wait Progress bar is visible
 */
public boolean waitForProgressbarVisible(int maxtimeout) throws Exception{
	int count=0;
	while((WebDriverMain._isElementVisible(ManageUsersPageObjects(Progressbar)))&&(count<maxtimeout))
	{
		CommonUtility._sleepForGivenTime(1000);
		count=count+1;
	}
	if (!WebDriverMain._isElementVisible(ManageUsersPageObjects(Progressbar)))
		return true;
	else
		return false;
	
}

}
	