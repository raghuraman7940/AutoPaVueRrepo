package com.pauir.PageDefinitions.products;

import java.io.IOException;

import org.openqa.selenium.By;

import com.pauir.common.util.Constants;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.WebDriverMain;

public class FormPreviewPage {

	// Form Preview page objects
	public static String PreviewTitle = "xpath|//pa-title//div[@id='breadcrumb_title']//h1";
	public static String TestDetailsTitle = "xpath|//pa-title//div[@id='breadcrumb_title']//h1";
	public static String testDetailbtn = "xpath|//pa-breadcrumb//button";
	public static String FormPreviewiFrame = "xpath|//pa-session-preview-form//iframe";

	/**
	 * Function Name :- FormPreviewPageObjects<br>
	 * Description :- To set Form Preview Page Objects locator.
	 * 
	 * @return By
	 */
	public By FormPreviewPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	/**
	 * Function Name :- clearTextFromSearchBox<br>
	 * Description :- To clear text from search box
	 *
	 */
	public boolean verifyFormPreviewerPage() throws IOException {

		String title = WebDriverMain._getTextFromElement(FormPreviewPageObjects(PreviewTitle));

		if (title.contains(Constants.FormPreviewTitle)) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * Function Name :- verifyiFrameLoaded<br>
	 * Description :- To verify previewer loaded within iFrame
	 *
	 */
	public boolean verifyiFrameLoaded() throws IOException {

		CommonUtility._sleepForGivenTime(2000);

		if (WebDriverMain._isElementPresent(FormPreviewPageObjects(FormPreviewiFrame))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- navigateToTestDetailsPage<br>
	 * Description :- To navigate back to test details page
	 *
	 */
	public boolean navigateToTestDetailsPage() throws IOException {

		if (LeftClick._click(FormPreviewPageObjects(testDetailbtn))) {
			CommonUtility._sleepForGivenTime(2000);
			if (WebDriverMain._getTextFromElement(FormPreviewPageObjects(TestDetailsTitle))
					.contains(Constants.TestDetailsPageTitle)) {
				return true;
			} else {
				return false;
			}

		}

		return false;

	}

}
