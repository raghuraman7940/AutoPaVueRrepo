package com.pauir.PageDefinitions.products;

import java.io.IOException;

import org.openqa.selenium.By;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.WebDriverMain;

public class CreateTestPage {
	
	public static String Localauthapp = "xpath|//pa-local-authoring[@class='ng-star-inserted']//iframe[@id='localAuthorIframe']";
	public static String Createtesttab = "xpath|//li[@id='k-tabstrip-tab-1']";
	
	public By CreateTestPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	public boolean createTestTabExistAndClikcOnit() throws IOException {
		boolean flag = WebDriverMain._isElementVisible(CreateTestPageObjects(Createtesttab));
		if (flag) {
			LeftClick._click(CreateTestPageObjects(Createtesttab));
		} 
		
		return flag;
	}
	
	
	public boolean verifyLocalAuthoringApp() throws IOException {
		
		
		boolean flag = WebDriverMain._isElementPresent(CreateTestPageObjects(Localauthapp));
	
		if (flag) 
		{
			return true;
		} 
		else
		{
			return false;
		}
		
	
	}
	
	
}


