/**
 * ManageOrganizationsPage
 */
package com.pauir.PageDefinitions.organizations;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.pauir.PageDefinitions.home.Home;
import webdriver.main.CommonUtility;
import webdriver.main.KendoDropdown;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class ManageOrganizationsPage {
	// Initialize
	Login login = new Login(WebDriverMain._getDriver());
	CommonFunctions common;
	Home home = new Home();

	// Manage User page objects
	public static String ManageOrgspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String CreateOrg="xpath|//pa-grid-actions/button[contains(text(),'Add')]";
	public static String DeleteOrg="xpath|//pa-grid-actions/button[contains(text(),'Delete')]";
	public static String OrgRowPresent = "xpath|//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String OrgDatagridHeaderRow = "xpath|//pa-org-list//kendo-grid//table/thead/tr/th";
	public static String OrgList="xpath|.//kendo-grid//table/thead/tr[1]/th[1]";
	public static String TableRecords="xpath|//kendo-grid//kendo-grid-list//table/tbody";
	public static String Name="xpath|.//palib-grid-column-sort[contains(text(),'Name')]";
	public static String Code="xpath|.//palib-grid-column-sort[contains(text(),'Code')]";
	public static String Type="xpath|.//palib-grid-column-sort[contains(text(),'Type')]";
	public static String ParentOrg="xpath|.//palib-grid-column-sort[contains(text(),'Parent Organization')]";
	public static String Participating="xpath|.//palib-grid-column-sort[contains(text(),'Participating')]";
	public static String OrgListDropDpwn = "xpath|.//label[contains(@class,'k-checkbox-label') and contains(@for,'k-grid0-check')]";
	public static String SearchInputFilter = "xpath|//pa-org-list//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Home')]";
	public static String Breadcrumb = "xpath|//pa-breadcrumb/ol";
	public static String Progressbar="xpath|//pa-progress-bar/kendo-dialog/div[contains(@class,'k-dialog')]";
	public static String Success_Message="xpath|//pa-alerts//div[@role ='alert']/p/span";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	
	public static String Org_Tab = "xpath|//pa-org-tabs/kendo-tabstrip/ul/li/span";
	public static String OrgActive_Tab = "xpath|//pa-org-tabs/kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
	public static String BtnEditAdminTime="xpath|//pa-grid-actions/button[contains(text(),'Edit Administration Time')]";	
	public static String DropdownAdministration="xpath|//kendo-dropdownlist[@id='testadmin']//span[@class='k-input']";
	
	/**
	 * Function Name :- ManageOrganizationsPageObjects<br>
	 * Description :- To set Manage Organizations Page Objects locator.
	 * 
	 * @return By
	 */
	public By ManageOrganizationsPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyManageOrgsPageNavigation<br>
	 * Description :- To verify ManageOrgs Page Navigation.
	 *
	 */
	public boolean verifyManageOrgsPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		String PageTitle=WebDriverMain._getTextFromElement(ManageOrganizationsPageObjects(ManageOrgspage_Title));
		//if ((PageTitle.contains(Constants.OrgDstListPageTitle))||(PageTitle.contains(Constants.OrgSchListPageTitle)))
		if ((PageTitle.contains(Constants.mapCustomLabels.get("pa.core.nav.link.label.org.list.dist")))||(PageTitle.contains(Constants.mapCustomLabels.get("pa.core.nav.link.label.org.list.sch"))))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- verifyDistrictsPageNavigation<br>
	 * Description :- To verify Manage Orgs Districts Page Navigation.
	 *
	 */
	public boolean verifyDistrictsPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(ManageOrganizationsPageObjects(ManageOrgspage_Title)).contains(Constants.mapCustomLabels.get("pa.core.nav.link.label.org.list.dist")))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- verifySchoolsPageNavigation<br>
	 * Description :- To verify ManageOrgs Page School Navigation.
	 *
	 */
	public boolean verifySchoolsPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(ManageOrganizationsPageObjects(ManageOrgspage_Title)).contains(Constants.mapCustomLabels.get("pa.core.nav.link.label.org.list.sch")))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- verifyOrgDetailsPageNavigation<br>
	 * Description :- To verify OrgDetails Page Navigation.
	 *
	 */
	public boolean verifyOrgDetailsPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		String OrgPageTitle=WebDriverMain._getTextFromElement(ManageOrganizationsPageObjects(ManageOrgspage_Title));
		//if ((OrgPageTitle.contains(Constants.DistrictDetailsPageTitle))||(OrgPageTitle.contains(Constants.SchoolDetailsPageTitle)))
		if ((OrgPageTitle.contains(Constants.mapCustomLabels.get("pa.core.org.district.details.title")))||(OrgPageTitle.contains(Constants.mapCustomLabels.get("pa.core.org.school.details.title"))))
			return true;
		else
			return false;
	}
	
	
	/**
	 * Function Name :- Searchfill_OrgName<br>
	 * Description :- To Fill Name Filter in Organization Page.
	 *
	 */
	public boolean Searchfill_OrgName(String Orgname) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(ManageOrganizationsPageObjects(SearchInputFilter), Orgname);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;
	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Organization Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(ManageOrganizationsPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		boolean flag = WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(ManageOrganizationsPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- waitforTableRecordsExist<br>
	 * Description :- To wait Table list to load
	 *
	 */
	public boolean waitforTableRecordsExist() throws IOException {
		WebDriverMain._waitForElementVisible(ManageOrganizationsPageObjects(TableRecords));
		if (WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(TableRecords)))
			return true;
		else
			return false;
	}
	/**
	 * Function Name :- clickManageOrganizationsBreadCrum<br>
	 * Description :- To click Manage Organizations BreadCrum.
	 *
	 */
	public boolean clickHomeBreadCrum() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();
			WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(Breadcrumb_Home));
			flag=LeftClick._click(ManageOrganizationsPageObjects(Breadcrumb_Home));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(500);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- clickonOrgame<br>
	 * Description :- To click Org Name filter.
	 *
	 */
	public boolean clickonOrgame(String Orgname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator("xpath=//td/button[contains(text(),'" + Orgname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	
	/**
	 * Function Name :- hasOrglist<br>
	 * Description :- To get org list results Details.
	 *
	 */
	public boolean hasOrglist() throws IOException {
		boolean flag=false;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(NoRecords)))
				flag=true;	
		} 
		return flag;
	}

	/**
	 * Function Name :- getOrgsearchresultsDetails<br>
	 * Description :- To get org search results Details.
	 *
	 */
	public HashMap<String, String> getOrgsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(ManageOrganizationsPageObjects(OrgDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	

	/**
	 * Function Name :- getOrgColumnHeaderDetails<br>
	 * Description :- To get org Col header Details.
	 *
	 */
	public List<String> getOrgColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	
		//return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- verifyOrgsearchresultsDetails<br>
	 * Description :- To get org search results Details.
	 *
	 */
	public List<String> verifyOrgsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ManageOrganizationsPageObjects(OrgDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyOrgsearchresultsCheckbox<br>
	 * Description :- To verify org search results checkbox Details.
	 *
	 */
	public List<String> verifyOrgsearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ManageOrganizationsPageObjects(OrgDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						
						if (MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"))&&(MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.dist")))) {
							String SearchOrg=MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"))+" - "+MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.dist"));
							MapDgOrgdetails.add(SearchOrg);
						}
						else if (MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch"))&&(MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.sch")))) {
							String SearchOrg=MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch"))+" - "+MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.sch"));
							MapDgOrgdetails.add(SearchOrg);
						}
						else if (MapDgOrgRec.containsKey("School Name")&&(MapDgOrgRec.containsKey("School Code"))) {
							String SearchOrg=MapDgOrgRec.get("School Name")+" - "+MapDgOrgRec.get("School Code");
							MapDgOrgdetails.add(SearchOrg);
						}
					}
					
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyOrgsearchresultsDetailsfromtext<br>
	 * Description :- To get org search results Details.
	 *
	 */
	public List<String> verifyOrgsearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ManageOrganizationsPageObjects(OrgDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
			
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}	
					if (MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"))&&(MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.dist")))) {
						String SearchOrg=MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"))+" - "+MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.dist"));
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
						
					}
					else if (MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch"))&&(MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.sch")))) {
						String SearchOrg=MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch"))+" - "+MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.sch"));
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
						
					}
					
					
				
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	

	/**
	 * Function Name :- clickonTestlink<br>
	 * Description :- To click Test Name hyper link.
	 *
	 */
	public boolean SelectonOrgCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Function Name :- SelectonOrgCheckbox<br>
	 * Description :- To select Org in search results checkbox Details.
	 *
	 */
	public List<String> SelectonOrgCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ManageOrganizationsPageObjects(OrgDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"))&&(MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.dist")))) {
							String SearchOrg=MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"))+" - "+MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.dist"));
							MapDgOrgdetails.add(SearchOrg);
						}
						else if (MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch"))&&(MapDgOrgRec.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.sch")))) {
							String SearchOrg=MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch"))+" - "+MapDgOrgRec.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.code.sch"));
							MapDgOrgdetails.add(SearchOrg);
						}
						
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}

	/**
	 * Function Name :- verifyOrgSearchresultsDetailsfromlist<br>
	 * Description :- To verify Org search results Details.
	 *
	 */
	public List<String> verifyOrgSearchresultsDetailsfromlist(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(NoRecords))){
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td[2]");
						WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
						if (dataRec!=null) {
							String sDGStuName = dataRec.getText().trim();
							if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase()))
								MapDgOrgdetails.add(sDGStuName);
							//return MapDgOrgdetails;
						}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifySuccessMessage<br>
	 * Description :- To verify Success Message
	 * @throws IOException 
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess=WebDriverMain._getTextFromElement(ManageOrganizationsPageObjects(Success_Message));
		if(textSuccess.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Function Name :- checkfirstrecord<br>
	 * Description :- To select the first record from the data grid
	 *
	 */
	public void checkfirstrecord(int count) throws IOException {
		{
			List<WebElement> orglist = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgListDropDpwn));
			int listCount = orglist.size();
//			int inputcount = Integer.parseInt(count);
			
			System.out.println("listcount :" + listCount);
			System.out.println("inputcount :" + count);

			for (int i = 0; i < listCount; i++) {
				WebElement e = orglist.get(i);

				if (i == count) {

					break;
				}

				else {

					LeftClick.clickByWebElementJS(e);
					CommonUtility._sleepForGivenTime(1000);

				}
			}
		}
	}
	
	/**
	 * Function Name :- createButton_isVisible<br>
	 * Description :- To verify create button is visible
	 */
	public boolean createButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(CreateOrg)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- createButton_isEnabled<br>
	 * Description :- To verify create button is enabled
	 *
	 */
	public boolean createButton_isEnabled() throws IOException{
		if (WebDriverMain._isElementClickable(ManageOrganizationsPageObjects(CreateOrg)))
			return true;
		else
			return false;
	}
	
	
	/**
	 * Function Name :- deleteButton_isVisible<br>
	 * Description :- To verify delete button is visible
	 *
	 */
	public boolean deleteButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(DeleteOrg)))
			return true;
		else
			return false; 
	}
	
	
	/**
	 * Function Name :- deleteButton_isEnabled<br>
	 * Description :- To verify delete button is enabled
	 *
	 */
	public boolean deleteButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(ManageOrganizationsPageObjects(DeleteOrg));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickDeleteButton<br>
	 * Description :- To click the Delete button.
	 *
	 */
	public boolean clickDeleteButton() throws IOException{
		boolean flag=LeftClick._click(ManageOrganizationsPageObjects(DeleteOrg));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	/**
	 * Function Name :- waitForProgressbarVisible<br>
	 * Description :- To wait Progress bar is visible
	 */
	public boolean waitForProgressbarVisible(int maxtimeout) throws Exception{
		int count=0;
		while((WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(Progressbar)))&&(count<maxtimeout))
		{
			CommonUtility._sleepForGivenTime(1000);
			count=count+1;
		}
		if (!WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(Progressbar)))
			return true;
		else
			return false;
		
	}
	
	/**
	 * Function Name :- GetTabOptions<br>
	 * Description :- Get the Tab options
	 * 
	 * @param TabOption
	 * @throws IOException
	 */
	public List<String> GetTabOptions(String TabOption) throws IOException {
		List<String> lstTabOptions = null;
		List<WebElement> lstRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(Org_Tab));
		if (lstRow.size()>=1) {
			lstTabOptions=new ArrayList<String>();
			for (WebElement Row : lstRow) {
				String tabstr = Row.getText();
				lstTabOptions.add(tabstr);
			}
		}
		return lstTabOptions;


	}
	
	/**
	 * Function Name :- SelectTabOption<br>
	 * Description :- Select the Tab options
	 * 
	 * @param TabOption
	 * @throws IOException
	 */
	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean flag=false;
		boolean iActiveflag=false;
		By objlocator = null;
		objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-tabs/kendo-tabstrip/ul/li/span[contains(text(),'"+TabOption+"')]");
		List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
		iActiveflag=VerifyActiveTab(TabOption);
		if (!iActiveflag) {
			flag=LeftClick._click(objlocator);
			CommonUtility._sleepForGivenTime(1000);
			iActiveflag=VerifyActiveTab(TabOption);
			if (iActiveflag) {
				return true;
			}
		}
		else 
			return true;
		
		return false;


	}
	
	/**
	 * Function Name :- VerifyActiveTab<br>
	 * Description :- To verify Active Tab
	 * @throws IOException 
	 */
	public boolean VerifyActiveTab(String ActiveTab) throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess=WebDriverMain._getTextFromElement(ManageOrganizationsPageObjects(OrgActive_Tab));
		if(textSuccess.contains(ActiveTab)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Function Name :- getOrgsearchresultsDetails<br>
	 * Description :- To get org search results Details.
	 *
	 */
	public HashMap<String, String> SelectOrglist() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ManageOrganizationsPageObjects(OrgRowPresent));
		System.out.println("Org Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(ManageOrganizationsPageObjects(OrgDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/button");
						WebElement tsElm =WebDriverMain._getElementWithWait(objlocator);
						if (WebDriverMain._isElementClickable(tsElm)) {
							tsElm.click();
							CommonFunctions.PleaseWaitAndLoadingMessage();
							return MapDgOrgRec;
						}
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- EditAdminTimeButton_isVisible<br>
	 * Description :- To verify EditAdminTime button is visible
	 *
	 */
	public boolean EditAdminTimeButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(ManageOrganizationsPageObjects(BtnEditAdminTime)))
			return true;
		else
			return false; 
	}
	
	
	/**
	 * Function Name :- clickEditAdminTimeButton<br>
	 * Description :- To click the EditAdminTime button.
	 *
	 */
	public boolean clickEditAdminTimeButton() throws IOException{
		boolean flag=LeftClick._click(ManageOrganizationsPageObjects(BtnEditAdminTime));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- VerifyEditAdminModalDisplayed<br>
	 * Description :- To Verify EditAdminTime Popup displayed.
	 * 
	 * @return boolean
	 */
	public boolean VerifyEditAdminModalDisplayed() throws IOException {
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog/div[contains(@class,'k-dialog')]");
		if (WebDriverMain._isElementPresent(objlocator)) {
			WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
			if (targetElement != null) {
				try {
					if (targetElement.isDisplayed())
						return true;
				} catch (Exception e) {
					return false;
				}
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- SelectAdministrationDropdown<br>
	 * Description :- To select the Administration.
	 *
	 */
	public boolean SelectAdministrationDropdown(String AdminText) throws IOException {
		boolean flag = false;
		By objPopupListlocator=CommonUtility._getByLocator(Constants.popupdropdownlist);
		flag = KendoDropdown._selectByValue(ManageOrganizationsPageObjects(DropdownAdministration), objPopupListlocator, AdminText);
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- verifyEditAdminLabel<br>
	 * Description :- To verify the label on EditAdmin page form.
	 *
	 */
	public boolean verifyEditAdminLabel(String labelmessage) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-list/kendo-dialog//label[contains(text(),'"+labelmessage+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- GetValueforEditAdminLabel<br>
	 * Description :- To get the value for label on Edit Admin Time form.
	 *
	 */
	public String GetValueforEditAdminLabel(String labelmessage) throws IOException{
		String LabelValue=null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-org-list/kendo-dialog//label[contains(text(),'"+labelmessage+"')]//following-sibling::span");
		if (WebDriverMain._isElementVisible(objlocator)) {
			LabelValue=WebDriverMain._getTextFromElement(objlocator);
			return LabelValue;
		
		}
		return LabelValue;
	}
	

}