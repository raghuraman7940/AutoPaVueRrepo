package com.pauir.PageDefinitions.sessions;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.WebDriverMain;

public class SessionListPage {
	// Initialize
	CommonFunctions common;

	// Session List page objects
		public static String SessionListPage_verification="xpath|.//h5[contains(text(),'Organizations')]";
		public static String SessionListTable="xpath|//pa-session-list//kendo-grid//table/thead";
		public static String SessionListPage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
		public static String btnMoreActions="xpath|.//button[@id='moreActions']";
		public static String btnCreate="xpath|//pa-placeholder/pa-session-tabs/kendo-tabstrip/ul//span[contains(text(),'Create Session')]";
		public static String SessionRowPresent = "xpath|//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr";
		public static String SessionDatagridHeaderRow = "xpath|//pa-session-list//kendo-grid//table/thead/tr/th";
		public static String SessionList="xpath|.//kendo-grid//table/thead/tr[1]/th[1]";
		public static String TableRecords="xpath|//kendo-grid//kendo-grid-list//table/tbody";
		public static String SessionListDropDpwn = "xpath|.//label[contains(@class,'k-checkbox-label') and contains(@for,'k-grid0-check')]";
		public static String SearchInputFilter = "xpath|//input[@placeholder=\"Search\"]";
		public static String searchicon = "xpath|.//i[@class='fa fa-search']";
		public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li[1]/a[contains(.,'home')]";
		public static String DeleteSession="xpath|//pa-session-list//pa-grid-actions/button[contains(.,'Delete') or contains(.,'Remove')]";
		public static String Progressbar="xpath|//pa-progress-bar/kendo-dialog/div[contains(@class,'k-dialog')]";

		public static String Success_Message="xpath|//pa-alerts//div[@role='alert']/p/span";
		public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
		public static String CloseAlerts="xpath|//pa-alerts//button[@class='close']";
		
		public static String Sessions_Tab = "xpath|//pa-session-tabs/kendo-tabstrip/ul/li";
		public static String SessionList_Tab = "xpath|//pa-session-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Sessions List')]";
		public static String CreateSession_Tab = "xpath|//pa-session-tabs/kendo-tabstrip/ul/li/span[contains(text(),'Create Session')]";
		public static String SessionsActive_Tab = "xpath|//pa-session-tabs/kendo-tabstrip/ul/li[contains(@class,'k-state-active')]/span";
		
		
		
	/**
	 * Function Name :- SessionListPageObjects<br>
	 * Description :- To set Session List Page Objects locator.
	 * 
	 * @return By
	 */
	public By SessionListPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifySessionListPageNavigation<br>
	 * Description :- To verify Session  List Page Navigation.
	 *
	 */
	public boolean verifySessionListPageNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(SessionListPageObjects(SessionListPage_Title)).contains(Constants.ViewSessionListPageTitle))
			return true;
		else
			return false;
	}
	
	
	/**
	 * Function Name :- IsSessionListTableExist<br>
	 * Description :- To verify Session List Table
	 *
	 */
	public boolean IsSessionListTableExist() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementVisible(SessionListPageObjects(SessionListTable))) {
			waitforTableRecordsExist();
			return true;
		}
		else
			return false;
	}
	/**
	 * Function Name :- Searchfill_SessionName<br>
	 * Description :- To Fill Name Filter in Session list Page.
	 *
	 */
	public boolean Searchfill_SessionName(String SessionName) throws Exception {
	
		boolean flag = WebDriverMain._isElementVisible(SessionListPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(SessionListPageObjects(SearchInputFilter), SessionName);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Session Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(SessionListPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(500);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		
		boolean flag = WebDriverMain._isElementVisible(SessionListPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(SessionListPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		}
		return flag;
	}
	
	/**
	 * Function Name :- waitforTableRecordsExist<br>
	 * Description :- To wait Table list to load
	 *
	 */
	public boolean waitforTableRecordsExist() throws IOException {
		//WebDriverMain._waitForElementVisible(SessionListPageObjects(TableRecords));
		if (WebDriverMain._isElementVisible(SessionListPageObjects(TableRecords)))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- clickHomeBreadCrum<br>
	 * Description :- To click Home BreadCrum.
	 *
	 */
	public boolean clickHomeBreadCrum() throws IOException{
		boolean flag=LeftClick._click(SessionListPageObjects(Breadcrumb_Home));
		common.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clickonSessionName<br>
	 * Description :- To click Session Name hyperlink.
	 *
	 */
	public boolean clickonSessionName(String Sessionname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//button[contains(text(),'" + Sessionname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (WebDriverMain._isElementClickable(tsElm)) {
				tsElm.click();
				CommonFunctions.PleaseWaitAndLoadingMessage();
				return true;
			}
		}
		return false;
	}
	
	

	/**
	 * Function Name :- getSessionSearchresultsDetails<br>
	 * Description :- To get Session search results Details.
	 *
	 */
	public HashMap<String, String> getSessionSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		System.out.println("Sessions Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					List<WebElement> lstheaderRow = WebDriverMain
							._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					return MapDgOrgRec;
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	
	
	/**
	 * Function Name :- SelectonSessionCheckboxWithMatchedColValue<br>
	 * Description :- To select Session in search results checkbox Details.
	 *
	 */
	public HashMap<String, String> SelectSessionbyMode(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
				System.out.println("Sess Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					if (!WebDriverMain._isElementVisible(SessionListPageObjects(NoRecords))) {
						MapDgOrgRec = new HashMap<String, String>();
						for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
							
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
								String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
								if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
									if (rowindex >= selectcnt) {
										//Select Matched Session
										objlocator = CommonUtility
												._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
														+ Irow + "]/td");
										List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
										
										for (int iCol1 = 0; iCol1 < dataRec.size(); iCol1++) {
											String sDGColmnName1 = lstheaderRow.get(iCol1).getText();
											String sDGColmnValue1 = dataRec.get(iCol1).getText();
											MapDgOrgRec.put(sDGColmnName1, sDGColmnValue1);
										}
										
										objlocator = CommonUtility
												._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
														+ Irow + "]/td//button");
										boolean flag=LeftClick._click(objlocator);
										if (flag) {
											CommonFunctions.PleaseWaitAndLoadingMessage();
											return MapDgOrgRec;
										}
									
									}
								}	
						}
				}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgRec;
	}

	/**
	 * Function Name :- getSessionColumnHeaderDetails<br>
	 * Description :- To get Session table Column headers.
	 *
	 */
	public List<String> getSessionColumnHeaderDetails() throws IOException {
		By objlocator = null;
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	
		//return MapDgOrgColHeader;
	}

	/**
	 * Function Name :- hasSessionlist<br>
	 * Description :- To verify Session list.
	 *
	 */
	public boolean hasSessionlist() throws IOException {
		boolean flag=false;	
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		if (lstOrgrRow.size() >= 1) {
			//if have Records
			if (!WebDriverMain._isElementVisible(SessionListPageObjects(NoRecords)))
				flag=true;
		} 
		return flag;
	}
	
	/**
	 * Function Name :- verifySessionSearchresultsDetails<br>
	 * Description :- To verify Session search results Details.
	 *
	 */
	public List<String> verifySessionSearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		System.out.println("Session Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifySessionSearchresultsCheckbox<br>
	 * Description :- To verify Session search results checkbox .
	 *
	 */
	public List<String> verifySessionSearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		System.out.println("Session Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey("Session Name")) {
							String SearchOrg=MapDgOrgRec.get("Session Name");
							MapDgOrgdetails.add(SearchOrg);
						}
					}
					
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	
	/**
	 * Function Name :- verifySessionSearchresultsSorting<br>
	 * Description :- To verify Session search results sorting .
	 *
	 */
	public List<String> verifySessionSearchresultsSorting(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgColValues = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		System.out.println("Session Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		if ((lstheaderRow.size() >= 1)&&(lstOrgrRow.size() >= 2)) {
			for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				if (sDGColmnName.contains(ColName)) {
					MapDgColValues=new ArrayList<String>();
					int datacounter= iCol+1;
					for (int iSorCount = 0; iSorCount < 2; iSorCount++) {
						objlocator1 =CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//table/thead/tr/th["+datacounter + "]/a/span[@aria-label='Sortable']");
						LeftClick.clickByJS(objlocator1);
						CommonUtility._sleepForGivenTime(1000);
						objlocator =CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr/td["+ datacounter + "]");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iColval = 0; iColval < dataRec.size(); iColval++) {
							String sDGColmnValue = dataRec.get(iColval).getText();
							MapDgColValues.add(sDGColmnValue);
						}
					}
				}
			}
		}
		return MapDgColValues;
	}
	
	/**
	 * Function Name :- verifySessionSearchresultsDetailsfromtext<br>
	 * Description :- To verify Session search results Details.
	 *
	 */
	public List<String> verifySessionSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		String OrgName=null,OrgCode=null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		System.out.println("Session Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
			
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					if (MapDgOrgRec.containsKey("Session Name")) {
						String SearchOrg=MapDgOrgRec.get("Session Name");
						if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
							MapDgOrgdetails.add(SearchOrg);
						
					}
					
					
				
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	

	/**
	 * Function Name :- SelectonSessionCheckbox<br>
	 * Description :- To click Session name Checkbox.
	 *
	 */
	public boolean SelectonSessionCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}


	/**
	 * Function Name :- SelectonSessionCheckbox<br>
	 * Description :- To select Session in search results checkbox Details.
	 *
	 */
	public List<String> SelectonSessionCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		System.out.println("Sess Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/input[contains(@type,'checkbox')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey("Session Name")) {
							String SearchOrg=MapDgOrgRec.get("Session Name");
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	
	/**
	 * Function Name :- SelectonSessionCheckboxWithMatchedColValue<br>
	 * Description :- To select Session in search results checkbox Details.
	 *
	 */
	public List<String> SelectonSessionCheckboxWithMatchedColValue(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
				System.out.println("Sess Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					MapDgOrgdetails=new ArrayList<String>();
					MapDgdetails=new ArrayList<HashMap<String, String>>();
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
						String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
						if (sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
							if (rowindex >= selectcnt) {
								//Select Matched Checkbox
								objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/input[contains(@type,'checkbox')]");
								WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
								if (chbxele!=null) {
									LeftClick.clickByWebElementJS(chbxele);
									objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td[2]");
									String sDGSessValue = WebDriverMain._getTextFromElement(objlocator);
									MapDgOrgdetails.add(sDGSessValue);
									selectcnt=selectcnt+1;
								}
							}
						}	
					}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgdetails;
	}
	
	
	/**
	 * Function Name :- SelectonSessionCheckboxWithNotMatchedColValue<br>
	 * Description :- To select Session in search results checkbox Details.
	 *
	 */
	public List<String> SelectonSessionCheckboxWithNotMatchedColValue(int rowindex,String ColName,String MatchValues) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		int selectcnt=1;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
				System.out.println("Sess Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					MapDgOrgdetails=new ArrayList<String>();
					MapDgdetails=new ArrayList<HashMap<String, String>>();
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]");
						String sDGColmnValue = WebDriverMain._getTextFromElement(objlocator);
						if (!sDGColmnValue.toLowerCase().contains(MatchValues.toLowerCase())) {
							if (rowindex >= selectcnt) {
								//Select Matched Checkbox
								objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td/input[contains(@type,'checkbox')]");
								WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
								if (chbxele!=null) {
									LeftClick.clickByWebElementJS(chbxele);
									objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td[2]");
									String sDGSessValue = WebDriverMain._getTextFromElement(objlocator);
									MapDgOrgdetails.add(sDGSessValue);
									selectcnt=selectcnt+1;
								}
							}
						}	
					}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgdetails;
	}
	/**
	 * Function Name :- verifyOrgSearchresultsDetailsfromlist<br>
	 * Description :- To verify Org search results Details.
	 *
	 */
	public List<String> verifyOrgSearchresultsDetailsfromlist(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(SessionListPageObjects(NoRecords))){
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td[2]");
						WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
						if (dataRec!=null) {
							String sDGStuName = dataRec.getText().trim();
							if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase()))
								MapDgOrgdetails.add(sDGStuName);
							//return MapDgOrgdetails;
						}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifySuccessMessage<br>
	 * Description :- To verify Success Message
	 * @throws IOException 
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess=WebDriverMain._getTextFromElement(SessionListPageObjects(Success_Message));
		if(textSuccess.contains(successmessage)){
			return true;
		}else{
			return false;
		}
	}


	/**
	 * Function Name :- checkfirstrecord<br>
	 * Description :- To select the first record from the data grid
	 *
	 */
	public void checkfirstrecord(int count) throws IOException {
		List<WebElement> orglist = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionListDropDpwn));
		int listCount = orglist.size();
		System.out.println("listcount :" + listCount);
		System.out.println("inputcount :" + count);
		for (int i = 0; i < listCount; i++) {
			WebElement e = orglist.get(i);
			if (i == count) {
				break;
			}
			else {
				LeftClick.clickByWebElementJS(e);
				CommonUtility._sleepForGivenTime(1000);
			}
		}
	}
		
	/**
	 * Function Name :- CreateButton_isVisible<br>
	 * Description :- To verify Create button is visible
	 *
	 */
	public boolean CreateButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(SessionListPageObjects(btnCreate)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- CreateButton_isEnabled<br>
	 * Description :- To verify Create button is enabled
	 *
	 */
	public boolean CreateButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(SessionListPageObjects(btnCreate));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickCreateSessionButton<br>
	 * Description :- To click the Create Session button.
	 *
	 */
	public void clickCreateSessionButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(SessionListPageObjects(btnCreate));
		CommonUtility._sleepForGivenTime(2000);
		common.PleaseWaitAndLoadingMessage();
	}
	
	/**
	 * Function Name :- deleteButton_isVisible<br>
	 * Description :- To verify delete button is visible
	 *
	 */
	public boolean deleteButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(SessionListPageObjects(DeleteSession)))
			return true;
		else
			return false; 
	}
	
	
	/**
	 * Function Name :- deleteButton_isEnabled<br>
	 * Description :- To verify delete button is enabled
	 *
	 */
	public boolean deleteButton_isDisabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(SessionListPageObjects(DeleteSession));
		String attributeText = delete.getAttribute("outerHTML");
		System.out.println("attributeText :"+attributeText);
		if(attributeText.contains("disabled"))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- clickDeleteButton<br>
	 * Description :- To click the Delete button.
	 *
	 */
	public boolean clickDeleteButton() throws IOException{
		boolean flag=LeftClick._click(SessionListPageObjects(DeleteSession));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	/**
	 * Function Name :- waitForProgressbarVisible<br>
	 * Description :- To wait Progress bar is visible
	 */
	public boolean waitForProgressbarVisible(int maxtimeout) throws Exception{
		int count=0;
		while((WebDriverMain._isElementVisible(SessionListPageObjects(Progressbar)))&&(count<maxtimeout))
		{
			CommonUtility._sleepForGivenTime(1000);
			count=count+1;
		}
		if (!WebDriverMain._isElementVisible(SessionListPageObjects(Progressbar)))
			return true;
		else
			return false;
		
	}
	
	/**
	 * Function Name :- CreateSessionTab_isVisible<br>
	 * Description :- To verify Create Session button is visible
	 *
	 */
	public boolean CreateSessionTab_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(SessionListPageObjects(CreateSession_Tab)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- SelectTabOption<br>
	 * Description :- Select the Tab options
	 * 
	 * @param TabOption
	 * @throws IOException
	 */
	public boolean SelectTabOption(String TabOption) throws IOException {
		boolean flag=false;
		boolean iActiveflag=false;
		if (WebDriverMain._isElementPresent(SessionListPageObjects(Sessions_Tab))) {
			switch (TabOption.toLowerCase()) {
				case "sessions list":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						flag=LeftClick._click(SessionListPageObjects(SessionList_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				case "create session":
					iActiveflag=VerifyActiveTab(TabOption);
					if (!iActiveflag) {
						flag=LeftClick._click(SessionListPageObjects(CreateSession_Tab));
						CommonUtility._sleepForGivenTime(1000);
					}
					else
						return true;
					break;
				default:
					flag=LeftClick._click(SessionListPageObjects(SessionList_Tab));
					CommonUtility._sleepForGivenTime(1000);
					break;
			}
		}
		else
			return false;
		
		iActiveflag=VerifyActiveTab(TabOption);
		if (iActiveflag) {
			return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- VerifyActiveTab<br>
	 * Description :- To verify Active Tab
	 * @throws IOException 
	 */
	public boolean VerifyActiveTab(String ActiveTab) throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(1000);
		String textSuccess=WebDriverMain._getTextFromElement(SessionListPageObjects(SessionsActive_Tab));
		if(textSuccess.toLowerCase().contains(ActiveTab.toLowerCase())){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Function Name :- Close_Alerts<br>
	 * Description :- To Close Alerts 
	 *
	 */
	public boolean Close_Alerts() throws IOException{
//		CommonUtility._scrollup();
//		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(CloseAlerts));
		for (WebElement AlertEle : lstAlertsRow) {
			if (WebDriverMain._isElementClickable(AlertEle)) {
				AlertEle.click();
			}
		}
		return true;
	}
	
	/**
	 * Function Name :- verifySessionSearchresultsDetails<br>
	 * Description :- To verify Session search results Details.
	 *
	 */
	public HashMap<String, String> SelectSessionList() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(SessionListPageObjects(SessionRowPresent));
		System.out.println("Session Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(SessionListPageObjects(SessionDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(SessionListPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-session-list//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/button");
						WebElement tsElm = WebDriverMain._getElementWithWait(objlocator);
						if (WebDriverMain._isElementClickable(tsElm)) {
							tsElm.click();
							CommonFunctions.PleaseWaitAndLoadingMessage();
							return MapDgOrgRec;
						}
						
					}
					
				}
			}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

}
