/**
 * Class Detail Page
 */
package com.pauir.PageDefinitions.classes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import com.aventstack.extentreports.Status;
import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.TextBox;
import webdriver.main.KendoGrid;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class ClassDetailPage {
	// Class Details page objects
	public static String ClassDetailspage_Title="xpath|.//pa-breadcrumb//div[contains(@class,'breadcrumb-title')]//h1";
	public static String btnEdit="xpath|.//a/span[contains(text(),'Edit')]";
	public static String Breadcrumb = "xpath|//pa-breadcrumb/ol";
	public static String Breadcrumb_Home = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Home')]";
	public static String Breadcrumb_ClassList = "xpath|//pa-breadcrumb/ol/li/a[contains(.,'Classes')]";
	public static String ClassHeader_Section="xpath|//pa-class-info//div[@class='card-header']";
	public static String Class_StudentList_Section="xpath|//kendo-tabstrip/ul/li[contains(.,'Student List')]";
	public static String Class_StudentList="xpath|//pa-class-info//kendo-grid//kendo-grid-list";
	public static String Class_Accomlink="xpath|//pa-class-info//button[contains( text(),'Accom')]";
	public static String Class_Accomclose="xpath|//pa-placeholder//div//div//span[@class ='k-icon k-i-x']";

	
	public static String LastUpdated="xpath|//pa-class-info//span[contains(text(),'Last Modified')]";
	public static String ClearTeacherlist="xpath|//kendo-multiselect[@formcontrolname='teachers']//kendo-taglist/ul/li//span[contains(@class,'k-i-close')]";
	
	// Student List page objects
	public static String StudentListpage_verification="xpath|.//h5[contains(text(),'Student Management')]";
	public static String StudentListpage_Title="xpath|.//pa-breadcrumb//h1[contains(@class,'breadcrumb-title')]";
	public static String btnAddStudent="xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Add Student')]";
	public static String btnRemoveStudent="xpath|//div[@role='tabpanel']//pa-grid-actions/button[contains(text(),'Remove')]";
	public static String btnDelete="xpath|.//button[contains(text(),'Delete')]";
	public static String StuRowPresent = "xpath|//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String StuDatagridHeaderRow = "xpath|//pa-class-info//kendo-grid//table/thead/tr/th";
	public static String StuList="xpath|.//kendo-grid//table/thead/tr[1]/th[1]";
	public static String SearchInputFilter = "xpath|//pa-class-info//pa-grid-search//input";
	public static String searchicon = "xpath|.//i[@class='fa fa-search']";
	public static String Kendogrid = "xpath|//kendo-grid//table";
	public static String NoRecords = "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr[contains(@class,'norecords')]";
	
	
	
	
	/**
	 * Function Name :- ClassDetailPageObjects<br>
	 * Description :- To set Class Details Page Objects locator.
	 * 
	 * @return By
	 */
	public By ClassDetailPageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Function Name :- verifyClassDetailsNavigation<br>
	 * Description :- To verify Class Detail Page Navigation.
	 *
	 */
	public boolean verifyClassDetailsNavigation() throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._getTextFromElement(ClassDetailPageObjects(ClassDetailspage_Title)).contains(Constants.ClassDetailPageTitle))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- EditButton_isVisible<br>
	 * Description :- To verify edit button is visible
	 *
	 */
	public boolean EditButton_isVisible() throws IOException{
		if (WebDriverMain._isElementVisible(ClassDetailPageObjects(btnEdit)))
			return true;
		else
			return false; 
	}
	/**
	 * Function Name :- EditButton_isEnabled<br>
	 * Description :- To verify Edit button is enabled
	 *
	 */
	public boolean EditButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(ClassDetailPageObjects(btnEdit));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit button.
	 *
	 */
	public boolean clickEditButton() throws IOException{
		CommonUtility._scrollup();
		CommonUtility._sleepForGivenTime(500);
		boolean flag=LeftClick._click(ClassDetailPageObjects(btnEdit));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}


	/**
	 * Function Name :- Verify_ClassHeader_Section<br>
	 * Description :- To verify Class Header section is visible
	 *
	 */
	public boolean Verify_ClassHeader_Section() throws IOException{
		if (WebDriverMain._isElementVisible(ClassDetailPageObjects(ClassHeader_Section)))
			return true;
		else
			return false; 
	}
	
	/**
	 * Function Name :- Verify_Class_StudentList<br>
	 * Description :- To verify Class Student List  is visible
	 *
	 */
	public boolean Verify_Class_StudentList() throws IOException{
		if (WebDriverMain._isElementVisible(ClassDetailPageObjects(Class_StudentList_Section))) {
			WebElement elmStudentlst = WebDriverMain._getElementWithWait(ClassDetailPageObjects(LastUpdated));
			if (WebDriverMain._isElementVisible(elmStudentlst)) {
				CommonUtility._scrollElement(elmStudentlst);
				return true;
			}
			return true;
		}
		else
			return false; 
		
		
	}
	
	
	

	
	/**
	 * Function Name :- verifyViewClassDetails<br>
	 * Description :- To verify the view  Class details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewClassDetails(HashMap<String,String> MapFilledField) throws IOException{
		boolean verifedFlag=true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            
	            if (sFieldLabel.length()>1) {
		          
		            if (sFieldLabel.toLowerCase().contains("teachers")) {
		            	sFieldLabel="Teacher(s)";
		            	String lines[] = sFieldValue.split("\\r?\\n");
		            	sFieldValue=lines[0];
		            }
		            //Class Name value is present without label
		            if (sFieldLabel.toLowerCase().contains("class name")) {
		            	sFieldLabel="";
		            }
		            objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//label[contains(text(),'"+sFieldLabel+"')]");
					boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if(sFieldValue.length()>1) { 
							
							MapDgStuRec.put(sFieldLabel, sFieldValue);
							if (sFieldLabel.length()<1) 
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//h2[contains(text(),'"+sFieldValue+"')]");
							else
								objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//span[contains(text(),'"+sFieldValue+"')]");
							boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								verifedFlag=false;
								UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
							}
						}
					}
	            }
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		
		if (verifedFlag)
			UMReporter.log(Status.PASS,"User have access to view the Class field value in Class details page :"+MapDgStuRec);
		return verifedFlag;
	}
	
	
	/**
	 * Function Name :- verifyClassName<br>
	 * Description :- To verify the Class name in  Class details Page 
	 * @throws IOException 
	 */	
	public boolean verifyClassName(String ClsName) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//h2[contains(text(),'"+ClsName+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- verifyLastUpdatedLabel<br>
	 * Description :- To verify the last updated on Class details page form.
	 *
	 */
	public String verifyLastUpdatedLabel() throws IOException{
		String LstUpdatedDate=null;
		if (WebDriverMain._isElementVisible(ClassDetailPageObjects(LastUpdated))) {
			LstUpdatedDate=WebDriverMain._getTextFromElement(ClassDetailPageObjects(LastUpdated));
			return LstUpdatedDate;
		}
		else
			return LstUpdatedDate;
	}
	
	
	/**
	 * Function Name :- verifyClassHeaderLabel<br>
	 * Description :- To verify the label on Class Header details page.
	 *
	 */
	public boolean verifyClassHeaderLabel(String labelmessage) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//label[contains(text(),'"+labelmessage+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- clickClassManagementBreadcrumb<br>
	 * Description :- To click Class Management Breadcrumb.
	 *
	 */
	public boolean clickClassManagementBreadcrumb() throws IOException{
		boolean flag=false;
		try {
			CommonUtility._scrollup();		
			WebDriverMain._isElementVisible(ClassDetailPageObjects(Breadcrumb_ClassList));
			flag=LeftClick._click(ClassDetailPageObjects(Breadcrumb_ClassList));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(1000);
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- Searchfill_StudName<br>
	 * Description :- To Fill Name Filter in Class details Page.
	 *
	 */
	public boolean Searchfill_StudName(String Studname) throws Exception {
		boolean flag = WebDriverMain._isElementVisible(ClassDetailPageObjects(SearchInputFilter));
		if (flag){
			flag =TextBox._setTextBox(ClassDetailPageObjects(SearchInputFilter), Studname);
			CommonUtility._sleepForGivenTime(200);
		}
		return flag;

	}
	
	/**
	 * Function Name :- ClearSearchText<br>
	 * Description :- To Clear Text in Class Details Page.
	 *
	 */
	public boolean ClearSearchText() throws Exception {
		boolean flag =TextBox._setTextBox(ClassDetailPageObjects(SearchInputFilter), "");
		CommonUtility._sleepForGivenTime(1000);
		return flag;
	}
	
	/**
	 * Function Name :- clicksearchicon<br>
	 * Description :- To clicks earch icon.
	 *
	 */
	public boolean clicksearchicon() throws IOException {
		
		boolean flag = WebDriverMain._isElementVisible(ClassDetailPageObjects(SearchInputFilter));
		if (flag) {
			flag=LeftClick._click(ClassDetailPageObjects(searchicon));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
	}
	
	
	

	/**
	 * Function Name :- getStudsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public HashMap<String, String> getStudsearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ClassDetailPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex == Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(ClassDetailPageObjects(StuDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}
	

	/**
	 * Function Name :- getStuColumnHeaderDetails<br>
	 * Description :- To get Students Col header Details.
	 *
	 */
	public List<String> getStuColumnHeaderDetails() throws IOException {
		List<String> MapDgOrgColHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuDatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgOrgColHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgOrgColHeader.add(sDGColmnName);
			}
		}
		return MapDgOrgColHeader;
	}
	
	/**
	 * Function Name :- getClassSearchresultsDetails<br>
	 * Description :- To get Class search results Details.
	 *
	 */
	public boolean hasStudlist() throws IOException {
		boolean flag=false;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ClassDetailPageObjects(NoRecords)))
				flag=true;	
		} 
		else
			flag=false;
		return flag;
	}
	/**
	 * Function Name :- verifyStusearchresultsDetails<br>
	 * Description :- To get Students search results Details.
	 *
	 */
	public List<String> verifyStusearchresultsDetails(int rowindex) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ClassDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					for (int iCol = 0; iCol < dataRec.size(); iCol++) {
						String sDGColmnName = lstheaderRow.get(iCol).getText();
						String sDGColmnValue = dataRec.get(iCol).getText();
						MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
					}
					MapDgOrgdetails.add(MapDgOrgRec.toString());
				}
				
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	/**
	 * Function Name :- verifyStuGridPagination<br>
	 * Description :- To verify Students grid pagination.
	 *
	 */
	public int verifyStuGridPagination() throws IOException {
		int maxpage=0;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		maxpage=KendoGrid.GetMaxPageNum();		
		System.out.println("Stu Page : " + maxpage);
		if (maxpage>29) {
			//Select Next Page
			KendoGrid.SelectNextPage();
			lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
			System.out.println("Stu Next Row Count : " + lstOrgrRow.size());
			//Select First Page
			KendoGrid.SelectFirstPage();
		}
		return maxpage;
	}
	
	
	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> verifyStusearchresultsCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ClassDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(ClassDetailPageObjects(NoRecords))){
				
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (rowindex >= Irow) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
						WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
						if (chbxele!=null) {
							objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
											+ Irow + "]/td");
							List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
							for (int iCol = 0; iCol < dataRec.size(); iCol++) {
								String sDGColmnName = lstheaderRow.get(iCol).getText();
								String sDGColmnValue = dataRec.get(iCol).getText();
								MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
							}
							if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.ClassFDStudID))) {
								String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.ClassFDStudID);
								MapDgOrgdetails.add(SearchOrg);
							}
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyStudSearchresultsDetailsfromtext<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public List<String> verifyStudSearchresultsDetailsfromtext(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ClassDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(ClassDetailPageObjects(NoRecords))){
			
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.ClassFDStudID))) {
							String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.ClassFDStudID);
							if (SearchOrg.toLowerCase().contains(SearchText.toLowerCase()))
								MapDgOrgdetails.add(SearchOrg);
						}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- verifyStudSearchresultsDetailsfromtext<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public List<String> verifyStudSearchresultsDetailsfromlist(String SearchText) throws IOException {
		By objlocator = null;
		List<String> MapDgOrgdetails = null;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			//if have Records
			if (!WebDriverMain._isElementVisible(ClassDetailPageObjects(NoRecords))){
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td[2]");
						WebElement dataRec = WebDriverMain._getElementWithWait(objlocator);
						if (dataRec!=null) {
							String sDGStuName = dataRec.getText().trim();
							if (SearchText.toLowerCase().contains(sDGStuName.toLowerCase()))
								MapDgOrgdetails.add(sDGStuName);
							//return MapDgOrgdetails;
						}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	

	/**
	 * Function Name :- SelectonStuCheckbox<br>
	 * Description :- To click Student Checkbox.
	 *
	 */
	public boolean SelectonStuCheckbox() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonFunctions.PleaseWaitAndLoadingMessage();
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- verifyStusearchresultsCheckbox<br>
	 * Description :- To verify Students search results checkbox Details.
	 *
	 */
	public List<String> SelectonStuCheckbox(int rowindex) throws IOException {
		By objlocator,objlocator1 = null;
		List<String> MapDgOrgdetails = null;
		List<HashMap<String, String>> MapDgdetails = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(ClassDetailPageObjects(StuDatagridHeaderRow));
		if (lstOrgrRow.size() >= 1) {
			MapDgOrgdetails=new ArrayList<String>();
			MapDgdetails=new ArrayList<HashMap<String, String>>();
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex >= Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
							+ Irow + "]/td/label[contains(@class,'k-checkbox-label')]");
					WebElement chbxele= WebDriverMain._getElementWithWait(objlocator1);
					if (chbxele!=null) {
						LeftClick.clickByWebElementJS(chbxele);
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						MapDgdetails.add(MapDgOrgRec);
						if (MapDgOrgRec.containsKey(Constants.FDStudName)&&(MapDgOrgRec.containsKey(Constants.ClassFDStudID))) {
							String SearchOrg=MapDgOrgRec.get(Constants.FDStudName)+" - "+MapDgOrgRec.get(Constants.ClassFDStudID);
							MapDgOrgdetails.add(SearchOrg);
						}
					}
				}
			}
			return MapDgOrgdetails;
		} else
			System.out.println("No record found");
		return MapDgOrgdetails;
	}
	
	/**
	 * Function Name :- clickonStudName<br>
	 * Description :- To click Student Name hyperlink.
	 *
	 */
	public boolean clickonStudName(String Studname) throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		for (WebElement UserRow : lstUserRow) {
			objlocator = CommonUtility._getObjectLocator(
					"xpath=//button[contains(text(),'" + Studname + "')]");
			WebElement tsElm = UserRow.findElement(objlocator);
			if (tsElm!=null) {
				if (WebDriverMain._isElementClickable(tsElm)) {
					tsElm.click();
					CommonFunctions.PleaseWaitAndLoadingMessage();
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- AddStudentsButton_isVisible<br>
	 * Description :- To verify AddStudents button is visible
	 */
	public boolean AddStudentsButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(ClassDetailPageObjects(btnAddStudent)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- AddStudentsButton_isEnabled<br>
	 * Description :- To verify AddStudents button is enabled
	 *
	 */
	public boolean AddStudentsButton_isEnabled() throws IOException{
		WebElement delete = WebDriverMain._getElementWithWait(ClassDetailPageObjects(btnAddStudent));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickAddStudentsButton<br>
	 * Description :- To click the Add Students button.
	 *
	 */
	public boolean clickAddStudentsButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(ClassDetailPageObjects(btnAddStudent));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- RemoveStudentsButton_isVisible<br>
	 * Description :- To verify Remove Students button is visible
	 */
	public boolean RemoveStudentsButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(ClassDetailPageObjects(btnRemoveStudent)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- RemoveStudentsButton_isEnabled<br>
	 * Description :- To verify Remove Students button is enabled
	 *
	 */
	public boolean RemoveStudentsButton_isEnabled() throws IOException{
		WebElement delete = WebDriverMain._getElementWithWait(ClassDetailPageObjects(btnRemoveStudent));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- clickRemoveStudentsButton<br>
	 * Description :- To click the Remove Students button.
	 *
	 */
	public boolean clickRemoveStudentsButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(ClassDetailPageObjects(btnRemoveStudent));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	
	/**
	 * Function Name :- deleteButton_isVisible<br>
	 * Description :- To verify delete button is visible
	 *
	 */
	public boolean deleteButton_isVisible() throws IOException{
	
		if (WebDriverMain._isElementVisible(ClassDetailPageObjects(btnDelete)))
			return true;
		else
			return false; 
	}
	
	
	/**
	 * Function Name :- deleteButton_isEnabled<br>
	 * Description :- To verify delete button is enabled
	 *
	 */
	public boolean deleteButton_isEnabled() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(ClassDetailPageObjects(btnDelete));
		String attributeText = delete.getAttribute("innerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
	}
	/**
	 * Function Name :- clicktoclearteacher<br>
	 * Description :- To clear the selected teacher from the class.
	 *
	 */
	public boolean clicktoclearteacher() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		boolean flag=LeftClick._click(ClassDetailPageObjects(ClearTeacherlist));
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return flag;
	}
	
	/**
	 * Function Name :- getStudsearchresultsDetails<br>
	 * Description :- To get Student search results Details.
	 *
	 */
	public HashMap<String, String> SelectClassStudentRecord() throws IOException {
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
		System.out.println("Stu Row Count : " + lstOrgrRow.size());
		if (lstOrgrRow.size() >= 1) {
			if (!WebDriverMain._isElementVisible(ClassDetailPageObjects(NoRecords))) {
				for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
					if (Irow == 1) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility
								._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
										+ Irow + "]/td");
						List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
						List<WebElement> lstheaderRow = WebDriverMain
								._getElementsWithWait(ClassDetailPageObjects(StuDatagridHeaderRow));
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["
								+ Irow + "]/td/button");
						WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
						if (tsElm!=null) {
							if (WebDriverMain._isElementClickable(tsElm)) {
								tsElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								return MapDgOrgRec;
							}
						}
						
							
						return MapDgOrgRec;
					}
				}
			}
		} else
			System.out.println("No record found");
		return MapDgOrgRec;
	}

/**
	 * Function Name :- Click Accom link
	 * Description :- To Click the Accom link on the class details page.
	 * 
	 * @return By
	 */
	public boolean clickaccomLink() throws Exception {
		boolean flag = WebDriverMain._isElementVisible(ClassDetailPageObjects(Class_Accomlink));
		if (flag) {
			flag=LeftClick._click(ClassDetailPageObjects(Class_Accomlink));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
}

	/**
	 * Function Name :- Close Accom dialog
	 * Description :- To Close the Accom dialog on the class details page.
	 * 
	 * @return By
	 */
	public boolean clickaccomClose() throws Exception {
		boolean flag = WebDriverMain._isElementVisible(ClassDetailPageObjects( Class_Accomclose));
		if (flag) {
			flag=LeftClick._click(ClassDetailPageObjects( Class_Accomclose));
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
		}
		return flag;
}
	
	/**
	 * Function Name :- SelectStudentWithAccomCapsule<br>
	 * Description :- To select Student Accom Capsule in search results Details.
	 *
	 */
	public HashMap<String, String> SelectStudentWithAccomCapsule(String ColName) throws IOException {
		By objlocator,objlocator1 = null;
		HashMap<String, String> MapDgOrgRec = null;
		//Get Column Name
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuDatagridHeaderRow));
		for (int iCol = 1; iCol < lstheaderRow.size(); iCol++) {
			String sDGColmnName = lstheaderRow.get(iCol).getText();
			//Match Column Name
			if (sDGColmnName.contains(ColName)) {
				System.out.println("Column Name : " + sDGColmnName);
				int datacounter= iCol+1;
				List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(ClassDetailPageObjects(StuRowPresent));
				System.out.println("Student Row Count : " + lstOrgrRow.size());
				if (lstOrgrRow.size() >= 1) {
					for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
						MapDgOrgRec = new HashMap<String, String>();
						objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]/button[contains(@class,'btn-capsule')]");
						
						if (WebDriverMain._isElementPresent(objlocator)) {
								//Select Matched Record
								objlocator1 = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td");
								List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator1);
								for (int iCol1 = 0; iCol1 < dataRec.size(); iCol1++) {
									String sDGColmnName1 = lstheaderRow.get(iCol1).getText();
									String sDGColmnValue1 = dataRec.get(iCol1).getText();
									MapDgOrgRec.put(sDGColmnName1, sDGColmnValue1);
								}
								//Click Capsule
								//objlocator = CommonUtility._getObjectLocator("xpath=//pa-class-info//kendo-grid//kendo-grid-list//table/tbody/tr["+ Irow + "]/td["+ datacounter + "]/button[contains(@class,'btn-capsule')]");
								WebElement tsElm =  WebDriverMain._getElementWithWait(objlocator);
								if (tsElm!=null) {
									if (WebDriverMain._isElementClickable(tsElm)) {
										tsElm.click();
										CommonFunctions.PleaseWaitAndLoadingMessage();
										return MapDgOrgRec;
									}
								}
							
						}	
					}
			return MapDgOrgRec;
		} else
			System.out.println("No record found");
	}			
	}
		return MapDgOrgRec;
	}

}



