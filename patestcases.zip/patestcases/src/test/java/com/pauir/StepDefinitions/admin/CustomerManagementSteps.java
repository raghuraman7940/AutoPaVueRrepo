
/**
 * Admin-Customer Management Step Definition 
 */

package com.pauir.StepDefinitions.admin;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.PageDefinitions.Admin.AdminHome;
import com.pauir.PageDefinitions.Admin.CustomerManagementPage;
import webdriver.main.UMReporter;

public class CustomerManagementSteps {
	
	//Initialize the class variable
	public static AdminHome adminhome;
	public static CustomerManagementPage customerlist;
	public static CommonFunctions common;
	public CustomerManagementSteps()throws IOException{
		//Initialize the Page object
		adminhome=new AdminHome();
		customerlist=new CustomerManagementPage();
	}
	@Then("^Verify Customer list page is displayed$")
	public void verify_whether_Customer_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Customer list page is displayed");
		//Verify the Form list page displayed
		if(customerlist.IsCustListTableExist())
			UMReporter.log(Status.PASS,"User is navigated to Customer list page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Given("^Verify the Customer Table fields$")
	public void verify_Customer_Table_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When :Verify the Customer Table fields");
		String Fieldname;
		List<String> NonVerified=null;
		List<String> MapDgOrgColHeader=customerlist.getCustomerColumnHeaderDetails();
		if (MapDgOrgColHeader!=null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Customer Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Customer Table fields are verified :"+MapDgOrgColHeader);
	}
	
	@Given("^Verify the Customer Table fields fields are sortable$")
	public void verify_Customer_Table_fields_Sortable(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"Then :Verify the Customer Table fields fields are sortable");
		String Fieldname;
		List<String> NotVerified=null;
		List<String> MapDgColValues=null;
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NotVerified=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			MapDgColValues=customerlist.verifyCustomerSearchresultsSorting(Fieldname);
			if (MapDgColValues==null) 
				NotVerified.add(Fieldname);
		}
		if (NotVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Customer Table fields are not Sortable :"+NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Customer Table fields are Sortable :"+list);
	}
	
	
	@Then("^User able to access the list of Customer$")
	public void verify_Customer_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the Customers ");
		List<String> MapDgOrgColHeader=customerlist.verifyCustomerSearchresultsDetails(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following Customer lists are accessed :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The records are not found in list");
	}
	
	@When("^User fill the Customer name search text (.*)$")
	public void Fill_Searchtext_Customer_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User fill the Customer name search text : "+SeachText);
		 boolean flag=customerlist.Searchfill_SearchText(SeachText);
		 if (flag)
			 UMReporter.log(Status.PASS, "Provided the Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to provide search text in input field");
	}
	
	@When("^User select the search icon in Customer list page$")
	public void Click_Searchicon_Customer_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon in Customer list page");
		boolean flag=customerlist.clicksearchicon();
	    if (flag)
	    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
		 else
		    UMReporter.log(Status.FAIL, "Unable to select search icon");
	}
	
	@Then("^verify the (.*) search results in the Customer list$")
	public void Verify_Searchtext_in_Customer_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the Customer list : "+SeachText);
		 List<String> MapDgOrgDet=customerlist.verifyCustomerSearchresultsDetailsfromtext(SeachText);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "The lists matches the SeachText :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The records are not found in list");
	
	}
	@Then("^Clear Search text field in Customer list page$")
	public void Clear_Searchtextfield_Class_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the Search text field");
		boolean flag=customerlist.ClearSearchText();
		
	    if (flag) {
	    	flag=customerlist.clicksearchicon();
	    	 UMReporter.log(Status.PASS, "Cleared the Search Text");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}
	
	@Then("^Select Home breadcrumb in Customer list page$")
	public void Select_Home_breadcrumb_organization_list() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Home> breadcrumb");
		customerlist.clickHomeBreadCrum();
	    if (adminhome.VerifyLoggedinAdminHomePage()) {
	    	 UMReporter.log(Status.PASS, "Selected the Home breadcrumb");
	    }
		 else {
			 adminhome.MenuOtion("home", "");
			  if (adminhome.VerifyLoggedinAdminHomePage()) 
			    	 UMReporter.log(Status.PASS, "Selected the Home Navigation");
			  else
				  UMReporter.log(Status.FAIL, "Unable to select Home breadcrumb");
		 }
	}
	
	
}
