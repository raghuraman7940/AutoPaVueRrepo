
package com.pauir.StepDefinitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.products.RejectedTestListPage;

public class RejectedTestSteps {

	public static Home home;
	public static RejectedTestListPage rejectedtestList;
	public static HashMap<String, String> MapFilledRejectedTestField = null;
	public static HashMap<String, String> MapSelectedRejectedTest = null;
	public static HashMap<String, String> MapSelectedStudent = null;
	public RejectedTestSteps() throws IOException {
		// Initialize the Page object
		home = new Home();
		rejectedtestList=new RejectedTestListPage();
	}

	@Given("Navigate to Rejected Tests page$")
	public void navigate_to_Rejected_Tests_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Rejected Tests page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL, "LogIn Failed.");
			throw new RuntimeException("Login fail!");
		}
		// Select Menu option Primary and secondary option
		home.MenuOtion("rejected tests", "");
		// Verify the Rejected Tests list page displayed
		if (rejectedtestList.IsRejectedTestListTableExist())
			UMReporter.log(Status.PASS, "User is navigated successfully to Rejected Tests page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@Given("Verify Rejected Test list page is displayed")
	public void verify_Rejected_Tests_list_page_is_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Rejected Test list page is displayed");
		// Verify the Courses list page displayed
		if (rejectedtestList.IsRejectedTestListTableExist()) {
			CommonFunctions.waitUntilLoadingSpinner(10);
			UMReporter.log(Status.PASS, "User is navigated to Rejected Test list page");
		} 
	}

	@Given("Verify the Rejected Test Table fields")
	public void verify_the_Rejected_Test_Table_fields(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "When :Verify the Rejected Test Table fields");
		String Fieldname;
		List<String> NonVerified = null;
		List<String> MapDgOrgColHeader = rejectedtestList.getRejectedTestColumnHeaderDetails();
		if (MapDgOrgColHeader != null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size() > 0)
			UMReporter.log(Status.FAIL,
					"The following expected Rejected Test Table fields are not exist in frontend :" + NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Rejected Test Table fields are verified :" + MapDgOrgColHeader);

	}

	@When("User fill the Rejected Test search text (.*)$")
	public void user_fill_the_RejectedTest_search_text_Teacher(String SeachText) throws Exception {
		if (SeachText.indexOf("$") >= 0)
			SeachText = CommonFunctions.getTestData(SeachText);
		UMReporter.log(Status.INFO, "Then : Rejected Test fill the search text : " + SeachText);
		System.out.println("Search text " + SeachText);
		UMReporter.log(Status.INFO, "Then : User fill the Rejected Test details search text : " + SeachText);
		boolean flag = rejectedtestList.Searchfill_SearchValue(SeachText);
		if (flag)
			UMReporter.log(Status.PASS, "Provided the Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to provide search text in input field");
	}

	@When("User select the search icon in Rejected Tests page")
	public void user_select_the_search_icon_in_RejectedTest_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon in Rejected Test list page");
		boolean flag = rejectedtestList.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "Clicked the Search Icon");
		else
			UMReporter.log(Status.FAIL, "Unable to select search icon");
	}

	@When("^User search the Rejected Test by search text (.*)$")
	public void User_Search_Searchtext_student_list(String SeachText) throws Exception {
//		UMReporter.log(Status.INFO, "Then : User find the student by search text : "+SeachText);
		boolean flag = false;
		if (MapFilledRejectedTestField != null) {
			String SeachText1 = null;
			if (MapFilledRejectedTestField.containsKey("First Name")) {
				SeachText1 = MapFilledRejectedTestField.get("First Name");
				flag = rejectedtestList.Searchfill_SearchValue(SeachText1);
				flag = rejectedtestList.clicksearchicon();
				flag = rejectedtestList.hasRejectedTestRecords();
				if (flag) {
					UMReporter.log(Status.INFO, "Then : User search the Rejected Test by search text : " + SeachText);
					UMReporter.log(Status.PASS, "The Search text :" + SeachText1);
				}
			}
		}
		if (!flag) {
			if (SeachText.indexOf("$") >= 0)
				SeachText = CommonFunctions.getTestData(SeachText);
			UMReporter.log(Status.INFO, "Then : User search the Rejected Test by search text : " + SeachText);
			flag = rejectedtestList.Searchfill_SearchValue(SeachText);
			flag = rejectedtestList.clicksearchicon();
			flag = rejectedtestList.hasRejectedTestRecords();
			if (flag)
				UMReporter.log(Status.PASS, "The Search text :" + SeachText);
			else
				UMReporter.log(Status.FAIL, "Unable to set search text in input field");
		}
	}

	@Then("verify the (.*) search results in the Rejected Test list")
	public void verify_the_RejectedTest_search_results_in_the_RejectedTest_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the Rejected Test list : " + SeachText);
		if (MapFilledRejectedTestField != null)
			if (MapFilledRejectedTestField.containsKey("First Name"))
				SeachText = MapFilledRejectedTestField.get("First Name");
		List<String> MapDgOrgDet = rejectedtestList.verifyRejectedTestSearchresultsDetailsfromtext(SeachText);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "The Rejected Test lists matches the SeachText :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The Rejected Test are not found in list");
	}

	@Then("Clear Rejected Test Search text field")
	public void clear_Search_text_field() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the Search text field");
		boolean flag = rejectedtestList.ClearSearchText();
		if (flag) {
			flag = rejectedtestList.clicksearchicon();
			UMReporter.log(Status.PASS, "Cleared the Search Text");
		} else
			UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}

	@Then("^Verify the list of Rejected Test displayed in Rejected Tests page$")
	public void verify_RejectedTest_list_is_access_CoursesPage() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the list of Rejected Test displayed in Rejected Tests page");
		List<String> MapDgColHeader = rejectedtestList.verifyRejectedTestResultsDetails(3);
		if (MapDgColHeader != null)
			UMReporter.log(Status.PASS, "The following Rejected Test lists are accessed :" + MapDgColHeader);
		else
			UMReporter.log(Status.FAIL, "The Rejected Test are not found in list");
	}
	
	@When("^User select (.*) Open Status Rejected Test record in Rejected Tests page$")
	public void Select_RejectedTest_checkbox_In_RejectedTest_list(String stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : User select "+stucount+" Open Status Rejected Test record in Rejected Tests page");
		int stucnt=1;
		if (rejectedtestList.hasRejectedTestRecords()) {
			if (CommonUtility.isNumeric(stucount))
				stucnt=Integer.parseInt(stucount);
			MapSelectedRejectedTest=rejectedtestList.SelectStudentCheckboxWithMatchedColValue(stucnt,"Status","Open");
		    if (MapSelectedRejectedTest!=null) {
		    	UMReporter.log(Status.PASS, "Selected the Open Status Rejected Test : "+MapSelectedRejectedTest);
		    }
		    else
		    	UMReporter.log(Status.SKIP, "The Rejected Test are not found in list");
		}
		else
	    	UMReporter.log(Status.SKIP, "The Rejected Test are not found in list");
		
	}
	
	@Then("^Verify Assign to Student options is visible in Rejected Tests page$")
	public void verify_AssigntoStudent_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Assign to Student options is visible in Rejected Tests page");
		boolean createenabled = rejectedtestList.AssigntoStudentButton_isVisible();
		if(createenabled)
			UMReporter.log(Status.PASS, "Assign to Student option is visible");
		else
			UMReporter.log(Status.FAIL, "Assign to Student option is not visible");
	}
	
	@Then("^Click on Assign to Student button$")
	public void click_AssigntoStudent_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Assign to Student button");
		if (rejectedtestList.AssigntoStudentButton_isVisible()) {
			rejectedtestList.clickAssigntoStudent();
		UMReporter.log(Status.PASS, "Selected the Reassign Test(s) button");
		}
		else
			UMReporter.log(Status.SKIP, "Reassign Test(s) option is not displayed");
	}
	
	@When("^Verify dialog title and content in Assign to Student pop-up$")
	public void Verify_title_message_AssigntoStudentPopUp_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Verify dialog title and content in Assign to Student pop-up");
		boolean flag=false;
		String RejTest="";
		String RejStudName="";
		if (rejectedtestList.Verify_AssigntoStudent_StudentList()) {
			if (MapSelectedRejectedTest != null) {
				if (MapSelectedRejectedTest.containsKey("Test"))
					RejTest = MapSelectedRejectedTest.get("Test");
				if (MapSelectedRejectedTest.containsKey("First Name"))
					RejStudName = MapSelectedRejectedTest.get("First Name");
			}
			// Verify the Confirm pop up
			flag=rejectedtestList.Verify_AssigntoStudentWindowTitle(Constants.AssigntoStudentPopupTitle);
			flag=rejectedtestList.Verify_AssigntoStudentWindowNotes(RejTest);
			flag=rejectedtestList.Verify_AssigntoStudentWindowContent(RejStudName);
			if (flag)
				UMReporter.log(Status.PASS, "Verified Assign to Student pop-up title and message : " +Constants.AssigntoStudentPopupTitle+RejTest+RejStudName);
		}
		else
	    	UMReporter.log(Status.SKIP, "The Student list popup are not found after Assign to Student");
	}
	
	@When("^User search the Student by (.*) search text in Assign to Student pop-up$")
	public void User_Search_Searchtext_student_list_AssigntoStudentPopUp(String SeachText) throws Exception {
		boolean flag = false;		
		if (rejectedtestList.Verify_AssigntoStudent_StudentList()) {
			if (SeachText.indexOf("$") >= 0)
				SeachText = CommonFunctions.getTestData(SeachText);
			UMReporter.log(Status.INFO, "Then : User search the Student by search text in Assign to Student pop-up : : " + SeachText);
			flag = rejectedtestList.Searchfill_ATSSearchValue(SeachText);
			flag = rejectedtestList.clickATSsearchicon();
			CommonFunctions.waitUntilLoadingSpinner(10);
			if (flag)
				UMReporter.log(Status.PASS, "The Search text :" + SeachText);
			else
				UMReporter.log(Status.FAIL, "Unable to set search text in input field");
		}
		else
	    	UMReporter.log(Status.SKIP, "The Student list popup are not found after Assign to Student");
	}
	
	@Then("^Verify the Student list displayed in Assign to Student pop-up$")
	public void verify_Student_list_is_access_AssigntoStudentPopUp() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Student list displayed in Assign to Student pop-up");
		if (rejectedtestList.Verify_AssigntoStudent_StudentList()) {
			CommonFunctions.waitUntilLoadingSpinner(10);
			List<String> MapDgColHeader = rejectedtestList.GetStudentListDetails(2);
			if (MapDgColHeader != null)
				UMReporter.log(Status.PASS, "The following Student lists are accessed :" + MapDgColHeader);
			else
				UMReporter.log(Status.FAIL, "The Student list are not found in list");
		}
		else
	    	UMReporter.log(Status.SKIP, "The Student list popup are not found after Assign to Student");
	}
	
	@When("^User select (.*) Student from Student List in Assign to Student pop-up$")
	public void Select_Student_checkbox_Student_Session_Test_AssigntoStudentPopUp(String stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : User select "+stucount+" Student from Student List in Assign to Student pop-up");
		int stucnt=1;
		if (rejectedtestList.Verify_AssigntoStudent_StudentList()) {
			if (CommonUtility.isNumeric(stucount))
				stucnt=Integer.parseInt(stucount);
			MapSelectedStudent=rejectedtestList.SelectonStuCheckbox(stucnt);
		    if (MapSelectedStudent!=null) {
		    	UMReporter.log(Status.PASS, "Selected the Student : "+MapSelectedStudent);
		    }
		    else
		    	UMReporter.log(Status.SKIP, "The Student records are not found in list");
		}
		else
	    	UMReporter.log(Status.SKIP, "The Student list popup are not found after Assign to Student");
		
	}

	@Then("^Click on Assign button$")
	public void click_Assign_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Assign button");
		if (rejectedtestList.Verify_AssigntoStudent_StudentList()) {
			if (MapSelectedStudent!=null) {
				if (rejectedtestList.AssignButton_isEnabled()) {
					rejectedtestList.clickAssignButton();
					rejectedtestList.waitForProgressbarVisible(20);
				UMReporter.log(Status.PASS, "Selected the Assign button");
				}
				else
					UMReporter.log(Status.SKIP, "Assign option is not displayed");
			}
			else {
				rejectedtestList.clickCancelButton();
				UMReporter.log(Status.SKIP, "No Student found in Student list and Selected Cancel");
			}
				
		}
		else
	    	UMReporter.log(Status.SKIP, "The Student list popup are not found after Assign to Student");
	}

	@Then("^Verify the success message displayed in Rejected Tests page as (.*)$")
	public void verify_success_message_displayed_in_StudentDetails_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Rejected Tests page as " + messages);
		String ActualMessage;
		if (MapSelectedStudent!=null) {
			ActualMessage = rejectedtestList.GetSuccessMessage();
			if ((ActualMessage!=null)&&(ActualMessage.length()>2)) {
				// Selectedcount
				if(ActualMessage.contains(messages))
					UMReporter.log(Status.PASS, "Verified the success message displayed in Rejected Tests page:" + messages);
				else if(ActualMessage.contains("ERROR"))
					UMReporter.log(Status.SKIP, "The error message displayed :" +ActualMessage);
				else
					UMReporter.log(Status.FAIL, "Not matched expected message :" + messages+"\n Actual :"+ActualMessage);
				rejectedtestList.Close_Alerts();
			}
			else
				UMReporter.log(Status.SKIP, "No Success message displayed" );
		}
		else
			UMReporter.log(Status.SKIP, "No Student found in Student list");
		
	}

}
