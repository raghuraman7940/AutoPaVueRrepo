
package com.pauir.StepDefinitions;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.PageDefinitions.products.CreateTestPage;
import com.pauir.PageDefinitions.products.FormPreviewPage;
import com.pauir.PageDefinitions.products.ProductsListPage;
import com.pauir.PageDefinitions.products.TestDetailsPage;
import com.pauir.PageDefinitions.products.TestListPage;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.util.Constants;
import io.cucumber.datatable.DataTable;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class productSteps {

	public static Home home;
	public static Login login;
	public static ProductsListPage productList;
	public static TestListPage testList;
	public static TestDetailsPage testDetails;
	public static FormPreviewPage formPreview;
	public static CreateTestPage createTest;
	public static HashMap<String, String> MapTestFields = null;
	public static HashMap<String, String> MapTestFilledFields = null;
	public static HashMap<String, String> MapFilledRejectedTestField = null;

	public productSteps() throws IOException {
		// Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home = new Home();
		productList = new ProductsListPage();
		testList = new TestListPage();
		testDetails = new TestDetailsPage();
		formPreview = new FormPreviewPage();
		createTest = new CreateTestPage();
	}

	@Given("Navigate to Tests page")
	public void navigate_to_Products_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Tests page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL, "LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		// Select Menu option Primary and secondary option
		home.MenuOtion("Tests", "");
		// Verify the Product list page displayed
		if (productList.verifyProductListPageNavigation())
			UMReporter.log(Status.PASS, "User is navigated successfully to Tests page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@Given("Verify Products list page is displayed on Tests page")
	public void verify_products_page_is_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Products list page is displayed on Tests page");
		// Verify the Product list page displayed
		if (productList.isProductListButtonsExist())
			UMReporter.log(Status.PASS, "User is navigated to Test list page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");

	}

	@Given("User select the (.*) product in Tests Page")
	public void user_click_on_the_product(String ProdName) throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the product in Tests Page :"+ProdName);
		if (ProdName.indexOf("$")>=0)
			ProdName=CommonFunctions.getTestData(ProdName);
		System.out.println("Test ::" + ProdName);
		boolean flag = productList.clickOnProductName(ProdName);
		if (flag)
			UMReporter.log(Status.PASS, "Click on Test: " + ProdName);
		else
			UMReporter.log(Status.FAIL, "Unable to find Test in Test List");
	}

	@Given("Verify Tests list for selected product in Test List Page")
	public void verify_Tests_list_page_is_displayed_for_product() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Tests list for selected product in Test List Page");
		// Verify the Tests list page displayed
		if (testList.IsTestListTableExist())
			UMReporter.log(Status.PASS, "User is navigated to Tests list page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");

	}

	@Given("User search the Test (.*) in Tests List page")
	public void user_search_the_Test_Test_in_Tests_List_page(String testName) throws Exception {
		// Get from Testdata
		if (testName.indexOf("$") >= 0)
			testName = CommonFunctions.getTestData(testName);

		System.out.println("Search text " + testName);
		UMReporter.log(Status.INFO, "Then : User fill the Test name search text : " + testName);
		boolean flag = testList.Searchfill_testName(testName);
		if (flag)
			UMReporter.log(Status.PASS, "Provided the Test Name :" + testName);
		else
			UMReporter.log(Status.FAIL, "Unable to provide Test Name in input field");

	}

	@Given("User select the search icon in Tests List page")
	public void user_select_the_search_icon_in_Tests_List_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon in Test list page");
		boolean flag = testList.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "Clicked the Search Icon");
		else
			UMReporter.log(Status.FAIL, "Unable to select search icon");
	}

	@Then("Verify the (.*) search results in the Test list")
	public void verify_the_SearchText_search_results_in_the_Test_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the Test list : " + SeachText);
		if (SeachText.indexOf("$")>=0)
			SeachText=CommonFunctions.getTestData(SeachText);
		if (MapTestFilledFields != null)
			if (MapTestFilledFields.containsKey("Test"))
				SeachText = MapTestFilledFields.get("Test");
		List<String> MapDgOrgDet = testList.verifyTestSearchresultsDetailsfromtext(SeachText);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "The Test lists matches the SeachText :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The Test are not found in list");
	}

	@Then("Verify the Test List fields are sortable")
	public void verify_the_Test_List_fields_are_sortable(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When :Verify the Test List fields are sortable in Tests List page");
		String Fieldname;
		List<String> NotVerified = null;
		List<String> MapDgColValues = null;
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NotVerified = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^") >= 0)
				Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
			MapDgColValues = testList.verifyTestSearchresultsSorting(Fieldname);
			if (MapDgColValues != null)
				if (MapDgColValues.size() < 1)
					NotVerified.add(Fieldname);
		}
		if (NotVerified.size() > 0)
			UMReporter.log(Status.FAIL, "The following expected Test Table fields are not Sortable :" + NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Test Table fields are Sortable :" + list);
	}

	@Then("Verify (.*) as Tests list page Subtitle is displayed")
	public void verify_Pearson_Interim_as_Tests_list_page_Subtitle_is_displayed(String subTitle) throws Exception {
		UMReporter.log(Status.INFO, "Given : Verify the Subtitle for Test List page ");

		if (subTitle.indexOf("$")>=0)
			subTitle=CommonFunctions.getTestData(subTitle);
		// Verify the Test list page displayed
		if (testList.verifyTestListPageNavigation())
			UMReporter.log(Status.PASS, "User is navigated successfully to Test List page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");

		String testSubTitle = testList.verifyTestListSubtitle();

		if (testSubTitle.equals(subTitle))
			UMReporter.log(Status.PASS, "SubTitle of the Test List Page is " + testSubTitle);
		else
			UMReporter.log(Status.FAIL, "Unable to display SubTitle for Test List Page");

	}
	
	@Given("Verify Create Test tab is displayed and able to click on it")
	public void verify_create_test_tab_is_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Create Test tab is displayed and able to click on it");
		// Verify Create Test tab is displayed and able to click on it
		boolean flag = createTest.createTestTabExistAndClikcOnit();
		if (flag)
			UMReporter.log(Status.PASS, "Create Test tab is displayed and able to click on it");
		else
			UMReporter.log(Status.FAIL, "Create Test tab is not displayed");

	}

	
	@Given("Verify local authoring app is displayed on create test page")
	public void verify_local_authoring_app_is_displayed_on_create_test_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify local authoring app is displayed on create test page");
		// Verify local authoring app is displayed on create test page
		boolean flag = createTest.verifyLocalAuthoringApp();
		if (flag)
			UMReporter.log(Status.PASS, "Local authoring app is displayed on create test page");
		else
			UMReporter.log(Status.FAIL, "Local authoring app is not displayed on create test page");

	}
	
	@When("^User select the Test from Test list Page$")
	public void user_clicks_on_Test_TestList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select the Test from Test list Page");
		// Get Course Search results by row number
		MapTestFields=testList.SelectTestRecord();
		if(MapTestFields!=null) {
			if (MapTestFields.containsKey("Test")) {
				String TestName=MapTestFields.get("Test");
				CommonUtility._sleepForGivenTime(2000);
				UMReporter.log(Status.PASS,"Selected the Test name "+TestName+" hyperlink in Test list");
			}else
				UMReporter.log(Status.FAIL,"The Test name hyperlink not found in Test list");
		}
		else
			UMReporter.log(Status.FAIL,"No records found in Test list");	
		
	}
	
	
	@Given("^Verify the fields in Test details page$")
	public void verify_Course_Header_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the fields in Test details page");
		String Fieldname;
		List<String> NonVerified=null;
		List<String> VerifiedField=null;
		if(testDetails.Verify_TestDetails_Section()){
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				
				System.out.println("Fieldname:" + Fieldname);
				if (!testDetails.verifyTestDetailsHeaderLabel(Fieldname))
					NonVerified.add(Fieldname);
				else
					VerifiedField.add(Fieldname);
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected Test Header fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following Test Header fields are verified :"+VerifiedField);
		}
		else
			UMReporter.log(Status.FAIL, "The Test Header fields not found");
	}
	
	
	@Then("^Verify the selected test field values in Test details page$")
	public void verify_Selected_test_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the selected test field values in Test details page");
		if (MapTestFields!=null) {
			//Verify the Test details page displayed
			testDetails.verifyViewTestDetails(MapTestFields);
		}
	    else
	    	UMReporter.log(Status.FAIL,"Test Details are not found");
	}
	
	
	@Then("^Verify Form list is displayed in Test details page$")
	public void verify_Form_list_page_is_displayed_Test_detailspage() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Form list is displayed in Test details page");
		//Verify the Form list page displayed
		if(testDetails.Verify_Test_FormList())
			UMReporter.log(Status.PASS,"Form List is displayed in Test details page");
	    else
	    	UMReporter.log(Status.FAIL,"Form List is not displayed");
	}
	
	
	@Given("^Verify the Form Table fields in Test details page$")
	public void verify_Form_Table_fields_Test_Details_Page(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"Then : Verify the Form Table fields in Test details page");
		String Fieldname;
		List<String> NonVerified=null;
		//boolean flag = true;
		List<String> MapDgStuColHeader=testDetails.getFormColumnHeaderDetails();
		if (MapDgStuColHeader.size()>0) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgStuColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Form Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Form Table fields are verified :"+MapDgStuColHeader);
			
	}
	
	
	@Given("^Verify the Form Table fields are sortable$")
	public void verify_Form_Table_fields_Sortable(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When :Verify the Form Table fields are sortable");
		String Fieldname;
		List<String> NotVerified = null;
		List<String> MapDgColValues = null;
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NotVerified = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^") >= 0)
				Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
			MapDgColValues = testDetails.verifyFormFieldSorting(Fieldname);
			if (MapDgColValues == null)
				NotVerified.add(Fieldname);

		}
		if (NotVerified.size() > 0)
			UMReporter.log(Status.FAIL, "The following expected Form Table fields are not Sortable :" + NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Form Table fields are Sortable :" + list);
	}

	
	@When("User search the form (.*) in Test details page by form code$")
	public void Fill_Searchtext_form_list_Testdetails_page_form_code(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search the form in Test details page by form code : "+SeachText);
		 boolean flag=testDetails.Searchfill(SeachText);
		 flag=testDetails.clicksearchicon();
		 if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@Then("^verify (.*) search results in test details page$")
	public void Verify_Searchtext_in_student_list_Course_Page(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in test details page : "+SeachText);
		 List<String> MapDgOrgDet=testDetails.verifyFormSearchresultsDetails(SeachText);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "The form lists matches the SeachText :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The forms are not found in list");
	
	}
	
	
	
	@When("User search the form (.*) in Test details page by test code$")
	public void Fill_Searchtext_form_list_Testdetails_page_test_code(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search the form in Test details page by test code : "+SeachText);
		 boolean flag=testDetails.Searchfill(SeachText);
		 flag=testDetails.clicksearchicon();
		 if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	
	@Then("^Clear the text from search box$")
	public void clear_text_from_search_box() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the text from search box");
		 boolean flag = testDetails.clearTextFromSearchBox();
		 if(flag)
		 {
			 UMReporter.log(Status.PASS, "Cleared the text from search box");
		 }
		 else
		 {
			 UMReporter.log(Status.FAIL, "Not able to clear the text from search box");
		 }
	}

	@Then("^User select the form from form list$")
	public void select_the_form_from_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the form from form list");
		// Get Course Search results by row number
				MapTestFields=testDetails.SelectFormRecord();
				if(MapTestFields!=null) {
					if (MapTestFields.containsKey("Form Code")) {
						String FormCode=MapTestFields.get("Form Code");
						CommonUtility._sleepForGivenTime(2000);
						UMReporter.log(Status.PASS,"Selected the Form code "+FormCode+" hyperlink in Form list");
					}else
						UMReporter.log(Status.FAIL,"The Form Code hyperlink not found in Form list");
				}
				else
					UMReporter.log(Status.FAIL,"No records found in Form list");	
	}
	
	@Then("^User navigates to form preview page$")
	public void navigates_to_form_previewer_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User navigates to form preview page");
		 boolean flag = formPreview.verifyFormPreviewerPage();
		 if(flag)
		 {
			 UMReporter.log(Status.PASS, "Navigates to form previewer page");
		 }
		 else
		 {
			 UMReporter.log(Status.FAIL, "Not able to navigate to form previewer page");
		 }
	}
	
	@Then("^Verify preview of test is loaded within an iFrame$")
	public void form_preview_loaded_within_iframe() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify preview of test is loaded within an iFrame");
		 boolean flag = formPreview.verifyiFrameLoaded();
		 if(flag)
		 {
			 UMReporter.log(Status.PASS, "Preview of test is loaded within an iFrame");
		 }
		 else
		 {
			 UMReporter.log(Status.FAIL, "Preview of test is not loaded within an iFrame");
		 }
	}

	@Then("^User navigates back to test details page$")
	public void navigates_back_to_test_details_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User navigates back to test details page");
		 boolean flag = formPreview.navigateToTestDetailsPage();
		 if(flag)
		 {
			 UMReporter.log(Status.PASS, "Navigate back to test details page");
		 }
		 else
		 {
			 UMReporter.log(Status.FAIL, "Not able to navigate back to test details page");
		 }
	}

}
