/**
 * Session- Step Definition 
 */
package com.pauir.StepDefinitions;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.WebElement;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.TestNav.TestNavHome;
import com.pauir.PageDefinitions.TestNav.SignIn;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.testDataTypes.Sessionfield;
import com.pauir.PageDefinitions.sessions.SessionDetailPage;
import com.pauir.PageDefinitions.sessions.SessionListPage;
import com.pauir.PageDefinitions.sessions.AddStudentsToSessionPage;
import com.pauir.PageDefinitions.sessions.CreateSessionPage;
import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

import com.pauir.common.util.CSV_Reader;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;

public class SessionSteps {

	// Initialize the class variable
	public static SessionListPage Sessionlist;
	public static SessionDetailPage sessiondetail;
	public static CreateSessionPage createsession;
	public static AddStudentsToSessionPage addstudentsession;
	public static CSV_Reader csvfreader;
	public static SignIn testnavlogin;
	public static TestNavHome testnavhome;
	public static HashMap<String, String> MapSessFields = null;
	public static HashMap<String, String> MapSessFilledFields = null;
	public static HashMap<String, String> MapSessEditedFields = null;
	public static HashMap<String, String> MapStudentFields = null;
	public static HashMap<String, String> MapStatusBarGraphValue = null;
	public static List<String> lstSelectedStudent = null;
	public static int iSelectedStudentCount = 0;
	public static List<String> lstSelectedStudent_SD = null;
	public static List<String> lstSelectedSess = null;
	public static String CurrentWinHnd = null;
	public static boolean LoggedinTestNavFlag = false;
	public static Set<String> testTicketsWinHnd = null;
	public static int printedTickets = 0;
	public static Login login;
	public static Home home;
	public static CommonFunctions common;
	public static String sSelectedSession = null;
	public static boolean SelectedViewAccomFlag = false;
	public static boolean SelectedViewIrregFlag = false;
	public static HashMap<String, String> MapStudAccomSelected = null;
	public static boolean IsStudMoved = false;
	public static boolean IsStudSelectedForDelete = false;
	public static boolean IsStudRemoved = false;
	public static File Exporttocsvfile =null;
	public static List<Map<String, String>> lstSectionCards=null;

	public SessionSteps() throws IOException {
		// Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home = new Home();
		Sessionlist = new SessionListPage();
		sessiondetail = new SessionDetailPage();
		createsession = new CreateSessionPage();
		addstudentsession = new AddStudentsToSessionPage();
		testnavlogin = new SignIn(WebDriverMain._getDriver());
		testnavhome = new TestNavHome();
		csvfreader = new CSV_Reader();
	}

	@Given("^Navigate to View Session page$")
	public void navigate_to_ViewSession_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to View Session page");
		boolean flag = home.VerifyLoggedinHomePage();
		;
		if (flag) {
			// Select Menu option Primary and secondary option
			home.MenuOtion("sessions", "pearson summative");
			// Verify the Session list page displayed
			if (Sessionlist.IsSessionListTableExist())
				UMReporter.log(Status.PASS, "User is navigated successfully to View Sessions page");
			else
				UMReporter.log(Status.FAIL, "Navigated to unexpected page");
		} else if (Sessionlist.IsSessionListTableExist()) {
			UMReporter.log(Status.PASS, "Navigated to View Sessions page");
		}
	}

	@Then("^Verify session list page is displayed$")
	public void verify_whether_Session_list_page_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify session list page is displayed");
		boolean flag = false;
		// Verify the Session list page displayed
		if (Sessionlist.IsSessionListTableExist())
			UMReporter.log(Status.PASS, "User is navigated to Session list page");
		else {
			flag = Sessionlist.SelectTabOption("Sessions List");
			if (Sessionlist.IsSessionListTableExist())
				UMReporter.log(Status.PASS, "User is navigated to Session list page");
			else
				UMReporter.log(Status.FAIL, "Navigated to unexpected page");
		}
	}

	@Then("^Verify session list is displayed in Test Sessions$")
	public void verify_Session_list_page_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify session list is displayed in Test Sessions");
		// Verify the Org list page displayed
		if (Sessionlist.IsSessionListTableExist())
			UMReporter.log(Status.PASS, "User is navigated to Test Session page");
		else {
			// Select Menu option Primary and secondary option
			home.MenuOtion("sessions", "pearson summative");
			// Verify the Session list page displayed
			if (Sessionlist.IsSessionListTableExist())
				UMReporter.log(Status.PASS, "User is navigated to Test Sessions page");
			else
				UMReporter.log(Status.FAIL, "Navigated to unexpected page");
		}
	}

	@Then("^Verify Create button is visible in Session list page$")
	public void verify_Create_button_is_visible_SessionList() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Create button is visible in Session list page");
		boolean deletevisible = Sessionlist.CreateButton_isVisible();
		if (deletevisible) {
			boolean deleteenabled = Sessionlist.CreateButton_isEnabled();
			if (deleteenabled)
				UMReporter.log(Status.PASS, "Create button is visible and enable");
			else
				UMReporter.log(Status.FAIL, "Create button is not enable");
		} else
			UMReporter.log(Status.FAIL, "Delete button is not visible");

	}

	@Given("^Verify the Session Table fields$")
	public void verify_Session_Table_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When :Verify the Session Table fields");
		String Fieldname;
		List<String> NonVerified = null;
		List<String> MapDgOrgColHeader = Sessionlist.getSessionColumnHeaderDetails();
		if (MapDgOrgColHeader != null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}

		if (NonVerified.size() > 0)
			UMReporter.log(Status.FAIL,
					"The following expected Session Table fields are not exist in frontend :" + NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Session Table fields are verified :" + MapDgOrgColHeader);
	}

	@Given("^Verify the Session Table fields fields are sortable$")
	public void verify_Session_Table_fields_Sortable(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When :Verify the Session Table fields fields are sortable");
		String Fieldname;
		List<String> NotVerified = null;
		List<String> MapDgColValues = null;
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NotVerified = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^") >= 0)
				Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
			MapDgColValues = Sessionlist.verifySessionSearchresultsSorting(Fieldname);
			if (MapDgColValues == null)
				NotVerified.add(Fieldname);

		}
		if (NotVerified.size() > 0)
			UMReporter.log(Status.FAIL, "The following expected Session Table fields are not Sortable :" + NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Session Table fields are Sortable :" + list);
	}

	@Then("^User able to access the list of all test sessions for the selected product type$")
	public void verify_Session_list_is_access() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User able to access the list of all test sessions for the selected product type");
		List<String> MapDgOrgColHeader = Sessionlist.verifySessionSearchresultsDetails(3);
		if (MapDgOrgColHeader != null)
			UMReporter.log(Status.PASS, "The following Session lists are accessed :" + MapDgOrgColHeader);
		else
			UMReporter.log(Status.FAIL, "The Session are not found in list");
	}

	@Then("^User able to access the list of test sessions in Sessions Page$")
	public void verify_Session_list_is_access_InSessions() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of test sessions in Sessions Page");
		List<String> MapDgOrgColHeader = Sessionlist.verifySessionSearchresultsDetails(3);
		if (MapDgOrgColHeader != null)
			UMReporter.log(Status.PASS, "The following Session lists are accessed :" + MapDgOrgColHeader);
		else
			UMReporter.log(Status.FAIL, "The Session are not found in list");
	}

	@Then("^Verify each session record contains a checkbox$")
	public void verify_Session_list_checkboxis_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify each session record contains a checkbox");
		List<String> MapDgOrgColHeader = Sessionlist.verifySessionSearchresultsCheckbox(3);
		if (MapDgOrgColHeader != null)
			UMReporter.log(Status.PASS, "The session lists contains checkbox :" + MapDgOrgColHeader);
		else
			UMReporter.log(Status.FAIL, "The session are not found in list");
	}

	@When("^Select the session record checkbox$")
	public void Select_Session_list_checkbox() throws Exception {
		UMReporter.log(Status.INFO, "When : Select the session record checkbox");
		boolean flag = Sessionlist.SelectonSessionCheckbox();
		if (flag)
			UMReporter.log(Status.PASS, "Selected the Session checkbox ");
		else
			UMReporter.log(Status.FAIL, "The Session are not found in list");
	}

	@When("^User fill the Session name search text (.*)$")
	public void Fill_Searchtext_session_list(String SeachText) throws Exception {

		// Get from Testdata
		if (SeachText.indexOf("$") >= 0)
			SeachText = CommonFunctions.getTestData(SeachText);

		System.out.println("Search text " + SeachText);
		UMReporter.log(Status.INFO, "Then : User fill the Session name search text : " + SeachText);
		boolean flag = Sessionlist.Searchfill_SessionName(SeachText);
		if (flag)
			UMReporter.log(Status.PASS, "Provided the Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to provide search text in input field");
	}

	@When("^User search the Session name search text (.*)$")
	public void Fill_CreatedSearchtext_Session_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User search the Session name search text : " + SeachText);
		boolean flag = false;
		if (MapSessFilledFields != null)
			if (MapSessFilledFields.containsKey("Session Name"))
				SeachText = MapSessFilledFields.get("Session Name");

		flag = Sessionlist.Searchfill_SessionName(SeachText);
		if (flag)
			UMReporter.log(Status.PASS, "The Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}

	@When("^User search (.*) Session in Test Sessions$")
	public void Search_Session_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User search Session in Test Sessions : " + SeachText);
		boolean flag = false;
		String SessionSearch = null;
		if (MapSessFilledFields != null) {
			if (MapSessFilledFields.containsKey("Session Name")) {
				SessionSearch = MapSessFilledFields.get("Session Name");
				flag = Sessionlist.Searchfill_SessionName(SessionSearch);
				flag = Sessionlist.clicksearchicon();
			}
			flag = Sessionlist.hasSessionlist();
		}
		if (!flag) {
			if (SeachText.indexOf("$") >= 0)
				SeachText = CommonFunctions.getTestData(SeachText);
			flag = Sessionlist.Searchfill_SessionName(SeachText);
			flag = Sessionlist.clicksearchicon();
			SessionSearch = SeachText;
		}
		if (flag)
			UMReporter.log(Status.PASS, "The Search text :" + SessionSearch);
		else
			UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}

	@When("^User select the search icon in Session list page$")
	public void Click_Searchicon_Session_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon in Session list page");
		boolean flag = Sessionlist.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "Clicked the Search Icon");
		else
			UMReporter.log(Status.FAIL, "Unable to select search icon");
	}

	@Then("^verify the (.*) search results in the Session list$")
	public void Verify_Searchtext_in_Session_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the Session list : " + SeachText);
		if (MapSessFilledFields != null)
			if (MapSessFilledFields.containsKey("Session Name"))
				SeachText = MapSessFilledFields.get("Session Name");
		List<String> MapDgOrgDet = Sessionlist.verifySessionSearchresultsDetailsfromtext(SeachText);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "The Session lists matches the SeachText :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The Sessions are not found in list");

	}

	@Then("^Clear Search text field in Session list page$")
	public void Clear_Searchtextfield_Class_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the Search text field");
		boolean flag = Sessionlist.ClearSearchText();

		if (flag) {
			flag = Sessionlist.clicksearchicon();
			UMReporter.log(Status.PASS, "Cleared the Search Text");
		} else
			UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}

	@When("^User select the session from session list$")
	public void user_clicks_on_First_IN_SessionList() throws Exception {
		UMReporter.log(Status.INFO, "When :User select the session from session list");
		boolean flag = false;
		HashMap<String, String> MapOrgField = null;
		// Get Seesion Search results by row number
		MapSessFields = Sessionlist.getSessionSearchresultsDetails(1);
		if (MapSessFields != null) {
			if (MapSessFields.containsKey("Session Name")) {
				String SessionName = MapSessFields.get("Session Name");
				sSelectedSession = SessionName;

				// Click on Session Name hyperlink on Org list page
				flag = Sessionlist.clickonSessionName(SessionName);
				// Check the Session selected
				if (flag) {
					CommonUtility._sleepForGivenTime(2000);
					UMReporter.log(Status.PASS,
							"Selected the Session name " + SessionName + " hyperlink in Session list");
				} else
					UMReporter.log(Status.FAIL, "The Session name " + SessionName + "  not found in Session list");
			}
		} else
			UMReporter.log(Status.FAIL, "No records found in Session list");

	}

	@When("^User select the (.*) mode test session from session list$")
	public void user_CBTSesstionclicks_on_First_IN_SessionList(String testMode) throws Exception {
		UMReporter.log(Status.INFO, "When :User select the " + testMode + " mode test session from session list");
		boolean flag = false;
		HashMap<String, String> MapOrgField = null;
		// Get Seesion Search results by row number
		MapSessFields = Sessionlist.SelectSessionbyMode(1, "Mode", testMode);
		if (MapSessFields != null) {
			if (MapSessFields.containsKey("Session Name")) {
				String SessionName = MapSessFields.get("Session Name");
				sSelectedSession = SessionName;
				// Check the Session selected
				UMReporter.log(Status.PASS, "Selected the Session name " + SessionName + " hyperlink in Session list");
			} else
				UMReporter.log(Status.PASS, "Selected the Session in Session list : " + MapSessFields);
		} else
			UMReporter.log(Status.FAIL, "No records found in Session list");

	}

	@Then("^Verify Session details page is displayed$")
	public void verify_whether_Session_details_page_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify Session details page is displayed");
		// Verify the Student Detail page displayed
		if (sessiondetail.verifySessionDetailsNavigation())
			UMReporter.log(Status.PASS, "User is navigated to Session details page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@Then("^Verify the Session name is displayed in Session details page$")
	public void verify_Student_name_in_details_page_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the Session name is displayed in Session details page");
		if (MapSessFields != null) {
			if (MapSessFields.containsKey("Session Name")) {
				String SessionName = MapSessFields.get("Session Name").trim();
				if (sessiondetail.verifySessionName(SessionName))
					UMReporter.log(Status.PASS, "Verified the Session name in Session details page :" + SessionName);
				else
					UMReporter.log(Status.SKIP, "The Session name not found in Session details page :" + SessionName);
			}
		} else
			UMReporter.log(Status.FAIL, "Session name not exist");
	}

	@Given("^Verify the Session information fields in Session details page$")
	public void verify_Students_info_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When : Verify the Session information fields in Session details page");
		String Fieldname, FieldValue;
		List<String> NonVerified = null;
		List<String> VerifiedField = null;
		sessiondetail.SessionInfoExpand("Yes");
		if (sessiondetail.Verify_Session_Info()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			VerifiedField = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!sessiondetail.verifySessionDetailsLabel(Fieldname))
					NonVerified.add(Fieldname);
				else {
					FieldValue = sessiondetail.GetValueforSessionLabel(Fieldname);
					VerifiedField.add(Fieldname + " = " + FieldValue);
				}
			}
			if (NonVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following expected Session Info fields are not exist in frontend :" + NonVerified);
			else
				UMReporter.log(Status.PASS, "The following verified Session Info fields with values :" + VerifiedField);
		} else
			UMReporter.log(Status.FAIL, "The Session Info fields are not found ");
	}

	@Then("^Verify the selected Session field values in Session details page$")
	public void verify_Selected_Student_details_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the selected Session field values in Session details page");
		if (MapSessFields != null) {
			// Expand the Session Info
			sessiondetail.SessionInfoExpand("Yes");
			// Verify the Session details page displayed
			sessiondetail.verifyViewSessionDetails(MapSessFields);
		} else
			UMReporter.log(Status.FAIL, "Session Details are not found");
	}

	@Then("^Select Test Sessions breadcrumb$")
	public void Select_Home_breadcrumb_organization_list() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select >Sessions breadcrumb");
		boolean flag = sessiondetail.clickViewSessionBreadcrumb();
		if (flag) {
			UMReporter.log(Status.PASS, "Selected the Sessions breadcrumb");
		} else
			UMReporter.log(Status.FAIL, "Unable to select Sessions breadcrumb");
	}

	@Given("^Navigate to Create Session page$")
	public void navigate_to_CreateSession_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Create Session page");
		boolean flag = home.VerifyLoggedinHomePage();
		;
		if (flag) {
			// Select Menu option Primary and secondary option
			home.MenuOtion("sessions", "pearson summative");
			// Verify the Create Session page displayed
			if (createsession.verifyCreateSessionPageNavigation())
				UMReporter.log(Status.PASS, "User is navigated successfully to Create Session page");
			else
				UMReporter.log(Status.FAIL, "Navigated to unexpected page");
		} else if (createsession.verifyCreateSessionPageNavigation()) {
			UMReporter.log(Status.PASS, "Navigated to Create Sessions page");
		}
	}

	@Then("^Verify Create session page is displayed$")
	public void verify_CreateSession_page_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify Create session page is displayed");
		// Verify the Org list page displayed
		if (createsession.verifyCreateSessionPageNavigation())
			UMReporter.log(Status.PASS, "User is navigated to Create Session page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@When("^User fill the Session information fields in Create Session page$")
	public void user_fills_all_fields_present_on_createStudent_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User fill the Session information fields in Create Session page");
		System.out.println("Session configured State :" + Constants.ORG_STATE);

		// Get fields from Configuration json file
		List<Sessionfield> fields = FileReaderManager.getInstance().getJsonReader()
				.getSessionfieldsbyState(Constants.ORG_STATE);

		if (fields != null) {
			// Fill All Input details from Configuration field
			MapSessFilledFields = createsession.FillSessionFields(fields, "all");
			String SessionName = MapSessFilledFields.get(Constants.SessionNameLabel);
			System.out.println("Filled Session fields: " + MapSessFilledFields);
			UMReporter.log(Status.PASS, "The Session field Input details :  " + MapSessFilledFields);
		} else
			UMReporter.log(Status.FAIL, "Unable to fill Session field details due to missing Config data for state : "
					+ Constants.ORG_STATE);
	}

	@Given("^User fill the Provided Session informations in Create Session page$")
	public void user_fills_provided_fields_present_CreateSessionPage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When : User fill the Provided Session informations in Create Session page");
		String Fieldname, FieldValue, FilledFieldValue = null;
		List<String> NonVerified = null;

		boolean isOnlineSession = false;
		String NonPaperSessionFields = "fields: start time end time su m tu w th f sa";

		// Get fields from Configuration json file
		List<Sessionfield> fields = FileReaderManager.getInstance().getJsonReader()
				.getSessionfieldsbyState(Constants.ORG_STATE);
		if (fields != null) {
			if (createsession.VerifyCreateSessionForm()) {
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified = new ArrayList<String>();
				MapSessFilledFields = new HashMap<String, String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");

					if (FieldValue.indexOf("$") >= 0)
						FieldValue = CommonFunctions.getTestData(FieldValue);

					System.out.println("isOnlineSession:" + isOnlineSession + " And "
							+ NonPaperSessionFields.contains(Fieldname.toLowerCase()));
					if ((NonPaperSessionFields.contains(Fieldname.toLowerCase()))) {
						if (isOnlineSession) {
							System.out.println("Filling Online fields:");
							System.out.println("FieldValue:" + Fieldname + " => " + FieldValue);
							Sessionfield field = FileReaderManager.getInstance().getJsonReader()
									.getSessionfieldbyLabel(fields, Fieldname);
							if (field != null) {
								FilledFieldValue = createsession.FillSessionField(field, FieldValue);
								if (FilledFieldValue == null)
									NonVerified.add(Fieldname);
								else
									MapSessFilledFields.put(Fieldname, FilledFieldValue);
							}
						}
					} else {

						if (Fieldname.equalsIgnoreCase("Testing Mode"))
							if (!FieldValue.equalsIgnoreCase("Paper"))
								isOnlineSession = true;

						System.out.println("FieldValue:" + Fieldname + " => " + FieldValue);
						Sessionfield field = FileReaderManager.getInstance().getJsonReader()
								.getSessionfieldbyLabel(fields, Fieldname);
						if (field != null) {
							FilledFieldValue = createsession.FillSessionField(field, FieldValue);
							if (FilledFieldValue == null)
								NonVerified.add(Fieldname);
							else
								MapSessFilledFields.put(Fieldname, FilledFieldValue);
						}

					}
				}
				if (NonVerified.size() > 0)
					UMReporter.log(Status.FAIL,
							"The following Session fields are unable to provide the input value :" + NonVerified);
				else
					UMReporter.log(Status.PASS,
							"The following Session fields provided the input values :" + MapSessFilledFields);
			}
		}
	}

	@When("^User check the fields control error on Create Session page$")
	public void user_check_userfields_on_createSession_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User check the fields control error on Create Session page");
		HashMap<String, String> MapFieldvalidation = new HashMap<String, String>();
		// Get fields from Configuration json file
		List<Sessionfield> fields = FileReaderManager.getInstance().getJsonReader()
				.getSessionfieldsbyState(Constants.ORG_STATE);
		// Checks the fields validation from Configuration field and user test data
		MapFieldvalidation = createsession.PageDataFieldValidation(fields, "required");
		UMReporter.log(Status.PASS,
				"Verified the following Input fields with Mandatory, Maximum, Minimum Length, Invalid data : "
						+ MapFieldvalidation);

	}

	@Then("^Verify Create Session button is enabled in Create Session page$")
	public void verify_createsession_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Create Session button is enabled in Create Session page");
		boolean btnCreatevisible = createsession.CreateSessionButton_isEnabled();
		if (btnCreatevisible)
			UMReporter.log(Status.PASS, "Create Session button is enabled");
		else
			UMReporter.log(Status.FAIL, "Create Session button is not enabled");

	}

	@Then("^Verify Create Session button is visible and disabled in Create Session page$")
	public void verify_createsession_button_is_visible_but_disabled() throws Exception {
		UMReporter.log(Status.INFO,
				"Then: Verify Create Session button is visible and disabled in Create Session page");
		boolean btnCreatevisible = createsession.CreateSessionButton_isVisible();
		if (btnCreatevisible) {
			boolean btnCreateenabled = createsession.CreateSessionButton_isEnabled();
			if (btnCreateenabled)
				UMReporter.log(Status.PASS, "Create Session button is visible and disabled");
			else
				UMReporter.log(Status.FAIL, "Create Session button is enabled without selecting record");
		} else
			UMReporter.log(Status.FAIL, "Create Session button is not visible");

	}

	@Then("^Click on Create Session button$")
	public void click_createsession_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Create Session button");
		boolean btnSelected = createsession.clickCreateSessionButton();
		if (btnSelected) {
			btnSelected = createsession.waitLoadingspinner_Invisible();
			if (btnSelected)
				UMReporter.log(Status.PASS, "Selected the Create Session button");
			else
				UMReporter.log(Status.FAIL, "Loading Spinner displays after Create Session button");
		} else
			UMReporter.log(Status.FAIL, "Unable to select the Create Session button");
	}

	@Then("^Verify the filled Session information in Session details page$")
	public void verify_filled_Student_details_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the filled Session information in Session details page");
		if (MapSessFilledFields != null) {
			// Verify the Student Detail page displayed
			if (sessiondetail.verifySessionDetailsNavigation())
				// Verify the Session details page displayed
				sessiondetail.verifyViewSessionDetails(MapSessFilledFields);
		} else
			UMReporter.log(Status.FAIL, "Session Details are not found");
	}

	@Then("^Verify Student list is displayed in Session details page$")
	public void verify_whether_Student_list_page_is_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Student list is displayed in Session details page");
		// Verify the Stu list page displayed
		if (sessiondetail.Verify_Session_StudentList()) {
			CommonFunctions.waitUntilLoadingSpinner(10);
			UMReporter.log(Status.PASS, "Student List is displayed in Session details page");
		}
		else
			UMReporter.log(Status.FAIL, "Student List is not displayed");
	}

	@Given("^Verify the Student Table fields in Session details page$")
	public void verify_Students_Table_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the Student Table fields in Session details page");
		String Fieldname;
		List<String> NonVerified = null;
		boolean flag = true;
		List<String> MapDgStuColHeader = sessiondetail.getStuColumnHeaderDetails();
		if (MapDgStuColHeader.size() > 0) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);

				if (!MapDgStuColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size() > 0)
			UMReporter.log(Status.FAIL,
					"The following expected Students Table fields are not exist in frontend :" + NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Students Table fields are verified :" + MapDgStuColHeader);

	}

	@Given("^Verify the Student Table fields fields are sortable in Session details page$")
	public void verify_Student_Table_fields_Sortable(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,
				"When :Verify the Student Table fields fields are sortable in Session details page");
		String Fieldname;
		List<String> NotVerified = null;
		List<String> MapDgColValues = null;
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NotVerified = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^") >= 0)
				Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
			MapDgColValues = sessiondetail.verifyStudentSearchresultsSorting(Fieldname);
			if (MapDgColValues != null)
				if (MapDgColValues.size() < 1)
					NotVerified.add(Fieldname);

		}
		if (NotVerified.size() > 0)
			UMReporter.log(Status.FAIL,
					"The following expected Session Student Table fields are not Sortable :" + NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Session Student Table fields are Sortable :" + list);
	}

	@Then("^User able to access the list of Student in Session details page$")
	public void verify_Students_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of Student in Session details page");
		List<String> MapDgStuColHeader = sessiondetail.verifyStusearchresultsDetails(3);
		if (MapDgStuColHeader != null)
			UMReporter.log(Status.PASS,
					"The following students lists are accessed in Session details Page :" + MapDgStuColHeader);
		else
			UMReporter.log(Status.FAIL, "The students are not found in list");
	}

	@Then("^Verify each Student record contains a checkbox in Session details page$")
	public void verify_student_list_checkboxis_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify each Student record contains a checkbox in Session details page");
		List<String> MapDgOrgColHeader = sessiondetail.verifyStusearchresultsCheckbox(3);
		if (MapDgOrgColHeader != null)
			UMReporter.log(Status.PASS, "The student lists contains checkbox :" + MapDgOrgColHeader);
		else
			UMReporter.log(Status.FAIL, "The student are not found in list");
	}

	@When("^Select the Student record checkbox in Session details page$")
	public void Select_student_list_checkbox() throws Exception {
		UMReporter.log(Status.INFO, "When : Select the student record checkbox");
		boolean flag = sessiondetail.SelectonStuCheckbox();
		if (flag)
			UMReporter.log(Status.PASS, "Selected the student checkbox ");
		else
			UMReporter.log(Status.FAIL, "The students are not found in list");
	}

	@Then("^Verify the pagination in Student datagrid in Session details page$")
	public void Verify_student_list_Paginations() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the pagination in Student datagrid in Session details page");
		int maxpage = sessiondetail.verifyStuGridPagination();
		if (maxpage > 1)
			UMReporter.log(Status.PASS, "The students lists pagination are upto max pages :" + maxpage);
		else if (maxpage == 1)
			UMReporter.log(Status.PASS, "The students list contains one page only.");
		else
			UMReporter.log(Status.FAIL, "The students list pagination fails.");
	}

	@When("^User search the student (.*) in Session details page$")
	public void Fill_Searchtext_student_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search the student in Session details page : " + SeachText);
		boolean flag = sessiondetail.Searchfill_StudName(SeachText);
		if (flag)
			UMReporter.log(Status.PASS, "The Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}

	@When("^User select the search icon in Session details page$")
	public void Click_Searchicon_student_list() throws Exception {
		UMReporter.log(Status.INFO, "When : User select the search icon in Session details page");
		boolean flag = sessiondetail.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "Clicked the Search Icon");
		else
			UMReporter.log(Status.FAIL, "Unable to select search icon");
	}

	@Then("^verify the (.*) search Student results in Session details page$")
	public void Verify_Searchtext_in_student_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search Student results in Session details paget : " + SeachText);
		List<String> MapDgOrgDet = sessiondetail.verifyStudSearchresultsDetailsfromtext(SeachText);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "The Student lists matches the SeachText :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The Students are not found in list");

	}

	@Then("^Clear Search text field in Session details page$")
	public void Clear_Searchtextfield_student_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear Search text field in Session details page");
		boolean flag = sessiondetail.ClearSearchText();
		if (flag) {
			flag = sessiondetail.clicksearchicon();
			UMReporter.log(Status.PASS, "Cleared the Search Text");
		} else
			UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}

	@When("^Click on Add Students button in Session details page$")
	public void Click_AddStudents_button_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Add Students button in Session details page");
		boolean isbtnclicked = sessiondetail.clickAddStudentsButton();
		if (isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Add Students button");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Add Students button");

	}

	@When("^Verify Add Students option is visible in Session details page$")
	public void Verify_AddStudents_button_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Verify Add Students options is visible in Session details page");
		boolean isbtnvisible = sessiondetail.AddStudentsButton_isVisible();
		if (isbtnvisible)
			UMReporter.log(Status.PASS, "Add Students options is visible");
		else
			UMReporter.log(Status.FAIL, "Add Students options is not visible");

	}

	@Then("^Verify Add Students to Session page is displayed$")
	public void verify_AddStudentsto_Session_page_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then :Verify Add Students to Session page is displayed");
		// Verify the Add Students to Session page displayed
		if (addstudentsession.verifyAddStudentsToSessionNavigation()) {
			addstudentsession.hasStudentlist();
			UMReporter.log(Status.PASS, "User is navigated to Add Students to Session page");
		} else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@Then("^Verify Student list is displayed in Add Students to Session page$")
	public void verify_whether_Student_list_page_is_displayed_in_AddStudent_Session() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify Student list is displayed in Add Students to Session page");
		// Verify the Stu list page displayed
		if (addstudentsession.Verify_Session_StudentList())
			UMReporter.log(Status.PASS, "Student List is displayed in Add Students to Session page");
		else
			UMReporter.log(Status.FAIL, "Student List is not displayed");
	}

	@Given("^Verify the Student Table fields in Add Students to Session page$")
	public void verify_Students_Table_fields_AddStudentsto_Session_page(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the Student Table fields in Add Students to Session page");
		String Fieldname;
		List<String> NonVerified = null;
		boolean flag = true;
		List<String> MapDgStuColHeader = addstudentsession.getStuColumnHeaderDetails();
		if (MapDgStuColHeader.size() > 0) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgStuColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size() > 0)
			UMReporter.log(Status.FAIL,
					"The following expected Students Table fields are not exist in frontend :" + NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Students Table fields are verified :" + MapDgStuColHeader);

	}

	@Given("^Verify the Student Table fields fields are sortable in Add Students to Session page$")
	public void verify_Student_Table_fields_Sortable_AddStudentsto_Session_page(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,
				"When :Verify the Student Table fields fields are sortable in Add Students to Session page");
		String Fieldname;
		List<String> NotVerified = null;
		List<String> MapDgColValues = null;
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NotVerified = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^") >= 0)
				Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
			MapDgColValues = addstudentsession.verifyStudentSearchresultsSorting(Fieldname);
			if (MapDgColValues != null)
				if (MapDgColValues.size() < 1)
					NotVerified.add(Fieldname);

		}
		if (NotVerified.size() > 0)
			UMReporter.log(Status.FAIL,
					"The following expected Session Student Table fields are not Sortable :" + NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Session Student Table fields are Sortable :" + list);
	}

	@Then("^User able to access the list of Student in Add Students to Session page$")
	public void verify_Students_list_is_access_AddStudentsto_Session_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of Student in Add Students to Session page");
		List<String> MapDgStuColHeader = addstudentsession.verifyStusearchresultsDetails(3);
		if (MapDgStuColHeader != null)
			UMReporter.log(Status.PASS,
					"The following students lists are accessed in Session details Page :" + MapDgStuColHeader);
		else
			UMReporter.log(Status.FAIL, "The students are not found in list");
	}

	@Then("^Verify each Student record contains a checkbox in Add Students to Session page$")
	public void verify_student_list_checkboxis_displayed_AddStudentsto_Session() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify each Student record contains a checkbox in Add Students to Session page");
		List<String> MapDgOrgColHeader = addstudentsession.verifyStusearchresultsCheckbox(3);
		if (MapDgOrgColHeader != null)
			UMReporter.log(Status.PASS, "The student lists contains checkbox :" + MapDgOrgColHeader);
		else
			UMReporter.log(Status.FAIL, "The student are not found in list");
	}

	@Then("^Verify Add button is enabled in Create Session page$")
	public void verify_Add_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Create Session button is enabled in Create Session page");
		boolean btnCreatevisible = addstudentsession.AddButton_isEnabled();
		if (btnCreatevisible)
			UMReporter.log(Status.PASS, "Add button is enabled");
		else
			UMReporter.log(Status.FAIL, "Add button is not enabled");
	}

	@Then("^Verify Add button is visible and disabled in Add Students to Session page$")
	public void verify_Add_button_is_visible_but_disabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Add button is visible and disabled in Add Students to Session page");
		boolean btnAddvisible = addstudentsession.AddButton_isVisible();
		if (btnAddvisible) {
			boolean btnAddenabled = addstudentsession.AddButton_isEnabled();
			if (btnAddenabled)
				UMReporter.log(Status.PASS, "Add button is visible and disabled");
			else
				UMReporter.log(Status.FAIL, "Add button is enabled without selecting record");
		} else
			UMReporter.log(Status.FAIL, "Add button is not visible");

	}

	@When("^Select the (.*) Students in Add Students to Session page$")
	public void Select_student_list_checkbox_AddStudentsto_Session(String Stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the " + Stucount + " Students in Add Students to Session page");
		iSelectedStudentCount=0;
		int stucnt = 1;
		if (CommonUtility.isNumeric(Stucount))
			stucnt = Integer.parseInt(Stucount);
		lstSelectedStudent = addstudentsession.SelectonStuCheckbox(stucnt);
		iSelectedStudentCount = lstSelectedStudent.size();
		if (lstSelectedStudent.size() > 0)
			UMReporter.log(Status.PASS, "Selected the student checkbox " + lstSelectedStudent);
		else
			UMReporter.log(Status.FAIL, "The students are not found in list");
	}

	@Then("^Verify the pagination in Student datagrid in Add Students to Session page$")
	public void Verify_student_list_Paginations_AddStudentsto_Session() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the pagination in Student datagrid in Add Students to Session page");
		int maxpage = addstudentsession.verifyStuGridPagination();
		if (maxpage > 1)
			UMReporter.log(Status.PASS, "The students lists pagination are upto max pages :" + maxpage);
		else if (maxpage == 1)
			UMReporter.log(Status.PASS, "The students list contains one page only.");
		else
			UMReporter.log(Status.FAIL, "The students list pagination fails.");
	}

	@When("^User search the student (.*) in Add Students to Session page$")
	public void Fill_Searchtext_student_list_AddStudentsto_Session(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search the student in Add Students to Session page : " + SeachText);
		boolean flag = addstudentsession.Searchfill_StudName(SeachText);
		if (flag)
			UMReporter.log(Status.PASS, "The Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}

	@When("^User select the search icon in Add Students to Session page$")
	public void Click_Searchicon_student_list_AddStudentsto_Session() throws Exception {
		UMReporter.log(Status.INFO, "When : User select the search icon in Add Students to Session page");
		boolean flag = addstudentsession.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "Clicked the Search Icon");
		else
			UMReporter.log(Status.FAIL, "Unable to select search icon");
	}

	@Then("^verify the (.*) search Student results in Add Students to Session page$")
	public void Verify_Searchtext_in_student_list_AddStudentsto_Session(String SeachText) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : verify the search Student results in Add Students to Session paget : " + SeachText);
		List<String> MapDgOrgDet = addstudentsession.verifyStudSearchresultsDetailsfromtext(SeachText);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "The Student lists matches the SeachText :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The Students are not found in list");

	}

	@Then("^Clear Search text field in Add Students to Session page$")
	public void Clear_Searchtextfield_student_list_AddStudentsto_Session() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear Search text field in Add Students to Session page");
		boolean flag = addstudentsession.ClearSearchText();
		if (flag) {
			flag = addstudentsession.clicksearchicon();
			UMReporter.log(Status.PASS, "Cleared the Search Text");
		} else
			UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}

	@When("^Verify the selected student count displays as (.*) Students Selected$")
	public void Verify_Selected_StuCount_session_list(String Stucount) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the selected student count displays as " + Stucount + " Students Selected");
		int stucnt = 0;
		boolean flag = false;
		if (CommonUtility.isNumeric(Stucount))
			stucnt = Integer.parseInt(Stucount);
		flag = addstudentsession.Verify_SelectedStudentCount(Stucount);
		if (flag)
			UMReporter.log(Status.PASS, "The selected student count display as :" + Stucount);
		else {
			flag = addstudentsession.Verify_SelectedStudentCount(String.valueOf(iSelectedStudentCount));
			if (flag)
				UMReporter.log(Status.PASS, "The selected student count display as :" + iSelectedStudentCount);
			else
				UMReporter.log(Status.FAIL, "The selected student count mistached the actual");
		}
	}

	@When("^Click on Cancel button in Add Students to Session page$")
	public void Click_Cancel_button_in_AddStudentsto_Session() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Cancel button in Add Students to Session page");
		boolean isbtnclicked = addstudentsession.clickCancelButton();
		if (isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Cancel button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Cancel button");

	}

	@When("^Click on Add button in Add Students to Session page$")
	public void Click_Add_button_in_AddStudentsto_Session() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Add button in Add Students to Session page");
		boolean isbtnclicked = addstudentsession.clickAddButton();
		if (isbtnclicked) {
			UMReporter.log(Status.PASS, "Selected the Add button");
			CommonUtility._sleepForGivenTime(7000);
			int count = 0;
			while ((addstudentsession.Verify_Progressbar_Visible()) && (count < 15)) {
				CommonUtility._sleepForGivenTime(1000);
				count = count + 1;
			}
		} else
			UMReporter.log(Status.FAIL, "Unable to click the Add button");

		// Select Cancel if Still Add Students page displayed
		if (addstudentsession.verifyAddStudentsToSessionNavigation()) {
			String ActFeMessage = addstudentsession.GetFEMessage();
			if (ActFeMessage != null)
				UMReporter.log(Status.FAIL, "Error message displayed after Add button :" + ActFeMessage);
			addstudentsession.clickCancelButton();
		}

	}

	@Then("^Verify the failure message displayed in Add Students to Session as (.*)$")
	public void verify_error_message_gets_displayed_on_AddStudentsto_Session_page(String messages) throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the error message displayed in Add Students to Session as " + messages);
		boolean flag;
		if (messages.contains("<X>"))
			if (iSelectedStudentCount != 0) // Studentcount
				messages = messages.replace("<X>", String.valueOf(iSelectedStudentCount));
		flag = addstudentsession.verifyAlertMessage(messages);
		if (flag)
			UMReporter.log(Status.PASS,
					"Verified the error message displayed in Add Students to Session page:" + messages);
		else
			UMReporter.log(Status.FAIL, "The error message is not matched with expected :" + messages);
	}

	@Then("^Verify the success message displayed in Session details page as (.*)$")
	public void verify_success_message_gets_displayed_on_AddStudentsto_Session_page(String messages)
			throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the success message displayed in Session details page as " + messages);
		boolean flag;
		if (sessiondetail.verifySuccessMessageVisible()) {
			if (messages.contains("<X>"))
				if (iSelectedStudentCount != 0) // Studentcount
					messages = messages.replace("<X>", String.valueOf(iSelectedStudentCount));
			if (messages.contains("<sessionname>"))
				if (sSelectedSession != null) // Session Name
					messages = messages.replace("<sessionname>", sSelectedSession);
			System.out.println(" Success message : " + messages);
			flag = sessiondetail.verifySuccessMessage(messages);
			if (flag) {
				UMReporter.log(Status.PASS,
						"Verified the success message displayed in Session details page:" + messages);
				sessiondetail.Close_Alerts();
			} else
				UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
		} else
			UMReporter.log(Status.SKIP, "The success message is not displayed");

	}

	@Then("^Verify the Selected Student details in Student list in Session details page$")
	public void verify_Selected_Student_in_Students_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Selected Student details in Student list in Session details page");
		List<String> NotVerified = null;
		List<String> Verified = null;
		List<String> MapDgStuColHeader = null;
		if (lstSelectedStudent != null) {
			NotVerified = new ArrayList<String>();
			Verified = new ArrayList<String>();
			for (String stu : lstSelectedStudent) {
				String strArrObjLocs[] = CommonUtility._split(stu, ",");
				if (strArrObjLocs.length == 2) {
					sessiondetail.Searchfill_StudName(strArrObjLocs[0].trim());
					sessiondetail.clicksearchicon();
				}
				MapDgStuColHeader = sessiondetail.verifyStudSearchresultsDetailsfromlist(stu);
				if (MapDgStuColHeader == null)
					NotVerified.add(stu);
				else
					Verified.add(MapDgStuColHeader.toString());
			}
			if (NotVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following students lists are not verified in Session details Page :" + NotVerified);
			else
				UMReporter.log(Status.PASS,
						"The following students lists are verified in Session details Page :" + Verified);
		} else
			UMReporter.log(Status.FAIL, "The students are not found in list");

	}

	@Then("Verify the page automatically refresh every 2 minutes to retrieve the updated testing status to be ready in Session details page$")
	public void verify_Selected_Student_Status_Updted_in_Students_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the page automatically refresh every 2 minutes to retrieve the updated testing status to be ready in Session details page");
		List<String> NotVerified = null;
		List<String> Verified = null;
		HashMap<String, String> MapStuStatus = new HashMap<String, String>();
		String StuName = null;
		String StuStatus = null;
		if (lstSelectedStudent != null) {
			NotVerified = new ArrayList<String>();
			Verified = new ArrayList<String>();
			for (String stu : lstSelectedStudent) {
				String strArrObjLocs[] = CommonUtility._split(stu, ",");
				if (strArrObjLocs.length == 2) {
					sessiondetail.Searchfill_StudName(strArrObjLocs[0].trim());
					sessiondetail.clicksearchicon();
				}
				StuStatus = sessiondetail.getStudStatusfromlist(1, Constants.FDStatus, stu);
				if (StuStatus != null)
					MapStuStatus.put(stu, StuStatus);
			}
			sessiondetail.waitForautorefresh(120);

			if (MapStuStatus != null) {
				for (Map.Entry<String, String> entry : MapStuStatus.entrySet()) {
					StuName = entry.getKey();
					StuStatus = entry.getValue();

					String strArrObjLocs[] = CommonUtility._split(StuName, ",");
					if (strArrObjLocs.length == 2) {
						sessiondetail.Searchfill_StudName(strArrObjLocs[0].trim());
						sessiondetail.clicksearchicon();
					}
					String StuUpdateStatus = sessiondetail.getStudStatusfromlist(1, Constants.FDStatus, StuName);

					if (StuUpdateStatus.equalsIgnoreCase(StuStatus))
						NotVerified.add(StuName + " = " + StuStatus + " -> " + StuUpdateStatus);
					else
						Verified.add(StuName + " = " + StuStatus + " -> " + StuUpdateStatus);

				}
			}

			if (NotVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The students lists are not updated the Student testing status in Session details Page :"
								+ NotVerified);
			else
				UMReporter.log(Status.PASS,
						"The students lists are updatded the Student testing status in Session details Page :"
								+ Verified);
		} else
			UMReporter.log(Status.FAIL, "The students are not found in list");

	}

	@Then("Select the refresh button in Session details page$")
	public void Select_Refresh_to_Status_Updted_in_Students_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Select the refresh button in Session details page");
		boolean flag = sessiondetail.clickRefreshButton();
		if (flag)
			UMReporter.log(Status.PASS, "Selected the refresh button ");
		else
			UMReporter.log(Status.FAIL, "Unable to select Refresh button ");

	}

	@Then("Verify the refresh button to retrieve the testing status in Session details page$")
	public void verify_Refresh_Selected_Student_Status_Updted_in_Students_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the refresh button to retrieve the testing status in Session details page");
		boolean flag = sessiondetail.clickRefreshButton();
		if (flag) {
			// Verify the updated status
			HashMap<String, String> MapDgSessStuRecAfterRef = sessiondetail.getStudStatusfromlist(2,
					Constants.FDStatus);
			if (MapDgSessStuRecAfterRef != null)
				UMReporter.log(Status.PASS,
						"Selected the refresh and few Students status are " + MapDgSessStuRecAfterRef);
			else
				UMReporter.log(Status.PASS, "Selected the refresh button");
		} else
			UMReporter.log(Status.FAIL, "Unable to select Refresh button ");

	}

	@Given("^Navigate to Test Sessions page$")
	public void navigate_to_TestSession_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Test Sessions page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL, "LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		// Select Menu option Primary and secondary option
		home.MenuOtion("Sessions Overview", "");
		// Verify the Session list page displayed
		if (Sessionlist.IsSessionListTableExist())
			UMReporter.log(Status.PASS, "User is navigated successfully to Test Sessions page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@Then("^Verify the list of Sessions displayed in Test Sessions page$")
	public void verify_Session_list_is_access_in_TestSessions() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the list of Sessions displayed in Test Sessions page");
		List<String> MapDgOrgColHeader = Sessionlist.verifySessionSearchresultsDetails(3);
		if (MapDgOrgColHeader != null)
			UMReporter.log(Status.PASS, "The following Session lists are accessed :" + MapDgOrgColHeader);
		else
			UMReporter.log(Status.FAIL, "The Session are not found in list");
	}

	@When("^Click on Create Session button in Session list page$")
	public void click_createsession_button_In_SessionList() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Create Session button in Session list page");
		Sessionlist.clickCreateSessionButton();
		UMReporter.log(Status.PASS, "Selected the Create Session button");
		// Verify the Create page displayed
		if (createsession.verifyCreateSessionPageNavigation())
			UMReporter.log(Status.PASS, "Selected the Create Session button and navigated to Create Session page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@Then("^Select Watch this Session in Session details page$")
	public void Select_WatchSession_SessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Watch this Session in Session details page");
		boolean flag = sessiondetail.SetWatchingSession("Yes");
		if (flag) {
			UMReporter.log(Status.PASS, "Selected the Watch this Session");
		} else
			UMReporter.log(Status.FAIL, "Unable to select Watch this Session");
	}

	@Then("^Select Stop Watching this Session in Session details page$")
	public void Select_StopWatchSession_SessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Stop Watching this Session in Session details page");
		boolean flag = sessiondetail.SetWatchingSession("No");
		if (flag) {
			UMReporter.log(Status.PASS, "Selected the Stop Watching this Session");
		} else
			UMReporter.log(Status.FAIL, "Unable to select Stop Watching this Session");
	}

	@Then("^Verify the watcher list in Session details page$")
	public void verify_Watchers_list_is_access_in_TestSessions() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the watcher list in Session details page");
		List<String> MapDgOrgColHeader = sessiondetail.VerifyWatchList();
		if (MapDgOrgColHeader != null)
			UMReporter.log(Status.PASS, "The following Wachers lists are accessed :" + MapDgOrgColHeader);
		else
			UMReporter.log(Status.FAIL, "The Wachers are not found");
	}

	@Then("^Verify the Provided watcher (.*) in watcher list of Session details page$")
	public void verify_Provided_Watchers_list_is_access_in_TestSessions(String Watchers) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Provided watcher in watcher list of Session details page");
		List<String> MapDgOrgColHeader = sessiondetail.VerifyWatchList(Watchers);
		if (MapDgOrgColHeader != null)
			UMReporter.log(Status.PASS, "The provided Wacher exist in Wachers lists :" + MapDgOrgColHeader);
		else
			UMReporter.log(Status.FAIL, "The Provided Wacher is not found");
	}

	@When("^Add the (.*) Watchers in Session details page$")
	public void Add_Watchers_list_in_TestSessions(String Watchers) throws Exception {
		UMReporter.log(Status.INFO, "When : Add the Watchers in Session details page " + Watchers);
		String AddWatchers = sessiondetail.AddWatchList(Watchers);
		if (AddWatchers != null)
			UMReporter.log(Status.PASS, "The following Wachers lists are added :" + AddWatchers);
		else
			UMReporter.log(Status.FAIL, "The Wachers are not found");
	}

	@When("^Click on Delete button in Session details page$")
	public void Click_DeleteStudents_button_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Delete button in Session details page");
		if (sessiondetail.deleteButton_isVisible()) {
			boolean isbtnclicked = sessiondetail.clickDeleteButton();
			if (isbtnclicked) {
				int count = 0;
				while ((addstudentsession.Verify_Progressbar_Visible()) && (count < 10)) {
					CommonUtility._sleepForGivenTime(1000);
					count = count + 1;
				}
				IsStudRemoved=true;
				UMReporter.log(Status.PASS, "Selected the Delete button");
			} else
				UMReporter.log(Status.FAIL, "Unable to click the Delete button");
		}
		else {
			UMReporter.log(Status.SKIP, "The Delete button is not exist");
			
		}

	}

	@When("^Select the (.*) Students in Session Details page$")
	public void Select_student_list_checkbox_SessionDetails(String Stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the " + Stucount + " Students in Session Details page");
		int stucnt = 1;
		if (CommonUtility.isNumeric(Stucount))
			stucnt = Integer.parseInt(Stucount);

		lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(stucnt);
		if (lstSelectedStudent_SD!=null) {
			if (lstSelectedStudent_SD.size() > 0) {
				iSelectedStudentCount=lstSelectedStudent_SD.size();
				UMReporter.log(Status.PASS, "Selected the student checkbox " + lstSelectedStudent_SD);
			}
			else
				UMReporter.log(Status.FAIL, "The students are not found in list");
		}
		else
			UMReporter.log(Status.SKIP, "The students are not found in list");

	}

	@Then("^Verify the success message displayed after delete in Session details page as (.*)$")
	public void verify_success_message_gets_displayed_on_SessionDetails_page(String messages) throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the success message displayed after delete in Session details page as " + messages);
		boolean flag;
		if (sessiondetail.verifySuccessMessageVisible()) {
			if (messages.contains("<X>"))
				if (lstSelectedStudent_SD.size() != 0) // Studentcount
					messages = messages.replace("<X>", String.valueOf(lstSelectedStudent_SD.size()));

			if (messages.contains("<sessionname>"))
				if (sSelectedSession != null) // Session name
					messages = messages.replace("<sessionname>", sSelectedSession);

			flag = sessiondetail.verifySuccessMessage(messages);
			if (flag)
				UMReporter.log(Status.PASS,
						"Verified the success message displayed in Session details page:" + messages);
			else
				UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);

			sessiondetail.Close_Alerts();
		} else
			UMReporter.log(Status.SKIP, "The success message is not displayed");
	}

	@Then("^Verify the Selected Students removed in Student list in Session details page$")
	public void verify_Selected_Student_Removed_in_Students_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Selected Students removed in Student list in Session details page");
		List<String> removedStudent = null;
		if ((lstSelectedStudent_SD != null)&&(IsStudRemoved)) {
			removedStudent = new ArrayList<String>();
			for (String stu : lstSelectedStudent_SD) {
				List<String> MapDgStuColHeader = sessiondetail.verifyStudSearchresultsDetailsfromlist(stu);
				if (MapDgStuColHeader == null)
					removedStudent.add(stu);
				else {
					if (MapDgStuColHeader.size() == 0)
						removedStudent.add(stu);
				}
			}
			if (removedStudent.size() > 0)
				UMReporter.log(Status.PASS,
						"The following students are removed in Student List of Session details Page :"
								+ removedStudent);
			else
				UMReporter.log(Status.FAIL, "The following students lists are not removed in Session details Page :"
						+ lstSelectedStudent_SD);
		} else
			UMReporter.log(Status.SKIP, "Student not found/not selected");
	}

	@Then("^Verify the Selected Students not removed in Student list in Session details page$")
	public void verify_Selected_Student_NOtRemoved_in_Students_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Selected Students not removed in Student list in Session details page");
		List<String> removedStudent = null;
		if (lstSelectedStudent_SD != null) {
			removedStudent = new ArrayList<String>();
			for (String stu : lstSelectedStudent_SD) {
				List<String> MapDgStuColHeader = sessiondetail.verifyStudSearchresultsDetailsfromlist(stu);
				if (MapDgStuColHeader == null)
					removedStudent.add(stu);
				else if (MapDgStuColHeader.size() < 1)
					removedStudent.add(stu);
			}
			if (removedStudent.size() > 0)
				UMReporter.log(Status.PASS, "The following students lists are not removed in Session details Page :"
						+ lstSelectedStudent_SD);
			else
				UMReporter.log(Status.FAIL,
						"The following students are removed in Student List of Session details Page :"
								+ removedStudent);
		} else
			UMReporter.log(Status.FAIL, "The students are not found in list");
	}

	@Then("^User to expand the session details section$")
	public void Select_Expand_Collapse_SessionDetails_Section() throws Exception {
		UMReporter.log(Status.INFO, "Then :User to expand the session details section");
		boolean flag = sessiondetail.SessionInfoExpand("Yes");
		if (flag) {
			UMReporter.log(Status.PASS, "The Session detail Section is displayed after expand");
		} else
			UMReporter.log(Status.FAIL, "The Session detail Section is displayed after expand");
	}

	@Then("^User to collapse the session details section$")
	public void Set_Collapse_SessionDetails_Section() throws Exception {
		UMReporter.log(Status.INFO, "Then :User to collapse the session details section");
		boolean flag = sessiondetail.SessionInfoExpand("No");
		if (flag) {
			UMReporter.log(Status.PASS, "The Session detail Section is not displayed after collapse");
		} else
			UMReporter.log(Status.FAIL, "The Session detail Section is not displayed after collapse");
	}

	@Then("^Verify Remove button is not displayed in session list page$")
	public void verify_delete_button_is_visible_but_disabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Remove button is not displayed in session list page");
		boolean deletevisible = Sessionlist.deleteButton_isVisible();
		if (!deletevisible) {
			UMReporter.log(Status.PASS, "Remove button is not displayed");
		} else
			UMReporter.log(Status.FAIL, "Remove button is displayed");
	}

	@Then("^Verify Remove button is displayed in session list page$")
	public void verify_delete_button_is_Enabledvisible() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Remove button is displayed in session list page");
		if ((lstSelectedSess != null)&&(IsStudSelectedForDelete)) {
			boolean deletevisible = Sessionlist.deleteButton_isVisible();
			if (deletevisible)
				UMReporter.log(Status.PASS, "Remove button is displayed");
			else {
				IsStudSelectedForDelete=false;
				UMReporter.log(Status.FAIL, "Remove button is not displayed");
			}
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");
	}

	@When("^Click on Remove button in session list page$")
	public void Click_Delete_button_in_SessList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Remove button in session list page");
		if ((lstSelectedSess != null)&&(IsStudSelectedForDelete)) {
			boolean isbtnclicked = Sessionlist.clickDeleteButton();
			if (isbtnclicked) {
				// Sessionlist.waitForProgressbarVisible(20);
				UMReporter.log(Status.PASS, "Selected the Remove button");
			} else {
				IsStudSelectedForDelete=false;
				UMReporter.log(Status.FAIL, "Unable to click the Remove button");
			}
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");
	}

	@When("^Select the (.*) sessions in session list page$")
	public void Select_Org_list_checkbox_Sesslist(String orgcount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the " + orgcount + " sessions in session list page");
		int stucnt = 1;
		if (CommonUtility.isNumeric(orgcount))
			stucnt = Integer.parseInt(orgcount);
		lstSelectedSess = Sessionlist.SelectonSessionCheckbox(stucnt);
		if (lstSelectedSess.size() > 0)
			UMReporter.log(Status.PASS, "Selected the session checkbox " + lstSelectedSess);
		else
			UMReporter.log(Status.FAIL, "The sessions are not found in list");
	}

	@When("^Select the (.*) sessions has no students in session list page$")
	public void Select_Session_Dependson_Colum_Value_checkbox_Sesslist(String sescount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the " + sescount + " sessions has no students in session list page");
		int stucnt = 1;
		IsStudSelectedForDelete=false;
		if (CommonUtility.isNumeric(sescount))
			stucnt = Integer.parseInt(sescount);
		lstSelectedSess = Sessionlist.SelectonSessionCheckboxWithMatchedColValue(stucnt, "Students Completed", "0/0");
		if (lstSelectedSess.size() > 0) {
			IsStudSelectedForDelete=true;
			UMReporter.log(Status.PASS, "Selected the session checkbox " + lstSelectedSess);
		}
		else
			UMReporter.log(Status.SKIP, "The sessions are not found in list");
	}

	@When("^Select the (.*) sessions has students in session list page$")
	public void Select_Session_Dependson_Colum_Value_checkbox_hasStu_Sesslist(String sescount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the " + sescount + " sessions has students in session list page");
		int stucnt = 1;
		IsStudSelectedForDelete=false;
		if (CommonUtility.isNumeric(sescount))
			stucnt = Integer.parseInt(sescount);
		lstSelectedSess = Sessionlist.SelectonSessionCheckboxWithNotMatchedColValue(stucnt, "Students Completed",
				"0/0");
		if (lstSelectedSess.size() > 0) {
			IsStudSelectedForDelete=true;
			UMReporter.log(Status.PASS, "Selected the session checkbox " + lstSelectedSess);
		}
		else
			UMReporter.log(Status.FAIL, "The sessions are not found in list");
	}

	@Then("^Verify the session are removed in session list page$")
	public void verify_Selected_Session_Removed_Sesslist() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the session are removed in session list page");
		List<String> removeOrg = null;
		
		if ((lstSelectedSess != null)&&(IsStudSelectedForDelete)) {
			removeOrg = new ArrayList<String>();
			for (String org : lstSelectedSess) {
				List<String> MapDgStuColHeader = Sessionlist.verifyOrgSearchresultsDetailsfromlist(org);
				if (MapDgStuColHeader == null)
					removeOrg.add(org);
				else if (MapDgStuColHeader.size() < 1)
					removeOrg.add(org);
			}
			if (removeOrg.size() > 0)
				UMReporter.log(Status.PASS, "The following session are removed in session List Page :" + removeOrg);
			else
				UMReporter.log(Status.FAIL,
						"The following sessions are not removed in session List Page :" + lstSelectedSess);
		} else
			UMReporter.log(Status.PASS, "The session are not found in list");
	}

	@Then("^Verify the Session are not removed in session list page$")
	public void verify_Selected_Org_NotRemoved_Orglist() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the session are not removed in session list page");
		List<String> removeOrg = null;
		if (lstSelectedSess != null) {
			removeOrg = new ArrayList<String>();
			for (String org : lstSelectedSess) {
				List<String> MapDgStuColHeader = Sessionlist.verifyOrgSearchresultsDetailsfromlist(org);
				if (MapDgStuColHeader == null)
					removeOrg.add(org);
				else if (MapDgStuColHeader.size() < 1)
					removeOrg.add(org);
			}
			if (removeOrg.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following session lists are not removed in session List Page :" + lstSelectedSess);
			else
				UMReporter.log(Status.PASS, "The following session are removed in session List Page :" + removeOrg);
		} else
			UMReporter.log(Status.PASS, "The Organization are not found in list");
	}

	@Then("^Verify the (?:success|warning|failure) message displayed in session list page as (.*)$")
	public void verify_success_message_gets_displayed_on_ClassList_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the message displayed in session list page as " + messages);
		boolean flag;
		if (messages.contains("<X>")) {
			if (lstSelectedSess != null) {
				int iSelectedOrgCount = lstSelectedSess.size();
				if (iSelectedOrgCount != 0) // Orgcount
					messages = messages.replace("<X>", String.valueOf(iSelectedOrgCount));
			}
		}
		flag = Sessionlist.verifySuccessMessage(messages);
		if (flag)
			UMReporter.log(Status.PASS, "Verified the message displayed in session list page:" + messages);
		else
			UMReporter.log(Status.FAIL, "The message is not matched with expected :" + messages);
	}

	@Given("^Click on cancel button in Session Details Page$")
	public void user_Select_Close_options_AccountDetailsScreen() throws IOException {
		UMReporter.log(Status.INFO, "When: Click on cancel button in Session Details Page");
		boolean flag = sessiondetail.clickCancelButton();
		if (flag)
			UMReporter.log(Status.PASS, "Selected the Cancel");
		else
			UMReporter.log(Status.FAIL, "Unable to select Cancel");
	}

	@When("^Click on Edit button in Session Details Page$")
	public void Click_Edit_button_in_AccountDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Edit button in Session Details Page");
		boolean isbtnclicked = sessiondetail.clickEditButton();
		if (isbtnclicked)
			UMReporter.log(Status.PASS, "Edit button is click");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Edit button");

	}

	@Given("^User edit the Provided Session informations in Session Details page$")
	public void user_Edits_provided_fields_present_SessionDetailPage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When : User edit the Provided Session informations in Session Details page");
		String Fieldname, FieldValue, FilledFieldValue = null;
		List<String> NonVerified = null;

		// Get fields from Configuration json file
		List<Sessionfield> fields = FileReaderManager.getInstance().getJsonReader()
				.getSessionfieldsbyState(Constants.ORG_STATE);
		if (fields != null) {
			if (createsession.VerifyEditSessionForm()) {
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified = new ArrayList<String>();
				MapSessEditedFields = new HashMap<String, String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					System.out.println("FieldValue:" + Fieldname + " => " + FieldValue);
					Sessionfield field = FileReaderManager.getInstance().getJsonReader().getSessionfieldbyLabel(fields,
							Fieldname);
					if (field != null) {
						FilledFieldValue = createsession.FillSessionField(field, FieldValue);
						if (FilledFieldValue == null)
							NonVerified.add(Fieldname);
						else
							MapSessEditedFields.put(Fieldname, FilledFieldValue);
					}
				}
				if (NonVerified.size() > 0)
					UMReporter.log(Status.FAIL,
							"The following Session fields are unable to provide the input value :" + NonVerified);
				else
					UMReporter.log(Status.PASS,
							"The following Session fields provided the input values :" + MapSessEditedFields);
			}
		}
	}

	@When("^Click on Save button in Session Details page$")
	public void Click_Save_button_in_UserDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Save button in Session Details page");
		if (sessiondetail.SaveButton_isEnabled()) {
			boolean isbtnclicked = sessiondetail.clickSaveButton();
			if (isbtnclicked)
				UMReporter.log(Status.PASS, "Save button is click");
			else
				UMReporter.log(Status.FAIL, "Unable to click the Save button");
		} else
			UMReporter.log(Status.FAIL, "Save button is not enabled to click");

	}

//@Then("^Verify the success message displayed in Session Details page as (.*)$")
//public void verify_success_message_gets_displayed_on_Account_Detailsscreen_page(String message) throws IOException {
//	UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Session Details page as "+message);
//	boolean flag;
//	String errormsg=null;
//	if (message.contains("<X>")) 
//		if (iSelectedStudentCount != 0) // Studentcount
//			message = message.replace("<X>", String.valueOf(iSelectedStudentCount));
//	
//	System.out.println("Success message1 : "+message);
//	flag = sessiondetail.verifySuccessMessage(message);
//	//System.out.println("Success message1 flag : "+flag);
//	if (flag) {
//		UMReporter.log(Status.PASS, "The Success message matched with expected "+message );
//		sessiondetail.Close_Alerts();
//	}
//	else {	
//		errormsg=sessiondetail.getFieldControlErrorMessage();
//		if (errormsg!=null)
//			UMReporter.log(Status.FAIL, "The following field error message is displayed :"+errormsg);
//		else
//			UMReporter.log(Status.FAIL, "The Success message not matched with expected :"+message);
//	}
//	
//}

	@Then("^Verify the edited information in Session Details page$")
	public void verify_edited_User_details_is_displayed_in_AccountDetails_screen() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the edited User information in Session Details page");
		if (MapSessEditedFields != null) {
			if (MapSessEditedFields.containsKey("Session Name")) {
				sSelectedSession = MapSessEditedFields.get("Session Name");
			}
			// Verify the Student Detail page displayed
			if (sessiondetail.Verify_Session_Info())
				// Verify the Session details page displayed
				sessiondetail.verifyViewSessionDetails(MapSessEditedFields);
			else {
				if (sessiondetail.CanceltButton_isVisible())
					sessiondetail.clickCancelButton();
				UMReporter.log(Status.FAIL, "Session details page is not displayed");
			}
		} else
			UMReporter.log(Status.FAIL, "Session details are not found");
	}

	@When("^Verify title and content (.*) in Confirmation Delete Session pop-up$")
	public void Verify_title_message_ConfirmPopUp_button(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Confirm Delete Session pop-up");
		if (IsStudSelectedForDelete) {
			boolean flag = false;
			// Verify the Confirm pop up
			flag = CommonFunctions.VerifyConfirmPopupContent(Constants.DeleteSessionConfirmPopupTitle, confmessage);
			if (flag)
				UMReporter.log(Status.PASS, "Verified Confirm Delete Session pop-up title and message : " + confmessage);
		}

	}

	@When("^Click on confirm button on Confirmation Delete Session pop-up$")
	public void Click_confirm_on_ConfirmDeleteOrgpopup() throws Exception {
		UMReporter.log(Status.INFO, "When :  Click on confirm button on Confirmation Delete Session pop-up");
		if (IsStudSelectedForDelete) {
			// Verify the Click Confirm in pop up
			boolean flag = CommonFunctions.ConfirmPopupActionBtn("Confirm");
			CommonUtility._sleepForGivenTime(3000);
			if (flag) {
				flag = Sessionlist.waitForProgressbarVisible(20);
	
				if (flag)
					UMReporter.log(Status.PASS, "Select the Confirm button and navigated to Session list page");
				else
					UMReporter.log(Status.PASS, "Progress bar is displayed for long time after delete");
	
			} else
				UMReporter.log(Status.FAIL, "Select the Confirm button and Session list not displayed ");
		}
	}

	@When("^Click on cancel button on Confirmation Delete Session pop-up$")
	public void Click_cancel_on_ConfirmDeleteOrgn_button() throws IOException {
		UMReporter.log(Status.INFO, "When :  Click on cancel button on Confirmation Delete Session pop-up");
		if (IsStudSelectedForDelete) {
		// Verify the Click cancel in pop up
		boolean flag = CommonFunctions.ConfirmPopupActionBtn("Cancel");
		CommonUtility._sleepForGivenTime(3000);
		if (flag)
			UMReporter.log(Status.PASS, "Select the Cancel button and pop up is closed ");
		else
			UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed ");
		}
	}

	@Then("^Verify the success message displayed in Session page as (.*)$")
	public void verify_success_message_displayed_in_Session_LIST_page_as(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Session page as " + messages);
		boolean flag;
		flag = Sessionlist.verifySuccessMessage(messages);
		if (flag) {
			UMReporter.log(Status.PASS, "Verified the success message displayed in Session page:" + messages);
			Sessionlist.Close_Alerts();
		} else
			UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);

	}
	
	
	@Then("^Verify the success message displayed after delete session in Session page as (.*)$")
	public void verify_success_message_displayed_afterdelete_in_Session_LIST_page_as(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Session page as " + messages);
		boolean flag;
		if(IsStudSelectedForDelete) {
			flag = Sessionlist.verifySuccessMessage(messages);
			if (flag) {
				UMReporter.log(Status.PASS, "Verified the success message displayed in Session page:" + messages);
				Sessionlist.Close_Alerts();
			} else
				UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
		}
		else
			UMReporter.log(Status.SKIP, "The sessions are not selected/Deleted");

	}

	@Then("^User switch to Sessions List Tab in Sessions Page$")
	public void Select_Session_list_Tab() throws Exception {
		UMReporter.log(Status.INFO, "Then :User switch to Sessions List Tab in Sessions Page");
		boolean flag = false;
		flag = Sessionlist.SelectTabOption("Sessions List");
		if (flag) {
			UMReporter.log(Status.PASS, "Selected the Sessions List Tab");
		} else
			UMReporter.log(Status.FAIL, "Unable to select Sessions List Tab");
	}

	@Then("^Verify Reports bulk action is visible in Session Details page$")
	public void verify_Reports_button_is_visible_in_DetailPage() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Reports bulk action is visible in Session Details page");
		if (lstSelectedStudent_SD != null) {
			boolean btnvisible = sessiondetail.ReportsButton_isVisible();
			if (btnvisible)
				UMReporter.log(Status.PASS, "Reports button is visible");
			else
				UMReporter.log(Status.SKIP,
						"Reports button is not visible, might reporting not enabled Please check manually");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}

	@Then("^Verify Reports bulk action is not visible in Session Details page$")
	public void verify_Reports_button_is_Notvisible_in_DetailPage() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Reports bulk action is not visible in Session Details page");
		boolean btnvisible = sessiondetail.ReportsButton_isVisible();
		if (!btnvisible)
			UMReporter.log(Status.PASS, "Reports button is not visible");
		else
			UMReporter.log(Status.FAIL, "Reports button is visible");

	}

	@Given("^Verify Reports items displayed in Session Details page$")
	public void verify_Reports_In_SessionDetails_page(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Reports items displayed in Session Details page");
		String Fieldname;
		List<String> NonVerified = null;
		boolean flag = true;
		if (lstSelectedStudent_SD != null) {
			if (sessiondetail.ReportsButton_isVisible()) {
				List<String> MapReportItems = sessiondetail.VerifyReportsList();
				if (MapReportItems.size() > 0) {
					List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
					NonVerified = new ArrayList<String>();
					for (int i = 0; i < list.size(); i++) {
						Fieldname = list.get(i).get("ReportItems");
						System.out.println("Repots:" + Fieldname);
						if (!MapReportItems.contains(Fieldname))
							NonVerified.add(Fieldname);
					}
				}
				if (NonVerified.size() > 0)
					UMReporter.log(Status.FAIL,
							"The following expected Report Items are not exist in frontend :" + NonVerified);
				else
					UMReporter.log(Status.PASS, "The following Report Items  are verified :" + MapReportItems);
			} else
				UMReporter.log(Status.SKIP, "Reports options not exist ");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}

	@Then("^Select the Report item (.*) in Session Details page$")
	public void Select_Report_displayed_in_Session_page_as(String reportname) throws Exception {
		UMReporter.log(Status.INFO, "Then : Select the Report item in Session Details page" + reportname);
		boolean flag;
		if (lstSelectedStudent_SD != null) {
			if (sessiondetail.ReportsButton_isVisible()) {
				CurrentWinHnd = CommonFunctions.GetCurrentWindowHandle();
				flag = sessiondetail.SelectReportFromList(reportname);
				if (flag)
					UMReporter.log(Status.PASS, "Select the Report Item in Session page:" + reportname);
				else
					UMReporter.log(Status.FAIL, "The Report item not found :" + reportname);
			} else
				UMReporter.log(Status.SKIP, "Reports options not exist ");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}
	
	@When("Verify the selected reports opened in New Browser Tab")
	public void verify_Reports_Reporting_page() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify the selected reports opened in New Browser Tab");
		testTicketsWinHnd = WebDriverMain._getDriver().getWindowHandles();
		for (String testTickets : testTicketsWinHnd) {
			if (!testTickets.equals(CurrentWinHnd)) {
				WebDriverMain._getDriver().switchTo().window(testTickets);
				CommonUtility._sleepForGivenTime(2000);
				String repurl=sessiondetail.GetReportingUrl();
				if (sessiondetail.Report_BtnDownloadReport_isVisible()) {
					UMReporter.log(Status.PASS, "Reporting frame is displayed in Reports Page : "+repurl);
				}
				else
					UMReporter.log(Status.SKIP, "Reports are not displayed in Reports Page : "+repurl);
				WebDriverMain._getDriver().switchTo().window(CurrentWinHnd);
			}
		}
	}
	

	@When("Close Reporting Tab page")
	public void close_Reporting_Tab_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Close Reporting Tab page");

		boolean flag = CommonFunctions.CloseAllWindowExceptCurrent(CurrentWinHnd);
		CommonUtility._sleepForGivenTime(1000);
		if (flag)
			UMReporter.log(Status.PASS, "Student Test Tickets page is closed");
		else
			UMReporter.log(Status.PASS, "Student Test Tickets page is not closed");
	}

	@When("^Click on Resetstudpswd button in Session details page$")
	public void Click_Resetstudpswd_button_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Resetstudent password button in Session details page");
		if (lstSelectedStudent_SD != null) {
			boolean isbtnclicked = sessiondetail.clickReststudentPasswordButton();
			if (isbtnclicked) {
				int count = 0;
				while ((addstudentsession.Verify_Progressbar_Visible()) && (count < 10)) {
					CommonUtility._sleepForGivenTime(1000);
					count = count + 1;
				}
				UMReporter.log(Status.PASS, "Selected the Resetstudent button");
			} else
				UMReporter.log(Status.FAIL, "Unable to click the Resetstudent button");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}

	@Then("^Verify Resetpassword button is not displayed in session details page$")
	public void verify_resetpassword_button_is_visible_but_disabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Resetpassword button is not displayed in session detail page");
		boolean deletevisible = sessiondetail.resetpasswordButton_isVisible();
		if (!deletevisible) {
			UMReporter.log(Status.PASS, "Resetpassword button is not displayed");
		} else
			UMReporter.log(Status.FAIL, "Resetpassword button is displayed");
	}

	@Then("^Verify Resetpassword button is displayed in session details page$")
	public void verify_resetpassword_button_is_Enabledvisible() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Resetpassword button is displayed in session detail page");
		if (lstSelectedStudent_SD != null) {
			boolean deletevisible = sessiondetail.resetpasswordButton_isVisible();
			if (deletevisible)
				UMReporter.log(Status.PASS, "Resetpassword button is displayed");
			else
				UMReporter.log(Status.FAIL, "Resetpassword button is not displayed");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");
	}

	@When("^Click on Print Testing Ticket above Student List in Session details page$")
	public void Click_PrintStudents_button_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Print Testing Ticket above Student List in Session details page");
		boolean isbtnclicked = sessiondetail.clickPrintButton();
		if (isbtnclicked) {

			UMReporter.log(Status.PASS, "Selected the Print Testing Ticket button to Open New Tab");
		} else
			UMReporter.log(Status.FAIL, "Unable to click the Print Testing Ticket button");
		// to Unselect the checkbox
		// sessiondetail.UnSelectAllStuCheckbox();

	}

	@Then("^User get Student details for TestNav integration in Session details page$")
	public void Get_Students_list_for_Testnav() throws Exception {
		UMReporter.log(Status.INFO, "Then : User get Student details for TestNav integration in Session details page");
		CurrentWinHnd = CommonFunctions.GetCurrentWindowHandle();
		MapStudentFields = sessiondetail.GetStudentDetails(1);
		if (MapStudentFields != null) {
			String testname = sessiondetail.GetValueforSessionLabel("Test:");
			MapStudentFields.put("Test", testname);
			UMReporter.log(Status.PASS, "The students details for TestNav Testing :" + MapStudentFields);
		} else
			UMReporter.log(Status.FAIL, "The students are not found in list");
	}

	@Then("^Launch TestNav web and login with Sudent Test Credentials$")
	public void TestNav_Login_Setup() throws Exception {
		UMReporter.log(Status.INFO, "Launch TestNav web and login with Sudent Test Credentials");
		System.out.println("Launch TestNav web and test attempt");
		int wincnt = CommonFunctions.getAllWindowExceptCurrent();
		boolean flag = false;
		if ((MapStudentFields != null) && (wincnt > 1)) {
			String user = MapStudentFields.get("Username");
			String pwd = MapStudentFields.get("Password");
			String name = MapStudentFields.get("Student Name");
			String test = MapStudentFields.get("Test");
			String cong = "Congratulations, you have finished";
			// Switch to New Window
			CommonFunctions.SwitchtoNewWindow(CurrentWinHnd);
			// Launch TestNav Web Url
			testnavlogin.NavigatetoTestNavURL();
			// Login with Username and Password
			testnavlogin.doLogin(user, pwd);
			testnavhome.waitForProgressbarVisible(20);
			flag = testnavhome.VerifyLoggedInUserIcon();
			if (flag) {
				testnavhome.VerifyWelcomeUser(name);
				testnavhome.ClickSelect();
				testnavhome.VerifyTestName(test);
				testnavhome.ClickStart();
				testnavhome.ClickStartSection();
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.SelectEndReviewOptions();
				testnavhome.ClickSubmitFinalAnswers();
				testnavhome.ConfirmSubmitPopupActionBtn("Yes, Submit Final Answers");
				// testnavhome.ConfirmExitPopupActionBtn("Save and Return Later");
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.VerifyBackToSign();
				UMReporter.log(Status.PASS, "Test Nav Login details: " + MapStudentFields);
			} else {

				String message = testnavlogin.getAlertMessage();
				UMReporter.log(Status.PASS, "Test Nav login fail with message : " + message);

			}
			// Switch to Current Window
			CommonFunctions.SwitchtoCurrentWindow(CurrentWinHnd);
		} else

			UMReporter.log(Status.PASS, "Unable to launch for Test Nav");

	}

	@Then("^User search and verify the Student details in Student list in Session details page$")
	public void Get_Selected_Student_in_Students_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User search and verify the Student details in Student list in Session details page");
		List<String> NotVerified = null;
		List<String> Verified = null;
		List<String> MapDgStuColHeader = null;
		if (lstSelectedStudent_SD != null) {
			NotVerified = new ArrayList<String>();
			Verified = new ArrayList<String>();
			for (String stu : lstSelectedStudent_SD) {
				String strArrObjLocs[] = CommonUtility._split(stu, ",");
				if (strArrObjLocs.length == 2) {
					sessiondetail.Searchfill_StudName(strArrObjLocs[0].trim());
					sessiondetail.clicksearchicon();
				}
				MapDgStuColHeader = sessiondetail.verifyStudSearchresultsDetailsfromlist(stu);
				if (MapDgStuColHeader == null)
					NotVerified.add(stu);
				else
					Verified.add(MapDgStuColHeader.toString());
			}
			if (NotVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following students lists are not verified in Session details Page :" + NotVerified);
			else
				UMReporter.log(Status.PASS,
						"The following students lists are verified in Session details Page :" + Verified);
		} else
			UMReporter.log(Status.FAIL, "The students are not found in list");

	}

	@Then("^Launch TestNav web login and activate the test$")
	public void TestNav_Login_Activate() throws Exception {
		UMReporter.log(Status.INFO, "Launch TestNav web and login with Sudent Test Credentials");
		System.out.println("Launch TestNav web and test attempt");
		int wincnt = CommonFunctions.getAllWindowExceptCurrent();
		boolean flag = false;
		if ((MapStudentFields != null) && (wincnt > 1)) {
			String user = MapStudentFields.get("Username");
			String pwd = MapStudentFields.get("Password");
			String name = MapStudentFields.get("Student Name");
			String test = MapStudentFields.get("Test");
			String cong = "Congratulations, you have finished";
			// Switch to New Window
			CommonFunctions.SwitchtoNewWindow(CurrentWinHnd);
			// Launch TestNav Web Url
			testnavlogin.NavigatetoTestNavURL();
			// Login with Username and Password
			testnavlogin.doLogin(user, pwd);
			testnavhome.waitForProgressbarVisible(20);
			flag = testnavhome.VerifyLoggedInUserIcon();
			if (flag) {
				LoggedinTestNavFlag = true;
				testnavhome.VerifyWelcomeUser(name);
				UMReporter.log(Status.PASS, "Test Nav logged in and activate the Student test: " + MapStudentFields);
			} else {

				String message = testnavlogin.getAlertMessage();
				UMReporter.log(Status.PASS, "Test Nav login fail with message : " + message);

			}

		} else
			UMReporter.log(Status.PASS, "Unable to launch for Test Nav");

	}

	@Then("^TestNav web to complete the opened test$")
	public void TestNav_Login_toComplete_Test() throws Exception {
		UMReporter.log(Status.INFO, "TestNav web to complete the opened test");
		System.out.println("Launch TestNav web and test attempt");
		int wincnt = CommonFunctions.getAllWindowExceptCurrent();
		boolean flag = false;
		if ((LoggedinTestNavFlag) && (wincnt > 1) && (MapStudentFields != null)) {
			String user = MapStudentFields.get("Username");
			String pwd = MapStudentFields.get("Password");
			String name = MapStudentFields.get("Student Name");
			String test = MapStudentFields.get("Test");
			String cong = "Congratulations, you have finished";
			// Switch to New Window
			CommonFunctions.SwitchtoNewWindow(CurrentWinHnd);
			// Launch TestNav Web Url
			flag = testnavhome.VerifyLoggedInUserIcon();
			if (flag) {
				testnavhome.VerifyWelcomeUser(name);
				testnavhome.ClickSelect();
				testnavhome.VerifyTestName(test);
				testnavhome.ClickStart();
				testnavhome.ClickStartSection();
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.SelectEndReviewOptions();
				testnavhome.ClickSubmitFinalAnswers();
				testnavhome.ConfirmSubmitPopupActionBtn("Yes, Submit Final Answers");
				// testnavhome.ConfirmExitPopupActionBtn("Save and Return Later");
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.VerifyBackToSign();
				UMReporter.log(Status.PASS, "Test Nav to complete the student test: " + MapStudentFields);
			} else {

				String message = testnavlogin.getAlertMessage();
				UMReporter.log(Status.PASS, "Test Nav login fail with message : " + message);

			}
		} else

			UMReporter.log(Status.PASS, "Unable to launch for Test Nav");

	}

	@Then("^TestNav web to exit the opened test$")
	public void TestNav_Login_toexit_Test() throws Exception {
		UMReporter.log(Status.INFO, "TestNav web to exit the opened test");
		System.out.println("Launch TestNav web and test attempt");
		int wincnt = CommonFunctions.getAllWindowExceptCurrent();
		boolean flag = false;
		if ((LoggedinTestNavFlag) && (wincnt > 1) && (MapStudentFields != null)) {
			String user = MapStudentFields.get("Username");
			String pwd = MapStudentFields.get("Password");
			String name = MapStudentFields.get("Student Name");
			String test = MapStudentFields.get("Test");
			String cong = "Congratulations, you have finished";
			// Switch to New Window
			CommonFunctions.SwitchtoNewWindow(CurrentWinHnd);
			// Launch TestNav Web Url
			flag = testnavhome.VerifyLoggedInUserIcon();
			if (flag) {
				testnavhome.VerifyWelcomeUser(name);
				testnavhome.ClickSelect();
				testnavhome.VerifyTestName(test);
				testnavhome.ClickStart();
				testnavhome.ClickStartSection();
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.Logout();
				testnavhome.ConfirmExitPopupActionBtn("Save and Return Later");
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.VerifyBackToSign();
				UMReporter.log(Status.PASS, "Test Nav to exit the student test: " + MapStudentFields);
			} else {

				String message = testnavlogin.getAlertMessage();
				UMReporter.log(Status.PASS, "Test Nav login fail with message : " + message);

			}
		} else

			UMReporter.log(Status.PASS, "Unable to launch for Test Nav");

	}

	@Then("^TestNav web close browser$")
	public void TestNav_Login_tocloseBrowser() throws Exception {
		UMReporter.log(Status.INFO, "TestNav web close browser");
		System.out.println("Launch TestNav web and test attempt");
		int wincnt = CommonFunctions.getAllWindowExceptCurrent();
		boolean flag = false;
		if ((wincnt > 1)) {
			CommonFunctions.CloseAllWindowExceptCurrent(CurrentWinHnd);
			UMReporter.log(Status.PASS, "TestNav web browser Closed");
		} else

			UMReporter.log(Status.FAIL, "Unable to find the Test Nav");

	}

	@Then("User select the refresh button to retrieve the testing status in Session details page$")
	public void Set_Refresh_Selected_Student_Status_Updted_in_Students_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User select the refresh button to retrieve the testing status in Session details page");
		// Switch to Current Window
		CommonFunctions.SwitchtoCurrentWindow(CurrentWinHnd);
		HashMap<String, String> MapDgSessStuRec = sessiondetail.getStudStatusfromlist(1, Constants.FDStatus);
		boolean flag = sessiondetail.clickRefreshButton();
		if (flag) {
			// Verify the updated status
			HashMap<String, String> MapDgSessStuRecAfterRef = sessiondetail.getStudStatusfromlist(1,
					Constants.FDStatus);
			if (MapDgSessStuRec.equals(MapDgSessStuRecAfterRef))
				UMReporter.log(Status.PASS,
						"Selected the refresh and the Student testing status remain same in Session details Page :"
								+ MapDgSessStuRec);
			else
				UMReporter.log(Status.PASS,
						"Selected the refresh and the Student testing status are updated in Session details Page :"
								+ MapDgSessStuRec + " New data=> " + MapDgSessStuRecAfterRef);
		} else
			UMReporter.log(Status.FAIL, "Unable to select Refresh button ");
	}

	@When("Verify PrintAllTickets button is not displayed in session details page")
	public void verify_PrintAllTickets_button_is_not_displayed_in_session_details_page() throws IOException {
		UMReporter.log(Status.INFO,
				"Then: Verify Print All Testing Tickets button is not displayed in session detail page");
		boolean printAllVisible = sessiondetail.printAllTicketsButton_isVisible();

		if (!printAllVisible) {
			UMReporter.log(Status.PASS, "PrintAllTickets button is not displayed");
		} else
			UMReporter.log(Status.FAIL, "PrintAllTickets button is displayed");
	}

	@When("Verify PrintSelectedTickets button is not displayed in session details page")
	public void verify_PrintSelectedTickets_button_is_not_displayed_in_session_details_page() throws Exception {
		UMReporter.log(Status.INFO,
				"Then: Verify Print Selected Testing Tickets button is not displayed in session detail page");

		boolean printSelectedVisible = sessiondetail.printSelectedTicketsButton_isVisible();

		if (!printSelectedVisible) {
			UMReporter.log(Status.PASS, "PrintSelectedTickets button is not displayed");
		} else
			UMReporter.log(Status.FAIL, "PrintSelectedTickets button is displayed");

	}

	@When("Click on PrintSelectedTickets button in Session details page")
	public void click_on_PrintSelectedTickets_button_in_Session_details_page() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Print Selected testing ticket(s) button in Session details page");
		if (lstSelectedStudent_SD != null) {
			CurrentWinHnd = CommonFunctions.GetCurrentWindowHandle();
			boolean isbtnclicked = sessiondetail.clickPrintSelectedTicketsButton();
			if (isbtnclicked) {
				int count = 0;
				while ((addstudentsession.Verify_Progressbar_Visible()) && (count < 10)) {
					CommonUtility._sleepForGivenTime(1000);
					count = count + 1;
				}
				UMReporter.log(Status.PASS, "Selected the Print Selected testing ticket(s) button");
			} else
				UMReporter.log(Status.FAIL, "Unable to click the Print Selected testing ticket(s) button");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}

	@When("Click on PrintAllTickets button in Session details page")
	public void click_on_PrintAllTickets_button_in_Session_details_page() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Print all testing ticket(s) button in Session details page");
		CurrentWinHnd = CommonFunctions.GetCurrentWindowHandle();
		boolean isbtnclicked = sessiondetail.clickPrintAllTicketsButton();
		if (isbtnclicked) {
			int count = 0;
			while ((addstudentsession.Verify_Progressbar_Visible()) && (count < 10)) {
				CommonUtility._sleepForGivenTime(1000);
				count = count + 1;
			}
			UMReporter.log(Status.PASS, "Selected the Print all testing ticket(s) button");
		} else
			UMReporter.log(Status.FAIL, "Unable to click the Print all testing ticket(s) button");
	}

	@When("Verify Navigate to studentTestTickets page")
	public void verify_Navigate_to_studentTestTickets_page() throws Exception {
		UMReporter.log(Status.INFO, "When: Student Tickets list is displayed in studentTestTickets page");
		testTicketsWinHnd = WebDriverMain._getDriver().getWindowHandles();

		for (String testTickets : testTicketsWinHnd) {
			if (!testTickets.equals(CurrentWinHnd)) {
				WebDriverMain._getDriver().switchTo().window(testTickets);
				printedTickets = sessiondetail.getPrintedTicketCnt();
				WebDriverMain._getDriver().switchTo().window(CurrentWinHnd);
			}
		}

		boolean hasNewPage = testTicketsWinHnd.size() > 1;
		if (hasNewPage)
			UMReporter.log(Status.PASS,
					"Student Test Tickets displayes in a separate tab with Test Tickets Count " + printedTickets);
		else
			UMReporter.log(Status.PASS, "Student Test Tickets tab is not opened");

	}

	
	@When("Verify Student Tickets list is displayed for {int} in studentTestTickets page")
	public void verify_Student_Tickets_list_is_displayed_for_in_studentTestTickets_page(Integer Stucount)
			throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify Student Tickets list is displayed for " + Stucount + " in studentTestTickets page");

		System.out.println("Selected students In Session::" + Stucount);
		System.out.println("Total Printed Tickets::" + printedTickets);
		if (printedTickets == Stucount)
			UMReporter.log(Status.PASS, "Testing Tickets are Printed for selected Students on studentTestTickets page");
		else
			UMReporter.log(Status.PASS,
					"Testing Tickets are not Printed for selected Students on studentTestTickets page");

	}

	@When("Close Student Test Tickets page")
	public void close_Student_Test_Tickets_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Student Test Tickets page is closed");

		boolean flag = CommonFunctions.CloseAllWindowExceptCurrent(CurrentWinHnd);
		CommonUtility._sleepForGivenTime(1000);
		if (flag)
			UMReporter.log(Status.PASS, "Student Test Tickets page is closed");
		else
			UMReporter.log(Status.PASS, "Student Test Tickets page is not closed");
	}

	@When("Verify Student Tickets list is displayed in studentTestTickets page")
	public void verify_Student_Tickets_list_is_displayed_in_studentTestTickets_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Student Tickets list is displayed in studentTestTickets page");

		int studentInSession = sessiondetail.getStudentInSessionCnt();
		System.out.println("Total student In Session::" + studentInSession);
		System.out.println("Total Printed Tickets::" + printedTickets);
		if (printedTickets == studentInSession)
			UMReporter.log(Status.PASS, "Testing Tickets are Printed for All Students on studentTestTickets page");
		else
			UMReporter.log(Status.PASS, "Testing Tickets are not Printed for All Students on studentTestTickets page");

	}

	@When("Verify Download Test action is not visible in Session Details page")
	public void verify_Download_Test_action_is_not_visible_in_Session_Details_page() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Download Test action is not visible in Session Details page");
		boolean btnvisible = sessiondetail.downloadTest_isVisible();
		if (!btnvisible)
			UMReporter.log(Status.PASS, "Download Test button is not visible");
		else
			UMReporter.log(Status.FAIL, "Download Test button is visible");
	}

	@When("Click on Download Test button in Session details page")
	public void click_on_Download_Test_button_in_Session_details_page() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Download Test button in Session details page");
		// CurrentWinHnd=CommonFunctions.GetCurrentWindowHandle();
		if (sessiondetail.downloadTest_isVisible()) {
			boolean isbtnclicked = sessiondetail.clickDownloadTestButton();
			if (isbtnclicked) {
				int count = 0;
				while ((addstudentsession.Verify_Progressbar_Visible()) && (count < 10)) {
					CommonUtility._sleepForGivenTime(1000);
					count = count + 1;
				}
				UMReporter.log(Status.PASS, "Selected Download Test button");
			} else
				UMReporter.log(Status.FAIL, "Unable to click the Download Test button");
		} else
			UMReporter.log(Status.SKIP, "Download Test option not displayed");
	}

	@When("Verify Download Test button in Session details page")
	public void verify_Download_Test_button_in_Session_details_page() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Download Test action is visible in Session Details page");
		if (lstSelectedStudent_SD != null) {
			boolean btnvisible = sessiondetail.downloadTest_isVisible();
			if (btnvisible)
				UMReporter.log(Status.PASS, "Download Test button is  visible");
			else
				UMReporter.log(Status.SKIP, "Download Test button is not visible. Check the Form file associated");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");
	}

	@When("^Click on Session detail button in report page$")
	public void Click_Sessiondetailbutton_in_reportpage() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the session detail navigation button in report page");
		boolean flag = sessiondetail.clicksessiondetailnavigationtbtn();
		if (flag)
			UMReporter.log(Status.PASS, "Clicked the session detail navigation button");
		else
			UMReporter.log(Status.SKIP, "Not in Report Page");
	}

	@When("^User search by student test status (.*) in Session details page$")
	public void Fill_SearchStatus_student_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search by student test status in Session details page : " + SeachText);
		boolean flag = sessiondetail.Searchfill_StudName(SeachText);
		flag = sessiondetail.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "The Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}

	@Then("^Verify Remove option is displayed above Student list in Session details page$")
	public void verify_remove_button_is_visible_In_StudentList() throws Exception {
		UMReporter.log(Status.INFO,
				"Then: Verify Remove option is displayed above Student list in Session details page");
		if (lstSelectedStudent_SD != null) {
			boolean deletevisible = sessiondetail.deleteButton_isVisible();
			if (deletevisible)
				UMReporter.log(Status.PASS, "Remove button is displayed");
			else
				UMReporter.log(Status.FAIL, "Remove button is not displayed");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");
	}

	@When("Verify PrintAllTickets button is displayed in session details page")
	public void verify_PrintAllTickets_button_is_displayed_in_session_details_page() throws IOException {
		UMReporter.log(Status.INFO,
				"Then: Verify Print All Testing Tickets button is displayed in session detail page");
		boolean printAllVisible = sessiondetail.printAllTicketsButton_isVisible();
		if (printAllVisible) {
			UMReporter.log(Status.PASS, "PrintAllTickets button is displayed");
		} else
			UMReporter.log(Status.FAIL, "PrintAllTickets button is not displayed");
	}

	@When("Verify PrintSelectedTickets button is displayed in session details page")
	public void verify_PrintSelectedTickets_button_is_displayed_in_session_details_page() throws Exception {
		UMReporter.log(Status.INFO,
				"Then: Verify Print Selected Testing Tickets button is displayed in session detail page");
		if (lstSelectedStudent_SD != null) {
			boolean printSelectedVisible = sessiondetail.printSelectedTicketsButton_isVisible();
			if (printSelectedVisible) {
				UMReporter.log(Status.PASS, "PrintSelectedTickets button is displayed");
			} else
				UMReporter.log(Status.FAIL, "PrintSelectedTickets button is not displayed");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");
	}

	@When("Verify Update Status button is displayed in session details page")
	public void verify_UpdateStatus_button_is_displayed_in_session_details_page() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Update Status button is displayed in session details page");
		if (lstSelectedStudent_SD != null) {
			boolean SelectedVisible = sessiondetail.updateStatusButton_isVisible();
			if (SelectedVisible) {
				List<String> MapDgStatus = sessiondetail.GetUpdateStatusActions();
				UMReporter.log(Status.PASS, "Update Status button is displayed with options : " + MapDgStatus);
			} else
				UMReporter.log(Status.FAIL, "Update Status button is not displayed");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");
	}

	@Then("^Verify THS bulk action is visible in Session Details page$")
	public void verify_handscore_button_is_visible_in_DetailPage() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify THS bulk action is visible in Session Details page");
		if (lstSelectedStudent_SD != null) {
			boolean btnvisible = sessiondetail.HandScoreButton_isVisible();
			if (btnvisible)
				UMReporter.log(Status.PASS, "THS button is visible");
			else
				UMReporter.log(Status.SKIP, "THS button is not visible. Check THS Configuration");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}

	@Then("^Verify THS bulk action is not visible in Session Details page$")
	public void verify_handscore_button_is_Notvisible_in_DetailPage() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify THS bulk action is not visible in Session Details page");
		boolean btnvisible = sessiondetail.HandScoreButton_isVisible();
		if (!btnvisible)
			UMReporter.log(Status.PASS, "THS button is not visible");
		else
			UMReporter.log(Status.FAIL, "THS button is visible");

	}

	@Then("^Verify Handscore option is visible in THS bulkaction$")
	public void verify_handscore_option_is_visible_in_ths() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Handscore option is visible in THS bulkaction");
		if (sessiondetail.HandScoreButton_isVisible()) {
			if (lstSelectedStudent_SD != null) {
				boolean btnvisible = sessiondetail.VerifyTHSFromList("Hand Score");
				if (btnvisible)
					UMReporter.log(Status.PASS, "Handscore option is visible");
				else
					UMReporter.log(Status.FAIL, "Handscore option is not visible");
			} else
				UMReporter.log(Status.SKIP, "The students are not selected/found in list");
		} else
			UMReporter.log(Status.SKIP, "Teacher Hand Scoring option is not visible. Check THS Configuration");
	}

	@When("Verify Handscore option is not visible in THS bulkaction")
	public void verify_Handscore_option_is_not_visible_in_THS_bulkaction() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Handscore option is not visible in THS bulkaction");
		if (sessiondetail.HandScoreButton_isVisible()) {
			boolean btnvisible = sessiondetail.VerifyTHSFromList("Hand Score");
			if (!btnvisible)
				UMReporter.log(Status.PASS, "Handscore option is not visible");
			else
				UMReporter.log(Status.FAIL, "Handscore option is visible");
		} else
			UMReporter.log(Status.SKIP, "Teacher Hand Scoring option is not visible. Check THS Configuration");
	}

	@Then("^Verify Submit option is visible in THS bulkaction$")
	public void verify_submit_option_is_visible_in_ths() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Submit option is visible in THS bulkaction");
		if (sessiondetail.HandScoreButton_isVisible()) {
			if (lstSelectedStudent_SD != null) {
				boolean btnvisible = sessiondetail.Submitoption_isVisible();
				if (btnvisible)
					UMReporter.log(Status.PASS, "Submit option is visible");
				else
					UMReporter.log(Status.FAIL, "Submit option is not visible");
			} else
				UMReporter.log(Status.SKIP, "The students are not selected/found in list");
		} else
			UMReporter.log(Status.SKIP, "Teacher Hand Scoring option is not visible. Check THS Configuration");

	}

	@Then("^Select Handscore option in THS dropdown$")
	public void Select_Handscoreoption_in_thsdropdown() throws Exception {
		UMReporter.log(Status.INFO, "Then : Select Handscore option in THS dropdown");
		if (sessiondetail.HandScoreButton_isVisible()) {
			if (lstSelectedStudent_SD != null) {
				boolean flag = sessiondetail.SelectTHSFromList("Hand Score");
				if (flag)
					UMReporter.log(Status.PASS, "Selected Handscore Option");
				else
					UMReporter.log(Status.FAIL, "Unable to select Handscore Option");
			} else
				UMReporter.log(Status.SKIP, "The students are not selected/found in list");
		} else
			UMReporter.log(Status.SKIP, "Teacher Hand Scoring option is not visible. Check THS Configuration");
	}

	@Then("^Select Submit option in THS dropdown$")
	public void Select_Submitoption_in_thsdropdown() throws Exception {
		UMReporter.log(Status.INFO, "Then : Select Submit option in THS dropdown");
		if (sessiondetail.HandScoreButton_isVisible()) {
			if (lstSelectedStudent_SD != null) {
				boolean flag = sessiondetail.SelectTHSFromList("Submit");
				if (flag)
					UMReporter.log(Status.PASS, "Selected Submit Option");
				else
					UMReporter.log(Status.FAIL, "Unable to select Submit Option");
			} else
				UMReporter.log(Status.SKIP, "The students are not selected/found in list");
		} else
			UMReporter.log(Status.SKIP, "Teacher Hand Scoring option is not visible. Check THS Configuration");
	}

	@Then("^Verify the success message displayed after submit as (.*)$")
	public void verify_submitSuccess_message(String textmessage) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed after submit as " + textmessage);
		if (lstSelectedStudent_SD != null) {
			boolean flag;
			flag = sessiondetail.verifySubmitmsg(textmessage.trim());
			if (flag)
				UMReporter.log(Status.PASS, "Success Message displayed");
			else
				UMReporter.log(Status.FAIL, "Success message not displayed");
			sessiondetail.Close_Alerts();
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");
	}

	@Then("^User restricted to view student details from student list in Session details page$")
	public void Verify_Student_Has_Hyperlink_in_student_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User restricted to view student details from student list in Session details page");
		List<String> MapDgOrgDet = sessiondetail.verifyStuGridNoHyperlinks(2);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "User does not have access to view student details :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The Students are not found in list");
	}

	@Then("^User unrestricted to view student details from student list in Session details page$")
	public void Verify_unrestricted_Student_Has_Hyperlink_in_student_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User unrestricted to view student details from student list in Session details page");
		List<String> MapDgOrgDet = sessiondetail.verifyStuGridHyperlinks(1);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "User have access to view student details :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The Students are not found in list");
	}

	@Given("^Verify the Status progress bar counts in Session details Page$")
	public void Verify_Status_progress_bar_StudentDetails_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Status progress bar counts in Session details Page");
		// Verify Session Status Blade open
		if (!sessiondetail.Verify_Session_Status_Blade())
			sessiondetail.SessionStatusBladeExpand("Yes");
		// Get widget content
		MapStatusBarGraphValue = sessiondetail.GetStatusProgressBarContent();

		if (MapStatusBarGraphValue != null)
			UMReporter.log(Status.PASS, "The Status progress bar counts : " + MapStatusBarGraphValue);
		else
			UMReporter.log(Status.SKIP, " The Status progress bar no data to display");
	}

	@When("^User select and verify the selected student status count displays of Students list in Session details page$")
	public void Verify_Selected_StuCount_Drilldown_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User select and verify the selected student status count displays of Students list in Session details page");
		int actual = 0;
		String actualmsg = null;
		if (MapStatusBarGraphValue != null) {
			if (!sessiondetail.Verify_Session_Status_Blade())
				sessiondetail.SessionStatusBladeExpand("Yes");
			for (Map.Entry<String, String> entry : MapStatusBarGraphValue.entrySet()) {
				System.out.println("INFO ViewMap - StatusBar  : " + entry.getKey());
				String sStatus = entry.getKey();
				String sCount = entry.getValue();
				actualmsg = null;
				int slectCnt = sessiondetail.SelectStatusInProgressBar(sStatus);
				System.out.println("slected Count : " + slectCnt);
				// Verify Students list status
				HashMap<String, String> mapVerifiedStudent = sessiondetail.verifyStudStatusfromlist(2,
						Constants.FDStatus, sStatus);
				if ((mapVerifiedStudent != null) && (mapVerifiedStudent.size() > 0))
					actualmsg = actualmsg + " Few verified Students : " + actualmsg;
				if (slectCnt > 0) {
					// Verify Students list count of selected status
					actual = sessiondetail.verifyStuCountGridPagination(slectCnt);
					if (actual == slectCnt)
						UMReporter.log(Status.PASS, "The selected " + slectCnt + " Student count of " + sStatus
								+ " status matches the Student list count :" + actual + " " + actualmsg);
					else
						UMReporter.log(Status.FAIL, "The selected " + slectCnt + " " + sStatus
								+ "student count mismatched the Student list count " + actual + " " + actualmsg);
				} else
					UMReporter.log(Status.PASS, actualmsg);
			}

		} else
			UMReporter.log(Status.PASS, "Unable to find progress bar graph");
	}

	@When("^Verify the selected student status count displays of Students list in Session details page$")
	public void Verify_Selected_StuCount_InProgressBarGraph_Student_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the selected student status count displays of Students list in Session details page");
		int actual = 0;
		String actualmsg = null;
		// Verify Session Status Blade open
		if (!sessiondetail.Verify_Session_Status_Blade())
			sessiondetail.SessionStatusBladeExpand("Yes");
		int slectCnt = sessiondetail.SelectStatusInProgressBar("");
		System.out.println("slected Count : " + slectCnt);
		if (slectCnt > 0) {
			// Verify Students list count of selected status
			actual = sessiondetail.verifyStuCountGridPagination(slectCnt);
			if (actual == slectCnt)
				UMReporter.log(Status.PASS,
						"The selected " + slectCnt + " Student count matches the Student list count :" + actual);
			else
				UMReporter.log(Status.FAIL,
						"The selected " + slectCnt + "student count mismatched the Student list count " + actual);
		} else
			UMReporter.log(Status.FAIL, "No Student Status Bar Graph");
	}

	@When("^User select the (.*) status in Status Bar Graph in Session details page$")
	public void Select_ProvidedStatus_StuCount_InProgressBarGraph_Student_list(String StudStatus) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User select the " + StudStatus + " status in Status Bar Graph in Session details page");
		String SelectStatus=null;
		boolean isStatusAvailable=false;
		// Verify Session Status Blade open
		if (!sessiondetail.Verify_Session_Status_Blade())
			sessiondetail.SessionStatusBladeExpand("Yes");
		
		if (StudStatus.contains("/")) {
			//Pending/ready
			String strArrObjLocs[] = CommonUtility._split(StudStatus, "/");
			if (strArrObjLocs.length > 1) {
				for (int iCol = 0; iCol < strArrObjLocs.length; iCol++) {
					SelectStatus=strArrObjLocs[iCol].trim();
					isStatusAvailable=sessiondetail.VerifyStatusAvailableInStatusBar(SelectStatus);
					if (isStatusAvailable) {
						StudStatus=SelectStatus;
						break;
					}
				}
			}
		}
		int slectCnt = sessiondetail.SelectStatusInProgressBar(StudStatus);
		System.out.println("slected Count : " + slectCnt);
		if (slectCnt > 0)
			UMReporter.log(Status.PASS,
					"Selected " + slectCnt + " Student(s) " + StudStatus + " in Student Status Bar Graph ");
		else
			UMReporter.log(Status.PASS, "No Student " + StudStatus + " Status Bar Graph");
	}

	@When("User select (.*) from Update Status bulk options in session details page")
	public void Select_BulkUpdateStatus_button_is_displayed_in_session_details_page(String Statusname)
			throws Exception {
		UMReporter.log(Status.INFO,
				"Then: User select " + Statusname + " from Update Status bulk options in session details page");
		boolean SelectedVisible = sessiondetail.updateStatusButton_isVisible();
		if (SelectedVisible) {
			boolean flagSelectedStatus = sessiondetail.SelectStatusFromList(Statusname);
			if (flagSelectedStatus) {

				if (Statusname.equalsIgnoreCase("Marked Complete")) {
					CommonUtility._sleepForGivenTime(1000);
					CommonFunctions.ConfirmPopupActionBtn("Confirm");
					CommonFunctions.waitUntilLoadingSpinner(10);
					CommonUtility._sleepForGivenTime(2000);
					if (CommonFunctions.VerifyConfirmPopupDisplayed())
						CommonFunctions.ConfirmPopupActionBtn("Cancel");

					Sessionlist.waitForProgressbarVisible(20);
				} else if (Statusname.equalsIgnoreCase("Void")) {
					CommonUtility._sleepForGivenTime(1000);
					CommonFunctions.ConfirmPopupActionBtn("Void");
					CommonFunctions.waitUntilLoadingSpinner(10);
					CommonUtility._sleepForGivenTime(2000);
				} else if ((Statusname.equalsIgnoreCase("DNR Both")) || (Statusname.equalsIgnoreCase("DNR Individual"))
						|| (Statusname.equalsIgnoreCase("DNR Summary"))) {
					CommonUtility._sleepForGivenTime(1000);
					CommonFunctions.ConfirmPopupActionBtn("DNR");
					CommonFunctions.waitUntilLoadingSpinner(10);
					CommonUtility._sleepForGivenTime(2000);
					if (CommonFunctions.VerifyConfirmPopupDisplayed())
						CommonFunctions.ConfirmPopupActionBtn("Cancel");

					Sessionlist.waitForProgressbarVisible(20);
				} else if (Statusname.equalsIgnoreCase("Not Tested")) {
					CommonUtility._sleepForGivenTime(1000);
					CommonFunctions.ConfirmPopupActionBtn("Not Tested");
					CommonFunctions.waitUntilLoadingSpinner(10);
					CommonUtility._sleepForGivenTime(2000);
				}

				UMReporter.log(Status.PASS, "Selected the status from Update Status options : " + Statusname);
			} else
				UMReporter.log(Status.FAIL, "Not Selected the status from Update Status options : :" + Statusname);
		} else
			UMReporter.log(Status.SKIP, "Update Status options is not displayed");
	}

	@When("^User select eligible student for Void or DNR update in Session details page$")
	public void Select_forVoidorDNRStatus_StuCount_InProgressBarGraph_Student_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User select eligible student for Void or DNR update in Session details page");
		if (!sessiondetail.Verify_Session_Status_Blade())
			sessiondetail.SessionStatusBladeExpand("Yes");
		MapStatusBarGraphValue = sessiondetail.GetStatusProgressBarContent();
		if (MapStatusBarGraphValue != null) {
			for (Map.Entry<String, String> entry : MapStatusBarGraphValue.entrySet()) {
				String sStatus = entry.getKey();
				String sCount = entry.getValue();
				if (!Constants.VoidDNRStatus.contains(sStatus.toLowerCase())) {
					int slectCnt = sessiondetail.SelectStatusInProgressBar(sStatus);
					System.out.println("slected Count : " + slectCnt);
					lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
					break;
				}
			}
		}
	}

	@Given("^Verify all user permissions in Test Sessions page$")
	public void User_allPermission_to_TestSessions_page() throws Exception {

		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL, "LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		List<String> LstUserPermissions = Constants.PERMISSIONS;

		// Switch Org
		String OrgName = FileReaderManager.getInstance().getJsonReader().getSelectOrgName("District");
		// Change the Org Details if not expected
		if (!home.Func_VerifyOrgName(OrgName))
			home.Func_ChangeOrganization(OrgName);

		if ((LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) && (LstUserPermissions.contains("ACCESS_HIGH_STAKES"))
				&& (LstUserPermissions.contains("ACCESS_LOW_STAKES"))) {
			UMReporter.log(Status.INFO, "Given :Verify all user permissions in Test Sessions page");
			home.MenuOtion("Sessions Overview", "");
			if (Sessionlist.IsSessionListTableExist()) {
				UMReporter.log(Status.PASS, "User have access Sessions in the hamburger menu");
				List<String> MapDgOrgColHeader = Sessionlist.verifySessionSearchresultsDetails(1);
				if (MapDgOrgColHeader != null)
					UMReporter.log(Status.PASS, "User have access to view list of Sessions :" + MapDgOrgColHeader);

				if (LstUserPermissions.contains("CREATE_TEST_SESSIONS")) {
					if (Sessionlist.CreateSessionTab_isVisible())
						UMReporter.log(Status.PASS,
								"User have access to Create Session, Create Session Tab is visible");
					else
						UMReporter.log(Status.SKIP,
								"User have access to Create Session, Create Session Tab is not visible");
				}

				// Search Session
				Sessionlist.Searchfill_SessionName(CommonFunctions.getTestData("$session"));
				Sessionlist.clicksearchicon();
				if ((LstUserPermissions.contains("DELETE_TEST_SESSIONS"))
						&& (!LstUserPermissions.contains("DELETE_TEST_SESSIONS_RESTRICTED"))
						&& (!LstUserPermissions.contains("DELETE_TEST_SESSIONS_LOW_STAKES"))) {
					lstSelectedSess = Sessionlist.SelectonSessionCheckbox(1);
					if (lstSelectedSess.size() > 0) {
						if (Sessionlist.deleteButton_isVisible())
							UMReporter.log(Status.PASS, "User have access to Delete Session, Delete button is visible");
						else
							UMReporter.log(Status.FAIL,
									"User have access to Delete Session, Delete button is not visible");
					}
				}

				if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
					MapSessFields = Sessionlist.SelectSessionList();
					if (MapSessFields != null) {
						if (sessiondetail.verifySessionDetailsNavigation()) {
							// Expand the Session Info
							sessiondetail.SessionInfoExpand("Yes");
							// Verify the Session details page displayed
							sessiondetail.verifyViewSessionDetails(MapSessFields);

							if ((LstUserPermissions.contains("SESSIONS_EDIT_SESSION"))
									&& (!LstUserPermissions.contains("SESSIONS_EDIT_SESSION_RESTRICTED"))
									&& (!LstUserPermissions.contains("SESSIONS_EDIT_SESSION_LOW_STAKES"))) {
								if (sessiondetail.EditButton_isVisible())
									UMReporter.log(Status.PASS,
											"User have access to Edit Session, Edit button is displayed");
								else
									UMReporter.log(Status.FAIL,
											"User have access to Edit Session, Edit button is not displayed");
							}

							// Students
							if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
								if (sessiondetail.Verify_Session_StudentList())
									UMReporter.log(Status.PASS,
											"User have access to View Student List in Session details page");

								if ((LstUserPermissions.contains("SESSIONS_ADD_STUDENTS"))
										&& (!LstUserPermissions.contains("SESSIONS_ADD_STUDENTS_RESTRICTED"))
										&& (!LstUserPermissions.contains("SESSIONS_ADD_STUDENTS_LOW_STAKES"))) {
									if (sessiondetail.AddStudentsButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to Add Student to a Session, Add Students button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Add Student to a Session,  Add Students button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
									if (sessiondetail.printAllTicketsButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to Print Test Tickets,  PrintAllTickets button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Print Test Tickets,  PrintAllTickets button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
									if (sessiondetail.clickRefreshButton())
										UMReporter.log(Status.PASS,
												"User have access to Refresh, refresh button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Refresh, refresh button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_ACCOMMODATIONS")) {
									if (sessiondetail.ViewAccommButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to View Accommodations, View Accommodations button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to View Accommodations, View Accommodations button is not displayed");
								}

								// Select Ready Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								int slectCnt = sessiondetail.SelectStatusInProgressBar("Ready");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if ((LstUserPermissions.contains("SESSIONS_REMOVE_STUDENTS"))
												&& (!LstUserPermissions.contains("SESSIONS_REMOVE_STUDENTS_RESTRICTED"))
												&& (!LstUserPermissions
														.contains("SESSIONS_REMOVE_STUDENTS_LOW_STAKES"))) {
											if (sessiondetail.deleteButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Remove Student from Session, Remove Students button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Remove Student from Session, Remove Students button is not displayed");
										}

										if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
											if (sessiondetail.printSelectedTicketsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Print Test Tickets,  Print Selected Student button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Print Test Tickets,  Print Selected Student button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_DOWNLOAD_TEST_FORM")) {
											if (sessiondetail.downloadTest_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Download Test, Download Test button is displayed");
											else
												UMReporter.log(Status.SKIP,
														"User have access to Download Test, Download Test button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_RESET_STUDENT_PASSWORD")) {
											if (sessiondetail.resetpasswordButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Reset Student Password, Reset Student Password button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Reset Student Password, Reset Student Password button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_UPDATE_STUDENT_TEST_STATUS")) {
											if (sessiondetail.updateStatusButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Update Status, Update Status button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Update Status, Update Statuss button is not displayed");
										}
										if (LstUserPermissions
												.contains("TEST_ATTEMPT_PROCTOR_STATUS_NOTTESTED_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if (LstUpdateActions.contains("Not Tested"))
													UMReporter.log(Status.PASS,
															"User have access to 'Not Tested', Not Tested option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Not Tested, Not Tested options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Not Tested, Update Status is not displayed");
										}

									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No ready status students records to verify Remove, Download test, Reset Password, Print Ticket");

								// Select Require Hand scoring Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								slectCnt = sessiondetail.SelectStatusInProgressBar("Requires Hand Scoring");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if ((LstUserPermissions.contains("SESSIONS_ACCESS_HAND_SCORE"))
												&& (!LstUserPermissions
														.contains("SESSIONS_ACCESS_HAND_SCORE_LOW_STAKES"))) {
											if (sessiondetail.HandScoreButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Handscore, Handscore button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Handscore, Handscore button is not displayed");
										}

										if (LstUserPermissions.contains("TEST_ATTEMPT_PROCTOR_STATUS_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if ((LstUpdateActions.contains("Void")))
													UMReporter.log(Status.PASS,
															"User have access to 'Void', Void option is displayed");
												else if ((LstUpdateActions.contains("Not Tested")))
													UMReporter.log(Status.PASS,
															"User have access to 'Not Tested', Not Tested option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Proctor, Void,DNR, Not Tested options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Not Tested, Update Status is not displayed");
										}

										if (LstUserPermissions.contains("TEST_ATTEMPT_PROCTOR_STATUS_VOID_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if ((LstUpdateActions.contains("Void")))
													UMReporter.log(Status.PASS,
															"User have access to 'Void', Void option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Proctor, Void options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Proctor, Void is not displayed");
										}
									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No Requires Hand Scoring status student records to verify handscore ");

								// Select Report Ready Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								slectCnt = sessiondetail.SelectStatusInProgressBar("Report Ready");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if ((LstUserPermissions.contains("SESSIONS_ACCESS_REPORTS"))
												&& (!LstUserPermissions
														.contains("SESSIONS_ACCESS_REPORTS_LOW_STAKES"))) {
											if (sessiondetail.ReportsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Reports,  Reports button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to  Reports,  Reports button is not displayed");
										}
									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No complete status student records to verify handscore ");
							}

							if ((LstUserPermissions.contains("SESSIONS_VIEW_STUDENT_PROFILE"))
									&& (!LstUserPermissions.contains("SESSIONS_VIEW_STUDENT_PROFILE_RESTRICTED"))) {
								List<String> MapDgOrgDet = sessiondetail.verifyStuGridHyperlinks(1);
								if (MapDgOrgDet != null)
									UMReporter.log(Status.PASS,
											"User have access to view student details :" + MapDgOrgDet);
								else
									UMReporter.log(Status.FAIL, "User restricted to view student details ");
							}

						} else
							UMReporter.log(Status.FAIL, "The Session details is not displayed");
					} else
						UMReporter.log(Status.SKIP, "No records found in Sessions list");
				}

				home.SelectCustomerLogo();

				/// Techer Session

				if ((LstUserPermissions.contains("SESSIONS_ADD_STUDENTS_RESTRICTED"))
						&& (LstUserPermissions.contains("SESSIONS_REMOVE_STUDENTS_RESTRICTED"))) {
					UMReporter.log(Status.INFO, "Given :User permissions for Teacher Session in Sessions page");
					home.MenuOtion("Sessions Overview", "");
					if (Sessionlist.IsSessionListTableExist()) {
						// Search Teacher Session
						Sessionlist.Searchfill_SessionName(CommonFunctions.getTestData("$teachersession"));
						Sessionlist.clicksearchicon();

						if (LstUserPermissions.contains("DELETE_TEST_SESSIONS_RESTRICTED")) {
							lstSelectedSess = Sessionlist.SelectonSessionCheckbox(1);
							if (lstSelectedSess.size() > 0) {
								if (Sessionlist.deleteButton_isVisible())
									UMReporter.log(Status.PASS,
											"User have access to Delete Session for teacher session, Delete button is visible");
								else
									UMReporter.log(Status.FAIL,
											"User have access to Delete Session for teacher session, Delete button is not visible");
							}
						}

						if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
							MapSessFields = Sessionlist.SelectSessionList();
							if (MapSessFields != null) {
								if (sessiondetail.verifySessionDetailsNavigation()) {
									// Expand the Session Info
									sessiondetail.SessionInfoExpand("Yes");
									// Verify the Session details page displayed
									sessiondetail.verifyViewSessionDetails(MapSessFields);

									if (LstUserPermissions.contains("SESSIONS_EDIT_SESSION_RESTRICTED")) {
										if (sessiondetail.EditButton_isVisible())
											UMReporter.log(Status.PASS,
													"User have access to Edit Session for teacher session, Edit button is displayed");
										else
											UMReporter.log(Status.FAIL,
													"User have access to Edit Session for teacher session, Edit button is not displayed");
									}

									// Students
									if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
										if (sessiondetail.Verify_Session_StudentList())
											UMReporter.log(Status.PASS,
													"User have access to View Student List in Session details page");

										if (LstUserPermissions.contains("SESSIONS_ADD_STUDENTS_RESTRICTED")) {
											if (sessiondetail.AddStudentsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Add Student to a teacher session , Add Students button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Add Student to a teacher session ,  Add Students button is not displayed");
										}

										if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
											if (sessiondetail.printAllTicketsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Print Test Tickets,  PrintAllTickets button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Print Test Tickets,  PrintAllTickets button is not displayed");
										}

										if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
											if (sessiondetail.clickRefreshButton())
												UMReporter.log(Status.PASS,
														"User have access to Refresh, refresh button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Refresh, refresh button is not displayed");
										}

										if (LstUserPermissions.contains("SESSIONS_PRINT_ACCOMMODATIONS")) {
											if (sessiondetail.ViewAccommButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to View Accommodations, View Accommodations button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to View Accommodations, View Accommodations button is not displayed");
										}

										// Select Ready Status
										if (!sessiondetail.Verify_Session_Status_Blade())
											sessiondetail.SessionStatusBladeExpand("Yes");
										int slectCnt = sessiondetail.SelectStatusInProgressBar("Ready");

										if (slectCnt > 0) {
											lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
											if (lstSelectedStudent_SD.size() > 0) {
												if (LstUserPermissions
														.contains("SESSIONS_REMOVE_STUDENTS_RESTRICTED")) {
													if (sessiondetail.deleteButton_isVisible())
														UMReporter.log(Status.PASS,
																"User have access to Remove Student from teacher session , Remove Students button is displayed");
													else
														UMReporter.log(Status.FAIL,
																"User have access to Remove Student from teacher session , Remove Students button is not displayed");
												}

												if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
													if (sessiondetail.printSelectedTicketsButton_isVisible())
														UMReporter.log(Status.PASS,
																"User have access to Print Test Tickets,  Print Selected Student button is displayed");
													else
														UMReporter.log(Status.FAIL,
																"User have access to Print Test Tickets,  Print Selected Student button is not displayed");
												}
												if (LstUserPermissions.contains("SESSIONS_DOWNLOAD_TEST_FORM")) {
													if (sessiondetail.downloadTest_isVisible())
														UMReporter.log(Status.PASS,
																"User have access to Download Test, Download Test button is displayed");
													else
														UMReporter.log(Status.SKIP,
																"User have access to Download Test, Download Test button is not displayed");
												}
												if (LstUserPermissions.contains("SESSIONS_RESET_STUDENT_PASSWORD")) {
													if (sessiondetail.resetpasswordButton_isVisible())
														UMReporter.log(Status.PASS,
																"User have access to Reset Student Password, Reset Student Password button is displayed");
													else
														UMReporter.log(Status.FAIL,
																"User have access to Reset Student Password, Reset Student Password button is not displayed");
												}
												if (LstUserPermissions
														.contains("SESSIONS_UPDATE_STUDENT_TEST_STATUS")) {
													if (sessiondetail.updateStatusButton_isVisible())
														UMReporter.log(Status.PASS,
																"User have access to Update Status, Update Status button is displayed");
													else
														UMReporter.log(Status.FAIL,
																"User have access to Update Status, Update Statuss button is not displayed");
												}
											}
											sessiondetail.SelectonStuCheckbox(1);
										} else
											UMReporter.log(Status.SKIP,
													"No ready status students records to verify Remove, Download test, Reset Password, Print Ticket");

										// Select Requires Hand Scoring Status
										if (!sessiondetail.Verify_Session_Status_Blade())
											sessiondetail.SessionStatusBladeExpand("Yes");
										slectCnt = sessiondetail.SelectStatusInProgressBar("Requires Hand Scoring");

										if (slectCnt > 0) {
											lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
											if (lstSelectedStudent_SD.size() > 0) {
												if (LstUserPermissions.contains("SESSIONS_ACCESS_HAND_SCORE")) {
													if (sessiondetail.HandScoreButton_isVisible())
														UMReporter.log(Status.PASS,
																"User have access to Handscore, Handscore button is displayed");
													else
														UMReporter.log(Status.FAIL,
																"User have access to Handscore, Handscore button is not displayed");
												}
											}
											sessiondetail.SelectonStuCheckbox(1);
										} else
											UMReporter.log(Status.SKIP,
													"No Requires Hand Scoring status student records to verify handscore ");

										// Select Report Ready Status
										if (!sessiondetail.Verify_Session_Status_Blade())
											sessiondetail.SessionStatusBladeExpand("Yes");
										slectCnt = sessiondetail.SelectStatusInProgressBar("Report Ready");

										if (slectCnt > 0) {
											lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
											if (lstSelectedStudent_SD.size() > 0) {
												if (LstUserPermissions.contains("SESSIONS_ACCESS_REPORTS")) {
													if (sessiondetail.ReportsButton_isVisible())
														UMReporter.log(Status.PASS,
																"User have access to Reports,  Reports button is displayed");
													else
														UMReporter.log(Status.FAIL,
																"User have access to  Reports,  Reports button is not displayed");
												}
											}
											sessiondetail.SelectonStuCheckbox(1);
										} else
											UMReporter.log(Status.SKIP,
													"No Report Ready status student records to verify Reports ");
									}

									if (LstUserPermissions.contains("VIEW_STUDENT_PROFILE_RESTRICTED")) {
										List<String> MapDgOrgDet = sessiondetail.verifyStuGridHyperlinks(1);
										if (MapDgOrgDet != null)
											UMReporter.log(Status.PASS,
													"User have access to view student details :" + MapDgOrgDet);
										else
											UMReporter.log(Status.FAIL, "User restricted to view student details ");
									}

								} else
									UMReporter.log(Status.FAIL, "The Session details is not displayed");
							} else
								UMReporter.log(Status.SKIP, "No records found in Sessions list");
						}

					}
				}
			}
		} else
			UMReporter.log(Status.PASS, "User restricted for Sessions");
	}

	@Given("^User permissions in Sessions page$")
	public void User_Permission_to_Sessions_page() throws Exception {

		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL, "LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		List<String> LstUserPermissions = Constants.PERMISSIONS;

		// Switch Org
		String OrgName = FileReaderManager.getInstance().getJsonReader().getSelectOrgName("School");
		// Change the Org Details if not expected
		if (!home.Func_VerifyOrgName(OrgName))
			home.Func_ChangeOrganization(OrgName);

		if ((LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) && (LstUserPermissions.contains("ACCESS_HIGH_STAKES"))
				&& (LstUserPermissions.contains("ACCESS_LOW_STAKES"))) {
			UMReporter.log(Status.INFO, "Given :User permissions in Sessions page");
			home.MenuOtion("Sessions Overview", "");
			if (Sessionlist.IsSessionListTableExist()) {
				UMReporter.log(Status.PASS, "User have access Sessions in the hamburger menu");
				List<String> MapDgOrgColHeader = Sessionlist.verifySessionSearchresultsDetails(1);
				if (MapDgOrgColHeader != null)
					UMReporter.log(Status.PASS, "User have access to view list of Sessions :" + MapDgOrgColHeader);

				if (LstUserPermissions.contains("CREATE_TEST_SESSIONS")) {
					if (Sessionlist.CreateSessionTab_isVisible())
						UMReporter.log(Status.PASS,
								"User have access to Create Session, Create Session Tab is visible");
					else
						UMReporter.log(Status.SKIP,
								"User have access to Create Session, Create Session Tab is not visible");
				}

				// Search Session
				Sessionlist.Searchfill_SessionName(CommonFunctions.getTestData("$session"));
				Sessionlist.clicksearchicon();
				if ((LstUserPermissions.contains("DELETE_TEST_SESSIONS"))
						&& (!LstUserPermissions.contains("DELETE_TEST_SESSIONS_RESTRICTED"))
						&& (!LstUserPermissions.contains("DELETE_TEST_SESSIONS_LOW_STAKES"))) {
					lstSelectedSess = Sessionlist.SelectonSessionCheckbox(1);
					if (lstSelectedSess.size() > 0) {
						if (Sessionlist.deleteButton_isVisible())
							UMReporter.log(Status.PASS, "User have access to Delete Session, Delete button is visible");
						else
							UMReporter.log(Status.FAIL,
									"User have access to Delete Session, Delete button is not visible");
					}
				}

				if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
					MapSessFields = Sessionlist.SelectSessionList();
					if (MapSessFields != null) {
						if (sessiondetail.verifySessionDetailsNavigation()) {
							// Expand the Session Info
							sessiondetail.SessionInfoExpand("Yes");
							// Verify the Session details page displayed
							sessiondetail.verifyViewSessionDetails(MapSessFields);

							if ((LstUserPermissions.contains("SESSIONS_EDIT_SESSION"))
									&& (!LstUserPermissions.contains("SESSIONS_EDIT_SESSION_RESTRICTED"))
									&& (!LstUserPermissions.contains("SESSIONS_EDIT_SESSION_LOW_STAKES"))) {
								if (sessiondetail.EditButton_isVisible())
									UMReporter.log(Status.PASS,
											"User have access to Edit Session, Edit button is displayed");
								else
									UMReporter.log(Status.FAIL,
											"User have access to Edit Session, Edit button is not displayed");
							}

							// Students
							if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
								if (sessiondetail.Verify_Session_StudentList())
									UMReporter.log(Status.PASS,
											"User have access to View Student List in Session details page");

								if ((LstUserPermissions.contains("SESSIONS_ADD_STUDENTS"))
										&& (!LstUserPermissions.contains("SESSIONS_ADD_STUDENTS_RESTRICTED"))
										&& (!LstUserPermissions.contains("SESSIONS_ADD_STUDENTS_LOW_STAKES"))) {
									if (sessiondetail.AddStudentsButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to Add Student to a Session, Add Students button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Add Student to a Session,  Add Students button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
									if (sessiondetail.printAllTicketsButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to Print Test Tickets,  PrintAllTickets button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Print Test Tickets,  PrintAllTickets button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
									if (sessiondetail.clickRefreshButton())
										UMReporter.log(Status.PASS,
												"User have access to Refresh, refresh button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Refresh, refresh button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_ACCOMMODATIONS")) {
									if (sessiondetail.ViewAccommButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to View Accommodations, View Accommodations button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to View Accommodations, View Accommodations button is not displayed");
								}

								// Select Ready Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								int slectCnt = sessiondetail.SelectStatusInProgressBar("Ready");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if ((LstUserPermissions.contains("SESSIONS_REMOVE_STUDENTS"))
												&& (!LstUserPermissions.contains("SESSIONS_REMOVE_STUDENTS_RESTRICTED"))
												&& (!LstUserPermissions
														.contains("SESSIONS_REMOVE_STUDENTS_LOW_STAKES"))) {
											if (sessiondetail.deleteButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Remove Student from Session, Remove Students button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Remove Student from Session, Remove Students button is not displayed");
										}
										
										if ((LstUserPermissions.contains("SESSIONS_MOVE_STUDENTS"))
												&& (!LstUserPermissions.contains("SESSIONS_MOVE_STUDENTS_RESTRICTED"))
												&& (!LstUserPermissions
														.contains("SESSIONS_MOVE_STUDENTS_LOW_STAKES"))) {
											if (sessiondetail.moveButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Move Student from session , Move button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Move Student from session , Move button is not displayed");
										}

										if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
											if (sessiondetail.printSelectedTicketsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Print Test Tickets,  Print Selected Student button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Print Test Tickets,  Print Selected Student button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_DOWNLOAD_TEST_FORM")) {
											if (sessiondetail.downloadTest_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Download Test, Download Test button is displayed");
											else
												UMReporter.log(Status.SKIP,
														"User have access to Download Test, Download Test button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_RESET_STUDENT_PASSWORD")) {
											if (sessiondetail.resetpasswordButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Reset Student Password, Reset Student Password button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Reset Student Password, Reset Student Password button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_UPDATE_STUDENT_TEST_STATUS")) {
											if (sessiondetail.updateStatusButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Update Status, Update Status button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Update Status, Update Statuss button is not displayed");
										}
										
										if (LstUserPermissions.contains("TEST_ATTEMPT_ADD_IRREGULARITY")) {
											if (sessiondetail.verifyEnterIrregularityButton())
												UMReporter.log(Status.PASS,
														"User have access to add Irregularity, Enter Irregularity button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to add Irregularity, Enter Irregularity button is not displayed");
										}

										if (LstUserPermissions
												.contains("TEST_ATTEMPT_PROCTOR_STATUS_NOTTESTED_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if (LstUpdateActions.contains("Not Tested"))
													UMReporter.log(Status.PASS,
															"User have access to 'Not Tested', Not Tested option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Not Tested, Not Tested options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Not Tested, Update Status is not displayed");
										}
									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No ready status students records to verify Remove, Download test, Reset Password, Print Ticket");

								// Select Require Hand scoring Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								slectCnt = sessiondetail.SelectStatusInProgressBar("Requires Hand Scoring");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if ((LstUserPermissions.contains("SESSIONS_ACCESS_HAND_SCORE"))
												&& (!LstUserPermissions
														.contains("SESSIONS_ACCESS_HAND_SCORE_LOW_STAKES"))) {
											if (sessiondetail.HandScoreButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Handscore, Handscore button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Handscore, Handscore button is not displayed");
										}

										if (LstUserPermissions.contains("TEST_ATTEMPT_PROCTOR_STATUS_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if ((LstUpdateActions.contains("Void")))
													UMReporter.log(Status.PASS,
															"User have access to 'Void', Void option is displayed");
												else if ((LstUpdateActions.contains("Not Tested")))
													UMReporter.log(Status.PASS,
															"User have access to 'Not Tested', Not Tested option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Proctor, Void,DNR, Not Tested options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Not Tested, Update Status is not displayed");
										}

										if (LstUserPermissions.contains("TEST_ATTEMPT_PROCTOR_STATUS_VOID_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if ((LstUpdateActions.contains("Void")))
													UMReporter.log(Status.PASS,
															"User have access to 'Void', Void option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Proctor, Void options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Proctor, Void is not displayed");
										}

									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No Requires Hand Scoring status student records to verify handscore ");

								// Select Report Ready Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								slectCnt = sessiondetail.SelectStatusInProgressBar("Report Ready");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if ((LstUserPermissions.contains("SESSIONS_ACCESS_REPORTS"))
												&& (!LstUserPermissions
														.contains("SESSIONS_ACCESS_REPORTS_LOW_STAKES"))) {
											if (sessiondetail.ReportsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Reports,  Reports button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to  Reports,  Reports button is not displayed");
										}
									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No complete status student records to verify handscore ");
							}

							if ((LstUserPermissions.contains("SESSIONS_VIEW_STUDENT_PROFILE"))
									&& (!LstUserPermissions.contains("SESSIONS_VIEW_STUDENT_PROFILE_RESTRICTED"))) {
								List<String> MapDgOrgDet = sessiondetail.verifyStuGridHyperlinks(1);
								if (MapDgOrgDet != null)
									UMReporter.log(Status.PASS,
											"User have access to view student details :" + MapDgOrgDet);
								else
									UMReporter.log(Status.FAIL, "User restricted to view student details ");
							}

						} else
							UMReporter.log(Status.FAIL, "The Session details is not displayed");
					} else
						UMReporter.log(Status.SKIP, "No records found in Sessions list");
				}

				home.SelectCustomerLogo();
			}
		} else
			UMReporter.log(Status.PASS, "User restricted for Sessions");
	}

	@Given("^User permissions for Teacher Sessions in Sessions page$")
	public void User_Permission_to_TeacherCreatedSessions_page() throws Exception {

		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL, "LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		List<String> LstUserPermissions = Constants.PERMISSIONS;

		if ((LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) && (LstUserPermissions.contains("ACCESS_HIGH_STAKES"))
				&& (LstUserPermissions.contains("ACCESS_LOW_STAKES"))) {
			UMReporter.log(Status.INFO, "Given :User permissions for Teacher Session in Sessions page");
			home.MenuOtion("Sessions Overview", "");
			if (Sessionlist.IsSessionListTableExist()) {
				UMReporter.log(Status.PASS, "User have access Sessions in the hamburger menu");
				List<String> MapDgOrgColHeader = Sessionlist.verifySessionSearchresultsDetails(1);
				if (MapDgOrgColHeader != null)
					UMReporter.log(Status.PASS, "User have access to view list of Sessions :" + MapDgOrgColHeader);

				if (LstUserPermissions.contains("CREATE_TEST_SESSIONS")) {
					if (Sessionlist.CreateSessionTab_isVisible())
						UMReporter.log(Status.PASS,
								"User have access to Create Session, Create Session Tab is visible");
					else
						UMReporter.log(Status.SKIP,
								"User have access to Create Session, Create Session Tab is not visible");
				}

				// Search Teacher Session
				Sessionlist.Searchfill_SessionName(CommonFunctions.getTestData("$teachersession"));
				Sessionlist.clicksearchicon();

				if (LstUserPermissions.contains("DELETE_TEST_SESSIONS_RESTRICTED")) {
					lstSelectedSess = Sessionlist.SelectonSessionCheckbox(1);
					if (lstSelectedSess.size() > 0) {
						if (Sessionlist.deleteButton_isVisible())
							UMReporter.log(Status.PASS,
									"User have access to Delete Session for teacher session, Delete button is visible");
						else
							UMReporter.log(Status.FAIL,
									"User have access to Delete Session for teacher session, Delete button is not visible");
					}
				}
				if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
					MapSessFields = Sessionlist.SelectSessionList();
					if (MapSessFields != null) {
						if (sessiondetail.verifySessionDetailsNavigation()) {
							// Expand the Session Info
							sessiondetail.SessionInfoExpand("Yes");
							// Verify the Session details page displayed
							sessiondetail.verifyViewSessionDetails(MapSessFields);

							if (LstUserPermissions.contains("SESSIONS_EDIT_SESSION_RESTRICTED")) {
								if (sessiondetail.EditButton_isVisible())
									UMReporter.log(Status.PASS,
											"User have access to Edit Session for teacher session, Edit button is displayed");
								else
									UMReporter.log(Status.FAIL,
											"User have access to Edit Session for teacher session, Edit button is not displayed");
							}

							// Students
							if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
								if (sessiondetail.Verify_Session_StudentList())
									UMReporter.log(Status.PASS,
											"User have access to View Student List in Session details page");

								if (LstUserPermissions.contains("SESSIONS_ADD_STUDENTS_RESTRICTED")) {
									if (sessiondetail.AddStudentsButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to Add Student to a teacher session , Add Students button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Add Student to a teacher session ,  Add Students button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
									if (sessiondetail.printAllTicketsButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to Print Test Tickets,  PrintAllTickets button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Print Test Tickets,  PrintAllTickets button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
									if (sessiondetail.clickRefreshButton())
										UMReporter.log(Status.PASS,
												"User have access to Refresh, refresh button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Refresh, refresh button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_ACCOMMODATIONS")) {
									if (sessiondetail.ViewAccommButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to View Accommodations, View Accommodations button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to View Accommodations, View Accommodations button is not displayed");
								}

								// Select Ready Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								int slectCnt = sessiondetail.SelectStatusInProgressBar("Ready");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if (LstUserPermissions.contains("SESSIONS_REMOVE_STUDENTS_RESTRICTED")) {
											if (sessiondetail.deleteButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Remove Student from teacher session , Remove Students button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Remove Student from teacher session , Remove Students button is not displayed");
										}
										
										if (LstUserPermissions.contains("TEST_ATTEMPT_ADD_IRREGULARITY")) {
											if (sessiondetail.verifyEnterIrregularityButton())
												UMReporter.log(Status.PASS,
														"User have access to add Irregularity, Enter Irregularity button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to add Irregularity, Enter Irregularity button is not displayed");
										}

										if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
											if (sessiondetail.printSelectedTicketsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Print Test Tickets,  Print Selected Student button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Print Test Tickets,  Print Selected Student button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_DOWNLOAD_TEST_FORM")) {
											if (sessiondetail.downloadTest_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Download Test, Download Test button is displayed");
											else
												UMReporter.log(Status.SKIP,
														"User have access to Download Test, Download Test button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_RESET_STUDENT_PASSWORD")) {
											if (sessiondetail.resetpasswordButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Reset Student Password, Reset Student Password button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Reset Student Password, Reset Student Password button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_UPDATE_STUDENT_TEST_STATUS")) {
											if (sessiondetail.updateStatusButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Update Status, Update Status button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Update Status, Update Statuss button is not displayed");
										}
										if (LstUserPermissions
												.contains("TEST_ATTEMPT_PROCTOR_STATUS_NOTTESTED_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if (LstUpdateActions.contains("Not Tested"))
													UMReporter.log(Status.PASS,
															"User have access to 'Not Tested', Not Tested option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Not Tested, Not Tested options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Not Tested, Update Status is not displayed");
										}

										sessiondetail.SelectonStuCheckbox(1);
									} else
										UMReporter.log(Status.SKIP,
												"No ready status students records to verify Remove, Download test, Reset Password, Print Ticket");

									// Select Requires Hand Scoring Status
									if (!sessiondetail.Verify_Session_Status_Blade())
										sessiondetail.SessionStatusBladeExpand("Yes");
									slectCnt = sessiondetail.SelectStatusInProgressBar("Requires Hand Scoring");

									if (slectCnt > 0) {
										lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
										if (lstSelectedStudent_SD.size() > 0) {
											if (LstUserPermissions.contains("SESSIONS_ACCESS_HAND_SCORE")) {
												if (sessiondetail.HandScoreButton_isVisible())
													UMReporter.log(Status.PASS,
															"User have access to Handscore, Handscore button is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Handscore, Handscore button is not displayed");
											}
											if (LstUserPermissions.contains("TEST_ATTEMPT_PROCTOR_STATUS_UPDATE")) {
												if (sessiondetail.updateStatusButton_isVisible()) {
													List<String> LstUpdateActions = sessiondetail
															.GetUpdateStatusActions();
													if ((LstUpdateActions.contains("Void")))
														UMReporter.log(Status.PASS,
																"User have access to 'Void', Void option is displayed");
													else if ((LstUpdateActions.contains("Not Tested")))
														UMReporter.log(Status.PASS,
																"User have access to 'Not Tested', Not Tested option is displayed");
													else
														UMReporter.log(Status.FAIL,
																"User have access to Proctor, Void,DNR, Not Tested options is not displayed");
												} else
													UMReporter.log(Status.SKIP,
															"User have access to Not Tested, Update Status is not displayed");
											}

											if (LstUserPermissions
													.contains("TEST_ATTEMPT_PROCTOR_STATUS_VOID_UPDATE")) {
												if (sessiondetail.updateStatusButton_isVisible()) {
													List<String> LstUpdateActions = sessiondetail
															.GetUpdateStatusActions();
													if ((LstUpdateActions.contains("Void")))
														UMReporter.log(Status.PASS,
																"User have access to 'Void', Void option is displayed");
													else
														UMReporter.log(Status.FAIL,
																"User have access to Proctor, Void options is not displayed");
												} else
													UMReporter.log(Status.SKIP,
															"User have access to Proctor, Void is not displayed");
											}

										}
									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No Requires Hand Scoring status student records to verify handscore ");

								// Select Report Ready Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								slectCnt = sessiondetail.SelectStatusInProgressBar("Report Ready");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if (LstUserPermissions.contains("SESSIONS_ACCESS_REPORTS")) {
											if (sessiondetail.ReportsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Reports,  Reports button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to  Reports,  Reports button is not displayed");
										}
									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No Report Ready status student records to verify Reports ");
							}

							if (LstUserPermissions.contains("VIEW_STUDENT_PROFILE_RESTRICTED")) {
								List<String> MapDgOrgDet = sessiondetail.verifyStuGridHyperlinks(1);
								if (MapDgOrgDet != null)
									UMReporter.log(Status.PASS,
											"User have access to view student details :" + MapDgOrgDet);
								else
									UMReporter.log(Status.FAIL, "User restricted to view student details ");
							}

						} else
							UMReporter.log(Status.FAIL, "The Session details is not displayed");
					} else
						UMReporter.log(Status.SKIP, "No records found in Sessions list");
				}
			}
		} else
			UMReporter.log(Status.PASS, "User restricted for Sessions");
	}

	@Given("^User permissions for Low Stakes in Sessions page$")
	public void User_Permission_to_LowSTakesSessions_page() throws Exception {

		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL, "LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		List<String> LstUserPermissions = Constants.PERMISSIONS;

		// Switch Org
		String OrgName = FileReaderManager.getInstance().getJsonReader().getSelectOrgName("District");
		// Change the Org Details if not expected
		if (!home.Func_VerifyOrgName(OrgName))
			home.Func_ChangeOrganization(OrgName);
		// Not high stakes
		if ((LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) && (LstUserPermissions.contains("ACCESS_LOW_STAKES"))
				&& (!LstUserPermissions.contains("ACCESS_HIGH_STAKES"))) {
			UMReporter.log(Status.INFO, "Given :User permissions in Low Stakes Sessions page");
			home.MenuOtion("Sessions Overview", "");
			if (Sessionlist.IsSessionListTableExist()) {
				UMReporter.log(Status.PASS, "User have access Sessions in the hamburger menu");
				List<String> MapDgOrgColHeader = Sessionlist.verifySessionSearchresultsDetails(1);
				if (MapDgOrgColHeader != null)
					UMReporter.log(Status.PASS,
							"User have access to view list of Low stakes Sessions :" + MapDgOrgColHeader);

				if (LstUserPermissions.contains("CREATE_TEST_SESSIONS")) {
					if (Sessionlist.CreateSessionTab_isVisible())
						UMReporter.log(Status.PASS,
								"User have access to Create Session, Create Session Tab is visible");
					else
						UMReporter.log(Status.SKIP,
								"User have access to Create Session, Create Session Tab is not visible");
				}

				// Search Session
				Sessionlist.Searchfill_SessionName(CommonFunctions.getTestData("$session"));
				Sessionlist.clicksearchicon();

				if (LstUserPermissions.contains("DELETE_TEST_SESSIONS_LOW_STAKES")) {
					lstSelectedSess = Sessionlist.SelectonSessionCheckbox(1);
					if (lstSelectedSess.size() > 0) {
						if (Sessionlist.deleteButton_isVisible())
							UMReporter.log(Status.PASS,
									"User have access to Delete Session for Low stakes session, Delete button is visible");
						else
							UMReporter.log(Status.FAIL,
									"User have access to Delete Session for Low stakes session, Delete button is not visible");
					}
				}

				if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
					MapSessFields = Sessionlist.SelectSessionList();
					if (MapSessFields != null) {
						if (sessiondetail.verifySessionDetailsNavigation()) {
							// Expand the Session Info
							sessiondetail.SessionInfoExpand("Yes");
							// Verify the Session details page displayed
							sessiondetail.verifyViewSessionDetails(MapSessFields);

							if (LstUserPermissions.contains("SESSIONS_EDIT_SESSION_LOW_STAKES")) {
								if (sessiondetail.EditButton_isVisible())
									UMReporter.log(Status.PASS,
											"User have access to Edit Session for Low stakes session, Edit button is displayed");
								else
									UMReporter.log(Status.FAIL,
											"User have access to Edit Session for Low stakes session, Edit button is not displayed");
							}

							// Students
							if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
								if (sessiondetail.Verify_Session_StudentList())
									UMReporter.log(Status.PASS,
											"User have access to View Student List in Session details page");

								if (LstUserPermissions.contains("SESSIONS_ADD_STUDENTS_LOW_STAKES")) {
									if (sessiondetail.AddStudentsButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to Add Student to a Low stakes session , Add Students button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Add Student to a Low stakes session ,  Add Students button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
									if (sessiondetail.printAllTicketsButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to Print Test Tickets,  PrintAllTickets button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to Print Test Tickets,  PrintAllTickets button is not displayed");
								}

								if (LstUserPermissions.contains("SESSIONS_PRINT_ACCOMMODATIONS")) {
									if (sessiondetail.ViewAccommButton_isVisible())
										UMReporter.log(Status.PASS,
												"User have access to View Accommodations, View Accommodations button is displayed");
									else
										UMReporter.log(Status.FAIL,
												"User have access to View Accommodations, View Accommodations button is not displayed");
								}

								// Select Ready Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								int slectCnt = sessiondetail.SelectStatusInProgressBar("Ready");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if (LstUserPermissions.contains("SESSIONS_REMOVE_STUDENTS_LOW_STAKES")) {
											if (sessiondetail.deleteButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Remove Student from Low stakes session , Remove Students button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Remove Student from Low stakes session , Remove Students button is not displayed");
										}
										
										if (LstUserPermissions.contains("SESSIONS_MOVE_STUDENTS_LOW_STAKES")) {
											if (sessiondetail.moveButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Move Student from Low stakes session , Remove Students button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Move Student from Low stakes session , Remove Students button is not displayed");
										}
										
										if (LstUserPermissions.contains("TEST_ATTEMPT_ADD_IRREGULARITY")) {
											if (sessiondetail.verifyEnterIrregularityButton())
												UMReporter.log(Status.PASS,
														"User have access to add Irregularity, Enter Irregularity button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to add Irregularity, Enter Irregularity button is not displayed");
										}

										if (LstUserPermissions.contains("SESSIONS_PRINT_AUTH_TICKETS")) {
											if (sessiondetail.printSelectedTicketsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Print Test Tickets,  Print Selected Student button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Print Test Tickets,  Print Selected Student button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_DOWNLOAD_TEST_FORM")) {
											if (sessiondetail.downloadTest_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Download Test, Download Test button is displayed");
											else
												UMReporter.log(Status.SKIP,
														"User have access to Download Test, Download Test button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_RESET_STUDENT_PASSWORD")) {
											if (sessiondetail.resetpasswordButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Reset Student Password, Reset Student Password button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Reset Student Password, Reset Student Password button is not displayed");
										}
										if (LstUserPermissions.contains("SESSIONS_UPDATE_STUDENT_TEST_STATUS")) {
											if (sessiondetail.updateStatusButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Update Status, Update Status button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Update Status, Update Statuss button is not displayed");
										}
										if (LstUserPermissions
												.contains("TEST_ATTEMPT_PROCTOR_STATUS_NOTTESTED_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if (LstUpdateActions.contains("Not Tested"))
													UMReporter.log(Status.PASS,
															"User have access to 'Not Tested', Not Tested option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Not Tested, Not Tested options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Not Tested, Update Status is not displayed");
										}

									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No ready status students records to verify Remove, Download test, Reset Password, Print Ticket");

								// Select Requires Hand Scoring Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								slectCnt = sessiondetail.SelectStatusInProgressBar("Requires Hand Scoring");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if (LstUserPermissions.contains("SESSIONS_ACCESS_HAND_SCORE_LOW_STAKES")) {
											if (sessiondetail.HandScoreButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Handscore to Low stakes session, Handscore button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to Handscore to Low stakes session, Handscore button is not displayed");
										}
										if (LstUserPermissions.contains("TEST_ATTEMPT_PROCTOR_STATUS_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if ((LstUpdateActions.contains("Void")))
													UMReporter.log(Status.PASS,
															"User have access to 'Void', Void option is displayed");
												else if ((LstUpdateActions.contains("Not Tested")))
													UMReporter.log(Status.PASS,
															"User have access to 'Not Tested', Not Tested option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Proctor, Void,DNR, Not Tested options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Not Tested, Update Status is not displayed");
										}

										if (LstUserPermissions.contains("TEST_ATTEMPT_PROCTOR_STATUS_VOID_UPDATE")) {
											if (sessiondetail.updateStatusButton_isVisible()) {
												List<String> LstUpdateActions = sessiondetail.GetUpdateStatusActions();
												if ((LstUpdateActions.contains("Void")))
													UMReporter.log(Status.PASS,
															"User have access to 'Void', Void option is displayed");
												else
													UMReporter.log(Status.FAIL,
															"User have access to Proctor, Void options is not displayed");
											} else
												UMReporter.log(Status.SKIP,
														"User have access to Proctor, Void is not displayed");
										}

									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No Requires Hand Scoring status student records to verify handscore ");

								// Select Report Ready Status
								if (!sessiondetail.Verify_Session_Status_Blade())
									sessiondetail.SessionStatusBladeExpand("Yes");
								slectCnt = sessiondetail.SelectStatusInProgressBar("Report Ready");

								if (slectCnt > 0) {
									lstSelectedStudent_SD = sessiondetail.SelectonStuCheckbox(1);
									if (lstSelectedStudent_SD.size() > 0) {
										if (LstUserPermissions.contains("SESSIONS_ACCESS_REPORTS_LOW_STAKES")) {
											if (sessiondetail.ReportsButton_isVisible())
												UMReporter.log(Status.PASS,
														"User have access to Reports to Low stakes session,  Reports button is displayed");
											else
												UMReporter.log(Status.FAIL,
														"User have access to  Reports to Low stakes session,  Reports button is not displayed");
										}
									}
									sessiondetail.SelectonStuCheckbox(1);
								} else
									UMReporter.log(Status.SKIP,
											"No Report Ready status student records to verify Reports ");
							}

							if (LstUserPermissions.contains("SESSIONS_VIEW_STUDENT_PROFILE")) {
								List<String> MapDgOrgDet = sessiondetail.verifyStuGridHyperlinks(1);
								if (MapDgOrgDet != null)
									UMReporter.log(Status.PASS,
											"User have access to view student details :" + MapDgOrgDet);
								else
									UMReporter.log(Status.FAIL, "User restricted to view student details ");
							}

						} else
							UMReporter.log(Status.FAIL, "The Session details is not displayed");
					} else
						UMReporter.log(Status.SKIP, "No records found in Sessions list");
				}

				home.SelectCustomerLogo();

			}
		}

		else
			UMReporter.log(Status.PASS, "User restricted for Sessions");
	}

	@Given("Verify Print Accommodation button is displayed in Session details page")
	public void verify_Print_Accommodation_button_is_displayed_in_Session_details_page() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Print Accommodation button is displayed in Session details page");
		boolean btnPrintAccomm = sessiondetail.PrintAccommButton_isVisible();
		if (btnPrintAccomm)
			UMReporter.log(Status.PASS, "Print Accommodation button is displayed");
		else
			UMReporter.log(Status.FAIL, "Print Accommodation button is not displayed");
	}

	@Given("Verify View Accommodation button is displayed in Session details page")
	public void verify_view_accommodation_button_is_displayed_in_session_details_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the View Accommodation button is displayed in Session details page");
		boolean btnViewAccomm = sessiondetail.ViewAccommButton_isVisible();
		if (btnViewAccomm)
			UMReporter.log(Status.PASS, "View Accommodation button is displayed");
		else
			UMReporter.log(Status.FAIL, "View Accommodation button is not displayed");
	}

	@When("Click on Print Accommodation button")
	public void click_on_Print_Accommodation_button() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the user is able to click on the Print Accommodation button");
		if (sessiondetail.PrintAccommButton_isVisible()) {
			boolean btnPrintAccomm = sessiondetail.clickPrintAccommButton();
			if (btnPrintAccomm)
				UMReporter.log(Status.PASS, "User is able to click on Print Accommodation button");
			else
				UMReporter.log(Status.FAIL, "User is not able to click on Print Accommodation button");
		} else
			UMReporter.log(Status.SKIP, "Print Accommodation button not exist");

	}

	@When("Click on View Accommodation button")
	public void click_on_view_accommodation_button() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the user is able to click on the View Accommodation button");
		if (sessiondetail.ViewAccommButton_isVisible()) {
			boolean btnViewAccomm = sessiondetail.clickViewAccommButton();
			if (btnViewAccomm) {
				SelectedViewAccomFlag = true;
				UMReporter.log(Status.PASS, "User is able to click on View Accommodation button");
			} else
				UMReporter.log(Status.FAIL, "User is not able to click on View Accommodation button");
		} else
			UMReporter.log(Status.SKIP, "View Accommodation option not exist");
	}

	@Then("Verify to display accommodations summary screen")
	public void verify_to_display_accommodations_summary_screen() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Accommodation Summary screen is displayed in Session details page");
		if (SelectedViewAccomFlag) {
			boolean accommSummary = sessiondetail.VerifyAccommHeadersContent(Constants.AccommodationModalHeaderTitle,
					Constants.AccommodationNeededHeader, Constants.AccommodationStudentHeader,Constants.AccommodationProctorLogin_HR,Constants.AccommodationProctorLogin_HS);
			if (accommSummary)
				UMReporter.log(Status.PASS, "Accommodation summary screen is displayed");
			else
				UMReporter.log(Status.FAIL, "Accommodation summary screen is not displayed");
		} else
			UMReporter.log(Status.SKIP, "View Accommodation not selected");
	}

	@Then("Verify accommodation list is displayed in accommodation summary")
	public void verify_accommodation_list_is_displayed_in_accommodation_summary() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Accommodation list is displayed in Accommodation Summary");
		if (SelectedViewAccomFlag) {
			boolean accommSummary = sessiondetail.accommList_isVisible();
			if (accommSummary) {
				List<String> LstAccomodations = sessiondetail.GetAccomNeededModalContent();
				if (LstAccomodations != null)
					if (LstAccomodations.size() > 0)
						UMReporter.log(Status.PASS,
								"Accommodation list is displayed in Accommodation Needed :" + LstAccomodations);
					else
						UMReporter.log(Status.PASS,
								"No Accommodation needed list is displayed in Accommodation Summary ");
				else
					UMReporter.log(Status.PASS, "No Accommodation needed list is displayed in Accommodation Summary");

			} else
				UMReporter.log(Status.FAIL, "Accommodation list is not displayed in Accommodation Summary");
		} else
			UMReporter.log(Status.SKIP, "View Accommodation not selected");
	}

	@Then("Verify Student list is displayed in accommodation summary")
	public void verify_Student_list_is_displayed_in_accommodation_summary() throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the Accommodation student list is displayed in Accommodation Summary");
		if (SelectedViewAccomFlag) {
			boolean accommSummary = sessiondetail.accommStudList_isVisible();
			if (accommSummary) {
				List<HashMap<String, String>> LstStudAccomodations = sessiondetail.GetStudentAccomsModalContent(2);
				if (LstStudAccomodations != null)
					UMReporter.log(Status.PASS, "Students Accommodation :" + LstStudAccomodations);
				else
					UMReporter.log(Status.PASS, "Accommodation Student list is displayed in Accommodation Summary");
			} else
				UMReporter.log(Status.FAIL, "Accommodation student list is not displayed in Accommodation Summary");
		} else
			UMReporter.log(Status.SKIP, "View Accommodation not selected");

	}

	@Then("Verify Download option in the View Accomodation modal window")
	public void verify_downlad_link_displayed_in_modal_window() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify Download option in the View Accomodation modal window");
		if (SelectedViewAccomFlag) {
			boolean downloadLink = sessiondetail.downloadLink_isVisible();
			if (downloadLink) {
				sessiondetail.clickdownloadAccommodations();
				// Get Latest file
				File downloadedfile = csvfreader.getLatestDownloadFile("pdf");
				if (downloadedfile != null) {
					String exportfilename = downloadedfile.getName();
					System.out.println("Download filenme : " + exportfilename);
					UMReporter.log(Status.PASS, "Selected the Download link and downloded PDF File :" + exportfilename);
				} else
					UMReporter.log(Status.PASS, "Selected the Download link ");
			} else
				UMReporter.log(Status.FAIL, "Download link is not displayed in the modal window");
		} else
			UMReporter.log(Status.SKIP, "View Accommodation not selected");

	}

	@Then("Close accommodations summary screen")
	public void close_accommodations_summary_screen() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Accommodation Summary screen is closed");
		if (SelectedViewAccomFlag) {
			sessiondetail.clickAccommSummaryCloseBtn();
			boolean accommSummary = sessiondetail.accommSummary_isVisible();
			if (!accommSummary)
				UMReporter.log(Status.PASS, "Accommodation summary screen is closed");
			else
				UMReporter.log(Status.FAIL, "Accommodation summary screen is not closed");
		} else
			UMReporter.log(Status.SKIP, "View Accommodation not selected");
	}

	@Given("^Verify the Section Progress content in Session details page$")
	public void Verify_Dashboard_Students_Registered_Widget_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Section Progress content in Session details page");
		CommonUtility._sleepForGivenTime(3000);
		CommonFunctions.waitUntilLoadingSpinner(10);
		lstSectionCards=null;
		if (sessiondetail.Verify_Session_Progress_Blade()) {
			if (!sessiondetail.Check_Session_Progress_Blade_expand())
				sessiondetail.SessionProgressBladeExpand("Yes");
			// Get Section Progress content
			lstSectionCards = sessiondetail.GetSectionContent();
			if (lstSectionCards != null)
				UMReporter.log(Status.PASS, "The Section Progress content : " + lstSectionCards);
			else
				UMReporter.log(Status.FAIL, "Section Progress no data to display");
			
			sessiondetail.SessionProgressBladeExpand("No");
		} else
			UMReporter.log(Status.SKIP, "Section Progress blade not visible");
	}

	@Given("Verify View Unsubmit button is displayed in Session details page")
	public void verify_View_Unsubmit_button_is_displayed_in_Session_details_page() throws IOException {
		UMReporter.log(Status.INFO, "Then: Verify Unsubmit button is displayed in session detail page");
		if (lstSelectedStudent_SD != null) {
			boolean unsubmitVisible = sessiondetail.unsubmitButton_isVisible();
			if (unsubmitVisible)
				UMReporter.log(Status.PASS, "Unsubmit button is displayed");
			else
				UMReporter.log(Status.FAIL, "Unsubmit button is not displayed");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}

	@When("Click on View Unsubmit button")
	public void click_on_View_Unsubmit_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Unsubmit button in session detail page");
		if (lstSelectedStudent_SD != null) {
			boolean isbtnclicked = sessiondetail.clickUnsubmitButton();
			if (isbtnclicked) {
				UMReporter.log(Status.PASS, "Selected the Unsubmit button");
			} else
				UMReporter.log(Status.FAIL, "Unable to click the Unsubmit button");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");
	}

	@When("click on Unsubmit button on Unsubmit Selected Test pop-up")
	public void click_on_Unsubmit_button_on_Unsubmit_Selected_Test_pop_up() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Unsubmit button in session detail page");
		// Verify the Click Confirm in pop up
		boolean flag = CommonFunctions.ConfirmPopupActionBtn("Unsubmit");
		// CommonUtility._sleepForGivenTime(500);
		if (flag)
			UMReporter.log(Status.PASS, "Selected the Unsubmit button");
		else
			UMReporter.log(Status.FAIL, "Unsubmit button is not visible");
	}

	@When("verified the Success message display for Unsubmit  were successfully unsubmitted")
	public void verified_the_Success_message_display_for_Unsubmit_were_successfully_unsubmitted(String messages)
			throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the success message displayed after Unsubmit in Session details page as " + messages);
		boolean flag;
		if (sessiondetail.verifySuccessMessageVisible()) {
			if (messages.contains("<X>"))
				if (lstSelectedStudent_SD.size() != 0) // Studentcount
					messages = messages.replace("<X>", String.valueOf(lstSelectedStudent_SD.size()));

			if (messages.contains("<sessionname>"))
				if (sSelectedSession != null) // Session name
					messages = messages.replace("<sessionname>", sSelectedSession);

			flag = sessiondetail.verifySuccessMessage(messages);
			if (flag)
				UMReporter.log(Status.PASS,
						"Verified the success message displayed in Session details page:" + messages);
			else
				UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);

			sessiondetail.Close_Alerts();
		} else
			UMReporter.log(Status.SKIP, "The success message is not displayed");
	}

	@When("^Click on Move option in Session details page$")
	public void Click_MoveStudents_option_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Move option in Session details page");
		boolean isbtnclicked = sessiondetail.clickMoveoption();
		if (isbtnclicked)

			UMReporter.log(Status.PASS, "Selected the Move Option");

		else
			UMReporter.log(Status.FAIL, "Unable to click the Move option");

	}

	@When("^Click on Close icon in Move prompt$")
	public void Click_MoveClose_icon_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Close icon in Move prompt");
		boolean isbtnclicked = sessiondetail.clickCloseIcon();
		if (isbtnclicked)

			UMReporter.log(Status.PASS, "Selected the Close icon");

		else
			UMReporter.log(Status.FAIL, "Unable to click the Close icon");

	}

	@When("^Click on dropdown icon in Move prompt$")
	public void Click_dropdown_icon_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on dropdown icon in Move prompt");
		boolean isbtnclicked = sessiondetail.clickPromptdropdown();
		if (isbtnclicked)

			UMReporter.log(Status.PASS, "Selected the dropdown icon");

		else
			UMReporter.log(Status.FAIL, "Unable to click the dropdown icon");

	}

	@When("^User move student test to (.*) sesson in Session details$")
	public void Click_MoveSession_dropdown_icon_inSessionDetails(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When: User move student test to sesson in Session details");
		// Get from Testdata
		if (SeachText.indexOf("$") >= 0)
			SeachText = CommonFunctions.getTestData(SeachText);

		boolean isbtnclicked = sessiondetail.MovetoSessionDropdown(SeachText);
		if (isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the dropdown icon");

		else
			UMReporter.log(Status.FAIL, "Unable to click the dropdown icon");

	}
	
	@When("^Click on Session in Move prompt$")
	public void Click_Session_in_Moveprompt() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on session in Move prompt");
		boolean isbtnclicked = sessiondetail.clicksessionRow();
		if (isbtnclicked)

			UMReporter.log(Status.PASS, "Selected the session ");

		else
			UMReporter.log(Status.FAIL, "Unable to click the session ");
	}

	@When("^Click on Move button in Move prompt$")
	public void Click_Movebutton_in_Moveprompt() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Move button in Move prompt");
		boolean isbtnclicked = sessiondetail.clickMovebutton();
		if (isbtnclicked) {
			UMReporter.log(Status.PASS, "Move button is Clicked ");
			int count=0;
			while ((addstudentsession.Verify_Progressbar_Visible()) && (count < 10)) {
				CommonUtility._sleepForGivenTime(1000);
				count = count + 1;
			}

		}

		else
			UMReporter.log(Status.FAIL, "Unable to click the Move button ");
	}

	@When("^Click on Cancel button in Move prompt$")
	public void Click_Cancelbutton_in_Moveprompt() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Cancel button in Move prompt");
		boolean isbtnclicked = sessiondetail.clickCancelbutton();
		if (isbtnclicked)

			UMReporter.log(Status.PASS, "Cancel button is Clicked ");

		else
			UMReporter.log(Status.FAIL, "Unable to click the Cancel button ");
	}

	@Then("^Verify the success message displayed after student moved from Session details page as (.*)$")
	public void verify_success_message_gets_displayed_aftermove_on_SessionDetails_page(String messages)
			throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the success message displayed after Move from Session details page as " + messages);
		boolean flag;
		if (sessiondetail.verifySuccessMessageVisible()) {
			if (messages.contains("<X>"))
				if (lstSelectedStudent_SD.size() != 0) // Studentcount
					messages = messages.replace("<X>", String.valueOf(lstSelectedStudent_SD.size()));

			flag = sessiondetail.verifySuccessMessage(messages);
			if (flag) {
				UMReporter.log(Status.PASS,
						"Verified the success message displayed in Session details page:" + messages);
				IsStudMoved=true;
			}
			else {
				String errormsg=sessiondetail.getErrorMessage();
				if (errormsg!=null)
					UMReporter.log(Status.SKIP, "The following error message is displayed :"+errormsg);
				else
					UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
			}

			sessiondetail.Close_Alerts();
		} else
			UMReporter.log(Status.SKIP, "The success message is not displayed");
	}

	@Then("^Verify the Selected Student moved from Student list in Session details page$")
	public void verify_Selected_Student_moved_from_Students_list() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Selected Students moved from Student list in Session details page");
		List<String> removedStudent = null;
		if ((lstSelectedStudent_SD != null)&&(IsStudMoved)) {
			removedStudent = new ArrayList<String>();
			for (String stu : lstSelectedStudent_SD) {
				List<String> MapDgStuColHeader = sessiondetail.verifyStudSearchresultsDetailsfromlist(stu);
				if (MapDgStuColHeader == null)
					removedStudent.add(stu);
				else {
					if (MapDgStuColHeader.size() == 0)
						removedStudent.add(stu);
				}
			}
			if (removedStudent.size() > 0)
				UMReporter.log(Status.PASS,
						"The following student move from Student List of Session details Page :" + removedStudent);
			else
				UMReporter.log(Status.FAIL, "The following students lists are not move from Session details Page :"
						+ lstSelectedStudent_SD);
		} else
			UMReporter.log(Status.SKIP, "The students are not found/Moved");
	}

	@Then("^Verify Add Irregularity button is visible and able to click on it$")
	public void verify_Add_Irregularity_button_visible_and_clickable() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Add Irregularity button is visible and able to click on it");
		boolean flag = sessiondetail.verifyAddIrregularityButtonAndClickOnit();
		if (flag)
			UMReporter.log(Status.PASS, "Add Irregularity button is visible and able to click on it");
		else
			UMReporter.log(Status.FAIL, "Add Irregularity button is not visible");

	}

	@Then("^Verify Add Irregularities modal window is opened$")
	public void verify_Add_Irregularities_modal_window_opened() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Add Irregularities modal window is opened");
		boolean flag = sessiondetail.verifyIrregularitiesModalWindowOpened();
		if (flag)
			UMReporter.log(Status.PASS, "Add Irregularities modal window is opened");
		else
			UMReporter.log(Status.FAIL, "Add Irregularities modal window is not opened");

	}

	@Then("^Verify the (.*) on Add Irregularities modal window$")
	public void verify_text_on_add_irregularities_window(String text) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the text on Add Irregularities modal window");
		boolean flag;
		if (text.contains("<?>"))
			if (iSelectedStudentCount != 0) // Studentcount
				text = text.replace("<?>", String.valueOf(iSelectedStudentCount));
		flag = sessiondetail.verifyTextOnIrregWindow(text);
		if (flag)
			UMReporter.log(Status.PASS, "Text is verified on Add Irregularities modal window as " + text);
		else
			UMReporter.log(Status.FAIL, "Text is not verified on Add Irregularities modal window");

	}

	@Then("^User selects the irregularity$")
	public void user_fills_the_irregularities(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "Then : User selects the irregularity");
		String Fieldname = null;
		boolean isfieldLabelExist = false;
		boolean FilledFieldFlag = false;

		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);

		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("Irregularities");
			isfieldLabelExist = sessiondetail.VerifyIrregularitiesLabel(Fieldname);

			if (isfieldLabelExist) {
				FilledFieldFlag = sessiondetail.FillIrregularities(Fieldname);
			}

			if (FilledFieldFlag)
				UMReporter.log(Status.PASS, "Irregularity is selected");
			else
				UMReporter.log(Status.FAIL, "Irregularity is not selected");
		}

	}
	
	@Then("^User enter the (.*) provided exception$")
	public void user_select_the_exceptions(String Exceptions) throws Exception {
		UMReporter.log(Status.INFO, "Then : User enter the provided exception :"+Exceptions);
		boolean FilledFieldFlag = false;
		if (sessiondetail.verifyIrregularitiesModalWindowOpened()) {
			FilledFieldFlag = sessiondetail.FillIrregularities(Exceptions);
			if (FilledFieldFlag)
				UMReporter.log(Status.PASS, "Irregularity is selected");
			else
				UMReporter.log(Status.FAIL, "Irregularity is not selected");
		}
		else
			UMReporter.log(Status.FAIL, "Enter Exception modal window is not opened");
	}

	@Then("^User adds the (.*) in comment box$")
	public void user_add_comments(String comment) throws Exception {
		UMReporter.log(Status.INFO, "Then : User adds the comment in comment box");
		boolean flag = sessiondetail.fillCommentBox(comment);
		if (flag)
			UMReporter.log(Status.PASS, "Comment is addedd");
		else
			UMReporter.log(Status.FAIL, "Comment is not addedd");

	}

	@Then("^Verify Cancel button is visible and clickable$")
	public void verify_cancel_button_visible_and_clickable() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Cancel button is visible and clickable");
		boolean flag = sessiondetail.verifyCancelButtonVisibleAndClickable();
		if (flag)
			UMReporter.log(Status.PASS, "Cancel button is visible and clickable");
		else
			UMReporter.log(Status.FAIL, "Cancel button is not visible");

	}

	@Then("^Verify Save and Close button is visible and able to click on it$")
	public void verify_save_and_close_button_visible_and_click_on_it() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Save and Close button is visible and able to click on it");
		boolean flag = sessiondetail.clickSaveAndCloseButton();
		if (flag) {
			UMReporter.log(Status.PASS, "Save and Close button is visible and able to click on it");
			int count = 0;
			while ((addstudentsession.Verify_Progressbar_Visible()) && (count < 10)) {
				CommonUtility._sleepForGivenTime(1000);
				count = count + 1;
			}
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.waitUntilLoadingSpinner(10);
			
		}
		else
			UMReporter.log(Status.FAIL, "Save and Close button is not visible");

	}

	@Then("^Verify the success message after adding irregularities as (.*)$")
	public void verify_success_message(String successmessage) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the success message after adding irregularities as " + successmessage);
		boolean flag = sessiondetail.verifySuccessMessageafteraddingirreg(successmessage);
		if (flag)
			UMReporter.log(Status.PASS, "Success message " + successmessage + " is verified");
		else
			UMReporter.log(Status.FAIL, "Success message " + successmessage + " is not verified");
		
		sessiondetail.Close_Alerts();

	}

	@Then("^Verify Irreg capsule is visible and able to click on it$")
	public void verify_irreg_capsule_visible_and_click_on_it() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Irreg capsule is visible and able to click on it");
		SelectedViewIrregFlag = sessiondetail.verifyIrregCapsuleVisibleAndClickable();
		if (SelectedViewIrregFlag)
			UMReporter.log(Status.PASS, "Irreg capsule is visible and click on it");
		else
			UMReporter.log(Status.SKIP, "Irreg capsule is not visible");

	}

	@Then("^Verify View Irregularities modal window is opened$")
	public void verify_View_Irregularities_modal_window_opened() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify View Irregularities modal window is opened");
		if (SelectedViewIrregFlag) {
			boolean flag = sessiondetail.verifyIrregularitiesModalWindowOpened();
			if (flag)
				UMReporter.log(Status.PASS, "View Irregularities modal window is opened");
			else
				UMReporter.log(Status.FAIL, "View Irregularities modal window is not opened");
		}
		else
			UMReporter.log(Status.SKIP, "Irreg capsule is not visible");

	}

	@Then("^Verify the (.*) on view irregularities modal window$")
	public void verify_headertext_on_view_irregularities_modal_window(String headertext) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the header text on view irregularities modal window");
		boolean flag;
		if (SelectedViewIrregFlag) {
			String studname = sessiondetail.getStudentName(1);
			flag = sessiondetail.verifyTextOnIrregWindow(headertext+" "+studname);
			if (flag)
				UMReporter.log(Status.PASS,
						"The header text " + headertext + " is verified on view irregularities modal window");
			else
				UMReporter.log(Status.FAIL,
						"The header text " + headertext + " is not verified on view irregularities modal window");
		}
		else
			UMReporter.log(Status.SKIP, "Irreg capsule is not visible");

	}

	@Then("^Verify the irregularities on view modal window with selected irregularities$")
	public void verify_irregularities_with_selected_irregularities(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the irregularities on view modal window with selected irregularities");
		String Fieldname = null;
		List<String> expected = new ArrayList<String>();
		List<String> actual = new ArrayList<String>();
		boolean flag = false;
		if (SelectedViewIrregFlag) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
	
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Irregularities");
				expected.add(Fieldname);
			}
			Collections.sort(expected);
			actual = sessiondetail.listOfIrregularities();
			//flag = actual.equals(expected);
			flag = Collections.disjoint(expected,actual);
			if (!flag)
				UMReporter.log(Status.PASS, "Irregularities are verified with selected irregularities");
			else
				UMReporter.log(Status.FAIL, "Irregularities are not verified with selected irregularities");
		}
		else
			UMReporter.log(Status.SKIP, "Irreg capsule is not visible");
	}
	
	@Then("^Verify irregularities list for selected student in Session details$")
	public void verify_irregularitieslist_from_selected_irregularities() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify irregularities list for selected student in Session details");
		List<String> actual = new ArrayList<String>();
		actual = sessiondetail.listOfIrregularities();
		if (actual.size()>0)
			UMReporter.log(Status.PASS, "The following Irregularities for selected student : "+actual);
		else
			UMReporter.log(Status.FAIL, "Irregularities are not verified with selected irregularities");
	}

	@Then("^Close the view irregularities modal window$")
	public void close_irregularites_window() throws Exception {
		UMReporter.log(Status.INFO, "Then : Close the view irregularities modal window");
		boolean flag = sessiondetail.closeIrregularitesWindow();
		if (flag)
			UMReporter.log(Status.PASS, "View Irregularities modal window is closed");
		else
			UMReporter.log(Status.FAIL, "View Irregularities modal window is not closed");

	}
	
	@Then("^Verify the accommodations from student list in session details$")
	public void Verify_accommodations_from_student_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the accommodations from student list in session details");
		HashMap<String, String> MapDgAccomRec  = sessiondetail.GetStudAccommfromlist(1,"Accom");
		if (MapDgAccomRec.size()>0)
			UMReporter.log(Status.PASS, "The student accommodations : "+MapDgAccomRec);
		else
			UMReporter.log(Status.SKIP, "No accommodation from student list");

	}
	
	@Then("^User select the preview  test for student have (.*) accommodations in session details$")
	public void User_Select_preview_test_student_accommodations_from_student_list(String Accommodation) throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the preview  test for student have accommodations in session details");
		MapStudAccomSelected  = sessiondetail.SelectStudAccommfromlist(1,"Accom",Accommodation);
		if (MapStudAccomSelected.size()>0)
			UMReporter.log(Status.PASS, "Preview test for the "+Accommodation+" accommodations student : "+MapStudAccomSelected);
		else
			UMReporter.log(Status.SKIP, "No accommodation from student list");

	}
	
	@When("^Verify Preview test iframe and return to Session detail$")
	public void Verify_Previewform_Sessiondetailbutton_in_reportpage() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Preview test iframe and return to Session detail");
		if (MapStudAccomSelected.size()>0) {
			boolean flag = sessiondetail.PrviewTestIframe_isVisible();
			if (flag) 
				UMReporter.log(Status.PASS, "Verified Preview test iframe and return to session detail page");
			else
				UMReporter.log(Status.FAIL, "Not in Preview test Page");
			
			sessiondetail.clicksessiondetailnavigationtbtn();
		}
		else
			UMReporter.log(Status.SKIP, "No accommodation from student list");
	}
	
	@Then("Verify the Print Answer Sheet button display in Session details page")
	public void Verify_on_Print_Answer_Sheet_button_in_Session_details_page() throws Exception {
		UMReporter.log(Status.INFO, "When: Verify the Print Answer Sheet button display in Session details page");
		if (lstSelectedStudent_SD.size()>0) {
			if(sessiondetail.PrintAnswerSheets_isVisible()) 
				UMReporter.log(Status.PASS, "Print Answer Sheet(s) button is displayed");
			else 
				 UMReporter.log(Status.SKIP, "Print Answer Sheet(s) button is not displayed");
		}
		else 
			UMReporter.log(Status.SKIP, "No student record to verify Print Answer Sheet(s)");
	}
	
	
@Then("Click on Print Answer Sheet button in Session details page")
public void click_on_Print_Answer_Sheet_button_in_Session_details_page() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Print Answer Sheet(s) button in Session details page");
	if (lstSelectedStudent_SD.size()>0) {
		if(sessiondetail.PrintAnswerSheets_isVisible()) {
			CurrentWinHnd = CommonFunctions.GetCurrentWindowHandle();
			boolean isbtnclicked = sessiondetail.clickPrintAnswerSheetsButton();
			if (isbtnclicked) {
				int count = 0;
				CommonUtility._sleepForGivenTime(7000);
//				while ((addstudentsession.Verify_Progressbar_Visible()) && (count < 5)) {
//					CommonUtility._sleepForGivenTime(1000);
//					count = count + 1;
//				}
				UMReporter.log(Status.PASS, "Selected the Print Answer Sheet(s) button");
			} else
				UMReporter.log(Status.FAIL, "Unable to click the Print Answer Sheet(s) button");
		}
		else {
			//Remove checked if Print Answer not displayed
			 sessiondetail.SelectonStuCheckbox(1);
			 lstSelectedStudent_SD=null;
			 UMReporter.log(Status.SKIP, "Print Answer Sheet(s) button is not visible");
		}
	}
	else 
		UMReporter.log(Status.SKIP, "No student record to verify Print Answer Sheet(s)");
}

@Then("Verify Navigate to answerSheets page")
public void verify_Navigate_to_answerSheets_page() throws Exception {
	UMReporter.log(Status.INFO, "When: Verify Navigate to answerSheets page");	
	testTicketsWinHnd = WebDriverMain._getDriver().getWindowHandles();
	boolean studentInSession=false;
	for (String testTickets : testTicketsWinHnd) {
		if (!testTickets.equals(CurrentWinHnd)) {
			WebDriverMain._getDriver().switchTo().window(testTickets);
			studentInSession = sessiondetail.answerSheet_isVisible();
			WebDriverMain._getDriver().switchTo().window(CurrentWinHnd);
		}
	}
	if (studentInSession)
		UMReporter.log(Status.PASS,	"Student Answer Sheet PDF displayes in a separate tab" );
	else
		UMReporter.log(Status.SKIP, "Student Answer Sheet tab is not opened");
}

@Then("Verify Student answer sheets is displayed in answerSheets page")
public void verify_Student_answer_sheets_is_displayed_in_answerSheets_page() throws Exception {
	UMReporter.log(Status.INFO, "Then : Verify answerSheets is displayed in answerSheets page");
	boolean studentInSession = sessiondetail.answerSheet_isVisible();
	if (studentInSession)
		UMReporter.log(Status.PASS, "Student Answer Sheet displayes on answerSheets page");
	else
		UMReporter.log(Status.SKIP, "Student Answer Sheet tab is not opened");

}

@Then("Close answer sheets page")
public void close_answer_sheets_page() throws Exception {
	UMReporter.log(Status.INFO, "Then : Close answer sheets page");
	boolean flag = CommonFunctions.CloseAllWindowExceptCurrent(CurrentWinHnd);
	CommonUtility._sleepForGivenTime(1000);
	if (flag)
		UMReporter.log(Status.PASS, "Student answer sheets PDF page is closed");
	else
		UMReporter.log(Status.SKIP, "Student answer sheets PDF page is not Opened");
}

@When("^Click on Edit button in Irregularities modal window$")
public void Click_Edit_button_in_Irregularities_modal() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Edit button in Irregularities modal window");
	if (SelectedViewIrregFlag) {
	boolean isbtnclicked = sessiondetail.clickEditIrreguButton();
	if (isbtnclicked)
		UMReporter.log(Status.PASS, "Selected Edit button");
	else
		UMReporter.log(Status.FAIL, "Unable to select the Edit button");
	}
	else
		UMReporter.log(Status.SKIP, "Irreg capsule is not visible");

}

@Then("^User select Remove Irregularities checkbox in Irregularities modal window$")
public void user_removeIrregularity_comments_Irregularity() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select Remove Irregularities checkbox in Irregularities modal window");
	if (SelectedViewIrregFlag) {
		boolean flag = sessiondetail.RemoveIrregularityCheckbox();
		if (flag)
			UMReporter.log(Status.PASS, "Checked Remove Irregularities option");
		else
			UMReporter.log(Status.FAIL, "Not Checked Remove Irregularities option");
	}
	else
		UMReporter.log(Status.SKIP, "Irreg capsule is not visible");

}

@Then("^User select the Save Changes button in Irregularities modal window$")
public void verify_save_changes_button_visible_and_click_on_it() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the Save Changes button in Irregularities modal window");
	if (SelectedViewIrregFlag) {
		boolean flag = sessiondetail.clickSaveChangesButton();
		if (flag) {
			UMReporter.log(Status.PASS, "Save Changes button is visible and able to click on it");		
		}
		else
			UMReporter.log(Status.FAIL, "Save Changes button is not visible");
	}
	else
		UMReporter.log(Status.SKIP, "Irreg capsule is not visible");

}

@When("User select (.*) Tickets Per Page and (.*) format Page layout in  Printing Options dialog in Student Test Tickets page")
public void verify_PrintingOPtions_studentTestTickets_page(String tiketperpage, String pagelayout) throws Exception {
	UMReporter.log(Status.INFO, "When: User select "+tiketperpage+" Tickets Per Page and "+pagelayout+" format Page layout in  Printing Options dialog in Student Test Tickets page");
	testTicketsWinHnd = WebDriverMain._getDriver().getWindowHandles();
	boolean flag=false;
	String Printingoptions="";
	for (String testTickets : testTicketsWinHnd) {
		if (!testTickets.equals(CurrentWinHnd)) {
			WebDriverMain._getDriver().switchTo().window(testTickets);
			if (sessiondetail.VerifyPrintingOptionsBar()) {
				flag = sessiondetail.verifyPrintingOptionTitle(Constants.PrintingOptionsPopupTitle);
				sessiondetail.SelectTicketsPerPageDropdown(tiketperpage);
				sessiondetail.SelectPageLayout(pagelayout);
				//flag=sessiondetail.ProceedtoPrintButton_isVisible();
				Printingoptions="Selected "+tiketperpage+" Tickets Per Page and "+pagelayout+" format Page layout in  Printing Options dialog";
			}
			else
				UMReporter.log(Status.FAIL, "Printing Options dialog not displayed in Student Test Tickets tab");
			
			printedTickets = sessiondetail.getPrintedTicketCnt();
			WebDriverMain._getDriver().switchTo().window(CurrentWinHnd);
		}
	}

	boolean hasNewPage = testTicketsWinHnd.size() > 1;
	if (hasNewPage)
		UMReporter.log(Status.PASS,
				Printingoptions+" Student testing tickets displayes in a separate tab " + printedTickets);
	else
		UMReporter.log(Status.PASS, "Student Test Tickets tab is not opened");

}

@Then("^Verify the Export to CSV option visible in Session details page$")
public void Verify_ExportTOCSV_options_of_Session_details_page() throws IOException {
	UMReporter.log(Status.INFO, "Then : Verify the Export to CSV option visible in Session details page$");
	if (sessiondetail.hasStudentlist()) {
	// verify export to CSV
	boolean flag = sessiondetail.verifyExporttoCSV();
	if (flag)
		UMReporter.log(Status.PASS, "The Export to CSV is visible in Session details page");
	else
		UMReporter.log(Status.FAIL, "The Export to CSV option not visible in Session details page");
	} else
		UMReporter.log(Status.SKIP, "No student records to Export to CSV");
}

@Then("^User select the Export to CSV option in Session details page$")
public void Select_ExportTOCSV_options_of_Session_details_page() throws IOException {
	UMReporter.log(Status.INFO, "Then : User select the Export to CSV option in Session details page");
	if (sessiondetail.hasStudentlist()) {
		// Get Title of drilldown page
		String pagetitle = sessiondetail.GetSessionName();
		System.out.println("Pagetitle : " + pagetitle);
		// Click export to CSV
		boolean flag = sessiondetail.clickExporttoCSV();

		// Get Latest file and check if matches the title
		Exporttocsvfile = csvfreader.getLatestDownloadFile("csv");
		String exportfilename = Exporttocsvfile.getName();
		System.out.println("Exported filenme : " + exportfilename);
		if (exportfilename.toLowerCase().contains(pagetitle.toLowerCase()))
			UMReporter.log(Status.PASS,
					"Selected the Export to CSV file of Session details page and downloded CSV File: " + exportfilename);
		else
			UMReporter.log(Status.FAIL,
					"Selected the Export to CSV file of Session details page and downloded CSV File not matched the page title : "
							+ exportfilename);

	} else
		UMReporter.log(Status.SKIP, "No student records to Export to CSV");
}

@Then("^Verify the downloaded CSV file with Student list in Session details page$")
public void verify_ExportTOCSV_options_of_Session_details_page() throws IOException {
	UMReporter.log(Status.INFO, "Then : Verify the downloaded CSV file with Student list in Session details page");
	if (Exporttocsvfile != null) {
		List<List<String>> notverified = new ArrayList<List<String>>();
		List<List<String>> verified = new ArrayList<List<String>>();
		// Get Drilldown page records
		List<List<String>> lstRecords = sessiondetail.getStudentListrecords(2);
		String exportfilename = Exporttocsvfile.getName();
		System.out.println("Exported filename : " + exportfilename);
		String absolutefilepath = Exporttocsvfile.getAbsolutePath();
		List<String> ExcludeColumn= new ArrayList<String>();
		ExcludeColumn.add("TestNav Username");
		ExcludeColumn.add("TestNav Password");
		ExcludeColumn.add("﻿Test Session Name");
		String sFormCode="﻿hhhhForm Code";
		ExcludeColumn.add(sFormCode.replace("﻿hhhh",""));
		String sTestCode="Test Code";
		ExcludeColumn.add(sTestCode.replace("﻿hhhh ",""));
		List<List<String>> lstdownoadedRecords = csvfreader.getExportedCSVContent(absolutefilepath, 3,ExcludeColumn);
		if (lstdownoadedRecords.equals(lstRecords))
			UMReporter.log(Status.PASS,
					"Verified the downloaded CSV content with Student List Table : " + lstdownoadedRecords);
		else {
			for (int i = 1; i < lstdownoadedRecords.size(); i++) {
				List<String> lst1 = lstdownoadedRecords.get(i);
				List<String> lst2 = lstRecords.get(i);

				if ((lst1.equals(lst2)) || (lst2.equals(lst1)))
					verified.add(lst1);
				else
					notverified.add(lst1);
			}
			if (notverified.size() > 0)
				UMReporter.log(Status.FAIL, "Not verified the Student list : " + lstRecords
						+ " Downloaded CSV Content : " + lstdownoadedRecords);
			else
				UMReporter.log(Status.SKIP, "Not verified the Student list : " + lstRecords
						+ " Downloaded CSV Content : " + lstdownoadedRecords);
		}
	} else
		UMReporter.log(Status.SKIP, "No student records to Export to CSV");
}



@When("Verify Session Info in Student Testing Tickets page")
public void verify_SessionInfo_in_studentTestTickets_page() throws Exception {
	UMReporter.log(Status.INFO, "When: Verify Session Info in Student Testing Tickets page");
	testTicketsWinHnd = WebDriverMain._getDriver().getWindowHandles();
	for (String testTickets : testTicketsWinHnd) {
		if (!testTickets.equals(CurrentWinHnd)) {
			WebDriverMain._getDriver().switchTo().window(testTickets);
			if (MapSessFields != null) {
				// Verify the Session details page displayed
				sessiondetail.verifySessionDetailsinStudentTestingTicket(MapSessFields);
			}
			if (lstSectionCards != null) {
				sessiondetail.verifySectionSealcodesinStudentTestingTicket(lstSectionCards);	
			}
			WebDriverMain._getDriver().switchTo().window(CurrentWinHnd);
		}
	}


}

}
