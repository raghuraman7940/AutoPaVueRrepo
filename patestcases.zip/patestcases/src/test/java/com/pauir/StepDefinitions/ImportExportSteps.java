package com.pauir.StepDefinitions;
/**
 * Import Export Step Definition 
 */
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.Common.ImportExport;
import com.pauir.common.core.CommonFunctions;
import webdriver.main.UMReporter;
import com.pauir.common.util.CSV_Reader;
import com.pauir.common.util.Constants;

public class ImportExportSteps {
	
	//Initialize the class variable
	public static ImportExport importexport;
	public static CommonFunctions common;
	public static CSV_Reader csvfreader;
	public static String csvfilepath;
	public static boolean isDatafilled=false;
	
	public ImportExportSteps()throws IOException{
		//Initialize the Page object
		csvfreader= new CSV_Reader();
		importexport= new ImportExport();
	}
	
	
	@Given("User switch to (.*) Tab")
	public void user_switch_to_Import_Student_Tab_Students_page(String ImportTab) throws IOException {
		UMReporter.log(Status.INFO, "When : User switch to "+ImportTab+" Tab");
		boolean selectImpotTab=importexport.SelectTabOption(ImportTab);
		if(selectImpotTab)
			UMReporter.log(Status.PASS, "Selected the "+ImportTab+" tab");
		else
			UMReporter.log(Status.FAIL, ImportTab+" Tab is not exist");
	}

	@Then("^Verify the Download Template option visible in (.*) page$")
	public void Verify_Download_Template_options_of_Import_page(String ImportTab) throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the Download Template option visible in "+ImportTab+" page");
		//verify export to CSV
		boolean flag=importexport.verifyDownloadTemplate();
		 if (flag)  
			UMReporter.log(Status.PASS,"The Download Template is visible in "+ImportTab+" page");
		 else
			UMReporter.log(Status.FAIL,"The Download Template option not visible in "+ImportTab+" page");
		
	}

	@Then("^User download the Template in (.*) page$")
	public void Select_Download_Template_options_of_Import_Students_page(String ImportTab) throws Exception  {
		UMReporter.log(Status.INFO, "Then : User download the Template in "+ImportTab+" page");
		if (importexport.verifyDownloadTemplate()) {
			String TemplateFile="ImportTemplate";
			//Click DownloadTemplate
			importexport.clickDownloadTemplate();
			//Get Latest file and check if matches the title
			 File downloadedfile=csvfreader.getLatestDownloadFile("csv");
			 String StudentImportTemplate=downloadedfile.getName();
			 csvfilepath=downloadedfile.getPath();
			 switch (ImportTab.toLowerCase()) {
				case "import students":
					TemplateFile=Constants.StudentImportTemplate;
					break;
				case "import users":
					TemplateFile=Constants.UserImportTemplate;
					break;
				case "import classes":
					TemplateFile=Constants.ClassImportTemplate;
					break;
				case "import courses":
					TemplateFile=Constants.CourseImportTemplate;
					break;
				case "import districts":
					TemplateFile=Constants.DistrictImportTemplate;
					break;
				case "import schools":
					TemplateFile=Constants.SchoolImportTemplate;
					break;
			}
			 if (StudentImportTemplate.toLowerCase().contains(TemplateFile.toLowerCase())) {
				 List<List<String>> lstdownoadedRecords=csvfreader.getExportedCSVContent(csvfilepath,1);
				 UMReporter.log(Status.PASS,"The Import Template File : "+StudentImportTemplate+" Downloded CSV Content "+lstdownoadedRecords);
			 }
			 else
				UMReporter.log(Status.FAIL,"Selected the Download Template and downloded CSV File not matched the page title : "+StudentImportTemplate);
		}
		else
			UMReporter.log(Status.SKIP,"Unable to download template");
	}
	
	@Given("^User set data in ImportTemplate CSV$")
	public void Set_StudentsData_for_Import(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO,"When : User set data in ImportTemplate CSV");
		String Data;
		String CSVTemplate=null;
		List<String> lstCSVData=null;
		if (importexport.checkFileExist(csvfilepath)) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			lstCSVData=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Data = list.get(i).get("Importdata");
				if (i==0) {
					CSVTemplate=Data;
				}
				else {
					if (Data.indexOf("@random")>=0)
						Data=CommonFunctions.generateRandomString(Data);
					lstCSVData.add(Data);
				}
			}
			List<List<String>> lstdownoadedRecords=csvfreader.getExportedCSVContent(csvfilepath,1);
			System.out.println("Downloaded : "+lstdownoadedRecords);
			System.out.println("Expected : "+CSVTemplate);
			
			if (lstdownoadedRecords.size()>=0) {
				System.out.println("lstdownoadedRecords : "+lstdownoadedRecords.get(0));
				List<String> lstString=lstdownoadedRecords.get(0);
				String str=lstString.toString();
				String downloadedrecords=str.substring(1, str.length()-1);
				System.out.println("downloadedrecords : "+downloadedrecords);
				System.out.println("CSVTemplate : "+CSVTemplate);
				if (downloadedrecords.contains(CSVTemplate)) {
					boolean flag= csvfreader.AppendCSVContent(csvfilepath,lstCSVData);
					if (flag) {
						isDatafilled=true;
						UMReporter.log(Status.PASS,"The following data added in ImportTemplate CSV "+lstCSVData);
					}
					else
						UMReporter.log(Status.FAIL,"No student data in ImportTemplate CSV");
				}
				else
					UMReporter.log(Status.FAIL,"Input data template mismatchs : "+CSVTemplate);
			}
			 else
					UMReporter.log(Status.SKIP,"The Import file template not found");
			
		 }
		 else
				UMReporter.log(Status.SKIP,"The Import file not found");
	}
	
	@Then("^User submit the filled Import csv in (.*) page$")
	public void User_submit_filled_data_Import_page(String ImportTab) throws Exception  {
		UMReporter.log(Status.INFO, "Then : User submit the filled Import csv in "+ImportTab+" page");
		boolean flag=false;
		 if ((importexport.checkFileExist(csvfilepath))&&(isDatafilled)) {
			//Set file path
			importexport.SetImportFilePath(csvfilepath);
			flag=importexport.SubmitButton_isVisible();
			if (flag) {
				flag=importexport.ClickSubmitButton();
				if (flag)
					UMReporter.log(Status.PASS,"The Download Template is visible in Import Students page");
				else
					UMReporter.log(Status.FAIL,"The Submit button not selected in Import Students page");
			}
			else
				UMReporter.log(Status.FAIL,"The Submit button not displayed in Import Students page");
		 }
		 else
				UMReporter.log(Status.SKIP,"The Import file not found");
	}
	
	
	@Then("^Verify the success message displayed in Import page as (.*)$")
	public void verify_success_message_displayed_in_Import_page_as(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Import page as " + messages);
		boolean flag;
		if (importexport.verifySuccessMessageExist()) {
			flag = importexport.verifySuccessMessage(messages);
			if (flag) 
				UMReporter.log(Status.PASS, "Verified the success message displayed in Import page :" + messages);		
			else
				UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
		}
		else
			UMReporter.log(Status.SKIP, "No success message is displayed" );
		
	}
	
	@Then("^Verify the success message displayed in (.*) list page as (.*)$")
	public void verify_success_message_displayed_in_Export_page_as(String Page, String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in "+Page+" list page as " + messages);
		boolean flag;
		if (importexport.verifySuccessMessageExist()) {
			flag = importexport.verifySuccessMessage(messages);
			if (flag) 
				UMReporter.log(Status.PASS, "Verified the success message displayed in "+Page+" list page :" + messages);		
			else
				UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
		}
		else
			UMReporter.log(Status.SKIP, "No success message is displayed" );
		
	}
	
	@Given("Click on View Navigation hyperlink link in Success Message")
	public void click_on_Import_Menu_Imports_Exports_link() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on View Navigation hyperlink link in Success Message ");
		if (importexport.verifySuccessMessageExist()) {
			String Navigatelink=importexport.GetSuccesshyperlinks();
			importexport.ClickSuccessLink();
			UMReporter.log(Status.PASS, "Selected the success link :"+Navigatelink);
		}
		else
			UMReporter.log(Status.SKIP, "No success message is displayed" );
	}
	
	@Given("Verify the Export (.*) button visible in list page")
	public void verify_the_Export_Classes_button_display(String ExportTab) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Export "+ExportTab+" button visible in list page");
		String ExpBtn="Export "+ExportTab;
		// Verify the Export Classes displayed
		if (importexport.verifyExportButton_isVisible(ExpBtn))
			UMReporter.log(Status.PASS, ExpBtn+" Button is displayed");
		else
			UMReporter.log(Status.FAIL, ExpBtn+" Button is not visible");
	}

	@Given("Click on Export (.*) button in list page")
	public void click_on_Export_button(String ExportTab) throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the Export "+ExportTab+" in "+ExportTab+" list page");
		String ExpBtn="Export "+ExportTab;
		boolean flag = importexport.clickExportButton(ExpBtn);
		if (flag)
			UMReporter.log(Status.PASS, "Selected the "+ExpBtn+" button");
		else
			UMReporter.log(Status.FAIL, "Unable to click "+ExpBtn);
	}

	
}