package com.pauir.StepDefinitions;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.Common.ImportExport;
import com.pauir.PageDefinitions.classes.ClassDetailPage;
import com.pauir.PageDefinitions.courses.CoursesListPage;
import com.pauir.PageDefinitions.courses.CreateCoursePage;
import com.pauir.PageDefinitions.courses.CourseDetailPage;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.PageDefinitions.sessions.SessionDetailPage;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.testDataTypes.Coursefield;
import com.pauir.common.util.CSV_Reader;
import com.pauir.common.util.Constants;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class CoursesSteps {
	public static Login login;
	public static Home home;
	public static SessionDetailPage sessiondetail;
	public static CommonFunctions common;
	public static CoursesListPage CoursesList;
	public static CourseDetailPage coursesdetail;
	public static ClassDetailPage classdetail;
	public static CreateCoursePage createcourse;
	public static HashMap<String, String> MapFilledCourseField = null;
	public static HashMap<String, String> MapEditedCourseField = null;
	public static ImportExport importexport;
	public static CSV_Reader csvfreader;
	public static String csvfilepath;
	public static HashMap<String, String> MapCourseFields = null;
	public static HashMap<String, String> MapCourseClassFields = null;
	public static Map<String, String> mapAppliedFilter = null;
	public static List<String> lstSelectedCourses = null;
	public static HashMap<String, String> MapStuFields = null;

	public CoursesSteps() throws IOException {
		login = new Login(WebDriverMain._getDriver());
		CoursesList = new CoursesListPage();
		coursesdetail = new CourseDetailPage();
		createcourse = new CreateCoursePage();
		home = new Home();
		csvfreader = new CSV_Reader();
		importexport = new ImportExport();
		classdetail = new ClassDetailPage();
		sessiondetail = new SessionDetailPage();
	}

	@Given("Navigate to Courses page$")
	public void navigate_to_Courses_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Courses page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL, "LogIn Failed.");
			throw new RuntimeException("Login fail!");
		}
		// Select Menu option Primary and secondary option
		home.MenuOtion("Courses", "");
		// Verify the Courses list page displayed
		if (CoursesList.IsCoursesListTableExist())
			UMReporter.log(Status.PASS, "User is navigated successfully to Courses page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@Given("Verify courses list page is displayed")
	public void verify_courses_list_page_is_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify courses list page is displayed");
		boolean flag = false;
		// Verify the Courses list page displayed
		if (CoursesList.IsCoursesListTableExist()) {
			CommonFunctions.waitUntilLoadingSpinner(10);
			UMReporter.log(Status.PASS, "User is navigated to courses list page");
		} else {
			flag = CoursesList.SelectTabOption("Courses List");
			if (CoursesList.IsCoursesListTableExist()) {
				CommonFunctions.waitUntilLoadingSpinner(10);
				UMReporter.log(Status.PASS, "User is navigated to courses list page");
			} else
				UMReporter.log(Status.FAIL, "Navigated to unexpected page");
		}
	}

	@Given("Verify the courses Table fields")
	public void verify_the_courses_Table_fields(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "When :Verify the courses Table fields");
		String Fieldname;
		List<String> NonVerified = null;
		List<String> MapDgOrgColHeader = CoursesList.getCoursesColumnHeaderDetails();
		if (MapDgOrgColHeader != null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size() > 0)
			UMReporter.log(Status.FAIL,
					"The following expected courses Table fields are not exist in frontend :" + NonVerified);
		else
			UMReporter.log(Status.PASS, "The following courses Table fields are verified :" + MapDgOrgColHeader);

	}

	@When("User fill the Course search text (.*)$")
	public void user_fill_the_Course_search_text_Teacher(String SeachText) throws Exception {
		if (SeachText.indexOf("$") >= 0)
			SeachText = CommonFunctions.getTestData(SeachText);
		UMReporter.log(Status.INFO, "Then : Course fill the search text : " + SeachText);
		System.out.println("Search text " + SeachText);
		UMReporter.log(Status.INFO, "Then : User fill the Course name search text : " + SeachText);
		boolean flag = CoursesList.Searchfill_CourseName(SeachText);
		if (flag)
			UMReporter.log(Status.PASS, "Provided the Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to provide search text in input field");
	}

	@When("User select the search icon in Courses page")
	public void user_select_the_search_icon_in_Courses_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon in Courses list page");
		boolean flag = CoursesList.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "Clicked the Search Icon");
		else
			UMReporter.log(Status.FAIL, "Unable to select search icon");
	}

	@When("^User search the course by search text (.*)$")
	public void User_Search_Searchtext_student_list(String SeachText) throws Exception {
//		UMReporter.log(Status.INFO, "Then : User find the student by search text : "+SeachText);
		boolean flag = false;
		if (MapFilledCourseField != null) {
			String SeachText1 = null;
			if (MapFilledCourseField.containsKey("Course Name")) {
				SeachText1 = MapFilledCourseField.get("Course Name");
				flag = CoursesList.Searchfill_CourseName(SeachText1);
				flag = CoursesList.clicksearchicon();
				flag = CoursesList.hasCourseRecords();
				if (flag) {
					UMReporter.log(Status.INFO, "Then : User search the course by search text : " + SeachText);
					UMReporter.log(Status.PASS, "The Search text :" + SeachText1);
				}
			}
		}
		if (!flag) {
			if (SeachText.indexOf("$") >= 0)
				SeachText = CommonFunctions.getTestData(SeachText);
			UMReporter.log(Status.INFO, "Then : User search the course by search text : " + SeachText);
			flag = CoursesList.Searchfill_CourseName(SeachText);
			flag = CoursesList.clicksearchicon();
			flag = CoursesList.hasCourseRecords();
			if (flag)
				UMReporter.log(Status.PASS, "The Search text :" + SeachText);
			else
				UMReporter.log(Status.FAIL, "Unable to set search text in input field");
		}
	}

	@Then("verify the (.*) search results in the Courses list")
	public void verify_the_Course_search_results_in_the_Courses_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the Courses list : " + SeachText);
		if (MapFilledCourseField != null)
			if (MapFilledCourseField.containsKey("Course Name"))
				SeachText = MapFilledCourseField.get("Course Name");
		List<String> MapDgOrgDet = CoursesList.verifyCourseSearchresultsDetailsfromtext(SeachText);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "The Course lists matches the SeachText :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The Course are not found in list");

	}

	@Then("Clear Courses Search text field")
	public void clear_Courses_Search_text_field() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the Search text field");
		boolean flag = CoursesList.ClearSearchText();

		if (flag) {
			flag = CoursesList.clicksearchicon();
			UMReporter.log(Status.PASS, "Cleared the Search Text");
		} else
			UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}

	@Then("^Verify the list of Courses displayed in Courses page$")
	public void verify_Coursess_list_is_access_CoursesPage() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the list of Courses displayed in Courses page");
		List<String> MapDgColHeader = CoursesList.verifyCoursesResultsDetails(3);
		if (MapDgColHeader != null)
			UMReporter.log(Status.PASS, "The following Courses lists are accessed :" + MapDgColHeader);
		else
			UMReporter.log(Status.FAIL, "The Courses are not found in list");
	}

	@Given("User switch to Import Courses Tab in Courses Page")
	public void user_switch_to_Import_Courses_Tab_Courses_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User switch to Import Courses Tab in Courses Page");
		boolean createenabled = CoursesList.SelectTabOption("Import Courses");
		if (createenabled)
			UMReporter.log(Status.PASS, "Selected the Import Courses tab");
		else
			UMReporter.log(Status.FAIL, "Import Courses Tab does not exist");
	}

	@Then("^User select the Download Template in Import Courses page$")
	public void Select_Download_Template_options_of_Import_Courses_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the Download Template in Import Courses page");
		if (importexport.verifyDownloadTemplate()) {
			// Click DownloadTemplate
			boolean flag = importexport.clickDownloadTemplate();
			// Get Latest file and check if matches the title
			File downloadedfile = csvfreader.getLatestDownloadFile("csv");
			String CourseImportTemplate = downloadedfile.getName();
			csvfilepath = downloadedfile.getPath();
			if (CourseImportTemplate.toLowerCase().contains(Constants.CourseImportTemplate.toLowerCase())) {
				List<List<String>> lstdownoadedRecords = csvfreader.getExportedCSVContent(csvfilepath, 1);
				UMReporter.log(Status.PASS, "Course Import Template File : " + CourseImportTemplate
						+ " Downloded CSV Content " + lstdownoadedRecords);
			} else
				UMReporter.log(Status.FAIL,
						"Selected the Course Download Template and downloded CSV File not matched the page title : "
								+ CourseImportTemplate);
		} else
			UMReporter.log(Status.SKIP, "Unable to download template");
	}

	@Given("^User set course data in CourseImportTemplate CSV$")
	public void Set_CoursesData_for_Import(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "When : User set course data in CourseImportTemplate CSV");
		String Data;
		List<String> lstCSVData = null;
		if (importexport.checkFileExist(csvfilepath)) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			lstCSVData = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Data = list.get(i).get("Importdata");
				if (Data.indexOf("@random") >= 0)
					Data = CommonFunctions.generateRandomString(Data);
				lstCSVData.add(Data);
			}
			boolean flag = csvfreader.AppendCSVContent(csvfilepath, lstCSVData);
			if (flag)
				UMReporter.log(Status.PASS,
						"The following course data added in CourseImportTemplate CSV " + lstCSVData);
			else
				UMReporter.log(Status.FAIL, "No course data in CourseImportTemplate CSV");
		} else
			UMReporter.log(Status.SKIP, "The Import file not found");
	}

	@Then("^User submit the filled CourseImport csv in Import Courses page$")
	public void User_submit_filled_Coursedata_Import_Courses_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User submit the filled CourseImport csv in Import Courses page");
		boolean flag = false;
		if (importexport.checkFileExist(csvfilepath)) {
			// Set file path
			importexport.SetImportFilePath(csvfilepath);
			flag = importexport.SubmitButton_isVisible();
			if (flag) {
				flag = importexport.ClickSubmitButton();
				if (flag)
					UMReporter.log(Status.PASS, "The Download Template is visible in Import Courses page");
				else
					UMReporter.log(Status.FAIL, "The Submit button not selected in Import Courses page");
			} else
				UMReporter.log(Status.FAIL, "The Submit button not displayed in Import Courses page");
		} else
			UMReporter.log(Status.SKIP, "The Import file not found");
	}

	@Then("^Verify the success message displayed in Import Courses page as (.*)$")
	public void verify_success_message_displayed_in_Import_Courses_page_as(String messages) throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the success message displayed in Import Courses page as " + messages);
		boolean flag;
		if (importexport.verifySuccessMessageExist()) {
			flag = importexport.verifySuccessMessage(messages);
			if (flag)
				UMReporter.log(Status.PASS,
						"Verified the success message displayed in Import Courses page :" + messages);
			else
				UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
		} else
			UMReporter.log(Status.SKIP, "No success message is displayed");

	}

	@Given("Verify the Export Courses button is displayed")
	public void verify_the_Export_Courses_button_display() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Export Courses button is displayed");
		// Verify the Export Courses button displayed
		if (CoursesList.verifyExportCourses_isVisible())
			UMReporter.log(Status.PASS, "Export Courses Button is visible");
		else
			UMReporter.log(Status.FAIL, "Export Courses Button is not visible");
	}

	@Given("Click on Export Courses button")
	public void click_on_Export_Courses_button() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the Export Courses in course list page");
		boolean flag = CoursesList.clickExportCourses();
		if (flag)
			UMReporter.log(Status.PASS, "Clicked the Export Courses Icon");
		else
			UMReporter.log(Status.FAIL, "Unable to click Export Courses");
	}

	@Then("^Verify the success message displayed in Courses List page as (.*)$")
	public void verify_success_message_displayed_in_courses_list_page_as(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Courses List page as " + messages);
		boolean flag;
		if (importexport.verifySuccessMessageExist()) {
			flag = importexport.verifySuccessMessage(messages);
			if (flag)
				UMReporter.log(Status.PASS, "Verified the success message displayed in Courses List page :" + messages);
			else
				UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
		} else
			UMReporter.log(Status.SKIP, "No success message is displayed");

	}

	@When("^User select the Course from Course list Page$")
	public void user_clicks_on_Course_CourseList() throws Exception {
		UMReporter.log(Status.INFO, "When :User select the Course from Course list Page");
		// Get Course Search results by row number
		MapCourseFields = CoursesList.SelectCourseRecord();
		if (MapCourseFields != null) {
			if (MapCourseFields.containsKey("Course Name")) {
				String CourseName = MapCourseFields.get("Course Name");
				CommonUtility._sleepForGivenTime(2000);
				UMReporter.log(Status.PASS, "Selected the Course name " + CourseName + " hyperlink in Courses list");
			} else
				UMReporter.log(Status.FAIL, "The Course name hyperlink  not found in Courses list");
		} else
			UMReporter.log(Status.FAIL, "No records found in Course list");

	}

	@Then("^Verify Course details page is displayed$")
	public void verify_Course_details_page_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify Course details page is displayed");
		// Verify the Class Detail page displayed
		if (coursesdetail.verifyCourseDetailsNavigation())
			UMReporter.log(Status.PASS, "User is navigated to Course details page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@Then("^Verify the Course name is displayed in Course details page$")
	public void verify_Course_name_in_details_page_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the Course name is displayed in Course details page");
		if (MapCourseFields != null) {
			if (MapCourseFields.containsKey("Course Name")) {
				String courseName = MapCourseFields.get("Course Name");
				if (coursesdetail.verifyCourseName(courseName))
					UMReporter.log(Status.PASS, "Verified the Course name in Course details page :" + courseName);
				else
					UMReporter.log(Status.FAIL, "The Course name not found in Course details page :" + courseName);
			}
		} else
			UMReporter.log(Status.FAIL, "Class name not exist");
	}

	@Then("^Verify the Last updated date value is displayed in Course details page$")
	public void verify_LastUpdate_in_Coursedetails_page_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the Last updated date value is displayed in Course details page");
		String LastUpdate = coursesdetail.verifyLastUpdatedLabel();
		if (LastUpdate != null)
			UMReporter.log(Status.PASS, "Verified the Last updated date in Course details page :" + LastUpdate);
		else
			UMReporter.log(Status.FAIL, "The Last updated date not found in Course details page :" + LastUpdate);

	}

	@Given("^Verify the Course fields in Course details page$")
	public void verify_Course_Header_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When : Verify the Course fields in Course details page");
		String Fieldname;
		List<String> NonVerified = null;
		List<String> VerifiedField = null;
		if (coursesdetail.Verify_CourseHeader_Section()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			VerifiedField = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));

				System.out.println("Fieldname:" + Fieldname);
				if (!coursesdetail.verifyCourseHeaderLabel(Fieldname))
					NonVerified.add(Fieldname);
				else
					VerifiedField.add(Fieldname);
			}
			if (NonVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following expected Course Header fields are not exist in frontend :" + NonVerified);
			else
				UMReporter.log(Status.PASS, "The following Course Header fields are verified :" + VerifiedField);
		} else
			UMReporter.log(Status.FAIL, "The Course Header fields not found");
	}

	@Then("^Verify the selected Course field values in Course details page$")
	public void verify_Selected_Course_details_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the selected Course field values in Course details page");
		if (MapCourseFields != null) {
			// Verify the Class details page displayed
			coursesdetail.verifyViewCourseDetails(MapCourseFields);
		} else
			UMReporter.log(Status.FAIL, "Course Details are not found");
	}

	@Then("^Verify Class list is displayed in Course details page$")
	public void verify_whether_Class_list_page_is_displayed_Course_detailspage() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify Class list is displayed in Course details page");
		// Verify the Org list page displayed
		if (coursesdetail.Verify_Course_ClassList())
			UMReporter.log(Status.PASS, "Class List is displayed in Course details page");
		else
			UMReporter.log(Status.FAIL, "Class List is not displayed");
	}

	@Given("^Verify the Class Table fields in Course details page$")
	public void verify_Class_Table_fields_Course_Page(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the Class Table fields in Course details page");
		String Fieldname;
		List<String> NonVerified = null;
		// boolean flag = true;
		List<String> MapDgStuColHeader = coursesdetail.getClassColumnHeaderDetails();
		if (MapDgStuColHeader.size() > 0) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgStuColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size() > 0)
			UMReporter.log(Status.FAIL,
					"The following expected Class Table fields are not exist in frontend :" + NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Class Table fields are verified :" + MapDgStuColHeader);

	}

	@Then("^User able to access the list of Classes in Course details page$")
	public void verify_Class_list_is_access_Course_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of Classes in Course details page");
		List<String> MapDgStuColHeader = coursesdetail.verifyClasssearchresultsDetails(3);
		if (MapDgStuColHeader != null)
			UMReporter.log(Status.PASS,
					"The following Class lists are accessed in Course details Page :" + MapDgStuColHeader);
		else
			UMReporter.log(Status.FAIL, "The Classes are not found in list");
	}

	@Then("^Verify the pagination in Class datagrid in Course details page$")
	public void Verify_student_list_Paginations() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the pagination in Class datagrid in Course details page");
		int maxpage = coursesdetail.verifyClassGridPagination();
		if (maxpage > 1)
			UMReporter.log(Status.PASS, "The Class lists pagination are upto max pages :" + maxpage);
		else if (maxpage == 1)
			UMReporter.log(Status.PASS, "The Class list contains one page only.");
		else
			UMReporter.log(Status.FAIL, "The students list pagination fails.");
	}

	@When("^User search the class (.*) in Course details page$")
	public void Fill_Searchtext_class_list_Coursedetails_page(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search the class in Course details page : " + SeachText);
		boolean flag = coursesdetail.Searchfill_ClassName(SeachText);
		flag = coursesdetail.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "The Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}

	@Then("^verify the (.*) search class results in Course details page$")
	public void Verify_Searchtext_in_class_list_Course_Page(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search class results in Course details paget : " + SeachText);
		List<String> MapDgOrgDet = coursesdetail.verifyClassSearchresultsDetailsfromtext(SeachText);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "The class lists matches the SeachText :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The class are not found in list");

	}

	@Then("^Clear Search text field in Course details page$")
	public void Clear_Searchtextfield_Class_list_Course_Page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear Search text field in Course details page");
		boolean flag = coursesdetail.ClearSearchText();
		if (flag) {
			flag = coursesdetail.clicksearchicon();
			UMReporter.log(Status.PASS, "Cleared the Search Text");
		} else
			UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}

	@When("^User select the Class from Class list in Course Details Page$")
	public void user_click_Class_on_CourseClassList_Course_Page() throws Exception {
		UMReporter.log(Status.INFO, "When :User select the Class from Class list in Course Details Page");
		boolean flag = false;
		HashMap<String, String> MapOrgField = null;
		MapCourseClassFields = coursesdetail.SelectCourseClassRecord();
		// Get Class Search results by row number
		if (MapCourseClassFields != null) {
			if (MapCourseClassFields.containsKey("Class Name")) {
				String ClsName = MapCourseClassFields.get("Class Name");
				// Check the Class selected
				UMReporter.log(Status.PASS, "Selected the Class name " + ClsName + " hyperlink in Class list");
			} else
				UMReporter.log(Status.FAIL, "No records found in Class list");
		} else
			UMReporter.log(Status.SKIP, "No records found in Class list");
	}

	@Then("^Verify the Class name is displayed in Class details page from Course details page$")
	public void verify_Class_name_in_details_page_is_displayed_Course_Page() throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the Class name is displayed in Class details page from Course details page");
		if (MapCourseClassFields != null) {
			if (MapCourseClassFields.containsKey("Class Name")) {
				String ClsName = MapCourseClassFields.get("Class Name");
				if (classdetail.verifyClassName(ClsName.trim()))
					UMReporter.log(Status.PASS, "Verified the Class name in Class details page :" + ClsName);
				else
					UMReporter.log(Status.FAIL, "The Class name not found in Class details page :" + ClsName);
			}
		} else
			UMReporter.log(Status.SKIP, "No Class record exist");
	}

	@Then("^Verify the selected Class field values from Course details page$")
	public void verify_Selected_Class_details_is_displayed_from_Course_Page() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the selected Class field values from Course details page");
		if (MapCourseClassFields != null) {
			// Verify the Student details page displayed
			classdetail.verifyViewClassDetails(MapCourseClassFields);
		} else
			UMReporter.log(Status.SKIP, "No Class record exist");
	}

	@Then("^Verify Create Course page is displayed$")
	public void verify_create_course_page_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify Create Course page is displayed");

		// Verify the Class Detail page displayed
		if (createcourse.verifyCreateCoursePageNavigation())
			UMReporter.log(Status.PASS, "User is navigated to Create Course page");
		else
			UMReporter.log(Status.FAIL, "Navigated to unexpected page");
	}

	@Given("^User fill the Provided Course details in Create Course page$")
	public void user_fills_provided_fields_present_CreateCoursePage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When : User fill the Provided Course details in Create Course page");
		String Fieldname, FieldValue, FilledFieldValue = null;
		List<String> NonVerified = null;

		// Get fields from Configuration json file
		List<Coursefield> fields = FileReaderManager.getInstance().getJsonReader()
				.getCoursefieldsbyState(Constants.ORG_STATE);
		if (fields != null) {
			if (createcourse.VerifyCreateCourseForm()) {
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified = new ArrayList<String>();
				MapFilledCourseField = new HashMap<String, String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					if (FieldValue.indexOf("$") >= 0)
						FieldValue = CommonFunctions.getTestData(FieldValue);

					System.out.println("FieldValue:" + Fieldname + " => " + FieldValue);
					Coursefield field = FileReaderManager.getInstance().getJsonReader().getCoursefieldbyLabel(fields,
							Fieldname);
					if (field != null) {
						FilledFieldValue = createcourse.FillCourseField(field, FieldValue);
						if (FilledFieldValue == null)
							NonVerified.add(Fieldname);
						else
							MapFilledCourseField.put(Fieldname, FilledFieldValue);
					}
				}
				if (NonVerified.size() > 0)
					UMReporter.log(Status.FAIL,
							"The following course fields are unable to provide the input value :" + NonVerified);
				else
					UMReporter.log(Status.PASS,
							"The following course fields provided the input values :" + MapFilledCourseField);

			} else
				UMReporter.log(Status.FAIL, "The input form fields are not displayed in course create page ");
		}
	}

	@When("^Click on Save button in Create Course page$")
	public void Click_Save_button() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Save button in Create Course page");
		boolean isbtnclicked = createcourse.clickSaveButton();
		if (isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Save button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Save button");

	}

	@Then("^Verify the filled course information in Course details page$")
	public void verify_filled_Course_details_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the filled course information in Course details page");
		if (MapFilledCourseField != null) {
			if (coursesdetail.verifyCourseDetailsNavigation())
				coursesdetail.verifyViewCourseDetails(MapFilledCourseField);
			else
				UMReporter.log(Status.FAIL, "Course Details are not displayed");

		} else
			UMReporter.log(Status.FAIL, "Course Details are not found");
	}

	@Then("^User clicks on Edit button in Course Details page$")
	public void Click_Edit_button_inCourseDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: User clicks on Edit button in Course Details page");
		boolean isbtnclicked = coursesdetail.clickEditButton();
		if (isbtnclicked)
			UMReporter.log(Status.PASS, "Edit button is click");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Edit button");

	}

	@Given("^User edit the details in Course details page$")
	public void user_edit_provided_fields_present_CreateCoursePage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "When : User edit the details in Course details page");
		String Fieldname, FieldValue, FilledFieldValue = null;
		List<String> NonVerified = null;

		// Get fields from Configuration json file
		List<Coursefield> fields = FileReaderManager.getInstance().getJsonReader()
				.getCoursefieldsbyState(Constants.ORG_STATE);
		if (fields != null) {
			if (createcourse.VerifyCreateCourseForm()) {
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified = new ArrayList<String>();
				MapEditedCourseField = new HashMap<String, String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					// Get from Testdata
					if (FieldValue.indexOf("$") >= 0)
						FieldValue = CommonFunctions.getTestData(FieldValue);
					System.out.println("FieldValue:" + Fieldname + " => " + FieldValue);
					Coursefield field = FileReaderManager.getInstance().getJsonReader().getCoursefieldbyLabel(fields,
							Fieldname);
					if (field != null) {
						FilledFieldValue = createcourse.FillCourseField(field, FieldValue);
						if (FilledFieldValue == null)
							NonVerified.add(Fieldname);
						else
							MapEditedCourseField.put(Fieldname, FilledFieldValue);
					}
				}
				if (NonVerified.size() > 0)
					UMReporter.log(Status.FAIL,
							"The following course fields are unable to edit the input value :" + NonVerified);
				else
					UMReporter.log(Status.PASS,
							"The following course fields edited the input values :" + MapEditedCourseField);

			} else
				UMReporter.log(Status.FAIL, "The edit input form fields are not displayed in course details page ");
		}

	}

	@When("^Click on Save button in Course Details page$")
	public void Click_Save_button_inClassDetails() throws Exception {
		UMReporter.log(Status.INFO, "And: Click on Save button in Course Details page");
		boolean isbtnclicked = coursesdetail.clickSaveButton();
		if (isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Save button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Save button");

	}

	@Then("^Verify the edited course information in Course details page$")
	public void verify_edited_Course_details_is_displayed() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the edited course information in Course details page");
		if (MapEditedCourseField != null) {
			if (coursesdetail.verifyCourseDetailsNavigation())
				coursesdetail.verifyViewCourseDetails(MapEditedCourseField);
			else
				UMReporter.log(Status.FAIL, "Course details page is not displayed");

		} else
			UMReporter.log(Status.FAIL, "Course details are not found");
	}

	@Given("^User Select Administration (.*) Subject (.*) Test (.*) and Grade (.*) under Testing Information in Course details Page$")
	public void Select_Students_TestingInfo_Widget_Admin_Subject_Grade_page(String Admin, String Subject,
			String Testname, String Grade) throws Exception {
		UMReporter.log(Status.INFO,
				"When : User Select Administration, Subject, Test and Grade under Testing Information in Course details Page");
		// Select Admin
		CommonUtility._sleepForGivenTime(2000);
		if (Admin.indexOf("$") >= 0)
			Admin = CommonFunctions.getTestData(Admin);

		if (Grade.indexOf("$") >= 0)
			Grade = CommonFunctions.getTestData(Grade);

		if (Subject.indexOf("$") >= 0)
			Subject = CommonFunctions.getTestData(Subject);

		if (Testname.indexOf("$") >= 0)
			Testname = CommonFunctions.getTestData(Testname);

		CommonUtility._scrollup();
		boolean Adminflag = home.SelectWidgetAdministration("Testing Information", Admin);
		boolean Subjectflag = home.SelectWidgetSubject("Testing Information", Subject);
		boolean Testflag = home.SelectWidgetTestname("Testing Information", Testname);
		boolean Gradeflag = home.SelectWidgetGrade("Testing Information", Grade);
		mapAppliedFilter = new HashMap<String, String>();
		CommonUtility._sleepForGivenTime(5000);
		if ((Adminflag) && (Subjectflag) && (Testflag) && (Gradeflag)) {
			mapAppliedFilter.put("admin", Admin);
			mapAppliedFilter.put("subject", Subject);
			mapAppliedFilter.put("test", Testname);
			mapAppliedFilter.put("grade", Grade);
			UMReporter.log(Status.PASS, " Selected Administration => " + Admin + " ,Subject => " + Subject + ",Test => "
					+ Testname + " ,  Grade => " + Grade);
			if (Grade.contains("All"))
				Grade = "All";
		} else
			UMReporter.log(Status.FAIL, "Unable to select Administration, Subject, Test and Grade");
	}

	@Given("^Verify the (.*) card of (.*) widget in the Testing Information in Course details Page$")
	public void Verify_Dashboard_Widgets_Under_testingInfo_page(String Card, String CardHeader) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the " + Card + " card of " + CardHeader
				+ " widget in the Testing Information in Course details Page");
		Map<String, String> mapWidCards = null;
		// Get widget content
		if (Card.equalsIgnoreCase("Registered"))
			mapWidCards = home.GetRegisteredCardsWidgetContent("Testing Information", CardHeader, Card);
		else
			mapWidCards = home.GetTestingInfoArcWidgetContent("Testing Information", CardHeader, Card);

		if (mapWidCards != null)
			UMReporter.log(Status.PASS, "The " + Card + " card of " + CardHeader + " student count : " + mapWidCards);
		else
			UMReporter.log(Status.SKIP,
					"The " + Card + " card of " + CardHeader + " student count  no data to display ");
	}

	@Given("^Verify the Test Status bar count of Test Session Overview widget in Coures details Page$")
	public void Verify_Dashboard_Test_Session_Overview_Widget_page() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Test Status bar count of Test Session Overview widget in Coures details Page");
		// Get widget content
		if (!home.checkWidhasNoData()) {
			Map<String, String> mapWidCards = sessiondetail.GetStatusProgressBarContent();
			if (mapWidCards != null) {
				int iTotStuds = home.getTotalStudentsCnt();
				mapWidCards.put("Total Students", String.valueOf(iTotStuds));
				UMReporter.log(Status.PASS, "The Test Status wise count : " + mapWidCards);
			} else
				UMReporter.log(Status.SKIP, "Test Session Overview widget no data to display");
		} else
			UMReporter.log(Status.SKIP, "Test Session Overview widget no data to display");

	}

	@Then("^Verify delete button is visible in Courses list page$")
	public void verify_delete_button_is_Enabledvisible_Courselist() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify delete button is visible in Courses list page");
		boolean deleteenabled = CoursesList.DeleteButton_isVisible();
		if (deleteenabled)
			UMReporter.log(Status.PASS, "Delete button is visible");
		else
			UMReporter.log(Status.FAIL, "Delete button is not displayed after selecting record");
	}

	@When("^Click on delete button in Courses list page$")
	public void Click_Delete_button_in_ClassList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on delete button in Courses list page");
		boolean isbtnclicked = CoursesList.clickDeleteButton();
		if (isbtnclicked) {
			UMReporter.log(Status.PASS, "Selected the delete button");
//		while(ClassMgmt.Verify_Progressbar_Visible())
//		{
//			CommonUtility._sleepForGivenTime(1000);
//		}
		} else
			UMReporter.log(Status.FAIL, "Unable to click the delete button");
	}

	@When("^Select the (.*) Courses in Courses list page$")
	public void Select_Course_checkbox_Course_list(String clscount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the " + clscount + " Course in Courses list page");
		int stucnt = 1;
		if (CommonUtility.isNumeric(clscount))
			stucnt = Integer.parseInt(clscount);
		lstSelectedCourses = CoursesList.SelectonCourseCheckbox(stucnt);
		if (lstSelectedCourses.size() > 0)
			UMReporter.log(Status.PASS, "Selected the Course checkbox " + lstSelectedCourses.size());
		else
			UMReporter.log(Status.FAIL, "The Courses are not found in list");
	}

	@Then("^Verify the Courses are deleted in Course list page$")
	public void verify_Selected_Course_Removed_Course_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Courses are deleted in Courses list page");
		List<String> deletedClass = null;
		if (lstSelectedCourses != null) {
			deletedClass = new ArrayList<String>();
			for (String cls : lstSelectedCourses) {
				List<String> MapDgStuColHeader = CoursesList.verifySelectedCourseInlist(cls);
				if (MapDgStuColHeader == null)
					deletedClass.add(cls);
				else if (MapDgStuColHeader.size() < 1)
					deletedClass.add(cls);
			}
			if (deletedClass.size() > 0)
				UMReporter.log(Status.PASS, "The following Courses are deleted in Courses List Page :" + deletedClass);
			else
				UMReporter.log(Status.FAIL,
						"The following Courses lists are not removed in Courses List Page :" + lstSelectedCourses);
		} else
			UMReporter.log(Status.PASS, "The Classes are not found in list");
	}

	@Then("^Verify the Courses are not deleted in Courses list page$")
	public void verify_Selected_Class_Not_Removed_Class_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Courses are not deleted in Courses list page");
		List<String> deletedClass = null;
		if (lstSelectedCourses != null) {
			deletedClass = new ArrayList<String>();
			for (String cls : lstSelectedCourses) {
				List<String> MapDgStuColHeader = CoursesList.verifySelectedCourseInlist(cls);
				if (MapDgStuColHeader == null)
					deletedClass.add(cls);
				else if (MapDgStuColHeader.size() < 1)
					deletedClass.add(cls);
			}
			if (deletedClass.size() > 0)
				UMReporter.log(Status.PASS,
						"The following Courses lists are not removed in Courses List Page :" + lstSelectedCourses);
			else
				UMReporter.log(Status.FAIL, "The following Courses are removed in Courses List Page :" + deletedClass);
		} else
			UMReporter.log(Status.FAIL, "The Classes are not found in list");
	}

	@Then("^Verify the alert success message in Courses list page as (.*)$")
	public void verify_success_message_gets_displayed_on_CoursesList_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the alert success message in Courses list page as " + messages);
		String ActualMessage;
		ActualMessage = CoursesList.GetSuccessMessage();
		if ((ActualMessage != null) && (ActualMessage.length() > 2)) {
			if (ActualMessage.contains(messages))
				UMReporter.log(Status.PASS, "Verified the success message displayed in course List page:" + messages);
			else if (ActualMessage.contains("ERROR"))
				UMReporter.log(Status.SKIP, "The error message displayed :" + ActualMessage);
			else
				UMReporter.log(Status.FAIL,
						"Not matched expected message :" + messages + "\n Actual :" + ActualMessage);
			CoursesList.Close_Alerts();
		} else
			UMReporter.log(Status.SKIP, "No Success message displayed");
	}

	@When("^Verify title and content (.*) in Confirmation Delete Courses pop-up$")
	public void Verify_title_message_ConfirmPopUp_button_CoursesPopup(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Confirm Delete Courses pop-up");
		boolean flag = false;
		// Verify the Confirm pop up
		flag = CommonFunctions.VerifyConfirmPopupContent(Constants.DeleteCourseConfirmPopupTitle, confmessage);
		if (flag)
			UMReporter.log(Status.PASS, "Verified Confirm Delete Class pop-up title and message : " + confmessage);

	}

	@When("^Click on confirm button on Confirmation Delete Courses pop-up$")
	public void Click_confirm_on_ConfirmDeleteCoursespopup() throws Exception {
		UMReporter.log(Status.INFO, "When :  Click on confirm button on Confirmation Delete Courses pop-up");
		// Verify the Click Confirm in pop up
		boolean flag = CommonFunctions.ConfirmPopupActionBtn("Confirm");
		CommonUtility._sleepForGivenTime(3000);
		if (flag) {

			flag = CoursesList.waitForProgressbarVisible(20);
			if (flag)
				UMReporter.log(Status.PASS, "Select the Confirm button and navigated to Courses list page");
			else
				UMReporter.log(Status.PASS, "Progress bar is displayed for long time after delete");

		} else
			UMReporter.log(Status.FAIL, "Select the Confirm button and Courses list not displayed ");
	}

	@When("^Click on cancel button on Confirmation Delete Courses pop-up$")
	public void Click_cancel_on_ConfirmDeleteCourses_button() throws IOException {
		UMReporter.log(Status.INFO, "When :  Click on cancel button on Confirmation Delete Courses pop-up");

		// Verify the Click cancel in pop up
		boolean flag = CommonFunctions.ConfirmPopupActionBtn("Cancel");
		CommonUtility._sleepForGivenTime(3000);
		if (flag)
			UMReporter.log(Status.PASS, "Select the Cancel button and pop up is closed ");
		else
			UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed ");
	}

	@Then("^Verify the success message displayed in Create Course page as (.*)$")
	public void verify_success_message_displayed_in_Create_Course_page_as(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Create Course page as " + messages);
		String ActualMessage;
		ActualMessage = createcourse.GetSuccessMessage();
		if ((ActualMessage != null) && (ActualMessage.length() > 2)) {
			if (ActualMessage.contains(messages))
				UMReporter.log(Status.PASS, "Verified the success message displayed in Create Course page:" + messages);
			else if (ActualMessage.contains("ERROR"))
				UMReporter.log(Status.SKIP, "The error message displayed :" + ActualMessage);
			else
				UMReporter.log(Status.FAIL,
						"Not matched expected message :" + messages + "\n Actual :" + ActualMessage);
			// createcourse.Close_Alerts();
		} else
			UMReporter.log(Status.SKIP, "No Success message displayed");
	}

	@Given("Click on View the new course now link")
	public void click_on_View_the_new_student_now_link() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on View the new course now link");
		createcourse.clickViewNewCourseLink();
		UMReporter.log(Status.PASS, "Selected the Success Message link");
	}

	@Then("^Verify Student list is displayed in Course details page$")
	public void verify_whether_Student_list_page_is_displayed_Course_detailspage() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify Student list is displayed in Course details page");
		// Verify the list page displayed
		if (coursesdetail.Verify_Course_StudentList())
			UMReporter.log(Status.PASS, "Student List is displayed in Course details page");
		else
			UMReporter.log(Status.FAIL, "Student List is not displayed");
	}

	@Given("Navigate to (.*) tab")
	public void user_switch_to_Student_List_Tab_Courses_Details_page(String SelectTab) throws IOException {
		UMReporter.log(Status.INFO, "When : User switch to Student List tab in Course Details Page");
		boolean createenabled = coursesdetail.SelectTabOption(SelectTab);
		if (createenabled)
			UMReporter.log(Status.PASS, "Selected the " + SelectTab + " tab");
		else
			UMReporter.log(Status.FAIL, SelectTab + " Tab does not exist");
	}

	@Given("^Verify the Student List Table fields in Course details page$")
	public void verify_Student_List_Table_fields_Course_Page(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the Student List Table fields in Course details page");
		String Fieldname;
		List<String> NonVerified = null;
		// boolean flag = true;
		List<String> MapDgStuColHeader = coursesdetail.getStudentColumnHeaderDetails();
		if (MapDgStuColHeader.size() > 0) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgStuColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size() > 0)
			UMReporter.log(Status.FAIL,
					"The following expected Student List Table fields are not exist in frontend :" + NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Student List Table fields are verified :" + MapDgStuColHeader);

	}

	@Then("^User able to access the list of students in Course details page$")
	public void verify_Student_list_is_access_Course_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of students in Course details page");
		List<String> MapDgStuColHeader = coursesdetail.verifyStudentsearchresultsDetails(3);
		if (MapDgStuColHeader != null)
			UMReporter.log(Status.PASS,
					"The following Student lists are accessed in Course details Page :" + MapDgStuColHeader);
		else
			UMReporter.log(Status.FAIL, "The Students are not found in list");
	}

	@When("^User select the student from student list in course details page$")
	public void user_clicks_on_First_IN_StudentList() throws Exception {
		UMReporter.log(Status.INFO, "When :User select the student from student list in course details page");
		boolean flag = false;
		HashMap<String, String> MapOrgField = null;
		// Get Student Search results by row number
		MapStuFields = coursesdetail.getStudsearchresultsDetails(1);
		if (MapStuFields != null) {
			if (MapStuFields.containsKey("Student Name")) {
				String StudName = MapStuFields.get("Student Name");
				String NameSplit[] = StudName.split(", ");
				if (NameSplit.length >= 1) {
					String Lname = NameSplit[0];
					MapStuFields.put("Last Name", Lname);
					String FMname = NameSplit[1];
					String FMNameSplit[] = FMname.split(" ");
					if (FMNameSplit.length > 1) {
						String Fname = FMNameSplit[0];
						MapStuFields.put("First Name", Fname);
						String Mname = FMNameSplit[1];
						MapStuFields.put("Middle Name", Mname);
					} else
						MapStuFields.put("First Name", FMname);
				}

				// Click on Student Name hyperlink on Org list page
				flag = coursesdetail.clickonStudName(MapStuFields.get("Student Name"));
				// Check the Student selected
				if (flag) {
					CommonUtility._sleepForGivenTime(2000);
					UMReporter.log(Status.PASS, "Selected the Student name " + MapStuFields.get("Student Name")
							+ " hyperlink in Student list");
				} else
					UMReporter.log(Status.FAIL,
							"The Student name " + MapStuFields.get("Student Name") + "  not found in Student list");
			}
		} else
			UMReporter.log(Status.FAIL, "No records found in Student list");

	}

	@When("^User search the student (.*) in Course details page$")
	public void Fill_Searchtext_student_list_Coursedetails_page(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search the student in Course details page : " + SeachText);
		boolean flag = coursesdetail.Searchfill_ClassName(SeachText);
		flag = coursesdetail.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "The Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}

	@Then("^verify the (.*) search student results in Course details page$")
	public void Verify_Searchtext_in_student_list_Course_Page(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search student results in Course details paget : " + SeachText);
		List<String> MapDgOrgDet = coursesdetail.verifyClassSearchresultsDetailsfromtext(SeachText);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "The student lists matches the SeachText :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The students are not found in list");

	}

}
