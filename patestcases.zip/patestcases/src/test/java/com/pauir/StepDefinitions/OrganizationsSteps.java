/**
 * Organization- Step Definition 
 */
package com.pauir.StepDefinitions;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.Common.ImportExport;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.testDataTypes.Classfield;
import com.pauir.common.testDataTypes.OrgContactfield;
import com.pauir.common.testDataTypes.Organizationsfield;
import com.pauir.common.testDataTypes.Sessionfield;
import com.pauir.PageDefinitions.organizations.ManageOrganizationsPage;
import com.pauir.PageDefinitions.organizations.OrganizationDetailPage;
import com.pauir.PageDefinitions.organizations.CreateOrganizationPage;

import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

import com.pauir.common.util.CSV_Reader;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;



public class OrganizationsSteps {
	
	//Initialize the class variable
	public static ManageOrganizationsPage manageorgs;
	public static OrganizationDetailPage orgdetails;
	public static CreateOrganizationPage createorg;
	public static ImportExport importexport;
	public static CSV_Reader csvfreader;
	public static HashMap<String,String> MapOrgField=null;
	public static HashMap<String, String> MapOrgFilledFields = null;
	public static HashMap<String, String> MapOrgEditedFields = null;
	public static HashMap<String,String> MapOrgcontactField=null;
	public static HashMap<String, String> MapOrgcontactFilledFields = null;
	public static List<String> lstSelectedOrg=null;
	public static List<String> lstSelectedOrgReports=null;
	public static String CurrentWinHnd = null;

	public static Login login;
	public static Home home;
	public static CommonFunctions common;
	
	public OrganizationsSteps()throws IOException{
		//Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home= new Home();
		manageorgs=new ManageOrganizationsPage();
		orgdetails=new OrganizationDetailPage();
		createorg= new CreateOrganizationPage();
		importexport= new ImportExport();
		csvfreader = new CSV_Reader();
	}
	
	@Given("^Navigate to Manage Organizations page$")
	public void navigate_to_Organizations_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Manage Organizations page");
		boolean flag=home.VerifyLoggedinHomePage();;
		if (flag) {
			// Select Menu option Primary and secondary option
			home.MenuOtion("organizations", "Manage organizations");
			//Verify the User list page displayed
			if(manageorgs.verifyManageOrgsPageNavigation())
				UMReporter.log(Status.PASS,"User is navigated successfully to Manage Organizations page");
		    else
		    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
		}
		else if (manageorgs.verifyManageOrgsPageNavigation()) {
			UMReporter.log(Status.PASS,"Navigated to Organizations page");
		}
	}
	
	@Then("^Verify whether organizations list page is displayed$")
	public void verify_whether_user_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify whether organizations list page is displayed ");
		//Verify the Org list page displayed
		if(manageorgs.verifyManageOrgsPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Manage Organizations page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	

	
	@Then("^Verify Organizations list page is displayed$")
	public void verify_Org_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Organizations list page is displayed");
		//Verify the Org list page displayed
		if(manageorgs.verifyManageOrgsPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Manage Organizations page");
	    else {
	    	// Select Menu option Primary and secondary option
	    	home.MenuOtion("organizations", "Schools");
			//Verify the User list page displayed
			if(manageorgs.verifyManageOrgsPageNavigation())
				UMReporter.log(Status.PASS,"User is navigated successfully to Manage Organizations page");
		    else
		    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	    }
	}
	
	
	@Then("^Verify create button is visible and enable on Organization list page$")
	public void verify_create_button_is_visible_and_enable_on_Org_page() throws Exception{
		
		UMReporter.log(Status.INFO, "Then: Verify create button is visible and enable on Organization list page");    
		boolean createvisible = manageorgs.createButton_isVisible();
		if(createvisible) {
			boolean createenabled = manageorgs.createButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Create button is visable and enabled");
			else
				UMReporter.log(Status.FAIL, "Create button is not enabled");
		}
		else
			UMReporter.log(Status.FAIL, "Create button is not visible");
		
		
	}
	
	@Then("^Verify delete button is not visible before selecting record in organization list$")
	public void verify_delete_button_is_visible_but_disabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify delete button is not visible before selecting record in organization list");
		boolean deletevisible = manageorgs.deleteButton_isVisible();
		if(!deletevisible) 
			UMReporter.log(Status.PASS, "Delete button is not visible");
		else
			UMReporter.log(Status.FAIL, "Delete button is not visible");
		
	}
	
	@Given("^Verify the organizations Table fields$")
	public void verify_organizations_Table_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the organizations Table fields");
		String Fieldname;
		List<String> NonVerified=null;
		boolean flag = true;
		List<String> MapDgOrgColHeader=manageorgs.getOrgColumnHeaderDetails();
		if (MapDgOrgColHeader!=null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));

				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected organizations Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following organizations Table fields are verified :"+MapDgOrgColHeader);
	}
	
	@Then("^Verify delete button is enabled above the organization list$")
	public void verify_delete_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify delete button is enabled above the organization list");
		 boolean deletevisible=manageorgs.deleteButton_isEnabled();
		if(deletevisible)
			UMReporter.log(Status.PASS, "Delete button is enabled");
		else
			UMReporter.log(Status.FAIL, "Delete button is not enabled");
			
	    
	}
	
	@Then("^User able to access the list of organizations from the navigation$")
	public void verify_organization_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of organizations from the navigation");
		List<String> MapDgOrgColHeader=manageorgs.verifyOrgsearchresultsDetails(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following organizations lists are accessed :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The organizations are not found in list");
	}
	
	@Then("^verify each organization record contains a checkbox$")
	public void verify_organization_list_checkboxis_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : verify each organization record contains a checkbox");
		List<String> MapDgOrgColHeader=manageorgs.verifyOrgsearchresultsCheckbox(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The organizations lists contains checkbox :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The organizations are not found in list");
	}
	
	@When("^Select the organization record checkbox$")
	public void Select_organization_list_checkbox() throws Exception {
		UMReporter.log(Status.INFO, "When : Select the organization record checkbox");
		 boolean flag=manageorgs.SelectonOrgCheckbox();
	    if (flag)
	    	UMReporter.log(Status.PASS, "Selected the organizations checkbox ");
	    else
	    	UMReporter.log(Status.FAIL, "The organizations are not found in list");
	}
	
	@When("^User fill the search text (.*)$")
	public void Fill_Searchtext_organization_list(String SeachText) throws Exception {
		//Get from Testdata
		if (SeachText.indexOf("$")>=0)
			SeachText=CommonFunctions.getTestData(SeachText);
		
		UMReporter.log(Status.INFO, "Then : User fill the search text : "+SeachText);
		
		 boolean flag=manageorgs.Searchfill_OrgName(SeachText);
		 if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@When("^User search the organization (.*)$")
	public void Fill_CreatedSearchtext_organization_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User search the organization : "+SeachText);
		boolean flag=false;
		if (MapOrgFilledFields!=null)
			
			if (MapOrgFilledFields.containsKey("Organization Name")) 
				SeachText=MapOrgFilledFields.get("Organization Name");
			else if (MapOrgFilledFields.containsKey("District Name")) 
				SeachText=MapOrgFilledFields.get("District Name");
			else if (MapOrgFilledFields.containsKey("School Name")) 
				SeachText=MapOrgFilledFields.get("School Name");
		
	    flag=manageorgs.Searchfill_OrgName(SeachText);
		if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@When("^User search (.*) the organization in Organization list$")
	public void Search_Org_organization_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User search the organization in Organization list : "+SeachText);
		boolean flag=false;
		if (MapOrgFilledFields!=null) {
			String OrgSeachText=null;
			if (MapOrgFilledFields.containsKey("Organization Name")) 
				OrgSeachText=MapOrgFilledFields.get("Organization Name");
			else if (MapOrgFilledFields.containsKey("District Name")) 
				OrgSeachText=MapOrgFilledFields.get("District Name");
			else if (MapOrgFilledFields.containsKey("School Name"))  
				OrgSeachText=MapOrgFilledFields.get("School Name");
			 flag=manageorgs.Searchfill_OrgName(OrgSeachText);
			 flag=manageorgs.clicksearchicon();
		}
	    flag= manageorgs.hasOrglist();
		if (!flag) {
			if (SeachText.indexOf("$")>=0)
				SeachText=CommonFunctions.getTestData(SeachText);
			 flag=manageorgs.Searchfill_OrgName(SeachText);
			 flag=manageorgs.clicksearchicon();
		}
	    
		if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@When("^User select the search icon$")
	public void Click_Searchicon_organization_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon");
		boolean flag=manageorgs.clicksearchicon();
	    if (flag)
	    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
		 else
		    UMReporter.log(Status.FAIL, "Unable to select search icon");
	}
	
	@Then("^verify the (.*) search results in the organization list$")
	public void Verify_Searchtext_in_organization_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the organization list : "+SeachText);
		 List<String> MapDgOrgDet=manageorgs.verifyOrgsearchresultsDetailsfromtext(SeachText);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "The organizations lists matches the SeachText :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The organizations are not found in list");
	
	}
	@Then("^Clear Search text field$")
	public void Clear_Searchtextfield_organization_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the Search text field");
		boolean flag=manageorgs.ClearSearchText();
		
	    if (flag) {
	    	flag=manageorgs.clicksearchicon();
	    	 UMReporter.log(Status.PASS, "Cleared the Search Text");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}
	
	@Then("^Select Home breadcrumb$")
	public void Select_Home_breadcrumb_organization_list() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Home> breadcrumb");
//		boolean flag=manageorgs.clickHomeBreadCrum();
//	    if (home.VerifyLoggedinHomePage()) {
//	    	 UMReporter.log(Status.PASS, "Selected the Home breadcrumb");
//	    }
//		
		  home.MenuOtion("home", "");
		  if (home.VerifyLoggedinHomePage()) 
		    	 UMReporter.log(Status.PASS, "Selected the Home Navigation");
		  else
			  UMReporter.log(Status.FAIL, "Unable to select Home breadcrumb");
		 
	}
	
	@Then("^Verify the (.*) columns in Organizations Table$")
	public void verify_organizations_Table_fields(String displayCols) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the "+displayCols+" columns in Organizations Table");
		String Fieldname;
		List<String> NonVerified=null;
		boolean flag = true;
		List<String> MapDgOrgColHeader=manageorgs.getOrgColumnHeaderDetails();
		if (MapDgOrgColHeader!=null) {
			NonVerified=new ArrayList<String>();
			String arrCols[]=displayCols.split("/");
			for (int i = 0; i < arrCols.length; i++) {
				Fieldname = arrCols[i];
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified!=null)
			UMReporter.log(Status.FAIL, "The following expected organization table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following organizations Table fields are verified :"+MapDgOrgColHeader);
	}
	
	
	@Then("^Verify organizations list are sorted alphabetically by (.*)$")
	public void verify_organizations_Table_Sorting_fields(String displayCols) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the "+displayCols+" columns in Organizations Table");
		String Fieldname;
		List<String> NonVerified=null;
		boolean flag = true;
		List<String> MapDgOrgColHeader=manageorgs.getOrgColumnHeaderDetails();
		if (MapDgOrgColHeader!=null) {
			NonVerified=new ArrayList<String>();
			String arrCols[]=displayCols.split("/");
			for (int i = 0; i < arrCols.length; i++) {
				Fieldname = arrCols[i];
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified!=null)
			UMReporter.log(Status.FAIL, "The following expected organization table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following organizations Table fields are verified :"+MapDgOrgColHeader);
	}

	@When("^User select the organization from Organization list$")
	public void user_clicks_on_First_IN_OrganizationsList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select the organization from Organization list");
		boolean flag=false;
		String OrgName=null;
	//	HashMap<String,String> MapOrgField=null;
		// Get Org Search results by row number
		MapOrgField=manageorgs.getOrgsearchresultsDetails(1);
		if(MapOrgField!=null) {

			if (MapOrgField.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"))) 
				OrgName=MapOrgField.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"));
			else if (MapOrgField.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch")))
				OrgName=MapOrgField.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch"));
			//Click on Org Name hyperlink on Org list page
			flag=manageorgs.clickonOrgame(OrgName);
				//Check the Org selected
				if(flag) {
					CommonUtility._sleepForGivenTime(3000);
					UMReporter.log(Status.PASS,"Selected the Organization name "+OrgName+" hyperlink in Organizations datagrid");
				}
				else
					UMReporter.log(Status.FAIL,"The Organization name "+OrgName+"  not found in Organizations datagrid");	
			
		}
		else
			UMReporter.log(Status.FAIL,"No records found in Organizations datagrid");	
		
	}
	
	@Then("^Verify organization details page is displayed$")
	public void verify_whether_organization_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify organization details page is displayed ");
		//Verify the Organization Detail page displayed
		if(orgdetails.verifyOrganizationDetailsNavigation())
			UMReporter.log(Status.PASS,"User is navigated to organization details page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Then("^Verify the organization name is displayed in Organization details page$")
	public void verify_Student_name_in_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the organization name is displayed in Organization details page");
		if (MapOrgField!=null) {
			String OrgName=null;
			if (MapOrgField.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"))) 
				OrgName=MapOrgField.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.dist"));
			else if (MapOrgField.containsKey(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch")))
				OrgName=MapOrgField.get(Constants.mapCustomLabels.get("pa.core.org.search.column.title.name.sch"));
			
			if(orgdetails.verifyOrgName(OrgName))
				UMReporter.log(Status.PASS,"Verified the Organization name in Organization details page :"+OrgName);
			else
				UMReporter.log(Status.FAIL,"The Organization name not found in Organization details page :"+OrgName);
		
		}
	    else
	    	UMReporter.log(Status.FAIL,"Organization name not exist");
	}
	
	@Then("^Verify the Last updated date value is displayed in Organization details page$")
	public void verify_LastUpdate_in_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the Last updated date value is displayed in Organization details page");
		String LastUpdate=orgdetails.verifyLastUpdatedLabel();
		if(LastUpdate!=null)
			UMReporter.log(Status.PASS,"Verified the Last updated date in Organization details page :"+LastUpdate);
		else
			UMReporter.log(Status.FAIL,"The Last updated date not found in Organization details page :"+LastUpdate);

	}
	
	@Given("^Verify the Organization Info fields in Organization details page$")
	public void verify_Organization_info_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the Organization Info fields in Organization details page");
		String Fieldname,FieldValue;
		List<String> NonVerified=null;
		List<String> VerifiedField=null;
		if(orgdetails.Verify_Organization_Info()){
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				
				System.out.println("Fieldname:" + Fieldname);
				if (!orgdetails.verifyOrganizationLabel(Fieldname))
					NonVerified.add(Fieldname);
				else {
					FieldValue=orgdetails.GetValueforOrganizationLabel(Fieldname);
					VerifiedField.add(Fieldname+" = "+FieldValue);
				}
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected Organization Info fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following Organization Info fields with values are verified :"+VerifiedField);
		}
		else
			UMReporter.log(Status.FAIL, "The Organization Info fields not found");
	}
	
	@Given("^Verify the Organization Mailing Address fields in Organization details page$")
	public void verify_Organization_MailingAddress_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the Organization Mailing Address fields in Organization details page");
		String Fieldname,FieldValue;
		List<String> NonVerified=null;
		List<String> VerifiedField=null;
		if(orgdetails.Verify_Organization_Address()){
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				System.out.println("Fieldname:" + Fieldname);
				if (!orgdetails.verifyOrganizationLabel(Fieldname))
					NonVerified.add(Fieldname);
				else{
					FieldValue=orgdetails.GetValueforOrganizationLabel(Fieldname);
					VerifiedField.add(Fieldname+" = "+FieldValue);
				}
					
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected  Organization Mailing Address fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following  Organization Mailing Address fields with values are verified :"+VerifiedField);
		}
		else
			UMReporter.log(Status.FAIL, "The Organization Mailing Addres fields not found");
		
	}
	
	@Given("^Verify the Organization Contact Info fields in Organization details page$")
	public void verify_Organization_contact_Info_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the Organization Contact Info fields in Organization details page");
		String Fieldname,FieldValue;
		List<String> NonVerified=null;
		List<String> VerifiedField=null;
		if(orgdetails.Verify_Organization_Contact()){
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				System.out.println("Fieldname:" + Fieldname);
				if (!orgdetails.verifyOrganizationLabel(Fieldname))
					NonVerified.add(Fieldname);
				else{
					FieldValue=orgdetails.GetValueforOrganizationLabel(Fieldname);
					VerifiedField.add(Fieldname+" = "+FieldValue);
				}
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected Organization Contact Info fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following Organization Contact Info fields with values are verified :"+VerifiedField);
		}
		else
			UMReporter.log(Status.FAIL, "The Organization Contact Info fields not found");
		
	}
	
	@Then("^Verify the selected Organization field values in Organization details page$")
	public void verify_Selected_Organization_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the selected Organization field values in Organization details page");
		if (MapOrgField!=null) {
			//Verify the Organization details page displayed
			orgdetails.verifyViewOrganizationDetails(MapOrgField);
		}
	    else
	    	UMReporter.log(Status.FAIL,"Organization Details are not found");
	}
	
	@Then("^Select Organization Management breadcrumb$")
	public void Select_breadcrumb_organization_list() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Organization Management> breadcrumb");
		boolean flag=orgdetails.clickOrgListBreadcrumb();
	    if (flag) {
	    	 UMReporter.log(Status.PASS, "Selected the Organization Management breadcrumb");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to select Organization Management breadcrumb");
	}
	
	@Then("^Select Districts breadcrumb$")
	public void Select_breadcrumb_District_list() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Districts breadcrumb");
		boolean flag=orgdetails.clickDistrictsBreadcrumb();
	    if (flag) {
	    	 UMReporter.log(Status.PASS, "Selected the Districts breadcrumb");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to select Districts breadcrumb");
	}
	
	@Then("^Select Schools breadcrumb$")
	public void Select_breadcrumb_Schools_list() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Schools breadcrumb");
		boolean flag=orgdetails.clickSchoolsBreadcrumb();
	    if (flag) {
	    	 UMReporter.log(Status.PASS, "Selected the Schools breadcrumb");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to select Schools breadcrumb");
	}
	
// Add contact	
	
	@When("^User check the fields control error on add contact page$")
	public void user_check_userfields_on_contact_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User check the fields control error on add contact page");
		// Get fields from Configuration json file
		List<OrgContactfield> fields = FileReaderManager.getInstance().getJsonReader().getOrgContactfield(Constants.ORG_STATE);
		// Checks the fields validation from Configuration field and user test data
		orgdetails.PageDataFieldValidation(fields, "required");
		UMReporter.log(Status.PASS, "Verified the User Input fields with Maximum, Minimum Length, Invalid data ");

	}	
	
	@Then("^Click on add contact button$")
	public void click_addcontact_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on add contact button");
		orgdetails.clickaddcontactButton();
		UMReporter.log(Status.PASS, "Selected the add contact button");
	}
	@Then("^Click on delete contact button$")
	public void click_deletecontact_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on delete contact button");
		orgdetails.clickDeletecontactButton();
		UMReporter.log(Status.PASS, "Selected the delete contact button");
	}
	
	@Then("^Click on save contact button$")
	public void click_save_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on save button");
		orgdetails.clickcontactsaveButton();
		UMReporter.log(Status.PASS, "Selected the save button");
	}
	
	@Then("^Click on edit contact button$")
	public void click_edit_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on edit button");
		orgdetails.clickcontacteditButton();
		UMReporter.log(Status.PASS, "Selected the edit button");
	}
	
	@Then("^Select organization Managemnent breadcrum$")
	public void Select_organizationmgmt_breadcrum() throws Exception {
		UMReporter.log(Status.INFO, "When : Select the Organization Management breadcrum");
		orgdetails.clickOrgMgmtBreadCrum();
		UMReporter.log(Status.PASS, "Selected the Organization Management breadcrum");
	}
	
	@Then("^Verify add button is visible and enable on Organization list page$")
	public void verify_add_button_is_visible_and_enable_on_Org_page() throws Exception{
		
		UMReporter.log(Status.INFO, "Then: Verify add button is visible and enable on Organization list page");    
		boolean createvisible = orgdetails.contactaddButton_isVisible();
		if(createvisible) {
			boolean createenabled = orgdetails.contactaddButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Add button is visable and enabled");
			else
				UMReporter.log(Status.FAIL, "Add button is not enabled");
		}
		else
			UMReporter.log(Status.FAIL, "Add contact button is not visible");
	
	}
	
	@Then("^Verify delete button is visible and enable on contacts$")
	public void verify_delete_button_is_visible_and_enable_on_Org_page() throws Exception{
		
		UMReporter.log(Status.INFO, "Then: Verify delete button is visible and enable on contacts");    
		boolean createvisible = orgdetails.contactDeleteButton_isVisible();
		if(createvisible) {
			boolean createenabled = orgdetails.contactDeleteButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Delete button is visable and enabled");
			else
				UMReporter.log(Status.FAIL, "Delete button is not enabled");
		}
		else
			UMReporter.log(Status.FAIL, "Delete contact button is not visible");
	
	}
	
	@Given("^User fill the contact informations in add contact org detail page$")
	public void user_fills_provided_fields_present_addcontacts(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User fill the Provided contact informations in org details page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		
		// Get fields from Configuration json file
		List<OrgContactfield> fields = FileReaderManager.getInstance().getJsonReader().getOrgContactfield(Constants.ORG_STATE);
		if (fields!=null) {
			if(orgdetails.VerifyAddcontactForm()) {
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapOrgcontactFilledFields=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
					OrgContactfield field=FileReaderManager.getInstance().getJsonReader().getOrgContactfieldbyLabel(fields, Fieldname);
					if (field!=null) {
						FilledFieldValue = orgdetails.FillOrgContactField(field, FieldValue);
						                  
						
						if (FilledFieldValue==null)
							NonVerified.add(Fieldname);
						else 
							MapOrgcontactFilledFields.put(Fieldname,FilledFieldValue);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following contact fields are unable to provide the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following contact fields provided the input values :"+ MapOrgcontactFilledFields);
				
			}
		}
	}
	
////Add or Update Organization
	
	@Then("^Verify Add button is visible and enabled in Organizations list page$")
	public void verify_Add_button_is_visible_and_Enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Add button is visible and enabled in Organizations list page");
		boolean createvisible = createorg.AddButton_isVisible();
		if(createvisible) {
			boolean createenabled = createorg.AddButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Add button is visible and enabled");
			else
				UMReporter.log(Status.FAIL, "Add button is visible and disabled");
		}
		else
			UMReporter.log(Status.FAIL, "Add button is not visible");
	}
	
	@When("^Click on Add button in Organizations list page$")
	public void Click_Add_button_inOrgList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Add button in Organizations list page");
		boolean isbtnclicked = createorg.clickAddButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Add button is click");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Add button");
		
	}
	
	@Then("^Verify Create Organization page is displayed$")
	public void verify_CreateOrg_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Create Organization page is displayed");
		//Verify the Class Detail page displayed
		if(createorg.verifyCreateOrganizationPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Create Organization page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	

	@Given("^User fill the Provided Organization details in Create Organization page$")
	public void user_fills_provided_fields_present_CreateOrgPage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User fill the Provided Organization details in Create Organization page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		
		// Get fields from Configuration json file
		List<Organizationsfield> fields = FileReaderManager.getInstance().getJsonReader().getOrgfieldsbyState(Constants.ORG_STATE);
		if (fields!=null) {
			if(createorg.VerifyCreateOrganizationForm()){
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapOrgFilledFields=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					
					if (FieldValue.indexOf("^")>=0)
						FieldValue=Constants.mapCustomLabels.get(FieldValue.substring(1));
					
					System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
					Organizationsfield field=FileReaderManager.getInstance().getJsonReader().getOrgfieldbyLabel(fields, Fieldname);
					if (field!=null) {
						FilledFieldValue = createorg.FillOrganizationField(field, FieldValue);
						if (FilledFieldValue==null)
							NonVerified.add(Fieldname);
						else 
							MapOrgFilledFields.put(Fieldname,FilledFieldValue);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following Organization fields are unable to provide the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following Organization fields provided the input values :"+MapOrgFilledFields);
				
			}
			else
				UMReporter.log(Status.FAIL, "The input form fields are not displayed in class Organization page ");
		}
	}
	
	@When("^User check the fields control error on Create Organization page$")
	public void user_check_fields_on_createOrg_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User check the fields control error on Create Organization page");
		HashMap<String,String> MapClassFieldvalidation=  new HashMap<String,String>();
		// Get fields from Configuration json file
		List<Organizationsfield> fields = FileReaderManager.getInstance().getJsonReader().getOrgfieldsbyState(Constants.ORG_STATE);
		// Checks the fields validation from Configuration field and user test data
		MapClassFieldvalidation=createorg.PageDataFieldValidation(fields, "required");
		UMReporter.log(Status.PASS, "Verified the following Input fields with Mandatory, Maximum, Minimum Length, Invalid data : "+MapClassFieldvalidation);

	}
	
	@Then("^Verify Save button is visible and disabled in Create Organization page$")
	public void verify_Save_button_is_visible_and_disabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Save button is visible and disabled in Create Organization page");
		boolean btnvisible = createorg.SaveButton_isVisible();
		if(btnvisible) {
			boolean btnenabled = createorg.SaveButton_isEnabled();
			if(btnenabled)
				UMReporter.log(Status.PASS, "Save button is visible and disable");
			else
				UMReporter.log(Status.FAIL, "Save button is visible and enable");
		}
		else
			UMReporter.log(Status.FAIL, "Save button is not visible");
	}
	
	@Then("^Verify Save button is enabled in Create Organization page$")
	public void verify_Save_button_is_visible_and_Enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Save button is enabled in Create Organization page");
		boolean btnvisible = createorg.SaveButton_isVisible();
		if(btnvisible) {
			boolean btnenabled = createorg.SaveButton_isEnabled();
			if(btnenabled)
				UMReporter.log(Status.PASS, "Save button is visible and enable");
			else
				UMReporter.log(Status.FAIL, "Save button is visible and disable");
		}
		else
			UMReporter.log(Status.FAIL, "Save button is not visible");
	}
	
	@Then("^Verify Cancel button is enabled in Create Organization page$")
	public void verify_Cancel_button_is_visible_and_Enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Cancel button is enabled in Create Organization page");
		boolean btnvisible = createorg.CancelButton_isVisible();
		if(btnvisible) 
				UMReporter.log(Status.PASS, "Cancel button is visible");
			else
				UMReporter.log(Status.FAIL, "Cancel button is not visible");
	
	}
	
	@When("^Click on Save button in Create Organization page$")
	public void Click_Save_button_inClassList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Save button in Create Organization page");
		boolean isbtnclicked = createorg.clickSaveButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Save button");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Save button");
		
	}
	
	@When("^Click on Cancel button in Create Organization page$")
	public void Click_Cancel_button_inClassList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Cancel button in Create Organization page");
		boolean isbtnclicked = createorg.clickCancelButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Cancel button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Cancel button");
		
	}
	
	@Then("^Verify the filled Organization information in Organization details page$")
	public void verify_filled_Class_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the filled Organization information in Organization details page");
		if (MapOrgFilledFields!=null) {
			//Verify the Student Detail page displayed
			if(orgdetails.verifyOrganizationDetailsNavigation())
			//Verify the Organization details page displayed
			orgdetails.verifyViewOrganizationDetails(MapOrgFilledFields);
			else
				UMReporter.log(Status.FAIL,"Organization Details is not displayed");
		}
	    else
	    	UMReporter.log(Status.FAIL,"Organization Details are not found");
	}
	
	@When("^Click on Edit button in Organization details page$")
	public void Click_Edit_button_inClassDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Edit button in Organization details page");
		boolean isbtnclicked = createorg.clickEditButton();//EditButton_isVisible
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Edit button");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Edit button");
		
	}
	
	@When("^Verify the Edit button visible in Organization details page$")
	public void Verify_Edit_button_inOrganizationDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Verify the Edit button visible in Organization details page");
		boolean isbtnclicked = createorg.EditButton_isVisible();//EditButton_isVisible
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Edit option is visible in Organization details page");
		else
			UMReporter.log(Status.FAIL, "Edit option is not visible in Organization details page");
		
	}
	
	@Given("^User edit the details in Organization details page$")
	public void user_edit_provided_fields_present_CreateClassPage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User edit the details in Organization details page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		
		// Get fields from Configuration json file
		List<Organizationsfield> fields = FileReaderManager.getInstance().getJsonReader().getOrgfieldsbyState(Constants.ORG_STATE);
		if (fields!=null) {
			if(createorg.VerifyCreateOrganizationForm()){
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapOrgEditedFields=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
					Organizationsfield field=FileReaderManager.getInstance().getJsonReader().getOrgfieldbyLabel(fields, Fieldname);
					if (field!=null) {
						FilledFieldValue = createorg.FillOrganizationField(field, FieldValue);
						if (FilledFieldValue==null)
							NonVerified.add(Fieldname);
						else 
							MapOrgEditedFields.put(Fieldname,FilledFieldValue);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following Organization fields are unable to edit the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following Organization fields edited the input values :"+MapOrgEditedFields);
			}
			else
				UMReporter.log(Status.FAIL, "The edit form fields are not displayed in Organization details page ");
		}
		
	}
	@Then("^Verify the edited Organization information in Organization details page$")
	public void verify_edited_Organization_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the edited Organization information in Organization details page");
		if (MapOrgEditedFields!=null) {
			//Verify the Student Detail page displayed
			if(orgdetails.verifyOrganizationDetailsNavigation())
				//Verify the Org details page displayed
			orgdetails.verifyViewOrganizationDetails(MapOrgEditedFields);
			else
				UMReporter.log(Status.FAIL,"Organization details page is not displayed");
		}
	    else
	    	UMReporter.log(Status.FAIL,"Organization details are not found");
	}
	
	@Given("^Navigate to My (.*) page$")
	public void navigate_to_MyState_page(String OrgType) throws Exception {
		UMReporter.log(Status.INFO,"Given : Navigate to My "+OrgType+" page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Organizations");
			throw new RuntimeException("Login fail!");
		}
		home.MenuOtion("organizations", "my "+OrgType.trim());
		//Verify the Organization Detail page displayed
		if(orgdetails.verifyOrganizationDetailsNavigation())
			UMReporter.log(Status.PASS,"User is navigated to My "+OrgType+" organization details page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Then("^Verify the My (.*) details is displayed in Organization details page$")
	public void verify_Org_name_in_details_page_is_displayed(String OrgType) throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify My "+OrgType+" details is displayed in Organization details page");
		String OrgCode=null,OrgName=null;
		
		OrgName=home.Func_GetCurrentOrgName();
		String[] arrOrg = OrgName.split("\\(");
		if (arrOrg.length > 1) {
			OrgName= arrOrg[0].trim();
			OrgCode= arrOrg[1].trim();
			String[] arrOrg1 = OrgCode.split("\\)");
			if (arrOrg1.length >= 1) 
				OrgCode=arrOrg1[0].trim();
			
		}
		if (OrgName!=null) {
				if(orgdetails.verifyOrgName(OrgName))
					UMReporter.log(Status.PASS,"Verified My "+OrgType+" details in Organization details page :"+OrgName+" - "+OrgCode);
				else
					UMReporter.log(Status.FAIL,"My "+OrgType+" details is not found in Organization details page :"+OrgName);
		}
	    else
	    	UMReporter.log(Status.FAIL,"Organization name not exist");
	}
	
	@Given("^Navigate to Districts page$")
	public void navigate_to_Districts_page() throws Exception {
		UMReporter.log(Status.INFO,"Given : Navigate to Districts page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Organizations");
			throw new RuntimeException("Login fail!");
		}
		home.MenuOtion("organizations", "districts");
		//Verify the Organization list page displayed
		if(manageorgs.verifyDistrictsPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated to District organization list page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Given("^Navigate to Schools page$")
	public void navigate_to_Schools_page() throws Exception {
		UMReporter.log(Status.INFO,"Given : Navigate to Schools page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Organizations");
			throw new RuntimeException("Login fail!");
		}
		home.MenuOtion("organizations", "Schools");
		//Verify the Organization list page displayed
		if(manageorgs.verifySchoolsPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Schools organization list page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Then("^Verify the list of Districts displayed in Districts page$")
	public void verify_District_organization_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the list of Districts displayed in Districts page");
		List<String> MapDgOrgColHeader=manageorgs.verifyOrgsearchresultsDetails(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following Districts lists are accessed :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The Districts are not found in list");
	}
	
	@Then("^Verify the list of Schools displayed in Schools page$")
	public void verify_Schools_organization_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the list of Schools displayed in Schools page");
		List<String> MapDgOrgColHeader=manageorgs.verifyOrgsearchresultsDetails(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following Schools lists are accessed :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The Schools are not found in list");
	}
	

	@Then("^Verify delete button is enabled in Organization list page$")
	public void verify_delete_button_is_Enabledvisible() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify delete button is enabled in Organization list page");
		boolean deleteenabled = manageorgs.deleteButton_isEnabled();
		if(deleteenabled)
			UMReporter.log(Status.PASS, "Delete button is enabled");
		else
			UMReporter.log(Status.FAIL, "Delete button is disabled after selecting record");
	}
	
	@When("^Click on delete button in Organization list page$")
	public void Click_Delete_button_in_OrgList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on delete button in Organization list page");
		boolean isbtnclicked = manageorgs.clickDeleteButton();
		if(isbtnclicked) {
			UMReporter.log(Status.PASS, "Selected the delete button");
//			isbtnclicked=manageorgs.waitForProgressbarVisible(15);
//			if(isbtnclicked) 
//				UMReporter.log(Status.PASS, "Selected the delete button");
//			else
//				UMReporter.log(Status.PASS, "Progress bar is displayed for long time after delete");
			
		}
		else
			UMReporter.log(Status.FAIL, "Unable to click the delete button");
	}
	
	@When("^Select the (.*) (?:School|District) in Organization list page$")
	public void Select_Org_list_checkbox_Orglist(String orgcount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the "+orgcount+" Organization in Organization list page");
		int stucnt=1;
		if (CommonUtility.isNumeric(orgcount))
			stucnt=Integer.parseInt(orgcount);
		lstSelectedOrg=manageorgs.SelectonOrgCheckbox(stucnt);
	    if (lstSelectedOrg.size()>0)
	    	UMReporter.log(Status.PASS, "Selected the Organization checkbox "+lstSelectedOrg);
	    else
	    	UMReporter.log(Status.FAIL, "The Organization are not found in list");
	}	
	@Then("^Verify the Organization are removed in Organization list page$")
	public void verify_Selected_Org_Removed_Orglist() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Organization are removed in Organization list page");
		List<String> removeOrg=null;
		if (lstSelectedOrg!=null) {
			removeOrg=new ArrayList<String>();
			for (String org:lstSelectedOrg) {
				List<String> MapDgStuColHeader=manageorgs.verifyOrgSearchresultsDetailsfromlist(org);
				if(MapDgStuColHeader==null)
					removeOrg.add(org);
				else if (MapDgStuColHeader.size()<1)
					removeOrg.add(org);
			}
	    if (removeOrg.size()>0)
	    	UMReporter.log(Status.PASS, "The following Organization are removed in Organization List Page :"+removeOrg);
	    else
	    	UMReporter.log(Status.FAIL, "The following Organization lists are not removed in Organization List Page :"+lstSelectedOrg);
		}
		else
			UMReporter.log(Status.PASS, "The Organization are not found in list");
	}
	
	
	@Then("^Verify the Organization are not removed in Organization list page$")
	public void verify_Selected_Org_NotRemoved_Orglist() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Organization are not removed in Organization list page");
		List<String> removeOrg=null;
		if (lstSelectedOrg!=null) {
			removeOrg=new ArrayList<String>();
			for (String org:lstSelectedOrg) {
				List<String> MapDgStuColHeader=manageorgs.verifyOrgSearchresultsDetailsfromlist(org);
				if(MapDgStuColHeader==null)
					removeOrg.add(org);
				else if (MapDgStuColHeader.size()<1)
					removeOrg.add(org);
			}
	    if (removeOrg.size()>0)
	    	UMReporter.log(Status.FAIL, "The following Organization lists are not removed in Organization List Page :"+lstSelectedOrg);
	    else
	    	UMReporter.log(Status.PASS, "The following Organization are removed in Organization List Page :"+removeOrg);
		}
		else
			UMReporter.log(Status.PASS, "The Organization are not found in list");
	}
	@Then("^Verify success message displayed in Organizations list page as (.*)$")
	public void verify_success_message_gets_displayed_on_OrgList_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Organization list page as " + messages);
		boolean flag;
		if (messages.contains("<X>")) { 
			if (lstSelectedOrg!=null) {
				int iSelectedOrgCount=lstSelectedOrg.size();
				if (iSelectedOrgCount != 0) // Orgcount
					messages = messages.replace("<X>", String.valueOf(iSelectedOrgCount));
			}
		}
		flag = manageorgs.verifySuccessMessage(messages);
		if (flag) 
			UMReporter.log(Status.PASS, "Verified the success message displayed in Organization list page:" + messages);
		else
			UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
	}
	
	
	@Then("^Verify the error message displayed in Organization list page as (.*)$")
	public void verify_error_message_gets_displayed_on_OrgList_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the error message displayed in Organization list page as " + messages);
		boolean flag;
		if (messages.contains("<X>")) { 
			if (lstSelectedOrg!=null) {
				int iSelectedOrgCount=lstSelectedOrg.size();
				if (iSelectedOrgCount != 0) // Orgcount
					messages = messages.replace("<X>", String.valueOf(iSelectedOrgCount));
			}
		}
		flag = manageorgs.verifySuccessMessage(messages);
		if (flag) 
			UMReporter.log(Status.PASS, "Verified the success message displayed in Organization list page:" + messages);
		else
			UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
	}

	@When("^Verify title and content (.*) in Confirmation Delete Organization pop-up$")
	public void Verify_title_message_ConfirmPopUp_button(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Confirm Delete Organization pop-up");
		boolean flag=false;
		// Verify the Confirm pop up
		flag=CommonFunctions.VerifyConfirmPopupContent(Constants.DeleteOrgConfirmPopupTitle,confmessage);
		if (flag)
			UMReporter.log(Status.PASS, "Verified Confirm Delete Organization pop-up title and message : " +confmessage);
			
	}
	
	@When("^Click on confirm button on Confirmation Delete Organization pop-up$")
	public void Click_confirm_on_ConfirmDeleteOrgpopup() throws Exception {
		UMReporter.log(Status.INFO, "When :  Click on confirm button on Confirmation Delete Organization pop-up");
			// Verify the Click Confirm in pop up
		boolean flag=CommonFunctions.ConfirmPopupActionBtn("Confirm");
		CommonUtility._sleepForGivenTime(3000);
			if (flag) {
				flag=manageorgs.waitForProgressbarVisible(15);
				if(flag) 
					UMReporter.log(Status.PASS, "Select the Confirm button and navigated to Organization list page" );
				else
					UMReporter.log(Status.PASS, "Progress bar is displayed for long time after delete");
				
			}
			else
				UMReporter.log(Status.FAIL, "Select the Confirm button and Student list not displayed " );
	}

	@When("^Click on cancel button on Confirmation Delete Organization pop-up$")
	public void Click_cancel_on_ConfirmDeleteOrgn_button() throws IOException {
		UMReporter.log(Status.INFO, "When :  Click on cancel button on Confirmation Delete Organization pop-up");
		
			// Verify the Click cancel in pop up
			boolean flag=CommonFunctions.ConfirmPopupActionBtn("Cancel");
			CommonUtility._sleepForGivenTime(3000);
			if (flag) 
				UMReporter.log(Status.PASS, "Select the Cancel button and pop up is closed " );
			else
				UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed " );
	}
	
	@Given("^User permissions in My Organizations page$")
	public void User_Permission_to_MyOrg_page() throws Exception {
		
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		List<String> LstUserPermissions=Constants.PERMISSIONS;
		
		if (LstUserPermissions.contains("VIEW_MY_ORGANIZATION_DETAILS")) {
			if (home.VerifyMenuOtion("organizations", "my state")) {
				UMReporter.log(Status.INFO, "Given : User permissions in State page");
				home.MenuOtion("organizations", "my state");
				if (LstUserPermissions.contains("VIEW_ORGANIZATION_DETAILS")) {
						if(orgdetails.verifyOrganizationDetailsNavigation()) {
							String OrgCode=null,OrgName=null;
							OrgName=home.Func_GetCurrentOrgName();
							String[] arrOrg = OrgName.split("\\(");
							if (arrOrg.length > 1) {
								OrgName= arrOrg[0].trim();
								OrgCode= arrOrg[1].trim();
								String[] arrOrg1 = OrgCode.split("\\)");
								if (arrOrg1.length >= 1) 
									OrgCode=arrOrg1[0].trim();
								
							}
							if (OrgName!=null) 
									if(orgdetails.verifyOrgName(OrgName))
										UMReporter.log(Status.PASS, "User have access to View State detail for pinned organization : "+OrgName);
							
								if (LstUserPermissions.contains("EDIT_ORGANIZATION_DETAILS")) {
									if(orgdetails.EditButton_isVisible())
										UMReporter.log(Status.PASS, "User have access to Edit State, Edit button is displayed");
									else
										UMReporter.log(Status.FAIL, "User have access to Edit State, Edit button is not displayed");
								}
						}	
						else
							UMReporter.log(Status.FAIL,"The State details is not displayed");	
						
				}
			}
			else if (home.VerifyMenuOtion("organizations", "my district")) {
				UMReporter.log(Status.INFO, "Given : User permissions in My District page");
				home.MenuOtion("organizations", "my district");
				if (LstUserPermissions.contains("VIEW_ORGANIZATION_DETAILS")) {
						if(orgdetails.verifyOrganizationDetailsNavigation()) {
							String OrgCode=null,OrgName=null;
							OrgName=home.Func_GetCurrentOrgName();
							String[] arrOrg = OrgName.split("\\(");
							if (arrOrg.length > 1) {
								OrgName= arrOrg[0].trim();
								OrgCode= arrOrg[1].trim();
								String[] arrOrg1 = OrgCode.split("\\)");
								if (arrOrg1.length >= 1) 
									OrgCode=arrOrg1[0].trim();
								
							}
							if (OrgName!=null) 
									if(orgdetails.verifyOrgName(OrgName))
										UMReporter.log(Status.PASS, "User have access to View District detail for pinned organization : "+OrgName);
							
								if (LstUserPermissions.contains("EDIT_ORGANIZATION_DETAILS")) {
									if(orgdetails.EditButton_isVisible())
										UMReporter.log(Status.PASS, "User have access to Edit District, Edit button is displayed");
									else
										UMReporter.log(Status.FAIL, "User have access to Edit District, Edit button is not displayed");
								}
						}	
						else
							UMReporter.log(Status.FAIL,"The District details is not displayed");	
						
				}
			}
			else if (home.VerifyMenuOtion("organizations", "my school")) {
				UMReporter.log(Status.INFO, "Given : User permissions in My School page");
				home.MenuOtion("organizations", "my school");
				if (LstUserPermissions.contains("VIEW_ORGANIZATION_DETAILS")) {
						if(orgdetails.verifyOrganizationDetailsNavigation()) {
							String OrgCode=null,OrgName=null;
							OrgName=home.Func_GetCurrentOrgName();
							String[] arrOrg = OrgName.split("\\(");
							if (arrOrg.length > 1) {
								OrgName= arrOrg[0].trim();
								OrgCode= arrOrg[1].trim();
								String[] arrOrg1 = OrgCode.split("\\)");
								if (arrOrg1.length >= 1) 
									OrgCode=arrOrg1[0].trim();
								
							}
							if (OrgName!=null) 
									if(orgdetails.verifyOrgName(OrgName))
										UMReporter.log(Status.PASS, "User have access to View School detail for pinned organization : "+OrgName);
							
								if (LstUserPermissions.contains("EDIT_ORGANIZATION_DETAILS")) {
									if(orgdetails.EditButton_isVisible())
										UMReporter.log(Status.PASS, "User have access to Edit School, Edit button is displayed");
									else
										UMReporter.log(Status.FAIL, "User have access to Edit School, Edit button is not displayed");
								}
						}	
						else
							UMReporter.log(Status.FAIL,"The School details is not displayed");	
				}
			}
			
		}
		else
			UMReporter.log(Status.PASS,"User restricted for My Organization");
	}
	
	@Given("^User permissions in Organizations page$")
	public void User_Permission_to_Organization_page() throws Exception {
		
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		List<String> LstUserPermissions=Constants.PERMISSIONS;
		
		if (LstUserPermissions.contains("VIEW_ORGANIZATIONS_LIST")) {

			if (home.VerifyMenuOtion("organizations", "districts")) {
				UMReporter.log(Status.INFO, "Given : User permissions in Districts page");
				home.MenuOtion("organizations", "districts");
				//Verify the Organization list page displayed
				if(manageorgs.verifyDistrictsPageNavigation()) {
					UMReporter.log(Status.PASS,"User have access Districts in the hamburger menu");
					List<String> MapDgOrgColHeader=manageorgs.verifyOrgsearchresultsDetails(1);
				    if (MapDgOrgColHeader!=null)
				    	UMReporter.log(Status.PASS, "User have access to view list of Districts :"+MapDgOrgColHeader);
				    
				    if (LstUserPermissions.contains("CREATE_ORGANIZATION")) {
						if(importexport.VerifyTabOption_isVisible("Create District")) {
							UMReporter.log(Status.PASS, "User have access to Create Districts, Create District Tab is visible");
						}
						else
							UMReporter.log(Status.SKIP, "User have access to Create Districts, Create District Tab is not visible");		
					}
				    
				    if (LstUserPermissions.contains("DELETE_ORGANIZATION")) {
				    	lstSelectedOrg=manageorgs.SelectonOrgCheckbox(1);
					    if (lstSelectedOrg.size()>0) {
							if(manageorgs.deleteButton_isVisible())
								UMReporter.log(Status.PASS, "User have access to Delete Districts, Delete button is displayed when selected the class "+lstSelectedOrg);
							else
								UMReporter.log(Status.FAIL, "User have access to Delete Districts, Delete button is not visible");
					    }
					    else
					    	UMReporter.log(Status.SKIP, "User have access to Delete Districts, Unable to select Organization checkbox");
					}
					if (LstUserPermissions.contains("VIEW_ORGANIZATION_DETAILS")) {
						MapOrgField=manageorgs.SelectOrglist();
						if(MapOrgField!=null) {
							
							if(orgdetails.verifyOrganizationDetailsNavigation()) {
								orgdetails.verifyViewOrganizationDetails(MapOrgField);
									
									if (LstUserPermissions.contains("EDIT_ORGANIZATION_DETAILS")) {
										if(orgdetails.EditButton_isVisible())
											UMReporter.log(Status.PASS, "User have access to Edit District, Edit button is displayed");
										else
											UMReporter.log(Status.FAIL, "User have access to Edit District, Edit button is not displayed");
									}
							}	
							else
								UMReporter.log(Status.FAIL,"The District details is not displayed");	
							}
							else
								UMReporter.log(Status.SKIP,"No records found in Districts list");
					}
				}
			}
			//Schools
			if (home.VerifyMenuOtion("organizations", "schools")) {
				UMReporter.log(Status.INFO, "Given : User permissions in Schools page");
				home.MenuOtion("organizations", "schools");
				//Verify the Organization list page displayed
				if(manageorgs.verifySchoolsPageNavigation()) {
					UMReporter.log(Status.PASS,"User have access Schools in the hamburger menu");
					List<String> MapDgOrgColHeader=manageorgs.verifyOrgsearchresultsDetails(1);
				    if (MapDgOrgColHeader!=null)
				    	UMReporter.log(Status.PASS, "User have access to view list of Schools :"+MapDgOrgColHeader);
				    
				    if (LstUserPermissions.contains("CREATE_ORGANIZATION")) {
				    	if(importexport.VerifyTabOption_isVisible("Create School")) {
				    		UMReporter.log(Status.PASS, "User have access to Create Schools, Create School Tab is visible");
//							importexport.SelectTabOption("School List");
//							CommonUtility._sleepForGivenTime(2000);
						}
						else
							UMReporter.log(Status.SKIP, "User have access to Create Schools, Create School Tab is not visible");		
					}
				    
				    if (LstUserPermissions.contains("DELETE_ORGANIZATION")) {
				    	lstSelectedOrg=manageorgs.SelectonOrgCheckbox(1);
					    if (lstSelectedOrg.size()>0) {
							if(manageorgs.deleteButton_isVisible())
								UMReporter.log(Status.PASS, "User have access to Delete Schools, Delete button is displayed when selected the class "+lstSelectedOrg);
							else
								UMReporter.log(Status.FAIL, "User have access to Delete Schools, Delete button is not visible");
					    }
					    else
					    	UMReporter.log(Status.SKIP, "User have access to Delete Schools, Unable to select Organization checkbox");
					}
					if (LstUserPermissions.contains("VIEW_ORGANIZATION_DETAILS")) {
						MapOrgField=manageorgs.SelectOrglist();
						if(MapOrgField!=null) {
							if(orgdetails.verifyOrganizationDetailsNavigation()) {
								orgdetails.verifyViewOrganizationDetails(MapOrgField);
									
									if (LstUserPermissions.contains("EDIT_ORGANIZATION_DETAILS")) {
										if(orgdetails.EditButton_isVisible())
											UMReporter.log(Status.PASS, "User have access to Edit School, Edit button is displayed");
										else
											UMReporter.log(Status.FAIL, "User have access to Edit School, Edit button is not displayed");
									}
							}	
							else
								UMReporter.log(Status.FAIL,"The School details is not displayed");	
							}
							else
								UMReporter.log(Status.SKIP,"No records found in Schools list");
					}
				}
			}
		}
		else
			UMReporter.log(Status.PASS,"User restricted for Organization");
	}
	
	
	@Given("^User switch to (.*) Reports Tab in Organization details page$")
	public void Select_Org_reports_list_Tab(String OrgType) throws Exception {
		UMReporter.log(Status.INFO, "Given : User switch to "+OrgType+" Reports Tab in Organization details page");
		boolean flag=false;
		String OrgTypeReport=OrgType+" Reports";
		flag=orgdetails.SelectTabOption(OrgTypeReport);
	    if (flag) {
	    	CommonFunctions.waitUntilLoadingSpinner(120);
	    	 UMReporter.log(Status.PASS, "Selected the "+OrgTypeReport+" Tab");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to select "+OrgTypeReport+" Tab");
	}
	
	@Given("^Verify the (?:State|LEA|District|School) Reports Table fields in Organization details page$")
	public void verify_OrgReports_Table_fields_In_Organizations_details(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When :Verify the Reports Table fields in Organization details page");
		String Fieldname;
		List<String> NonVerified=null;
		List<String> MapDgOrgColHeader=orgdetails.getOrgReportColumnHeaderDetails();
		if (MapDgOrgColHeader!=null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Table fields are verified :"+MapDgOrgColHeader);
	}
	
	@Given("^Verify the (?:State|LEA|District|School) Reports Table fields are sortable in Organization details page$")
	public void verify_OrgReports_Table_fields_Sortable(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When :Verify the Table fields are sortable in Organization details page");
		String Fieldname;
		List<String> NotVerified=null;
		List<String> MapDgColValues=null;
		if (orgdetails.Verify_OrgHasReports()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NotVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				
				MapDgColValues=orgdetails.verifyOrgReportSearchresultsSorting(Fieldname);
				if (MapDgColValues==null) 
					NotVerified.add(Fieldname);
			}
			if (NotVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following Reports Table fields are not Sortable :"+NotVerified);
			else
				UMReporter.log(Status.PASS, "The following Reports Table fields are Sortable :"+list);
		}
		else
			UMReporter.log(Status.SKIP, "No records in Reports list");
	}
	
	@Then("^User able to access the (?:State|LEA|District|School) Reports list in Organization details page$")
	public void verify_OrgReports_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the Reports list in Organization details page");
		if (orgdetails.Verify_OrgHasReports()) {
			List<String> MapDgOrgColHeader=orgdetails.verifyOrgReportResultsDetails(3);
		    if (MapDgOrgColHeader!=null)
		    	UMReporter.log(Status.PASS, "The following reports lists are accessed :"+MapDgOrgColHeader);
		    else
		    	UMReporter.log(Status.FAIL, "The reports are not found in list");
		}
		else
			UMReporter.log(Status.SKIP, "No records in Reports list");
	}
	
	@Given("^User include the Shipping Coordinator in Create Organization page$")
	public void user_fills_Contact_fields_present_addcontacts_CreatePage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User include the Shipping Coordinator in Create Organization page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;

		// Get fields from Configuration json file
		List<OrgContactfield> fields = FileReaderManager.getInstance().getJsonReader().getOrgContactfield(Constants.ORG_STATE);
		if (fields!=null) {
			if(createorg.VerifyCreateOrganizationForm()){
				
				//createorg.ShippingCoordInclude("Yes");
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapOrgcontactFilledFields=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
					OrgContactfield field=FileReaderManager.getInstance().getJsonReader().getOrgContactfieldbyLabel(fields, Fieldname);
					if (field!=null) {
						FilledFieldValue = orgdetails.FillOrgContactField(field, FieldValue);
						if (FilledFieldValue==null)
							NonVerified.add(Fieldname);
						else 
							MapOrgcontactFilledFields.put(Fieldname,FilledFieldValue);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following contact fields are unable to provide the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following contact fields provided the input values :"+ MapOrgcontactFilledFields);
				
			}
		}
	}
	
	@Then("^Verify the Shipping Coordinator information in Organization details page$")
	public void verify_filled_Org_Shipping_Contact_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the Shipping Coordinator information in Organization details page");
		if(orgdetails.Verify_Organization_Contact()){
			if (MapOrgcontactFilledFields!=null) {
				//Verify the Org Contact Detail page displayed
				if(orgdetails.verifyOrganizationDetailsNavigation())
				//Verify the Organization Contact details page displayed
				orgdetails.verifyViewOrganizationDetails(MapOrgcontactFilledFields);
				else
					UMReporter.log(Status.FAIL,"Organization Shipping Details is not displayed");
			}
			else
		    	UMReporter.log(Status.FAIL,"Organization Shipping Details are not found");
		}
	    else
	    	UMReporter.log(Status.SKIP,"Organization Shipping Details are not found");
	}
	
	@Then("^Verify Edit Administration Time button is visible in Organization list page$")
	public void verify_EditAdministrationTime_button_is_Enabledvisible() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Edit Administration Time button is visible in Organization list page");
		boolean deleteenabled = manageorgs.EditAdminTimeButton_isVisible();
		if(deleteenabled)
			UMReporter.log(Status.PASS, "Edit Administration Time button is visible");
		else
			UMReporter.log(Status.FAIL, "Edit Administration Time button is not visible");
	}
	
	@When("^Click on Edit Administration Time button in Organization list page$")
	public void Click_EditAdministrationTime_button_in_OrgList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Edit Administration Time button in Organization list page");
		boolean isbtnclicked = manageorgs.clickEditAdminTimeButton();
		if(isbtnclicked) {
			UMReporter.log(Status.PASS, "Selected the Edit Administration Time button");
		}
		else
			UMReporter.log(Status.FAIL, "Unable to click the Edit Administration Time button");
	}
	
	@When("^Verify title in Edit Administration Time pop-up$")
	public void Verify_title_message_EditAdministrationTimePopUp() throws Exception {
		UMReporter.log(Status.INFO, "When :Verify title in Edit Administration Time pop-up");
		if(manageorgs.VerifyEditAdminModalDisplayed()){
			boolean flag=false;
			// Verify the Confirm pop up
			flag=CommonFunctions.VerifyConfirmPopupContent(Constants.EditAdminTimePopupTitle,"");
			if (flag)
				UMReporter.log(Status.PASS, "Verified Edit Administration Time pop-up title " );
		}
		else
			UMReporter.log(Status.SKIP, "Edit Administration Time pop-up not displyed");
	}
	
	@When("^User select (.*) Administration in Edit Administration Time pop-up$")
	public void Click_Administration_dropdown_icon_EditAdministrationTime_popup(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When: User select "+SeachText+" Administration in Edit Administration Time pop-up");
		if(manageorgs.VerifyEditAdminModalDisplayed()){
			// Get from Testdata
			if (SeachText.indexOf("$") >= 0)
				SeachText = CommonFunctions.getTestData(SeachText);
			boolean isbtnclicked = manageorgs.SelectAdministrationDropdown(SeachText);
			if (isbtnclicked)
				UMReporter.log(Status.PASS, "Selected the Administation");
			else
				UMReporter.log(Status.FAIL, "Unable to click the dropdown icon");
		}
		else
			UMReporter.log(Status.SKIP, "Edit Administration Time pop-up not displyed");
	}
	
	@Given("^Verify the Original Testing Schedule in Edit Administration Time pop-up$")
	public void verify_TestingSchedule_infon_EditAdministrationTime_popup(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the Original Testing Schedule in Edit Administration Time pop-up");
		if(manageorgs.VerifyEditAdminModalDisplayed()){
			String Fieldname,FieldValue;
			List<String> NonVerified=null;
			List<String> VerifiedField=null;
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!manageorgs.verifyEditAdminLabel(Fieldname))
					NonVerified.add(Fieldname);
				else {
					FieldValue=manageorgs.GetValueforEditAdminLabel(Fieldname);
					VerifiedField.add(Fieldname+" = "+FieldValue);
				}
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following Original Testing Schedule fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following Original Testing Schedule values :"+VerifiedField);
		}
		else
			UMReporter.log(Status.SKIP, "Edit Administration Time pop-up not displyed");
	}
	
	@Given("^User set the New Testing Schedule in Edit Administration Time pop-up$")
	public void user_set_provided_fields_EditAdministrationTime_popup(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User set the New Testing Schedule in Edit Administration Time pop-up");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		// Get fields from Configuration json file
		List<Organizationsfield> fields = FileReaderManager.getInstance().getJsonReader().getOrgfieldsbyState(Constants.ORG_STATE);
		if (fields!=null) {
			if(manageorgs.VerifyEditAdminModalDisplayed()){
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapOrgFilledFields=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					
					if (FieldValue.indexOf("^")>=0)
						FieldValue=Constants.mapCustomLabels.get(FieldValue.substring(1));
					
					System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
					Organizationsfield field=FileReaderManager.getInstance().getJsonReader().getOrgfieldbyLabel(fields, Fieldname);
					if (field!=null) {
						FilledFieldValue = createorg.FillOrganizationField(field, FieldValue);
						if (FilledFieldValue==null)
							NonVerified.add(Fieldname);
						else 
							MapOrgFilledFields.put(Fieldname,FilledFieldValue);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following Testing Schedule fields are unable to provide the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following Testing Schedule values :"+MapOrgFilledFields);
				
			}
			else
				UMReporter.log(Status.FAIL, "The input form fields are not displayed in Edit Administration Time pop-up ");
		}
	}
	@When("^Click on confirm button in Edit Administration Time pop-up$")
	public void Click_confirm_on_ConfirmEditAdministrationTimepopup() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on confirm button in Edit Administration Time pop-up");
			// Verify the Click Confirm in pop up
		boolean flag=CommonFunctions.ConfirmPopupActionBtn("Confirm");
		CommonUtility._sleepForGivenTime(3000);
		if (flag) {
			flag=manageorgs.waitForProgressbarVisible(15);
			if(flag) 
				UMReporter.log(Status.PASS, "Select the Confirm button and navigated to Organization list page" );
			else
				UMReporter.log(Status.PASS, "Progress bar is displayed for long time after delete");
		}
		else
			UMReporter.log(Status.FAIL, "Select the Confirm button and Organization list not displayed " );
	}
	@When("^Click on cancel button in Edit Administration Time pop-up$")
	public void Click_cancel_on_ConfirmEditAdministrationTime_popup() throws IOException {
		UMReporter.log(Status.INFO, "When : Click on cancel button in Edit Administration Time pop-up");
			// Verify the Click cancel in pop up
			boolean flag=CommonFunctions.ConfirmPopupActionBtn("Cancel");
			CommonUtility._sleepForGivenTime(3000);
			if (flag) 
				UMReporter.log(Status.PASS, "Select the Cancel button and pop up is closed " );
			else
				UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed " );
	}
	
	@When("^Select the (.*) Reports in (?:State|LEA|District|School) Reports list page$")
	public void Select_Course_checkbox_Course_list(String repcount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the " + repcount + " Reports in Reports list page");
		int stucnt = 1;
		if (CommonUtility.isNumeric(repcount))
			stucnt = Integer.parseInt(repcount);
		lstSelectedOrgReports = orgdetails.SelectonReportsCheckbox(stucnt);
		if (lstSelectedOrgReports.size() > 0)
			UMReporter.log(Status.PASS, "Selected the Reports checkbox " + lstSelectedOrgReports);
		else
			UMReporter.log(Status.FAIL, "The Reports are not found in list");
	}
	
	@Then("^Verify the (.*) bulk action is visible under (?:State|LEA|District|School) Reports list in Organization Details page$")
	public void verify_Reports_button_is_visible_in_DetailPage(String BulkActions) throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify the "+BulkActions+" bulk action is visible under Reports list in Organization Details page");
		if (lstSelectedOrgReports != null) {
			boolean btnvisible = orgdetails.ReportsButton_isVisible(BulkActions);
			if (btnvisible)
				UMReporter.log(Status.PASS, "Reports button is visible");
			else
				UMReporter.log(Status.SKIP,
						"Reports button is not visible, might reporting not enabled Please check manually");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}


	@Given("^Verify the Download CSVs bulk action displayed under (?:State|LEA|District|School) Reports list in Organization Details page$")
	public void verify_DownloadCSVs_In_ReportList_in_OrganizationDetails_page(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Download CSVs bulk action displayed displayed under Report List in Organization Details page");
		String Fieldname;
		List<String> NonVerified = null;
		boolean flag = true;
		if (lstSelectedOrgReports != null) {
			if (orgdetails.ReportsButton_isVisible("Download CSVs")) {
				List<String> MapReportItems = orgdetails.VerifyReportsList("Download CSVs");
				if (MapReportItems.size() > 0) {
					List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
					NonVerified = new ArrayList<String>();
					for (int i = 0; i < list.size(); i++) {
						Fieldname = list.get(i).get("ReportItems");
						System.out.println("Reports:" + Fieldname);
						if (!MapReportItems.contains(Fieldname))
							NonVerified.add(Fieldname);
					}
				}
				if (NonVerified.size() > 0)
					UMReporter.log(Status.FAIL,
							"The following expected Report actions are not exist in frontend :" + NonVerified);
				else
					UMReporter.log(Status.PASS, "The following Report actions are verified :" + MapReportItems);
			} else
				UMReporter.log(Status.SKIP, "Download CSVs options not exist ");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}
	
	
	@Given("^Verify the Download Final PDFs bulk action displayed under (?:State|LEA|District|School) Reports list in Organization Details page$")
	public void verify_DownloadFinalPDFs_In_ReportList_in_OrganizationDetails_page(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Download Final PDFs bulk action displayed displayed under Report List in Organization Details page");
		String Fieldname;
		List<String> NonVerified = null;
		boolean flag = true;
		if (lstSelectedOrgReports != null) {
			if (orgdetails.ReportsButton_isVisible("Download Final PDFs")) {
				List<String> MapReportItems = orgdetails.VerifyReportsList("Download Final PDFs");
				if (MapReportItems.size() > 0) {
					List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
					NonVerified = new ArrayList<String>();
					for (int i = 0; i < list.size(); i++) {
						Fieldname = list.get(i).get("ReportItems");
						System.out.println("Reports:" + Fieldname);
						if (!MapReportItems.contains(Fieldname))
							NonVerified.add(Fieldname);
					}
				}
				if (NonVerified.size() > 0)
					UMReporter.log(Status.FAIL,
							"The following expected Report actions are not exist in frontend :" + NonVerified);
				else
					UMReporter.log(Status.PASS, "The following Report actions are verified :" + MapReportItems);
			} else
				UMReporter.log(Status.SKIP, "Download Final PDFs options not exist ");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}

	@Given("^Verify the Online Reports bulk action displayed under (?:State|LEA|District|School) Reports list in Organization Details page$")
	public void verify_OnlineReports_In_ReportList_in_OrganizationDetails_page(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Online Reports bulk action displayed displayed under Report List in Organization Details page");
		String Fieldname;
		List<String> NonVerified = null;
		boolean flag = true;
		if (lstSelectedOrgReports != null) {
			if (orgdetails.ReportsButton_isVisible("Online Reports")) {
				List<String> MapReportItems = orgdetails.VerifyReportsList("Online Reports");
				if (MapReportItems.size() > 0) {
					List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
					NonVerified = new ArrayList<String>();
					for (int i = 0; i < list.size(); i++) {
						Fieldname = list.get(i).get("ReportItems");
						System.out.println("Reports:" + Fieldname);
						if (!MapReportItems.contains(Fieldname))
							NonVerified.add(Fieldname);
					}
				}
				if (NonVerified.size() > 0)
					UMReporter.log(Status.FAIL,
							"The following expected Report actions are not exist in frontend :" + NonVerified);
				else
					UMReporter.log(Status.PASS, "The following Report actions are verified :" + MapReportItems);
			} else
				UMReporter.log(Status.SKIP, "Online Reports options not exist ");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}

	@Then("^Select the (.*) in (.*) bulk action with  displayed under (?:State|LEA|District|School) Reports list in Organization Details page$")
	public void Select_Report_displayed_in_Session_page_as(String ActionButton,String reportname) throws Exception {
		UMReporter.log(Status.INFO, "Then : Select the bulk action displayed under Reports list in Organization Details page" + reportname);
		boolean flag;
		if (lstSelectedOrgReports != null) {
			if (orgdetails.ReportsButton_isVisible(ActionButton)) {
				CurrentWinHnd = CommonFunctions.GetCurrentWindowHandle();
				flag = orgdetails.SelectReportFromList(ActionButton,reportname);
				if (flag)
				{
					String Downloadedfilename = "";
					if (ActionButton.equalsIgnoreCase("Download CSVs")) {
						CommonUtility._sleepForGivenTime(5000);
						// Get Latest file and check if matches the title
						File downloadedfile = csvfreader.getLatestDownloadFile("zip");
						String exportfilename = downloadedfile.getName();
						Downloadedfilename=" and downloaded file "+exportfilename;
					}
					else if (ActionButton.equalsIgnoreCase("Download Final PDFs")) {
						CommonUtility._sleepForGivenTime(5000);
						// Get Latest file and check if matches the title
						File downloadedfile = csvfreader.getLatestDownloadFile("pdf");
						String exportfilename = downloadedfile.getName();
						Downloadedfilename=" and downloaded file "+exportfilename;
					}
					else if (ActionButton.equalsIgnoreCase("Online Reports")) {
						CommonUtility._sleepForGivenTime(5000);
						Set<String> testTicketsWinHnd = WebDriverMain._getDriver().getWindowHandles();
						for (String testTickets : testTicketsWinHnd) {
							if (!testTickets.equals(CurrentWinHnd)) {
								WebDriverMain._getDriver().switchTo().window(testTickets);
								CommonUtility._sleepForGivenTime(2000);
								Downloadedfilename= "New Browser Tab Opened and reporting frame is displayed  ";
								WebDriverMain._getDriver().switchTo().window(CurrentWinHnd);
							}
						}
						flag = CommonFunctions.CloseAllWindowExceptCurrent(CurrentWinHnd);
					}
					UMReporter.log(Status.PASS, "Select the action Item in Reports List:" + reportname+Downloadedfilename);
				}
				else
					UMReporter.log(Status.FAIL, "The Report item not found :" + reportname);
			} else
				UMReporter.log(Status.SKIP, "Reports options not exist ");
		} else
			UMReporter.log(Status.SKIP, "The students are not selected/found in list");

	}
	
	@When("Verify the selected Organization reports is opened in New Browser Tab")
	public void verify_Reports_Reporting_page() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify the selected Organization reports is opened in New Browser Tab");
		Set<String> testTicketsWinHnd = WebDriverMain._getDriver().getWindowHandles();
		for (String testTickets : testTicketsWinHnd) {
			if (!testTickets.equals(CurrentWinHnd)) {
				WebDriverMain._getDriver().switchTo().window(testTickets);
				CommonUtility._sleepForGivenTime(2000);
				UMReporter.log(Status.PASS, "Reporting frame is displayed in Reports Page  ");
				WebDriverMain._getDriver().switchTo().window(CurrentWinHnd);
			}
		}
	}
	
	
}
	
	
	
	
	
	
	
	
	
