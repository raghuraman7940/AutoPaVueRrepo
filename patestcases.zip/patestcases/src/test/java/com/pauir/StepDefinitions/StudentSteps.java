/**
 * Students Step Definition 
 */
package com.pauir.StepDefinitions;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.Common.ImportExport;
import com.pauir.PageDefinitions.classes.ClassDetailPage;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.testDataTypes.Studentfield;
import com.pauir.PageDefinitions.sessions.SessionDetailPage;
import com.pauir.PageDefinitions.students.CreateStudentPage;
import com.pauir.PageDefinitions.students.StudentDetailPage;
import com.pauir.PageDefinitions.students.StudentListPage;

import webdriver.main.CommonUtility;
import webdriver.main.LeftClick;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

import com.pauir.common.util.CSV_Reader;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;



public class StudentSteps {
	
	//Initialize the class variable
	public static StudentListPage studentlist;
	public static StudentDetailPage studentdetail;
	public static CreateStudentPage studentcreate;
	public static SessionDetailPage sessiondetail;
	public static ClassDetailPage Classdetail;
	public static ImportExport importexport;
	public static Login login;
	public static Home home;
	public static CommonFunctions common;
	public static CSV_Reader csvfreader;
	public static RequestMethod requests;
	public static HashMap<String, String> MapStuFields = null;
	public static HashMap<String, String> MapStuFilledFields = null;
	public static HashMap<String,String> MapStuAccomFields=  null;
	public static HashMap<String,String> MapStuDemoFields=  null;
	public static HashMap<String, String> MapStuEditedFields = null;
	public static HashMap<String, String> MapSessFields= null;
	public static HashMap<String, String> MapClassFields= null;
	public static List<String> lstSelectedStudent=null;
	public static List<String> lstSelectedSession=null;
	List <Map<String,Object>> lstApiCustDemoFields=null;
	public static String csvfilepath;
	public static String SelectedReportingSchool=null;
	
	public StudentSteps()throws IOException{
		//Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home= new Home();
		studentlist=new StudentListPage();
		studentdetail=new StudentDetailPage();
		studentcreate = new CreateStudentPage();
		sessiondetail= new SessionDetailPage();
		Classdetail= new ClassDetailPage();
		csvfreader= new CSV_Reader();
		importexport= new ImportExport();
		requests=new RequestMethod();
	}
	
	@Given("^Navigate to Student List page$")
	public void navigate_to_Student_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Student List page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		boolean flag=home.VerifyLoggedinHomePage();;
		if (flag) {
			// Select Menu option Primary and secondary option
			home.MenuOtion("students", "");
			//Verify the User list page displayed
			if(studentlist.verifyStudentListNavigation())
				UMReporter.log(Status.PASS,"User is navigated successfully to Student List page");
		    else
		    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
		}
		else if (studentlist.verifyStudentListNavigation()) {
			CommonUtility._sleepForGivenTime(1000);
			UMReporter.log(Status.PASS,"Navigated to Student list page");
		}
	}
	
	@Then("^Verify whether Student list page is displayed$")
	public void verify_whether_Student_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify whether Student list page is displayed ");
		//Verify the Org list page displayed
		if(studentlist.verifyStudentListNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Student List page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Given("^Verify the Student Table fields$")
	public void verify_Students_Table_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the Students Table fields");
		String Fieldname;
		List<String> NonVerified=null;
		boolean flag = true;
		List<String> MapDgStuColHeader=studentlist.getStuColumnHeaderDetails();
		if (MapDgStuColHeader.size()>0) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgStuColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Students Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Students Table fields are verified :"+MapDgStuColHeader);
			
	}
	
	@Given("^Verify the Student Table fields are sortable in Student List page$")
	public void verify_Student_Table_fields_Sortable(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO,"When :Verify the Student Table fields are sortable in Student List page");
		String Fieldname;
		List<String> NotVerified=null;
		List<String> MapDgColValues=null;
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NotVerified=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^")>=0)
				Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
			MapDgColValues=studentlist.verifyStudentSearchresultsSorting(Fieldname);
			if (MapDgColValues!=null) 
				if (MapDgColValues.size()<1)
					NotVerified.add(Fieldname);
			
		}
		if (NotVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Student Table fields are not Sortable :"+NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Student Table fields are Sortable :"+list);
	}
	
	@Then("^User able to access the list of Student from the navigation$")
	public void verify_Students_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of students from the navigation");
		List<String> MapDgStuColHeader=studentlist.verifyStusearchresultsDetails(3);
	    if (MapDgStuColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following students lists are accessed :"+MapDgStuColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The students are not found in list");
	}
	
	@Then("^Verify each Student record contains a checkbox$")
	public void verify_student_list_checkboxis_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : verify each student record contains a checkbox");
		List<String> MapDgOrgColHeader=studentlist.verifyStusearchresultsCheckbox(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The student lists contains checkbox :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The student are not found in list");
	}
	
	@When("^Select the Student record checkbox$")
	public void Select_student_list_checkbox() throws Exception {
		UMReporter.log(Status.INFO, "When : Select the student record checkbox");
		 boolean flag=studentlist.SelectonStuCheckbox();
	    if (flag)
	    	UMReporter.log(Status.PASS, "Selected the student checkbox ");
	    else
	    	UMReporter.log(Status.FAIL, "The students are not found in list");
	}	
	
	@Then("^Verify the pagination in Student datagrid$")
	public void Verify_student_list_Paginations() throws Exception {
		UMReporter.log(Status.INFO, "When : Verify the pagination in Student datagrid");
		int maxpage=studentlist.verifyStuGridPagination();
		if (maxpage>1) 
	    	UMReporter.log(Status.PASS, "The students lists pagination are upto max pages :"+maxpage);
	    else if(maxpage==1)
	    	UMReporter.log(Status.PASS, "The students list contains one page only.");
	    else
	    	UMReporter.log(Status.FAIL, "The students list pagination fails.");
	}
	
	@When("^User select the student from student list$")
	public void user_clicks_on_First_IN_StudentList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User selects the record in student list");
		boolean flag=false;
		HashMap<String,String> MapOrgField=null;
		// Get Student Search results by row number
		MapStuFields=studentlist.getStudsearchresultsDetails(1);
		if(MapStuFields!=null) {
			if (MapStuFields.containsKey("Student Name")) {
				String StudName=MapStuFields.get("Student Name");
				String NameSplit[]=StudName.split(", ");
       		  	if (NameSplit.length>=1){
       			  String Lname=NameSplit[0];
       			  MapStuFields.put("Last Name", Lname);
       			  String FMname=NameSplit[1];
       			  String FMNameSplit[]=FMname.split(" ");
       			  if (FMNameSplit.length>1){
       				String Fname=FMNameSplit[0];
       				MapStuFields.put("First Name", Fname);
       			 	String Mname=FMNameSplit[1];
       			 	MapStuFields.put("Middle Name", Mname);
       			  }
       			  else
       				MapStuFields.put("First Name", FMname);
       		  	}
       			  
				//Click on Student Name hyperlink on Org list page
				flag=studentlist.clickonStudName(MapStuFields.get("Student Name"));
				//Check the Student selected
				if(flag) {
					CommonUtility._sleepForGivenTime(2000);
					UMReporter.log(Status.PASS,"Selected the Student name "+MapStuFields.get("Student Name")+" hyperlink in Student list");
				}
				else
					UMReporter.log(Status.FAIL,"The Student name "+MapStuFields.get("Student Name")+"  not found in Student list");	
			}
		}
		else
			UMReporter.log(Status.FAIL,"No records found in Student list");	
		
	}
	
	@Then("^Verify Student details page is displayed$")
	public void verify_whether_Student_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Student details page is displayed ");
		//Verify the Student Detail page displayed
		if(studentdetail.verifyStudentDetailsNavigation()&&studentdetail.verifyStudentDetails())
			UMReporter.log(Status.PASS,"User is navigated to Student details page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Then("^Verify the Student name is displayed in Student details page$")
	public void verify_Student_name_in_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the Student name is displayed in Student details page ");
		if (MapStuFields!=null) {
			if (MapStuFields.containsKey("Student Name")) {
				String StudName=MapStuFields.get("Student Name");
//			if ((MapStuFields.containsKey("Last Name"))&&(MapStuFields.containsKey("First Name"))&&(MapStuFields.containsKey("Middle Name"))) {
//				String StudName=MapStuFields.get("First Name")+" "+MapStuFields.get("Middle Name")+" "+MapStuFields.get("Last Name");
				if(studentdetail.verifyStudentName(StudName))
					UMReporter.log(Status.PASS,"Verified the Student name in Student details page :"+StudName);
				else
					UMReporter.log(Status.FAIL,"The Student name not found in Student details page :"+StudName);
			}
		}
	    else
	    	UMReporter.log(Status.FAIL,"Student name not exist");
	}
	
	@Then("^Verify the Last updated date value is displayed in Student details page$")
	public void verify_LastUpdate_in_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the Last updated date value is displayed in Student details page ");
		String LastUpdate=studentdetail.verifyLastUpdatedLabel();
		if(LastUpdate!=null)
			UMReporter.log(Status.PASS,"Verified the Last updated date in Student details page :"+LastUpdate);
		else
			UMReporter.log(Status.FAIL,"The Last updated date not found in Student details page :"+LastUpdate);

	}
	
	@Then("^Verify the filled Student information in Student details page$")
	public void verify_filled_Student_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the filled Student information in Student details page");
		if (MapStuFilledFields!=null) {
			//Verify the Student Detail page displayed
			if(studentdetail.verifyStudentDetailsNavigation()&&studentdetail.verifyStudentDetails()) {
				if (!studentdetail.Verify_Student_Info_Blade()) 
					studentdetail.StudentInfoExpand("Yes");
			//Verify the Student details page displayed
				studentdetail.verifyViewStudentDetails(MapStuFilledFields);
			}
			else
				UMReporter.log(Status.FAIL,"Student Details is not displayed");
		}
	    else
	    	UMReporter.log(Status.FAIL,"Student Details are not found");
	}
	
	@Then("^Verify the filled Student accommodations in Student details page$")
	public void verify_filled_Student_accommodations_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the filled Student accommodations in Student details page");
		if (MapStuAccomFields!=null) {
			
			//Verify the Student Detail page displayed
			if(studentdetail.verifyStudentDetailsNavigation()) {
				if (!studentdetail.Verify_Student_Accommodations_Blade()) 
					studentdetail.StudentAccommodationBladeExpand("Yes");
				//Verify the Organization details page displayed
				studentdetail.verifyViewStudentAccomodations(MapStuAccomFields);
			}
			else
				UMReporter.log(Status.FAIL,"Student Accommodations Details is not displayed");
		}
	    else
	    	UMReporter.log(Status.SKIP,"Student Accommodations Details are not found");
			
	}
	
	@Then("^Verify the edited Student information in Student details page$")
	public void verify_edited_Student_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the edited Student information in Student details page");
		if (MapStuEditedFields!=null) {
			//Verify the Student Detail page displayed
			if(studentdetail.verifyStudentDetailsNavigation())
			//Verify the Student details page displayed
				studentdetail.verifyViewStudentDetails(MapStuEditedFields);
			else
				UMReporter.log(Status.FAIL,"Student Details is not displayed");
		}
	    else
	    	UMReporter.log(Status.FAIL,"Student Details are not found");
		
	}
	
	@Given("^Verify the Student Info fields in Student details page$")
	public void verify_Students_info_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the Student Info fields in Student details page");
		String Fieldname,FieldValue;
		List<String> NonVerified=null;
		List<String> VerifiedField=null;
		if(studentdetail.Verify_Student_Info()){
			
			if (!studentdetail.Verify_Student_Info_Blade())
				studentdetail.StudentInfoExpand("Yes");
			
			
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				//System.out.println("Fieldname:" + Fieldname);
				if (!studentdetail.verifyStudentLabel(Fieldname))
					NonVerified.add(Fieldname);
				else {
					FieldValue=studentdetail.GetValueforStudentLabel(Fieldname);
					VerifiedField.add(Fieldname+" = "+FieldValue);
				}
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected Students Info fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following verified Students Info fields with values :"+VerifiedField);
		}
		else
			UMReporter.log(Status.FAIL, "The Students Info fields are not found ");
	}
	
	@Given("^Verify the Student Enrollment fields in Student details page$")
	public void verify_Students_enrollment_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the Student Enrollment fields in Student details page");
		String Fieldname,FieldValue;
		List<String> NonVerified=null;
		List<String> VerifiedField=null;
		if(studentdetail.Verify_Student_Enrollment()){
			

			if (!studentdetail.Verify_Student_Info_Blade())
				studentdetail.StudentInfoExpand("Yes");
			
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				//System.out.println("Fieldname:" + Fieldname);
				if (!studentdetail.verifyStudentLabel(Fieldname))
					NonVerified.add(Fieldname);
				else{
					FieldValue=studentdetail.GetValueforStudentOrganiztionLabel(Fieldname);
					VerifiedField.add(Fieldname+" = "+FieldValue);
				}
					
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected Students Enrollment fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following verified Students Enrollment fields with values:"+VerifiedField);
		}
		else
			UMReporter.log(Status.FAIL, "The Students Enrollment fields are not found ");
	}
	
	
	
	@Then("^Verify the selected Student field values in Student details page$")
	public void verify_Selected_Student_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the selected Student field values in Student details page ");
		if (MapStuFields!=null) {
			//Verify the Student details page displayed
			studentdetail.verifyViewStudentDetails(MapStuFields);
		}
	    else
	    	UMReporter.log(Status.FAIL,"Student Details are not found");
	}
	
	@Then("^Select Student List breadcrumb$")
	public void Select_Home_breadcrumb_organization_list() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Student List > breadcrumb");
		boolean flag=studentdetail.clickStudentListBreadcrumb();
	    if (flag) {
	    	 UMReporter.log(Status.PASS, "Selected the Student List breadcrumb");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to select Student List breadcrumb");
	}
	
	@When("^User fill the student search text (.*)$")
	public void Fill_Searchtext_student_list(String SeachText) throws Exception {
		//Get from Testdata
		if (SeachText.indexOf("$")>=0)
			SeachText=CommonFunctions.getTestData(SeachText);
		UMReporter.log(Status.INFO, "Then : User fill the student search text : "+SeachText);
		 boolean flag=studentlist.Searchfill_StudName(SeachText);
		 if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	
	@When("^User search the student by search text (.*)$")
	public void Fill_CreatedSearchtext_student_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User search the student by search text : "+SeachText);
		boolean flag=false;
		if (MapStuFilledFields!=null) { 
			if (MapStuFilledFields.containsKey("Last Name")) 
				SeachText=MapStuFilledFields.get("Last Name");
		}
		else
		{
			if (SeachText.indexOf("$")>=0)
				SeachText=CommonFunctions.getTestData(SeachText);
		}
		flag=studentlist.Searchfill_StudName(SeachText);
		if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	
	@When("^User find the student by search text (.*)$")
	public void User_Search_Searchtext_student_list(String SeachText) throws Exception {
//		UMReporter.log(Status.INFO, "Then : User find the student by search text : "+SeachText);
		boolean flag=false;
		if (MapStuFilledFields!=null) { 
			String SeachText1=null;
			if (MapStuFilledFields.containsKey("Last Name")) { 
				 SeachText1= MapStuFilledFields.get("Last Name");
				flag=studentlist.Searchfill_StudName(SeachText1);
				flag=studentlist.clicksearchicon();
				flag=studentlist.hasStudentRecords();
				if (flag) {
					UMReporter.log(Status.INFO, "Then : User find the student by search text : "+SeachText);
					 UMReporter.log(Status.PASS, "The Search text :"+SeachText1);
				}
			}
		}
		if (!flag)
		{
			if (SeachText.indexOf("$")>=0)
				SeachText=CommonFunctions.getTestData(SeachText);
			UMReporter.log(Status.INFO, "Then : User find the student by search text : "+SeachText);
			flag=studentlist.Searchfill_StudName(SeachText);
			flag=studentlist.clicksearchicon();
			flag=studentlist.hasStudentRecords();
			if (flag)
				 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
			 else
				    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
		}
	}
	
	@When("^User select the search icon in student list page$")
	public void Click_Searchicon_student_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon in student list page");
		boolean flag=studentlist.clicksearchicon();
	    if (flag)
	    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
		 else
		    UMReporter.log(Status.FAIL, "Unable to select search icon");
	}
	
	@Then("^verify the (.*) search results in the student list$")
	public void Verify_Searchtext_in_student_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the Student list : "+SeachText);
		if (MapStuFilledFields!=null) 
			if (MapStuFilledFields.containsKey("Last Name")) 
				SeachText=MapStuFilledFields.get("Last Name");
		
		 List<String> MapDgOrgDet=studentlist.verifyStudSearchresultsDetailsfromtext(3,SeachText);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "The Student lists matches the SeachText :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The Students are not found in list");
	
	}
	
	@Then("^Clear Search text field in student list page$")
	public void Clear_Searchtextfield_student_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the Search text field");
		boolean flag=studentlist.ClearSearchText();
		
	    if (flag) {
	    	flag=studentlist.clicksearchicon();
	    	 UMReporter.log(Status.PASS, "Cleared the Search Text");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}
	
	// create student steps
	
	@When("^User check the fields control error on Create Student page$")
	public void user_check_studentfields_on_studentedit_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User check the fields control error on student edit page");
		// Get fields from Configuration json file
		List<Studentfield> fields = FileReaderManager.getInstance().getJsonReader().getStudentfields(Constants.ORG_STATE);
		// Checks the fields validation from Configuration field and user test data
		studentcreate.PageDataFieldValidation(fields, "required");
		UMReporter.log(Status.PASS, "Verified the Student Input fields with Maximum, Minimum Length, Invalid data ");

	}	
	
	
	@Then("^User fill the student informations in create student page$")
	public void user_fills_provided_fields_present_createstudent(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User fill the Provided student informations in student create page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		boolean isfieldLabelExist=false;
		
		// Get fields from Configuration json file
		List<Studentfield> fields = FileReaderManager.getInstance().getJsonReader().getStudentfields(Constants.ORG_STATE);
		if (fields!=null) {
			if((studentcreate.VerifyAddstudentForm())||(studentcreate.VerifyEditstudentForm())) {
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapStuFilledFields=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					String TempFieldname=Fieldname;
					if (TempFieldname.indexOf("^")>=0)
						TempFieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
					
					System.out.println("FieldValue:" + TempFieldname+" => "+FieldValue);
					isfieldLabelExist=studentcreate.VerifyFieldLabelExist(TempFieldname);
					if (isfieldLabelExist) {
						Studentfield field=FileReaderManager.getInstance().getJsonReader().getStudentfieldbyLabel(fields, Fieldname);
						if (field!=null) {
							FilledFieldValue = studentcreate.FillStuContactField(field, FieldValue);
							if (FilledFieldValue==null)
								NonVerified.add(TempFieldname);
							else 
								MapStuFilledFields.put(TempFieldname,FilledFieldValue);
						}
						else {
							System.out.println("Field Not Exist in Testdataresources file:" +FieldValue);
						}
					}
				}
				if (MapStuFilledFields!=null) {
					if ((MapStuFilledFields.containsKey("Last Name"))&&(MapStuFilledFields.containsKey("First Name"))&&(MapStuFilledFields.containsKey("Middle Name"))) {
						 String StuName=MapStuFilledFields.get("Last Name")+", "+MapStuFilledFields.get("First Name")+" "+MapStuFilledFields.get("Middle Name");
							MapStuFilledFields.put("Student Name",StuName);
					}
					else if ((MapStuFilledFields.containsKey("Last Name"))&&(MapStuFilledFields.containsKey("First Name"))) {
						 String StuName=MapStuFilledFields.get("Last Name")+", "+MapStuFilledFields.get("First Name");
							MapStuFilledFields.put("Student Name",StuName);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following student fields are unable to provide the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following student fields provided the input values :"+ MapStuFilledFields);
				
			}
			else
				UMReporter.log(Status.FAIL, "The Student input form not displayed");
		}
	}
	
	
	@Then("^Verify Create Student button is visible and enabled in student list page$")
	public void verify_create_button_is_visible_and_enable_in_studentlist_page() throws Exception{
		
		UMReporter.log(Status.INFO, "Then: Verify create button is visible and enable in Student list page");    
		boolean createvisible = studentcreate.StudentCreateButton_isVisible();
		if(createvisible) {
			boolean createenabled = studentcreate.StudentCreateButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Create button is visable and enabled");
			else
				UMReporter.log(Status.FAIL, "Create button is not enabled");
		}
		else
			UMReporter.log(Status.FAIL, "Create contact button is not visible");
	
	}
	
	@Then("^Click on Create Student button$")
	public void click_CreateStudent_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Create Student button");
		studentcreate.ClickCreateStudentButton();
		CommonFunctions.waitUntilCreatingLoadingSpinner(10);
		UMReporter.log(Status.PASS, "Selected the Create Student button");
	}

	@Then("^Verify Create Student page is displayed$")
	public void verify_whether_Student_create_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Student Create page is displayed ");
		
		if(studentcreate.verifyStudentCreateNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Student Create page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	
	@Then("^Verify save button is enabled in create student page$")
	public void verify_save_button_is_visible_and_enable_in_create_page() throws Exception{
		
		UMReporter.log(Status.INFO, "Then: Verify save button is visible and enable in Student create page");    
		boolean createvisible = studentcreate.StudentSaveButton_isVisible();
		if(createvisible) {
			boolean createenabled = studentcreate.StudentSaveButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Save button is visable and enabled");
			else
				UMReporter.log(Status.PASS, "Save button is not enabled");
		}
		else
			UMReporter.log(Status.FAIL, "Save button is not visible");
	
	}
		
	@Then("^Verify save button is disabled in create student page$")
	public void verify_save_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Save button is enabled in Create student page");
		boolean createenabled = studentcreate.StudentSaveButton_isEnabled();
		if(!createenabled)
			UMReporter.log(Status.FAIL, "Save student button is enabled");
		else
			UMReporter.log(Status.PASS, "Save student button is not enabled");
			
	    
	}
	
	
	
	
	@Then("^Verify cancel button is enabled in create student page$")
	public void verify_cancel_button_is_visible_and_enable_in_create_page() throws Exception{
		
		UMReporter.log(Status.INFO, "Then: Verify cancel button is visible and enable in Student create page");    
		boolean createvisible = studentcreate.StudentCancelButton_isVisible();
		if(createvisible) {
			boolean createenabled = studentcreate.StudentCacncelButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Cancel button is visable and enabled");
			else
				UMReporter.log(Status.FAIL, "Cancel button is not enabled");
		}
		else
			UMReporter.log(Status.FAIL, "Cancel button is not visible");
	
	}
	
	@Then("^Click on Save Student button$")
	public void click_SaveStudent_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Save Student button");
		studentcreate.ClickSaveStudentButton();
		
		UMReporter.log(Status.PASS, "Selected the Save Student button");
	}
	
	
	@Then("^Click on Cancel button in Student Page$")
	public void click_CancelStudent_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Cancel button in Student Page");
		studentcreate.ClickCancelStudentButton();
		UMReporter.log(Status.PASS, "Selected the Cancel button");
	}
	
	@Then("^Verify Edit button is visible in student details page$")
	public void verify_edit_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Edit button is visible in student details page");
		boolean createenabled = studentcreate.EditButton_isVisible();
		if(createenabled)
			UMReporter.log(Status.PASS, "Edit student option is visible");
		else
			UMReporter.log(Status.FAIL, "Edit student option is not visible");
	}
	
	@Then("^Click on Edit Student button$")
	public void click_EditStudent_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Edit Student button");
		studentcreate.ClickEditStudentButton();
		UMReporter.log(Status.PASS, "Selected the Edit Student button");
	}
	
	@Given("^Navigate to Students page$")
	public void navigate_to_Students_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Students page");
		// Select Menu option Primary and secondary option
		home.MenuOtion("students", "");
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonFunctions.waitUntilLoadingSpinner(10);
		//CommonUtility._sleepForGivenTime(1000);
		
		//Verify the User list page displayed
		if(studentlist.verifyStudentListNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Student page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Then("^Verify the list of Students displayed in Students page$")
	public void verify_Students_list_is_access_StudentPage() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the list of Students displayed in Students page");
		List<String> MapDgStuColHeader=studentlist.verifyStusearchresultsDetails(3);
	    if (MapDgStuColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following students lists are accessed :"+MapDgStuColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The students are not found in list");
	}
	
	@Then("^User edit the student informations in student details page$")
	public void user_fills_edit_fields_present_studentDetails(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User edit the student informations to unenroll organization in student details page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		// Get fields from Configuration json file
		List<Studentfield> fields = FileReaderManager.getInstance().getJsonReader().getStudentfields(Constants.ORG_STATE);
		if (fields!=null) {
			if(studentcreate.VerifyEditstudentForm()) {
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapStuEditedFields=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					
					if (FieldValue.indexOf("$")>=0)
						FieldValue=CommonFunctions.getTestData(FieldValue);
					System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
					
					if(Fieldname.equalsIgnoreCase("Organization"))
						studentdetail.verifyEditFormFirstField();
					
					Studentfield field=FileReaderManager.getInstance().getJsonReader().getStudentfieldbyLabel(fields, Fieldname);
					if (field!=null) {
						FilledFieldValue = studentcreate.FillStuContactField(field, FieldValue);		                  
						
						if (FilledFieldValue==null)
							NonVerified.add(Fieldname);
						else 
							MapStuEditedFields.put(Fieldname,FilledFieldValue);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following student fields are edit to provide the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following student fields provided the edit values :"+ MapStuFilledFields);
				
			}
		}
	}
	
	@Then("^User unenroll the provided organization (.*) in student details page$")
	public void user_fills_edit_fields_UnenrollstudentDetails(String OrgtoRemove) throws Exception {
		UMReporter.log(Status.INFO,"When : User unenroll the provided organization in student details page ");
		boolean flag=false;
		if(studentcreate.VerifyEditstudentForm()) {
			
			if (OrgtoRemove.indexOf("$")>=0)
				OrgtoRemove=CommonFunctions.getTestData(OrgtoRemove);
			
			studentdetail.verifyEditFormFirstField();
			
			flag = studentcreate.RemoveStudenEnrollment(OrgtoRemove,"Yes");
			if (flag)
				UMReporter.log(Status.PASS, "The following student enrollments are removed :"+ OrgtoRemove);				
			else
				UMReporter.log(Status.FAIL, "The following student enrollment orgnization are unable to remove :"+OrgtoRemove);
		}		
	}
	
	@Then("^User unenroll till last organization in student details page$")
	public void user_unenroll_fields_UnenrollstudentDetails() throws Exception {
		UMReporter.log(Status.INFO,"When : User unenroll till last organization in student details page ");
		boolean flag=false;
		if(studentcreate.VerifyEditstudentForm()) {
			flag = studentcreate.RemoveAllStudentEnrollment();
			if (flag)
				UMReporter.log(Status.PASS, "The Student enrollments are removed :");				
			else
				UMReporter.log(Status.FAIL, "The Student enrollment orgnization are unable to remove ");
		}		
	}

	@When("^Verify title and content (.*) in Confirmation Unenroll pop-up$")
	public void Verify_title_message_ConfirmPopUp_button(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Confirm Unenroll pop-up");
		boolean flag=false;
		// Verify the Confirm pop up
		flag=CommonFunctions.VerifyConfirmPopupContent(Constants.UnenrollConfirmPopupTitle,confmessage);
		if (flag)
			UMReporter.log(Status.PASS, "Verified Confirm Unenroll pop-up title and message : " +confmessage);
			
	}
	
	@When("^Click on confirm button on Confirmation Unenroll pop-up$")
	public void Click_confirm_on_ConfirmUnenrollpopupUnenroll_button() throws IOException {
		UMReporter.log(Status.INFO, "When :  Click on confirm button on Confirmation Unenroll pop-up");
			// Verify the Click Confirm in pop up
		boolean flag=CommonFunctions.ConfirmPopupActionBtn("Yes");
		CommonUtility._sleepForGivenTime(3000);
			if (flag) 
				UMReporter.log(Status.PASS, "Select the Confirm button and navigated to Student list page " );
			else
				UMReporter.log(Status.FAIL, "Select the Confirm button and Student list not displayed " );
	}

	@When("^Click on cancel button on Confirmation Unenroll pop-up$")
	public void Click_cancel_on_ConfirmUnassignpopupUnAssign_button() throws IOException {
		UMReporter.log(Status.INFO, "When :  Click on cancel button on Confirmation Unenroll pop-up");
		
			// Verify the Click cancel in pop up
			boolean flag=CommonFunctions.ConfirmPopupActionBtn("No");
			CommonUtility._sleepForGivenTime(3000);
			if (flag) 
				UMReporter.log(Status.PASS, "Select the Cancel button and pop up is closed " );
			else
				UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed " );
	}
	
	@Then("^Verify the error message displayed in Student detail as (.*)$")
	public void verify_error_message_gets_displayed_On_Student_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the error message displayed in Student detail as " + messages);
		boolean flag;
		flag = studentdetail.verifyErrorMessage("Organization");
		flag = studentdetail.verifyFailureMessage(messages);
		if (flag) 
			UMReporter.log(Status.PASS, "Verified the error message displayed in Student detail:" + messages);
		else
			UMReporter.log(Status.FAIL, "The error message is not matched with expected :" + messages);
	}
	
	@Then("^Verify Session list is displayed in Student details page$")
	public void verify_whether_Session_list_page_is_displayed_StudentDetails() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Session list is displayed in Student details page");
		//Verify the Stu list page displayed
		if(studentdetail.Verify_Student_SessionList())
			UMReporter.log(Status.PASS,"Session List is displayed in Student details page");
	    else
	    	UMReporter.log(Status.FAIL,"Session List is not displayed");
	}
	
	@Given("^Verify the (?:Session|Class) Table fields in Student Detail Page$")
	public void verify_Session_Table_fields_In_Student_details(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When :Verify the Table fields in Student Detail Page");
		String Fieldname;
		List<String> NonVerified=null;
		List<String> MapDgOrgColHeader=studentdetail.getSessionColumnHeaderDetails();
		if (MapDgOrgColHeader!=null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Table fields are verified :"+MapDgOrgColHeader);
	}
	
	@Given("^Verify the (?:Session|Class) Table fields fields are sortable in Student Detail Page$")
	public void verify_Session_Table_fields_Sortable(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When :Verify the Table fields fields are sortable in Student Detai Page");
		String Fieldname;
		List<String> NotVerified=null;
		List<String> MapDgColValues=null;
		if (studentdetail.Verify_StudentHasSessions()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NotVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				
				MapDgColValues=studentdetail.verifySessionSearchresultsSorting(Fieldname);
				if (MapDgColValues==null) 
					NotVerified.add(Fieldname);
			}
			if (NotVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected Table fields are not Sortable :"+NotVerified);
			else
				UMReporter.log(Status.PASS, "The following Table fields are Sortable :"+list);
		}
		else
			UMReporter.log(Status.SKIP, "No records in Students Session/Class list");
	}
	
	
	@Then("^User able to access the (?:Session|Class) list assignments in Student Detail Page$")
	public void verify_Session_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of assignments in Student Detai Page");
		if (studentdetail.Verify_StudentHasSessions()) {
			List<String> MapDgOrgColHeader=studentdetail.verifySessionSearchresultsDetails(3);
		    if (MapDgOrgColHeader!=null)
		    	UMReporter.log(Status.PASS, "The following assignment lists are accessed :"+MapDgOrgColHeader);
		    else
		    	UMReporter.log(Status.FAIL, "The assignment are not found in list");
		}
		else
			UMReporter.log(Status.SKIP, "No records in Students Session/Class list");
	}

	
	@When("^User search the Student (?:Session|Class) by search text (.*)$")
	public void Fill_Searchtext_session_list(String SeachText) throws Exception {
		
		if (SeachText.indexOf("$")>=0)
			SeachText=CommonFunctions.getTestData(SeachText);
		
		UMReporter.log(Status.INFO, "Then : User search the Student assignment by search text : "+SeachText);
		 boolean flag=studentdetail.Searchfill_SessionName(SeachText);
		 if (flag)
			 UMReporter.log(Status.PASS, "Provided the Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to provide search text in input field");
	}
	
	
	
	@When("^User select the search icon in Student Detail page$")
	public void Click_Searchicon_Session_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon in Student Detail page");
		boolean flag=studentdetail.clicksearchicon();
	    if (flag)
	    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
		 else
		    UMReporter.log(Status.FAIL, "Unable to select search icon");
	}
	
	@Then("^verify the (.*) search results in the (?:Session|Class) list in Student Detail Page$")
	public void Verify_Searchtext_in_Session_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the  list : "+SeachText);
		 List<String> MapDgOrgDet=studentdetail.verifySessionSearchresultsDetailsfromtext(SeachText);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "The assignment lists matches the SeachText :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The assignment are not found in list");
	
	}
	@Then("^Clear Search text field in Student Detail Page$")
	public void Clear_Searchtextfield_Class_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the Search text field in Student Detail Page");
		boolean flag=studentdetail.ClearSearchText();
		
	    if (flag) {
	    	flag=studentdetail.clicksearchicon();
	    	 UMReporter.log(Status.PASS, "Cleared the Search Text");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}
	
	
	
	@When("^User select the session from session list in Student Detail Page$")
	public void user_clicks_on_First_IN_SessionList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select the session from session list in Student Detail Page");
		boolean flag=false;
		HashMap<String,String> MapOrgField=null;
		// Get Seesion Search results by row number
		MapSessFields=studentdetail.getSessionSearchresultsDetails(1);
		if(MapSessFields!=null) {
			if (MapSessFields.containsKey("Session Name")) {
				String SessionName=MapSessFields.get("Session Name");
				//Click on Session Name hyperlink on Org list page
				flag=studentdetail.clickonSessionName(SessionName);
				//Check the Session selected
				if(flag) {
					CommonUtility._sleepForGivenTime(2000);
					UMReporter.log(Status.PASS,"Selected the Session name "+SessionName+" hyperlink in Session list in Student Detail");
				}
				else
					UMReporter.log(Status.FAIL,"The Session name "+SessionName+"  not found in Session list in Student Detail");	
			}
		}
		else
			UMReporter.log(Status.FAIL,"No records found in Session list");	
		
	}
	
	@Then("^Verify the selected session data from Student Details in Session details page$")
	public void verify_Selected_Session_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the selected Session field values in Session details page");
		if (MapSessFields!=null) {
			//Verify the Session details page displayed
			sessiondetail.verifyViewSessionDetails(MapSessFields);
		}
	    else
	    	UMReporter.log(Status.FAIL,"Session Details are not found");
	}
	
	@Then("^User switch to Sessions List Tab in Student details Page$")
	public void Select_Session_list_Tab() throws Exception {
		UMReporter.log(Status.INFO, "Then : User switch to Sessions List Tab in Student details Page");
		boolean flag=false;
		if(!studentdetail.VerifyActiveTab("Session List")) {
			flag=studentdetail.SelectTabOption("Session List");
		    if (flag) {
		    	 UMReporter.log(Status.PASS, "Selected the Sessions List Tab");
		    }
			 else
			    UMReporter.log(Status.FAIL, "Unable to select Sessions List Tab");
		}
		else
		    UMReporter.log(Status.PASS, "Sessions List Tab selected");
	}
	
	@Then("^User switch to Class List Tab in Student details Page$")
	public void Select_Class_list_Tab() throws Exception {
		UMReporter.log(Status.INFO, "Then : User switch to Class List Tab in Student details Page");
		boolean flag=false;
		flag=studentdetail.SelectTabOption("Class List");
	    if (flag) {
	    	 UMReporter.log(Status.PASS, "Selected the Class List Tab");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to select Class List Tab");
	}
	
	@Then("^Verify Class list is displayed in Student details page$")
	public void verify_whether_Class_list_page_is_displayed_StudentDetails() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Class list is displayed in Student details page");
		//Verify the Stu list page displayed
		if(studentdetail.Verify_Student_ClassList())
			UMReporter.log(Status.PASS,"Class List is displayed in Student details page");
	    else
	    	UMReporter.log(Status.FAIL,"Class List is not displayed");
	}
	
	@When("^User select the class from class list in Student Detail Page$")
	public void user_clicks_on_First_IN_ClassList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select the class from class list in Student Detail Page");
		boolean flag=false;
		HashMap<String,String> MapOrgField=null;
		// Get Class Search results by row number
		MapClassFields=studentdetail.getSessionSearchresultsDetails(1);
		if(MapClassFields!=null) {
			if (MapClassFields.containsKey("Class Name")) {
				String ClsName=MapClassFields.get("Class Name");
				//Click on Session Name hyperlink on Org list page
				flag=studentdetail.clickonSessionName(ClsName);
				//Check the Session selected
				if(flag) {
					CommonUtility._sleepForGivenTime(2000);
					UMReporter.log(Status.PASS,"Selected the Class name "+ClsName+" hyperlink in Class list in Student Detail");
				}
				else
					UMReporter.log(Status.FAIL,"The Class name "+ClsName+"  not found in Class list in Student Detail");	
			}
		}
		else
			UMReporter.log(Status.SKIP,"No records found in Class list");	
		
	}
	
	@Then("^Verify the selected class data from Student Details in Class details page$")
	public void verify_Selected_Class_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the selected class data from Student Details in Class details page");
		if (MapClassFields!=null) {
			if(Classdetail.verifyClassDetailsNavigation())
				//Verify the Session details page displayed
				Classdetail.verifyViewClassDetails(MapClassFields);
		}
	    else
	    	UMReporter.log(Status.SKIP,"Class Details are not found");
	}
	
	@When("^User select View ISR link from session list in Student Detail Page$")
	public void user_clicks_on_First_ISR_Report_IN_SessionList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select View ISR link from session list in Student Detail Page");
		boolean flag=false;
		HashMap<String,String> MapOrgField=null;
		// Get Seesion Search results by row number
		MapSessFields=studentdetail.SelectViewISRReport();
		if(MapSessFields!=null) {
			UMReporter.log(Status.PASS,"Selected View ISR Report from Session list in Student Detail"+MapSessFields);
		}
		else
			UMReporter.log(Status.FAIL,"No records found in Session list");	
		
	}
	
	@Then("^Verify Report page is displayed in Student details page$")
	public void verify_Report_page_is_displayed_StudentDetails() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Report page is displayed in Student details page");
		//Verify the Stu list page displayed
		if(studentdetail.verifyReportNavigation())
			UMReporter.log(Status.PASS,"Report page is displayed");
	    else
	    	UMReporter.log(Status.FAIL,"Report page is not displayed");
	}
	
	@Then("^Verify the selected ISR Report data from Student Details in Session details page$")
	public void verify_Selected_ISR_Report_is_displayed() throws Exception  {
		UMReporter.log(Status.INFO, "Then : Verify the selected ISR Report data from Student Details in Session details page");
		HashMap<String, String> MapDgOrgRec=null;
		if (MapSessFields!=null) {
			boolean flag=studentdetail.waitForSpinnerVisible(20);
			//Verify the Session details page displayed
			if (flag) {
				MapDgOrgRec=studentdetail.verifyViewReportDetails(MapSessFields);
				UMReporter.log(Status.PASS,"Verified ISR Report data : "+MapDgOrgRec);
					
			}
			else
				UMReporter.log(Status.FAIL,"Spinner Loading exceed the max time");
		}
	    else
	    	UMReporter.log(Status.FAIL,"Session Details are not found");
	}
	
	@Then("^Select Student Details breadcrumb$")
	public void Select_StudentDetails_breadcrumb() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Student Details breadcrumb");
		boolean flag=studentdetail.clickStudentDetailsBreadcrumb();
	    if (flag) {
	    	 UMReporter.log(Status.PASS, "Selected the Student Details breadcrumb");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to select Student Details breadcrumb");
	}
	
	@Then("^User restricted to view student details from student list$")
	public void Verify_Student_Has_Hyperlink_in_student_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User restricted to view student details from student list ");
		 List<String> MapDgOrgDet=studentlist.verifyStuGridNoHyperlinks(2);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "User does not have access to view student details :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The Students are not found in list");
	}
	
	@Then("^User unrestricted to view student details from student list$")
	public void Verify_unrestricted_Student_Has_Hyperlink_in_student_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User unrestricted to view student details from student list");
		 List<String> MapDgOrgDet=studentlist.verifyStuGridHyperlinks(1);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "User have access to view student details :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The Students are not found in list");
	}

	
	@Then("^User direct url navigation to Create Student page$")
	public void DirectNavigation_toStudent_create_page() throws IOException  {
		UMReporter.log(Status.INFO, "Then : User direct url navigation to Create Student page");
		home.AppendUrlDirectPageNavigate();
		if(studentcreate.verifyStudentCreateNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Student Create page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	
	//-------------------------------------------		
	@Given("User navigation to Create Student page")
	public void user_navigation_to_Create_Student_page() throws IOException {
		UMReporter.log(Status.INFO, "When : Click on Create Student tab");
		studentcreate.ClickCreateStudentTab();
		UMReporter.log(Status.PASS, "Selected the Create Student tab");
	}

	@Given("Click on Proceed button on Create Student Warning pop-up")
	public void click_on_Proceed_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Proceed button on Create Student Warning pop-up");
		// Verify the Click Confirm in pop up
		if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
			boolean flag=CommonFunctions.ConfirmPopupActionBtn("Proceed");
			CommonUtility._sleepForGivenTime(500);
			if (flag) 
				UMReporter.log(Status.PASS, "Selected the Proceed button" );
			else
				UMReporter.log(Status.FAIL, "Proceed button is not visible" );
		}
		else
			UMReporter.log(Status.PASS, "Create Student Warning pop-up is not displayed" );
	}

	@Given("Click on Cancel button on Create Student Warning pop-up")
	public void click_on_Cancel_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Cancel button on Create Student Warning pop-up");
		// Verify the Click cancel in pop up
		boolean flag=CommonFunctions.ConfirmPopupActionBtn("Cancel");
		CommonUtility._sleepForGivenTime(1000);
		if (flag) 
			UMReporter.log(Status.PASS, "Selected the Cancel button and pop up is closed " );
		else
			UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed " );
	}
	
	@Given("Verify Reset button is enabled in create Student  page")
	public void verify_Reset_button_is_enabled_in_create_Student_page() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Reset button is visible and enable in Create Student page");    
		boolean resetVisible = studentcreate.StudentResetButton_isVisible();
		if(resetVisible) {
			boolean resetEnabled = studentcreate.StudentResetButton_isEnabled();
			if(resetEnabled)
				UMReporter.log(Status.PASS, "Reset button is visable and enabled");
			else
				UMReporter.log(Status.FAIL, "Reset button is not enabled");
		}
		else
			UMReporter.log(Status.FAIL, "Reset contact button is not visible");
	}

	@Then("^Verify the success message displayed in Create Student page as (.*)$")
	public void verify_success_message_displayed_in_Create_Student_page_as(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Create Student page as " + messages);
		boolean flag;
		flag = studentcreate.verifySuccessMessage(messages);
		if (flag) {
			UMReporter.log(Status.PASS, "Verified the success message displayed in Create Student page:" + messages);		
		}
		else
			UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);		
		
	}
	
	@Given("Click on View the new student now link")
	public void click_on_View_the_new_student_now_link() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Success Message link");
		studentcreate.ClickSuccessLink();
		UMReporter.log(Status.PASS, "Selected the Success Message link");
	}
	
	@Given("Click on Reset button on Create Student Page")
	public void click_on_Reset_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Reset button on Create Student Page");
		studentcreate.ClickResetBtn();
		UMReporter.log(Status.PASS, "Selected the Reset button");
	}
	
	@Given("Verify Create Student button is disabled in Create Student Page")
	public void verify_Create_Student_button_is_disabled_in_crate_student_page() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify create button is visible and disable in Create Student Page");    
		boolean createvisible = studentcreate.StudentCreateButton_isVisible();
		if(createvisible) {
			boolean createenabled = studentcreate.StudentCreateButton_isEnabled();
			if(!createenabled)
				UMReporter.log(Status.PASS, "Create button is disabled");
			else
				UMReporter.log(Status.FAIL, "Create button is not disabled");
		}
		else
			UMReporter.log(Status.FAIL, "Create contact button is not Visible");
	}

	@Given("User switch to Create Student Tab")
	public void user_switch_to_Create_Student_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User switch to Create Student Tab");
		boolean createenabled=studentcreate.SelectTabOption("Create Student");
		if(createenabled)
			UMReporter.log(Status.PASS, "Selected the Create Student tab");
		else
			UMReporter.log(Status.FAIL, "Create Student Tab is not exist");
	}
	
	@Given("User switch to Student List Tab")
	public void user_switch_to_Student_list_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User switch to Student List Tab");
		boolean createenabled=studentcreate.SelectTabOption("Student List");
		if(createenabled)
			UMReporter.log(Status.PASS, "Selected the Student List tab");
		else
			UMReporter.log(Status.FAIL, "Student List Tab is not exist");
	}
	
	@Given("^User permissions in Students page$")
	public void User_Permission_to_Students_page() throws Exception {
		
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		List<String> LstUserPermissions=Constants.PERMISSIONS;
		
		//Switch Org
		String OrgName=FileReaderManager.getInstance().getJsonReader().getSelectOrgName("School"); 
		//Change the Org Details if not expected
		if (!home.Func_VerifyOrgName(OrgName)) 
			home.Func_ChangeOrganization(OrgName);
		
		if (LstUserPermissions.contains("VIEW_STUDENTS_LIST")) {
			UMReporter.log(Status.INFO, "Given : User permissions in Students page");
			home.MenuOtion("students", "");
			if(studentlist.verifyStudentListNavigation())
				UMReporter.log(Status.PASS,"User have access Students option in the hamburger menu");
				List<String> MapDgStuColHeader=studentlist.verifyStusearchresultsDetails(1);
				if (MapDgStuColHeader!=null)
			    	UMReporter.log(Status.PASS, "User have access to view list of Students : "+MapDgStuColHeader);
			
			
			if (LstUserPermissions.contains("CREATE_STUDENT")) {
				if(studentcreate.CreateStudentTab_isVisible()) 
					UMReporter.log(Status.PASS, "User have access to Create Student, Create button is visible");
				else
					UMReporter.log(Status.SKIP, "User have access to Create Student, Create button is not visible");
				if (LstUserPermissions.contains("CREATE_TEMPORARY_STUDENT")) {
					if(studentcreate.CreateStudentTab_isVisible()) 
						UMReporter.log(Status.PASS, "User have access to Create Temporary Student, Create Student Tab is visible");
					else
						UMReporter.log(Status.SKIP, "User have access to Create Temporary Student, Create Student Tab is not visible");		
				}
			}
			
//			if (LstUserPermissions.contains("DELETE_STUDENT")) {
//				lstSelectedStudent=studentlist.SelectonStuCheckbox(1);
//			    if (lstSelectedStudent.size()>0) {
//					if(studentlist.DeleteStudents_isVisible())
//						UMReporter.log(Status.PASS, "User have access to Delete Student, Delete button is displayed when selected the Student "+lstSelectedStudent);
//					else
//						UMReporter.log(Status.FAIL, "User have access to Delete Student, Delete button is not visible");
//			    }
//			    else
//			    	UMReporter.log(Status.SKIP, "User have access to Delete Student, Unable to select Student checkbox");
//			}
			
			if (LstUserPermissions.contains("DELETE_TEMPORARY_STUDENT")) {
				lstSelectedStudent=studentlist.SelectonStudentCheckboxWithMatchedColValue(1,Constants.FDStudID,"TEMP");
			    if (lstSelectedStudent.size()>0) {
					if(studentlist.DeleteStudents_isVisible())
						UMReporter.log(Status.PASS, "User have access to Delete Student, Delete button is displayed when selected the Student "+lstSelectedStudent);
					else
						UMReporter.log(Status.FAIL, "User have access to Delete Student, Delete button is not visible");
			    }
			    else
			    	UMReporter.log(Status.SKIP, "User have access to Delete Student, Unable to select Student checkbox");
			}
			
			if ((LstUserPermissions.contains("VIEW_STUDENT_PROFILE"))&&(!LstUserPermissions.contains("VIEW_STUDENT_PROFILE_RESTRICTED"))) {
				MapStuFields=studentlist.SelectStudentRecord();
				if(MapStuFields!=null) {
					if(studentdetail.verifyStudentDetailsNavigation()) {
						studentdetail.verifyViewStudentDetails(MapStuFields);
							
							if (LstUserPermissions.contains("EDIT_CLASS")) {
								if(studentdetail.EditButton_isVisible())
									UMReporter.log(Status.PASS, "User have access to Edit Student, Edit button is displayed");
								else
									UMReporter.log(Status.FAIL, "User have access to Edit Student, Edit button is not displayed");
							}
							
							if (LstUserPermissions.contains("ACCESS_STUDENT_TESTSESSIONS")) {
							    if (studentdetail.SelectTabOption("Session List")) {
							    	List<String> MapDgOrgColHeader=studentdetail.verifySessionSearchresultsDetails(1);
								    if (MapDgOrgColHeader!=null) {
								    	UMReporter.log(Status.PASS, "User have access to View Student Session assignments  , Session details : "+MapDgOrgColHeader);
								    	if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
									    	List<String> MapDgSessColHeader=studentdetail.verifySessionHyperlink(1);
										    if (MapDgSessColHeader!=null) 
										    	UMReporter.log(Status.PASS, "User have access to View Student Session assignment detail , Session hyperlink : "+MapDgSessColHeader);
								    	}
								    }	
								    else
										UMReporter.log(Status.SKIP, "User have access to View Student Session assignments ,  No session records");
							    }
							}
							
							if (LstUserPermissions.contains("ACCESS_CLASSES")) {
							    if (studentdetail.SelectTabOption("Class List")) {
							    	List<String> MapDgOrgColHeader=studentdetail.verifySessionSearchresultsDetails(1);
								    if (MapDgOrgColHeader!=null) {
								    	UMReporter.log(Status.PASS, "User have access to View Student Class Assignments , Class details : "+MapDgOrgColHeader);
								    
								    	if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
									    	List<String> MapDgSessColHeader=studentdetail.verifySessionHyperlink(1);
										    if (MapDgSessColHeader!=null) 
										    	UMReporter.log(Status.PASS, "User have access to View Student Class assignment detail , Class hyperlink : "+MapDgSessColHeader);
								    	}
								    }
								    else
										UMReporter.log(Status.SKIP, "User have access to View Student Class Assignments,  No Class records");
							    }
							}
						}
						else
							UMReporter.log(Status.FAIL,"The Student details is not displayed");	
					}
					else
						UMReporter.log(Status.SKIP,"No records found in Student list");
			}
			
			if (LstUserPermissions.contains("VIEW_STUDENT_PROFILE_RESTRICTED")) {
				//Search Teacher student
				 studentlist.Searchfill_StudName(CommonFunctions.getTestData("$teacherstudent"));
				 studentlist.clicksearchicon();
				MapStuFields=studentlist.SelectStudentRecord();
				if(MapStuFields!=null) {
					if(studentdetail.verifyStudentDetailsNavigation()) {
						studentdetail.verifyViewStudentDetails(MapStuFields);
							
							if (LstUserPermissions.contains("EDIT_CLASS")) {
								if(studentdetail.EditButton_isVisible())
									UMReporter.log(Status.PASS, "User have access to Edit Student, Edit button is displayed");
								else
									UMReporter.log(Status.FAIL, "User have access to Edit Student, Edit button is not displayed");
							}
							
							if (LstUserPermissions.contains("ACCESS_STUDENT_TESTSESSIONS")) {
							    if (studentdetail.SelectTabOption("Session List")) {
							    	List<String> MapDgOrgColHeader=studentdetail.verifySessionSearchresultsDetails(1);
							    	if (MapDgOrgColHeader!=null) {
								    	UMReporter.log(Status.PASS, "User have access to View Student Session assignments  , Session details : "+MapDgOrgColHeader);
								    	if (LstUserPermissions.contains("ACCESS_TEST_SESSIONS")) {
									    	List<String> MapDgSessColHeader=studentdetail.verifySessionHyperlink(1);
										    if (MapDgSessColHeader!=null) 
										    	UMReporter.log(Status.PASS, "User have access to View Student Session assignment detail , Session hyperlink : "+MapDgSessColHeader);
								    	}
								    }
								    else
										UMReporter.log(Status.SKIP, "User have access to View Student Session assignments ,  No session records");
							    }
							}
							
							if (LstUserPermissions.contains("ACCESS_CLASSES")) {
							    if (studentdetail.SelectTabOption("Class List")) {
							    	List<String> MapDgOrgColHeader=studentdetail.verifySessionSearchresultsDetails(1);
							    	 if (MapDgOrgColHeader!=null) {
									    	UMReporter.log(Status.PASS, "User have access to View Student Class Assignments , Class details : "+MapDgOrgColHeader);
									    	if (LstUserPermissions.contains("ACCESS_CLASSES")) {
										    	List<String> MapDgSessColHeader=studentdetail.verifySessionHyperlink(1);
											    if (MapDgSessColHeader!=null) 
											    	UMReporter.log(Status.PASS, "User have access to View Student Class assignment detail , Class hyperlink : "+MapDgSessColHeader);
									    	}
									   }
								    else
										UMReporter.log(Status.SKIP, "User have access to View Student Class Assignments,  No Class records");
							    }
							}
						}
						else
							UMReporter.log(Status.FAIL,"The Student details is not displayed");	
					}
					else
						UMReporter.log(Status.SKIP,"No records found in Student list");
			}
		}
		else
			UMReporter.log(Status.PASS,"User restricted for Students");
		
	}
	
	@Then("verify the More link to display all accommodation")
	public void verify_the_More_link_to_display_all_accommodation() throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the More link to display all accommodation");
		boolean flag=studentlist.clickMoreLink();
	    if (flag)
	    	 UMReporter.log(Status.PASS, "Clicked the More Link");
		 else
		    UMReporter.log(Status.FAIL, "Unable to click on More Link");
	}
	
	@Then("verify the accommodation list is displayed")
	public void verify_the_accommodation_list_is_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the accommodation list is displayed");
		//Verify the Org list page displayed
		if(studentlist.verifyAccommodationList())
			{
			UMReporter.log(Status.PASS,"Accommodation list is displayed");
			studentlist.closeAccommodationList();
			}
	    else
	    	UMReporter.log(Status.FAIL,"Accommodation list is not displayed");
	}

	
	@When("^User search the student for Merge Student by search text (.*)$")
	public void Fill_SearchSearchtext_student_list(String SeachText) throws Exception {
		//UMReporter.log(Status.INFO, "Then : User search the student for Merge Student by search text : "+SeachText);
		boolean flag=false;
//		if (MapStuFields!=null) { 
//			if (MapStuFields.containsKey("Last Name")) 
//				SeachText=MapStuFields.get("Last Name");
//		}
		if (SeachText.indexOf("$")>=0)
			SeachText=CommonFunctions.getTestData(SeachText);
		UMReporter.log(Status.INFO, "Then : User search the student for Merge Student by search text : "+SeachText);
		flag=studentlist.Searchfill_StudName(SeachText);
		flag=studentlist.clicksearchicon();
		MapStuFields=studentlist.getPermanentStudsNotTempid(1,Constants.FDStudID,"TEMP");
		if(MapStuFields!=null) {
			if (MapStuFields.containsKey("Student Name")) {
				String StudName=MapStuFields.get("Student Name");
				String NameSplit[]=StudName.split(", ");
       		  	if (NameSplit.length>=1){
       			  String Lname=NameSplit[0];
       			  MapStuFields.put("Last Name", Lname);
       			  String FMname=NameSplit[1];
       			  String FMNameSplit[]=FMname.split(" ");
       			  if (FMNameSplit.length>1){
       				String Fname=FMNameSplit[0];
       				MapStuFields.put("First Name", Fname);
       			 	String Mname=FMNameSplit[1];
       			 	MapStuFields.put("Middle Name", Mname);
       			  }
       			  else
       				MapStuFields.put("First Name", FMname);
       		  	}
			}

				 UMReporter.log(Status.PASS, "The Search Student details :"+MapStuFields);
		}
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@Then("^User fill the existing student informations in create student page$")
	public void user_fills_existing_Value_present_createstudent(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User fill the existing student informations in create student page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		boolean isfieldLabelExist=false;
		HashMap<String,String> MapStuExistingFields=  new HashMap<String,String>();
		MapStuExistingFields=MapStuFields;
		if (MapStuExistingFields!=null) {		
			// Get fields from Configuration json file
			List<Studentfield> fields = FileReaderManager.getInstance().getJsonReader().getStudentfields(Constants.ORG_STATE);
			if (fields!=null) {
				if((studentcreate.VerifyAddstudentForm())||(studentcreate.VerifyEditstudentForm())) {
					List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
					NonVerified=new ArrayList<String>();
					MapStuFilledFields=  new HashMap<String,String>();
					for (int i = 0; i < list.size(); i++) {
						Fieldname = list.get(i).get("FieldLabel");
						if (MapStuExistingFields.containsKey(Fieldname))
							FieldValue = MapStuExistingFields.get(Fieldname);
						else
							FieldValue = list.get(i).get("InputValue");
						
						System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
						isfieldLabelExist=studentcreate.VerifyFieldLabel(Fieldname);
						if (isfieldLabelExist) {
							Studentfield field=FileReaderManager.getInstance().getJsonReader().getStudentfieldbyLabel(fields, Fieldname);
							if (field!=null) {
								FilledFieldValue = studentcreate.FillStuContactField(field, FieldValue);
								if (FilledFieldValue==null)
									NonVerified.add(Fieldname);
								else 
									MapStuFilledFields.put(Fieldname,FilledFieldValue);
							}
							else {
								System.out.println("Field Not Exist in Testdataresources file:" +FieldValue);
							}
						}
					}
					
					if (MapStuFilledFields!=null) {
						if ((MapStuFilledFields.containsKey("Last Name"))&&(MapStuFilledFields.containsKey("First Name"))&&(MapStuFilledFields.containsKey("Middle Name"))) {
							 String StuName=MapStuFilledFields.get("Last Name")+", "+MapStuFilledFields.get("First Name")+" "+MapStuFilledFields.get("Middle Name");
								MapStuFilledFields.put("Student Name",StuName);
						}
						else if ((MapStuFilledFields.containsKey("Last Name"))&&(MapStuFilledFields.containsKey("First Name"))) {
							 String StuName=MapStuFilledFields.get("Last Name")+", "+MapStuFilledFields.get("First Name");
								MapStuFilledFields.put("Student Name",StuName);
						}
					}
						
					
					if (NonVerified.size()>0)
						UMReporter.log(Status.FAIL, "The following student fields are unable to provide the input value :"+NonVerified);
					else
						UMReporter.log(Status.PASS, "The following student fields provided the input values :"+ MapStuFilledFields);
					
				}
			}
		}
	}
	
	
	
	@Then("^User fill the student accommodations informations in create student page$")
	public void user_fills_accomodations_Value_present_createstudent(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User fill the student accommodations informations in create student page");
		String Fieldname,FieldValue,FieldSubject,FilledFieldLabel=null;
		List<String> NonVerified=null;
		boolean isfieldLabelExist=false;
		boolean FilledFieldFlag=false;
		
		//Expand Accomm Blade
		if (!studentcreate.Verify_Student_Accommodations_Blade()) 
			studentcreate.StudentAccommodationBladeExpand("Yes");
		
		// Get fields from Configuration json file
		if(studentcreate.VerifyStudentAccommodationForm()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			MapStuAccomFields=  new HashMap<String,String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Accommodations");
				FieldSubject = list.get(i).get("Subject");
				FieldValue = list.get(i).get("ValidValue");
				System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
				isfieldLabelExist=studentcreate.VerifyAccommodationsLabel(Fieldname);
				if (isfieldLabelExist) {
					FilledFieldFlag = studentcreate.FillAccommodationsField(Fieldname,FieldSubject, FieldValue);
					FilledFieldLabel=Fieldname+" - "+FieldSubject;
					
					if (FilledFieldFlag) {
						MapStuAccomFields.put(FilledFieldLabel,FieldValue);
					}
					else 
						NonVerified.add(Fieldname);
				}
				
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following student accommodation fields are unable to provide the input value :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following student accommodation fields provided the input values :"+ MapStuAccomFields);
		}
		else
			UMReporter.log(Status.SKIP, "The student accommodation fields are not displayed");
	
	}
	
	@Then("^User edit the student accommodations informations in student details page$")
	public void user_edit_accomodations_Value_present_StudentDetails(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User edit the student accommodations informations in student details page");
		String Fieldname,FieldValue,FieldSubject,FilledFieldLabel=null;
		List<String> NonVerified=null;
		boolean isfieldLabelExist=false;
		boolean FilledFieldFlag=false;
		//Expand Accomm Blade
		if (!studentdetail.Verify_Student_Accommodations_Blade()) 
			studentdetail.StudentAccommodationBladeExpand("Yes");
		
		// Get fields from Configuration json file
		if(studentdetail.verifyEditStudentAccomTitle()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			MapStuAccomFields=  new HashMap<String,String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Accommodations");
				FieldSubject = list.get(i).get("Subject");
				FieldValue = list.get(i).get("ValidValue");
				System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
				isfieldLabelExist=studentcreate.VerifyAccommodationsLabel(Fieldname);
				if (isfieldLabelExist) {
					FilledFieldFlag = studentcreate.FillAccommodationsField(Fieldname,FieldSubject, FieldValue);
					FilledFieldLabel=Fieldname+" - "+FieldSubject;
					if (FilledFieldFlag) {
						MapStuAccomFields.put(FilledFieldLabel,FieldValue);
					}
					else 
						NonVerified.add(Fieldname);
				}
				
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following student accommodation fields are unable to edit the input value :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following student accommodation fields edited the input values :"+ MapStuAccomFields);
		}
		else
			UMReporter.log(Status.SKIP, "The student accommodation fields are not displayed");
	
	}
	
	@When("^Select the (.*) Temporary student in student list page$")
	public void Select_Temp_Student_Dependson_Colum_Value_checkbox_Studentlist(String stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the "+stucount+" Temporary student in student list page");
		int stucnt=1;
		if (CommonUtility.isNumeric(stucount))
			stucnt=Integer.parseInt(stucount);
		lstSelectedStudent=studentlist.SelectonStudentCheckboxWithMatchedColValue(stucnt,Constants.FDStudID,"TEMP");
	    if (lstSelectedStudent.size()>0)
	    	UMReporter.log(Status.PASS, "Selected the Temporary Student checkbox "+lstSelectedStudent);
	    else
	    	UMReporter.log(Status.FAIL, "The Temporary Student are not found in list");
	}
	
	@When("^Select the (.*) Permanent student in student list page$")
	public void Select_Perm_Student_Dependson_Colum_Value_checkbox_Studentlist(String stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the "+stucount+" Permanent student in student list page");
		int stucnt=1;
		if (CommonUtility.isNumeric(stucount))
			stucnt=Integer.parseInt(stucount);
		lstSelectedStudent=studentlist.SelectonStudentCheckboxWithNotMatchedColValue(stucnt,Constants.FDStudID,"TEMP");
	    if (lstSelectedStudent.size()>0)
	    	UMReporter.log(Status.PASS, "Selected the Permanent Student checkbox "+lstSelectedStudent);
	    else
	    	UMReporter.log(Status.FAIL, "The Permanent Student are not found in list");
	}
	
	@Then("^Verify Merge Students button is visible in student list page$")
	public void verify_Merge_Students_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Merge Students button is visible in student list page");
		boolean createenabled = studentlist.MergeStudents_isVisible();
		if(createenabled)
			UMReporter.log(Status.PASS, "Merge Students option is visible");
		else
			UMReporter.log(Status.FAIL, "Merge Students option is not visible");
	}
	
	@Then("^Click on Merge Students button$")
	public void click_Merge_Students_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Merge Students button");
		if (studentlist.MergeStudents_isVisible()) {
		studentlist.clickMergeStudents();
		UMReporter.log(Status.PASS, "Selected the Merge Students Student button");
		}
		else
			UMReporter.log(Status.SKIP, "Merge Students option is not displayed");
	}
	
	@When("^Verify title and content (.*) in Merge Selected Students Warning pop-up$")
	public void Verify_title_message_MergeStudentPopUp_button(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Confirm Delete Session pop-up");
		boolean flag=false;
		// Verify the Confirm pop up
		flag=CommonFunctions.VerifyConfirmPopupContent(Constants.MergeSelectStudentPopupTitle,confmessage);
		if (flag)
			UMReporter.log(Status.PASS, "Verified Confirm Delete Session pop-up title and message : " +confmessage);
			
	}
	
	@Given("Click on Proceed button on Merge Selected Students Warning pop-up")
	public void click_on_Proceed_button_Merge_popup() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Proceed button on Merge Selected Students Warning pop-up");
		// Verify the Click Confirm in pop up
		if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
			boolean flag=CommonFunctions.ConfirmPopupActionBtn("Proceed");
			CommonFunctions.waitUntilLoadingSpinner(10);
			CommonUtility._sleepForGivenTime(8000);
			if (flag) 	
				UMReporter.log(Status.PASS, "Selected the Proceed button" );
			else
				UMReporter.log(Status.FAIL, "Proceed button is not visible" );
		}
		else
			UMReporter.log(Status.SKIP, "Merge Students Confirmation Pop Up not displayed");
			
	}

	@Given("Click on Cancel button on Merge Selected Students Warning pop-up")
	public void click_on_Cancel_button_Merge_popup() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Cancel button on Merge Selected Students Warning pop-up");
		if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
			// Verify the Click cancel in pop up
			boolean flag=CommonFunctions.ConfirmPopupActionBtn("Cancel");
			CommonUtility._sleepForGivenTime(1000);
			if (flag) 
				UMReporter.log(Status.PASS, "Selected the Cancel button and pop up is closed " );
			else
				UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed " );
		}
		else
			UMReporter.log(Status.SKIP, "Merge Students Confirmation Pop Up not displayed");
	}

	@Then("^Verify the success message displayed in Student List page as (.*)$")
	public void verify_success_message_displayed_in_Student_list_page_as(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Student List page as " + messages);
		String ActualMessage;
		ActualMessage = studentcreate.GetSuccessMessage();
		if ((ActualMessage!=null)&&(ActualMessage.length()>2)) {
			if(ActualMessage.contains(messages))
				UMReporter.log(Status.PASS, "Verified the success message displayed in Student List page:" + messages);
			else if(ActualMessage.contains("ERROR"))
				UMReporter.log(Status.SKIP, "The error message displayed :" +ActualMessage);
			else
				UMReporter.log(Status.FAIL, "Not matched expected message :" + messages+"\n Actual :"+ActualMessage);
			studentcreate.Close_Alerts();
		}	
		else
			UMReporter.log(Status.SKIP, "No Success message displayed" );
		
	}
	
	
	@Then("^Verify the success message displayed in Student Details page as (.*)$")
	public void verify_success_message_displayed_in_StudentDetails_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Student Details page as " + messages);
		String ActualMessage;
		ActualMessage = studentcreate.GetSuccessMessage();
		if ((ActualMessage!=null)&&(ActualMessage.length()>2)) {
			// Sesscount
			if (messages.contains("<X>")) {
				if (lstSelectedSession.size() > 0) {
					int iSelectedCnt=lstSelectedSession.size();
					messages = messages.replace("<X>", String.valueOf(iSelectedCnt));
				}
			}
			
			if(ActualMessage.contains(messages))
				UMReporter.log(Status.PASS, "Verified the success message displayed in Student Details page:" + messages);
			else if(ActualMessage.contains("ERROR"))
				UMReporter.log(Status.SKIP, "The error message displayed :" +ActualMessage);
			else
				UMReporter.log(Status.FAIL, "Not matched expected message :" + messages+"\n Actual :"+ActualMessage);
			studentcreate.Close_Alerts();
		}
		else
			UMReporter.log(Status.SKIP, "No Success message displayed" ); 
		
	}
	
	@Then("^Verify Delete Students button is visible in student list page$")
	public void verify_Delete_Students_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Delete Students button is visible in student list page");
		boolean createenabled = studentlist.DeleteStudents_isVisible();
		if(createenabled)
			UMReporter.log(Status.PASS, "Delete Students option is visible");
		else
			UMReporter.log(Status.FAIL, "Delete Students option is not visible");
	}
	
	@Then("^Click on Delete Students button$")
	public void click_Delete_Students_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Delete Students button");
		if (studentlist.DeleteStudents_isVisible())
		{
			studentlist.clickDeleteStudents();
			UMReporter.log(Status.PASS, "Selected the Delete Students Student button");
		}
		else
			UMReporter.log(Status.SKIP, "Delete Students option is not visible");
	}
	
	@When("^Verify title and content (.*) in Delete Selected Students Warning pop-up$")
	public void Verify_title_message_DeleteStudentPopUp_button(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Confirm Delete Student pop-up");
		boolean flag=false;
		// Verify the Confirm pop up
		flag=CommonFunctions.VerifyConfirmPopupContent(Constants.MergeSelectStudentPopupTitle,confmessage);
		CommonUtility._sleepForGivenTime(1000);
		if (flag) 
			UMReporter.log(Status.PASS, "Verified Confirm Delete Student pop-up title and message : " +confmessage);
		
	}
	
	@Given("Click on Delete button on Delete Selected Students Warning pop-up")
	public void click_on_Proceed_button_Delete_popup() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Delete button on Delete Selected Students Warning pop-up");
		// Verify the Click Confirm in pop up
		if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
			boolean flag=CommonFunctions.ConfirmPopupActionBtn("Confirm");
			CommonUtility._sleepForGivenTime(5000);
			if (flag) {
				flag=studentlist.waitForProgressbarVisible(20);
				UMReporter.log(Status.PASS, "Selected the Confirm button" );
			}
			else
				UMReporter.log(Status.FAIL, "Confirm button is not visible" );
		}
		else
			UMReporter.log(Status.SKIP, "Delete Confirm Popup is not displyed");
			
	}

	@Given("Click on Cancel button on Delete Selected Students Warning pop-up")
	public void click_on_Cancel_button_Delete_popup() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Cancel button on Delete Selected Students Warning pop-up");
		// Verify the Click cancel in pop up
		boolean flag=CommonFunctions.ConfirmPopupActionBtn("Cancel");
		CommonUtility._sleepForGivenTime(1000);
		if (flag) 
			UMReporter.log(Status.PASS, "Selected the Cancel button and pop up is closed " );
		else
			UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed " );
	}
	
	@When("^User select the Temporary student from student list$")
	public void user_clicks_on_First_TempStudents_StudentList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select the Temporary student from student list");
		boolean flag=false;
		HashMap<String,String> MapOrgField=null;
		// Get Student Search results by row number
		MapStuFields=studentlist.SelectStudentWithMatchedColValue(1,Constants.FDStudID,"TEMP");
		if(MapStuFields!=null) {
			if (MapStuFields.containsKey("Student Name")) {
				String StudName=MapStuFields.get("Student Name");
				String NameSplit[]=StudName.split(", ");
       		  	if (NameSplit.length>=1){
       			  String Lname=NameSplit[0];
       			  MapStuFields.put("Last Name", Lname);
       			  String FMname=NameSplit[1];
       			  String FMNameSplit[]=FMname.split(" ");
       			  if (FMNameSplit.length>1){
       				String Fname=FMNameSplit[0];
       				MapStuFields.put("First Name", Fname);
       			 	String Mname=FMNameSplit[1];
       			 	MapStuFields.put("Middle Name", Mname);
       			  }
       			  else
       				MapStuFields.put("First Name", FMname);
       		  	}
				CommonUtility._sleepForGivenTime(2000);
				UMReporter.log(Status.PASS,"Selected the Student name "+MapStuFields.get("Student Name")+" hyperlink in Student list");
			}else
				UMReporter.log(Status.FAIL,"The Temporary Student name "+MapStuFields.get("Student Name")+"  not found in Student list");
		}
		else
			UMReporter.log(Status.FAIL,"No temporary student records found in Student list");	
		
	}
	
	@When("^User select the Permanent student from student list$")
	public void user_clicks_on_First_Permanent_Students_StudentList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select the Permanent student from student list");
		boolean flag=false;
		HashMap<String,String> MapOrgField=null;
		// Get Student Search results by row number
		MapStuFields=studentlist.SelectStudentWithNotMatchedColValue(1,Constants.FDStudID,"TEMP");
		if(MapStuFields!=null) {
			if (MapStuFields.containsKey("Student Name")) {
				String StudName=MapStuFields.get("Student Name");
				String NameSplit[]=StudName.split(", ");
       		  	if (NameSplit.length>=1){
       			  String Lname=NameSplit[0];
       			  MapStuFields.put("Last Name", Lname);
       			  String FMname=NameSplit[1];
       			  String FMNameSplit[]=FMname.split(" ");
       			  if (FMNameSplit.length>1){
       				String Fname=FMNameSplit[0];
       				MapStuFields.put("First Name", Fname);
       			 	String Mname=FMNameSplit[1];
       			 	MapStuFields.put("Middle Name", Mname);
       			  }
       			  else
       				MapStuFields.put("First Name", FMname);
       		  	}
				CommonUtility._sleepForGivenTime(2000);
				UMReporter.log(Status.PASS,"Selected the Student name "+MapStuFields.get("Student Name")+" hyperlink in Student list");
			}else
				UMReporter.log(Status.FAIL,"The Permanent Student name "+MapStuFields.get("Student Name")+"  not found in Student list");
		}
		else
			UMReporter.log(Status.FAIL,"No Permanent student records found in Student list");	
		
	}
	
	@When("^User select and verify the student accommodation capsule in student list$")
	public void user_select_verify_first_Students_Accomm_StudentList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select and verify the student accommodation capsule in student list");
		boolean flag=false;
		HashMap<String,String> MapStuAccomField=null;
		// Get Student Search results by row number
		MapStuAccomField=studentlist.SelectStudentWithAccomCapsule("Accom");
		if(MapStuAccomField!=null) {
			if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
				List<String> accomlist=CommonFunctions.GetDailogContent();
				CommonFunctions.CloseDialog();
				UMReporter.log(Status.PASS,"The Accommodation details displayed for Student name "+MapStuAccomField.get("Student Name")+" are "+accomlist);
			}
			else
				UMReporter.log(Status.FAIL,"The Accommodation details not displayed after selecting Accommodation capsule for Student name "+MapStuAccomField.get("Student Name"));
		}
		else
			UMReporter.log(Status.SKIP,"No student with accom capsule records found in Student list");	
		
	}
	
	
	@Then("^Verify Update Reporting School button is visible in Student Details page$")
	public void verify_Update_Reporting_School_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Update Reporting School button is visible in Student Details page");
		if (lstSelectedSession.size()>0){
			boolean createenabled = studentdetail.updateReportingSchool_isVisible();
			if(createenabled)
				UMReporter.log(Status.PASS, "Update Reporting School option is visible");
			else
				UMReporter.log(Status.FAIL, "Update Reporting School option is not visible");
		}
		  else
		    	UMReporter.log(Status.SKIP, "The Sessions are not selected to enable Update Reporting School Options");
	}
	
	

@When("^User select (.*) session from Session List in Student Details page$")
	public void Select_Session_checkbox_StudentProfile(String stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : User select "+stucount+" session from Session List in Student Details page");
		int stucnt=1;
		if (CommonUtility.isNumeric(stucount))
			stucnt=Integer.parseInt(stucount);
		lstSelectedSession=studentdetail.SelectonSessionCheckbox(stucnt);
	    if (lstSelectedSession.size()>0)
	    	UMReporter.log(Status.PASS, "Selected the Sessions : "+lstSelectedSession);
	    else
	    	UMReporter.log(Status.SKIP, "The Sessions are not found in list");
	}

	
	@Then("^User Update Reporting School from Session list in Student Detail Page$")
	public void click_Update_Reporting_School_button_StudentDetails() throws Exception {
		UMReporter.log(Status.INFO, "When : User Update Reporting School from Session list in Student Detail Page");
		boolean flag=false;
		if ((studentdetail.updateReportingSchool_isVisible())&&((lstSelectedSession.size()>0)))
		{
			List<String> lstSchhool=studentdetail.GetReportingSchoolList();
			CommonUtility._sleepForGivenTime(2000);
			for (String TestSchool:lstSchhool) {
				String SessionSchool=lstSelectedSession.toString();
				if (!SessionSchool.contains(TestSchool)) {
					SelectedReportingSchool=TestSchool;
					flag=studentdetail.SelectReportingSchoolFromList(SelectedReportingSchool);
					break;
				}
			}
			if (flag)
				UMReporter.log(Status.PASS, "Updated "+SelectedReportingSchool+" Reporting School for the Session : "+lstSelectedSession);
			else
				UMReporter.log(Status.FAIL, "Unable to Update Reporting School for the Session : "+lstSelectedSession);
				
		}
		else
			UMReporter.log(Status.SKIP, "Update Reporting School option is not visible");
			
	}
	
	@When("^Verify title and content (.*) in Update Reporting School Confirmation pop-up$")
	public void Verify_title_message_Update_Reporting_SchoolPopUp_button(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Update Reporting School Confirmation pop-up");
		boolean flag=false;
		// Verify the Confirm pop up
		flag=CommonFunctions.VerifyConfirmPopupContent(Constants.UpdateReportingSchoolPopupTitle,confmessage);
		CommonUtility._sleepForGivenTime(1000);
		if (flag) 
			UMReporter.log(Status.PASS, "Verified Confirm Update Reporting School pop-up title and message : " +confmessage);
		else
			UMReporter.log(Status.FAIL, "Confirmation Popup is not visible" );
			
	}
	
	@Given("User confirms in Update Reporting School Confirmation pop-up")
	public void click_on_Proceed_button_Update_Reporting_School_popup() throws Exception {
		UMReporter.log(Status.INFO, "When : User confirms in Update Reporting School Confirmation pop-up");
		// Verify the Click Confirm in pop up
		if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
			boolean flag=CommonFunctions.ConfirmPopupActionBtn("Confirm");
			CommonUtility._sleepForGivenTime(5000);
			if (flag) {
				flag=studentlist.waitForProgressbarVisible(20);
				UMReporter.log(Status.PASS, "Confirmed in Update Reporting School pop-up " );
			}
			else
				UMReporter.log(Status.FAIL, "Confirm button is not visible" );
		}
		else
			UMReporter.log(Status.SKIP, "Confirmation Popup is not displyed");
			
	}
	
	@Then("^Verify the updated Reporting School from Session List in Student details page$")
	public void verify_Updated_Reporting_School_In_SessionList() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the updated Reporting School from Session List in Student details page");
		 if ((lstSelectedSession.size()>0)&&(SelectedReportingSchool!=null)) {
			//Verify the Session details page displayed
			 HashMap<String, String> MapDgOrgRec = studentdetail.verifySessRepSchoolfromlist(1,"School",SelectedReportingSchool);
			 if (MapDgOrgRec!=null)
				 UMReporter.log(Status.PASS, "Verified the updated Reporting School for session "+MapDgOrgRec );
		}
	    else
	    	UMReporter.log(Status.SKIP,"Session Details are not found");
	}

	@Then("^User fill the student demographics informations in create student page$")
	public void user_fills_demographics_Value_present_createstudent() throws IOException {
		UMReporter.log(Status.INFO,"When : User fill the student demographics informations in create student page");
		List<String> NonVerified=null;

		// Get fields from Configuration json file
		if(studentcreate.VerifyStudentDemographicsForm()) {
			
			if (!studentcreate.Verify_Student_Demographics_Blade()) 
				studentcreate.StudentDemographicsBladeExpand("Yes");
			
			String orgrefid=CommonFunctions.getTestData("schoolrefid");
			String custrefid=CommonFunctions.getTestData("customerrefid");
			Constants.APIheaders.put("orgreferenceid", orgrefid);
			lstApiCustDemoFields=requests.Getcustomerdemographics(Constants.APIheaders,custrefid,orgrefid);
			System.out.println("customerdemographics  : "+lstApiCustDemoFields);
			if (lstApiCustDemoFields!=null) {
				//MapStuDemoFields=  new HashMap<String,String>();
				MapStuDemoFields=studentcreate.FillDemographicsFields(lstApiCustDemoFields,"all");
				if (MapStuDemoFields.size()>0)
					UMReporter.log(Status.PASS, "The following student demographics fields provided :"+ MapStuDemoFields);
				else
					UMReporter.log(Status.FAIL, "The following student demographics fields are unable to provide the input value :"+NonVerified);
			}
			else
				UMReporter.log(Status.SKIP, "API student customer demographics failed for Org "+orgrefid);
		}
		else
			UMReporter.log(Status.SKIP, "The student demographics fields are not displayed");
	
	}
	
	@Then("^Verify the filled Student demographics information in Student details page$")
	public void verify_filled_Student_Demographics_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the filled Student demographics information in Student details page");
		if (MapStuFilledFields!=null) {
			//Verify the Student Detail page displayed
			if(studentdetail.verifyStudentDetailsNavigation()&&studentdetail.verifyStudentDetails()) {
				if (!studentdetail.Verify_Student_Demographics_Blade()) 
					studentdetail.StudentDemographicsBladeExpand("Yes");
			//Verify the Student details page displayed
				studentdetail.verifyViewStudentDetails(MapStuDemoFields);
			}
			else
				UMReporter.log(Status.FAIL,"Student Demographics Details is not displayed");
		}
	    else
	    	UMReporter.log(Status.FAIL,"Student Demographics Details are not found");
	}
	
	@Given("^Verify the Student Demographics fields in Student details page$")
	public void verify_Students_demographics_fields() throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the Student Demographics fields in Student details page");
		String Fieldname,FieldValue;
		List<String> NonVerified=null;
		List<String> VerifiedField=null;
		if(studentdetail.Verify_Student_Demographics()){
			if (!studentdetail.Verify_Student_Demographics_Blade())
				studentdetail.StudentDemographicsBladeExpand("Yes");
			
			if (lstApiCustDemoFields==null) {
				String orgrefid=CommonFunctions.getTestData("schoolrefid");
				String custrefid=CommonFunctions.getTestData("customerrefid");
				Constants.APIheaders.put("orgreferenceid", orgrefid);
				lstApiCustDemoFields=requests.Getcustomerdemographics(Constants.APIheaders,custrefid,orgrefid);
				System.out.println("customerdemographics  : "+lstApiCustDemoFields);
			}
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			if (lstApiCustDemoFields!=null) {
				if (lstApiCustDemoFields.size()>0) {
					//Iterate each field values
					for (Map<String,Object> MapSetField: lstApiCustDemoFields){
						String sFieldLabel=MapSetField.get("demographicDisplayCode").toString();
						if (!studentdetail.verifyStudentLabel(sFieldLabel))
							NonVerified.add(sFieldLabel);
						else {
							FieldValue=studentdetail.GetValueforStudentLabel(sFieldLabel);
							VerifiedField.add(sFieldLabel+" = "+FieldValue);
						}
					}
				}
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected Students Demographics fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following verified Students Demographics fields with values :"+VerifiedField);
		}
		else
			UMReporter.log(Status.FAIL, "The Students Demographics fields are not found ");
	}
	
	@Then("^Verify Reassign Test button is visible in Student Details page$")
	public void verify_Reassign_Test_button_is_enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Reassign Test(s) button is visible in Student Details page");
		boolean createenabled = studentdetail.ReassignTestButton_isVisible();
		if(createenabled)
			UMReporter.log(Status.PASS, "Reassign Test(s) option is visible");
		else
			UMReporter.log(Status.FAIL, "Reassign Test(s) option is not visible");
	}
	
	@Then("^Click on Reassign Test button$")
	public void click_Reassign_Test_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Reassign Test(s) button");
		if (studentdetail.ReassignTestButton_isVisible()) {
			studentdetail.clickReassignTest();
		UMReporter.log(Status.PASS, "Selected the Reassign Test(s) button");
		}
		else
			UMReporter.log(Status.SKIP, "Reassign Test(s) option is not displayed");
	}
	
	@When("^Verify title and content (.*) in Reassign Test pop-up$")
	public void Verify_title_message_Reassign_TestPopUp_button(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Reassign Test(s) pop-up");
		boolean flag=false;
		// Verify the Confirm pop up
		flag=CommonFunctions.VerifyConfirmPopupContent(Constants.MergeSelectStudentPopupTitle,confmessage);
		if (flag)
			UMReporter.log(Status.PASS, "Verified Reassign Test(s) pop-up title and message : " +confmessage);
			
	}
	
	@Then("^Click on Next button$")
	public void click_Next_button() throws Exception {
		UMReporter.log(Status.INFO, "When : Click on Next button");
		if (studentdetail.NextButton_isEnabled()) {
			studentdetail.clickNextButton();
		UMReporter.log(Status.PASS, "Selected the Next button");
		}
		else
			UMReporter.log(Status.SKIP, "Next option is not displayed");
	}
	
	@When("^User select (.*) Student from Student List in Reassign Test pop-up$")
	public void Select_Student_checkbox_Student_Session_Test_Reassign_TestPopUp(String stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : User select "+stucount+" Student from Student List in Reassign Test pop-up");
		int stucnt=1;
		if (studentdetail.Verify_ReassignTest_StudentList()) {
			if (CommonUtility.isNumeric(stucount))
				stucnt=Integer.parseInt(stucount);
			HashMap<String, String> mapSelectStud=studentdetail.SelectonStuCheckbox(stucnt);
		    if (mapSelectStud!=null) {
		    	UMReporter.log(Status.PASS, "Selected the Student : "+mapSelectStud);
		    }
		    else
		    	UMReporter.log(Status.SKIP, "The Student records are not found in list");
		}
		else
	    	UMReporter.log(Status.SKIP, "The Student list popup are not found after Reassign Test");
		
	}

	@When("^User select (.*) Test from Student Test List in Reassign Test pop-up$")
	public void Select_StudentTest_checkbox_Student_Session_Test_Reassign_TestPopUp(String stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : User select "+stucount+" Test from Student Test List in Reassign Test pop-up");
		int stucnt=1;
		if (studentdetail.Verify_ReassignTest_StudentTestList()) {
			if (CommonUtility.isNumeric(stucount))
				stucnt=Integer.parseInt(stucount);
    		List<HashMap<String, String>> lstSelectStudTest=studentdetail.SelectonStuTestSessionCheckbox(stucnt);
    		if (lstSelectStudTest.size()>0) {
    			UMReporter.log(Status.PASS, "Selected the Student Test : "+lstSelectStudTest);
    		}
    	}
		else
	    	UMReporter.log(Status.SKIP, "The Student Test list popup are not found after Reassign Test");
	}
	
	@When("^User Confirm and Reassign in Reassign Test pop-up$")
	public void Verify_ConfirmationWindow_Test_Reassign_TestPopUp() throws Exception {
		UMReporter.log(Status.INFO, "When : Verify Confirmation and select Reassign button in Reassign Test pop-up");
		if (studentdetail.Verify_ReassignTestWindow()) {
			boolean flag=CommonFunctions.VerifyDialogTitle("Confirm Test(s) Reassignment");
			if (flag) {
				String strMoveFrom = studentdetail.GetMoveFromConfirmReassignment();
				String strMoveTo = studentdetail.GetMoveToConfirmReassignment();
				flag=studentdetail.clickReassignButton();
				if (flag) {
					flag=studentlist.waitForProgressbarVisible(20);
					UMReporter.log(Status.PASS, "Verified Confirmation and selected Reassign "+strMoveFrom+" -> "+strMoveTo);
				}
				else
					UMReporter.log(Status.FAIL, "Reassign button is not found");
			}
			else
				UMReporter.log(Status.FAIL, "Confirmation popup not found");
		}
		else
	    	UMReporter.log(Status.SKIP, "The Student list popup are not found ");
	}
	
}