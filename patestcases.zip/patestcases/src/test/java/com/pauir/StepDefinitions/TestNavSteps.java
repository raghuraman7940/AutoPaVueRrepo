package com.pauir.StepDefinitions;


import java.io.IOException;
import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.TestNav.TestNavHome;
import com.pauir.PageDefinitions.TestNav.SignIn;
import com.pauir.PageDefinitions.sessions.SessionDetailPage;
import com.pauir.common.core.CommonFunctions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class TestNavSteps {
	public static SignIn testnavlogin;
	public static TestNavHome testnavhome;
	public static boolean LoggedinTestNavFlag=false;

	public TestNavSteps()throws IOException{
		
		//Initialize the Page object
		testnavlogin = new SignIn(WebDriverMain._getDriver());
		testnavhome= new TestNavHome();
	}
	
	
@Then("^Launch TestNav web and login with (.*) (.*) user$")
public void TestNav_Login_Setup(String user,String pwd) throws Exception {
		UMReporter.log(Status.INFO,"Given : Launch TestNav web and login with user : "+user+" - "+pwd);
		testnavlogin.NavigatetoTestNavURL();
		testnavlogin.doLogin(user,pwd);
		testnavhome.waitForProgressbarVisible(20);
		boolean flag=testnavhome.VerifyLoggedInUserIcon();
		if (flag) {
			System.out.println("TestNav logged in Success");	
			LoggedinTestNavFlag=true;
			UMReporter.log(Status.PASS,"Test Nav web logged in success with user: "+user+" : "+pwd);
		}
		else{
			String message=testnavlogin.getAlertMessage();
			System.out.println("TestNav logged failed with message : "+message);	
			UMReporter.log(Status.FAIL,"Test Nav login failed with message : "+message);
		}
}

@Then("^Verify the testNav web with (.*) student$")
public void TestNav_Verify_Login_HomePage(String name) throws Exception {
		UMReporter.log(Status.INFO,"Given : Verify the testNav web with student : "+name);
		if (LoggedinTestNavFlag) {
			boolean flag=testnavhome.VerifyWelcomeUser(name);
			if (flag) {
				UMReporter.log(Status.PASS,"The Student "+name+" is displayed in Testnav" );
			}
			else{
				UMReporter.log(Status.FAIL,"The Student "+name+" is not displayed in Testnav");
				
			}
		}
		 else 
			  UMReporter.log(Status.FAIL,"Testnav login failed");
}

@Then("^TestNav web to complete the test (.*) for (.*) student$")
public void TestNav_Login_Setup_Tocomplete(String test, String name) throws Exception {
		UMReporter.log(Status.INFO,"Then: TestNav web to complete the "+test+" test for student"+name);
		//Logged in TestNav Web Url
		if (LoggedinTestNavFlag) {
			boolean flag=testnavhome.VerifyLoggedInUserIcon();
			if (flag) {
				testnavhome.VerifyWelcomeUser(name);
				testnavhome.ClickSelect();
				testnavhome.VerifyTestName(test);
				testnavhome.ClickStart();
				testnavhome.ClickStartSection();
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.SelectEndReviewOptions();
				testnavhome.ClickSubmitFinalAnswers();
				testnavhome.ConfirmSubmitPopupActionBtn("Yes, Submit Final Answers");
				//testnavhome.ConfirmExitPopupActionBtn("Save and Return Later");
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.VerifyBackToSign();
				UMReporter.log(Status.PASS,"Test Nav to completed the test  "+test+" for student "+name);
			}
			else{
				String message=testnavlogin.getAlertMessage();
				UMReporter.log(Status.FAIL,"Test Nav login fail with message : "+message);
			}
		 }
		  else
			  
			  UMReporter.log(Status.FAIL,"Testnav login failed");
		
}

@Then("^TestNav web to exit the test (.*) for (.*) student$")
public void TestNav_Login_toexit_Test(String test, String name) throws Exception {
		UMReporter.log(Status.INFO,"TestNav web to exit the test "+test+" test for student"+name);
		System.out.println("Launch TestNav web and test attempt");
		boolean flag=false;
		  if ((LoggedinTestNavFlag)) {
			//Launch TestNav Web Url
			flag=testnavhome.VerifyLoggedInUserIcon();
			if (flag) {
				testnavhome.VerifyWelcomeUser(name);
				testnavhome.ClickSelect();
				testnavhome.VerifyTestName(test);
				testnavhome.ClickStart();
				testnavhome.ClickStartSection();
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.Logout();
				testnavhome.ConfirmExitPopupActionBtn("Save and Return Later");
				testnavhome.waitForProgressbarVisible(20);
				testnavhome.VerifyBackToSign();
				UMReporter.log(Status.PASS,"Test Nav to exited the test  "+test+" for student "+name);
			}
			else
			{
				String message=testnavlogin.getAlertMessage();
				UMReporter.log(Status.FAIL,"Test Nav login fail with message : "+message);
			}
		 }
		  else
			  UMReporter.log(Status.FAIL,"Test Nav login failed");
		
}



}
