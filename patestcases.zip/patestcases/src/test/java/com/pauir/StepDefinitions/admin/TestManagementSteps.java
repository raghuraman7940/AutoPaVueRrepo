
/**
 * Admin-Product Management Step Definition 
 */

package com.pauir.StepDefinitions.admin;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import com.aventstack.extentreports.Status;
import com.pauir.common.core.CommonFunctions;
import com.pauir.PageDefinitions.Admin.AdminHome;
import com.pauir.PageDefinitions.Admin.TestManagementPage;
import webdriver.main.UMReporter;

public class TestManagementSteps {
	
	//Initialize the class variable
	public static AdminHome adminhome;
	public static TestManagementPage formlist;
	public static CommonFunctions common;
	public TestManagementSteps()throws IOException{
		//Initialize the Page object
		adminhome=new AdminHome();
		formlist=new TestManagementPage();
	}
	
	@Given("^Switch to (.*) Tab in Test Management Page$")
	public void Click_TestMgMt_Tabs(String Tab) throws IOException  {
		UMReporter.log(Status.INFO, "Given : Switch to the Tab : "+Tab);
		//Verify the Form list page displayed
		boolean TabSelected=false;
		switch(Tab){
		case "Form":
			TabSelected=formlist.clickFormTab();
			break;
		case "TestAdmin":
			TabSelected=formlist.clickTestAdminTab();
			break;
			
		case "Tests":
			TabSelected=formlist.clickTestTab();
			break;
		}
		if(TabSelected)
			UMReporter.log(Status.PASS,"Selected the Tab : "+Tab);
	    else
	    	UMReporter.log(Status.FAIL,"Unable to Select Tab : "+Tab);
	}
	
	@Then("^Verify Form list page is displayed$")
	public void verify_whether_Form_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Form list page is displayed");
		//Verify the Form list page displayed
		if(formlist.IsFormListTableExist())
			UMReporter.log(Status.PASS,"User is navigated to Form list page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Then("^Verify TestAdmin list page is displayed$")
	public void verify_whether_TestAdmin_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify TestAdmin list page is displayed");
		//Verify the TestAdmin list page displayed
		if(formlist.IsTestAdminListTableExist())
			UMReporter.log(Status.PASS,"User is navigated to TestAdmin list page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Then("^Verify Tests list page is displayed$")
	public void verify_whether_Tests_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Tests list page is displayed");
		//Verify the Tests list page displayed
		if(formlist.IsTestListTableExist())
			UMReporter.log(Status.PASS,"User is navigated to Tests list page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Given("^Verify the (?:Form|TestAdmin|Tests) Table fields$")
	public void verify_Forms_Table_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When :Verify the Form Table fields");
		String Fieldname;
		List<String> NonVerified=null;
		List<String> MapDgOrgColHeader=formlist.getFormColumnHeaderDetails();
		if (MapDgOrgColHeader!=null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Form Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Form Table fields are verified :"+MapDgOrgColHeader);
	}
	
	@Given("^Verify the (?:Form|TestAdmin|Tests) Table fields fields are sortable$")
	public void verify_Form_Table_fields_Sortable(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"Then :Verify the Table fields fields are sortable");
		String Fieldname;
		List<String> NotVerified=null;
		List<String> MapDgColValues=null;
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NotVerified=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			MapDgColValues=formlist.verifyFormSearchresultsSorting(Fieldname);
			if (MapDgColValues==null) 
				NotVerified.add(Fieldname);
		}
		if (NotVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Table fields are not Sortable :"+NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Table fields are Sortable :"+list);
	}
	
	
	@Then("^User able to access the list of (?:Form|TestAdmin|Tests)$")
	public void verify_Form_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list ");
		List<String> MapDgOrgColHeader=formlist.verifyFormSearchresultsDetails(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following lists are accessed :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The records are not found in list");
	}
	
	@When("^User fill the (?:Form|TestAdmin|Tests) name search text (.*)$")
	public void Fill_Searchtext_Form_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User fill the search text : "+SeachText);
		 boolean flag=formlist.Searchfill_SearchText(SeachText);
		 if (flag)
			 UMReporter.log(Status.PASS, "Provided the Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to provide search text in input field");
	}
	
	@When("^User select the search icon in (?:Form|TestAdmin|Tests) list page$")
	public void Click_Searchicon_Session_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon in Form list page");
		boolean flag=formlist.clicksearchicon();
	    if (flag)
	    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
		 else
		    UMReporter.log(Status.FAIL, "Unable to select search icon");
	}
	
	@Then("^verify the (.*) search results in the (?:Form|TestAdmin|Tests) list$")
	public void Verify_Searchtext_in_Session_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the list : "+SeachText);
		 List<String> MapDgOrgDet=formlist.verifyFormSearchresultsDetailsfromtext(SeachText);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "The lists matches the SeachText :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The records are not found in list");
	
	}
	@Then("^Clear Search text field in (?:Form|TestAdmin|Tests) list page$")
	public void Clear_Searchtextfield_Class_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the Search text field");
		boolean flag=formlist.ClearSearchText();
		
	    if (flag) {
	    	flag=formlist.clicksearchicon();
	    	 UMReporter.log(Status.PASS, "Cleared the Search Text");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}
	
	@Then("^Select Home breadcrumb in (?:Form|TestAdmin|Tests) list page$")
	public void Select_Home_breadcrumb_organization_list() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Home> breadcrumb");
		formlist.clickHomeBreadCrum();
	    if (adminhome.VerifyLoggedinAdminHomePage()) {
	    	 UMReporter.log(Status.PASS, "Selected the Home breadcrumb");
	    }
		 else {
			 adminhome.MenuOtion("home", "");
			  if (adminhome.VerifyLoggedinAdminHomePage()) 
			    	 UMReporter.log(Status.PASS, "Selected the Home Navigation");
			  else
				  UMReporter.log(Status.FAIL, "Unable to select Home breadcrumb");
		 }
	}
	
	
}
