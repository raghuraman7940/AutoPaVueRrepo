package com.pauir.StepDefinitions;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.home.DrilldownPage;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.PageDefinitions.sessions.SessionDetailPage;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.testDataTypes.Userfield;
import com.pauir.common.util.CSV_Reader;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

public class DashboardSteps {

	public static Login login;
	public static Home home;
	public static SessionDetailPage sessiondetail;

	public static DrilldownPage drilldownpage;
	public static CSV_Reader csvfreader;
	public static CommonFunctions common;
	public static int iSelectedWidCount = 0;
	public static String sSelectedWidStatus = null;
	public static HashMap<String, String> MapUserEditedFields = null;
	public static Map<String, String> mapSelectedWid = null;
	public static Map<String, String> mapAppliedFilter = null;
	public static String sTitle = null;
	public static String sSubTitle = null;
	public static String sParentOrg = null;

	public DashboardSteps() throws IOException {

		// Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home = new Home();
		sessiondetail = new SessionDetailPage();
		drilldownpage = new DrilldownPage();
		csvfreader = new CSV_Reader();

	}

	@Given("^Verify a welcome message on the header - Welcome (.*)$")
	public void user_Verify_welcome_Message(String ExpMessage) throws IOException {
		UMReporter.log(Status.INFO, "Given :Verify a welcome message on the header - Welcome  " + ExpMessage);
		// Get the message
		String message = home.Func_GetWelcomeMessage();
		message = message.trim().toString();
		String strArrObjLocs[] = CommonUtility._split(ExpMessage, ",");
		if (strArrObjLocs.length >= 2) {
			ExpMessage = strArrObjLocs[0].trim();
		}
		if ((message.equalsIgnoreCase(ExpMessage)) || (message.contains(ExpMessage)))
			UMReporter.log(Status.PASS, "The Welcome message matched with expected :  " + ExpMessage);
		else
			UMReporter.log(Status.FAIL, "The Welcome message not matched with expected : " + ExpMessage);
	}

	@Given("^Verify a text below welcome message on the header - (.*)$")
	public void user_Verify_welcome_Message_Next_Text(String ExpMessage) throws IOException {

		UMReporter.log(Status.INFO, "Given :Verify a text below welcome message on the header - " + ExpMessage);
		// Get the message
		String message = home.Func_GetRole();
		String custName = home.Func_GetCurrentCusName();
		message = message + " " + custName;
		message = message.trim().toString();
		if ((message.equalsIgnoreCase(ExpMessage)) || (message.contains(ExpMessage)))
			UMReporter.log(Status.PASS, "The Logged message matched with expected :  " + ExpMessage);
		else
			UMReporter.log(Status.FAIL, "The Logged message not matched with expected : " + ExpMessage);
	}

	@Given("^User must be allowed to expand the project dropdown to view a list of projects$")
	public void user_Expand_Project_Dropdown() throws IOException {
		UMReporter.log(Status.INFO,
				"Given : User must be allowed to expand the project dropdown to view a list of projects");
		// Get the message
		List<String> act_options = home.Func_CustomerDropdownList();
		if (act_options != null)
			UMReporter.log(Status.PASS, "The project dropdown displayed a list of projects :  " + act_options);
		else
			UMReporter.log(Status.PASS, "The project dropdown displayed as read only  ");
	}

	@Given("^Verify the customer logo above the header area as (.*)$")
	public void user_CustomerLogo_Image(String complogo) throws IOException {
		UMReporter.log(Status.INFO, "Given : Verify the customer logo above the header area as " + complogo);
		// Get the message
		String ImgSrc = home.GetCustomerLogoSrc();
		if (ImgSrc.contains(complogo))
			UMReporter.log(Status.PASS, "The Customer logo image is matched :  " + complogo);
		else
			UMReporter.log(Status.FAIL, "The Customer logo image is matched : " + ImgSrc);
	}

	@Given("^User selects the Profile icon the displaying of the MyAccount and Logout links$")
	public void user_Verify_Profile_options() throws IOException {
		UMReporter.log(Status.INFO,
				"When: User selects the Profile icon the displaying of the MyAccount and Logout links");
		// Get the message
		home.SelectProfileIconOptions();
		List<String> ProfOpts = home.GetProfileIconOptions();
		if ((ProfOpts.contains(Constants.MyAccountTitle)) && (ProfOpts.contains(Constants.LogoutTitle)))
			UMReporter.log(Status.PASS, "The MyAccount and Logout links are displayed");
		else
			UMReporter.log(Status.FAIL, "The MyAccount and Logout links are not displayed");
		home.CloseProfileIconOptions();
	}

	@Given("^User Select the MyAccount option invokes the Account Details screen$")
	public void user_Select_MyAccount_Profile_options() throws IOException {
		UMReporter.log(Status.INFO, "When :User Select the MyAccount option invokes the Account Details screen");
		// Get the message
		boolean flag = home.MyAccount();
		if (flag) {
			flag = home.VerifyMyccountDialog();
			if (flag)
				UMReporter.log(Status.PASS, "The Account Details screen displayed ");
			else
				UMReporter.log(Status.FAIL, "The Account Details screen not displayed  ");
		} else
			UMReporter.log(Status.FAIL, "The My Account options not exist in Profile options ");
	}

	@Given("^Verify the user association to Organizations and Roles in Account Details screen$")
	public void user_Verify_Org_Roles_fields_present_AccountDetScreenPage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,
				"When : Verify the user association to Organizations and Roles in Account Details screen");
		String Org, Role;
		List<String> NonVerified = null;
		List<String> VerifiedField = null;
		if (home.VerifyMyccountDialog()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			List<String> lstOrgRoles = home.Func_GetOrgNRoles();
			for (int i = 0; i < list.size(); i++) {
				Org = list.get(i).get("Organizations").toUpperCase();
				Role = list.get(i).get("Roles").toUpperCase();
//			System.out.println("FieldValue:" + Org+" => "+Role);
//			System.out.println("lstOrgRoles:" + lstOrgRoles);
//			System.out.println("lstOrgRoles Org:" + lstOrgRoles.contains(Org));
//			System.out.println("lstOrgRoles Role:" + lstOrgRoles.contains(Role));
				if ((lstOrgRoles.contains(Org)) && (lstOrgRoles.contains(Role)))
					VerifiedField.add(Org + " - " + Role);
				else
					NonVerified.add(Org + " - " + Role);

			}
			if (NonVerified.size() > 0)
				UMReporter.log(Status.PASS,
						"The user association verified the Organizations and Roles   :" + NonVerified);
			else
				UMReporter.log(Status.FAIL,
						"The user association not verified the Organizations and Roles are :" + VerifiedField);
		} else
			UMReporter.log(Status.FAIL, "The Account Details screen is not displayed ");
	}

	@Given("^Verify the user account Details displayes in Details Section$")
	public void verify_User_info_fields(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify the user account Details displayes in Details Section");
		String Fieldname, FieldValue;
		List<String> NonVerified = null;
		List<String> VerifiedField = null;
		if (home.CloseButton_isVisible()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			VerifiedField = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				System.out.println("Fieldname:" + Fieldname);
				if (!home.verifyUserLabel(Fieldname))
					NonVerified.add(Fieldname);
				else {
					FieldValue = home.GetValueforUserLabel(Fieldname);
					VerifiedField.add(Fieldname + " = " + FieldValue);
				}
			}
			if (NonVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following expected user account Details  are not exist in frontend :" + NonVerified);
			else
				UMReporter.log(Status.PASS,
						"The following user account Details with values are verified :" + VerifiedField);
		} else
			UMReporter.log(Status.FAIL, "The user account section not displayed");
	}

	@Given("^User selects the Details tab in Account Details screen$")
	public void user_Select_NameActivity_options() throws IOException {
		UMReporter.log(Status.INFO, "When: User selects the Details tab in Account Details screen");
		// Get the message
		boolean flag = home.SelectMyAccountTabOption("nameactivity");
		if (flag)
			UMReporter.log(Status.PASS, "Selected the Details tab");
		else
			UMReporter.log(Status.FAIL, "The Details tab not selected");
	}

	@Given("^User selects the Password Reset tab in Account Details screen$")
	public void user_Select_Passwordreset_options() throws IOException {
		UMReporter.log(Status.INFO, "When: User selects the Password Reset tab in Account Details screen");
		// Get the message
		boolean flag = home.SelectMyAccountTabOption("passwordreset");
		if (flag)
			UMReporter.log(Status.PASS, "Selected the Password Reset tab");
		else
			UMReporter.log(Status.FAIL, "The Password Reset tab not selected");
	}

	@Given("^Verify the Password fields displayes in Password Reset Section$")
	public void verify_Password_info_fields(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify the Password fields displayes in Password Reset Section");
		String Fieldname, FieldValue;
		List<String> NonVerified = null;
		List<String> VerifiedField = null;
		if (home.EditButton_isVisible()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			VerifiedField = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				System.out.println("Fieldname:" + Fieldname);
				if (!home.verifyUserLabel(Fieldname))
					NonVerified.add(Fieldname);
				else {
					FieldValue = home.GetValueforUserLabel(Fieldname);
					VerifiedField.add(Fieldname + " = " + FieldValue);
				}
			}
			if (NonVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following expected Password Reset Details  are not exist in frontend :" + NonVerified);
			else
				UMReporter.log(Status.PASS,
						"The following Password Reset Details with values are verified :" + VerifiedField);
		} else
			UMReporter.log(Status.FAIL, "The Password Reset section not displayed");
	}

	@Given("^Verify the Cancel button in Account Details screen$")
	public void user_Verify_Cancel_options_AccountDetailsScreen() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify the Cancel button in Account Details screen");
		boolean flag = home.CanceltButton_isVisible();
		if (flag)
			UMReporter.log(Status.PASS, "The Cancel button is visible");
		else
			UMReporter.log(Status.FAIL, "The Cancel button not exist");
	}

	@Given("^Verify the Edit button visible and enabled in Account Details screen$")
	public void user_Verify_Edit_options_AccountDetailsScreen() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify the Edit button visible and enabled in Account Details screen");
		boolean flag = home.EditButton_isVisible();
		if (flag) {

			boolean flagenabled = home.EditButton_isEnabled();
			if (flagenabled)
				UMReporter.log(Status.PASS, "The Edit button is visible and enabled");
			else
				UMReporter.log(Status.FAIL, "The Edit button is visible and disabled");
		} else
			UMReporter.log(Status.FAIL, "The Edit button not exist");
	}

	@Given("^Click on Cancel in Account Details screen$")
	public void user_Select_Cancel_in_AccountDetailsScreen() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Cancel in Account Details screen");
		boolean flag = home.clickCancelButton();
		if (flag)
			UMReporter.log(Status.PASS, "Selected the Cancel button");
		else
			UMReporter.log(Status.FAIL, "Unable to select Cancel");
	}

	@Given("^User is able to cancel/close the Account Details screen$")
	public void user_Select_Close_options_AccountDetailsScreen() throws Exception {
		UMReporter.log(Status.INFO, "When: User is able to cancel/close the Account Details screen");
		boolean flag = home.clickCloseButton();
		if (flag) {
			if (home.CloseButton_isVisible())
				flag = home.clickCloseButton();
			UMReporter.log(Status.PASS, "Selected the Cancel/Close");
		} else
			UMReporter.log(Status.FAIL, "Unable to select Cancel/Close");
	}

	@When("^Click on Edit button in Account Details screen$")
	public void Click_Edit_button_in_AccountDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Edit button in Account Details screen");
		boolean isbtnclicked = home.clickEditButton();
		if (isbtnclicked)
			UMReporter.log(Status.PASS, "Edit button is click");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Edit button");

	}

	@Given("^User edit the user account Details displayes in Details Section$")
	public void user_edit_provided_fields_present_Details_Section(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO, "When : User edit the user account Details displayes in Details Section");
		String Fieldname, FieldValue, FilledFieldValue = null;
		List<String> NonVerified = null;
		// Get fields from Configuration json file
		List<Userfield> fields = FileReaderManager.getInstance().getJsonReader()
				.getUserfieldsbyState(Constants.ORG_STATE);
		if (fields != null) {
			if (home.SaveButton_isVisible()) {
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified = new ArrayList<String>();
				MapUserEditedFields = new HashMap<String, String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					System.out.println("FieldValue:" + Fieldname + " => " + FieldValue);

					Userfield field = FileReaderManager.getInstance().getJsonReader().getUserfieldbyLabel(fields,
							Fieldname);
					if (field != null) {
						FilledFieldValue = home.FillUserField(field, FieldValue);
						if (FilledFieldValue == null)
							NonVerified.add(Fieldname);
						else
							MapUserEditedFields.put(Fieldname, FilledFieldValue);
					}
				}
				if (NonVerified.size() > 0)
					UMReporter.log(Status.FAIL,
							"The following user fields are unable to edit the input value :" + NonVerified);
				else
					UMReporter.log(Status.PASS,
							"The following user fields edited the input values :" + MapUserEditedFields);

			} else
				UMReporter.log(Status.FAIL, "The input form fields are not displayed in class user page ");
		}

	}

	@When("^Click on Save button in Account Details screen$")
	public void Click_Save_button_in_UserDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Save button in Account Details screen");
		boolean isbtnclicked = home.clickSaveButton();
		if (isbtnclicked)
			UMReporter.log(Status.PASS, "Save button is click");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Save button");

	}

	@Then("^Verify the success message displayed in Account Details screen$")
	public void verify_success_message_gets_displayed_on_Account_Detailsscreen_page() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Account Details screen");
		boolean flag;
		flag = home.verifySuccessMessage("Success");
		if (flag) {
			UMReporter.log(Status.PASS, "Verified the success message displayed in Account Details screen");

		} else {
			UMReporter.log(Status.FAIL, "The success message is not displayed :");
		}

		home.Close_Alerts();
	}

	@Then("^Verify the edited Account information in Account Details screen$")
	public void verify_edited_User_details_is_displayed_in_AccountDetails_screen() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the edited User information in User details page");
		if (MapUserEditedFields != null) {
			// Verify the Student Detail page displayed
			if (home.EditButton_isVisible())
				// Verify the Session details page displayed
				home.verifyViewUserDetails(MapUserEditedFields);
			else
				UMReporter.log(Status.FAIL, "User details page is not displayed");

		} else
			UMReporter.log(Status.FAIL, "User details are not found");
	}

	@Given("^User Select Administration (.*) and Grade (.*) in Students Registered widget in Dashboard Page$")
	public void Select_Students_Registered_Widget_Admin_Grade_page(String Admin, String Grade) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User Select Administration and Grade in Students Registered widget in Dashboard Page");
		// Select Admin
		CommonUtility._sleepForGivenTime(2000);
		sParentOrg = null;
		sTitle = null;
		sSubTitle = null;

		if (Admin.indexOf("$") >= 0)
			Admin = CommonFunctions.getTestData(Admin);

		if (Grade.indexOf("$") >= 0)
			Grade = CommonFunctions.getTestData(Grade);

		CommonUtility._scrollup();
		boolean Adminflag = home.SelectWidgetAdministration("Students Registered", Admin);
		boolean Gradeflag = home.SelectWidgetGrade("Students Registered", Grade);
		CommonUtility._sleepForGivenTime(5000);
		if ((Adminflag) && (Gradeflag)) {
			UMReporter.log(Status.PASS, " Selected Administration => " + Admin + " ,  Grade => " + Grade);
			if (Grade.contains("All"))
				Grade = "All";
			sSubTitle = "Administration: " + Admin + ", Grade: " + Grade;
		} else
			UMReporter.log(Status.FAIL, "Unable to select Administration and Grade");
	}

	@Given("^Verify the Subject wise count of Students Registered widget in Dashboard Page$")
	public void Verify_Dashboard_Students_Registered_Widget_page() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Subject wise count of Students Registered widget in Dashboard Page");
		// Get widget content
		List<Map<String, String>> lstWidCards = home.GetArcWidgetContent("Students Registered");
		if (lstWidCards != null)
			UMReporter.log(Status.PASS, "The Subject wise registered and not registered count : " + lstWidCards);
		else
			UMReporter.log(Status.FAIL, "Students Registered Widget no data to display");
	}

	@Given("^User Select (.*) count in Students Registered widget in Dashboard Page$")
	public void Select_Dashboard_Students_Registered_Widget_Count_page(String SelectStatus) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User Select " + SelectStatus + " count in Students Registered widget in Dashboard Page");
		String Subject, Selectcnt;
		// Select widget count
		mapSelectedWid = home.SelectArcWidgetContent("Students Registered", SelectStatus);
		if (mapSelectedWid != null) {
			Subject = mapSelectedWid.get("subject");
			Selectcnt = mapSelectedWid.get(SelectStatus);
			sSelectedWidStatus = SelectStatus;
			if (CommonUtility.isNumeric(Selectcnt))
				iSelectedWidCount = Integer.parseInt(Selectcnt);
			UMReporter.log(Status.PASS, "Selected the " + iSelectedWidCount + " " + SelectStatus + " student count of "
					+ Subject + " in Students Registered widget  ");
		} else
			UMReporter.log(Status.FAIL, "Unable to Select " + SelectStatus + " count in Students Registered Widget");
	}

	@Then("^Verify (.*) level drilldown page$")
	public void verify_Page_of_Student_Counts_in_Drilldown_page(String OrgType) throws IOException {
		if (OrgType.indexOf("^") >= 0)
			OrgType = Constants.mapCustomLabels.get(OrgType.substring(1));
		UMReporter.log(Status.INFO, "Then : Verify " + OrgType + " level drilldown page ");
		if (iSelectedWidCount != 0) {
			// Verify the Stu list page displayed
			if (drilldownpage.verifyPageNavigation(OrgType))
				UMReporter.log(Status.PASS, "Navigated to level of drilldown page : " + OrgType);
			else
				UMReporter.log(Status.FAIL, "Unable to navigate the drilldown page");
		} else
			UMReporter.log(Status.PASS, "Unable to navigate the drilldown page");

	}

	@Then("^Verify the title as (.*) that have student tests in (.*) status in Organization in Drilldown page$")
	public void verify_Pagetitle_of_SessionOverview_Drilldown_page(String OrgType, String SelectStatus)
			throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the title as " + OrgType + " that have student tests in "
				+ SelectStatus + " status in Organization in Drilldown page ");
		if (iSelectedWidCount != 0) {
			if (sParentOrg == null)
				sParentOrg = home.Func_GetPinnedOrgName();

			if (SelectStatus.equalsIgnoreCase("Total Tests")) {
				sTitle = "Student Tests by " + OrgType + " in " + sParentOrg;
				if (OrgType.equalsIgnoreCase("Student Tests"))
					sTitle = "Student Tests in " + sParentOrg;
			} else {
				sTitle = OrgType + " that have student tests in " + SelectStatus + " status in " + sParentOrg;
				if (OrgType.equalsIgnoreCase("Student Tests"))
					sTitle = "Student Tests in " + SelectStatus + " status in " + sParentOrg;
			}

			// Verify the Stu list page displayed
			if (drilldownpage.verifyPageNavigation(sTitle))
				UMReporter.log(Status.PASS, "Verified the title of drilldown page : " + sTitle);
			else
				UMReporter.log(Status.FAIL, "Not verified the drilldown title : " + sTitle);
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Then("^Verify the sub title of selected Administration and Session filter in Drilldown page$")
	public void verify_Page_Subtitle_of_SeesionOverview_Drilldown_page() throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the sub title of selected Administration and Session filter in Drilldown page");
		if (iSelectedWidCount != 0) {
			if (sSubTitle != null) {
				// Verify the Stu list page displayedsd
				if (drilldownpage.verifyPageSubtitle(sSubTitle))
					UMReporter.log(Status.PASS, "Verified the sub title of drilldown page : " + sSubTitle);
				else
					UMReporter.log(Status.FAIL, "Not verified the drilldown sub title : " + sSubTitle);
			} else
				UMReporter.log(Status.FAIL, "The drilldown sub title not found ");
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Then("^Verify the sub title of selected Administration and Grade filter in Drilldown page$")
	public void verify_Page_Subtitle_of_Drilldown_page() throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the sub title of selected Administration and Grade filter in Drilldown page");
		if (iSelectedWidCount != 0) {
			if (sSubTitle != null) {
				// Verify the Stu list page displayedsd
				if (drilldownpage.verifyPageSubtitle(sSubTitle))
					UMReporter.log(Status.PASS, "Verified the sub title of drilldown page : " + sSubTitle);
				else
					UMReporter.log(Status.FAIL, "Not verified the drilldown sub title : " + sSubTitle);
			} else
				UMReporter.log(Status.FAIL, "The drilldown sub title not found ");
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Then("^Verify the title (.*) (.*) for selected subject in organization in Drilldown page$")
	public void verify_Pagetitle_of_Drilldown_page(String OrgType, String SelectStatus) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the title for selected subject in organization in Drilldown page"
				+ OrgType + " - " + SelectStatus);
		if (iSelectedWidCount != 0) {
			sTitle = OrgType + " " + SelectStatus;
			if (mapAppliedFilter != null) {
				String Subject = mapAppliedFilter.get("subject");
				if (sParentOrg == null)
					sParentOrg = home.Func_GetPinnedOrgName();
				sTitle = OrgType + " " + SelectStatus + " for " + Subject + " in " + sParentOrg;
			}
			// Verify the Stu list page displayed
			if (drilldownpage.verifyPageNavigation(sTitle))
				UMReporter.log(Status.PASS, "Verified the title of drilldown page : " + sTitle);
			else
				UMReporter.log(Status.FAIL, "Not verified the drilldown title : " + sTitle);
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Given("^Verify the Student count Table fields in Drilldown page$")
	public void verify_Students_Table_fields_DrilldownTable(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the Student count Table fields in Drilldown page");
		String Fieldname;
		List<String> NonVerified = null;
		boolean flag = true;
		if (iSelectedWidCount != 0) {
			List<String> MapDgStuColHeader = drilldownpage.getStuColumnHeaderDetails();
			if (MapDgStuColHeader.size() > 0) {
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified = new ArrayList<String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("TableFields");
					if (Fieldname.indexOf("^") >= 0)
						Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
					System.out.println("Fieldname:" + Fieldname);
					if (!MapDgStuColHeader.contains(Fieldname))
						NonVerified.add(Fieldname);
				}
			}
			if (NonVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following expected Students Drilldown Table fields are not exist in frontend :"
								+ NonVerified);
			else
				UMReporter.log(Status.PASS,
						"The following Students Drilldown Table fields are verified :" + MapDgStuColHeader);
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");

	}

	@Given("^Verify the Student count Table fields fields are sortable in Drilldown page$")
	public void verify_Student_Table_fields_Sortable_Drilldown_page(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,
				"When :Verify the Student count Table fields fields are sortable in Drilldown page");
		String Fieldname;
		List<String> NotVerified = null;
		List<String> MapDgColValues = null;
		if (iSelectedWidCount != 0) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NotVerified = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^") >= 0)
					Fieldname = Constants.mapCustomLabels.get(Fieldname.substring(1));
				MapDgColValues = drilldownpage.verifyStudentSearchresultsSorting(Fieldname);
				if (MapDgColValues != null)
					if (MapDgColValues.size() < 1)
						NotVerified.add(Fieldname);
			}
			if (NotVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following expected Session Student Table fields are not Sortable :" + NotVerified);
			else
				UMReporter.log(Status.PASS, "The following Session Student Table fields are Sortable :" + list);
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Then("^Verify the Student count and Schools for Disticts wise in Drilldown page$")
	public void verify_Students_list_by_DistrictWise_in_Drilldown_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Student count and Schools for Disticts wise in Drilldown page");
		if (iSelectedWidCount != 0) {
			List<String> MapDgStuColHeader = drilldownpage.verifyStusearchresultsDetails(3);
			if (MapDgStuColHeader != null)
				UMReporter.log(Status.PASS, "The following Schools and " + sSelectedWidStatus
						+ " Student count are displayed in Drilldown page :" + MapDgStuColHeader);
			else
				UMReporter.log(Status.FAIL, "The Drilldown students are not found in list");
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Then("^Verify the Selected Student count displays in (?:Schools|Districts) list in Drilldown page$")
	public void verify_StudentsCount_list_by_DistrictWise_in_Drilldown_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Selected Student count in Drilldown page");
		int DrillStudCount = 0;
		int FsDrillStudCount;
		if (iSelectedWidCount != 0) {
			List<String> MapDgStuColHeader = drilldownpage.verifyStudentSearchresultsbyCol("Students");
			if (MapDgStuColHeader != null) {
				for (String Studcnt : MapDgStuColHeader) {
					FsDrillStudCount = 0;
					if (CommonUtility.isNumeric(Studcnt))
						FsDrillStudCount = Integer.parseInt(Studcnt);

					DrillStudCount = DrillStudCount + FsDrillStudCount;
				}
				
				
				if (DrillStudCount == iSelectedWidCount)
					UMReporter.log(Status.PASS, "The Selected " + sSelectedWidStatus
							+ " Student count matched with Drilldown Student Count :" + iSelectedWidCount);
				else {
					int diffvalue = 0;
					if (DrillStudCount > iSelectedWidCount)
						diffvalue = DrillStudCount - iSelectedWidCount;
					else
						diffvalue = iSelectedWidCount - DrillStudCount;

					if (diffvalue > 10)
						UMReporter.log(Status.FAIL, "The Selected " + sSelectedWidStatus + " Student count "
								+ iSelectedWidCount + " not matched with Drilldown Student Count " + DrillStudCount);
					else
						UMReporter.log(Status.SKIP, "The Selected " + sSelectedWidStatus + " Student count "
							+ iSelectedWidCount + " not matched with Drilldown Student Count " + DrillStudCount);
				}
			} else
				UMReporter.log(Status.PASS, "Unable to navigate the drilldown page");
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Then("^Verify the Student count by School wise in Drilldown page$")
	public void verify_Students_list_is_access_in_Drilldown_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Student count by School wise in Drilldown page");
		if (iSelectedWidCount != 0) {
			List<String> MapDgStuColHeader = drilldownpage.verifyStusearchresultsDetails(3);
			if (MapDgStuColHeader != null)
				UMReporter.log(Status.PASS, "The following School wise " + sSelectedWidStatus
						+ " Students Count are displayed in Drilldown Page :" + MapDgStuColHeader);
			else
				UMReporter.log(Status.FAIL, "The Students Count are not found in list");
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@When("^User select the School count for District in Drilldown page$")
	public void user_clicks_on_First_Count_In_Drilldown() throws Exception {
		UMReporter.log(Status.INFO, "When :User select the School count for District in Drilldown page");
		boolean flag = false;
		HashMap<String, String> MapSelectDrillCount = null;
		if (iSelectedWidCount != 0) {
			// Get Drilldown Search results by row number
			MapSelectDrillCount = drilldownpage.getStudsearchresultsDetails(3);
			if (MapSelectDrillCount != null) {
				if (MapSelectDrillCount.containsKey("Schools")) {
					String SchCnt = MapSelectDrillCount.get("Schools");
					// Click on Count hyperlink on Drilldown page
					flag = drilldownpage.clickonSchCount(SchCnt);
					// Check the Sch Count
					if (flag) {

						String DistFieldname = Constants.mapCustomLabels.get(Constants.DDDistricts);
						CommonUtility._sleepForGivenTime(1000);
						sParentOrg = MapSelectDrillCount.get(DistFieldname);
						if (MapSelectDrillCount.containsKey("Students")) {
							String StudCnt = MapSelectDrillCount.get("Students");
							if (CommonUtility.isNumeric(StudCnt))
								iSelectedWidCount = Integer.parseInt(StudCnt);
						}
						UMReporter.log(Status.PASS, "Selected the School Count " + SchCnt
								+ " hyperlink for the District " + sParentOrg + " in Drilldown Page");
					} else
						UMReporter.log(Status.FAIL, "The School Count " + SchCnt + "  not found in Drilldown page");
				}
			} else
				UMReporter.log(Status.FAIL, "No records found in Drilldown Table");
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");

	}

	@When("^User select the Student count for District in Drilldown page$")
	public void user_clicks_on_First_StudentCount_In_Distirct_Drilldown() throws Exception {
		UMReporter.log(Status.INFO, "When :User select the Student count for District in Drilldown page");
		boolean flag = false;
		HashMap<String, String> MapSelectDrillCount = null;
		if (iSelectedWidCount != 0) {
			// Get Drilldown Search results by row number
			MapSelectDrillCount = drilldownpage.getStudsearchresultsDetails(1);
			if (MapSelectDrillCount != null) {
				if (MapSelectDrillCount.containsKey("Students")) {
					String StudCnt = MapSelectDrillCount.get("Students");
					// Click on Count hyperlink on Drilldown page
					flag = drilldownpage.clickonSchCount(StudCnt);
					// Check the Sch Count
					if (flag) {
						CommonUtility._sleepForGivenTime(2000);
						String DistFieldname = Constants.mapCustomLabels.get(Constants.DDDistricts);
						CommonUtility._sleepForGivenTime(1000);
						sParentOrg = MapSelectDrillCount.get(DistFieldname);
						if (CommonUtility.isNumeric(StudCnt))
							iSelectedWidCount = Integer.parseInt(StudCnt);
						UMReporter.log(Status.PASS,
								"Selected the " + sSelectedWidStatus + " Student Count " + StudCnt
										+ " hyperlink for the District " + MapSelectDrillCount.get("Districts")
										+ " in Drilldown Page");
					} else
						UMReporter.log(Status.FAIL, "The " + sSelectedWidStatus + " Student Count " + StudCnt
								+ "  not found in Drilldown page");
				}
			} else
				UMReporter.log(Status.FAIL, "No records found in Session list");
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");

	}

	@When("^User select the Student count for School in Drilldown page$")
	public void user_clicks_on_First_StudentCount_In_Drilldown() throws Exception {
		UMReporter.log(Status.INFO, "When :User select the Student count for School in Drilldown page");
		boolean flag = false;
		HashMap<String, String> MapSelectDrillCount = null;
		if (iSelectedWidCount != 0) {
			// Get Drilldown Search results by row number
			MapSelectDrillCount = drilldownpage.getStudsearchresultsDetails(3);
			if (MapSelectDrillCount != null) {
				if (MapSelectDrillCount.containsKey("Students")) {
					String StudCnt = MapSelectDrillCount.get("Students");
					// Click on Count hyperlink on Drilldown page
					flag = drilldownpage.clickonSchCount(StudCnt);
					// Check the Sch Count
					if (flag) {
						sParentOrg = MapSelectDrillCount.get("Schools");
						CommonUtility._sleepForGivenTime(2000);
						if (CommonUtility.isNumeric(StudCnt))
							iSelectedWidCount = Integer.parseInt(StudCnt);
						UMReporter.log(Status.PASS,
								"Selected the " + sSelectedWidStatus + " Student Count " + StudCnt
										+ " hyperlink for the school " + MapSelectDrillCount.get("Schools")
										+ " in Drilldown Page");
					} else
						UMReporter.log(Status.FAIL, "The " + sSelectedWidStatus + " Student Count " + StudCnt
								+ "  not found in Drilldown page");
				}
			} else
				UMReporter.log(Status.FAIL, "No records found in Session list");
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");

	}

	@Then("^Verify the pagination in Student datagrid in Drilldown page$")
	public void Verify_student_list_Paginations_Drilldownpage() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the pagination in Student datagrid in Drilldown page");
		int maxpage = drilldownpage.verifyStuGridPagination();
		if (maxpage > 1)
			UMReporter.log(Status.PASS, "The students lists pagination are upto max pages :" + maxpage);
		else if (maxpage == 1)
			UMReporter.log(Status.PASS, "The students list contains one page only.");
		else
			UMReporter.log(Status.FAIL, "The students list pagination fails.");
	}

	@When("^User search the student (.*) in Drilldown page$")
	public void Fill_Searchtext_student_list_Drilldownpage(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search the student in Drilldown page : " + SeachText);
		boolean flag = drilldownpage.Searchfill_StudName(SeachText);
		if (flag)
			UMReporter.log(Status.PASS, "The Search text :" + SeachText);
		else
			UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}

	@When("^User select the search icon in Drilldown page$")
	public void Click_Searchicon_student_list_Drilldown() throws Exception {
		UMReporter.log(Status.INFO, "When : User select the search icon in Drilldown page");
		boolean flag = drilldownpage.clicksearchicon();
		if (flag)
			UMReporter.log(Status.PASS, "Clicked the Search Icon");
		else
			UMReporter.log(Status.FAIL, "Unable to select search icon");
	}

	@Then("^verify the (.*) search Student results in Drilldown page$")
	public void Verify_Searchtext_in_student_list_Drilldown(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search Student results in Drilldown page : " + SeachText);
		List<String> MapDgOrgDet = drilldownpage.verifyStudSearchresultsDetailsfromtext(SeachText);
		if (MapDgOrgDet != null)
			UMReporter.log(Status.PASS, "The Student lists matches the SeachText :" + MapDgOrgDet);
		else
			UMReporter.log(Status.FAIL, "The Students are not found in list");

	}

	@Then("^Clear Search text field in Drilldown page$")
	public void Clear_Searchtextfield_student_list_AddStudentsto_Session() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear Search text field in Drilldown page");
		boolean flag = drilldownpage.ClearSearchText();
		if (flag) {
			flag = drilldownpage.clicksearchicon();
			UMReporter.log(Status.PASS, "Cleared the Search Text");
		} else
			UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}

	@When("^Verify the student count displays in Student list in Drilldown page$")
	public void Verify_Selected_StuCount_Drilldown_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the student count displays in Student list in Drilldown page");
		int actual = 0;
		if (iSelectedWidCount != 0) {
			actual = drilldownpage.verifyStuCountGridPagination(iSelectedWidCount);
			if (actual != iSelectedWidCount) {
				int diffvalue = 0;
				if (actual > iSelectedWidCount)
					diffvalue = actual - iSelectedWidCount;
				else
					diffvalue = iSelectedWidCount - actual;

				if (diffvalue > 20)
					UMReporter.log(Status.FAIL, "The selected " + iSelectedWidCount + " " + sSelectedWidStatus
							+ "student count mistached the actual drilldown " + actual);
				else
					UMReporter.log(Status.SKIP, "The selected " + iSelectedWidCount + " " + sSelectedWidStatus
							+ "student count mistached the actual drilldown " + actual);
			} else
				UMReporter.log(Status.PASS, "The selected " + sSelectedWidStatus
						+ " Student count matches the drilldown count :" + iSelectedWidCount);

		} else
			UMReporter.log(Status.PASS, "Unable to navigate the drilldown page");
	}

	@Then("^Select District breadcrumb in Drilldown page$")
	public void Select_District_breadcrumb_Drilldown_Page() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select < District breadcrumb in Drilldown page");
		String DistLabel= Constants.mapCustomLabels.get("label.organizationtype.district");
		boolean flag = drilldownpage.verifyBreadcrumb(DistLabel);
		if (flag) {
			flag = drilldownpage.clickBreadcrumb();
			if (flag)
				UMReporter.log(Status.PASS, "Selected the < "+DistLabel+" breadcrumb");
			else
				UMReporter.log(Status.FAIL, "Unable to select < "+DistLabel+" breadcrumb");
		} else
			UMReporter.log(Status.FAIL, "Unable to locate < "+DistLabel+" breadcrumb");
	}

	@Then("^Select State breadcrumb in Drilldown page$")
	public void Select_State_breadcrumb_Drilldown_Page() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select < State breadcrumb in Drilldown page");
		String StateLabel= Constants.mapCustomLabels.get("label.organizationtype.state");
		boolean flag = drilldownpage.verifyBreadcrumb(StateLabel);
		if (flag) {
			flag = drilldownpage.clickBreadcrumb();
			if (flag)
				UMReporter.log(Status.PASS, "Selected the < "+StateLabel+" breadcrumb");
			else
				UMReporter.log(Status.FAIL, "Unable to select < "+StateLabel+" breadcrumb");
		} else
			UMReporter.log(Status.FAIL, "Unable to locate < "+StateLabel+" breadcrumb");
	}

	@Then("^Select Home breadcrumb in Drilldown page$")
	public void Select_Home_breadcrumb_Drilldown_Page() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select < Home breadcrumb in Drilldown page");
		boolean flag = drilldownpage.verifyBreadcrumb("Home");
		if (flag) {
			flag = drilldownpage.clickBreadcrumb();
			if (flag)
				UMReporter.log(Status.PASS, "Selected the < Home breadcrumb");
			else
				UMReporter.log(Status.FAIL, "Unable to select < Home breadcrumb");
		} else
			UMReporter.log(Status.FAIL, "Unable to locate < Home breadcrumb");
	}

	@Given("^User Select Administration (.*) and Grade (.*) in Student Tests Completed widget in Dashboard Page$")
	public void Select_Widget_Admin_Grade_page_In_StudentTestCompletion(String Admin, String Grade) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User Select Administration and Grade in Student Tests Completed in Dashboard Page");
		// Select Admin
		sParentOrg = null;
		sTitle = null;
		sSubTitle = null;
		CommonUtility._sleepForGivenTime(2000);

		if (Admin.indexOf("$") >= 0)
			Admin = CommonFunctions.getTestData(Admin);
		if (Grade.indexOf("$") >= 0)
			Grade = CommonFunctions.getTestData(Grade);
		boolean Adminflag = home.SelectWidgetAdministration("Tests Completed", Admin);
		boolean Gradeflag = home.SelectWidgetGrade("Tests Completed", Grade);
		if ((Adminflag) && (Gradeflag)) {
			UMReporter.log(Status.PASS, " Selected Administration => " + Admin + " ,  Grade => " + Grade);
			if (Grade.contains("All"))
				Grade = "All";
			sSubTitle = "Administration: " + Admin + ", Grade: " + Grade;
		} else
			UMReporter.log(Status.FAIL, "Unable to select Administration and Grade");
	}

	@Given("^Verify the Subject wise count of Student Tests Completed widget in Dashboard Page$")
	public void Verify_Dashboard_Student_Tests_Completed_Widget_page() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Subject wise count of Student Tests Completed widget in Dashboard Page");
		// Get widget content
		List<Map<String, String>> lstWidCards = home.GetArcWidgetContent("Tests Completed");
		if (lstWidCards != null)
			UMReporter.log(Status.PASS, "The Subject wise registered and not registered count : " + lstWidCards);
		else
			UMReporter.log(Status.PASS, "Student Tests Completed Widget no data to display");
	}

	@Given("^User Select (.*) count in Student Tests Completed widget in Dashboard Page$")
	public void Select_Dashboard_Student_Tests_Completed_Widget_Count_page(String SelectStatus) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User Select " + SelectStatus + " count in Student Tests Completed widget in Dashboard Page");
		String Subject, Selectcnt;
		// Select widget count
		mapSelectedWid = home.SelectArcWidgetContent("Tests Completed", SelectStatus);
		if (mapSelectedWid != null) {
			Subject = mapSelectedWid.get("subject");
			Selectcnt = mapSelectedWid.get(SelectStatus);
			sSelectedWidStatus = SelectStatus;
			if (CommonUtility.isNumeric(Selectcnt))
				iSelectedWidCount = Integer.parseInt(Selectcnt);
			UMReporter.log(Status.PASS, "Selected the " + iSelectedWidCount + " " + SelectStatus + " student count of "
					+ Subject + " in Student Tests Completed widget  ");
		} else
			UMReporter.log(Status.FAIL,
					"Unable to Select " + SelectStatus + " count in Student Tests Completed Widget");
	}

	@Given("^User Select Administration (.*) and Session (.*) in Test Session Overview Widget in Dashboard Page$")
	public void Select_Test_Session_Overview_Widget_Admin_Grade_page(String Admin, String Session) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User Select Administration and Session in Test Session Overview Widget in Dashboard Page");
		// Select Admin
		boolean Sessionflag = true;
		sParentOrg = null;
		sTitle = null;
		sSubTitle = null;
		CommonUtility._sleepForGivenTime(2000);

		if (Admin.indexOf("$") >= 0)
			Admin = CommonFunctions.getTestData(Admin);

		if (Session.indexOf("$") >= 0)
			Session = CommonFunctions.getTestData(Session);

		boolean Adminflag = home.SelectWidgetAdministration("Test Sessions Overview", Admin);
		if (Session.length() > 2)
			Sessionflag = home.SelectWidgetSession("Test Sessions Overview", Session);

		if ((Adminflag) && (Sessionflag))
			if (Session.length() > 2) {
				UMReporter.log(Status.PASS, " Selected Administration => " + Admin + " ,  Session => " + Session);
				sSubTitle = "Administration: " + Admin + ", Session: " + Session;
			} else {
				UMReporter.log(Status.PASS, " Selected Administration => " + Admin + " ,  Session => All Sessions ");
				sSubTitle = "Administration: " + Admin + ", Session: ALL";
			}
		else
			UMReporter.log(Status.FAIL, "Unable to select Administration and Session");
	}

	@Given("^Verify the Test Status wise count of Test Session Overview widget in Dashboard Page$")
	public void Verify_Dashboard_Test_Session_Overview_Widget_page() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Test Status wise count of Test Session Overview widget in Dashboard Page");
		// Get widget content
		if (!home.checkWidhasNoData()) {
			Map<String, String> mapWidCards = sessiondetail.GetStatusProgressBarContent();
			if (mapWidCards != null) {
				int iTotStuds = home.getTotalStudentsCnt();
				mapWidCards.put("Total Tests", String.valueOf(iTotStuds));
				UMReporter.log(Status.PASS, "The Test Status wise count : " + mapWidCards);
			} else
				UMReporter.log(Status.SKIP, "Test Session Overview widget no data to display");
		} else
			UMReporter.log(Status.SKIP, "Test Session Overview widget no data to display");

	}

	@Given("^User select (.*) test status count in Test Session Overview widget in Dashboard Page$")
	public void Select_Dashboard_Test_Session_Overview_Widget_Count_page(String SelectStatus) throws Exception {
		UMReporter.log(Status.INFO, "Then : User Select " + SelectStatus
				+ " test status count in Test Session Overview widget in Dashboard Page");
		int slectCnt = 0;
		iSelectedWidCount = 0;
		sSelectedWidStatus = SelectStatus;
		// Select widget count
		if (!home.checkWidhasNoData()) {
			if (SelectStatus.equalsIgnoreCase("Total Tests"))
				slectCnt = home.SelectTotalStudents();
			else
				slectCnt = sessiondetail.SelectStatusInProgressBar(SelectStatus);

			System.out.println("slected Status Count : " + slectCnt);
			if (slectCnt > 0) {
				if (mapAppliedFilter != null) {
					String Grade = mapAppliedFilter.get("grade");
					if (Grade.contains("All"))
						Grade = "All";
					sSubTitle = "Administration: " + mapAppliedFilter.get("admin") + ", Grade: " + Grade;
				}
				sSelectedWidStatus = SelectStatus;
				iSelectedWidCount = slectCnt;
				UMReporter.log(Status.PASS, "Selected " + slectCnt + " " + SelectStatus
						+ " in Student Status Bar Graph in Test Session Overview widget ");
			} else
				UMReporter.log(Status.SKIP,
						"No Student " + SelectStatus + " Status Bar Graph in Test Session Overview widget");
		} else
			UMReporter.log(Status.SKIP, "Test Session Overview widget no data to display");

//		Map<String, String> mapWidCard =home.SelectStatusSessionOverviewWidgetContent("Test Sessions Overview",SelectStatus);
//		if(mapWidCard!=null) {
//			Selectcnt=mapWidCard.get(SelectStatus);
//			sSelectedWidStatus=SelectStatus;
//			if (CommonUtility.isNumeric(Selectcnt))
//				iSelectedWidCount=Integer.parseInt(Selectcnt);
//			UMReporter.log(Status.PASS,"Selected the "+iSelectedWidCount+" "+SelectStatus+" Test status student count in Test Session Overview widget  ");
//		}
//	    else
//	    	UMReporter.log(Status.FAIL,"Unable to Select "+SelectStatus+" count in Test Session Overview Widget");
	}

	@Then("^Verify the success message displayed in Account Details screen as (.*)$")
	public void verify_success_message_gets_displayed_on_Password_Update_Account_Detailsscreen_page(String Message)
			throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Account Details screen");
		boolean flag;
		String actulmessage = home.GetAlertMessage();
		if (actulmessage.contains(Message))
			UMReporter.log(Status.PASS,
					"Verified the success message displayed in Account Details screen" + actulmessage);
		else {
			if(home.SaveButton_isVisible()) {
				home.clickCancelButton();
			}
			UMReporter.log(Status.FAIL, "The following error message is displayed " + actulmessage);
		}
		home.Close_Alerts();
	}

//Sheetal

	@When("Verify the error hint displayed in Account Details screen")
	public void verify_the_error_hint_displayed_in_Account_Details_screen() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the error message displayed in Account Details screen");
		boolean flag;
		flag = home.verifyErrorHint("Password");
		if (flag) {
			UMReporter.log(Status.PASS, "Verified the Error message displayed in Account Details screen");
			// home.Close_Alerts();
		} else {
			UMReporter.log(Status.FAIL, "The error message is not matched with expected :");
		}
	}

	@Then("^Verify the error message displayed in Account Details screen$")
	public void verify_error_message_gets_displayed_on_Account_Detailsscreen_page() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the error message displayed in Account Details screen");
		boolean flag;
		flag = home.verifyErrorMessage("Incorrect");
		if (flag) {
			UMReporter.log(Status.PASS, "Verified the error message displayed in Account Details screen");
			home.Close_Alerts();
		} else {
			UMReporter.log(Status.FAIL, "The error message is not matched with expected :");
		}

	}

	@Given("^Verify the widget (.*) displayed in Dashboard Page$")
	public void Verify_Dashboard_Title_Widget_page(String WidgetTitile) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the widget displayed in Dashboard Page " + WidgetTitile);
		// Get widget content
		sParentOrg = home.Func_GetPinnedOrgName();
		boolean flag = home.VerifyArcWidgetTitle(WidgetTitile);
		if (!home.IsCardBodyDisplayed(WidgetTitile)) {
			home.DashboardWidgetBladeExpand(WidgetTitile, "Yes");
		}
		if (flag)
			UMReporter.log(Status.PASS, "The " + WidgetTitile + " widget is displayed in Dashboard Page ");
		else
			UMReporter.log(Status.FAIL, "The " + WidgetTitile + " widget is not displayed in Dashboard Page ");
	}

	@Given("^Verify Pearson logo displays on the footer$")
	public void return_to_Home_page() throws Exception {
		UMReporter.log(Status.INFO, "Verify Pearson logo displays on the footer");

		boolean flag = home.SelectfooterLogo();
		if (flag)
			UMReporter.log(Status.PASS, "Pearson Logo displays on the footer");
		else
			UMReporter.log(Status.FAIL, "Pearson Logo is not displays on the footer");

	}

	@Given("^Verify a Copyrights message on the footer - (.*)$")
	public void user_Verify_Copyrights(String ExpMessage) throws IOException {

		UMReporter.log(Status.INFO, "Given : Verify a Copyrights message on the footer -: " + ExpMessage);
		// Get the message
		String message = home.Func_GetCopyrights();
		message = message.trim().toString();
		if (message.equalsIgnoreCase(ExpMessage))
			UMReporter.log(Status.PASS, "The Copyrights matched with expected :  " + ExpMessage);
		else
			UMReporter.log(Status.FAIL, "The Copyrights not matched with expected : " + ExpMessage);
	}

	@Then("^User view the Terms and Conditions tab$")
	public void user_view_Tc_Tab() throws IOException {
		UMReporter.log(Status.INFO, "Then: User view the Terms and Conditions tab");
		boolean flag = login.IsTcPageExist();
		if (flag) {

			UMReporter.log(Status.PASS, "Selected and read the Terms & Conditions");
		} else
			UMReporter.log(Status.FAIL, "Unable to select Terms & Conditions");
	}

	@Given("^User selects the Conditions Links displaying the Terms & conditions$")
	public void Select_Conditions() throws Exception {
		UMReporter.log(Status.INFO, "Given :User selects the Conditions Links displaying the Terms & conditions");
		boolean flag = home.clickConditions();

		if (flag)
			UMReporter.log(Status.PASS, "Selected the Conditions Link");
		else
			UMReporter.log(Status.FAIL, "Unable to select the Conditions Link");
	}

	@Given("^User selects the Privacy Link displaying the Privacy policy$")
	public void Select_Privacy() throws Exception {
		UMReporter.log(Status.INFO, "Given :User selects the Privacy Link displaying the Privacy policy");
		boolean flag = home.clickprivacy();

		if (flag)
			UMReporter.log(Status.PASS, "Selected the Privacy Link");
		else
			UMReporter.log(Status.FAIL, "Unable to select the Privacy Link");
	}

	@Given("^Verify a user name and Project for the (.*) role in the header$")
	public void user_Verify_welcome_Message_logged(String userrole) throws IOException {

		UMReporter.log(Status.INFO, "Given : Verify a user name and Project for the role in the header " + userrole);
		String FS_UserName = null, FS_Customer = null;
		// Get the message
		String message = home.Func_GetWelcomeMessage();
		message = message.trim().toString();
		String FS_Userrole = home.Func_GetRole();
		message = message + " " + FS_Userrole;
		String custName = home.Func_GetCurrentCusName();
		message = message + " " + custName;
		message = message.trim().toString();
		System.out.println("message: " + message);

		FS_UserName = FileReaderManager.getInstance().getJsonReader().getNamebyRole(userrole);
		FS_Customer = FileReaderManager.getInstance().getJsonReader().getApplicationCustomer();
		if ((message.contains(FS_Userrole)) && (message.contains(FS_UserName)) && (message.contains(FS_Customer)))
			UMReporter.log(Status.PASS, "The Username, customer and role matched with expected :  " + message);
		else
			UMReporter.log(Status.FAIL,
					"The Username, customer and role not matched with expected : " + FS_Userrole + FS_UserName);
	}

	@When("^User select View Sessions from Student list in Drilldown page$")
	public void Verify_ViewSession_StuCount_Drilldown_list_IN_RegWidget() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select View Sessions from Student list in Drilldown page");
		List<HashMap<String, String>> MapDgOrgdetails = null;
		if (iSelectedWidCount != 0) {
			if (sSelectedWidStatus.equalsIgnoreCase("Registered")) {
				MapDgOrgdetails = drilldownpage.SelectViewSessions(1);
				if (MapDgOrgdetails != null)
					UMReporter.log(Status.PASS,
							"The selected " + sSelectedWidStatus + " Student's Sessions :" + MapDgOrgdetails);
				else
					UMReporter.log(Status.FAIL, "The selected " + iSelectedWidCount + " " + sSelectedWidStatus
							+ "student does not have sessions  ");
			} else
				UMReporter.log(Status.PASS, "No session list for selected " + sSelectedWidStatus + " Students");
		} else
			UMReporter.log(Status.PASS, "Unable to navigate the drilldown page");

	}

	@Then("^Verify the Export to CSV option visible in Drilldown page$")
	public void Verify_ExportTOCSV_options_of_Drilldown_page() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the Export to CSV option visible in Drilldown page");
		if (iSelectedWidCount != 0) {
			// verify export to CSV
			boolean flag = drilldownpage.verifyExporttoCSV();
			if (flag)
				UMReporter.log(Status.PASS, "The Export to CSV is visible in drilldown page");
			else
				UMReporter.log(Status.FAIL, "The Export to CSV option not visible in drilldown page");
		} else
			UMReporter.log(Status.FAIL, "Unable to navigate the drilldown page");
	}

	@Then("^User select the Export to CSV option in Drilldown page$")
	public void Select_ExportTOCSV_options_of_Drilldown_page() throws IOException {
		UMReporter.log(Status.INFO, "Then : User select the Export to CSV option in Drilldown page");
		if (iSelectedWidCount != 0) {
			// Get Title of drilldown page
			String pagetitle = drilldownpage.getPageTitleForDownload();
			System.out.println("Pagetitle : " + pagetitle);
			// Click export to CSV
			boolean flag = drilldownpage.clickExporttoCSV();

			// Get Latest file and check if matches the title
			File downloadedfile = csvfreader.getLatestDownloadFile("csv");
			String exportfilename = downloadedfile.getName();
			System.out.println("Exported filenme : " + exportfilename);
			if (exportfilename.toLowerCase().contains(pagetitle.toLowerCase()))
				UMReporter.log(Status.PASS,
						"Selected the Export to CSV file of drilldown page and downloded CSV File: " + exportfilename);
			else
				UMReporter.log(Status.FAIL,
						"Selected the Export to CSV file of drilldown page and downloded CSV File not matched the page title : "
								+ exportfilename);

		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Then("^Verify the downloaded CSV file with Drilldown Table Contents$")
	public void verify_ExportTOCSV_options_of_Drilldown_page() throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the downloaded CSV file with Drilldown Table Contents");
		if (iSelectedWidCount != 0) {
//		List<String> notverified = new ArrayList<String>();
//		List<String> verified = new ArrayList<String>();
			List<List<String>> notverified = new ArrayList<List<String>>();
			List<List<String>> verified = new ArrayList<List<String>>();
			// Get Drilldown page records
			List<List<String>> lstRecords = drilldownpage.getDrilldownrecords(2);
			// Get Latest file and check if matches the title
			File downloadedfile = csvfreader.getLatestDownloadFile("csv");
			String exportfilename = downloadedfile.getName();
			System.out.println("Exported filenme : " + exportfilename);
			String absolutefilepath = downloadedfile.getAbsolutePath();
			List<List<String>> lstdownoadedRecords = csvfreader.getExportedCSVContent(absolutefilepath, 3);
			if (lstdownoadedRecords.equals(lstRecords))
				UMReporter.log(Status.PASS,
						"Verified the downloaded CSV content with drilldown Table : " + lstdownoadedRecords);
			else {
				for (int i = 1; i < lstdownoadedRecords.size(); i++) {
					List<String> lst1 = lstdownoadedRecords.get(i);
					List<String> lst2 = lstRecords.get(i);

					if ((lst1.equals(lst2)) || (lst2.equals(lst1)))
						verified.add(lst1);
					else
						notverified.add(lst1);
				}
				if (notverified.size() > 0)
					UMReporter.log(Status.FAIL, "Not verified the drilldown content : " + lstRecords
							+ " Downloaded CSV Content : " + lstdownoadedRecords);
				else
					UMReporter.log(Status.SKIP, "Not verified the drilldown content : " + lstRecords
							+ " Downloaded CSV Content : " + lstdownoadedRecords);
			}
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Given("^User permissions in Dashboard page$")
	public void User_Permissions_Widget_in_Dashboard_page() throws Exception {

		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL, "LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		List<String> LstUserPermissions = Constants.PERMISSIONS;
		String WidgetTitile = null;

		if (LstUserPermissions.contains("DASHBOARD_STUDENT_REGISTRATION_WIDGET_ACCESS")) {
			UMReporter.log(Status.INFO, "Given :User permissions for Students Registered widget in Dasboard page");
			home.MenuOtion("home", "");
			WidgetTitile = "Students Registered";
			// home.SelectCustomerLogo();
			if (home.VerifyArcWidgetTitle(WidgetTitile)) {
				UMReporter.log(Status.PASS, "User have access the " + WidgetTitile + " widget in Dashboard Page");
				home.SelectWidgetAdministration(WidgetTitile, CommonFunctions.getTestData("$admin"));
				mapSelectedWid = home.SelectArcWidgetContent(WidgetTitile, "Registered");
				if (mapSelectedWid != null) {
					HashMap<String, String> MapSelectDrillCount = null;
					UMReporter.log(Status.PASS, "User have access the " + WidgetTitile + " widget : " + mapSelectedWid);
					// Drilldown
					if (LstUserPermissions.contains("DASHBOARD_STUDENT_REGISTRATION_WIDGET_ACCESS")) {
						if (drilldownpage.verifyPageNavigation("Districts ")) {
							MapSelectDrillCount = drilldownpage.SelectDrillResultsCount();
							if (MapSelectDrillCount != null)
								UMReporter.log(Status.PASS, "User have access the " + WidgetTitile
										+ " in  districts level drilldown :" + MapSelectDrillCount);
							if (drilldownpage.verifyExporttoCSV())
								UMReporter.log(Status.PASS,
										"User have access the Export to CSV options in districts level drilldown page");
						}
						if (drilldownpage.verifyPageNavigation("Schools ")) {
							MapSelectDrillCount = drilldownpage.SelectDrillResultsCount();
							if (MapSelectDrillCount != null)
								UMReporter.log(Status.PASS, "User have access the " + WidgetTitile
										+ " in  Schools level drilldown : :" + MapSelectDrillCount);
							if (drilldownpage.verifyExporttoCSV())
								UMReporter.log(Status.PASS,
										"User have access the Export to CSV options in Schools level drilldown page");
						}
						if (drilldownpage.verifyPageNavigation("Students ")) {
							MapSelectDrillCount = drilldownpage.getStudsearchresultsDetails(1);
							if (MapSelectDrillCount != null)
								UMReporter.log(Status.PASS, "User have access the " + WidgetTitile
										+ " in  Students level drilldown : :" + MapSelectDrillCount);
							if (drilldownpage.verifyExporttoCSV())
								UMReporter.log(Status.PASS,
										"User have access the Export to CSV options in Students level drilldown page");
						}
					}
				} else
					UMReporter.log(Status.SKIP,
							"User have access to " + WidgetTitile + " widget,  No records to drilldown");

			}
		}

		if (LstUserPermissions.contains("DASHBOARD_STUDENT_COMPLETED_WIDGET_ACCESS")) {
			UMReporter.log(Status.INFO, "Given :User permissions for Student Tests Completed widget in Dasboard page");
			home.SelectCustomerLogo();
			WidgetTitile = "Tests Completed";
			if (home.VerifyArcWidgetTitle(WidgetTitile)) {
				UMReporter.log(Status.PASS, "User have access the " + WidgetTitile + " widget in Dashboard Page");
				home.SelectWidgetAdministration(WidgetTitile, CommonFunctions.getTestData("$admin"));
				mapSelectedWid = home.SelectArcWidgetContent(WidgetTitile, "Completed");
				if (mapSelectedWid != null) {
					HashMap<String, String> MapSelectDrillCount = null;
					UMReporter.log(Status.PASS, "User have access the " + WidgetTitile + " widget : " + mapSelectedWid);
					// Drilldown
					if (LstUserPermissions.contains("DASHBOARD_STUDENT_COMPLETED_WIDGET_ACCESS")) {
						if (drilldownpage.verifyPageNavigation("Districts ")) {
							MapSelectDrillCount = drilldownpage.SelectDrillResultsCount();
							if (MapSelectDrillCount != null)
								UMReporter.log(Status.PASS, "User have access the " + WidgetTitile
										+ " in  districts level drilldown :" + MapSelectDrillCount);
							if (drilldownpage.verifyExporttoCSV())
								UMReporter.log(Status.PASS,
										"User have access the Export to CSV options in districts level drilldown page");
						}
						if (drilldownpage.verifyPageNavigation("Schools ")) {
							MapSelectDrillCount = drilldownpage.SelectDrillResultsCount();
							if (MapSelectDrillCount != null)
								UMReporter.log(Status.PASS, "User have access the " + WidgetTitile
										+ " in  Schools level drilldown : :" + MapSelectDrillCount);
							if (drilldownpage.verifyExporttoCSV())
								UMReporter.log(Status.PASS,
										"User have access the Export to CSV options in Schools level drilldown page");
						}
						if (drilldownpage.verifyPageNavigation("Students ")) {
							MapSelectDrillCount = drilldownpage.getStudsearchresultsDetails(1);
							if (MapSelectDrillCount != null)
								UMReporter.log(Status.PASS, "User have access the " + WidgetTitile
										+ " in  Students level drilldown : :" + MapSelectDrillCount);
							if (drilldownpage.verifyExporttoCSV())
								UMReporter.log(Status.PASS,
										"User have access the Export to CSV options in Students level drilldown page");
						}
					}
				} else
					UMReporter.log(Status.SKIP,
							"User have access to " + WidgetTitile + " widget,  No records to drilldown");

			}
		}

		if (LstUserPermissions.contains("DASHBOARD_TEST_SESSION_OVERVIEW_WIDGET_ACCESS")) {
			UMReporter.log(Status.INFO, "Given :User permissions for Test Sessions Overview widget in Dasboard page");
			home.SelectCustomerLogo();
			WidgetTitile = "Test Sessions Overview";
			if (home.VerifyArcWidgetTitle(WidgetTitile)) {
				UMReporter.log(Status.PASS, "User have access the " + WidgetTitile + " widget in Dashboard Page");
				home.SelectWidgetAdministration(WidgetTitile, CommonFunctions.getTestData("$admin"));
				// mapSelectedWid
				// =home.SelectStatusSessionOverviewWidgetContent(WidgetTitile,"Ready");
				int slectCnt = sessiondetail.SelectStatusInProgressBar("Ready");
				if (slectCnt > 0) {
					HashMap<String, String> MapSelectDrillCount = null;
					UMReporter.log(Status.PASS,
							"User have access the " + WidgetTitile + " widget  and selected  " + slectCnt + " Ready");
					// Drilldown
					if (LstUserPermissions.contains("DASHBOARD_TEST_SESSION_OVERVIEW_WIDGET_ACCESS")) {
						if (drilldownpage.verifyPageNavigation("Districts ")) {
							MapSelectDrillCount = drilldownpage.SelectDrillResultsCount();
							if (MapSelectDrillCount != null)
								UMReporter.log(Status.PASS, "User have access the " + WidgetTitile
										+ " in  districts level drilldown :" + MapSelectDrillCount);
							if (drilldownpage.verifyExporttoCSV())
								UMReporter.log(Status.PASS,
										"User have access the Export to CSV options in districts level drilldown page");
						}
						if (drilldownpage.verifyPageNavigation("Schools ")) {
							MapSelectDrillCount = drilldownpage.SelectDrillResultsCount();
							if (MapSelectDrillCount != null)
								UMReporter.log(Status.PASS, "User have access the " + WidgetTitile
										+ " in  Schools level drilldown : :" + MapSelectDrillCount);
							if (drilldownpage.verifyExporttoCSV())
								UMReporter.log(Status.PASS,
										"User have access the Export to CSV options in Schools level drilldown page");
						}
						if (drilldownpage.verifyPageNavigation("Student Tests in")) {
							MapSelectDrillCount = drilldownpage.getStudsearchresultsDetails(1);
							if (MapSelectDrillCount != null)
								UMReporter.log(Status.PASS, "User have access the " + WidgetTitile
										+ " in  Students level drilldown : :" + MapSelectDrillCount);
							if (drilldownpage.verifyExporttoCSV())
								UMReporter.log(Status.PASS,
										"User have access the Export to CSV options in Students level drilldown page");
						}
					}
				} else
					UMReporter.log(Status.SKIP,
							"User have access to " + WidgetTitile + " widget,  No records to drilldown");

			}
		}

	}

	@Given("^User Select Administration (.*) Subject (.*) and Grade (.*) in Dashboard Page$")
	public void Select_Students_TestingInfo_Widget_Admin_Subject_Grade_page(String Admin, String Subject, String Grade)
			throws Exception {
		UMReporter.log(Status.INFO, "Then : User Select Administration, Subject and Grade in Dashboard Page");
		// Select Admin
		CommonUtility._sleepForGivenTime(2000);
		sParentOrg = null;
		sTitle = null;
		sSubTitle = null;

		if (Admin.indexOf("$") >= 0)
			Admin = CommonFunctions.getTestData(Admin);

		if (Grade.indexOf("$") >= 0)
			Grade = CommonFunctions.getTestData(Grade);

		if (Subject.indexOf("$") >= 0)
			Subject = CommonFunctions.getTestData(Subject);

		CommonUtility._scrollup();
		boolean Adminflag = home.SelectWidgetAdministration("Testing Info", Admin);
		boolean Subjectflag = home.SelectWidgetSubject("Testing Info", Subject);
		boolean Gradeflag = home.SelectWidgetGrade("Testing Info", Grade);
		mapAppliedFilter = new HashMap<String, String>();
		CommonUtility._sleepForGivenTime(5000);
		if ((Adminflag) && (Subjectflag) && (Gradeflag)) {
			mapAppliedFilter.put("admin", Admin);
			mapAppliedFilter.put("subject", Subject);
			mapAppliedFilter.put("grade", Grade);
			UMReporter.log(Status.PASS,
					" Selected Administration => " + Admin + " ,Subject => " + Subject + " ,  Grade => " + Grade);
			if (Grade.contains("All"))
				Grade = "All";
			sSubTitle = "Administration: " + Admin + ", Grade: " + Grade;
		} else
			UMReporter.log(Status.FAIL, "Unable to select Administration, Subject and Grade");
	}

	@Given("^User Select Subject (.*) and Grade (.*) in Dashboard Page$")
	public void Select_Students_Accommodation_Blade_Subject_Grade_page(String Subject, String Grade) throws Exception {
		UMReporter.log(Status.INFO, "Then : User Select Subject and Grade in Dashboard Page");
		// Select Admin
		CommonUtility._sleepForGivenTime(2000);
		sParentOrg = null;
		sTitle = null;
		sSubTitle = null;

		if (Grade.indexOf("$") >= 0)
			Grade = CommonFunctions.getTestData(Grade);

		if (Subject.indexOf("$") >= 0)
			Subject = CommonFunctions.getTestData(Subject);

		CommonUtility._scrollup();
		boolean Subjectflag = home.SelectWidgetSubject("Testing Info", Subject);
		boolean Gradeflag = home.SelectWidgetGrade("Testing Info", Grade);
		mapAppliedFilter = new HashMap<String, String>();
		CommonUtility._sleepForGivenTime(5000);
		if ((Subjectflag) && (Gradeflag)) {
			mapAppliedFilter.put("subject", Subject);
			mapAppliedFilter.put("grade", Grade);
			UMReporter.log(Status.PASS, " Selected Subject => " + Subject + " ,  Grade => " + Grade);
			if (Grade.contains("All"))
				Grade = "All";
			sSubTitle = "Grade: " + Grade;
		} else
			UMReporter.log(Status.FAIL, "Unable to select Subject and Grade");
	}

	@Given("^Verify the Students count in Students Registered Arc Widget under Testing Information in Dashboard Page$")
	public void Verify_Dashboard_Students_Registered_Widget_In_TestingInfo_page() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Students count in Students Registered Arc Widget under Testing Information in Dashboard Page");
		// Get widget content
		Map<String, String> mapWidCards = home.GetTestingInfoArcWidgetContent("Testing Information", "Pre-Testing",
				"Students Registered");
		if (mapWidCards != null)
			UMReporter.log(Status.PASS,
					"The Students Registered Arc Widget, registered and not registered student count : " + mapWidCards);
		else
			UMReporter.log(Status.SKIP, "The Students Registered Widget no data to display");
	}

	@Given("^User Select (.*) count in Students Registered widget under Testing Information in Dashboard Page$")
	public void Select_Dashboard_Students_Registered_Widget_Count_Under_testingInfo_page(String SelectStatus)
			throws Exception {
		UMReporter.log(Status.INFO, "Then : User Select " + SelectStatus
				+ " count in Students Registered widget under Testing Information in Dashboard Page");
		String Selectcnt;
		// Select widget count
		mapSelectedWid = home.SelectTestingInfoArcWidgetContent("Testing Information", "Pre-Testing",
				"Students Registered", SelectStatus);
		if (mapSelectedWid != null) {
			Selectcnt = mapSelectedWid.get(SelectStatus);
			sSelectedWidStatus = SelectStatus;
			if (CommonUtility.isNumeric(Selectcnt))
				iSelectedWidCount = Integer.parseInt(Selectcnt);
			UMReporter.log(Status.PASS, "Selected the " + iSelectedWidCount + " " + SelectStatus
					+ " student count in Students Registered widget");
		} else
			UMReporter.log(Status.FAIL, "Unable to Select " + SelectStatus + " count in Students Registered Widget");
	}

	@Given("^Verify the Student test completed count of Student Tests Completed Arc widget under Testing Information in Dashboard Page$")
	public void Verify_Dashboard_Student_Tests_Completed_Widget_Under_testingInfo_page() throws Exception {
		UMReporter.log(Status.INFO,
				"Then : Verify the Student test completed count of Student Tests Completed Arc widget under Testing Information in Dashboard Page");
		// Get widget content
		Map<String, String> mapWidCards = home.GetTestingInfoArcWidgetContent("Testing Information", "Testing",
				"Tests Completed");
		if (mapWidCards != null)
			UMReporter.log(Status.PASS, "The Student Tests Completed and not Completed count : " + mapWidCards);
		else
			UMReporter.log(Status.SKIP, "Student Tests Completed Widget no data to display");
	}

	@Given("^User Select (.*) count in Student Tests Completed widget under Testing Information in Dashboard Page$")
	public void Select_Dashboard_Student_Tests_Completed_Widget_Count_Under_testingInfo_page(String SelectStatus)
			throws Exception {
		UMReporter.log(Status.INFO, "Then : User Select " + SelectStatus
				+ " count in Student Tests Completed widget under Testing Information in Dashboard Page");
		String Subject, Selectcnt;
		// Select widget count
		mapSelectedWid = home.SelectTestingInfoArcWidgetContent("Testing Information", "Testing",
				"Tests Completed", SelectStatus);
		if (mapSelectedWid != null) {
			Selectcnt = mapSelectedWid.get(SelectStatus);
			sSelectedWidStatus = SelectStatus;
			if (CommonUtility.isNumeric(Selectcnt))
				iSelectedWidCount = Integer.parseInt(Selectcnt);
			UMReporter.log(Status.PASS, "Selected the " + iSelectedWidCount + " " + SelectStatus
					+ " student count in Student Tests Completed widget  ");
		} else
			UMReporter.log(Status.FAIL,
					"Unable to Select " + SelectStatus + " count in Student Tests Completed Widget");
	}

	@Given("^Verify the Student Tests Irregularities in Dashboard Page$")
	public void Verify_Dashboard_Irregularities_Widget() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Student Tests Exceptions in Dashboard Page");
		// Get widget content
		Map<String, String> mapWidCard = home.GetCardsWidgetContent("Exceptions");
		if (mapWidCard.size() > 0)
			UMReporter.log(Status.PASS, "The Student Tests Exceptions count : " + mapWidCard);
		else
			UMReporter.log(Status.SKIP, "Student Tests Exceptions no data to display");
	}

	@Given("^User select Student Tests Irregularities count in Dashboard Page$")
	public void Select_Dashboard_Irregularities_Count_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select Student Tests w/Exceptions count in Dashboard Page");
		iSelectedWidCount = 0;
		sSelectedWidStatus = "Exceptions";
		// Select widget count
		iSelectedWidCount = home.SelectCardWidgetContent("Exceptions", "Student Tests w/Exceptions");
		if (iSelectedWidCount != 0)
			UMReporter.log(Status.PASS, "Selected Student Tests w/Exceptions count : " + iSelectedWidCount);
		else
			UMReporter.log(Status.SKIP, "Student Student Tests w/Exceptions no data to display");
	}

	@Then("^Verify the title (.*) for selected Student Tests Irregularities count in Drilldown page$")
	public void verify_Pagetitle_of_Irregularities_Drilldown_page(String OrgType) throws IOException {
		UMReporter.log(Status.INFO,
				"Then : Verify the title for selected Student Tests Exceptions count in Drilldown page" + OrgType);
		if (iSelectedWidCount != 0) {
			String SelectStatus = "with Exceptions";
			sTitle = OrgType + " " + SelectStatus;
			if (mapAppliedFilter != null) {
				String Subject = mapAppliedFilter.get("subject");
				if (sParentOrg == null)
					sParentOrg = home.Func_GetPinnedOrgName();
				sTitle = OrgType + " " + SelectStatus + " for " + Subject + " in " + sParentOrg;
			}
			// Verify the Stu list page displayed
			if (drilldownpage.verifyPageNavigation(sTitle))
				UMReporter.log(Status.PASS, "Verified the title of drilldown page : " + sTitle);
			else
				UMReporter.log(Status.FAIL, "Not verified the drilldown title : " + sTitle);
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Given("^Verify the (.*) card of (.*) widget in the Testing Information blade in Dashboard Page$")
	public void Verify_Dashboard_Widgets_Under_testingInfo_page(String Card, String CardHeader) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the " + Card + " card of " + CardHeader
				+ " widget in the Testing Information blade in Dashboard Page");
		// Get widget content
		Map<String, String> mapWidCards = home.GetTestingInfoArcWidgetContent("Testing Information", Card, CardHeader);
		if (mapWidCards != null)
			UMReporter.log(Status.PASS, "The " + Card + " card of " + CardHeader + " student count : " + mapWidCards);
		else
			UMReporter.log(Status.SKIP,
					"The " + Card + " card of " + CardHeader + " student count  no data to display ");
	}

	@Given("^User Select (.*) count in (.*) card of (.*) widget in the Testing Information blade in Dashboard Page$")
	public void Select_Widgets_Count_Under_testingInfo_page(String SelectStatus, String Card, String CardHeader)
			throws Exception {
		UMReporter.log(Status.INFO, "Then : User Select " + SelectStatus + " count in " + Card + " card of "
				+ CardHeader + " widget in the Testing Information blade in Dashboard Page");
		String Subject, Selectcnt;
		mapSelectedWid = home.SelectTestingInfoArcWidgetContent("Testing Information", Card, CardHeader, SelectStatus);
		if (mapSelectedWid != null) {
			Selectcnt = mapSelectedWid.get(SelectStatus);
			sSelectedWidStatus = SelectStatus;
			if (CommonUtility.isNumeric(Selectcnt))
				iSelectedWidCount = Integer.parseInt(Selectcnt);
			UMReporter.log(Status.PASS, "Selected the " + iSelectedWidCount + " " + SelectStatus + " student count in "
					+ Card + " card of " + CardHeader + " widget");
		} else
			UMReporter.log(Status.FAIL, "Unable to Select " + SelectStatus + " student count in " + Card + " card of "
					+ CardHeader + " widget");
	}

	@Given("^Verify the cards in Accommodations Blade in Dashboard Page$")
	public void Verify_Dashboard_Accommodations_Widget() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the cards in Accommodations Blade in Dashboard Page");
		// Get widget content
		Map<String, String> mapWidCard = home.GetCardsWidgetContent("Accommodations");
		if (mapWidCard.size() > 0)
			UMReporter.log(Status.PASS, "The Student/Tests w/Accommodations count : " + mapWidCard);
		else
			UMReporter.log(Status.SKIP, "Student/Test w/Accommodations no data to display");
	}

	@Given("^User select (.*) count in Accommodations Blade in Dashboard Page$")
	public void Select_Dashboard_Accommodations_Count_page(String StudAccomHeader) throws Exception {
		UMReporter.log(Status.INFO,
				"Then : User select " + StudAccomHeader + " count in Accommodations Blade in Dashboard Page");
		iSelectedWidCount = 0;
		sSelectedWidStatus = "Accommodations";
		// Select widget count
		iSelectedWidCount = home.SelectCardWidgetContent("Accommodations", StudAccomHeader);
		if (iSelectedWidCount != 0)
			UMReporter.log(Status.PASS, "Selected " + StudAccomHeader + " count : " + iSelectedWidCount);
		else
			UMReporter.log(Status.SKIP, StudAccomHeader + " no data to display");
	}

	@Then("^Verify the title (.*) for selected Students with (.*) count in Drilldown page$")
	public void verify_Pagetitle_of_accommodationWithStudents_Drilldown_page(String OrgType,String Accomtitle) throws IOException {
		UMReporter.log(Status.INFO,"Then : Verify the title for selected Students with "+Accomtitle+" count in Drilldown page" + OrgType);
		if (iSelectedWidCount != 0) {
			String SelectStatus = "with Students with "+Accomtitle;
			sTitle = OrgType + " " + SelectStatus;
			if (mapAppliedFilter != null) {
				String Subject = mapAppliedFilter.get("subject");
				if (sParentOrg == null)
					sParentOrg = home.Func_GetPinnedOrgName();
				if (OrgType.equalsIgnoreCase("Students"))
					sTitle = "Students with "+Accomtitle+" for " + Subject + " in " + sParentOrg;
				else
					sTitle = OrgType + " " + SelectStatus + " for " + Subject + " in " + sParentOrg;
			}
			// Verify the Stu list page displayed
			if (drilldownpage.verifyPageNavigation(sTitle))
				UMReporter.log(Status.PASS, "Verified the title of drilldown page : " + sTitle);
			else
				UMReporter.log(Status.FAIL, "Not verified the drilldown title : " + sTitle);
		} else
			UMReporter.log(Status.SKIP, "Unable to navigate the drilldown page");
	}

	@Then("^Clear the search text$")
	public void clear_search_text() throws Exception {
		UMReporter.log(Status.INFO, "And :Clear the search text");
		boolean flag = drilldownpage.ClearSearchText();

		if (flag)
			UMReporter.log(Status.PASS, "Cleared the search text");
		else
			UMReporter.log(Status.FAIL, "Unable to clear the search text");
	}

}
