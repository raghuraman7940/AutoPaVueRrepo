/**
 * User- Step Definition 
 */
package com.pauir.StepDefinitions;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.Common.ImportExport;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.testDataTypes.Userfield;
import com.pauir.PageDefinitions.users.ManageUsersPage;
import com.pauir.PageDefinitions.users.UserDetailPage;
import com.pauir.PageDefinitions.users.CreateUserPage;


import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;



public class UsersSteps {
	
	//Initialize the class variable
	public static ManageUsersPage manageusers;
	public static UserDetailPage userdetails;
	public static CreateUserPage createuser;
	public static HashMap<String,String> MapUserField=null;
	public static HashMap<String, String> MapUserFilledFields = null;
	public static HashMap<String,String> MapUserEditedFields=null;
	public static Login login;
	public static Home home;
	public static CommonFunctions common;
	public static ImportExport importexport;
	public static List<String> lstSelectedUsers = null;
	
	public UsersSteps()throws IOException{
		//Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home= new Home();
		manageusers=new ManageUsersPage();
		userdetails = new UserDetailPage();
		createuser=new CreateUserPage();
		importexport= new ImportExport();
	}
	
	@Given("^Navigate to User Management page$")     
	public void navigate_to_user_managemnet_page() throws Exception {
		 
		UMReporter.log(Status.INFO, "Given : Navigate to Manage User page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		boolean flag=home.VerifyLoggedinHomePage();;
		if (flag) {
			// Select Menu option Primary and secondary option
			home.MenuOtion("users", "");
			//Verify the User list page displayed
			if(manageusers.verifyManageUsersPageNavigation())
				UMReporter.log(Status.PASS,"User is navigated successfully to Manage Users page");
		    else
		    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
		}
		else if (manageusers.verifyManageUsersPageNavigation()) {
			UMReporter.log(Status.PASS,"Navigated to Users page");
		}
	}
	
	@Given("^Verify Users list page is displayed$")     
	public void navigate_to_user_list_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Verify Users list page is displayed");	
		//Verify the User list page displayed
		if((manageusers.verifyManageUsersPageNavigation())&&(importexport.VerifyActiveTab("User List")))
			UMReporter.log(Status.PASS,"User is navigated successfully to Manage Users page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}


@Then("^Verify create button is visible and enable on user list page$")
public void verify_create_button_is_visible_and_enable_on_Use_page() throws Exception{
	
	UMReporter.log(Status.INFO, "Then: Verify create button is visible and enable on User list page");    
	boolean createvisible = manageusers.createButton_isVisible();
	if(createvisible) {
		boolean createenabled = manageusers.createButton_isEnabled();
		if(createenabled)
			UMReporter.log(Status.PASS, "Create button is visable and enabled");
		else
			UMReporter.log(Status.FAIL, "Create button is not enabled");
	}
	else
		UMReporter.log(Status.FAIL, "Create button is not visible");
	
	
}

@Then("^Verify delete button is visible and disabled above the user list$")
public void verify_delete_button_is_visible_but_disabled() throws Exception {
	UMReporter.log(Status.INFO, "Then: Verify delete button is visible and enabled above the user list");
	boolean deletevisible = manageusers.deleteButton_isVisible();
	if(deletevisible) {
		boolean deleteenabled = manageusers.deleteButton_isEnabled();
		if(deleteenabled)
			UMReporter.log(Status.PASS, "Delete button is visible and disabled");
		else
			UMReporter.log(Status.FAIL, "Delete button is enabled without selecting record");
	}
	else
		UMReporter.log(Status.FAIL, "Delete button is not visible");
	
}

@Given("^Verify the user Table fields$")
         
public void verify_user_Table_fields(DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO,"When : Verify the users Table fields");
	String Fieldname;
	List<String> NonVerified=null;
	boolean flag = true;
	List<String> MapDgUserColHeader=manageusers.getUserColumnHeaderDetails();
	if (MapDgUserColHeader!=null) {
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NonVerified=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			System.out.println("Fieldname:" + Fieldname);
			if (!MapDgUserColHeader.contains(Fieldname))
				NonVerified.add(Fieldname);
		}
	}
	if (NonVerified.size()>0)
		UMReporter.log(Status.FAIL, "The following expected users Table fields are not exist in frontend :"+NonVerified);
	else
		UMReporter.log(Status.PASS, "The following users Table fields are verified :"+MapDgUserColHeader);
}

//@Then("^User able to access the list of users from the navigation$")
//public void verify_user_list_is_access() throws Exception {
//	UMReporter.log(Status.INFO, "Then : User able to access the list of users from the navigation");
//	List<String> MapDgUserColHeader=manageusers.verifyUsersearchresultsDetails(3);
//    if (MapDgUserColHeader!=null)
//    	UMReporter.log(Status.PASS, "The following User lists are accessed :"+MapDgUserColHeader);
//    else
//    	UMReporter.log(Status.FAIL, "The user are not found in list");
//}

@Then("^verify each user record contains a checkbox$")
public void verify_user_list_checkboxis_displayed() throws Exception {
	UMReporter.log(Status.INFO, "Then : verify each user record contains a checkbox");
	List<String> MapDgUserColHeader=manageusers.verifyUsersearchresultsCheckbox(3);
    if (MapDgUserColHeader!=null)
    	UMReporter.log(Status.PASS, "The Users lists contains checkbox :"+MapDgUserColHeader);
    else
    	UMReporter.log(Status.FAIL, "The Users are not found in list");
}

@When("^Select the user record checkbox$")
public void Select_user_list_checkbox() throws Exception {
	UMReporter.log(Status.INFO, "When : Select the user record checkbox");
	 boolean flag=manageusers.SelectonUserCheckbox();
    if (flag)
    	UMReporter.log(Status.PASS, "Selected the users checkbox ");
    else
    	UMReporter.log(Status.FAIL, "The users are not found in list");
}

@Then("^Verify delete button is enabled above the user list$")
public void verify_delete_button_is_enabled() throws Exception {
	UMReporter.log(Status.INFO, "Then : Verify delete button is enabled above the user list");
	 boolean deletevisible=manageusers.deleteButton_isEnabled();
	if(deletevisible)
		UMReporter.log(Status.PASS, "Delete button is enabled");
	else
		UMReporter.log(Status.FAIL, "Delete button is not enabled");
   
}

@When("^User fill the user search text (.*)$")
public void Fill_Searchtext_user_list(String SeachText) throws Exception {
	if (SeachText.indexOf("$")>=0)
		SeachText=CommonFunctions.getTestData(SeachText);
	UMReporter.log(Status.INFO, "Then : User fill the search text : "+SeachText);
	 boolean flag=manageusers.Searchfill_UserName(SeachText);
	 if (flag)
		 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
	 else
	    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
}

@When("^User search the user name search text (.*)$")
public void Fill_CreatedSearchtext_User_list(String SeachText) throws Exception {
	UMReporter.log(Status.INFO, "Then : User search the user name search text : "+SeachText);
	boolean flag=false;
	if (MapUserFilledFields!=null) {
		if (MapUserFilledFields.containsKey("First Name")) 
			SeachText=MapUserFilledFields.get("First Name");
	}
	else {
		if (SeachText.indexOf("$")>=0)
			SeachText=CommonFunctions.getTestData(SeachText);
	}
	flag=manageusers.Searchfill_UserName(SeachText);
	if (flag)
		 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
	 else
	    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
}

@When("^User search user name (.*) in User list$")
public void Search_CreatedSearchtext_User_list(String SeachText) throws Exception {
	UMReporter.log(Status.INFO, "Then : User search user name in User list : "+SeachText);
	boolean flag=false;
	String UserSerchText=null;
	if (MapUserFilledFields!=null) {
		if (MapUserFilledFields.containsKey("First Name")) {
			UserSerchText=MapUserFilledFields.get("First Name");
			flag=manageusers.Searchfill_UserName(UserSerchText);
			flag=manageusers.clicksearchicon();
			flag=manageusers.hasUserlist();
		}
	}
	
	if (!flag) {
		if (SeachText.indexOf("$")>=0)
			SeachText=CommonFunctions.getTestData(SeachText);
		flag=manageusers.Searchfill_UserName(SeachText);
		flag=manageusers.clicksearchicon();
		UserSerchText=SeachText;
		
	}
	if (flag)
		 UMReporter.log(Status.PASS, "The Search text :"+UserSerchText);
	 else
	    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
}

@Then("^verify the (.*) search results in the user list$")
public void Verify_Searchtext_in_user_list(String SeachText) throws Exception {
	UMReporter.log(Status.INFO, "Then : verify the search results in the user list : "+SeachText);
	if (MapUserFilledFields!=null) 
		if (MapUserFilledFields.containsKey("First Name")) 
			SeachText=MapUserFilledFields.get("First Name");
	
	 List<String> MapDgOrgDet=manageusers.verifyUsersearchresultsDetailsfromtext(SeachText);
	 if (MapDgOrgDet!=null)
    	UMReporter.log(Status.PASS, "The users lists matches the SeachText :"+MapDgOrgDet);
	 else
    	UMReporter.log(Status.FAIL, "The users are not found in list");

}

@Then("^Clear user Search text field$")
public void Clear_Searchtextfield_user_list() throws Exception {
	UMReporter.log(Status.INFO, "Then : Clear the Search text field");
	boolean flag=manageusers.ClearSearchText();
	
    if (flag) {
    	flag=manageusers.clicksearchicon();
    	 UMReporter.log(Status.PASS, "Cleared the Search Text");
    }
	 else
	    UMReporter.log(Status.FAIL, "Unable to Clear search Text");
}

@When("^User select the search icon in user page$")
public void Click_Searchicon_user_list() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the search icon");
	boolean flag=manageusers.clicksearchicon();
    if (flag)
    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
	 else
	    UMReporter.log(Status.FAIL, "Unable to select search icon");
}
	
	@Then("^User able to access the list of users from the navigation$")
	public void verify_user_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of users from the navigation");
		List<String> MapDgUserColHeader=manageusers.verifyUsersearchresultsDetails(3);
	    if (MapDgUserColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following User lists are accessed :"+MapDgUserColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The user are not found in list");
	}
	
	@When("^User select the user from User list$")
	public void user_clicks_on_First_IN_UserssList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select the user from User list");
		boolean flag=false;
		MapUserField=userdetails.getusersearchresultsDetails(1);
		if(MapUserField!=null) {
			if (MapUserField.containsKey("Name")) {
				//Click on User Name hyperlink on User list page
				flag=userdetails.clickonUserame(MapUserField.get("Name"));
				//Check the User selected
				if(flag) {
					CommonUtility._sleepForGivenTime(3000);
					UMReporter.log(Status.PASS,"Selected the User name "+MapUserField.get("Name")+" hyperlink in Userss datagrid");
				}
				else
					UMReporter.log(Status.FAIL,"The User name "+MapUserField.get("Name")+"  not found in Users datagrid");	
			}
		}
		else
			UMReporter.log(Status.FAIL,"No records found in Users datagrid");	
		
	}
	@Then("^Verify user details page is displayed$")
	public void verify_whether_user_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify user details page is displayed ");
		//Verify the User Detail page displayed
		if(userdetails.verifyUserDetailsNavigation())
			UMReporter.log(Status.PASS,"User is navigated to organization details page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Given("^Verify the User Info fields in User details page$")
	public void verify_User_info_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the User Info fields in User details page");
		String Fieldname,FieldValue;
		List<String> NonVerified=null;
		List<String> VerifiedField=null;
		if(userdetails.Verify_User_Info()){
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				System.out.println("Fieldname:" + Fieldname);
				if (!userdetails.verifyUserLabel(Fieldname))
					NonVerified.add(Fieldname);
				else {
					FieldValue=userdetails.GetValueforUserLabel(Fieldname);
					VerifiedField.add(Fieldname+" = "+FieldValue);
				}
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected User Info fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following User Info fields with values are verified :"+VerifiedField);
		}
		else
			UMReporter.log(Status.FAIL, "The User Info fields not found");
	}
	
	@Given("^Verify the Entitlements table fields in User details page$")
    
	public void verify_Entitlements_Table_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the users Entitlement Table fields");
		String Fieldname;
		List<String> NonVerified=null;
		boolean flag = true;
		List<String> MapDgUserColHeader=userdetails.getUserdeailsColumnHeaderDetails();
		if (MapDgUserColHeader!=null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgUserColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected users Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following users Table fields are verified :"+MapDgUserColHeader);
	}
	
	@Then("^Verify the Last updated date value is displayed in User details page$")
	public void verify_LastUpdate_in_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the Last updated date value is displayed in User details page");
		String LastUpdate=userdetails.verifyLastUpdatedLabel();
		if(LastUpdate!=null)
			UMReporter.log(Status.PASS,"Verified the Last updated date in User details page :"+LastUpdate);
		else
			UMReporter.log(Status.FAIL,"The Last updated date not found in User details page :"+LastUpdate);

	}
	
	@Then("^Verify Edit button is visible and enable on User list page$")
	public void verify_Edit_button_is_visible_and_enable_on_Org_page() throws Exception{
		
		UMReporter.log(Status.INFO, "Then: Verify Edit button is visible and enable on User detail page");    
		boolean createvisible = userdetails.UserEditButton_isVisible();
		if(createvisible) {
			boolean createenabled = userdetails.EditUserButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Edit button is visable and disabled");
			else
				UMReporter.log(Status.FAIL, "Edit button is not enabled");
		}
		else
			UMReporter.log(Status.FAIL, "User Edit button is not visible");
	
	}
	
	@Then("^Select Users breadcrumb$")
	public void Select_usermgmt_breadcrum() throws Exception {
		UMReporter.log(Status.INFO, "When : Select Users> breadcrum");
		userdetails.clickUserMgmtBreadCrum();
		UMReporter.log(Status.PASS, "Selected the Users breadcrum");
	}
	
	
	@Then("^Verify the user name is displayed in User details page$")
	public void verify_user_name_in_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the user name is displayed in User details page");
		boolean flag=false;
		if (MapUserField!=null) {
			if (MapUserField.containsKey("Name")) {
				String UserName=MapUserField.get("Name");
				String strArrObjLocs[] = CommonUtility._split(UserName,",");
				if(strArrObjLocs.length==2)
					flag=userdetails.verifyUserName(strArrObjLocs[1].trim(),strArrObjLocs[0].trim());
				else
					flag=userdetails.verifyUserName(UserName);
				
				if(flag)
					UMReporter.log(Status.PASS,"Verified the Username in User details page :"+UserName);
				else
					UMReporter.log(Status.FAIL,"The Username not found in User details page :"+UserName);
			}
		}
	    else
	    	UMReporter.log(Status.FAIL,"Username not exist");
	}
	
	@Given("^Navigate to Users page$")     
	public void navigate_to_users_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Users page");

		// Select Menu option Primary and secondary option
		home.MenuOtion("users", "");
		//Verify the User list page displayed
		if(manageusers.verifyManageUsersPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Manage Users page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	
	}
	
	@Then("^Verify the list of Users is displayed in Users page$")
	public void verify_user_list_is_access_UserPage() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the list of Users is displayed in Users page");
		List<String> MapDgUserColHeader=manageusers.verifyUsersearchresultsDetails(3);
	    if (MapDgUserColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following User lists are accessed :"+MapDgUserColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The user are not found in list");
	}
	

	@Then("^Verify Create button is visible and enabled in Users list page$")
	public void verify_Create_button_is_visible_and_Enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Create button is visible and enabled in Users list page");
		boolean createvisible = manageusers.createButton_isVisible();
		if(createvisible) {
			boolean createenabled = manageusers.createButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Create button is visible and enabled");
			else
				UMReporter.log(Status.FAIL, "Create button is visible and disabled");
		}
		else
			UMReporter.log(Status.FAIL, "Create button is not visible");
	}
	
	@When("^Click on Create button in Users list page$")
	public void Click_Create_button_inUsersList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Create button in Users list page");
		boolean isbtnclicked = manageusers.clickCreateUserButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Create button is click");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Create button");
		
	}
	
	@Then("^Verify Create User page is displayed$")
	public void verify_CreateUsers_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Create User page is displayed");
		//Verify the Class Detail page displayed
		if(importexport.VerifyActiveTab("Create User"))
			UMReporter.log(Status.PASS,"User is navigated to Create User page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	

	@Given("^User fill the Provided User details in Create User page$")
	public void user_fills_provided_fields_present_CreateUsersPage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User fill the Provided User details in Create User page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		
		// Get fields from Configuration json file
		List<Userfield> fields = FileReaderManager.getInstance().getJsonReader().getUserfieldsbyState(Constants.ORG_STATE);
		if (fields!=null) {
			if(createuser.VerifyCreateUserForm()){
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapUserFilledFields=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
					Userfield field=FileReaderManager.getInstance().getJsonReader().getUserfieldbyLabel(fields, Fieldname);
					if (field!=null) {
						FilledFieldValue = createuser.FillUserField(field, FieldValue);
						if (FilledFieldValue==null)
							NonVerified.add(Fieldname);
						else 
							MapUserFilledFields.put(Fieldname,FilledFieldValue);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following user fields are unable to provide the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following user fields provided the input values :"+MapUserFilledFields);
				
			}
			else
				UMReporter.log(Status.FAIL, "The input form fields are not displayed in class user page ");
		}
	}
	
	@When("^User check the fields control error on Create Users page$")
	public void user_check_userfields_on_createUsers_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User check the fields control error on Create Users page");
		HashMap<String,String> MapClassFieldvalidation=  new HashMap<String,String>();
		// Get fields from Configuration json file
		List<Userfield> fields = FileReaderManager.getInstance().getJsonReader().getUserfieldsbyState(Constants.ORG_STATE);
		// Checks the fields validation from Configuration field and user test data
		MapClassFieldvalidation=createuser.PageDataFieldValidation(fields, "required");
		UMReporter.log(Status.PASS, "Verified the following Input fields with Mandatory, Maximum, Minimum Length, Invalid data : "+MapClassFieldvalidation);

	}
	
	@Then("^Verify Create User button is visible and disabled in Create Users page$")
	public void verify_Save_button_is_visible_and_disabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Create User button is visible and disabled in Create Users page");
		boolean btnvisible = createuser.CreateUserButton_isVisible();
		if(btnvisible) {
			boolean btnenabled = createuser.CreateUserButton_isEnabled();
			if(btnenabled)
				UMReporter.log(Status.PASS, "Save button is visible and disable");
			else
				UMReporter.log(Status.FAIL, "Save button is visible and enable");
		}
		else
			UMReporter.log(Status.FAIL, "Save button is not visible");
	}
	
	@Then("^Verify Create User button is enabled in Create Users page$")
	public void verify_Save_button_is_visible_and_Enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Create User button is enabled in Create Users page");
		boolean btnvisible = createuser.CreateUserButton_isVisible();
		if(btnvisible) {
			boolean btnenabled = createuser.CreateUserButton_isEnabled();
			if(btnenabled)
				UMReporter.log(Status.PASS, "Save button is visible and enable");
			else
				UMReporter.log(Status.FAIL, "Save button is visible and disable");
		}
		else
			UMReporter.log(Status.FAIL, "Save button is not visible");
	}
	
	@Then("^Verify Cancel button is enabled in Create Users page$")
	public void verify_Cancel_button_is_visible_and_Enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Cancel button is enabled in Create Users page");
		boolean btnvisible = createuser.CancelButton_isVisible();
		if(btnvisible) 
				UMReporter.log(Status.PASS, "Cancel button is visible");
			else
				UMReporter.log(Status.FAIL, "Cancel button is not visible");
	
	}
	
	@When("^Click on Create User button in Create Users page$")
	public void Click_Save_button_in_UsersList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Create User button in Create Users page");
		boolean isbtnclicked = createuser.clickCreateUserButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Create User button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Create User button");
	}
	
	@When("^Click on Cancel button in Create Users page$")
	public void Click_Cancel_button_in_UsersList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Cancel button in Create Users page");
		boolean isbtnclicked = createuser.clickCancelButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Cancel button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Cancel button");
	}
	
	@Then("^Verify the filled User information in User details page$")
	public void verify_filled_User_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the filled User information in User details page");
		boolean flag =false;
		if (MapUserFilledFields!=null) {
			//Verify the User Detail page displayed
			if(userdetails.verifyUserDetailsNavigation()) {
				//Verify the User details page displayed
				flag = userdetails.verifyViewUserDetails(MapUserFilledFields);
				
			}
			else
				UMReporter.log(Status.FAIL,"User Details is not displayed");
				
		}
	    else
	    	UMReporter.log(Status.FAIL,"Class Details are not found");
	}
	
	@When("^Click on Edit button in User details page$")
	public void Click_Edit_button_in_UserDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Edit button in User details page");
		boolean isbtnclicked = userdetails.clickEditButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Edit button is click");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Edit button");
	}
	
	@Given("^User edit the details in User details page$")
	public void user_edit_provided_fields_present_CreateUserPage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User edit the details in User details page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		// Get fields from Configuration json file
				List<Userfield> fields = FileReaderManager.getInstance().getJsonReader().getUserfieldsbyState(Constants.ORG_STATE);
				if (fields!=null) {
					if(createuser.VerifyCreateUserForm()){
						List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
						NonVerified=new ArrayList<String>();
						MapUserEditedFields=  new HashMap<String,String>();
						for (int i = 0; i < list.size(); i++) {
							Fieldname = list.get(i).get("FieldLabel");
							FieldValue = list.get(i).get("InputValue");
							System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
							Userfield field=FileReaderManager.getInstance().getJsonReader().getUserfieldbyLabel(fields, Fieldname);
							if (field!=null) {
								FilledFieldValue = createuser.FillUserField(field, FieldValue);
								if (FilledFieldValue==null)
									NonVerified.add(Fieldname);
								else 
									MapUserEditedFields.put(Fieldname,FilledFieldValue);
							}
						}
						if (NonVerified.size()>0)
							UMReporter.log(Status.FAIL, "The following user fields are unable to edit the input value :"+NonVerified);
						else
							UMReporter.log(Status.PASS, "The following user fields edited the input values :"+MapUserEditedFields);
						
					}
					else
						UMReporter.log(Status.FAIL, "The input form fields are not displayed in class user page ");
				}
		
	}
	
	@When("^Click on Save button in User details page$")
	public void Click_Save_button_in_UserDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Save button in User details page");
		boolean isbtnclicked = userdetails.clickSaveButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Save button is click");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Save button");
		
	}
	
	@Then("^Verify the edited User information in User details page$")
	public void verify_edited_User_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the edited User information in User details page");
		if (MapUserEditedFields!=null) {
			MapUserFilledFields=MapUserEditedFields;
			//Verify the Student Detail page displayed
			if(userdetails.verifyUserDetailsNavigation())
				//Verify the Session details page displayed
				userdetails.verifyViewUserDetails(MapUserEditedFields);
			else
				UMReporter.log(Status.FAIL,"User details page is not displayed");
				
		}
	    else
	    	UMReporter.log(Status.FAIL,"User details are not found");
	}
	
	@Then("^Verify the success message displayed in Create User page as (.*)$")
	public void verify_success_message_gets_displayed_on_CreateUser_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Create User page "+messages);
		boolean flag;
		String ErrMessage=null;
		flag = createuser.verifySuccessMessage(messages);
		if (flag) {
			UMReporter.log(Status.PASS, "Verified the success message displayed in Create User page:" + messages);
			createuser.Close_Alerts();
		}
		else {
			flag = createuser.verifyErrorMessage("Create User");
			if (flag) {
				ErrMessage=createuser.getAlertMessage();
				UMReporter.log(Status.FAIL, "The error message displayed in Create User page :"+ErrMessage);
				MapUserFilledFields=null;
				createuser.Close_Alerts();
			}
			else
				UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
		}
		
	}
	
	@Then("^User direct url navigation to Create User page$")
	public void DirectUrlNavigation_CreateUsers_page() throws IOException  {
		UMReporter.log(Status.INFO, "Then : User direct url navigation to Create User page");
		home.AppendUrlDirectPageNavigate();
		//Verify the Class Detail page displayed
		if(createuser.verifyCreateUserPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Create User page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Given("^User permissions in Users page$")
	public void User_Permission_to_Organization_page() throws Exception {
		
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		List<String> LstUserPermissions=Constants.PERMISSIONS;
		
		if (LstUserPermissions.contains("VIEW_USER_LIST")) {
			UMReporter.log(Status.INFO, "Given :User permissions in Users page");
			home.MenuOtion("users", "");
			//Verify the User list page displayed
			if(manageusers.verifyManageUsersPageNavigation()) {
				UMReporter.log(Status.PASS,"User have access Users in the hamburger menu");
				List<String> MapDgUserColHeader=manageusers.verifyUsersearchresultsDetails(1);
			    if (MapDgUserColHeader!=null)
			    	UMReporter.log(Status.PASS, "User have access to view list of Users :"+MapDgUserColHeader);
			    
			    if (LstUserPermissions.contains("CREATE_USER")) {
					if(manageusers.createButton_isVisible()) 
						UMReporter.log(Status.PASS, "User have access to Create Users, Add button is visible");
					else
						UMReporter.log(Status.SKIP, "User have access to Create Users, Add button is not visible");		
				}
			    
			    if (LstUserPermissions.contains("RESEND_INVITE")) {
			    	//Search Pending User
			    	manageusers.Searchfill_UserName("Pending");
					manageusers.clicksearchicon();
			    	List<String> MapDgUserList=manageusers.SelectUserListCheckbox(1);
					if (MapDgUserList!=null) {
						if(manageusers.ResendInvite_isVisible()) 
							UMReporter.log(Status.PASS, "User have access to Resend Invite, Resend User Invite button is visible");
						else
							UMReporter.log(Status.SKIP, "User have access to Resend Invite, Resend User Invite button is not visible");	
					}
				}
			    
				if (LstUserPermissions.contains("VIEW_USER_DETAILS")) {
					MapUserField=userdetails.Selectuserlist();
					if(MapUserField!=null) {
						
						if(userdetails.verifyUserDetailsNavigation()) {
							
							if (MapUserField.containsKey("Name")) {
								String UserName=MapUserField.get("Name");
								String strArrObjLocs[] = CommonUtility._split(UserName,",");
								if(strArrObjLocs.length==2)
									MapUserField.put("Name", strArrObjLocs[1].trim());
							}
							userdetails.verifyViewUserDetails(MapUserField);
								
								if (LstUserPermissions.contains("EDIT_USER")) {
									if(userdetails.UserEditButton_isVisible())
										UMReporter.log(Status.PASS, "User have access to Edit User, Edit button is displayed");
									else
										UMReporter.log(Status.FAIL, "User have access to Edit User, Edit button is not displayed");
								}
						}	
						else
							UMReporter.log(Status.FAIL,"The User details is not displayed");	
						}
						else
							UMReporter.log(Status.SKIP,"No records found in Users list");
				}
			}
		}
		else
			UMReporter.log(Status.PASS,"User restricted for Users");
	}
	
	@Then("^Verify delete button is visible in User list page$")
	public void verify_delete_button_is_Enabledvisible_Userlist() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify delete button is visible in User list page");
		boolean deleteenabled = manageusers.deleteButton_isVisible();
		if (deleteenabled)
			UMReporter.log(Status.PASS, "Delete button is visible");
		else
			UMReporter.log(Status.FAIL, "Delete button is not displayed after selecting record");
	}

	@When("^Click on delete button in User list page$")
	public void Click_Delete_button_in_UserList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on delete button in User list page");
		boolean isbtnclicked = manageusers.clickDeleteButton();
		if (isbtnclicked) {
			UMReporter.log(Status.PASS, "Selected the delete button");
		} else
			UMReporter.log(Status.FAIL, "Unable to click the delete button");
	}

	@When("^Select the (.*) user in User list page$")
	public void Select_User_checkbox_User_list(String usrcount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the " + usrcount + " user in User list page");
		int stucnt = 1;
		if (CommonUtility.isNumeric(usrcount))
			stucnt = Integer.parseInt(usrcount);
		lstSelectedUsers = manageusers.SelectUserListCheckbox(stucnt);
		if (lstSelectedUsers.size() > 0)
			UMReporter.log(Status.PASS, "Selected the user checkbox " + lstSelectedUsers.size());
		else
			UMReporter.log(Status.FAIL, "The Users are not found in list");
	}

	@Then("^Verify the users are deleted in User list page$")
	public void verify_Selected_User_Removed_User_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the users are deleted in User list page");
		List<String> deletedClass = null;
		if (lstSelectedUsers != null) {
			deletedClass = new ArrayList<String>();
			for (String cls : lstSelectedUsers) {
				List<String> MapDgStuColHeader = manageusers.verifySelectedUserInlist(cls);
				if (MapDgStuColHeader == null)
					deletedClass.add(cls);
				else if (MapDgStuColHeader.size() < 1)
					deletedClass.add(cls);
			}
			if (deletedClass.size() > 0)
				UMReporter.log(Status.PASS, "The following users are deleted in User List Page :" + deletedClass);
			else
				UMReporter.log(Status.FAIL,
						"The following users are not removed in User List Page :" + lstSelectedUsers);
		} else
			UMReporter.log(Status.PASS, "The user are not found in user list");
	}

	@Then("^Verify the user are not deleted in User list page$")
	public void verify_Selected_user_Not_Removed_User_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the user are not deleted in User list page");
		List<String> deletedClass = null;
		if (lstSelectedUsers != null) {
			deletedClass = new ArrayList<String>();
			for (String cls : lstSelectedUsers) {
				List<String> MapDgStuColHeader = manageusers.verifySelectedUserInlist(cls);
				if (MapDgStuColHeader == null)
					deletedClass.add(cls);
				else if (MapDgStuColHeader.size() < 1)
					deletedClass.add(cls);
			}
			if (deletedClass.size() > 0)
				UMReporter.log(Status.PASS,
						"The following users are not removed in User List Page :" + lstSelectedUsers);
			else
				UMReporter.log(Status.FAIL, "The following users are removed in User List Page :" + deletedClass);
		} else
			UMReporter.log(Status.FAIL, "The users are not found in User list");
	}

	@Then("^Verify the alert success message in User list page as (.*)$")
	public void verify_success_message_gets_displayed_on_UserList_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the alert success message in User list page as " + messages);
		String ActualMessage;
		ActualMessage = manageusers.GetSuccessMessage();
		if ((ActualMessage != null) && (ActualMessage.length() > 2)) {
			if (ActualMessage.contains(messages))
				UMReporter.log(Status.PASS, "Verified the success message displayed in User List page:" + messages);
			else if (ActualMessage.contains("ERROR"))
				UMReporter.log(Status.SKIP, "The error message displayed :" + ActualMessage);
			else
				UMReporter.log(Status.FAIL,
						"Not matched expected message :" + messages + "\n Actual :" + ActualMessage);
			manageusers.Close_Alerts();
		} else
			UMReporter.log(Status.SKIP, "No Success message displayed");
	}

	@When("^Verify title and content (.*) in Confirmation Delete User pop-up$")
	public void Verify_title_message_ConfirmPopUp_button_UserPopup(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Confirm Delete User pop-up");
		boolean flag = false;
		// Verify the Confirm pop up
		flag = CommonFunctions.VerifyConfirmPopupContent(Constants.DeleteUserConfirmPopupTitle, confmessage);
		if (flag)
			UMReporter.log(Status.PASS, "Verified Confirm Delete User pop-up title and message : " + confmessage);

	}

	@When("^Click on confirm button on Confirmation Delete User pop-up$")
	public void Click_confirm_on_ConfirmDeleteUserpopup() throws Exception {
		UMReporter.log(Status.INFO, "When :  Click on confirm button on Confirmation User Courses pop-up");
		// Verify the Click Confirm in pop up
		boolean flag = CommonFunctions.ConfirmPopupActionBtn("Confirm");
		CommonUtility._sleepForGivenTime(3000);
		if (flag) {

			flag = manageusers.waitForProgressbarVisible(20);
			if (flag)
				UMReporter.log(Status.PASS, "Select the Confirm button and navigated to User list page");
			else
				UMReporter.log(Status.PASS, "Progress bar is displayed for long time after delete");

		} else
			UMReporter.log(Status.FAIL, "Select the Confirm button and Courses list not displayed ");
	}

	@When("^Click on cancel button on Confirmation Delete User pop-up$")
	public void Click_cancel_on_ConfirmDeleteUser_button() throws IOException {
		UMReporter.log(Status.INFO, "When :  Click on cancel button on Confirmation User Courses pop-up");

		// Verify the Click cancel in pop up
		boolean flag = CommonFunctions.ConfirmPopupActionBtn("Cancel");
		CommonUtility._sleepForGivenTime(3000);
		if (flag)
			UMReporter.log(Status.PASS, "Select the Cancel button and pop up is closed ");
		else
			UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed ");
	}

}
	
	
	
	
	
	
	
	
	
