/**
 * Shipments- Step Definition 
 */
package com.pauir.StepDefinitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.PageDefinitions.orders.CreateOrdersPage;
import com.pauir.PageDefinitions.orders.OrderDetailPage;
import com.pauir.PageDefinitions.shipments.ShipmentsPage;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.testDataTypes.Ordersfield;
import com.pauir.common.testDataTypes.Userfield;


import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;



public class ShipmentsSteps {
	
	//Initialize the class variable
	public static ShipmentsPage shipments;
	public static List<String> lstSelectedImport=null;
	public static Login login;
	public static Home home;
	public static CommonFunctions common;
	public static CreateOrdersPage createorder;
	public static OrderDetailPage orderdetails;
	public static String CurrentWinHnd=null;
	public static HashMap<String, String> MapShipFields = null;
	public static HashMap<String,String> MapFilledOrderField=null;
	public static HashMap<String,String> MapEditedOrderField=null;
	public static HashMap<String, String> MapOrderFields = null;
	public static String sSelectedOrder = null;
	
	public ShipmentsSteps()throws IOException{
		//Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home= new Home();
		shipments=new ShipmentsPage();
		createorder= new CreateOrdersPage ();
		orderdetails= new OrderDetailPage();
	}
	
	@Given("^Navigate to Shipments page$")     
	public void navigate_to_Shipments_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Shipments page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		boolean flag=home.VerifyLoggedinHomePage();;
		if (flag) {
			// Select Menu option Primary and secondary option
			home.MenuOtion("shipments", "");
			//Verify the shipments list page displayed
			if(shipments.verifyShipmentsPageNavigation())
				UMReporter.log(Status.PASS,"User is navigated successfully to Shipments page");
		    else
		    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
		}
		else if (shipments.verifyShipmentsPageNavigation()) {
			UMReporter.log(Status.PASS,"Navigated to Shipments page");
		}
	}
	
	@Then("^User switch to (.*) Tab in Shipments page$")
	public void Select_Session_list_Tab(String ShipType) throws Exception {
		UMReporter.log(Status.INFO, "Then : User switch to "+ShipType+" in Shipments page");
		boolean flag=false;
		if(!shipments.VerifyActiveTab(ShipType)) {
			flag=shipments.SelectTabOption(ShipType);
		    if (flag) {
		    	 UMReporter.log(Status.PASS, "Selected the "+ShipType+" Tab");
		    }
			 else
			    UMReporter.log(Status.FAIL, "Unable to select "+ShipType);
		}
		else
			UMReporter.log(Status.PASS, "Selected the "+ShipType+" Tab");
	}
	
	@Given("^Verify Shipments list page is displayed$")     
	public void navigate_to_Shipments_list_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Verify Shipments list page is displayed");	
		//Verify the Shipments list page displayed
		if(shipments.verifyShipmentsPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Shipments page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}



@Given("^Verify the Shipments Table fields$")
public void verify_Shipments_Table_fields(DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO,"When : Verify the Shipmentss Table fields");
	String Fieldname;
	List<String> NonVerified=null;
	boolean flag = true;
	List<String> MapDgUserColHeader=shipments.getColumnHeaderDetails();
	if (MapDgUserColHeader!=null) {
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NonVerified=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^")>=0)
				Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
			System.out.println("Fieldname:" + Fieldname);
			if (!MapDgUserColHeader.contains(Fieldname))
				NonVerified.add(Fieldname);
		}
	}
	if (NonVerified.size()>0)
		UMReporter.log(Status.FAIL, "The following expected Shipments Table fields are not exist in frontend :"+NonVerified);
	else
		UMReporter.log(Status.PASS, "The following Shipments Table fields are verified :"+MapDgUserColHeader);
}

@Given("^Verify the Shipments Table fields are sortable in Shipments page$")
public void verify_Shipments_Table_fields_Sortable(DataTable ddata) throws Exception {
	UMReporter.log(Status.INFO,"When :Verify the Shipments Table fields are sortable in Shipments page");
	String Fieldname;
	List<String> NotVerified=null;
	List<String> MapDgColValues=null;
	List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
	NotVerified=new ArrayList<String>();
	if (shipments.hasShipmentslist()) {
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^")>=0)
				Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
			MapDgColValues=shipments.verifySearchresultsSorting(Fieldname);
			if (MapDgColValues==null) 
				NotVerified.add(Fieldname);
			
		}
		if (NotVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Shipments Table fields are not Sortable :"+NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Table fields are Sortable :"+list);
		}
	else
		UMReporter.log(Status.SKIP, "No records in Shipment list");
	
}


@When("^User search Tracking number (.*) in Shipments list$")
public void Fill_Searchtext_Shipments_list(String SeachText) throws Exception {
	
	if (SeachText.indexOf("$")>=0)
		SeachText=CommonFunctions.getTestData(SeachText);

	UMReporter.log(Status.INFO, "Then : User search Tracking number in Shipments list "+SeachText);
	
	 boolean flag=shipments.FillSearchInput(SeachText);
	 if (flag)
		 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
	 else
	    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
}

@Then("^verify the (.*) search results in the Shipments list$")
public void Verify_Searchtext_in_Shipments_list(String SeachText) throws Exception {
	if (SeachText.indexOf("$")>=0)
		SeachText=CommonFunctions.getTestData(SeachText);
	UMReporter.log(Status.INFO, "Then : verify the search results in the Shipments list : "+SeachText);
	
	 List<String> MapDgOrgDet=shipments.verifysearchresultsDetailsfromtext(SeachText);
	 if (MapDgOrgDet!=null)
    	UMReporter.log(Status.PASS, "The Shipments lists matches the SeachText :"+MapDgOrgDet);
	 else
    	UMReporter.log(Status.FAIL, "The Shipments list are not found");
}

@When("^User select the search icon in Shipments page$")
public void Click_Searchicon_Shipments_list() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the search icon in Shipments page");
	boolean flag=shipments.clicksearchicon();
    if (flag)
    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
	 else
	    UMReporter.log(Status.FAIL, "Unable to select search icon");
}
	
@Then("^Verify the list of Shipments is displayed in Shipments page$")
public void verify_Shipments_list_is_access_UserPage() throws Exception {
	UMReporter.log(Status.INFO, "Then : Verify the list of Shipments is displayed in Shipments page");
	List<String> MapDgUserColHeader=shipments.verifysearchresultsDetails(3);
    if (MapDgUserColHeader!=null)
    	UMReporter.log(Status.PASS, "The following Shipments lists are accessed :"+MapDgUserColHeader);
    else
    	UMReporter.log(Status.FAIL, "The Shipments are not found in list");
}

@Given("^User permissions in Shipments page$")
public void User_Permission_to_DataImports_page() throws Exception {
	
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
		throw new RuntimeException("Login fail!");
	}
	List<String> LstUserPermissions=Constants.PERMISSIONS;
	
	if (LstUserPermissions.contains("VIEW_SHIPMENT_PACKAGES")) {
		UMReporter.log(Status.INFO, "Given : User permissions in Shipments page");
		//Switch Org
		String OrgName=FileReaderManager.getInstance().getJsonReader().getSelectOrgName("State"); 
		//Change the Org Details if not expected
		if (!home.Func_VerifyOrgName(OrgName)) 
			home.Func_ChangeOrganization(OrgName);
		
		home.MenuOtion("shipments", "");
		//Verify the Shipments list page displayed
		if(shipments.verifyShipmentsPageNavigation()) {
			UMReporter.log(Status.PASS,"User have access Shipments in the hamburger menu");
			List<String> MapDgUserColHeader=shipments.verifysearchresultsDetails(1);
		    if (MapDgUserColHeader!=null)
		    	UMReporter.log(Status.PASS, "User have access Shipments lists are :"+MapDgUserColHeader);
		}
	}	
	else
		UMReporter.log(Status.PASS,"User restricted for Shipments");
	
}

@When("^User select the Tracking Number hyperlink to call carrier website$")
public void Select_Trackingnum_hyperlink_Shipments_list() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the Tracking Number hyperlink to call carrier website");
	CurrentWinHnd=CommonFunctions.GetCurrentWindowHandle();
	MapShipFields=shipments.SelectShipmentList();
	if(MapShipFields!=null) 
	   	UMReporter.log(Status.PASS, "Selected the tracker number "+MapShipFields);
	else
		UMReporter.log(Status.SKIP, "No records in shipment list");
}

@When("^Verify the shipment carriers website open a new browser tab$")
public void Verify_Trackingnum_Carrier_Shipments_list() throws Exception {
	UMReporter.log(Status.INFO, "Then : Verify the shipment carriers website open a new browser tab");
	Set<String> ShipmentCarierTab=null;
	String Carrierurl=null;
	if(MapShipFields!=null) {
		ShipmentCarierTab= WebDriverMain._getDriver().getWindowHandles();
		if(ShipmentCarierTab.size()>0) {
			for(String testCarrier : ShipmentCarierTab) {
				if (!testCarrier.equals(CurrentWinHnd)) {
			    	WebDriverMain._getDriver().switchTo().window(testCarrier);
			    	CommonUtility._sleepForGivenTime(1000);
			    	Carrierurl=WebDriverMain._getDriver().getCurrentUrl();
			    	CommonUtility._sleepForGivenTime(1000);
			    	WebDriverMain._getDriver().switchTo().window(CurrentWinHnd);
				}
			}  
			CommonFunctions.CloseAllWindowExceptCurrent(CurrentWinHnd);
			if (Carrierurl!=null)
				UMReporter.log(Status.PASS, "The Shipment details in carrier website "+Carrierurl);
			else
				UMReporter.log(Status.FAIL, "No carrier website opened in browser tab");
		}
		else
			UMReporter.log(Status.SKIP, "No new browser tab opened");
	}
	else
		UMReporter.log(Status.SKIP, "No records found in shipment tab");	
    
}

@Given("Verify Order list page is displayed")
public void verify_Order_list_page_is_displayed() throws Exception {
	UMReporter.log(Status.INFO, "Given : Verify Order list page is displayed");	
	//Verify the Order list page displayed
	if(shipments.verifyOrdersPageNavigation()) {
		CommonFunctions.waitUntilLoadingSpinner(10);
		UMReporter.log(Status.PASS,"User is navigated successfully to Order page");
	}
    else
    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
}

@Given("Verify the order Table fields")
public void verify_the_order_Table_fields(io.cucumber.datatable.DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO,"When : Verify the Additional Orders Table fields");
	String Fieldname;
	List<String> NonVerified=null;
	boolean flag = true;
	List<String> MapDgUserColHeader=shipments.getColumnHeaderDetails();
	if (MapDgUserColHeader!=null) {
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NonVerified=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^")>=0)
				Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
			System.out.println("Fieldname:" + Fieldname);
			if (!MapDgUserColHeader.contains(Fieldname))
				NonVerified.add(Fieldname);
		}
	}
	if (NonVerified.size()>0)
		UMReporter.log(Status.FAIL, "The following expected Additional Orders Table fields are not exist in frontend :"+NonVerified);
	else
		UMReporter.log(Status.PASS, "The following Additional Orders Table fields are verified :"+MapDgUserColHeader);
}

@Given("Verify the list of Orders is displayed in Shipments page")
public void verify_the_list_of_Orders_is_displayed_in_Shipments_page() throws IOException {
			UMReporter.log(Status.INFO, "Given : Verify Order list page is displayed");	
		//Verify the Shipments list page displayed
		if(shipments.verifyOrdersPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Order page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}

@Given("^User switch to (.*) Tab in Order page$")
public void user_switch_to_Additional_Orders_Tab_in_Order_page(String Additional_Orders) throws IOException {
	UMReporter.log(Status.INFO, "When : User switch to "+Additional_Orders+" Tab");
	boolean selectImpotTab=shipments.SelectTabOption(Additional_Orders);
	if(selectImpotTab)
		UMReporter.log(Status.PASS, "Selected the "+Additional_Orders+" tab");
	else
		UMReporter.log(Status.FAIL, Additional_Orders+" Tab is not exist");
}

@Given("Verify the list of Orders is displayed in order page")
public void verify_the_list_of_Orders_is_displayed_in_order_page() throws Exception {
	UMReporter.log(Status.INFO, "Then : Verify the list of Orders is displayed in Shipments page");
	List<String> MapDgUserColHeader=shipments.verifysearchresultsDetails(3);
    if (MapDgUserColHeader!=null)
    	UMReporter.log(Status.PASS, "The following Order lists are accessed :"+MapDgUserColHeader);
    else
    	UMReporter.log(Status.FAIL, "The Orders are not found in list");
}

@When("^User search Order number (.*) in order list$")
public void user_search_Order_number_delivered_in_order_list(String SeachText) throws Exception {
	if (SeachText.indexOf("$")>=0)
		SeachText=CommonFunctions.getTestData(SeachText);

	UMReporter.log(Status.INFO, "Then : User search Staus in order list "+SeachText);
	
	 boolean flag=shipments.FillSearchInput(SeachText);
	 if (flag)
		 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
	 else
	    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
}

@When("User select the search icon in Order page")
public void user_select_the_search_icon_in_Order_page() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the search icon in Order List page");
	boolean flag=shipments.clicksearchicon();
    if (flag)
    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
	 else
	    UMReporter.log(Status.FAIL, "Unable to select search icon");
}


@Then("^verify the (.*) search results in the order list$")
public void verify_the_delivered_search_results_in_the_order_list(String SeachText) throws Exception {
	if (SeachText.indexOf("$")>=0)
		SeachText=CommonFunctions.getTestData(SeachText);
	UMReporter.log(Status.INFO, "Then : verify the search results in the Order list : "+SeachText);
	 List<String> MapDgOrgDet=shipments.verifyAOsearchresultsDetailsfromtext(SeachText);
	 if (MapDgOrgDet!=null)
    	UMReporter.log(Status.PASS, "The Shipments lists matches the SeachText :"+MapDgOrgDet);
	 else
    	UMReporter.log(Status.FAIL, "The Shipments list are not found");
}

@Then("Verify the order Table fields fields are sortable to AO page")
public void verify_the_order_Table_fields_fields_are_sortable_to_AO_page(io.cucumber.datatable.DataTable ddata) throws Exception {
	UMReporter.log(Status.INFO,"When :Verify the Order Table fields are sortable in Additional Orders page");
	String Fieldname;
	List<String> NotVerified=null;
	List<String> MapDgColValues=null;
	List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
	NotVerified=new ArrayList<String>();
	if (shipments.hasShipmentslist()) {
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^")>=0)
				Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
			MapDgColValues=shipments.verifySearchresultsSorting(Fieldname);
			if (MapDgColValues==null) 
				NotVerified.add(Fieldname);
			
		}
		if (NotVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Order Table fields are not Sortable :"+NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Table fields are Sortable :"+list);
		}
	else
		UMReporter.log(Status.SKIP, "No records in Additional Orders list");
}


@Then("^Verify Create Order page is displayed$")
public void verify_create_Order_page_displayed() throws IOException {
	UMReporter.log(Status.INFO, "Then : Verify Create Order page is displayed");
	// Verify the Order page displayed
	if (createorder.verifyCreateOrderPageNavigation())
		UMReporter.log(Status.PASS, "User is navigated to Create New Order page");
	else
		UMReporter.log(Status.FAIL, "Navigated to unexpected page");
}

@Given("^User fill the Provided Order details in Create Order page$")
public void user_fills_provided_fields_present_CreateOrderPage(DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO, "When : User fill the Provided Order details in Create Order page");
	String Fieldname, FieldValue, FilledFieldValue = null;
	List<String> NonVerified = null;
	// Get fields from Configuration json file
	List<Ordersfield> fields = FileReaderManager.getInstance().getJsonReader().getOrdersfieldsbyState(Constants.ORG_STATE);
	if (fields != null) {
		if (createorder.VerifyCreateOrdersForm()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			MapFilledOrderField = new HashMap<String, String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("FieldLabel");
				FieldValue = list.get(i).get("InputValue");
				if (FieldValue.indexOf("$") >= 0)
					FieldValue = CommonFunctions.getTestData(FieldValue);

				System.out.println("FieldValue:" + Fieldname + " => " + FieldValue);
				Ordersfield field = FileReaderManager.getInstance().getJsonReader().getOrdersfieldbyLabel(fields,Fieldname);
				if (field != null) {
					FilledFieldValue = createorder.FillOrderField(field, FieldValue);
					if (FilledFieldValue == null)
						NonVerified.add(Fieldname);
					else
						MapFilledOrderField.put(Fieldname, FilledFieldValue);
				}
			}
			if (NonVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following Order fields are unable to provide the input value :" + NonVerified);
			else
				UMReporter.log(Status.PASS,
						"The following Order fields provided the input values :" + MapFilledOrderField);

		} else
			UMReporter.log(Status.FAIL, "The input form fields are not displayed in Create Order page ");
	}
}

@When("^Click on Create Order button in Create Order page$")
public void Click_CreateOrder_button() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Create Order button in Create Order page");
	boolean isbtnclicked = createorder.clickCreateOrderButton();
	if (isbtnclicked)
		UMReporter.log(Status.PASS, "Selected the Create Order button");
	else
		UMReporter.log(Status.FAIL, "Uanable to click the Create Order button");
}


@Then("^Verify the alert success message in Create Order page as (.*)$")
public void verify_success_message_gets_displayed_on_CoursesList_page(String messages) throws IOException {
	UMReporter.log(Status.INFO, "Then : Verify the alert success message in Create Order page " + messages);
	String ActualMessage;
	ActualMessage = createorder.GetSuccessMessage();
	if ((ActualMessage!=null)&&(ActualMessage.length()>2)) {
		if(ActualMessage.contains(messages))
			UMReporter.log(Status.PASS, "Verified the success message displayed in Create Order page:" + messages);
		else if(ActualMessage.contains("ERROR"))
			UMReporter.log(Status.SKIP, "The error message displayed :" +ActualMessage);
		else
			UMReporter.log(Status.FAIL, "Not matched expected message :" + messages+"\n Actual :"+ActualMessage);
		createorder.Close_Alerts();
	}	
	else
		UMReporter.log(Status.SKIP, "No Success message displayed" );
}

@When("^User select the Order from Order list Page$")
public void user_clicks_on_Order_OrderList() throws Exception  {
	UMReporter.log(Status.INFO, "When :User select the Order from Order list Page");
	// Get Course Search results by row number
	MapOrderFields=shipments.SelectOrderRecord();
	if(MapOrderFields!=null) {
		if (MapOrderFields.containsKey("Order #")) {
			sSelectedOrder=MapOrderFields.get("Order #");
			CommonUtility._sleepForGivenTime(2000);
			UMReporter.log(Status.PASS,"Selected the Order # "+sSelectedOrder+" hyperlink in Order list");
		}else
			UMReporter.log(Status.FAIL,"The Order hyperlink  not found in Order list");
	}
	else
		UMReporter.log(Status.FAIL,"No records found in Order list");	
	
}


@Then("^Verify Order details page is displayed$")
public void verify_Order_details_page_is_displayed() throws IOException  {
	UMReporter.log(Status.INFO, "Then : Verify Order details page is displayed");
	//Verify the Detail page displayed
	if(orderdetails.verifyOrderDetailsNavigation())
		UMReporter.log(Status.PASS,"User is navigated to Order details page");
    else
    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
}

@Then("^Verify the Order Number is displayed in Order details page$")
public void verify_Order_name_in_Orderdetails_page_is_displayed() throws IOException  {
	UMReporter.log(Status.INFO, "Then : Verify the Order Number is displayed in Order details page");
	if (MapOrderFields!=null) {
		if (MapOrderFields.containsKey("Order #")) {
			String OrderNum=MapOrderFields.get("Order #");
			if(orderdetails.verifyOrderNum(OrderNum))
				UMReporter.log(Status.PASS,"Verified the Order Number in Order details page :"+OrderNum);
			else
				UMReporter.log(Status.FAIL,"The Order Number not found in Order details page :"+OrderNum);
		}
	}
    else
    	UMReporter.log(Status.FAIL,"Order Number not exist");
}

@Given("^Verify the Order fields in Order details page$")
public void verify_Order_Header_fields(DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO,"When : Verify the Order fields in Order details page");
	String Fieldname;
	List<String> NonVerified=null;
	List<String> VerifiedField=null;
	if(orderdetails.Verify_OrderHeader_Section()){
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NonVerified=new ArrayList<String>();
		VerifiedField=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("Fields");
			if (Fieldname.indexOf("^")>=0)
				Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
			
			System.out.println("Fieldname:" + Fieldname);
			if (!orderdetails.verifyOrderHeaderLabel(Fieldname))
				NonVerified.add(Fieldname);
			else
				VerifiedField.add(Fieldname);
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Order Header fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Order Header fields are verified :"+VerifiedField);
	}
	else
		UMReporter.log(Status.FAIL, "The Course Header fields not found");
}

@Given("^Verify link to display popup in Order details page$")
public void verify_Order_popup_fields(DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO,"When : Verify link to display popup in Order details page");
	String Fieldname;
	String Fieldvalue;
	List<String> NonVerified=null;
	List<String> VerifiedField=null;
	if(orderdetails.Verify_OrderHeader_Section()){
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NonVerified=new ArrayList<String>();
		VerifiedField=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldvalue=null;
			Fieldname = list.get(i).get("Fields");
			if (Fieldname.indexOf("^")>=0)
				Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
			
			System.out.println("Fieldname:" + Fieldname);
			Fieldvalue=orderdetails.GetOrderPopupLabel("See "+Fieldname);
			if (Fieldvalue!=null)
				VerifiedField.add(Fieldname+" : "+Fieldvalue);
			else
				NonVerified.add(Fieldname);
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Order fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Order fields are verified :"+VerifiedField);
	}
	else
		UMReporter.log(Status.FAIL, "The Order details page not found");
}

@Then("^Verify the selected Order field values in Order details page$")
public void verify_Selected_Order_details_is_displayed() throws IOException  {
	UMReporter.log(Status.INFO, "Then : Verify the selected Order field values in Order details page");
	if (MapOrderFields!=null) {
		//Verify the Class details page displayed
		orderdetails.verifyViewOrderDetails(MapOrderFields);
	}
    else
    	UMReporter.log(Status.FAIL,"Order Details are not found");
}


@Then("^Verify Item list is displayed in Order details page$")
public void verify_whether_Item_list_page_is_displayed_Order_detailspage() throws IOException  {
	UMReporter.log(Status.INFO, "Then : Verify Item list is displayed in Order details page");
	//Verify the Org list page displayed
	if(orderdetails.Verify_Order_ItemList())
		UMReporter.log(Status.PASS,"Items List is displayed in Order details page");
    else
    	UMReporter.log(Status.FAIL,"Items List is not displayed");
}

@Given("^Verify the Items Table fields in Order details page$")
public void verify_Items_Table_fields_Order_Details_Page(DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO,"Then : Verify the Items Table fields in Order details page");
	String Fieldname;
	List<String> NonVerified=null;
	//boolean flag = true;
	List<String> MapDgStuColHeader=orderdetails.getItemsColumnHeaderDetails();
	if (MapDgStuColHeader.size()>0) {
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NonVerified=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^")>=0)
				Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
			System.out.println("Fieldname:" + Fieldname);
			if (!MapDgStuColHeader.contains(Fieldname))
				NonVerified.add(Fieldname);
		}
	}
	if (NonVerified.size()>0)
		UMReporter.log(Status.FAIL, "The following expected Items Table fields are not exist in frontend :"+NonVerified);
	else
		UMReporter.log(Status.PASS, "The following Items Table fields are verified :"+MapDgStuColHeader);
		
}

@Then("^User able to access the list of Items in Order details page$")
public void verify_Items_list_is_access_Order_page() throws Exception {
	UMReporter.log(Status.INFO, "Then : User able to access the list of Items in Order details page");
	List<String> MapDgStuColHeader=orderdetails.verifyItemsearchresultsDetails(3);
    if (MapDgStuColHeader!=null)
    	UMReporter.log(Status.PASS, "The following Items lists are accessed in Order details Page :"+MapDgStuColHeader);
    else
    	UMReporter.log(Status.FAIL, "The Items are not found in list");
}


@When("^User search the Items (.*) in Order details page$")
public void Fill_Searchtext_item_list_Orderdetails_page(String SeachText) throws Exception {
	UMReporter.log(Status.INFO, "When : User search the item in Order details page : "+SeachText);
	 boolean flag=orderdetails.Searchfill_Orders(SeachText);
	 flag=orderdetails.clicksearchicon();
	 if (flag)
		 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
	 else
	    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
}

@Then("^verify the (.*) search Items results in Order details page$")
public void Verify_Searchtext_in_Items_list_Course_Page(String SeachText) throws Exception {
	UMReporter.log(Status.INFO, "Then : verify the search Items results in Order details page : "+SeachText);
	 List<String> MapDgOrgDet=orderdetails.verifyItemSearchresultsDetailsfromtext(SeachText);
	 if (MapDgOrgDet!=null)
    	UMReporter.log(Status.PASS, "The Items lists matches the SeachText :"+MapDgOrgDet);
	 else
    	UMReporter.log(Status.FAIL, "The Items are not found in list");

}


@Given("^User permissions in Additional Orders page$")
public void User_Permission_to_Additional_Orders_page() throws Exception {
	
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
		throw new RuntimeException("Login fail!");
	}
	List<String> LstUserPermissions=Constants.PERMISSIONS;
	
		
	if (LstUserPermissions.contains("ACCESS_AO") || LstUserPermissions.contains("ACCESS_AO_INTERNAL")) {
		UMReporter.log(Status.INFO, "Given : User permissions in Additional Orders page");
		//Switch Org
		String OrgName=FileReaderManager.getInstance().getJsonReader().getSelectOrgName("State"); 
		//Change the Org Details if not expected
		if (!home.Func_VerifyOrgName(OrgName)) 
			home.Func_ChangeOrganization(OrgName);
		
		home.MenuOtion("shipments", "");
		boolean selectAOTab=shipments.SelectTabOption("Additional Orders");
		//Verify the AO list page displayed
		if(selectAOTab) {
		if(shipments.verifyOrdersPageNavigation()) {
			UMReporter.log(Status.PASS,"User have access Additional Orders in the hamburger menu");
			List<String> MapDgUserColHeader=shipments.verifyAOsearchresultsDetailsfromtext("Draft");
		    if (MapDgUserColHeader!=null && LstUserPermissions.contains("ACCESS_AO"))
		    	UMReporter.log(Status.PASS, "User(ACCESS_AO) have access Additional Orders lists are :"+MapDgUserColHeader);
		    else 
		    	UMReporter.log(Status.PASS, "User(ACCESS_AO_INTERNAL) have access Additional Orders lists are :"+MapDgUserColHeader);
		}}
	}	
	else
		UMReporter.log(Status.PASS,"User restricted for Additional Orders");
	
}

@When("^Click on Edit button in Order details page$")
public void Click_Edit_button() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Edit button in Order details page");
	boolean isbtnclicked = orderdetails.clickEditButton();
	if (isbtnclicked)
		UMReporter.log(Status.PASS, "Selected the Edit button");
	else
		UMReporter.log(Status.FAIL, "Unable to click the Edit button");
}

@Given("^User edit the Order details in Order details page$")
public void user_edit_provided_fields_present_OrderDetailsPage(DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO, "When : User edit the Order details in Order details page");
	String Fieldname, FieldValue, FilledFieldValue = null;
	List<String> NonVerified = null;
	// Get fields from Configuration json file
	List<Ordersfield> fields = FileReaderManager.getInstance().getJsonReader().getOrdersfieldsbyState(Constants.ORG_STATE);
	if (fields != null) {
		if (createorder.VerifyCreateOrdersForm()) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified = new ArrayList<String>();
			MapEditedOrderField = new HashMap<String, String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("FieldLabel");
				FieldValue = list.get(i).get("InputValue");
				if (FieldValue.indexOf("$") >= 0)
					FieldValue = CommonFunctions.getTestData(FieldValue);

				System.out.println("FieldValue:" + Fieldname + " => " + FieldValue);
				Ordersfield field = FileReaderManager.getInstance().getJsonReader().getOrdersfieldbyLabel(fields,Fieldname);
				if (field != null) {
					FilledFieldValue = createorder.FillOrderField(field, FieldValue);
					if (FilledFieldValue == null)
						NonVerified.add(Fieldname);
					else
						MapEditedOrderField.put(Fieldname, FilledFieldValue);
				}
			}
			if (NonVerified.size() > 0)
				UMReporter.log(Status.FAIL,
						"The following Order fields are unable to edit the input value :" + NonVerified);
			else
				UMReporter.log(Status.PASS,
						"The following Order fields edited the input values :" + MapEditedOrderField);

		} else
			UMReporter.log(Status.FAIL, "The input form fields are not displayed in Order details page ");
	}
}


@When("^Click on Save button in Order details page$")
public void Click_Save_button() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Save button in Order details page");
	boolean isbtnclicked = orderdetails.clickSaveButton();
	if (isbtnclicked)
		UMReporter.log(Status.PASS, "Selected the Save button");
	else
		UMReporter.log(Status.FAIL, "Unable to click the Save button");
}

@Then("^Verify the alert success message in Order details page as (.*)$")
public void verify_success_message_gets_displayed_on_Orderdetails_page(String messages) throws IOException {
	UMReporter.log(Status.INFO, "Then : Verify the alert success message in Order details page " + messages);
	String ActualMessage;
	ActualMessage = createorder.GetSuccessMessage();
	if ((ActualMessage!=null)&&(ActualMessage.length()>2)) {
		if(ActualMessage.contains(messages))
			UMReporter.log(Status.PASS, "Verified the success message displayed in Order details page:" + messages);
		else if(ActualMessage.contains("ERROR"))
			UMReporter.log(Status.SKIP, "The error message displayed :" +ActualMessage);
		else
			UMReporter.log(Status.FAIL, "Not matched expected message :" + messages+"\n Actual :"+ActualMessage);
		createorder.Close_Alerts();
	}	
	else
		UMReporter.log(Status.SKIP, "No Success message displayed" );
}

@When("^Click on Add or Edit Items button in Order details page$")
public void Click_AddorEdit_Items_button() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Add or Edit Items button in Order details page");
	boolean isbtnclicked = orderdetails.clickAddEditItemButton();
	if (isbtnclicked)
		UMReporter.log(Status.PASS, "Selected the Add or Edit Items button");
	else
		UMReporter.log(Status.FAIL, "Unable to click the Add or Edit Items button");
}

@Then("^Verify Add Items to Order page is displayed$")
public void verify_AddItemOrder_details_page_is_displayed() throws IOException  {
	UMReporter.log(Status.INFO, "Then : Verify Add Items to Order page is displayed");
	//Verify the Detail page displayed
	if(orderdetails.verifyOrderItemsDetailsNavigation())
		UMReporter.log(Status.PASS,"User is navigated to Add Items to Order page");
    else
    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
}

@Then("^Verify Items list is displayed in Add Items to Order page$")
public void verify_whether_AddItem_list_page_is_displayed_Order_detailspage() throws IOException  {
	UMReporter.log(Status.INFO, "Then : Verify Items list is displayed in Add Items to Order page");
	//Verify the Org list page displayed
	if(orderdetails.Verify_ItemList())
		UMReporter.log(Status.PASS,"Items List is displayed in Add Items to Order page");
    else
    	UMReporter.log(Status.FAIL,"Items List is not displayed");
}

@When("^User set the (.*) items with quantity value as (.*) in Add Items to Order page$")
public void Usedr_Set_Quantity_Itemlist(String Itemcount,String ItemQuantity) throws Exception {
	UMReporter.log(Status.INFO, "When : User set the "+Itemcount+" items with quantity value as "+ItemQuantity+" in Add Items to Order page");
	int itemcnt = 1;
	int itemQtyt = 0;
	if (CommonUtility.isNumeric(Itemcount))
		itemcnt = Integer.parseInt(Itemcount);
	if (CommonUtility.isNumeric(ItemQuantity))
		itemQtyt = Integer.parseInt(ItemQuantity);
	List<HashMap<String, String>> lstSelectedItems = orderdetails.SetItemsQuantity(itemcnt, itemQtyt);
	if (lstSelectedItems!=null) {
		if (lstSelectedItems.size() > 0) 
			UMReporter.log(Status.PASS, "Provided Order Items Quatity : " + lstSelectedItems);
		else
			UMReporter.log(Status.FAIL, "The Order items list are not found");
	}
	else
		UMReporter.log(Status.SKIP, "The Order items list are not found");
}

@When("^Click on Order Details button in Add Items to Order page$")
public void Click_OrderDetails_button() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Order Details button in Add Items to Order page");
	boolean isbtnclicked = orderdetails.clickOrderDetailsButton();
	if (isbtnclicked)
		UMReporter.log(Status.PASS, "Selected the Order Details button");
	else
		UMReporter.log(Status.FAIL, "Unable to click the Order Details button");
}

@Then("^User select the Delete Order button in Order page")
public void Click_Delete_Order_button() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the Delete Order button in Order List page");
	boolean flag= orderdetails.clickDeleteOrderButton();
    if (flag)
    	 UMReporter.log(Status.PASS, "Clicked the Delete Order button");
	 else
	    UMReporter.log(Status.FAIL, "Unable to select Delete Order button");
}

@Then("^User select the Confirm button in Order Details page")
public void Click_Confirm_button() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the Confirm button in Delete Order Pop up in Order List page");
	boolean flag= orderdetails.clickConfirmButton();
    if (flag)
    	 UMReporter.log(Status.PASS, "Clicked the Confirm button");
	 else
	    UMReporter.log(Status.FAIL, "Unable to select Confirm button");
}

@Then("^User select the Cancel button in Order Details page")
public void Click_Cancel_button() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the Cancel button in Delete Order Pop up in Order List page");
	boolean flag= orderdetails.clickCancelButton();
    if (flag)
    	 UMReporter.log(Status.PASS, "Clicked the Cancel button");
	 else
	    UMReporter.log(Status.FAIL, "Unable to select Cancel button");
}

@Then("^Verify Delete Success Message is displayed in Order List page$")
public void verify_Success_Message_Order_List_Page() throws IOException  {
	UMReporter.log(Status.INFO, "Then : Verify Delete Success Message is displayed in Order List page");
	//Verify the Org list page displayed
	if(orderdetails.Verify_SuccessMessage())
		UMReporter.log(Status.PASS," Delete Success Message is displayed in Order List page");
    else
    	UMReporter.log(Status.FAIL,"Success Message is not displayed in Order List page");
}

@Then("User select the Release Order button in Order page")
public void user_select_the_Release_Order_button_in_Order_page() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the Release Order button in Order List page");
	boolean flag= orderdetails.clickReleaseOrderButton();
    if (flag)
    	 UMReporter.log(Status.PASS, "Clicked the Release Order button");
	 else
	    UMReporter.log(Status.FAIL, "Unable to select Release Order button");
}

@Then("Verify Release status Success Message is displayed in Order List page")
public void verify_Release_status_Success_Message_is_displayed_in_Order_List_page() throws Exception {
	UMReporter.log(Status.INFO, "Then : Verify Release_status Success Message is displayed in Order List page");
	//Verify the Org list page displayed
	if(orderdetails.Verify_SuccessMessage())
		UMReporter.log(Status.PASS," Release_status Success Message is displayed in Order List page");
    else
    	UMReporter.log(Status.FAIL,"Success Message is not displayed in Order List page");
}

@Then("^Verify the success message displayed in Order List page as (.*)$")
public void verify_success_message_gets_displayed_on_OrderList_page(String messages) throws IOException {
	UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Order List page " + messages);
	boolean flag;
	if (messages.contains("<X>")) 
		if (sSelectedOrder != null) // SelectOrder
			messages = messages.replace("<X>", sSelectedOrder);
	flag = shipments.verifySuccessMessage(messages);
	if (flag) 
		UMReporter.log(Status.PASS, "Verified the success message displayed in Order List page:" + messages);
	else
		UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
	shipments.Close_Alerts();
}

}
