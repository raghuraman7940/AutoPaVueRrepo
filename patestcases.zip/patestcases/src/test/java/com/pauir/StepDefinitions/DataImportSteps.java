/**
 * User- Step Definition 
 */
package com.pauir.StepDefinitions;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.testDataTypes.Userfield;
import com.pauir.PageDefinitions.dataimports.DataImportPage;


import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;



public class DataImportSteps {
	
	//Initialize the class variable
	public static DataImportPage dataimports;

	public static HashMap<String,String> MapUserField=null;
	public static HashMap<String, String> MapUserFilledFields = null;
	public static HashMap<String,String> MapUserEditedFields=null;
	public static List<String> lstSelectedImport=null;
	public static Login login;
	public static Home home;
	public static CommonFunctions common;
	public static boolean isDownloadBtnSelected=false;
	
	public DataImportSteps()throws IOException{
		//Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home= new Home();
		dataimports=new DataImportPage();
	}
	
	@Given("^Navigate to Imports/Exports page$")     
	public void navigate_to_DataImports_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Imports/Exports page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		boolean flag=home.VerifyLoggedinHomePage();;
		if (flag) {
			// Select Menu option Primary and secondary option
			home.MenuOtion("data imports", "");
			//Verify the Data Imports list page displayed
			if(dataimports.verifyDataImportsPageNavigation())
				UMReporter.log(Status.PASS,"User is navigated successfully to Imports/Exports page");
		    else
		    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
		}
		else if (dataimports.verifyDataImportsPageNavigation()) {
			UMReporter.log(Status.PASS,"Navigated to Imports/Exports page");
		}
	}
	
	@Given("^Verify Imports/Exports page is displayed$")     
	public void navigate_to_DataImports_list_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Verify Imports/Exports page is displayed");	
		//Verify the Data Imports list page displayed
		if(dataimports.verifyDataImportsPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Imports/Exports page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}


@Then("^Verify Download Initial Import is visible in Data Imports list page$")
public void verify_DataImports_button_is_visible_in_DataImports_page() throws Exception{
	UMReporter.log(Status.INFO, "Then: Verify Download Initial Import is visible in Data Imports list page");
	if (lstSelectedImport.size()>0) {
		boolean createvisible = dataimports.DownloadImport_isVisible();
		if(createvisible) 
			UMReporter.log(Status.PASS, "Download Initial Import is visible");
		else
			UMReporter.log(Status.FAIL, "Download Initial Import button is not visible");
	}
	else
		UMReporter.log(Status.SKIP, "The Data Import/Export are not found in list");
}

@Then("^Verify Download Results button is visible in Data Imports list page$")
public void verify_delete_button_is_visible_in_DataImports() throws Exception {
	UMReporter.log(Status.INFO, "Then: Verify Download Results button is visible in Data Imports list page");
	if (lstSelectedImport.size()>0) {
		boolean deletevisible = dataimports.DownloadResultsButton_isVisible();
		if(deletevisible) 
			UMReporter.log(Status.PASS, "Download Results button is visible");
		else
			UMReporter.log(Status.SKIP, "Download Results button is not visible");
	}
	else
		UMReporter.log(Status.SKIP, "The Data Import/Export are not found in list");
	
}

@Given("^Verify the Data Imports Table fields$")
public void verify_user_Table_fields(DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO,"When : Verify the Data Imports Table fields");
	String Fieldname;
	List<String> NonVerified=null;
	boolean flag = true;
	List<String> MapDgUserColHeader=dataimports.getColumnHeaderDetails();
	if (MapDgUserColHeader!=null) {
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NonVerified=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			System.out.println("Fieldname:" + Fieldname);
			if (!MapDgUserColHeader.contains(Fieldname))
				NonVerified.add(Fieldname);
		}
	}
	if (NonVerified.size()>0)
		UMReporter.log(Status.FAIL, "The following expected Data Imports Table fields are not exist in frontend :"+NonVerified);
	else
		UMReporter.log(Status.PASS, "The following Data Imports Table fields are verified :"+MapDgUserColHeader);
}

@Given("^Verify the Data Imports Table fields fields are sortable in Data Imports page$")
public void verify_Session_Table_fields_Sortable(DataTable ddata) throws IOException {
	UMReporter.log(Status.INFO,"When :Verify the Data Imports Table fields fields are sortable in Data Imports page");
	String Fieldname;
	List<String> NotVerified=null;
	List<String> MapDgColValues=null;
	List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
	NotVerified=new ArrayList<String>();
	for (int i = 0; i < list.size(); i++) {
		Fieldname = list.get(i).get("TableFields");
		MapDgColValues=dataimports.verifySearchresultsSorting(Fieldname);
		if (MapDgColValues==null) 
			NotVerified.add(Fieldname);
		
	}
	if (NotVerified.size()>0)
		UMReporter.log(Status.FAIL, "The following expected Table fields are not Sortable :"+NotVerified);
	else
		UMReporter.log(Status.PASS, "The following Table fields are Sortable :"+list);
}


@When("^User search batch number (.*) in Data Imports list$")
public void Fill_Searchtext_dataimports_list(String SeachText) throws Exception {
	
	if (SeachText.indexOf("$")>=0)
		SeachText=CommonFunctions.getTestData(SeachText);

	UMReporter.log(Status.INFO, "Then : User search batch number in Data Imports list "+SeachText);
	
	 boolean flag=dataimports.Searchfill_SearchText(SeachText);
	 if (flag)
		 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
	 else
	    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
}

@Then("^verify the (.*) search results in the Data Imports list$")
public void Verify_Searchtext_in_dataimports_list(String SeachText) throws Exception {
	if (SeachText.indexOf("$")>=0)
		SeachText=CommonFunctions.getTestData(SeachText);
	UMReporter.log(Status.INFO, "Then : verify the search results in the Data Imports list : "+SeachText);
	
	 List<String> MapDgOrgDet=dataimports.verifysearchresultsDetailsfromtext(SeachText);
	 if (MapDgOrgDet!=null)
    	UMReporter.log(Status.PASS, "The Data Imports lists matches the SeachText :"+MapDgOrgDet);
	 else
    	UMReporter.log(Status.FAIL, "The Data Imports list are not found");
}

@When("^User select the search icon in Data Imports page$")
public void Click_Searchicon_user_list() throws Exception {
	UMReporter.log(Status.INFO, "Then : User select the search icon in Data Imports page");
	boolean flag=dataimports.clicksearchicon();
    if (flag)
    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
	 else
	    UMReporter.log(Status.FAIL, "Unable to select search icon");
}
	
@Then("^Verify the list of Data Imports is displayed in Data Imports page$")
public void verify_user_list_is_access_UserPage() throws Exception {
	UMReporter.log(Status.INFO, "Then : Verify the list of Data Imports is displayed in Data Imports page");
	List<String> MapDgUserColHeader=dataimports.verifysearchresultsDetails(2);
    if (MapDgUserColHeader!=null)
    	UMReporter.log(Status.PASS, "The following Data Imports lists are accessed :"+MapDgUserColHeader);
    else
    	UMReporter.log(Status.FAIL, "The Data Imports are not found in list");
}

@When("^Click on Download Initial Import in Data Imports page$")
public void Click_DownloadImport_button_DownloadImportList() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Download Initial Import in Data Imports page");
	if (lstSelectedImport.size()>0) {
		boolean isbtnclicked = dataimports.clickDownloadImportButton();
		if(isbtnclicked) {
			isDownloadBtnSelected=true;
			UMReporter.log(Status.PASS, "Download Initial Import button is click");
		}
		else
			UMReporter.log(Status.FAIL, "Unable to click the Download Initial Import button");
	}
	else
		UMReporter.log(Status.SKIP, "The Data Import/Export are not found in list");
}

@When("^Click on Download Results in Data Imports page$")
public void Click_DownloadResults_button_DownloadImportList() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Download Results in Data Imports page");
	if (lstSelectedImport.size()>0) {
		boolean deletevisible = dataimports.DownloadResultsButton_isVisible();
		if (deletevisible) {
			boolean isbtnclicked = dataimports.clickDownloadResultsButton();
			if(isbtnclicked) {
				isDownloadBtnSelected=true;
				UMReporter.log(Status.PASS, "Download Results button is click");
			}
			else
				UMReporter.log(Status.FAIL, "Unable to click the Download Results button");
		}
		else
			UMReporter.log(Status.SKIP, "Download Results button is not displayed");
			
	}
	else
		UMReporter.log(Status.SKIP, "The Data Import/Export are not found in list");
}
	
@When("^Select the (.*) record in Data Imports page$")
public void Select_student_list_checkbox_SessionDetails(String Stucount) throws Exception {
	UMReporter.log(Status.INFO, "When : Select the "+Stucount+" record in Data Imports page");
	int stucnt=1;
	isDownloadBtnSelected=false;
	if (CommonUtility.isNumeric(Stucount))
		stucnt=Integer.parseInt(Stucount);
		lstSelectedImport=dataimports.SelectonImportCheckbox(stucnt);
	    if (lstSelectedImport.size()>0)
	    	UMReporter.log(Status.PASS, "Selected the data import record checkbox "+lstSelectedImport);
	    else
	    	UMReporter.log(Status.FAIL, "The Import are not found in list");
}


@Then("^Verify Download Message in Imports/Exports Page as (.*)$")
public void verify_Dataimports_message(String message) throws Exception {
	UMReporter.log(Status.INFO, "Then : Verify Download Message in Imports/Exports Page as " + message);
	if (isDownloadBtnSelected) {
	    String ActualMessage = dataimports.GetSuccessMessage();
		if ((ActualMessage!=null)&&(ActualMessage.length()>2)) {
			if(ActualMessage.contains(message))
				UMReporter.log(Status.PASS, "Verified the success message displayed in Imports/Exports page:" + message);
			else if(ActualMessage.contains("ERROR"))
				UMReporter.log(Status.PASS, "The error message displayed :" +ActualMessage);
			else
				UMReporter.log(Status.FAIL, "Not matched expected message :" + message+"\n Actual :"+ActualMessage);
			dataimports.Close_Alerts();
		}	
		else
			UMReporter.log(Status.PASS, "No message displayed" );
	}
	else
		UMReporter.log(Status.SKIP, "No download button is selected" );
	
}


@Given("^User permissions in Imports/Exports page$")
public void User_Permission_to_DataImports_page() throws Exception {
	
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
		throw new RuntimeException("Login fail!");
	}
	List<String> LstUserPermissions=Constants.PERMISSIONS;
	
	if (LstUserPermissions.contains("ACCESS_BATCHNOTIFICATIONS")) {
		UMReporter.log(Status.INFO, "Given : User permissions in Imports/Exports page");
		//Switch Org
		String OrgName=FileReaderManager.getInstance().getJsonReader().getSelectOrgName("State"); 
		//Change the Org Details if not expected
		if (!home.Func_VerifyOrgName(OrgName)) 
			home.Func_ChangeOrganization(OrgName);
		
		home.MenuOtion("data imports", "");
		//Verify the Data Imports list page displayed
		if(dataimports.verifyDataImportsPageNavigation()) {
			UMReporter.log(Status.PASS,"User have access Imports/Exports in the hamburger menu");
			List<String> MapDgUserColHeader=dataimports.verifysearchresultsDetails(1);
		    if (MapDgUserColHeader!=null)
		    	UMReporter.log(Status.PASS, "User have access Imports/Exports lists are :"+MapDgUserColHeader);
		}
	}	
	else
		UMReporter.log(Status.PASS,"User restricted for Imports/Exports");
	
}

@Then("^Verify the list of (.*) displayed in Imports/Exports page$")
public void verify_ImportExport_list_is_access_ImpExpPage(String ImportExport) throws Exception {
	UMReporter.log(Status.INFO, "Then : Verify the list of "+ImportExport+" displayed in Imports/Exports page");
	List<String> MapDgUserColHeader=dataimports.verifysearchresultsDetails(2);
    if (MapDgUserColHeader!=null)
    	UMReporter.log(Status.PASS, "The following "+ImportExport+" are accessed :"+MapDgUserColHeader);
    else
    	UMReporter.log(Status.FAIL, "The "+ImportExport+" are not found in list");
}

@When("^User search (.*) under (.*) Tab in Import/Export Page$")
public void Fill_Searchtext_SelectIcon_ExpImports_list(String SeachText,String ImportExport) throws Exception {
	if (SeachText.indexOf("$")>=0)
		SeachText=CommonFunctions.getTestData(SeachText);
	UMReporter.log(Status.INFO, "Then : User search '"+SeachText+"' under "+ImportExport+" Tab in Import/Export Page");
	boolean flag=dataimports.Searchfill_SearchText(SeachText);
	if (flag) {
		 flag=dataimports.clicksearchicon();
		 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
	}
	else
	    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
}

@When("^User select (.*) Roster Type batch under (.*) Tab in Import/Export page$")
public void Select_Batch_list_checkbox_ImportExport_Page(String RosterType, String ImportExport ) throws Exception {
	UMReporter.log(Status.INFO, "When : User select "+RosterType+" Roster Type batch under "+ImportExport+" Tab in Import/Export page");
	isDownloadBtnSelected=false;
	lstSelectedImport=dataimports.SelectonBatchCheckboxWithMatchedColValue(1,"Roster Type",RosterType);
	if (lstSelectedImport.size()>0)
		UMReporter.log(Status.PASS, "Selected "+RosterType+" in "+ImportExport+" checkbox "+lstSelectedImport);
	else
	 	UMReporter.log(Status.SKIP, "The Data Import/Export are not found in list");
}

@Then("^Verify Download Export button is visible in Data Export list page$")
public void verify_DownloadExport_button_is_visible_in_DataImports() throws Exception {
	UMReporter.log(Status.INFO, "Then: Verify Download Export button is visible in Data Export list page");
	if (lstSelectedImport.size()>0) {
		boolean deletevisible = dataimports.DownloadExportButton_isVisible();
		if(deletevisible) 
			UMReporter.log(Status.PASS, "Download Export button is visible");
		else
			UMReporter.log(Status.FAIL, "Download Export button is not visible");
	}
	else
		UMReporter.log(Status.SKIP, "The Data Import/Export are not found in list");
	
}

@When("^Click on Download Export in Data Export list page$")
public void Click_DownloadExport_button_DownloadImportList() throws Exception {
	UMReporter.log(Status.INFO, "When: Click on Download Export in Data Export list page");
	if (lstSelectedImport.size()>0) {
		boolean isbtnclicked = dataimports.clickDownloadExportButton();
		if(isbtnclicked) {
			isDownloadBtnSelected=true;
			UMReporter.log(Status.PASS, "Selected Download Export button");
		}
		else
			UMReporter.log(Status.FAIL, "Unable to click the Download Export button");
	}
	else
		UMReporter.log(Status.SKIP, "The Data Import/Export are not found in list");
}

}
	
	
	
	
	
	
	
	
	
