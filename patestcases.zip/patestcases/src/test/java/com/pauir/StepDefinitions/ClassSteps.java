/**
 * Class- Step Definition 
 */
package com.pauir.StepDefinitions;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.cucumber.datatable.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.PageDefinitions.students.StudentDetailPage;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.testDataTypes.Classfield;
import com.pauir.PageDefinitions.classes.ClassDetailPage;
import com.pauir.PageDefinitions.classes.ClassManagementPage;
import com.pauir.PageDefinitions.classes.CreateClassPage;
import com.pauir.PageDefinitions.Common.ImportExport;
import com.pauir.PageDefinitions.classes.AddStudentsToClassPage;
import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;

import com.pauir.common.util.CSV_Reader;
import com.pauir.common.util.Constants;

public class ClassSteps {
	
	//Initialize the class variable
	public static ClassManagementPage ClassMgmt;
	public static ClassDetailPage Classdetail;
	public static StudentDetailPage studentdetail;
	public static CreateClassPage createclass;
	public static AddStudentsToClassPage addstudentclass;
	public static HashMap<String,String> MapClassField=null;
	public static HashMap<String,String> MapFilledClassField=null;
	public static HashMap<String,String> MapEditedClassField=null;
	public static HashMap<String, String> MapclassStuFields = null;
	public static List<String> lstAddedStudent=null;
	public static List<String> lstRemovedStudent=null;
	public static List<String> lstSelectedClass=null;
	public static int iSelectedStudentCount=0;
	public static int iSelectedClassCount=0;

	public static Login login;
	public static Home home;
	public static CommonFunctions common;
	public static CSV_Reader csvfreader;
	public static ImportExport importexport;
	public static String csvfilepath;
	
	public ClassSteps()throws IOException{
		//Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home= new Home();
		ClassMgmt=new ClassManagementPage();
		Classdetail= new ClassDetailPage();
		studentdetail=new StudentDetailPage();
		createclass=new CreateClassPage();
		addstudentclass= new AddStudentsToClassPage();
		csvfreader= new CSV_Reader();
		importexport= new ImportExport();
	}
	
	@Given("^Navigate to Class Management page$")
	public void navigate_to_Class_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Class Management page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		boolean flag=home.VerifyLoggedinHomePage();;
		if (flag) {
			// Select Menu option Primary and secondary option
			home.MenuOtion("classes", "");
			//Verify the User list page displayed
			if(ClassMgmt.verifyClassMgmtPageNavigation())
				UMReporter.log(Status.PASS,"User is navigated successfully to Class Management page");
		    else
		    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
		}
		else if (ClassMgmt.verifyClassMgmtPageNavigation()) {
			UMReporter.log(Status.PASS,"Navigated to Class Management page");
		}
	}
	
	@Then("^Verify whether class list page is displayed$")
	public void verify_whether_Class_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify whether class list page is displayed ");
		//Verify the Org list page displayed
		if(ClassMgmt.verifyClassMgmtPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated to class list page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	
	@Then("^Verify class list page is displayed$")
	public void verify_Class_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify class list page is displayed ");
		//Verify the Org list page displayed
		if(ClassMgmt.verifyClassMgmtPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated to class list page");
	    else
	    {
	    	// Select Menu option Primary and secondary option
			home.MenuOtion("classes", "");
			//Verify the User list page displayed
			if(ClassMgmt.verifyClassMgmtPageNavigation())
				UMReporter.log(Status.PASS,"User is navigated to class list page");
		    else
		    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	    }
	}
	
	@Then("^Verify More Actions button is visible and disabled on Class list page$")
	public void verify_MoreAcctions_button_is_visible_and_enable_on_Class_page() throws Exception{
		UMReporter.log(Status.INFO, "Then: Verify More Actions button is visible and disabled on Class list page");    
		boolean btnvisible = ClassMgmt.MoreActionsButton_isVisible();
		if(btnvisible) {
			boolean btneenabled = ClassMgmt.MoreActionsButton_isEnabled();
			if(btneenabled)
				UMReporter.log(Status.PASS, "More Actions button is visable and disable");
			else
				UMReporter.log(Status.FAIL, "More Actions button is enabled");
		}
		else
			UMReporter.log(Status.FAIL, "More Acctions is not visible");
		
		
	}
	
	@Then("^Verify delete button is visible and disabled the Class list page$")
	public void verify_delete_button_is_visible_but_disabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify delete button is visible and disabled the Class list page");
		boolean deletevisible = ClassMgmt.deleteButton_isVisible();
		if(deletevisible) {
			boolean deleteenabled = ClassMgmt.deleteButton_isEnabled();
			if(deleteenabled)
				UMReporter.log(Status.PASS, "Delete button is visible and disabled");
			else
				UMReporter.log(Status.FAIL, "Delete button is enabled without selecting record");
		}
		else
			UMReporter.log(Status.FAIL, "Delete button is not visible");
		
	}
	
	@Given("^Verify the class Table fields$")
	public void verify_Class_Table_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : VVerify the class Table fields");
		String Fieldname;
		List<String> NonVerified=null;
	//	boolean flag = true;
		List<String> MapDgOrgColHeader=ClassMgmt.getClassColumnHeaderDetails();
		if (MapDgOrgColHeader!=null) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgOrgColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Class Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Class Table fields are verified :"+MapDgOrgColHeader);
	}
	
	
	@Then("^User able to access the list of class from the navigation$")
	public void verify_Class_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of class from the navigation");
		List<String> MapDgOrgColHeader=ClassMgmt.verifyClassSearchresultsDetails(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following Class lists are accessed :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The Class are not found in list");
	}
	
	@Then("^Verify each class record contains a checkbox$")
	public void verify_class_list_checkboxis_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify each class record contains a checkbox");
		List<String> MapDgOrgColHeader=ClassMgmt.verifyClassSearchresultsCheckbox(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The class lists contains checkbox :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The class are not found in list");
	}
	
	@When("^Select the class record checkbox$")
	public void Select_class_list_checkbox() throws Exception {
		UMReporter.log(Status.INFO, "When : Select the class record checkbox");
		 boolean flag=ClassMgmt.SelectonClassCheckbox();
	    if (flag)
	    	UMReporter.log(Status.PASS, "Selected the class checkbox ");
	    else
	    	UMReporter.log(Status.FAIL, "The class are not found in list");
	}
	
	@When("^User fill the class search text (.*)$")
	public void Fill_Searchtext_class_list(String SeachText) throws Exception {
		//Get from Testdata
		if (SeachText.indexOf("$")>=0)
			SeachText=CommonFunctions.getTestData(SeachText);
				
		UMReporter.log(Status.INFO, "Then : User fill the class search text : "+SeachText);
		 boolean flag=ClassMgmt.Searchfill_ClassName(SeachText);
		 if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@When("^User search the class search text (.*)$")
	public void Search_Searchtext_class_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User search the class search text : "+SeachText);
		if (MapFilledClassField!=null) { 
			if (MapFilledClassField.containsKey("Class Name")) 
				SeachText=MapFilledClassField.get("Class Name");
		}
		else
			if (SeachText.indexOf("$")>=0)
				SeachText=CommonFunctions.getTestData(SeachText);
		 boolean flag=ClassMgmt.Searchfill_ClassName(SeachText);
		 if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@When("^User search (.*) class in the Class list$")
	public void Search_ClassSearchtext_class_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User search class in the Class list: "+SeachText);
		boolean bflag=false;
		String ClassSertext=null;
		if (MapFilledClassField!=null) {
			if (MapFilledClassField.containsKey("Class Name")) {
				ClassSertext=MapFilledClassField.get("Class Name");
				ClassMgmt.Searchfill_ClassName(ClassSertext);
				ClassMgmt.clicksearchicon();
			}
			// Check Class has result
			bflag=ClassMgmt.hasClasslist();
			
		}
		
		if(!bflag) {
			if (SeachText.indexOf("$")>=0)
				SeachText=CommonFunctions.getTestData(SeachText);
			ClassMgmt.Searchfill_ClassName(SeachText);
			ClassMgmt.clicksearchicon();
			ClassSertext=SeachText;
			// Check Class has result
			bflag=ClassMgmt.hasClasslist();
		}
		 if (bflag)
			 UMReporter.log(Status.PASS, "The Search text :"+ClassSertext);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@When("^User select the search icon in class list page$")
	public void Click_Searchicon_Class_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : User select the search icon in class list page");
		boolean flag=ClassMgmt.clicksearchicon();
	    if (flag)
	    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
		 else
		    UMReporter.log(Status.FAIL, "Unable to select search icon");
	}
	
	@Then("^verify the (.*) search results in the class list$")
	public void Verify_Searchtext_in_Class_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search results in the class list : "+SeachText);
		if (MapFilledClassField!=null) 
			if (MapFilledClassField.containsKey("Class Name")) 
				SeachText=MapFilledClassField.get("Class Name");
		 List<String> MapDgOrgDet=ClassMgmt.verifyClassSearchresultsDetailsfromtext(SeachText);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "The class lists matches the SeachText :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The class are not found in list");
	
	}
	@Then("^Clear Search text field in class list page$")
	public void Clear_Searchtextfield_Class_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear the Search text field");
		boolean flag=ClassMgmt.ClearSearchText();
		
	    if (flag) {
	    	flag=ClassMgmt.clicksearchicon();
	    	 UMReporter.log(Status.PASS, "Cleared the Search Text");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}
	
	@When("^User select the class from class list$")
	public void user_clicks_on_First_IN_ClassList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User select the class from class list");
		boolean flag=false;
		// Get Class Search results by row number
		MapClassField=ClassMgmt.getClassSearchresultsDetails(1);
		if(MapClassField!=null) {
			if (MapClassField.containsKey("Class Name")) {
				//Click on Class Name hyperlink on Org list page
				flag=ClassMgmt.clickonClassName(MapClassField.get("Class Name"));
				//Check the Class selected
				if(flag) {
					CommonUtility._sleepForGivenTime(2000);
					UMReporter.log(Status.PASS,"Selected the Class name "+MapClassField.get("Class Name")+" hyperlink in Class List");
				}
				else
					UMReporter.log(Status.FAIL,"The Class name "+MapClassField.get("Last Name")+"  not found in Class List");	
			}
		}
		else
			UMReporter.log(Status.FAIL,"No records found in Organizations datagrid");	
		
	}
	
	@When("^User search (.*) and select the class from class list$")
	public void user_Search_clicks_on_First_IN_ClassList(String SeachText) throws Exception  {
		UMReporter.log(Status.INFO, "When :User select the class from class list");
		boolean flag=false;
		// Check Class has result
		flag=ClassMgmt.hasClasslist();
		if(!flag) {
			flag=ClassMgmt.Searchfill_ClassName(SeachText);
			flag=ClassMgmt.clicksearchicon();
		
		}
		// Get Class Search results by row number
		MapClassField=ClassMgmt.getClassSearchresultsDetails(1);
		if(MapClassField!=null) {
			if (MapClassField.containsKey("Class Name")) {
				//Click on Class Name hyperlink on Org list page
				flag=ClassMgmt.clickonClassName(MapClassField.get("Class Name"));
				//Check the Class selected
				if(flag) {
					CommonUtility._sleepForGivenTime(2000);
					UMReporter.log(Status.PASS,"Selected the Class name "+MapClassField.get("Class Name")+" hyperlink in Class List");
				}
				else
					UMReporter.log(Status.FAIL,"The Class name "+MapClassField.get("Last Name")+"  not found in Class List");	
			}
		}
		else
			UMReporter.log(Status.FAIL,"No records found in Organizations datagrid");
		
		
	}
	
	@Then("^Verify Class details page is displayed$")
	public void verify_class_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Class details page is displayed");
		//Verify the Class Detail page displayed
		if(Classdetail.verifyClassDetailsNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Class details page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Then("^Verify the Class name is displayed in Class details page$")
	public void verify_Class_name_in_details_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the Class name is displayed in Class details page");
		if (MapClassField!=null) {
			if (MapClassField.containsKey("Class Name")) {
				String ClsName=MapClassField.get("Class Name");
				if(Classdetail.verifyClassName(ClsName))
					UMReporter.log(Status.PASS,"Verified the Class name in Class details page :"+ClsName);
				else
					UMReporter.log(Status.FAIL,"The Class name not found in Class details page :"+ClsName);
			}
		}
	    else
	    	UMReporter.log(Status.FAIL,"Class name not exist");
	}
	
	@Then("^Verify the Last updated date value is displayed in Class details page$")
	public void verify_LastUpdate_in_classdetails_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the Last updated date value is displayed in Class details page");
		String LastUpdate=Classdetail.verifyLastUpdatedLabel();
		if(LastUpdate!=null)
			UMReporter.log(Status.PASS,"Verified the Last updated date in Class details page :"+LastUpdate);
		else
			UMReporter.log(Status.FAIL,"The Last updated date not found in Class details page :"+LastUpdate);

	}
	
	@Given("^Verify the Class Header fields in Class details page$")
	public void verify_Class_Header_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : Verify the Class Header fields in Class details page");
		String Fieldname;
		List<String> NonVerified=null;
		List<String> VerifiedField=null;
		if(Classdetail.Verify_ClassHeader_Section()){
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			VerifiedField=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("Fields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				
				System.out.println("Fieldname:" + Fieldname);
				if (!Classdetail.verifyClassHeaderLabel(Fieldname))
					NonVerified.add(Fieldname);
				else
					VerifiedField.add(Fieldname);
			}
			if (NonVerified.size()>0)
				UMReporter.log(Status.FAIL, "The following expected Class Header fields are not exist in frontend :"+NonVerified);
			else
				UMReporter.log(Status.PASS, "The following Class Header fields are verified :"+VerifiedField);
		}
		else
			UMReporter.log(Status.FAIL, "The Class Header fields not found");
	}
	
	@Then("^Verify the selected Class field values in Class details page$")
	public void verify_Selected_Class_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the selected Class field values in Class details page");
		if (MapClassField!=null) {
			//Verify the Class details page displayed
			Classdetail.verifyViewClassDetails(MapClassField);
		}
	    else
	    	UMReporter.log(Status.FAIL,"Class Details are not found");
	}
	
	@Then("^Select Classes breadcrumb$")
	public void Select_breadcrumb_Classes() throws Exception {
		UMReporter.log(Status.INFO, "Then :Select Classes> breadcrumb");
		boolean flag=Classdetail.clickClassManagementBreadcrumb();
	    if (flag) {
	    	 UMReporter.log(Status.PASS, "Selected the Classes breadcrumb");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to select Classes breadcrumb");
	}
	

	@Then("^Verify Student list is displayed in Class details page$")
	public void verify_whether_Student_list_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Student list is displayed in Class details page");
		//Verify the Org list page displayed
		if(Classdetail.Verify_Class_StudentList())
			UMReporter.log(Status.PASS,"Student List is displayed in Class details page");
	    else
	    	UMReporter.log(Status.FAIL,"Student List is not displayed");
	}
	
	@Given("^Verify the Student Table fields in Class details page$")
	public void verify_Students_Table_fields(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"Then : Verify the Student Table fields in Class details page");
		String Fieldname;
		List<String> NonVerified=null;
		//boolean flag = true;
		List<String> MapDgStuColHeader=Classdetail.getStuColumnHeaderDetails();
		if (MapDgStuColHeader.size()>0) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgStuColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Students Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Students Table fields are verified :"+MapDgStuColHeader);
			
	}
	
	@Then("^User able to access the list of Student in Class details page$")
	public void verify_Students_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of Student in Class details page");
		List<String> MapDgStuColHeader=Classdetail.verifyStusearchresultsDetails(3);
	    if (MapDgStuColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following students lists are accessed in Class details Page :"+MapDgStuColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The students are not found in list");
	}
	
	@Then("^Verify each Student record contains a checkbox in Class details page$")
	public void verify_student_list_checkboxis_displayed() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify each Student record contains a checkbox in Class details page");
		List<String> MapDgOrgColHeader=Classdetail.verifyStusearchresultsCheckbox(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The student lists contains checkbox :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The student are not found in list");
	}
	
	@When("^Select the Student record checkbox in Class details page$")
	public void Select_student_list_checkbox() throws Exception {
		UMReporter.log(Status.INFO, "When : Select the student record checkbox");
		 boolean flag=Classdetail.SelectonStuCheckbox();
	    if (flag)
	    	UMReporter.log(Status.PASS, "Selected the student checkbox ");
	    else
	    	UMReporter.log(Status.FAIL, "The students are not found in list");
	}	
	
	@Then("^Verify the pagination in Student datagrid in Class details page$")
	public void Verify_student_list_Paginations() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the pagination in Student datagrid in Class details page");
		int maxpage=Classdetail.verifyStuGridPagination();
		if (maxpage>1) 
	    	UMReporter.log(Status.PASS, "The students lists pagination are upto max pages :"+maxpage);
	    else if(maxpage==1)
	    	UMReporter.log(Status.PASS, "The students list contains one page only.");
	    else
	    	UMReporter.log(Status.FAIL, "The students list pagination fails.");
	}
	
	@When("^User search (.*) student in Student list of Class details page$")
	public void SearchStudent_Searchtext_class_detail(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : User search student in Student list of Class details page: "+SeachText);
		boolean flag=false;
		String StuSertext=null;
		if (lstAddedStudent!=null) {
			for (String stu:lstAddedStudent) {
				
				String strArrObjLocs[] = CommonUtility._split(stu,",");
				if(strArrObjLocs.length==2)
					StuSertext=strArrObjLocs[0].trim();
				else
					StuSertext=stu;
				
				flag=Classdetail.Searchfill_StudName(StuSertext);
				flag=Classdetail.clicksearchicon();
				
			}
		}
		// Check Class has result
		flag=Classdetail.hasStudlist();
		if(!flag) {
			flag=Classdetail.Searchfill_StudName(SeachText);
			flag=Classdetail.clicksearchicon();
			StuSertext=SeachText;
		}
		 if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+StuSertext);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@When("^User search the student (.*) in Class details page$")
	public void Fill_Searchtext_student_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search the student in Class details page : "+SeachText);
		 boolean flag=Classdetail.Searchfill_StudName(SeachText);
		 if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@When("^User select the search icon in Class details page$")
	public void Click_Searchicon_student_list() throws Exception {
		UMReporter.log(Status.INFO, "When : User select the search icon in Class details page");
		boolean flag=Classdetail.clicksearchicon();
	    if (flag)
	    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
		 else
		    UMReporter.log(Status.FAIL, "Unable to select search icon");
	}
	
	@Then("^verify the (.*) search Student results in Class details page$")
	public void Verify_Searchtext_in_student_list(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search Student results in Class details paget : "+SeachText);
		 List<String> MapDgOrgDet=Classdetail.verifyStudSearchresultsDetailsfromtext(SeachText);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "The Student lists matches the SeachText :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The Students are not found in list");
	
	}
	@Then("^Clear Search text field in Class details page$")
	public void Clear_Searchtextfield_student_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear Search text field in Class details page");
		boolean flag=Classdetail.ClearSearchText();
	    if (flag) {
	    	flag=Classdetail.clicksearchicon();
	    	 UMReporter.log(Status.PASS, "Cleared the Search Text");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}
	
	@Then("^Verify Create button is visible and enabled in Class list page$")
	public void verify_Create_button_is_visible_and_Enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Create button is visible and enabled in Class list page");
		boolean createvisible = ClassMgmt.CreateButton_isVisible();
		if(createvisible) {
			boolean createenabled = ClassMgmt.CreateButton_isEnabled();
			if(createenabled)
				UMReporter.log(Status.PASS, "Create button is visible and enabled");
			else
				UMReporter.log(Status.FAIL, "Create button is visible and disabled");
		}
		else
			UMReporter.log(Status.FAIL, "Create button is not visible");
	}
	
	@When("^Click on Create button in Class list page$")
	public void Click_Create_button_inClassList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Create button in Class list page");
		boolean isbtnclicked = ClassMgmt.clickCreateButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Create button is click");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Create button");
		
	}
	
	@Then("^Verify Create Class page is displayed$")
	public void verify_Createclass_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Create Class page is displayed");
		//Verify the Class Detail page displayed
		if(createclass.verifyCreateClassPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Create Class page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	

	@Given("^User fill the Provided Class details in Create Class page$")
	public void user_fills_provided_fields_present_CreateClassPage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User fill the Provided Class details in Create Class page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		
		// Get fields from Configuration json file
		List<Classfield> fields = FileReaderManager.getInstance().getJsonReader().getClassfieldsbyState(Constants.ORG_STATE);
		if (fields!=null) {
			if(createclass.VerifyCreateClassForm()){
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapFilledClassField=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					if (FieldValue.indexOf("$")>=0)
						FieldValue=CommonFunctions.getTestData(FieldValue);
					
					System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
					Classfield field=FileReaderManager.getInstance().getJsonReader().getClassfieldbyLabel(fields, Fieldname);
					if (field!=null) {
						FilledFieldValue = createclass.FillClassField(field, FieldValue);
						if (FilledFieldValue==null)
							NonVerified.add(Fieldname);
						else 
							MapFilledClassField.put(Fieldname,FilledFieldValue);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following class fields are unable to provide the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following class fields provided the input values :"+MapFilledClassField);
				
			}
			else
				UMReporter.log(Status.FAIL, "The input form fields are not displayed in class create page ");
		}
	}
	
	@When("^User check the fields control error on Create Class page$")
	public void user_check_userfields_on_createClass_page() throws IOException {
		UMReporter.log(Status.INFO, "When : User check the fields control error on Create Class page");
		HashMap<String,String> MapClassFieldvalidation=  new HashMap<String,String>();
		// Get fields from Configuration json file
		List<Classfield> fields = FileReaderManager.getInstance().getJsonReader().getClassfieldsbyState(Constants.ORG_STATE);
		// Checks the fields validation from Configuration field and user test data
		MapClassFieldvalidation=createclass.PageDataFieldValidation(fields, "required");
		UMReporter.log(Status.PASS, "Verified the following Input fields with Mandatory, Maximum, Minimum Length, Invalid data : "+MapClassFieldvalidation);

	}
	
	@Then("^Verify Save button is visible and disabled in Create Class page$")
	public void verify_Save_button_is_visible_and_disabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Save button is visible and disabled in Create Class page");
		boolean btnvisible = createclass.SaveButton_isVisible();
		if(btnvisible) {
			boolean btnenabled = createclass.SaveButton_isEnabled();
			if(btnenabled)
				UMReporter.log(Status.PASS, "Save button is visible and disable");
			else
				UMReporter.log(Status.FAIL, "Save button is visible and enable");
		}
		else
			UMReporter.log(Status.FAIL, "Save button is not visible");
	}
	
	@Then("^Verify Save button is enabled in Create Class page$")
	public void verify_Save_button_is_visible_and_Enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Save button is enabled in Create Class page");
		boolean btnvisible = createclass.SaveButton_isVisible();
		if(btnvisible) {
			boolean btnenabled = createclass.SaveButton_isEnabled();
			if(btnenabled)
				UMReporter.log(Status.PASS, "Save button is visible and enable");
			else
				UMReporter.log(Status.FAIL, "Save button is visible and disable");
		}
		else
			UMReporter.log(Status.FAIL, "Save button is not visible");
	}
	
	@Then("^Verify Cancel button is enabled in Create Class page$")
	public void verify_Cancel_button_is_visible_and_Enabled() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Cancel button is enabled in Create Class page");
		boolean btnvisible = createclass.CancelButton_isVisible();
		if(btnvisible) 
				UMReporter.log(Status.PASS, "Cancel button is visible");
			else
				UMReporter.log(Status.FAIL, "Cancel button is not visible");
	
	}
	
	@When("^Click on Save button in Create Class page$")
	public void Click_Save_button_inClassList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Save button in Create Class page");
		boolean isbtnclicked = createclass.clickSaveButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Save button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Save button");
		
	}
	
	@When("^Click on Cancel button in Create Class page$")
	public void Click_Cancel_button_inClassList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Cancel button in Create Class page");
		boolean isbtnclicked = createclass.clickCancelButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Cancel button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Cancel button");
		
	}
	
	@When("^Click on Save button in Class Details page$")
	public void Click_Save_button_inClassDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Save button in Class Details page");
		boolean isbtnclicked = createclass.clickSaveButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Save button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Save button");
		
	}
	
	@Then("^Verify the filled class information in Class details page$")
	public void verify_filled_Class_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the filled class information in Class details page");
		if (MapFilledClassField!=null) {
			//Verify the Student Detail page displayed
			if(Classdetail.verifyClassDetailsNavigation())
				//Verify the Session details page displayed
				Classdetail.verifyViewClassDetails(MapFilledClassField);
			else
				UMReporter.log(Status.FAIL,"Class Details is not displayed");
				
		}
	    else
	    	UMReporter.log(Status.FAIL,"Class Details are not found");
	}
	
	@When("^Click on Edit button in Class details page$")
	public void Click_Edit_button_inClassDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Edit button in Class details page");
		boolean isbtnclicked = Classdetail.clickEditButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Edit button is click");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Edit button");
		
	}
	
	@When("^Verify Edit options is visible in Class details page$")
	public void Verify_Edit_button_inClassDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Verify Edit options is visible in Class details page");
		boolean isbtnclicked = Classdetail.EditButton_isVisible();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Edit option is visible");
		else
			UMReporter.log(Status.FAIL, "Edit option is not visible");
		
	}
	@Given("^User edit the details in Class details page$")
	public void user_edit_provided_fields_present_CreateClassPage(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"When : User edit the details in Class details page");
		String Fieldname,FieldValue,FilledFieldValue=null;
		List<String> NonVerified=null;
		
		// Get fields from Configuration json file
		List<Classfield> fields = FileReaderManager.getInstance().getJsonReader().getClassfieldsbyState(Constants.ORG_STATE);
		if (fields!=null) {
			if(createclass.VerifyCreateClassForm()){
				List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
				NonVerified=new ArrayList<String>();
				MapEditedClassField=  new HashMap<String,String>();
				for (int i = 0; i < list.size(); i++) {
					Fieldname = list.get(i).get("FieldLabel");
					FieldValue = list.get(i).get("InputValue");
					//Get from Testdata
					if (FieldValue.indexOf("$")>=0)
						FieldValue=CommonFunctions.getTestData(FieldValue);
					System.out.println("FieldValue:" + Fieldname+" => "+FieldValue);
					Classfield field=FileReaderManager.getInstance().getJsonReader().getClassfieldbyLabel(fields, Fieldname);
					if (field!=null) {
						FilledFieldValue = createclass.FillClassField(field, FieldValue);
						if (FilledFieldValue==null)
							NonVerified.add(Fieldname);
						else 
							MapEditedClassField.put(Fieldname,FilledFieldValue);
					}
				}
				if (NonVerified.size()>0)
					UMReporter.log(Status.FAIL, "The following class fields are unable to edit the input value :"+NonVerified);
				else
					UMReporter.log(Status.PASS, "The following class fields edited the input values :"+MapEditedClassField);
				
			}
			else
			UMReporter.log(Status.FAIL, "The edit input form fields are not displayed in class details page ");
		}
		
	}
	@Then("^Verify the edited class information in Class details page$")
	public void verify_edited_Class_details_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify the edited class information in Class details page");
		if (MapEditedClassField!=null) {
			//Verify the Student Detail page displayed
			if(Classdetail.verifyClassDetailsNavigation())
				//Verify the Session details page displayed
				Classdetail.verifyViewClassDetails(MapEditedClassField);
			else
				UMReporter.log(Status.FAIL,"Class details page is not displayed");
				
		}
	    else
	    	UMReporter.log(Status.FAIL,"Class details are not found");
	}
	
	@When("^Click on Add Students button in Class details page$")
	public void Click_AddStudents_button_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Add Students button in Class details page");
		boolean isbtnclicked = Classdetail.clickAddStudentsButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Add Students button");
		else
			UMReporter.log(Status.FAIL, "Unable to click the Add Students button");

	}
	
	@When("^Verify Add Students option is visible in Class details page$")
	public void Verify_AddStudents_button_inSessionDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Verify Add Students option is visible in Class details page");
		boolean isbtnclicked = Classdetail.AddStudentsButton_isVisible();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Add Students button is visible");
		else
			UMReporter.log(Status.FAIL, "Add Students button is not visible");

	}
	
	@Then("^Verify Add Students to Class page is displayed$")
	public void verify_AddStudentsto_Class_page_is_displayed() throws IOException  {
		UMReporter.log(Status.INFO, "Then :Verify Add Students to Class page is displayed");
		//Verify the Add Students to Session page displayed
		if(addstudentclass.verifyAddStudentsToClassNavigation())
			UMReporter.log(Status.PASS,"User is navigated to Add Students to Class page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	
	@Then("^Verify Student list is displayed in Add Students to Class page$")
	public void verify_whether_Student_list_page_is_displayed_in_AddStudent_Class() throws IOException  {
		UMReporter.log(Status.INFO, "Then : Verify Student list is displayed in Add Students to Class page");
		//Verify the Stu list page displayed
		if(addstudentclass.Verify_Class_StudentList())
			UMReporter.log(Status.PASS,"Student List is displayed in Add Students to Class page");
	    else
	    	UMReporter.log(Status.FAIL,"Student List is not displayed");
	}
	
	@Given("^Verify the Student Table fields in Add Students to Class page$")
	public void verify_Students_Table_fields_AddStudentsto_Class_page(DataTable ddata) throws IOException {
		UMReporter.log(Status.INFO,"Then : Verify the Student Table fields in Add Students to Class page");
		String Fieldname;
		List<String> NonVerified=null;
		//boolean flag = true;
		List<String> MapDgStuColHeader=addstudentclass.getStuColumnHeaderDetails();
		if (MapDgStuColHeader.size()>0) {
			List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
			NonVerified=new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				Fieldname = list.get(i).get("TableFields");
				if (Fieldname.indexOf("^")>=0)
					Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
				System.out.println("Fieldname:" + Fieldname);
				if (!MapDgStuColHeader.contains(Fieldname))
					NonVerified.add(Fieldname);
			}
		}
		if (NonVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Students Table fields are not exist in frontend :"+NonVerified);
		else
			UMReporter.log(Status.PASS, "The following Students Table fields are verified :"+MapDgStuColHeader);
			
	}
	
	@Given("^Verify the Student Table fields fields are sortable in Add Students to Class page$")
	public void verify_Student_Table_fields_Sortable_AddStudentsto_Class_page(DataTable ddata) throws Exception {
		UMReporter.log(Status.INFO,"When :Verify the Student Table fields fields are sortable in Add Students to Class page");
		String Fieldname;
		List<String> NotVerified=null;
		List<String> MapDgColValues=null;
		List<Map<String, String>> list = ddata.asMaps(String.class, String.class);
		NotVerified=new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			Fieldname = list.get(i).get("TableFields");
			if (Fieldname.indexOf("^")>=0)
				Fieldname=Constants.mapCustomLabels.get(Fieldname.substring(1));
			MapDgColValues=addstudentclass.verifyStudentSearchresultsSorting(Fieldname);
			if (MapDgColValues!=null) 
				if (MapDgColValues.size()<1)
					NotVerified.add(Fieldname);
			
		}
		if (NotVerified.size()>0)
			UMReporter.log(Status.FAIL, "The following expected Class Student Table fields are not Sortable :"+NotVerified);
		else
			UMReporter.log(Status.PASS, "The following Session Student Table fields are Sortable :"+list);
	}
	
	@Then("^User able to access the list of Student in Add Students to Class page$")
	public void verify_Students_list_is_access_AddStudentsto_Class_page() throws Exception {
		UMReporter.log(Status.INFO, "Then : User able to access the list of Student in Add Students to Class page");
		List<String> MapDgStuColHeader=addstudentclass.verifyStusearchresultsDetails(3);
	    if (MapDgStuColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following students lists are accessed in Class details Page :"+MapDgStuColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The students are not found in list");
	}
	
	@Then("^Verify each Student record contains a checkbox in Add Students to Class page$")
	public void verify_student_list_checkboxis_displayed_AddStudentsto_Class() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify each Student record contains a checkbox in Add Students to Class page");
		List<String> MapDgOrgColHeader=addstudentclass.verifyStusearchresultsCheckbox(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The student lists contains checkbox :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The student are not found in list");
	}
	

	@Then("^Verify Add button is enabled in Add Students to Class page$")
	public void verify_Add_button_is_enabled_Class() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Add button is enabled in Add Students to Class page");
		 boolean btnCreatevisible=addstudentclass.AddButton_isEnabled();
		if(btnCreatevisible)
			UMReporter.log(Status.PASS, "Add button is enabled");
		else
			UMReporter.log(Status.FAIL, "Add button is not enabled");
	}
	@Then("^Verify Add button is visible and disabled in Add Students to Class page$")
	public void verify_Add_button_is_visible_but_disabled_Class() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Add button is visible and disabled in Add Students to Class page");
		boolean btnAddvisible = addstudentclass.AddButton_isVisible();
		if(btnAddvisible) {
			boolean btnAddenabled = addstudentclass.AddButton_isEnabled();
			if(btnAddenabled)
				UMReporter.log(Status.PASS, "Add button is visible and disabled");
			else
				UMReporter.log(Status.FAIL, "Add button is enabled without selecting record");
		}
		else
			UMReporter.log(Status.FAIL, "Add button is not visible");
		
	}
	
	@When("^Select the (.*) Students in Add Students to Class page$")
	public void Select_student_list_checkbox_AddStudentsto_Class(String Stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the "+Stucount+" Students in Add Students to Class page");
		int stucnt=1;
		if (CommonUtility.isNumeric(Stucount))
			stucnt=Integer.parseInt(Stucount);
		lstAddedStudent=addstudentclass.SelectonStuCheckbox(stucnt);
		iSelectedStudentCount=lstAddedStudent.size();
	    if (lstAddedStudent.size()>0)
	    	UMReporter.log(Status.PASS, "Selected the student checkbox "+lstAddedStudent);
	    else
	    	UMReporter.log(Status.FAIL, "The students are not found in list");
	}	
	
	@Then("^Verify the pagination in Student datagrid in Add Students to Class page$")
	public void Verify_student_list_Paginations_AddStudentsto_Class() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the pagination in Student datagrid in Add Students to Class page");
		int maxpage=addstudentclass.verifyStuGridPagination();
		if (maxpage>1) 
	    	UMReporter.log(Status.PASS, "The students lists pagination are upto max pages :"+maxpage);
	    else if(maxpage==1)
	    	UMReporter.log(Status.PASS, "The students list contains one page only.");
	    else
	    	UMReporter.log(Status.FAIL, "The students list pagination fails.");
	}
	
	@When("^User search the student (.*) in Add Students to Class page$")
	public void Fill_Searchtext_student_list_AddStudentsto_Class(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "When : User search the student in Add Students to Class page : "+SeachText);
		 boolean flag=addstudentclass.Searchfill_StudName(SeachText);
		 if (flag)
			 UMReporter.log(Status.PASS, "The Search text :"+SeachText);
		 else
		    UMReporter.log(Status.FAIL, "Unable to set search text in input field");
	}
	
	@When("^User select the search icon in Add Students to Class page$")
	public void Click_Searchicon_student_list_AddStudentsto_Class() throws Exception {
		UMReporter.log(Status.INFO, "When : User select the search icon in Add Students to Class page");
		boolean flag=addstudentclass.clicksearchicon();
	    if (flag)
	    	 UMReporter.log(Status.PASS, "Clicked the Search Icon");
		 else
		    UMReporter.log(Status.FAIL, "Unable to select search icon");
	}
	
	@Then("^verify the (.*) search Student results in Add Students to Class page$")
	public void Verify_Searchtext_in_student_list_AddStudentsto_Class(String SeachText) throws Exception {
		UMReporter.log(Status.INFO, "Then : verify the search Student results in Add Students to Class page : "+SeachText);
		 List<String> MapDgOrgDet=addstudentclass.verifyStudSearchresultsDetailsfromtext(SeachText);
		 if (MapDgOrgDet!=null)
	    	UMReporter.log(Status.PASS, "The Student lists matches the SeachText :"+MapDgOrgDet);
		 else
	    	UMReporter.log(Status.FAIL, "The Students are not found in list");
	
	}
	@Then("^Clear Search text field in Add Students to Class page$")
	public void Clear_Searchtextfield_student_list_AddStudentsto_Class() throws Exception {
		UMReporter.log(Status.INFO, "Then : Clear Search text field in Add Students to Class page");
		boolean flag=addstudentclass.ClearSearchText();
	    if (flag) {
	    	flag=addstudentclass.clicksearchicon();
	    	 UMReporter.log(Status.PASS, "Cleared the Search Text");
	    }
		 else
		    UMReporter.log(Status.FAIL, "Unable to Clear search Text");
	}
	
	@When("^Verify the selected student count displays as (.*) Students Selected in Add Students to Class page$")
	public void Verify_Selected_StuCount_Class_list(String Stucount) throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the selected student count displays as "+Stucount+" Students Selected in Add Students to Class page");
		int stucnt=0;
		 boolean flag=false;
		if (CommonUtility.isNumeric(Stucount))
			stucnt=Integer.parseInt(Stucount);
		 flag=addstudentclass.Verify_SelectedStudentCount(Stucount);
		 if (flag)
			 UMReporter.log(Status.PASS, "The selected student count display as :"+Stucount);
		 else
		 {
			 flag=addstudentclass.Verify_SelectedStudentCount(String.valueOf(iSelectedStudentCount));
			 if (flag)
				 UMReporter.log(Status.PASS, "The selected student count display as :"+iSelectedStudentCount);
			 else
				 UMReporter.log(Status.FAIL, "The selected student count mistached the actual");
		 }
	}
	
	@When("^Click on Cancel button in Add Students to Class page$")
	public void Click_Cancel_button_in_AddStudentsto_Class() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Cancel button in Add Students to Class page");
		boolean isbtnclicked = addstudentclass.clickCancelButton();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Selected the Cancel button");
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Cancel button");
		
	}
	
	@When("^Click on Add button in Add Students to Class page$")
	public void Click_Add_button_in_AddStudentsto_Class() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Add button in Add Students to Class page");
		boolean isbtnclicked = addstudentclass.clickAddButton();
		if(isbtnclicked) {
			UMReporter.log(Status.PASS, "Selected the Add button");
			while(addstudentclass.Verify_Progressbar_Visible())
			{
				CommonUtility._sleepForGivenTime(1000);
			}
		}
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Add button");
	}
	
	
	@Then("^Verify the failure message displayed in Add Students to Class as (.*)$")
	public void verify_error_message_gets_displayed_on_AddStudentsto_Class_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the error message displayed in Add Students to Class as " + messages);
		boolean flag;
		if (messages.contains("<X>")) 
			if (iSelectedStudentCount != 0) // Studentcount
				messages = messages.replace("<X>", String.valueOf(iSelectedStudentCount));
		flag = addstudentclass.verifyAlertMessage(messages);
		if (flag) 
			UMReporter.log(Status.PASS, "Verified the error message displayed in Add Students to Class page:" + messages);
		else
			UMReporter.log(Status.FAIL, "The error message is not matched with expected :" + messages);
	}
	
	@Then("^Verify the success message displayed in Class details page as (.*)$")
	public void verify_success_message_gets_displayed_on_AddStudentsto_Class_page(String messages) throws IOException {
		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Class details page as " + messages);
		boolean flag;
		if (messages.contains("<X>")) 
			if (iSelectedStudentCount != 0) // Studentcount
				messages = messages.replace("<X>", String.valueOf(iSelectedStudentCount));
		flag = addstudentclass.verifySuccessMessage(messages);
		if (flag) 
			UMReporter.log(Status.PASS, "Verified the success message displayed in Class details page:" + messages);
		else
			UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
	}
	
	@Then("^Verify the Selected Student details in Student list in Class details page$")
	public void verify_Selected_Student_in_Students_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Selected Student details in Student list in Class details page");
		List<String> NotVerified=null;
		if (lstAddedStudent!=null) {
			NotVerified=new ArrayList<String>();
			for (String stu:lstAddedStudent) {
				List<String> MapDgStuColHeader=Classdetail.verifyStudSearchresultsDetailsfromlist(stu);
				if (MapDgStuColHeader==null)
					NotVerified.add(stu);
			}
	    if (NotVerified.size()>0)
	    	UMReporter.log(Status.FAIL, "The following students lists are not verified in Class details Page :"+NotVerified);
	    else
	    	UMReporter.log(Status.PASS, "The following students lists are verified in Class details Page :"+lstAddedStudent);
		}
		else
			UMReporter.log(Status.FAIL, "The students are not found in list");
			
	}
	
	@Then("^Verify Remove Student button is enabled in Class details page$")
	public void verify_Remove_Student_button_is_enabled_Class() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify Remove Student button is enabled in Class details page");
		
		 boolean btnCreatevisible=Classdetail.RemoveStudentsButton_isEnabled();
		if(btnCreatevisible)
			UMReporter.log(Status.PASS, "Remove Student button is enabled");
		else
			UMReporter.log(Status.FAIL, "Remove Student button is not enabled");
	}
	
	@Then("^Verify Remove Student button is not visible in Class details page$")
	public void verify_Remove_Student_button_is_visible_but_disabled_Class() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify Remove Student button is not visible in Class details page");
		if (lstRemovedStudent!=null) {
			boolean btnAddvisible = Classdetail.RemoveStudentsButton_isVisible();
			if(!btnAddvisible) 
				UMReporter.log(Status.PASS, "Remove Student button is not visible before selecting record");
			else
				UMReporter.log(Status.FAIL, "Remove Student button is visible");
		}
		else
			UMReporter.log(Status.PASS, "The students are not found in list");
		
	}
	
	@When("^Click on Remove Students button in Class details page$")
	public void Click_RemoveStudents_button_in_ClassDetails() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on Remove Students button in Class details page");
		boolean isbtnclicked = Classdetail.clickRemoveStudentsButton();
		if(isbtnclicked) {
			UMReporter.log(Status.PASS, "Selected the Remove Students button");
			while(addstudentclass.Verify_Progressbar_Visible())
			{
				CommonUtility._sleepForGivenTime(1000);
			}
		}
		else
			UMReporter.log(Status.FAIL, "Uanable to click the Remove Students button");
	}
	
	@When("^Select the (.*) Students in Class Details page$")
	public void Select_student_list_checkbox_Class_Details_Class(String Stucount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the "+Stucount+" Students in Class Details page");
		int stucnt=1;
		if (CommonUtility.isNumeric(Stucount))
			stucnt=Integer.parseInt(Stucount);
		lstRemovedStudent=Classdetail.SelectonStuCheckbox(stucnt);
		iSelectedStudentCount=lstRemovedStudent.size();
	    if (lstRemovedStudent.size()>0)
	    	UMReporter.log(Status.PASS, "Selected the student checkbox "+lstRemovedStudent);
	    else
	    	UMReporter.log(Status.FAIL, "The students are not found in list");
	}	
	@Then("^Verify the Selected Students removed in Student list in Class details page$")
	public void verify_Selected_Student_in_Students_list_In_ClassDetails() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Selected Students removed in Student list in Class details page");
		List<String> removedStudent=null;
		if (lstRemovedStudent!=null) {
			removedStudent=new ArrayList<String>();
			for (String stu:lstRemovedStudent) {
				List<String> MapDgStuColHeader=Classdetail.verifyStudSearchresultsDetailsfromlist(stu);
				if(MapDgStuColHeader==null)
					removedStudent.add(stu);
				else if (MapDgStuColHeader.size()<1)
					removedStudent.add(stu);
			}
	    if (removedStudent.size()>0)
	    	UMReporter.log(Status.PASS, "The following students are removed in Student List of Class details Page :"+removedStudent);
	    else
	    	UMReporter.log(Status.FAIL, "The following students lists are not removed in Class details Page :"+lstRemovedStudent);
		}
		else
			UMReporter.log(Status.FAIL, "The students are not found in list");
			
	}
	
	@Given("^Navigate to Classes page$")
	public void navigate_to_Classes_page() throws Exception {
		UMReporter.log(Status.INFO, "Given : Navigate to Classes page");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		// Select Menu option Primary and secondary option
		home.MenuOtion("classes", "");
		//Verify the User list page displayed
		if(ClassMgmt.verifyClassMgmtPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Classes page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");

	}
	
	@Then("^Verify the list of Classes displayed in Classes page$")
	public void verify_Classes_list_is_access() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the list of Classes displayed in Classes page");
		List<String> MapDgOrgColHeader=ClassMgmt.verifyClassSearchresultsDetails(3);
	    if (MapDgOrgColHeader!=null)
	    	UMReporter.log(Status.PASS, "The following Class lists are accessed :"+MapDgOrgColHeader);
	    else
	    	UMReporter.log(Status.FAIL, "The Class are not found in list");
	}
	
	@When("^Click to remove the teacher$")
	public void Click_to_remove_the_teacher() throws Exception {
		UMReporter.log(Status.INFO, "When: Click to remove the teacher");
		boolean isbtnclicked = Classdetail.clicktoclearteacher();
		if(isbtnclicked)
			UMReporter.log(Status.PASS, "Removed the teacher from the Class");
		else
			UMReporter.log(Status.FAIL, "Unable to Remove the teacher from the Class");
		
	}
	

	@Then("^Verify delete button is enabled in Class list page$")
	public void verify_delete_button_is_Enabledvisible() throws Exception {
		UMReporter.log(Status.INFO, "Then: Verify delete button is enabled in Class list page");
		boolean deleteenabled = ClassMgmt.deleteButton_isEnabled();
		if(deleteenabled)
			UMReporter.log(Status.PASS, "Delete button is enabled");
		else
			UMReporter.log(Status.FAIL, "Delete button is disabled after selecting record");
	}
	
	@When("^Click on delete button in Class list page$")
	public void Click_Delete_button_in_ClassList() throws Exception {
		UMReporter.log(Status.INFO, "When: Click on delete button in Class list page");
		boolean isbtnclicked = ClassMgmt.clickDeleteButton();
		if(isbtnclicked) {
			UMReporter.log(Status.PASS, "Selected the delete button");
//			while(ClassMgmt.Verify_Progressbar_Visible())
//			{
//				CommonUtility._sleepForGivenTime(1000);
//			}
		}
		else
			UMReporter.log(Status.FAIL, "Unable to click the delete button");
	}
	
	@When("^Select the (.*) classes in Class list page$")
	public void Select_Class_list_checkbox_Class_list(String clscount) throws Exception {
		UMReporter.log(Status.INFO, "When : Select the "+clscount+" classes in Class list page");
		int stucnt=1;
		if (CommonUtility.isNumeric(clscount))
			stucnt=Integer.parseInt(clscount);
		lstSelectedClass=ClassMgmt.SelectonClassCheckbox(stucnt);
		iSelectedClassCount=lstSelectedClass.size();
	    if (lstSelectedClass.size()>0)
	    	UMReporter.log(Status.PASS, "Selected the Class checkbox "+lstSelectedClass);
	    else
	    	UMReporter.log(Status.FAIL, "The Classes are not found in list");
	}	
	@Then("^Verify the Classes are removed in Class list page$")
	public void verify_Selected_Class_Removed_Class_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Classes are removed in Class list page");
		List<String> deletedClass=null;
		if (lstSelectedClass!=null) {
			deletedClass=new ArrayList<String>();
			for (String cls:lstSelectedClass) {
				List<String> MapDgStuColHeader=ClassMgmt.verifyClassSearchresultsDetailsfromlist(cls);
				if(MapDgStuColHeader==null)
					deletedClass.add(cls);
				else if (MapDgStuColHeader.size()<1)
					deletedClass.add(cls);
			}
	    if (deletedClass.size()>0)
	    	UMReporter.log(Status.PASS, "The following classes are removed in Class List Page :"+deletedClass);
	    else
	    	UMReporter.log(Status.FAIL, "The following class lists are not removed in Class List Page :"+lstSelectedClass);
		}
		else
			UMReporter.log(Status.PASS, "The Classes are not found in list");
	}
	
	@Then("^Verify the Classes are not deleted in Class list page$")
	public void verify_Selected_Class_Not_Removed_Class_list() throws Exception {
		UMReporter.log(Status.INFO, "Then : Verify the Classes are not deleted in Class list page");
		List<String> deletedClass=null;
		if (lstSelectedClass!=null) {
			deletedClass=new ArrayList<String>();
			for (String cls:lstSelectedClass) {
				List<String> MapDgStuColHeader=ClassMgmt.verifyClassSearchresultsDetailsfromlist(cls);
				if(MapDgStuColHeader==null)
					deletedClass.add(cls);
				else if (MapDgStuColHeader.size()<1)
					deletedClass.add(cls);
			}
	    if (deletedClass.size()>0)
	    	UMReporter.log(Status.PASS, "The following class lists are not removed in Class List Page :"+lstSelectedClass);
	    else
	    	UMReporter.log(Status.FAIL, "The following classes are removed in Class List Page :"+deletedClass);
		}
		else
			UMReporter.log(Status.FAIL, "The Classes are not found in list");
	}
	
//	@Then("^Verify the (?:success|error) message displayed in Class list page as (.*)$")
//	public void verify_success_message_gets_displayed_on_ClassList_page(String messages) throws IOException {
//		UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Class list page as " + messages);
//		boolean flag;
//		if (messages.contains("<X>")) 
//			if (iSelectedClassCount != 0) // Classcount
//				messages = messages.replace("<X>", String.valueOf(iSelectedClassCount));
//		flag = ClassMgmt.verifySuccessMessage(messages);
//		if (flag) 
//			UMReporter.log(Status.PASS, "Verified the success message displayed in Class list page:" + messages);
//		else
//			UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
//	}
	
	@When("^Verify title and content (.*) in Confirmation Delete Class pop-up$")
	public void Verify_title_message_ConfirmPopUp_button(String confmessage) throws Exception {
		UMReporter.log(Status.INFO, "When :  Verify title and message in Confirm Delete Class pop-up");
		boolean flag=false;
		// Verify the Confirm pop up
		flag=CommonFunctions.VerifyConfirmPopupContent(Constants.DeleteClassConfirmPopupTitle,confmessage);
		if (flag)
			UMReporter.log(Status.PASS, "Verified Confirm Delete Class pop-up title and message : " +confmessage);
			
	}

	@When("^Click on confirm button on Confirmation Delete Class pop-up$")
	public void Click_confirm_on_ConfirmDeleteOrgpopup() throws Exception {
		UMReporter.log(Status.INFO, "When :  Click on confirm button on Confirmation Delete Class pop-up");
			// Verify the Click Confirm in pop up
		boolean flag=CommonFunctions.ConfirmPopupActionBtn("Confirm");
		CommonUtility._sleepForGivenTime(3000);
			if (flag) {
				
				flag=ClassMgmt.waitForProgressbarVisible(20);
				if(flag) 
					UMReporter.log(Status.PASS, "Select the Confirm button and navigated to Class list page" );
				else
					UMReporter.log(Status.PASS, "Progress bar is displayed for long time after delete");
				
			}
			else
				UMReporter.log(Status.FAIL, "Select the Confirm button and Class list not displayed " );
	}

	@When("^Click on cancel button on Confirmation Delete Class pop-up$")
	public void Click_cancel_on_ConfirmDeleteOrgn_button() throws IOException {
		UMReporter.log(Status.INFO, "When :  Click on cancel button on Confirmation Delete Class pop-up");
		
			// Verify the Click cancel in pop up
			boolean flag=CommonFunctions.ConfirmPopupActionBtn("Cancel");
			CommonUtility._sleepForGivenTime(3000);
			if (flag) 
				UMReporter.log(Status.PASS, "Select the Cancel button and pop up is closed " );
			else
				UMReporter.log(Status.FAIL, "Select the Cancel button and pop up is not closed " );
	}
	

@When("^User select the student from Student list in Class Details Page$")
	public void user_clicks_on_ClassStudentList() throws Exception  {
		UMReporter.log(Status.INFO, "When :User selects the first record in Student datagrid");
		boolean flag=false;
		HashMap<String,String> MapOrgField=null;
		MapclassStuFields=Classdetail.getStudsearchresultsDetails(1);
		// Get Student Search results by row number
		if(MapclassStuFields!=null) {
			if (MapclassStuFields.containsKey("Student Name")) {
				String StudName=MapclassStuFields.get("Student Name");
				String NameSplit[]=StudName.split(", ");
       		  	if (NameSplit.length>=1){
       			  String Lname=NameSplit[0].trim();
       			  MapclassStuFields.put("Last Name", Lname);
       			  String FMname=NameSplit[1];
       			  String FMNameSplit[]=FMname.split(" ");
       			  if (FMNameSplit.length>1){
       				String Fname=FMNameSplit[0].trim();
       				MapclassStuFields.put("First Name", Fname);
       			 	String Mname=FMNameSplit[1].trim();
       			 	MapclassStuFields.put("Middle Name", Mname);
       			  }
       			  else
       				MapclassStuFields.put("First Name", FMname.trim());
       		  	}
		       	//Click on Student Name hyperlink on Org list page
				flag=Classdetail.clickonStudName(MapclassStuFields.get("Student Name"));
				//Check the Student selected
				if(flag) {
					//CommonUtility._sleepForGivenTime(2000);
					UMReporter.log(Status.PASS,"Selected the Student name "+MapclassStuFields.get("Student Name")+" hyperlink in Student list");
				}
				else
					UMReporter.log(Status.FAIL,"The Student name "+MapclassStuFields.get("Student Name")+"  not found in Student list");	
			}
		}
		else
			UMReporter.log(Status.FAIL,"No records found in Student list");	
	}

@Then("^Verify the Student name is displayed in Student details page from class details page$")
public void verify_Student_name_in_details_page_is_displayed() throws IOException  {
	UMReporter.log(Status.INFO, "Then : Verify the Student name is displayed in Student details page ");
	if (MapclassStuFields!=null) {
		if (MapclassStuFields.containsKey("Student Name")) {
			String StudName=MapclassStuFields.get("Student Name");
//		if ((MapStuFields.containsKey("Last Name"))&&(MapStuFields.containsKey("First Name"))&&(MapStuFields.containsKey("Middle Name"))) {
//			String StudName=MapStuFields.get("Last Name")+", "+MapStuFields.get("First Name")+" "+MapStuFields.get("Middle Name");
			if(studentdetail.verifyStudentName(StudName.trim()))
				UMReporter.log(Status.PASS,"Verified the Student name in Student details page :"+StudName);
			else
				UMReporter.log(Status.FAIL,"The Student name not found in Student details page :"+StudName);
		}
	}
    else
    	UMReporter.log(Status.SKIP,"No Student record exist");
}

@Then("^Verify the selected Student field values from Class details page$")
public void verify_Selected_Student_details_is_displayed() throws IOException  {
	UMReporter.log(Status.INFO, "Then : Verify the selected Student field values in Student details page ");
	if (MapclassStuFields!=null) {
		//Verify the Student details page displayed
		studentdetail.verifyViewStudentDetails(MapclassStuFields);
	}
    else
    	UMReporter.log(Status.SKIP,"No Student record exist");
}

@Then("^User direct url navigation to Create Class page$")
public void User_redirect_Createclass_page_is_displayed() throws IOException  {
	UMReporter.log(Status.INFO, "Then : User direct url navigation to Create Class page");
	home.AppendUrlDirectPageNavigate();
	//Verify the Class Detail page displayed
	if(createclass.verifyCreateClassPageNavigation())
		UMReporter.log(Status.PASS,"User is navigated to Create Class page");
    else
    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
}

@Given("^User permissions in Classes page$")
public void User_Permission_in_Classes_page() throws Exception {
	
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
		throw new RuntimeException("Login fail!");
	}
	List<String> LstUserPermissions=Constants.PERMISSIONS;

	//Switch Org
	String OrgName=FileReaderManager.getInstance().getJsonReader().getSelectOrgName("District"); 
	//Change the Org Details if not expected
	if (!home.Func_VerifyOrgName(OrgName)) 
		home.Func_ChangeOrganization(OrgName);
	
	if (LstUserPermissions.contains("ACCESS_CLASSES")) {
		
		UMReporter.log(Status.INFO, "Given : User permissions in Classes page");
		home.MenuOtion("classes", "");
		//Verify the User list page displayed
		if(ClassMgmt.verifyClassMgmtPageNavigation()) {
			UMReporter.log(Status.PASS,"User have access classes option in the hamburger menu");
			List<String> MapDgOrgColHeader=ClassMgmt.verifyClassSearchresultsDetails(1);
		    if (MapDgOrgColHeader!=null)
		    	UMReporter.log(Status.PASS, "User have access to view list of Classes : "+MapDgOrgColHeader);
		}
		
		if (LstUserPermissions.contains("CREATE_CLASS")) {
			if(ClassMgmt.VerifyTabOption_isVisible("Create Class")) { 
				UMReporter.log(Status.PASS, "User have access to Create Class, Create button is visible");
//				ClassMgmt.SelectTabOption("Class List");
//				CommonUtility._sleepForGivenTime(2000);
			}
			else
				UMReporter.log(Status.SKIP, "User have access to Create Class, Create Class Tab is not visible");		
		}
		
		if (LstUserPermissions.contains("DELETE_CLASS")) {
			lstSelectedClass=ClassMgmt.SelectonClassCheckbox(1);
		    if (lstSelectedClass.size()>0) {
				if(ClassMgmt.deleteButton_isVisible())
					UMReporter.log(Status.PASS, "User have access to Delete Class, Delete button is displayed when selected the class "+lstSelectedClass);
				else
					UMReporter.log(Status.FAIL, "User have access to Delete Class, Delete button is not visible");
		    }
		    else
		    	UMReporter.log(Status.SKIP, "User have access to Delete Class, Unable to select Class checkbox");
		    
		}
		
		if (LstUserPermissions.contains("ACCESS_CLASSES")) {
				// Get Class Search results by row number
				MapClassField=ClassMgmt.SelectClasslistRecord();
				if(MapClassField!=null) {
					if(Classdetail.verifyClassDetailsNavigation()) {
						Classdetail.verifyViewClassDetails(MapClassField);
						
						if (LstUserPermissions.contains("EDIT_CLASS")) {
							if(Classdetail.EditButton_isVisible())
								UMReporter.log(Status.PASS, "User have access to Edit Class, Edit button is displayed");
							else
								UMReporter.log(Status.FAIL, "User have access to Edit Class, Edit button is not displayed");
						}
						
						if (LstUserPermissions.contains("ACCESS_CLASSES")) {
							if(Classdetail.Verify_Class_StudentList())
								UMReporter.log(Status.PASS,"User have access to View Student List in Class details page");
							
							if (LstUserPermissions.contains("CLASS_ADD_STUDENTS")) {
								if(Classdetail.AddStudentsButton_isVisible())
									UMReporter.log(Status.PASS, "User have access to Add Student to a Class, Add Students button is displayed");
								else
									UMReporter.log(Status.FAIL, "User have access to Add Student to a Class,  Add Students button is not displayed");
							}
							
							if (LstUserPermissions.contains("CLASS_REMOVE_STUDENTS")) {
								lstRemovedStudent=Classdetail.SelectonStuCheckbox(1);
							    if (lstRemovedStudent.size()>0) {
									if(Classdetail.RemoveStudentsButton_isVisible())
										UMReporter.log(Status.PASS,  "User have access to Remove Student from Class, Remove Students button is displayed");
									else
										UMReporter.log(Status.FAIL,  "User have access to Remove Student from Class, Remove Students button is not displayed");
							    }
								else
									UMReporter.log(Status.SKIP, "User have access to Remove Student from Class,  Not students found");
							}
							
							if (LstUserPermissions.contains("VIEW_STUDENT_PROFILE")) {
								MapclassStuFields=Classdetail.SelectClassStudentRecord();
								if(MapclassStuFields!=null) {
									if(studentdetail.verifyStudentDetailsNavigation())
										UMReporter.log(Status.PASS, "User have access to View Student Profile, Student detail : "+MapclassStuFields);
								}
								else
									UMReporter.log(Status.SKIP, "User have access to SelectClassStudentRecord,  No students records");
							}
						}
						
					}
						
					
					else
						UMReporter.log(Status.FAIL,"The Class details is not displayed");	
				}
				else
					UMReporter.log(Status.SKIP,"No records found in Class list");
		
		}
			
	}
	else
		UMReporter.log(Status.PASS,"User restricted for classes");
		
}


@Then("^Verify accoms capsule clickable in Student results in Class details page$")
public void verify_accoms_capsule_clickable() throws Exception{
	UMReporter.log(Status.INFO, "Then : Verify accoms capsule clickable in Student results in Class details page");
	boolean flag = Classdetail.clickaccomLink();
    if (flag)
    	UMReporter.log(Status.PASS, "Accoms capsule is clickable for the student");
    else
    	UMReporter.log(Status.FAIL, "Accoms capsule not clickable for the student");
}

@Then("^Verify accoms capsule can be closable in Student results in Class details page$")
public void verify_accoms_capsule_closable() throws Exception{
	UMReporter.log(Status.INFO, "Then : Verify accoms capsule closable in Student results in Class details page");
	boolean flag = Classdetail.clickaccomClose();
    if (flag)
    	UMReporter.log(Status.PASS, "Accoms capsule can be closable for the student");
    else
    	UMReporter.log(Status.FAIL, "Unable to close accoms capsule for the student");
}
@When("^User select and verify the accommodation capsule in student list in Class details page$")
public void user_select_verify_first_Students_Accomm_StudentList_in_ClassDetail_Page() throws Exception  {
	UMReporter.log(Status.INFO, "When :User select and verify the accommodation capsule in student list in Class details page");
	boolean flag=false;
	HashMap<String,String> MapStuAccomField=null;
	// Get Student Search results by row number
	MapStuAccomField=Classdetail.SelectStudentWithAccomCapsule("Accom");
	if(MapStuAccomField!=null) {
		if (CommonFunctions.VerifyConfirmPopupDisplayed()) {
			List<String> accomlist=CommonFunctions.GetDailogContent();
			CommonFunctions.CloseDialog();
			UMReporter.log(Status.PASS,"The Accommodation details displayed for Student name "+MapStuAccomField.get("Student Name")+" are "+accomlist);
		}
		else
			UMReporter.log(Status.SKIP,"The Accommodation details not displayed after selecting Accommodation capsule for Student name "+MapStuAccomField.get("Student Name"));
	}
	else
		UMReporter.log(Status.SKIP,"No student with accom capsule records found in Student list");	
	
}

@Given("Click on View the new class now link in Create Class Page")
public void click_on_View_the_new_student_now_link() throws Exception {
	UMReporter.log(Status.INFO, "When : Click on View the new class now link in Create Class Page");
	ClassMgmt.ClickSuccessLink();
	UMReporter.log(Status.PASS, "Selected View the new class now link");
}

@Then("^Verify the success message displayed in Create Class page as (.*)$")
public void verify_success_message_gets_displayed_on_CreateClass_page(String messages) throws IOException {
	UMReporter.log(Status.INFO, "Then : Verify the success message displayed in Create Class page as " + messages);
	boolean flag;
	flag = ClassMgmt.verifySuccessMessage(messages);
	if (flag) 
		UMReporter.log(Status.PASS, "Verified the success message displayed in Class list page:" + messages);
	else
		UMReporter.log(Status.FAIL, "The success message is not matched with expected :" + messages);
}

}




