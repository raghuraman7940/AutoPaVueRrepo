package com.pauir.StepDefinitions;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.aventstack.extentreports.Status;
import com.pauir.PageDefinitions.Admin.AdminHome;
import com.pauir.PageDefinitions.home.Home;
import com.pauir.PageDefinitions.home.DRSHome;
import com.pauir.PageDefinitions.home.DrilldownPage;
import com.pauir.PageDefinitions.login.Login;
import com.pauir.PageDefinitions.organizations.ManageOrganizationsPage;
import com.pauir.PageDefinitions.students.StudentListPage;
import com.pauir.PageDefinitions.users.ManageUsersPage;
import com.pauir.Request.API.DriverScript;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.util.Constants;
import com.pauir.common.util.RequestMethod;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.BeforeStep;
import cucumber.api.java.AfterStep;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import webdriver.main.WebDriverMain;
import static com.pauir.runner.MultiTestRunner.Browsertype;
import static com.pauir.runner.MultiTestRunner.ThdUserole;
import static com.pauir.runner.MultiTestRunner.ThdLoggedinFlag;

public class CommonSteps {
	
	
	
	UMReporter classReport;
	static boolean FFBrowser = false;
	static boolean CHBrowser = false;
	public static Login login;
	public static Home home;
	public static DrilldownPage drilldownpage;
	public static AdminHome adminhome;
	public static CommonFunctions common;
	public static boolean LoggedinFlag=false;
	public static boolean LoggedinAdminFlag=false;
	public static String LoggedinUsername=null;
	public static String LoggedinUserrole=null;
	public static String ScopeProgram;
	public static String ScopeYear;
	public static String ScopeAdmin;
	public static String JSESSIONID;
	public static ManageOrganizationsPage manageorgs;
	public static StudentListPage studentlist;
	public static ManageUsersPage manageusers;
	public static String CurrentWinHnd=null;
	public static HashMap<String, String> APIAUTHheaders =null;
	public static RequestMethod requests;
	public static DriverScript driverscript;
	public static long threadId;
	public static List<String> PERMISSIONS = Arrays.asList("ACCESS_TEST_SESSIONS","ACCESS_HIGH_STAKES","ACCESS_LOW_STAKES","DELETE_TEST_SESSIONS","CREATE_TEST_SESSIONS","SESSIONS_EDIT_SESSION","SESSIONS_ADD_STUDENTS","SESSIONS_REMOVE_STUDENTS","SESSIONS_UPDATE_STUDENT_TEST_STATUS","SESSIONS_PRINT_AUTH_TICKETS","SESSIONS_RESET_STUDENT_PASSWORD","SESSIONS_VIEW_STUDENT_PROFILE","SESSIONS_ACCESS_HAND_SCORE","SESSIONS_ACCESS_REPORTS","SESSIONS_DOWNLOAD_TEST_FORM","TEST_ATTEMPT_PROCTOR_STATUS_UPDATE","EXTERNAL_SYSTEM","ACCESS_STUDENT_TESTSESSIONS","CREATE_STUDENT_TEST_SESSION_IRREGULARITY","CREATE_UPDATE_ACCOM","VIEW_ACCOM_LIST","CREATE_IRREGULARITY","VIEW_ORGANIZATION_DETAILS");
	public static DRSHome drshome;
	public CommonSteps()throws IOException, NoSuchMethodException, SecurityException{
		
		
		//Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home= new Home();
		drilldownpage=new DrilldownPage();
		adminhome= new AdminHome();
		manageorgs=new ManageOrganizationsPage();
		manageusers=new ManageUsersPage();
		studentlist=new StudentListPage();
		requests=new RequestMethod();
		driverscript=new DriverScript();
		drshome=new DRSHome();
		
	
	}
	
	@Before
	public void beforeScenario(Scenario scenario) throws IOException {
		try{
			//Feature and Scenario Properties Setup
			String ScenarioName = "Scenario : ";
			String ReportDes=null;
			String ScenarioTags="";
			ScenarioName = ScenarioName + scenario.getName();
			String featureName =" Feature ";
			String strBrowser=null;
			String strUserrole="";
		    String rawFeatureName = scenario.getId().split("/Features/")[1].replace("/"," ");
		    rawFeatureName = rawFeatureName.split(".feature")[0].replace("_"," ");
		    
		    rawFeatureName=rawFeatureName.replace("TestSuites", "");
		    //Get Tags Names
		    Collection<String> lstTgs=scenario.getSourceTagNames();
		    for (String str:lstTgs)
		    	ScenarioTags=str+" "+ScenarioTags;
		    
		    featureName = featureName + rawFeatureName; 
		    String RunEnvironment=FileReaderManager.getInstance().getConfigReader().getEnvironment();
		    Constants.OSTYPE=FileReaderManager.getInstance().getConfigReader().getOSType();
		    threadId = Thread.currentThread().getId();
		    strBrowser=Browsertype.get();
//		    strUserrole=Constants.LOGGEDINUSERROLE;
		    if (ThdUserole.get()!=null)
		    	strUserrole=ThdUserole.get();
		    
//		    Constants.LOGGEDINUSERROLE=strUserrole;
	   	 	System.out.println(ScenarioName+" - " +strUserrole +" - " +strBrowser + " - " +RunEnvironment+" - "+threadId);
	   	 	//Get Browser Type
	   	 	if ((strBrowser.equalsIgnoreCase("CHROME"))&&(strUserrole.length()>2)) {
	   	 		CHBrowser=true;
	   	 		featureName=featureName + " <span class='categoryChrome'>"+strBrowser+"<p hidden>"+ threadId + "</p>"+ "</span><span class='categoryBrowser '>"+ strUserrole + "</span>";
	   	 	}
	   	 	else if (strBrowser.equalsIgnoreCase("CHROME")) {
	   	 		CHBrowser=true;
	   	 		featureName=featureName + " <span class='categoryBrowser'>"+strBrowser+"<p hidden>"+ threadId + "</p>"+ "</span>";
	   	 	}
	   	 	else if(strBrowser.equalsIgnoreCase("FIREFOX")) {
	   	 		FFBrowser=true;
	   	 		featureName=featureName + " <span class='categoryBrowser'>"+strBrowser+"<p hidden>"+ threadId + "</p>"+ "</span>";
	   	 	}
	   	 	else
	   	 		featureName=featureName + " <span class='categoryBrowser'>"+strBrowser+"<p hidden>"+ threadId + "</p>"+ "</span>";
	   	 	
	   	 	//Get Report Description
	   	 if (featureName.contains("Regression"))
	   		ReportDes="Regression Test - Scenarios: "+ScenarioTags;
	   	 else if(featureName.contains("smoke"))
		   	ReportDes="Smoke Test - Scenarios: "+ScenarioTags;
	   	 else if(featureName.contains("Functional"))
	   		ReportDes="Functional Test - Scenarios: "+ScenarioTags;
	   	 else 
	 		ReportDes="Regression Test - Scenarios: "+ScenarioTags;
	   	 
			//Initialize Feature report	   	 	
			classReport = new UMReporter(featureName , ReportDes, Constants.REPORTTYPE);
			//Initialize Feature scenario report
			UMReporter.initTest(featureName,ScenarioName,Constants.REPORTTYPE,strBrowser,RunEnvironment,Constants.OSTYPE,ScenarioTags);
			
		}catch(Exception ex){
			ex.printStackTrace();
			//System.out.println("Before Scenario Exception wantstoquit");   
		} 
	}
	
	@After(order = 1)
	public void afterScenario(Scenario scenario) {
		System.out.println("Scenario : "+scenario.getName()+" => "+scenario.getStatus());
		//CommonSteps.wantsToQuit = true == scenario.isFailed();
		//System.out.println("@After scenarios1 :");  
		
	}
	
	@After(order = 0)
	public void AfterSteps() throws InterruptedException {
		//System.out.println("@After scenarios :");   	 
		UMReporter.appendParent();
		
	}

	@BeforeStep
	public void BeforeStep(Scenario scenario) throws InterruptedException, IOException {
		String CurrentScenario=scenario.getName();
		//System.out.println("@@BeforeStep : "+scenario.getName()+"Loggedflag: "+Constants.Loggedinflag+" Threadid: "+threadId); 
		if ((CurrentScenario.equalsIgnoreCase("Login Page Setup"))||(CurrentScenario.contains("Login Page Setup"))) {
			//System.out.println("Login Page Setup - Issue Error handling"); 
		}
		else {
			if (!Constants.Loggedinflag) {
				UMReporter.log(Status.SKIP,"Skipped scenario due to login failed.");
				throw new RuntimeException("Login fail");
			}
			
		}
	}
	@AfterStep
	public void AfterStep() throws InterruptedException {
		//System.out.println("@@@AfterStep :");   	 
		
	}

@Given("^Launch the PA Refresh Site$")
public void Login_Into_NewPAUIR_Site_() throws IOException {
	
	UMReporter.log(Status.INFO, "Given : Launch the PA Refresh Site");
		//System.out.println("Before Login:"+LoggedinFlag);
	  
		//Launch PAUIR Site
		login.NavigatetoURL();
		
		CommonUtility._sleepForGivenTime(2000);
		
		//Verify the logged in Home Page
		home.WaitLoggedinHomePage();
		LoggedinFlag=home.VerifyLoggedinHomePage();
		if (LoggedinFlag) {
			UMReporter.log(Status.PASS,"PAUIR Home page is displayed Successfully");
		}
		else
			UMReporter.log(Status.FAIL,"logged in Failed");
	
}


@Given("^Launch the PA Refresh Site and login with admin user$")
public void Login_Into_PAUIR_Site_() throws IOException {
UMReporter.log(Status.INFO, "Given : Launch the PAUIR Site and login with admin user");
	String StrUserdetails=null;
	String StrUserPwd=null;
	//Launch Google Test Site for Jenkin launch Validation
	//StrUserdetails=login.NavigatetoTestURL();
	//if (StrUserdetails==null)
	//Launch PAUIR Site
	StrUserdetails=login.NavigatetoURL();
	
	//Check PA site to support launched Browsers
	if (login.IsLoginToPAExist()) {
		String BrowserCheck=login.GetBrowserHeaderSysCheck();
		System.out.println("Browser Check : "+BrowserCheck);  
		//Select Login into Pearson Access Link
		login.ClickLoginToPA();
		
	}
	
	//Check if already in home pge 
	LoggedinFlag=home.VerifyLoggedinHomePage();
	if (!LoggedinFlag) {
		//Login into the Site
		//login.doSignIn();
		StrUserPwd=login.doOneLogin();
		StrUserdetails=StrUserdetails+StrUserPwd;
	}
	
	CommonUtility._sleepForGivenTime(2000);
	
	//Verify the logged in Home Page
	home.WaitLoggedinHomePage();
	LoggedinFlag=home.VerifyLoggedinHomePage();
	if (LoggedinFlag) {
		//Verify Navigation and Org selector loaded in page else reload
		home.VerifyMenuOptions();
		Constants.Loggedinflag=true;
		ThdLoggedinFlag.set(true);
		LoggedinUsername=StrUserPwd;
		LoggedinUserrole=Constants.LOGGEDINUSERROLE;
		Constants.mapCustomLabels= requests.GetDefaultCustomlabels();
		UMReporter.log(Status.PASS,"logged in Successfully with login details : "+StrUserdetails);
	}
	else {
		
		System.out.println("Login Failed : "+StrUserdetails);   
		UMReporter.log(Status.FAIL,"logged in Failed "+StrUserdetails);
		throw new RuntimeException("Login failed!");
	}

}

@Given("^Logout the PA Refresh Site$")
public void Logout_close_browser() throws IOException {

	UMReporter.log(Status.INFO, "Given : Logout and close browser");
	//home.MenuOtion("home", "");
	//home.Logout();

	System.out.println("Logout the PA Refresh Site LoggedinFlag: "+LoggedinFlag+" ConstantLoggedinflag: "+Constants.Loggedinflag+" Thread :"+threadId);
	
	if (LoggedinFlag){
		LoggedinFlag=false;
		Constants.Loggedinflag=false;
		ThdLoggedinFlag.set(false);
		home.Logout();
		UMReporter.log(Status.PASS,"logout Successfully");
	}
	else
		UMReporter.log(Status.FAIL,"LogIn Failed.");
		
}

@Given("^Navigate to Home page$")
public void navigate_to_Home_page() throws Exception {
	 
	UMReporter.log(Status.INFO,"Navigate to Home page");
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	home.SelectCustomerLogo();
	//home.MenuOtion("home", "");
	//Verify the home page displayed
	boolean flag=home.VerifyLoggedinHomePage();
	if(flag)
		UMReporter.log(Status.PASS,"Navigated to Home page");
    else
    	UMReporter.log(Status.FAIL,"Unable to Navigate to Home page");
}

@Given("^Return to Home page$")
public void return_to_Home_page() throws Exception {
		UMReporter.log(Status.INFO,"Navigate to Home page");
		home.SelectCustomerLogo();
		//home.MenuOtion("home", "");
		//Verify the User list page displayed
		boolean flag=home.VerifyLoggedinHomePage();
		if(flag)
			UMReporter.log(Status.PASS,"Navigated to Home page");
	    else
	    	UMReporter.log(Status.FAIL,"Unable to Navigate to Home page");

}

@Given("^Navigate to Organizations Management page$")
public void navigate_to_Organizations_page() throws Exception {
	 
	UMReporter.log(Status.INFO, "Given : Navigate to Manage Organizations page");
	
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	boolean flag=home.VerifyLoggedinHomePage();;
	if (flag) {
		// Select Menu option Primary and secondary option
		home.MenuOtion("organizations", "districts");
		//Verify the User list page displayed
		if(manageorgs.verifyManageOrgsPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Manage Organizations page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	else if (manageorgs.verifyManageOrgsPageNavigation()) {
		UMReporter.log(Status.PASS,"Navigated to Organizations page");
	}
}

@Given("^Navigate to Organization details page$")
public void navigate_to_OrganizationDetail_page() throws Exception {
	UMReporter.log(Status.INFO, "Given : Navigate to Organization Detail page");
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	boolean flag=home.VerifyLoggedinHomePage();;
	if (flag) {
		// Select Menu option Primary and secondary option
		home.MenuOtion("organizations", "My");
		//Verify the User list page displayed
		if(manageorgs.verifyOrgDetailsPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Organization Details page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	else if (manageorgs.verifyOrgDetailsPageNavigation()) {
		UMReporter.log(Status.PASS,"Navigated to Organizations page");
	}
}

@Given("^User set the default in Project Switcher$")
public void user_select_the_Customer() throws IOException {	
	UMReporter.log(Status.INFO, "Given : User set the default in Project Switcher");
	//Set Customer

	if (LoggedinFlag) {
		String CusName=FileReaderManager.getInstance().getJsonReader().getApplicationCustomer();
		
		//Verify the Customer Name
		boolean bVerifiedFlag =home.Func_VerifyCusName(CusName);
		
		//Change the Customer Name if not expected
		if (!bVerifiedFlag) 
			bVerifiedFlag=home.Func_ChangeCustomer(CusName);
			
		HashMap<String,Object> MapPerfLogs=  new HashMap<String,Object>();
		MapPerfLogs.put("Content-Type", "application/json");
		
		String custrefid=CommonFunctions.getTestData("customerrefid");
		Constants.mapCustomLabels=requests.GetEnv_CustomLabels(MapPerfLogs,custrefid);
		requests.UpdateConstantsCustomlabels();
		
		if (Constants.APIheaders==null) 
			Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
		
		UMReporter.log(Status.PASS,"Selected the Project Name =>  "+CusName);
	}
	else
		UMReporter.log(Status.FAIL,"Login failed. Navigated to unexpected page");
		
	
}
@Given("^User set the default in Organization Selector$")
public void user_select_the_Organization_details() throws IOException {	
	UMReporter.log(Status.INFO, "Given : User set the default in Organization Selector ");
	//Set Program, Year and Admin class variable
	if (LoggedinFlag) {
		String OrgName=FileReaderManager.getInstance().getJsonReader().getApplicationOrganization();
		
		//Verify the Org Details
		boolean bVerifiedFlag =home.Func_VerifyOrgName(OrgName);
		
		//Change the Org Details if not expected
		if (!bVerifiedFlag) 
			home.Func_ChangeOrganization(OrgName);
			
		//Constants.ORG_STATE=home.GetStatefromOrgName(OrgName);
		UMReporter.log(Status.PASS,"Selected the Org details =>  "+OrgName);
	}
	else
		UMReporter.log(Status.FAIL,"Login failed. Navigated to unexpected page");
	
}

@Given("^User set the (.*) Organization in Organization Selector$")
public void user_select_the_Provided_Organization_details(String OrgName) throws IOException {
	
	UMReporter.log(Status.INFO, "Given :User set the Organization in Organization Selector: "+OrgName);
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	
	//Verify the Org Details
	boolean bVerifiedFlag =home.Func_VerifyOrgName(OrgName);

	//Change the Org Details if not expected
	if (!bVerifiedFlag) 
		home.Func_ChangeOrganization(OrgName);
	
	//Constants.ORG_STATE=home.GetStatefromOrgName(OrgName);	
	UMReporter.log(Status.PASS,"Selected the Org details =>  "+OrgName);
	
}

@Given("^User set the (.*) Project in Project Switcher$")
public void user_select_the_Provided_Customer(String CusName) throws IOException {
	
	UMReporter.log(Status.INFO, "Given :User set the Project in Project Switcher: "+CusName);
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	

	//Verify the Customer Name
	boolean bVerifiedFlag =home.Func_VerifyCusName(CusName);
	//Change the Customer Name if not expected
	if (!bVerifiedFlag) 
		bVerifiedFlag=home.Func_ChangeCustomer(CusName);
		
	UMReporter.log(Status.PASS,"Selected the Customer =>  "+CusName);
	
}

@Given("^Launch the PA Refresh Admin Site and login with user$")
public void Login_Into_PAUIR_Admin_Site_() throws IOException {
UMReporter.log(Status.INFO, "Given : Launch the PA Refresh Admin Site and login with user");

	//Launch PAUIR Admin Site
	login.NavigatetoAdminURL();
	
	LoggedinAdminFlag=adminhome.VerifyLoggedinAdminHomePage();
	if (!LoggedinAdminFlag) 
		//Login into the Site
		login.doAdminLogin();
	
	CommonUtility._sleepForGivenTime(5000);
	
	//Verify the logged in Admin Home Page
	adminhome.WaitLoggedinAdminHomePage();
	LoggedinAdminFlag=adminhome.VerifyLoggedinAdminHomePage();
	if (LoggedinAdminFlag) {
		UMReporter.log(Status.PASS,"logged in Successfully");
	}
	else
		UMReporter.log(Status.FAIL,"logged in Failed");

}

@Given("^Logout the PA Refresh Admin Site$")
public void Admin_Logout_close_browser() throws IOException {

	UMReporter.log(Status.INFO, "Given : Logout the PA Refresh Admin Site");
	adminhome.MenuOtion("home", "");
	if (LoggedinFlag){
		LoggedinFlag=false;
		//home.Logout();
		UMReporter.log(Status.PASS,"logout Successfully");
	}
}

@Given("^Navigate to Admin Home page$")
public void navigate_to_Admin_Home_page() throws Exception {
		UMReporter.log(Status.INFO,"Given: Navigate to Admin Home page");
		adminhome.MenuOtion("home", "");
		//Verify the User list page displayed
		boolean flag=adminhome.VerifyLoggedinAdminHomePage();
		if(flag)
			UMReporter.log(Status.PASS,"Navigated to Admin Home page");
	    else
	    	UMReporter.log(Status.FAIL,"Unable to navigate to Admin Home page");

}

@Given("^Navigate to Test Management page$")
public void navigate_to_TestManagement_page() throws Exception {
	UMReporter.log(Status.INFO, "Given : Navigate to Test Management page");
	boolean flag=adminhome.VerifyLoggedinAdminHomePage();;
	if (flag) {
		// Select Menu option Primary and secondary option
		adminhome.MenuOtion("product management", "test management");
		//Verify the User list page displayed
		if(adminhome.verifyTestMgmtPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Test Management page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	else if (adminhome.verifyTestMgmtPageNavigation()) {
		UMReporter.log(Status.PASS,"Navigated to Test Management page");
	}
}

@Given("^Navigate to Customer Management page$")
public void navigate_to_CustomerManagement_page() throws Exception {
	UMReporter.log(Status.INFO, "Given : Navigate to Customer Management page");
	boolean flag=adminhome.VerifyLoggedinAdminHomePage();;
	if (flag) {
		// Select Menu option Primary and secondary option
		adminhome.MenuOtion("customer management", "");
		//Verify the User list page displayed
		if(adminhome.verifyCustMgmtPageNavigation())
			UMReporter.log(Status.PASS,"User is navigated successfully to Customer Management page");
	    else
	    	UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	}
	else if (adminhome.verifyTestMgmtPageNavigation()) {
		UMReporter.log(Status.PASS,"Navigated to Customer Management page");
	}
}

@Given("^Verify home page is displayed$")
public void Verify_Home_page() throws Exception {
		UMReporter.log(Status.INFO,"Then : Verify home page is displayed");
		if (LoggedinFlag){
		//Verify the home page page displayed
		boolean flag=home.VerifyLoggedinHomePage();
		if(flag)
			UMReporter.log(Status.PASS,"Navigated to Home page");
	    else
	    	UMReporter.log(Status.FAIL,"Unable to Navigate to Home page");
		}
		else
			UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
}


@Given("^Navigate to View Reports page$")
public void Navigate_View_Reports_page() throws Exception {
		UMReporter.log(Status.INFO,"Then : Navigate to View Reports page");
		if (LoggedinFlag){
			CurrentWinHnd=CommonFunctions.GetCurrentWindowHandle();
			home.MenuOtion("Reports", "");
			UMReporter.log(Status.PASS,"Navigated to Home page");
		}
		else
			UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
	
}

@Then("^Verify it opens reporting application in a separate tab$")
public void Verify_View_Reports_Opens_page() throws Exception {
		UMReporter.log(Status.INFO,"Then : Verify it opens reporting application in a separate tab");
		if (LoggedinFlag){
			boolean flag=CommonFunctions.CloseAllWindowExceptCurrent(CurrentWinHnd);
			CommonUtility._sleepForGivenTime(1000);
			if (flag)
				UMReporter.log(Status.PASS,"The reporting application opens in a separate tab and closed");
			else
				UMReporter.log(Status.PASS,"The reporting application not opened");
		}
		else
			UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
	
}

@Given("^Login Demo test url launch$")
public void Login_URL_Demo_Test() throws Exception {
		UMReporter.log(Status.INFO,"Given : Login Demo test url launch");
		System.out.println("Login Demo test url launch");
		login.NavigatetoTestURL();
		//login.NavigatetoURL();
		//LoggedinFlag=false;
		UMReporter.log(Status.PASS,"Login Demo test url launch");
		
}

@Given("^Login Demo test$")
public void Demo_Test() throws Exception {
		UMReporter.log(Status.INFO,"Given : Login Demo test");
		System.out.println("Login Demo test");
		//LoggedinFlag=false;
		UMReporter.log(Status.PASS,"Login Demo test");
		
}
@When("^Demo test Step$")
public void Demo_Test_Step() throws Exception {
		UMReporter.log(Status.INFO,"When : Demo test Step");
		System.out.println("Demo test Step");
	//	Assume.assumeTrue(false);
		UMReporter.log(Status.PASS,"Demo test Step");
		// throw new AssumptionViolatedException("Skippingggg");
}

@Then("^Demo test another Step$")
public void Demo_Test_Step2() throws Exception {
		UMReporter.log(Status.INFO,"Then : Demo test another Step");
		System.out.println("Demo test another Step");
	//	Assume.assumeTrue(false);
		UMReporter.log(Status.PASS,"Demo test another Step");
		// throw new AssumptionViolatedException("Skippingggg");
}


@Then("^Verify User should redirected to the Cognito hosted UI$")
public void user_logout_redirection() throws IOException {
	UMReporter.log(Status.INFO, "Then: Verify User should redirected to the Cognito hosted UI");
	boolean flag =login.IsSignInHeaderExist();
	if (flag) 
		UMReporter.log(Status.PASS,"Navigated to Cognito hosted UI");
	else
		UMReporter.log(Status.FAIL,"Navigated to unexpected page");
}

@Then("^User Select Sign In as existing user (.*) in Cognito hosted UI$")
public void user_logout_signIn_SameUser(String Username) throws IOException {
	UMReporter.log(Status.INFO, "Then: User Select Sign In as existing user in Cognito hosted UI");
	boolean flag =login.IsSignInHeaderExist();
	if (flag) {
		flag =login.SignIn_ExistingUser(Username);
		if (flag) {
			LoggedinFlag=true;
			UMReporter.log(Status.PASS,"Selected Existing User: "+Username);
		}
		else
			UMReporter.log(Status.FAIL,"Unable to select Sign In as existing user");
	}
	else
		UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	
}

@Then("^User Select Sign In as different user in Cognito hosted UI$")
public void user_logout_signIn_DifferentUser() throws IOException {
	UMReporter.log(Status.INFO, "Then: User Select Sign In as different user in Cognito hosted UI");
	boolean flag =login.IsSignInHeaderExist();
	if (flag) {
		flag =login.SignIn_DifferentUser();
		if (flag) {
			UMReporter.log(Status.PASS,"Selected Sign In as different user");
		}
		else
			UMReporter.log(Status.FAIL,"Unable to select Sign In as different user");
	}
	else
		UMReporter.log(Status.FAIL,"Navigated to unexpected page");
	
}

@Given("^Login with different user (.*) (.*) in PA Refresh Site$")
public void Login_Into_PAUIR_Site_differentUser(String Username,String Password) throws IOException {
UMReporter.log(Status.INFO, "Given : Login with different user in PA Refresh Site "+Username+"/"+Password);
	boolean flag =login.IsSignInHeaderExist();
	if (!flag) {
		//Launch PAUIR Site
		//login.NavigatetoTestURL();
		login.NavigatetoURL();
		
		
	}
		
	//Check PA site to support launched Browsers
		if (login.IsLoginToPAExist()) {
			String BrowserCheck=login.GetBrowserHeaderSysCheck();
			System.out.println("Browser Check : "+BrowserCheck);  
			//Select Login into Pearson Access Link
			login.ClickLoginToPA();
			
		}
	//Login into the Site
		login.doLogin(Username,Password);
		CommonUtility._sleepForGivenTime(2000);
		
		if (login.IsTcPageExist()) {
			UMReporter.log(Status.PASS,"Logged In, new User Prompt to Accept the Terms and Condition");
			
		}
		else {
		//Verify the logged in Home Page
		home.WaitLoggedinHomePage();
		LoggedinFlag=home.VerifyLoggedinHomePage();
		if (LoggedinFlag) {
			Constants.Loggedinflag=true;
			//Verify Navigation and Org selector loaded in page else reload
			home.VerifyMenuOptions();
			UMReporter.log(Status.PASS,"logged in Successfully");
		}
		
		else
			UMReporter.log(Status.FAIL,"logged in Failed");
		}

}

@When("^User prompt a window to view the Terms and Conditions Page$")
public void user_view_Terms_Conditions_Page() throws IOException {
	UMReporter.log(Status.INFO, "When: User prompt a window to view the Terms and Conditions Page");
	boolean flag =login.IsTcPageExist();
	if (flag) 
			UMReporter.log(Status.PASS,"Prompted the Terms and Conditions Page ");
	else
		UMReporter.log(Status.FAIL,"Terms & Conditions window not displayed");	
}

@Then("^User view the Terms and Conditions$")
public void user_view_Terms_Conditions() throws IOException {
	UMReporter.log(Status.INFO, "Then: User view the Terms and Conditions page");
	boolean flag =login.IsTcPageExist();
	if (flag) {
		login.SelectTabOption("Terms & Conditions");
		flag =login.VerifyDownloadTcs();
		if (flag) {
			flag = login.VerifyIframe();
			UMReporter.log(Status.PASS,"Selected and read the Terms & Conditions");
		}
		else
			UMReporter.log(Status.FAIL,"Unable to select Terms & Conditions");
	}
	else
		UMReporter.log(Status.FAIL,"Terms & Conditions window not displayed");	
}

@Then("^User select the Download Terms and Conditions$")
public void user_download_Terms_Conditions() throws IOException {
	UMReporter.log(Status.INFO, "Then: User view the Terms and Conditions page");
	boolean flag =login.IsTcPageExist();
	if (flag) {
		login.SelectTabOption("Terms & Conditions");
		flag =login.DownloadTCs();
		if (flag) {
			UMReporter.log(Status.PASS,"Downloded the Terms & Conditions");
		}
		else
			UMReporter.log(Status.FAIL,"Unable to download Terms & Conditions");
	}
	else
		UMReporter.log(Status.FAIL,"Terms & Conditions window not displayed");	
}

@Then("^User view the Privacy Policy page$")
public void user_view_Privacy_Policy() throws IOException {
	UMReporter.log(Status.INFO, "Then: User view the Privacy Policy page");
	boolean flag =login.IsTcPageExist();
		if (flag) {
			flag = login.VerifyIframe();
			UMReporter.log(Status.PASS,"Selected and read the Privacy Policy");
		}
		else
			UMReporter.log(Status.FAIL,"Unable to select Privacy Policy");
	}
	
		


@Then("^User select the Download Privacy Policy$")
public void user_download_Privacy_Policy() throws IOException {
	UMReporter.log(Status.INFO, "Then: User select the Download Privacy Policy");
	boolean flag =login.IsTcPageExist();
	if (flag) {
		login.SelectTabOption("Privacy Policy");
		flag =login.DownloadPvtPlcy();
		if (flag) {
			UMReporter.log(Status.PASS,"Downloded the Terms & Conditions");
		}
		else
			UMReporter.log(Status.FAIL,"Unable to download Terms & Conditions");
	}
	else
		UMReporter.log(Status.FAIL,"Terms & Conditions window not displayed");	
}

@Then("^User select the accept button in the Terms and Conditions$")
public void user_accept_Terms_Conditions() throws IOException {
	UMReporter.log(Status.INFO, "Then: User select the accept button in the Terms and Conditions");
	boolean flag =login.IsTcPageExist();
	if (flag) {
		login.SelectTabOption("Terms & Conditions");
		flag =login.SelectAccept();
		if (flag) {
			LoggedinFlag=true;
			UMReporter.log(Status.PASS,"Accepted the Terms & Conditions");
		}
		else
			UMReporter.log(Status.FAIL,"Unable to accept Terms & Conditions");
	}
	else
		UMReporter.log(Status.FAIL,"Terms & Conditions window not displayed");	
}

@Then("^User select the decline button in the Terms and Conditions$")
public void user_decline_Terms_Conditions() throws IOException {
	UMReporter.log(Status.INFO, "Then: User select the decline button in the Terms and Condition");
	boolean flag =login.IsTcPageExist();
	if (flag) {
		login.SelectTabOption("Terms & Conditions");
		flag =login.SelectDecline();
		if (flag) {
			UMReporter.log(Status.PASS,"Decline the Terms & Conditions");
		}
		else
			UMReporter.log(Status.FAIL,"Unable to decline Terms & Conditions");
	}
	else
		UMReporter.log(Status.FAIL,"Terms & Conditions window not displayed");	
}



@Then("^User select the close icon$")
public void user_select_close() throws IOException {
	UMReporter.log(Status.INFO, "Then: User select the close icon");
	boolean flag =login.Selectclose();
	
		if (flag) {
		
			UMReporter.log(Status.PASS,"Closed the dialog");
		}
		else
			UMReporter.log(Status.FAIL,"Unable to close the dialog");
	}
	




@Given("^User select the (.*) Organization type in Organization Selector$")
public void user_select_the_Provided_OrganizationType_details(String OrgType) throws IOException {
	UMReporter.log(Status.INFO, "Given :User select the Organization type in Organization Selector: "+OrgType);
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	String OrgName=FileReaderManager.getInstance().getJsonReader().getSelectOrgName(OrgType); 
	//Verify the Org Details
	boolean bVerifiedFlag =home.Func_VerifyOrgName(OrgName);

	//Change the Org Details if not expected
	if (!bVerifiedFlag) 
		home.Func_ChangeOrganization(OrgName);
	
	//Constants.ORG_STATE=home.GetStatefromOrgName(OrgName);	
	UMReporter.log(Status.PASS,"Selected the Org details =>  "+OrgName);
	
}

@Given("^User permissions in Reports page$")
public void User_Permission_to_Reports_page() throws Exception {
	
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
		throw new RuntimeException("Login fail!");
	}
	List<String> LstUserPermissions=Constants.PERMISSIONS;
	if (LstUserPermissions.contains("ACCESS_REPORTS")) {
		UMReporter.log(Status.INFO, "Given : User permissions in Reports page");
		CurrentWinHnd=CommonFunctions.GetCurrentWindowHandle();
		home.MenuOtion("Reports", "");
		CommonFunctions.CloseAllWindowExceptCurrent(CurrentWinHnd);
	}	
	else
		UMReporter.log(Status.PASS,"User restricted for Reports");
	
}

@Given("^Login with user role (.*) in PA Refresh Site$")
public void Login_Into_PAUIR_Site_differentrole(String Userrole) throws IOException {
UMReporter.log(Status.INFO, "Given : Login with user role in PA Refresh Site "+Userrole);
	boolean flag =login.IsSignInHeaderExist();
	String FsUserName=null;
	if (!flag) {
		//Launch PA5 Site
		login.NavigatetoURL();
	}	
	//Check PA site to support launched Browsers
	if (login.IsLoginToPAExist()) {
		String BrowserCheck=login.GetBrowserHeaderSysCheck();
		System.out.println("Browser Check : "+BrowserCheck);  
		//Select Login into Pearson Access Link
		login.ClickLoginToPA();
	}
	//Login into the Site
	FsUserName=login.doOneLogin(Userrole);
	CommonUtility._sleepForGivenTime(2000);
	if (login.IsTcPageExist()) {
		UMReporter.log(Status.PASS,"Logged In, new User Prompt to Accept the Terms and Condition");
	}
	else {
	//Verify the logged in Home Page
	home.WaitLoggedinHomePage();
	LoggedinFlag=home.VerifyLoggedinHomePage();
	if (LoggedinFlag) {
		Constants.Loggedinflag=true;
		Constants.LOGGEDINUSERROLE=Userrole;
		ThdLoggedinFlag.set(true);
		LoggedinUsername=FsUserName;
		LoggedinUserrole=Userrole;
		//Verify Navigation and Org selector loaded in page else reload
		home.VerifyMenuOptions();
		UMReporter.log(Status.PASS,"logged in Successfully");
	}
	
	else
		UMReporter.log(Status.FAIL,"logged in Failed");
	}

}

@Given("^Login with user role for API Userrole Execution$")
public void Login_Into_PA5_Site_differentuserrole() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
UMReporter.log(Status.INFO, "Given : Login with user role for API Userrole Execution");
	boolean flag =login.IsSignInHeaderExist();
	HashMap<String,Object> MapAPIHeaders= null;
	String FsUserName=null;
	if (!flag) {
		//Launch PAUIR Site
		login.NavigatetoURL();
	}
	//Check PA site to support launched Browsers
	if (login.IsLoginToPAExist()) {
		String BrowserCheck=login.GetBrowserHeaderSysCheck();
		System.out.println("Browser Check : "+BrowserCheck);  
		//Select Login into Pearson Access Link
		login.ClickLoginToPA();
	}
	String Userrole=ThdUserole.get();
	//Login into the Site
	FsUserName=login.doOneLogin(Userrole);
	CommonUtility._sleepForGivenTime(2000);
	if (login.IsTcPageExist()) {
		UMReporter.log(Status.PASS,"Logged In, new User Prompt to Accept the Terms and Condition");
	}
	else {
	//Verify the logged in Home Page
	home.WaitLoggedinHomePage();
	LoggedinFlag=home.VerifyLoggedinHomePage();
	if (LoggedinFlag) {
		//Verify Navigation and Org selector loaded in page else reload
		home.VerifyMenuOptions();
		ThdLoggedinFlag.set(true);
		Constants.Loggedinflag=true;
		UMReporter.log(Status.PASS,"logged in Successfully");
		//Change Customer
		String CusName=FileReaderManager.getInstance().getJsonReader().getApplicationCustomer();
		//Verify the Customer Name
		boolean bVerifiedFlag =home.Func_VerifyCusName(CusName);
		//Change the Customer Name if not expected
		if (!bVerifiedFlag) 
			bVerifiedFlag=home.Func_ChangeCustomer(CusName);
		MapAPIHeaders=CommonFunctions.Get_Authorizationfromlog();
		if (MapAPIHeaders!=null) {
			System.out.println(MapAPIHeaders);
		  	String SelectedCustomer=FileReaderManager.getInstance().getJsonReader().getApplicationCustomer();
		  	HashMap<String,Object> mapPermissions=requests.GetAccount_Permissions(MapAPIHeaders,FsUserName,SelectedCustomer);
			if (mapPermissions!=null) {
				//driverscript.startDriverScript();
				System.out.println("mapPermissions"+mapPermissions);
				List<String> UserPermissions=(List<String>) mapPermissions.get("Permissions");
				Constants.PERMISSIONS=UserPermissions;
				UMReporter.log(Status.PASS,"The user permissions for user "+FsUserName+" are "+mapPermissions);
				String reportpath=driverscript.startNewDriverScript("json","APIUserroleSUITE",Userrole,"userrole",MapAPIHeaders.get("authorization").toString(),MapAPIHeaders.get("orgreferenceid").toString(),UserPermissions);//APIUserroleSUITE//APISmokeSUITE//APIRegressionSUITE
				UMReporter.log(Status.PASS,"API Execution completed and generated report <a href="+reportpath+">here</a>");
			}
		}
	}
	else
		UMReporter.log(Status.FAIL,"logged in Failed");
	}

}


@Then("^User execute User Role API Suite$")
public void user_get_APIauthorization_APIDriverScript_ForUserRole() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	UMReporter.log(Status.INFO, "Given: User execute User Role API Suite ");
	HashMap<String,Object> MapAPIHeaders= null;
	//Get auth and org for API for Authentication
	//Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	MapAPIHeaders=CommonFunctions.Get_Authorizationfromlog();
	if (MapAPIHeaders!=null) {
		System.out.println(MapAPIHeaders);
	  	String SelectedCustomer=FileReaderManager.getInstance().getJsonReader().getApplicationCustomer();
	  	HashMap<String,Object> mapPermissions=requests.GetAccount_Permissions(MapAPIHeaders,LoggedinUsername,SelectedCustomer);
		if (mapPermissions!=null) {
			//driverscript.startDriverScript();
			System.out.println("mapPermissions"+mapPermissions);
			List<String> UserPermissions=(List<String>) mapPermissions.get("Permissions");
			Constants.PERMISSIONS=UserPermissions;
			UMReporter.log(Status.PASS,"The user permissions for user "+LoggedinUsername+" are "+mapPermissions);
			String reportpath=driverscript.startNewDriverScript("json","APIUserroleSUITE",LoggedinUserrole,"userrole",MapAPIHeaders.get("authorization").toString(),MapAPIHeaders.get("orgreferenceid").toString(),UserPermissions);//APIUserroleSUITE//APISmokeSUITE//APIRegressionSUITE
			UMReporter.log(Status.PASS,"API Execution completed and generated report <a href="+reportpath+">here</a>");
		}
	}
}

@Given("^Logout the PA5 Site$")
public void Logout_PA_Site() throws IOException {
	UMReporter.log(Status.INFO, "Given : Logout the PA5 Site");
	System.out.println("Logout the PA5 Site LoggedinFlag: "+LoggedinFlag+" ConstantLoggedinflag: "+Constants.Loggedinflag+" Thread :"+threadId);
	if (ThdLoggedinFlag.get()){
		LoggedinFlag=false;
		ThdLoggedinFlag.set(false);
		//Constants.Loggedinflag=false;
		home.Logout();
		UMReporter.log(Status.PASS,"logout Successfully");
	}
	else
		UMReporter.log(Status.FAIL,"LogIn Failed.");
}


@Given("^Navigate to Reports Builder page$")
public void Navigate_View_ReportsBuilder_page() throws Exception {
		UMReporter.log(Status.INFO,"Then : Navigate to Reports Builder page");
		if (LoggedinFlag){
			CurrentWinHnd=CommonFunctions.GetCurrentWindowHandle();
			home.MenuOtion("Reportbuilder", "");
			UMReporter.log(Status.PASS,"Navigated to Home page");
		}
		else
			UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
	
}

@Then("^Verify it opens ReportBuilder application in a separate tab$")
public void Verify_View_ReportsBuilder_Opens_page() throws Exception {
		UMReporter.log(Status.INFO,"Then : Verify it opens ReportBuilder application in a separate tab");
		if (LoggedinFlag){
			boolean flag=false;
			Set<String> testTicketsWinHnd = WebDriverMain._getDriver().getWindowHandles();
			for (String testTickets : testTicketsWinHnd) {
				if (!testTickets.equals(CurrentWinHnd)) {
					WebDriverMain._getDriver().switchTo().window(testTickets);
					CommonUtility._sleepForGivenTime(20000);
					drshome.WaitDRSHomePage();
					UMReporter.log(Status.PASS, "Reporting frame is displayed in Reports Page : ");
					flag=true;
					//WebDriverMain._getDriver().switchTo().window(CurrentWinHnd);
				}
			}
			CommonUtility._sleepForGivenTime(1000);
			if (flag)
				UMReporter.log(Status.PASS,"The reporting application opens in a separate tab and closed");
			else
				UMReporter.log(Status.PASS,"The reporting application not opened");
		}
		else
			UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
	
}

@Given("^Logout the DRS Site$") 
public void logout_the_drs_site() throws IOException  {
	if (LoggedinFlag){
		boolean flag=CommonFunctions.CloseAllWindowExceptCurrent(CurrentWinHnd);
		CommonUtility._sleepForGivenTime(1000);
		if (flag)
			UMReporter.log(Status.PASS,"The reportbuilder tab is closed");
		else
			UMReporter.log(Status.PASS,"The reportbuilder tab not opened");
	}
	else
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");

}


}
