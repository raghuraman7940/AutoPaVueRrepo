package com.pauir.runner;

/**
 * TestRunner
 */
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.util.Constants;
import com.pauir.common.core.CommonFunctions;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import webdriver.main.UMReporter;
import static com.pauir.runner.MultiTestRunner.Browsertype;
	
	@RunWith(Cucumber.class)
	@CucumberOptions(
			features={
					
					//Functional - @functional
					//PAUIR 2019 
					"src/test/java/com/pauir/Features/PAUIR-3153_Organizations_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-3154_Student_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-3160_Class_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-3162_Student_details.feature",
					"src/test/java/com/pauir/Features/PAUIR-3159_7387_Organization_details.feature",
					"src/test/java/com/pauir/Features/PAUIR-3270_8298_Class_details.feature",
					"src/test/java/com/pauir/Features/PAUIR-3287_Session_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-3314_Create_Session.feature",
					"src/test/java/com/pauir/Features/PAUIR-3288_Session_details.feature",
					"src/test/java/com/pauir/Features/PAUIR-3616_User_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-3308_Add_updateorganizationcontact.feature",
					"src/test/java/com/pauir/Features/PAUIR-3309_Deleteorganizationcontact.feature",
					"src/test/java/com/pauir/Features/PAUIR-2757_Create_Modify_Class_details.feature",
					"src/test/java/com/pauir/Features/PAUIR-3307_Add_Update_Organizations.feature",
					"src/test/java/com/pauir/Features/PAUIR-3291_Session_details_Add_Student.feature",
					"src/test/java/com/pauir/Features/PAUIR-3621_User_details.feature",
					"src/test/java/com/pauir/Features/PAUIR-3545_Add_Update_Student.feature",
					"src/test/java/com/pauir/Features/PAUIR-3287_Session_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-2930_Class_details_Add_Remove_Students.feature",
					"src/test/java/com/pauir/Features/admin/PAUIR-3675_Form_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-4149_Hamburger_Menu.feature",
					"src/test/java/com/pauir/Features/PAUIR-231_Add_Remove_Teacher.feature",
					"src/test/java/com/pauir/Features/PAUIR-3887_4818_4817_Add_Modify_User_details.feature",
					"src/test/java/com/pauir/Features/admin/PAUIR-3693_TestAdmin_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-3608_4279_Session_details_Watchers_TestingDays.feature",
					"src/test/java/com/pauir/Features/admin/PAUIR-3709_Customer_list.feature",
					"src/test/java/com/pauir/Features/admin/PAUIR-3683_Tests_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-3283_Delete_Class.feature",
			        "src/test/java/com/pauir/Features/PAUIR-3549_Modify_Student_Profile_Enroll_Unenroll.feature",
			        "src/test/java/com/pauir/Features/PAUIR-3630_Session_details_Remove_Student.feature",
			        "src/test/java/com/pauir/Features/PAUIR-3310_Organizations_Delete.feature",
					"src/test/java/com/pauir/Features/PAUIR-4680_Refactor_Session_details.feature",
					"src/test/java/com/pauir/Features/PAUIR-4683_Refactor_Project_Switcher_Heade_Changes.feature",
					"src/test/java/com/pauir/Features/PAUIR-3379_Student_Details_Include_Test_Session.feature",
					"src/test/java/com/pauir/Features/PAUIR-3887_4818_4817_Add_Modify_User_details.feature",
					"src/test/java/com/pauir/Features/PAUIR-4736_4219_UserInfo_Profile_menu.feature",
					"src/test/java/com/pauir/Features/PAUIR-3648_Edit_Session_details.feature",
					"src/test/java/com/pauir/Features/PAUIR-5242_3649_Sessions_Delete.feature",
					"src/test/java/com/pauir/Features/PAUIR-5561_Studentprofile_from_ClassdetailsPage.feature",
					"src/test/java/com/pauir/Features/PAUIR-4889_Update_User_Password_via_Account_Profile.feature",
					"src/test/java/com/pauir/Features/PAUIR-3646_Sessions_Resetpassword.feature",
					"src/test/java/com/pauir/Features/PAUIR-5712_Session_Details_Print_Testing_Ticket.feature",
					"src/test/java/com/pauir/Features/PAUIR-5706_Allow_users_to_Download_Test.feature",
					"src/test/java/com/pauir/Features/PAUIR-5342_5653_Session_details_invoking_reports.feature",
					"src/test/java/com/pauir/Features/PAUIR-4821_Student_Details_Include_ClassList.feature",
					"src/test/java/com/pauir/Features/PAUIR-5705_Student_Details_ViewISR_Report.feature",
					"src/test/java/com/pauir/Features/PAUIR-5656_Session_Include_Timezone.feature",
					"src/test/java/com/pauir/Features/PAUIR-5845_NewUser_Prompt_TC_PvtPolicy.feature",
					"src/test/java/com/pauir/Features/PAUIR-5947_6595_Footer_displays_Logo_Copyrights_TC_Pvtpolicy.feature",
					"src/test/java/com/pauir/Features/PAUIR-6001_6864_TeacherHandScoring.feature",
					"src/test/java/com/pauir/Features/PAUIR-6114_UserInfo_Profile_timezone.feature",
					"src/test/java/com/pauir/Features/PAUIR-6966-Implement_to create_temporary_student.feature",
					"src/test/java/com/pauir/Features/PAUIR-4111_Display_Accommodations_in_Add_Students_to_Session_list.feature",
					"src/test/java/com/pauir/Features/PAUIR-4109_To_display_accommodations_indicator_on Session_Details view.feature",
					"src/test/java/com/pauir/Features/PAUIR-7730_Download_Test_Session_Accommodations_as_pdf.feature",
					"src/test/java/com/pauir/Features/PAUIR-7753_Internal_Roles_to_Unsubmit_student_test_attempts.feature",
					"src/test/java/com/pauir/Features/PAUIR-7260-To_Enter_View_Irregularities_In_Test_Session.feature",
					"src/test/java/com/pauir/Features/PAUIR-9735_Print_Answer_Sheet_from_Test_Session.feature",
					"src/test/java/com/pauir/Features/PAUIR-9394_Allow_import_export_Classes_data.feature",
			   		"src/test/java/com/pauir/Features/PAUIR-9052_scored_and_not_scored_drilldown.feature",
					"src/test/java/com/pauir/Features/PAUIR-10744_AO_List.feature",
				
					//PAUIR 2020
					"src/test/java/com/pauir/Features/PAUIR-3579_Session_Move_Students.feature",					
					"src/test/java/com/pauir/Features/PAUIR-9124_ list_of_tests-assessments_for_administrations_in_product.feature",
					"src/test/java/com/pauir/Features/PAUIR-9756-Ability_to_launch_local_authoring_application.feature",
					"src/test/java/com/pauir/Features/PAUIR-7250_allow_users_to_enter_irregularities_for_attempts_in_test session.feature",
					"src/test/java/com/pauir/Features/PAUIR-9320_Allow_import_Students_data.feature",
					"src/test/java/com/pauir/Features/PAUIR-9647_allow_import_export_courses_data.feature",
					"src/test/java/com/pauir/Features/PAUIR-9081_9308_Courses.feature",
					"src/test/java/com/pauir/Features/PAUIR-9395_Allow_import_export_organizations.feature",
					"src/test/java/com/pauir/Features/PAUIR-6931_Ability_to_view_details_of_test_and_preview_the_form.feature",
					"src/test/java/com/pauir/Features/PAUIR-10810_Ability_to_create_edit_courses.feature",
					"src/test/java/com/pauir/Features/PAUIR-10863_Export_Scored_Notscored.feature",
					"src/test/java/com/pauir/Features/PAUIR-9021_Ability_to_drill_down_student_test_counts_with_accomm_errors.feature",
					"src/test/java/com/pauir/Features/PAUIR-9054_Ability_to_drill_down_reported_not_reported_dashboard_widget.feature",
					"src/test/java/com/pauir/Features/PAUIR-10298_ability_to_display_unique_list_of_students_associated_with_course.feature",
					"src/test/java/com/pauir/Features/PAUIR-10748_Delete_AO.feature",
					"src/test/java/com/pauir/Features/PAUIR-10749_Submit_AO_to_PSO.feature",
				
					//Smoke Testing - @smoke
					"src/test/java/com/pauir/Features/TestSuites/smoke/APISmokeSuite.feature",
					"src/test/java/com/pauir/Features/TestSuites/smoke/UISmokeSuite.feature",
					"src/test/java/com/pauir/Features/TestSuites/smoke/SanityTest.feature",
					"src/test/java/com/pauir/Features/TestSuites/smoke/Sampletest.feature",
					"src/test/java/com/pauir/Features/TestSuites/smoke/Testnav_LoginAttempt.feature",
					
				     //Regression Testing - @regression
					"src/test/java/com/pauir/Features/TestSuites/Regression/APIRegressionSuite.feature",
					"src/test/java/com/pauir/Features/TestSuites/Regression/CBTTestSessions.feature",
					"src/test/java/com/pauir/Features/TestSuites/Regression/Classes_Courses.feature",
					"src/test/java/com/pauir/Features/TestSuites/Regression/Dashboard.feature",
					"src/test/java/com/pauir/Features/TestSuites/Regression/DataImports_Shipments_Products.feature",
					"src/test/java/com/pauir/Features/TestSuites/Regression/Orders.feature",
			        "src/test/java/com/pauir/Features/TestSuites/Regression/Organizations.feature",
					"src/test/java/com/pauir/Features/TestSuites/Regression/PBTTestSessions.feature",
					"src/test/java/com/pauir/Features/TestSuites/Regression/Students.feature",
					"src/test/java/com/pauir/Features/TestSuites/Regression/Users.feature",

					//User roles and Permissions -@roles @functional
					//External roles
					"src/test/java/com/pauir/Features/TestSuites/roles/Admin_Roles_Permission.feature",
					"src/test/java/com/pauir/Features/TestSuites/roles/Teacher_Roles_Permission.feature",
					"src/test/java/com/pauir/Features/TestSuites/roles/TestAdministrator_Roles_Permission.feature",
					"src/test/java/com/pauir/Features/TestSuites/roles/TestCoordinator_Roles_Permission.feature",
					"src/test/java/com/pauir/Features/TestSuites/roles/TestCoordinator_Interim_Roles_Permission.feature",
					"src/test/java/com/pauir/Features/TestSuites/roles/ReportingAdmin_Roles_Permission.feature",
					"src/test/java/com/pauir/Features/TestSuites/roles/HandScoringAdministrator_Roles_Permission.feature",
					//Internal roles
					"src/test/java/com/pauir/Features/TestSuites/roles/SystemAdmin_Roles_Permission.feature",
					"src/test/java/com/pauir/Features/TestSuites/roles/Customer_Support_1_Roles_Permission.feature",
					"src/test/java/com/pauir/Features/TestSuites/roles/Customer_Support_2_Roles_Permission.feature",
					"src/test/java/com/pauir/Features/TestSuites/roles/Technical_Support_Roles_Permission.feature",
 					
					//Automation Data Clean Up
					"src/test/java/com/pauir/Features/TestSuites/smoke/APICleanupSuite.feature",
					
			},
			glue={""},
			tags= {"not @Raw"},
		     strict = true,
		     dryRun = false,
		    monochrome = true,
			plugin = {"pretty", "json:target/cucumber-reports/Cucumber.json",
					"junit:target/cucumber-reports/Cucumber.xml",
					"html:target/cucumber-reports"}
			)
	public class SingleTestRunner {

		@BeforeClass
	    public static void setup() {
	        UMReporter.initReport(Constants.REPORTTYPE,Constants.PROJECTNAME);
	        String browserName;
	        String sysBrowser = System.getProperty("browser");
	      
			if (sysBrowser!=null) 
				 browserName=sysBrowser;
			else
				 browserName=FileReaderManager.getInstance().getConfigReader().getBrowser();
			
			//System.out.println("browserName => "+browserName);
			
			System.out.println("Environment => "+FileReaderManager.getInstance().getConfigReader().getEnvironment());
	        Constants.BROWSERTYPE=browserName;
	        Browsertype.set(browserName);
			CommonFunctions.InitializeWebDriver(browserName);
			
			  UMReporter.CleanReportFolder();
	    }
		
	    @AfterClass
	    public static void teardown() {
	    	try {
	        UMReporter.endReport(Constants.REPORTTYPE);
	        UMReporter.GenerateXtendReport();
	        CommonFunctions.CloseAllWebDriver();
	    	}
	    	catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }


	}

