/**
 * TestRunner from Testng.xml
 */
package com.pauir.runner;
import org.testng.annotations.Test;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.TestNGCucumberRunner;
import webdriver.main.CommonUtility;
import webdriver.main.UMReporter;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.PickleEventWrapper;
import java.lang.management.ManagementFactory;
import java.util.HashMap;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pauir.Request.API.ReportJSON;
import com.pauir.common.core.CommonFunctions;
import com.pauir.common.core.FileReaderManager;
import com.pauir.common.util.Constants;
import com.pauir.common.util.EmailReports;
@CucumberOptions(
        features = {
        		"src/test/java/com/pauir/Features/TestSuites"
//        		"src/test/java/com/pauir/Features/TestSuites/smoke/Sampletestfeature.feature",
//        		"src/test/java/com/pauir/Features/TestSuites/smoke/SmokeTest.feature"
//        		"src/test/java/com/pauir/Features/TestSuites/roles/API_UserRolesMatrix_Permission.feature",
				},
        glue={""},
        tags = {"not @RW"},
        plugin = {"pretty", 
                "json:target/cucumber-reports/CucumberTestReport.json",
                "rerun:target/cucumber-reports/rerun.txt"},
        junit ={ "--step-notifications"},
        strict = false,
        dryRun = false,
        monochrome = true
        )

public class MultiTestRunner extends AbstractTestNGCucumberTests{
    private TestNGCucumberRunner testNGCucumberRunner;
    public static ThreadLocal<String> Browsertype = new ThreadLocal<String>();
    public static ThreadLocal<String> ThdUserole = new ThreadLocal<String>();
    public static ThreadLocal<Boolean> ThdLoggedinFlag = new ThreadLocal<Boolean>();
    public static HashMap<String, String> MapFeatureScenrios = null;
    public static EmailReports email = new EmailReports();
    public static ReportJSON RepJs;
    public String cucumberOptionsFromEnv=null;
    public String reportloc=null;
    
    @BeforeSuite(alwaysRun = true)
    public void setUpClass() throws Exception {
    	try {
    		UMReporter.CleanupReportFolders();
	    	UMReporter.initReport(Constants.REPORTTYPE,Constants.PROJECTNAME);
	    	RepJs=new ReportJSON();
	    	MapFeatureScenrios=  new HashMap<String,String>();
	    	UMReporter.CleanReportFolder();
    	
    	}catch (Exception e) {
 			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @BeforeTest(alwaysRun = true)
    @Parameters({"browser", "userrole" })
    public void setUpClass1(String browserName,String userrole) throws Exception {
    	try {
	    	 testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	    	 String browserName1 = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("browser");
	    	 String FSuserrole = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("userrole");
	    	 System.out.println("FSuserrole : "+FSuserrole);
	    	 System.out.println("userrole : "+userrole);
	    	 ThdLoggedinFlag.set(false);
	    	 cucumberOptionsFromEnv = System.getProperty("cucumber.options");
	    	 System.out.println("Executing "+cucumberOptionsFromEnv);
	    	 System.out.println("Build Number:"+System.getProperty("BUILD_NUMBER"));
	    	 System.out.println("PIPELINE_VERSION :"+System.getProperty("PIPELINE_VERSION"));
	    	 reportloc = System.getProperty("reportloc");
	    	 System.out.println("Report location : "+reportloc);
	    	 CommonFunctions.InitializeWebDriver(browserName1);
	    }
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider="FeatureScenarios")
    public void feature(PickleEventWrapper pickleEvent,CucumberFeatureWrapper cucumberFeature) throws Throwable  {
    	try {
	    	String browserName = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("browser");
	    	 String FSuserrole = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("userrole");
	    	String strFeatureName=cucumberFeature.toString();
	    	strFeatureName=strFeatureName+browserName+FSuserrole;
	    	String strScenarioName=cucumberFeature.toString();
	    	System.out.println("strFeatureName = " +strFeatureName);
	    	if (!MapFeatureScenrios.containsKey(strFeatureName)) {
	    		MapFeatureScenrios.put(strFeatureName,strScenarioName);	
	    		Browsertype.set(browserName);
	    		ThdUserole.set(FSuserrole);
	    		System.out.println("browsertype:  " + Browsertype.get());
	    		long threadId = Thread.currentThread().getId();
	    		String processName = ManagementFactory.getRuntimeMXBean().getName();
	    		System.out.println("Started in thread: " + threadId + ", in JVM: " + processName+" , Feature : "+cucumberFeature);
	    		if (threadId%2==0)
	    			Thread.sleep(threadId*500);
	    		testNGCucumberRunner.runScenario(pickleEvent.getPickleEvent());
	    	}
	    	else
	    	{
	    		//System.out.println("pickleEvent: " +pickleEvent);
	    		testNGCucumberRunner.runScenario(pickleEvent.getPickleEvent());
	    		
	    	}
	        
	        UMReporter.endReport(Constants.REPORTTYPE);
	    }
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
 
    @AfterTest(alwaysRun = true)
    public void tearDownClass1() throws Exception {	
    	try {
		testNGCucumberRunner.finish();
		ThdLoggedinFlag.set(false);
		CommonFunctions.CloseWebDriver();
    	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    @DataProvider
    public Object[][] FeatureScenarios() {	
        return testNGCucumberRunner.provideScenarios();
    }
 
    @AfterSuite(alwaysRun = true)
    public void tearDownClass() throws Exception {   
    	try {
	    	UMReporter.endReport(Constants.REPORTTYPE);
	    	RepJs.GenerateUserrolesOverview();
	    	UMReporter.GenerateXtendReport();
	    	CommonUtility._sleepForGivenTime(4000);
	    	if (cucumberOptionsFromEnv.contains("regression")) 
	    		email.ComposeEmailReports("regression");
	    	else	
	    		email.ComposeEmailReports("smoke");
	    	CommonUtility._sleepForGivenTime(2000);
	    	CommonFunctions.CloseAllWebDriver();
	    
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}