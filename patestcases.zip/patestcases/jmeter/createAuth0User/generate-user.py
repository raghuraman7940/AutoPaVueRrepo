import sys
import csv
import random, string

def randomword(length):
   letters = string.ascii_lowercase
   return ''.join(random.choice(letters) for i in range(length))

def generateRandomName():
    fname = randomword(5)
    lname = randomword(5)
    email = fname + '.' + lname + '@email.com'

    if (email not in usedEmails):
        return (fname, lname, email)
    else:
        print('Duplicate')
        return generateRandomName()

usedEmails = [];

with open('datafiles/create-user.csv', 'w', newline='') as file:
    writer = csv.writer(file)

    writer.writerow(["FirstName", "LastName", "Email", "Password"])

    for x in range(int(sys.argv[1])):
        randomName = generateRandomName()
        writer.writerow([randomName[0], randomName[1], randomName[2], 'Password@123'])

