#!/bin/bash

function get_container_id {
  if [[ ! -f /proc/1/cpuset ]]; then
    echo "[entrypoint] method=get_container_id, event=cpusetNotFound"
    return 1
  else
    container_id=`awk -F/ '{ print $NF }' /proc/1/cpuset | cut -c 1-12`
  fi

  if [[ `echo "$container_id" | grep -E '^[a-f0-9]{12}$' -c` -eq "0" ]]; then
    echo "[entrypoint] method=get_container_id, event=invalidContainerId, containerId=$container_id"
    return 1
  fi
  echo "$container_id"
}

function render_configuration {
  echo "[entrypoint] method=render_configuration, entry"
  if [[ -f /usr/local/confd/bin/confd ]]; then
    echo "[entrypoint] method=render_configuration, Found confd"
    if [[ -f /etc/confd/env/local.env ]]; then
      echo "[entrypoint] method=render_configuration, backend=dotenv dotenv-file=/etc/confd/local.env"
      /usr/local/confd/bin/confd -onetime -backend dotenv -dotenv-file /etc/confd/env/local.env -confdir pa-refresh-auto/confd|| exit 1
    elif [[  ! -z "$CONFD_DYNAMO_TABLE" ]]; then
      echo "[entrypoint] method=render_configuration, backend=dynamodb, table=$CONFD_DYNAMO_TABLE"
      /usr/local/confd/bin/confd -onetime -backend dynamodb -table "$CONFD_DYNAMO_TABLE" -confdir pa-refresh-auto/confd || exit 1
    else
      echo "[entrypoint] method=render_configuration, event=backendNotFound"
      exit 1
    fi
  else
    echo "[entrypoint] method=render_configuration, event=confdNotFound"
    exit 1
  fi
}


export CONTAINER_ID="$(get_container_id)"
mkdir -p /usr/src/app/logs/$CONTAINER_ID
render_configuration
chmod 755 /usr/src/app/start.sh
export JAVA_OPTS="-Dcontainer.id=$CONTAINER_ID $JAVA_OPTS"

echo "[entrypoint] event=start, command='$@'"
exec $@
