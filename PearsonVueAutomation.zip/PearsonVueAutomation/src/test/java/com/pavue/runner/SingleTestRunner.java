package com.pavue.runner;

/**
 * TestRunner
 */
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import com.pavue.common.core.FileReaderManager;
import com.pavue.common.util.Constants;
import com.pavue.webdriver.UMReporter;
import com.pavue.common.core.CommonFunctions;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

import static com.pavue.runner.MultiTestRunner.Browsertype;
	
	@RunWith(Cucumber.class)
	@CucumberOptions(
			features={
//					//Smoke Testing - @smoke
					"src/test/java/com/pavue/features/APISmokeSuite.feature",
//					"src/test/java/com/pauir/Features/UISmokeSuite.feature",
//					"src/test/java/com/pauir/Features/SanityTest.feature",
//					"src/test/java/com/pauir/Features/Sampletest.feature",
					
			},
			glue={""},
			tags= {"not @Raw"},
		     strict = true,
		     dryRun = false,
		    monochrome = true,
			plugin = {"pretty", "json:target/cucumber-reports/Cucumber.json",
					"junit:target/cucumber-reports/Cucumber.xml",
					"html:target/cucumber-reports"}
			)
	public class SingleTestRunner {

		@BeforeClass
	    public static void setup() {
	        UMReporter.initReport(Constants.REPORTTYPE,Constants.PROJECTNAME);
	        String browserName;
	        String sysBrowser = System.getProperty("browser");
	      
			if (sysBrowser!=null) 
				 browserName=sysBrowser;
			else
				 browserName=FileReaderManager.getInstance().getConfigReader().getBrowser();
			
			//System.out.println("browserName => "+browserName);
			
			System.out.println("Environment => "+FileReaderManager.getInstance().getConfigReader().getEnvironment());
	        Constants.BROWSERTYPE=browserName;
	        Browsertype.set(browserName);
			CommonFunctions.InitializeWebDriver(browserName);
			
			  UMReporter.CleanReportFolder();
	    }
		
	    @AfterClass
	    public static void teardown() {
	    	try {
	        UMReporter.endReport(Constants.REPORTTYPE);
	        UMReporter.GenerateXtendReport();
	        CommonFunctions.CloseAllWebDriver();
	    	}
	    	catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }


	}

