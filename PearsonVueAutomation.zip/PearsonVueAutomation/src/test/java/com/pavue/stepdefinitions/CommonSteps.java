package com.pavue.stepdefinitions;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import com.aventstack.extentreports.Status;
import com.pavue.pages.Home;
import com.pavue.pages.Login;
import com.pavue.request.api.DriverScript;
import com.pavue.request.api.RequestMethod;
import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;
import com.pavue.common.core.CommonFunctions;
import com.pavue.common.core.FileReaderManager;
import com.pavue.common.util.Constants;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.BeforeStep;
import cucumber.api.java.AfterStep;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static com.pavue.runner.MultiTestRunner.Browsertype;
import static com.pavue.runner.MultiTestRunner.ThdUserole;;
public class CommonSteps {
	UMReporter classReport;
	static boolean FFBrowser = false;
	static boolean CHBrowser = false;
	public static Login login;
	public static Home home;
	public static CommonFunctions common;
	public static boolean LoggedinFlag=false;
	public static boolean LoggedinAdminFlag=false;
	public static String ScopeProgram;
	public static String ScopeYear;
	public static String ScopeAdmin;
	public static String JSESSIONID;
	public static String CurrentWinHnd=null;
	public static HashMap<String, String> APIAUTHheaders =null;
	public static RequestMethod requests;
	public static DriverScript driverscript;
	public static long threadId;
	
	public CommonSteps()throws IOException, NoSuchMethodException, SecurityException{
		//Initialize the Page object
		login = new Login(WebDriverMain._getDriver());
		home= new Home();
		requests=new RequestMethod();
		driverscript=new DriverScript();
	}
	
	@Before
	public void beforeScenario(Scenario scenario) throws IOException {
		try{
			//Feature and Scenario Properties Setup
			String ScenarioName = "Scenario : ";
			String ReportDes=null;
			String ScenarioTags="";
			ScenarioName = ScenarioName + scenario.getName();
			String featureName =" Feature ";
			String strBrowser=null;
			String strUserrole=null;
		    String rawFeatureName = scenario.getId().split("/features/")[1].replace("/"," ");
		    rawFeatureName = rawFeatureName.split(".feature")[0].replace("_"," ");
		    
		    rawFeatureName=rawFeatureName.replace("TestSuites", "");
		    //Get Tags Names
		    Collection<String> lstTgs=scenario.getSourceTagNames();
		    for (String str:lstTgs)
		    	ScenarioTags=str+" "+ScenarioTags;
		    
		    featureName = featureName + rawFeatureName; 
		    String RunEnvironment=FileReaderManager.getInstance().getConfigReader().getEnvironment();
		    Constants.OSTYPE=FileReaderManager.getInstance().getConfigReader().getOSType();
		    threadId = Thread.currentThread().getId();
		    strBrowser=Browsertype.get();
		    strUserrole=ThdUserole.get();
		    Constants.LOGGEDINUSERROLE=strUserrole;
	   	 	System.out.println(ScenarioName+" - " +strUserrole +" - " +strBrowser + " - " +RunEnvironment+" - "+threadId);
	   	 	//Get Browser Type
	   	 	if (strBrowser.equalsIgnoreCase("CHROME")) {
	   	 		CHBrowser=true;
	   	 		featureName=featureName + " <span class='categoryChrome'>"+strBrowser+"<p hidden>"+ threadId + "</p>"+ "</span><span class='categoryBrowser '>"+ strUserrole + "</span>";
	   	 	}
	   	 	else if(strBrowser.equalsIgnoreCase("FIREFOX")) {
	   	 		FFBrowser=true;
	   	 		featureName=featureName + " <span class='categoryBrowser'>"+strBrowser+"<p hidden>"+ threadId + "</p>"+ "</span>";
	   	 	}
	   	 	else
	   	 		featureName=featureName + " <span class='categoryBrowser'>"+strBrowser+"<p hidden>"+ threadId + "</p>"+ "</span>";
	   	 	
	   	 	//Get Report Description
	   	 if (featureName.contains("Regression"))
	   		ReportDes="Regression Test - Scenarios: "+ScenarioTags;
	   	 else if(featureName.contains("smoke"))
		   	ReportDes="Smoke Test - Scenarios: "+ScenarioTags;
	   	 else if(featureName.contains("Functional"))
	   		ReportDes="Functional Test - Scenarios: "+ScenarioTags;
	   	 else 
	 		ReportDes="Regression Test - Scenarios: "+ScenarioTags;
	   	 
			//Initialize Feature report	   	 	
			classReport = new UMReporter(featureName , ReportDes, Constants.REPORTTYPE);
			//Initialize Feature scenario report
			UMReporter.initTest(featureName,ScenarioName,Constants.REPORTTYPE,strBrowser,RunEnvironment,Constants.OSTYPE,ScenarioTags);
			
		}catch(Exception ex){
			ex.printStackTrace();
			//System.out.println("Before Scenario Exception wantstoquit");   
		} 
	}
	
	@After(order = 1)
	public void afterScenario(Scenario scenario) {
		System.out.println("Scenario : "+scenario.getName()+" => "+scenario.getStatus());
		//CommonSteps.wantsToQuit = true == scenario.isFailed();
		//System.out.println("@After scenarios1 :");  
		
	}
	
	@After(order = 0)
	public void AfterSteps() throws InterruptedException {
		//System.out.println("@After scenarios :");   	 
		UMReporter.appendParent();
		
	}

	@BeforeStep
	public void BeforeStep(Scenario scenario) throws InterruptedException, IOException {
		String CurrentScenario=scenario.getName();
		System.out.println("@@BeforeStep : "+scenario.getName()+"Loggedflag: "+Constants.Loggedinflag+" Threadid: "+threadId); 
		if ((CurrentScenario.equalsIgnoreCase("Login Page Setup"))||(CurrentScenario.contains("Login Page Setup"))) {
			//System.out.println("Login Page Setup - Issue Error handling"); 
		}
		else {
			if (!Constants.Loggedinflag) {
				UMReporter.log(Status.SKIP,"Skipped scenario due to login failed.");
				throw new RuntimeException("Login fail");
			}
			
		}
	}
	@AfterStep
	public void AfterStep() throws InterruptedException {
		//System.out.println("@@@AfterStep :");   	 
		
	}

@Given("^Launch the PA Refresh Site$")
public void Login_Into_NewPAUIR_Site_() throws IOException {
	UMReporter.log(Status.INFO, "Given : Launch the PA Refresh Site");
	//Launch PAUIR Site
	login.NavigatetoURL();
	CommonUtility._sleepForGivenTime(2000);
	//Verify the logged in Home Page
	home.WaitLoggedinHomePage();
	LoggedinFlag=home.VerifyLoggedinHomePage();
	if (LoggedinFlag) {
		UMReporter.log(Status.PASS,"PAUIR Home page is displayed Successfully");
	}
	else
		UMReporter.log(Status.FAIL,"logged in Failed");	
}


@Given("^Launch the PA Refresh Site and login with admin user$")
public void Login_Into_PAUIR_Site_() throws IOException {
UMReporter.log(Status.INFO, "Given : Launch the PAUIR Site and login with admin user");
	String StrUserdetails=null;
	String StrUserPwd=null;
	//Launch PAUIR Site
	StrUserdetails=login.NavigatetoURL();

	//Check PA site to support launched Browsers
	if (login.IsLoginToPAExist()) {
		String BrowserCheck=login.GetBrowserHeaderSysCheck();
		System.out.println("Browser Check : "+BrowserCheck);  
		//Select Login into Pearson Access Link
		login.ClickLoginToPA();
	}
	//Check if already in home pge 
	LoggedinFlag=home.VerifyLoggedinHomePage();
	if (!LoggedinFlag) {
		//Login into the Site
		//login.doSignIn();
		StrUserPwd=login.doLogin();
		StrUserdetails=StrUserdetails+StrUserPwd;
	}
	
	CommonUtility._sleepForGivenTime(2000);
	
	//Verify the logged in Home Page
	home.WaitLoggedinHomePage();
	LoggedinFlag=home.VerifyLoggedinHomePage();
	if (LoggedinFlag) {
		//Verify Navigation and Org selector loaded in page else reload
		home.VerifyMenuOptions();
		Constants.Loggedinflag=true;
		UMReporter.log(Status.PASS,"logged in Successfully with login details : "+StrUserdetails);
	}
	else {
		System.out.println("Login Failed : "+StrUserdetails);   
		UMReporter.log(Status.FAIL,"logged in Failed "+StrUserdetails);
		throw new RuntimeException("Login failed!");
	}
}

@Given("^Login with different user (.*) (.*) in PA Refresh Site$")
public void Login_Into_PAUIR_Site_differentUser(String Username,String Password) throws IOException {
UMReporter.log(Status.INFO, "Given : Login with different user in PA Refresh Site "+Username+"/"+Password);
	boolean flag =login.IsSignInHeaderExist();
	if (!flag) {
		//Launch PAUIR Site
		login.NavigatetoURL();
	}
	//Check PA site to support launched Browsers
	if (login.IsLoginToPAExist()) {
		String BrowserCheck=login.GetBrowserHeaderSysCheck();
		System.out.println("Browser Check : "+BrowserCheck);  
		//Select Login into Pearson Access Link
		login.ClickLoginToPA();
	}
	//Login into the Site
	login.doLogin(Username,Password);
	CommonUtility._sleepForGivenTime(2000);
	if (login.IsTcPageExist()) {
		UMReporter.log(Status.PASS,"Logged In, new User Prompt to Accept the Terms and Condition");
		
	}
	else {
	//Verify the logged in Home Page
	home.WaitLoggedinHomePage();
	LoggedinFlag=home.VerifyLoggedinHomePage();
	if (LoggedinFlag) {
		Constants.Loggedinflag=true;
		//Verify Navigation and Org selector loaded in page else reload
		home.VerifyMenuOptions();
		UMReporter.log(Status.PASS,"logged in Successfully");
	}
	else
		UMReporter.log(Status.FAIL,"logged in Failed");
	}

}

@Given("^Login with user role (.*) in PA Refresh Site$")
public void Login_Into_PAUIR_Site_differentrole(String Userrole) throws IOException {
UMReporter.log(Status.INFO, "Given : Login with user role in PA Refresh Site "+Userrole);
	boolean flag =login.IsSignInHeaderExist();
	if (!flag) {
		//Launch PAUIR Site
		login.NavigatetoURL();
	}
	//Check PA site to support launched Browsers
	if (login.IsLoginToPAExist()) {
		String BrowserCheck=login.GetBrowserHeaderSysCheck();
		System.out.println("Browser Check : "+BrowserCheck);  
		//Select Login into Pearson Access Link
		login.ClickLoginToPA();
	}
	//Login into the Site
	login.doLogin(Userrole);
	CommonUtility._sleepForGivenTime(2000);
	if (login.IsTcPageExist()) {
		UMReporter.log(Status.PASS,"Logged In, new User Prompt to Accept the Terms and Condition");
	}
	else {
	//Verify the logged in Home Page
	home.WaitLoggedinHomePage();
	LoggedinFlag=home.VerifyLoggedinHomePage();
	if (LoggedinFlag) {
		Constants.Loggedinflag=true;
		Constants.LOGGEDINUSERROLE=Userrole;
		home.VerifyMenuOptions();
		UMReporter.log(Status.PASS,"logged in Successfully");
	}
	else
		UMReporter.log(Status.FAIL,"logged in Failed");
	}
}

@Given("^Login with user role for API Userrole Execution$")
public void Login_Into_PA5_Site_differentuserrole() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
UMReporter.log(Status.INFO, "Given : Login with user role for API Userrole Execution");
	boolean flag =login.IsSignInHeaderExist();
	HashMap<String,Object> MapAPIHeaders= null;
	String FsUserName=null;
	if (!flag) {
		//Launch PAUIR Site
		login.NavigatetoURL();
	}
		
	//Check PA site to support launched Browsers
		if (login.IsLoginToPAExist()) {
			String BrowserCheck=login.GetBrowserHeaderSysCheck();
			System.out.println("Browser Check : "+BrowserCheck);  
			//Select Login into Pearson Access Link
			login.ClickLoginToPA();
			
		}
		String Userrole=ThdUserole.get();
		//Login into the Site
		FsUserName=login.doLogin(Userrole);
		CommonUtility._sleepForGivenTime(2000);
		
		if (login.IsTcPageExist()) {
			UMReporter.log(Status.PASS,"Logged In, new User Prompt to Accept the Terms and Condition");
			
		}
		else {
		//Verify the logged in Home Page
		home.WaitLoggedinHomePage();
		LoggedinFlag=home.VerifyLoggedinHomePage();
		if (LoggedinFlag) {
			//Verify Navigation and Org selector loaded in page else reload
			home.VerifyMenuOptions();
			
			//Change Customer
			String CusName=FileReaderManager.getInstance().getJsonReader().getApplicationCustomer();
			//Verify the Customer Name
			boolean bVerifiedFlag =home.Func_VerifyCusName(CusName);
			//Change the Customer Name if not expected
			if (!bVerifiedFlag) 
				bVerifiedFlag=home.Func_ChangeCustomer(CusName);
			
			MapAPIHeaders=CommonFunctions.Get_Authorizationfromlog();
			if (MapAPIHeaders!=null) {
				System.out.println(MapAPIHeaders);
			  	String SelectedCustomer=FileReaderManager.getInstance().getJsonReader().getApplicationCustomer();
			  	HashMap<String,Object> mapPermissions=requests.GetAccount_Permissions(MapAPIHeaders,FsUserName,SelectedCustomer);
				if (mapPermissions!=null) {
					//driverscript.startDriverScript();
					System.out.println("mapPermissions"+mapPermissions);
					List<String> UserPermissions=(List<String>) mapPermissions.get("Permissions");
					UMReporter.log(Status.PASS,"The user permissions for user "+FsUserName+" are "+mapPermissions);
					String reportpath=driverscript.startNewDriverScript("json","APIUserroleSUITE",Userrole,"userrole",MapAPIHeaders.get("authorization").toString(),MapAPIHeaders.get("orgreferenceid").toString(),UserPermissions);//APIUserroleSUITE//APISmokeSUITE//APIRegressionSUITE
					UMReporter.log(Status.PASS,"API Execution completed and generated report <a href="+reportpath+">here</a>");
				}
				home.Logout();
				LoggedinFlag=false;
			}
				
			UMReporter.log(Status.PASS,"logged in Successfully");
		}
		
		else
			UMReporter.log(Status.FAIL,"logged in Failed");
		}

}

@Given("^Navigate to Home page$")
public void navigate_to_Home_page() throws Exception {
	 
	UMReporter.log(Status.INFO,"Navigate to Home page");
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	home.SelectCustomerLogo();
	//home.MenuOtion("home", "");
	//Verify the home page displayed
	boolean flag=home.VerifyLoggedinHomePage();
	if(flag)
		UMReporter.log(Status.PASS,"Navigated to Home page");
    else
    	UMReporter.log(Status.FAIL,"Unable to Navigate to Home page");
}

@Given("^User set the (.*) Project in Project Switcher$")
public void user_select_the_Provided_Customer(String CusName) throws IOException {
	
	UMReporter.log(Status.INFO, "Given :User set the Project in Project Switcher: "+CusName);
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	//Verify the Customer Name
	boolean bVerifiedFlag =home.Func_VerifyCusName(CusName);
	//Change the Customer Name if not expected
	if (!bVerifiedFlag) 
		bVerifiedFlag=home.Func_ChangeCustomer(CusName);
		
	UMReporter.log(Status.PASS,"Selected the Customer =>  "+CusName);
}

@Given("^User set the default in Organization Selector$")
public void user_select_the_Organization_details() throws IOException {	
	UMReporter.log(Status.INFO, "Given : User set the default in Organization Selector ");
	//Set Program, Year and Admin class variable
	if (LoggedinFlag) {
		String OrgName=FileReaderManager.getInstance().getJsonReader().getApplicationOrganization();
		
		//Verify the Org Details
		boolean bVerifiedFlag =home.Func_VerifyOrgName(OrgName);
		
		//Change the Org Details if not expected
		if (!bVerifiedFlag) 
			home.Func_ChangeOrganization(OrgName);
			
		//Constants.ORG_STATE=home.GetStatefromOrgName(OrgName);
		UMReporter.log(Status.PASS,"Selected the Org details =>  "+OrgName);
	}
	else
		UMReporter.log(Status.FAIL,"Login failed. Navigated to unexpected page");
	
}

@Given("^User set the (.*) Organization in Organization Selector$")
public void user_select_the_Provided_Organization_details(String OrgName) throws IOException {
	
	UMReporter.log(Status.INFO, "Given :User set the Organization in Organization Selector: "+OrgName);
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	
	//Verify the Org Details
	boolean bVerifiedFlag =home.Func_VerifyOrgName(OrgName);

	//Change the Org Details if not expected
	if (!bVerifiedFlag) 
		home.Func_ChangeOrganization(OrgName);
	
	//Constants.ORG_STATE=home.GetStatefromOrgName(OrgName);	
	UMReporter.log(Status.PASS,"Selected the Org details =>  "+OrgName);
	
}

@Given("^User select the (.*) Organization type in Organization Selector$")
public void user_select_the_Provided_OrganizationType_details(String OrgType) throws IOException {
	UMReporter.log(Status.INFO, "Given :User select the Organization type in Organization Selector: "+OrgType);
	if (!Constants.Loggedinflag) {
		UMReporter.log(Status.FAIL,"LogIn Failed. Navigated to unexpected page");
		throw new RuntimeException("Login fail!");
	}
	String OrgName=FileReaderManager.getInstance().getJsonReader().getSelectOrgName(OrgType); 
	//Verify the Org Details
	boolean bVerifiedFlag =home.Func_VerifyOrgName(OrgName);

	//Change the Org Details if not expected
	if (!bVerifiedFlag) 
		home.Func_ChangeOrganization(OrgName);
	
	//Constants.ORG_STATE=home.GetStatefromOrgName(OrgName);	
	UMReporter.log(Status.PASS,"Selected the Org details =>  "+OrgName);
	
}

@Given("^Return to Home page$")
public void return_to_Home_page() throws Exception {
		UMReporter.log(Status.INFO,"Navigate to Home page");
		home.SelectCustomerLogo();
		//home.MenuOtion("home", "");
		//Verify the User list page displayed
		boolean flag=home.VerifyLoggedinHomePage();
		if(flag)
			UMReporter.log(Status.PASS,"Navigated to Home page");
	    else
	    	UMReporter.log(Status.FAIL,"Unable to Navigate to Home page");

}

@Given("^Logout the PA Refresh Site$")
public void Logout_close_browser() throws IOException {

	UMReporter.log(Status.INFO, "Given : Logout and close browser");
	//home.MenuOtion("home", "");
	//home.Logout();

	System.out.println("Logout the PA Refresh Site LoggedinFlag: "+LoggedinFlag+" ConstantLoggedinflag: "+Constants.Loggedinflag+" Thread :"+threadId);
	
	if (LoggedinFlag){
		LoggedinFlag=false;
		Constants.Loggedinflag=false;
		home.Logout();
		UMReporter.log(Status.PASS,"logout Successfully");
	}
	else
		UMReporter.log(Status.FAIL,"LogIn Failed.");
		
}

@Given("^Login Demo test url launch$")
public void Login_URL_Demo_Test() throws Exception {
		UMReporter.log(Status.INFO,"Given : Login Demo test url launch");
		System.out.println("Login Demo test url launch");
		login.NavigatetoTestURL();
		//login.NavigatetoURL();
		//LoggedinFlag=false;
		UMReporter.log(Status.PASS,"Login Demo test url launch");
		
}

@Given("^Login Demo test$")
public void Demo_Test() throws Exception {
		UMReporter.log(Status.INFO,"Given : Login Demo test");
		System.out.println("Login Demo test");
		//LoggedinFlag=false;
		UMReporter.log(Status.PASS,"Login Demo test");
		
}
@When("^Demo test Step$")
public void Demo_Test_Step() throws Exception {
		UMReporter.log(Status.INFO,"When : Demo test Step");
		System.out.println("Demo test Step");
	//	Assume.assumeTrue(false);
		UMReporter.log(Status.PASS,"Demo test Step");
		// throw new AssumptionViolatedException("Skippingggg");
}

@Then("^Demo test another Step$")
public void Demo_Test_Step2() throws Exception {
		UMReporter.log(Status.INFO,"Then : Demo test another Step");
		System.out.println("Demo test another Step");
	//	Assume.assumeTrue(false);
		UMReporter.log(Status.PASS,"Demo test another Step");
		// throw new AssumptionViolatedException("Skippingggg");
}

}
