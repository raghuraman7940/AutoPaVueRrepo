/**
 * API- Step Definition 
 */
package com.pavue.stepdefinitions;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.aventstack.extentreports.Status;
import com.pavue.request.api.DriverScript;
import com.pavue.request.api.ReportJSON;
import com.pavue.request.api.RequestMethod;
import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.UMReporter;
import com.pavue.common.core.CommonFunctions;
import com.pavue.common.core.FileReaderManager;
import com.pavue.common.util.Constants;



public class APISteps {
	
	//Initialize the class variable
	public static HashMap<String,String> MapUserField=null;
	public static HashMap<String, String> MapUserFilledFields = null;
	public static HashMap<String,String> MapUserEditedFields=null;
	public static List<String> lstSelectedImport=null;
	public static CommonFunctions common;
	public static DriverScript driverscript;
	public static  RequestMethod requests;
	public static ReportJSON RepJs;
	
	public APISteps()throws IOException, NoSuchMethodException, SecurityException{
		//Initialize the Page object
		
		driverscript= new DriverScript();
		RepJs=new ReportJSON();
		requests=new RequestMethod();
	}
	
	@Given("^the API Request input details (.*), (.*), (.*), (.*), (.*)$")     
	public void navigate_to_DataImports_page(String RequestUrl) throws Exception {
		UMReporter.log(Status.INFO, "Given : API Request input details");
		if (!Constants.Loggedinflag) {
			UMReporter.log(Status.FAIL,"LogIn Failed. Unable to run Students");
			throw new RuntimeException("Login fail!");
		}
		
	}
	

@Then("^User get the role permissions for loggedin user$")
public void user_get_authorization_org_Performancelog() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	UMReporter.log(Status.INFO, "Given: User get the role permissions for logged In user : "+Constants.LOGGEDIN_USER);
	//Get auth and org for API for Authentication
	Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	if (Constants.APIheaders!=null) {
		System.out.println(Constants.APIheaders);
	  	//String loggedInuser=FileReaderManager.getInstance().getJsonReader().getApplicationUsername();
	  	String SelectedCustomer=FileReaderManager.getInstance().getJsonReader().getApplicationCustomer();
	  	HashMap<String,Object> mapPermissions=requests.GetAccount_Permissions(Constants.APIheaders,Constants.LOGGEDIN_USER,SelectedCustomer);
		if (mapPermissions!=null) {
			//driverscript.startDriverScript();
			System.out.println("mapPermissions"+mapPermissions);
			Constants.PERMISSIONS=(List<String>) mapPermissions.get("Permissions");
			UMReporter.log(Status.PASS,"The user permissions for user "+Constants.LOGGEDIN_USER+" are "+mapPermissions);
		}
		else
			UMReporter.log(Status.FAIL,"INFO GET Account API unable to get permission");
	}
}

	
@Then("^User executes Smoke API Suite$")
public void user_get_APIauthorization_APIDriverScript() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	UMReporter.log(Status.INFO, "Given:User executes Smoke API Suite ");
	//Get auth and org for API for Authentication
	Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	if (Constants.APIheaders!=null) {
	  	String reportpath=driverscript.startNewDriverScript("json","APISmokeSUITE",Constants.LOGGEDINUSERROLE,"smoke",Constants.APIheaders.get("authorization").toString(),Constants.APIheaders.get("orgreferenceid").toString(),Constants.PERMISSIONS); //APISmokeSUITE//APIRegressionSUITE//APIUserroleSUITE
		UMReporter.log(Status.PASS,"API Execution completed and generated report <a href="+reportpath+">here</a>");
	}
}

@Then("^User executes Regression API Suite$")
public void user_get_APIauthorization_APIDriverScript_RegressionSuite() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	UMReporter.log(Status.INFO, "Given:User executes Regression API Suite");
	//Get auth and org for API for Authentication
	Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	if (Constants.APIheaders!=null) {
	  	String reportpath=driverscript.startNewDriverScript("json","APIRegressionSUITE",Constants.LOGGEDINUSERROLE,"regression",Constants.APIheaders.get("authorization").toString(),Constants.APIheaders.get("orgreferenceid").toString(),Constants.PERMISSIONS); //APISmokeSUITE//APIRegressionSUITE//APIUserroleSUITE	  	
		UMReporter.log(Status.PASS,"API Execution completed and generated report <a href="+reportpath+">here</a>");
	}
}

@Then("^User execute User Role API Suite$")
public void user_get_APIauthorization_APIDriverScript_ForUserRole() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	UMReporter.log(Status.INFO, "Given: User execute User Role API Suite ");
	//Get auth and org for API for Authentication
	//Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	if (Constants.APIheaders!=null) {
	  	String reportpath=driverscript.startNewDriverScript("json","APIUserroleSUITE",Constants.LOGGEDINUSERROLE,"userrole",Constants.APIheaders.get("authorization").toString(),Constants.APIheaders.get("orgreferenceid").toString(),Constants.PERMISSIONS); //APISmokeSUITE//APIRegressionSUITE//APIUserroleSUITE
		UMReporter.log(Status.PASS,"API Execution completed and generated report <a href="+reportpath+">here</a>");
	}
}

@Then("^User execute User Role Permission Matrix setup$")
public void user_get_APIUserrole_Matrix_APIDriverScript_ForUserRole() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	UMReporter.log(Status.INFO, "Given: User execute User Role API Suite ");
	//Get auth and org for API for Authentication
	//Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	if (Constants.APIheaders!=null) {
		String XlsxInputFile = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() +Constants.TEST_XLFILE;
	    String XLInputSheetName="UserrolePermissionSetup";
	    RepJs.GenerateUserroleTestDataFromExcelData(XlsxInputFile, XLInputSheetName,"ReportingAdmin");
		UMReporter.log(Status.PASS,"Generated Userrole matrix completed and generated report");
	}
}

@When("^Remove sessions (.*) upto max (.*) session$")
public void Select_student_list_checkbox_SessionDetails(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove sessions "+Searchtext+" upto max "+sMaxcount+" session");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;
	
	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		orgrefid=CommonFunctions.getTestData("schoolrefid");
		HashMap<String,Object> mapSesssref=requests.GetAndDeleteSessions(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted "+mapSesssref.size()+" Session : "+mapSesssref);
		if (mapSesssref!=null)
			if (mapSesssref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapSesssref.size()+" Sessions  "+mapSesssref.values());
			else
				UMReporter.log(Status.PASS, "No Session deleted due to dependency/with searchtext : "+Searchtext);
		
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete sessions");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete sessions");
    
}	
	
@When("^Remove classes (.*) upto max (.*) classes$")
public void Remove_Classes_upto_maxcount(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove classes "+Searchtext+" upto max "+sMaxcount+" classes");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Class
		orgrefid=CommonFunctions.getTestData("schoolrefid");
		HashMap<String,Object> mapClassref=requests.GetAndDeleteOrgclass(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted "+mapClassref.size()+" Classes : "+mapClassref);
		if (mapClassref!=null)
			if (mapClassref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapClassref.size()+" Classes "+mapClassref.values());
			else
				UMReporter.log(Status.PASS, "No classes deleted due to dependency /with searchtext : "+Searchtext);
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete Classes");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete Classes");
    
}

@When("^Remove students (.*) upto max (.*) students$")
public void Remove_Students_upto_maxcount(String Searchtext,String sMaxcount) throws Exception {
	// UMReporter.log(Status.INFO, "When : Remove students "+Searchtext+" upto max "+sMaxcount+" students");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Students
		orgrefid=CommonFunctions.getTestData("schoolrefid");
		HashMap<String,Object> mapStudsref=requests.GetAndDeleteStudents(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted "+mapStudsref.size()+" Students : "+mapStudsref);
		if (mapStudsref!=null)
			if (mapStudsref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapStudsref.size()+" Students "+mapStudsref.values());
			else
				UMReporter.log(Status.PASS, "No Students deleted due to dependency/with searchtext : "+Searchtext);
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete Students");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete Students");
    
}

@When("^Remove (.*) organizations (.*) upto max (.*) organizations$")
public void Remove_Organizations_upto_maxcount(String OrgType,String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove "+OrgType+" organizations "+Searchtext+" upto max "+sMaxcount+" organizations");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Organization
		orgrefid=CommonFunctions.getTestData("staterefid");
		HashMap<String,Object> mapOrgref=requests.GetAndDeleteOrg(Constants.APIheaders,orgrefid,MaxCount,OrgType,Searchtext);
		System.out.println("Deleted "+mapOrgref.size()+" "+OrgType+" Organizations : "+mapOrgref);
		if (mapOrgref!=null)
			if (mapOrgref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapOrgref.size()+" "+OrgType+" Organizations "+mapOrgref.values());
			else
				UMReporter.log(Status.PASS, "No "+OrgType+" Orgnizations deleted ");
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete schools due to dependency/with searchtext : "+Searchtext);
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete schools");
    
}

@When("^Remove test admin (.*) upto max (.*) test admin$")
public void Remove_testadmin_upto_maxcount(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove test admin "+Searchtext+" upto max "+sMaxcount+" test admin");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Test admins
		orgrefid=CommonFunctions.getTestData("masteradminrefid");
		HashMap<String,Object> mapTstAdminref=requests.GetAndDeleteTestAdmins(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted TestAdmin Count  : "+mapTstAdminref.size());
		System.out.println("Deleted TestAdmin  : "+mapTstAdminref);
		if (mapTstAdminref!=null)
			if (mapTstAdminref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapTstAdminref.size()+" test admins "+mapTstAdminref.values());
			else
				UMReporter.log(Status.PASS, "No Test Admin deleted due to dependency/with searchtext : "+Searchtext );
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete test admin");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete test admin");
    
}


@When("^Remove tests (.*) upto max (.*) tests$")
public void Remove_tests_upto_maxcount_test(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove test admin "+Searchtext+" upto max "+sMaxcount+" test admin");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Test admins
		orgrefid=CommonFunctions.getTestData("masteradminrefid");
		HashMap<String,Object> mapTstAdminref=requests.GetAndDeleteTests(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted Tests Count  : "+mapTstAdminref.size());
		System.out.println("Deleted Tests  : "+mapTstAdminref);
		if (mapTstAdminref!=null)
			if (mapTstAdminref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapTstAdminref.size()+" tests "+mapTstAdminref.values());
			else
				UMReporter.log(Status.PASS, "No Tests deleted due to dependency/ with searchtext : "+Searchtext);
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete tests");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete tests");
    
}

@When("^Remove formcode (.*) upto max (.*) formcode$")
public void Remove_formcodes_upto_maxcount_formcode(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove test admin "+Searchtext+" upto max "+sMaxcount+" test admin");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Test admins
		orgrefid=CommonFunctions.getTestData("masteradminrefid");
		HashMap<String,Object> mapTstAdminref=requests.GetAndDeleteFormcode(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted formcode Count  : "+mapTstAdminref.size());
		System.out.println("Deleted formcode  : "+mapTstAdminref);
		if (mapTstAdminref!=null)
			if (mapTstAdminref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapTstAdminref.size()+" formcode "+mapTstAdminref.values());
			else
				UMReporter.log(Status.PASS, "No formcode deleted due to dependency ");
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete formcode");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete tests");
    
}


@When("^Remove Accommodations (.*) upto max (.*) Accommodations$")
public void Remove_Accommodations_upto_maxcount_Accommodations(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove test admin "+Searchtext+" upto max "+sMaxcount+" test admin");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Test admins
		orgrefid=CommonFunctions.getTestData("masteradminrefid");
		HashMap<String,Object> mapTstAdminref=requests.GetAndDeleteAccommodations(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted Accommodations Count  : "+mapTstAdminref.size());
		System.out.println("Deleted Accommodations  : "+mapTstAdminref);
		if (mapTstAdminref!=null)
			if (mapTstAdminref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapTstAdminref.size()+" Accommodations "+mapTstAdminref.values());
			else
				UMReporter.log(Status.PASS, "No Accommodations deleted due to dependency/ with searchtext : "+Searchtext);
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete Accommodations");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete tests");
    
}

@When("^Remove Irregularity (.*) upto max (.*) Irregularity$")
public void Remove_Irregularity_upto_maxcount_Irregularity(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove test admin "+Searchtext+" upto max "+sMaxcount+" test admin");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Test admins
		orgrefid=CommonFunctions.getTestData("masteradminrefid");
		HashMap<String,Object> mapTstAdminref=requests.GetAndDeleteIrregularity(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted Irregularity Count  : "+mapTstAdminref.size());
		System.out.println("Deleted Irregularity  : "+mapTstAdminref);
		if (mapTstAdminref!=null)
			if (mapTstAdminref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapTstAdminref.size()+" Irregularity "+mapTstAdminref.values());
			else
				UMReporter.log(Status.PASS, "No Irregularity deleted due to dependency / with searchtext : "+Searchtext);
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete Irregularity");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete Irregularity");
    
}

@When("^Remove Irregularity category (.*) upto max (.*) Irregularity category$")
public void Remove_Irregularitycategory_upto_maxcount_Irregularitycategory(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove test admin "+Searchtext+" upto max "+sMaxcount+" test admin");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Test admins
		orgrefid=CommonFunctions.getTestData("masteradminrefid");
		HashMap<String,Object> mapTstAdminref=requests.GetAndDeleteIrregularitycategory(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted Irregularity category Count  : "+mapTstAdminref.size());
		System.out.println("Deleted Irregularity category : "+mapTstAdminref);
		if (mapTstAdminref!=null)
			if (mapTstAdminref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapTstAdminref.size()+" Irregularity category "+mapTstAdminref.values());
			else
				UMReporter.log(Status.PASS, "No Irregularity category deleted due to dependency/ with searchtext : "+Searchtext);
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete Irregularity category");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete Irregularity category");
    
}

@When("^Remove TestNavConfig (.*) upto max (.*) TestNavConfig$")
public void Remove_TestNavConfig_upto_maxcount_TestNavConfig(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove test admin "+Searchtext+" upto max "+sMaxcount+" test admin");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Test admins
		orgrefid=CommonFunctions.getTestData("masteradminrefid");
		HashMap<String,Object> mapTstAdminref=requests.GetAndDeleteTestNavConfig(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted TestNavConfig Count  : "+mapTstAdminref.size());
		System.out.println("Deleted TestNavConfig : "+mapTstAdminref);
		if (mapTstAdminref!=null)
			if (mapTstAdminref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapTstAdminref.size()+" TestNavConfig "+mapTstAdminref.values());
			else
				UMReporter.log(Status.PASS, "No TestNavConfig deleted due to dependency/ with searchtext : "+Searchtext);
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete TestNavConfig");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete TestNavConfig");
    
}


@When("^Remove Permissions (.*) upto max (.*) Permissions$")
public void Remove_Permissions_upto_maxcount_Permissions(String Searchtext,String sMaxcount) throws Exception {
	//UMReporter.log(Status.INFO, "When : Remove test admin "+Searchtext+" upto max "+sMaxcount+" test admin");
	int MaxCount=0;
	if (CommonUtility.isNumeric(sMaxcount))
		MaxCount=Integer.parseInt(sMaxcount);
	String orgrefid=null;

	if (Constants.APIheaders==null) 
		Constants.APIheaders=CommonFunctions.Get_Authorizationfromlog();
	
	if (Constants.APIheaders!=null) {
		//Delete Test admins
		orgrefid=CommonFunctions.getTestData("masteradminrefid");
		HashMap<String,Object> mapTstAdminref=requests.GetAndDeletePermissions(Constants.APIheaders,orgrefid,MaxCount,Searchtext);
		System.out.println("Deleted Permissions Count  : "+mapTstAdminref.size());
		System.out.println("Deleted Permissions : "+mapTstAdminref);
		if (mapTstAdminref!=null)
			if (mapTstAdminref.size()>0)
				UMReporter.log(Status.PASS, "Deleted "+mapTstAdminref.size()+" Permissions "+mapTstAdminref.values());
			else
				UMReporter.log(Status.PASS, "No Permissions deleted due to dependcy/ with searchtext "+Searchtext);
	    else
	    	UMReporter.log(Status.FAIL, "Unable to delete Permissions");
	}
	else
    	UMReporter.log(Status.SKIP, "Unable to delete Permissions");
    
}
}
	
	
	
	
	
	
	
	
	
