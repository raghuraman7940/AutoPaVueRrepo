package com.pavue.common.util;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class Constants {

	//General data
	public final static String KEYWORD = "Keyword";
	public final static String KEYWORD_PASS = "Pass";
	public final static String KEYWORD_FAIL = "Failed";
	public final static String KEYWORD_SKIP = "Skip";
	public final static String KEYWORD_REF = "ref#";
	public final static String DATA_SPLIT = "\\|";
	public final static Object POSITIVE_DATA = "Y";
	public final static String RANDOM_VALUE = "@random";
	public final static String KEYWORD_RANDOM = "#random";
	public final static String DATASET_SPLIT = "@";
	public final static String BDD_VALUESEPERATOR = "~";
	public final static String BDD_TABSEPERATOR = "|";
	public final static String CONFIG = "config";
	public final static String SRC_RES_FILEPATH="/downloads/Response/";
	public final static String SRC_RES_EXPORTFILEPATH="/src/main/resources/com/pavue/envtestdata/";
	
	//Project data
	public final static String PROJECTNAME = "Automation Test Report";
	public final static String REPORTTYPE = "Desktop";
	public final static String REPORTTESTDESC = "Regression Test - Scenarios";
	public final static String REPORTCROSSTESTDESC = "Cross Browser Test - Scenarios";
	public static String BROWSERTYPE = "Firefox";
	public static String OSTYPE = "Windows";
	public static String popupdropdownlist="xpath|//kendo-popup/div/kendo-list/div/ul/li";
	public static String INVALID_DATA = "Invalid~!@#$";
	public static String LOGGEDIN_USER = "test@email.com";
	public static String LOGGEDINUSERROLE = "System Admin";
	public static boolean Loggedinflag = false;
	
	//API
	public static String APIServer = "https://pa-dev-main.pearsonpathway.com";
	public static HashMap<String, Object> APIheaders =null;
	public static HashMap<String, Object> SuiteAPIheaders=null;
	public static String APIFieldKeys[] =new String[]{ "code", "name","overrideLabel", "type","description", "required", "minLength", "maxLength", "viewFieldOptions","regex" };
	public static List<String> PERMISSIONS = Arrays.asList("CREATE_STUDENT","DELETE_STUDENT", "VIEW_STUDENTS_LIST","VIEW_STUDENT_PROFILE_RESTRICTED", "ACCESS_CLASSES","CREATE_TEMPORARY_STUDENT","ACCESS_TEST_SESSIONS");
	public static String OauthToken = null;
	public static String UserroleOutputfile = null;
	public static HashMap<String, String> mapUserroleJsonOutputfiles =new HashMap<String,String>();
	public static HashMap<String, String> mapUserroleJsonReportfiles =new HashMap<String,String>();
	public static HashMap<String, String> mapUserrolehtmlReportfiles =new HashMap<String,String>();;
	public static String JSUserRole = "Userrole";
	public static String JSUsersuite = "usersuites";
	public static String UserRoleAdmin="Admin";
	public static String UserRoleTestCoordinator="TestCoordinator";
	public static String UserRoleTestCoordinatorInterim="TestCoordinator_Interim";
	public static String UserRoleTeacher="Teacher";
	public static String UserRoleReportingAdmin="ReportingAdministrator";
	public static String UserRoleHandScoreAdmin="HandScoringAdministrator";
	public static String UserRoleSystemAdmin="SystemAdmin";
	public static String UserRoleTechSupport="TechnicalSupport";
	public static String UserRoleCS1="CustomerSupport1";
	public static String UserRoleCS2="CustomerSupport2";

	
	//Suite Sheet
	public static String SUITE_XLFILE="Suite.xlsx";
	public static String SUITE_ID = "TestSuiteID";
	public static String DESCRIPTION = "Description";
	public static String TEST_SUITE_SHEET = "TestSuite";
	public static String Test_Suite_ID = "TestSuiteID";
	public static String TEST_CASES_SHEET = "SuiteName";
	public static String RUNMODE = "RunMode";
	public static String RUNMODE_YES = "YES";
	
	//Input Sheet Column
	public static String TEST_XLFILE="APITestSuites.xlsx";
	public static String XLFILE_FILEPATH="\\src\\main\\resources\\com\\pauir\\testDataResources\\";
	public static String TEST_SHEET ="APISmokeSUITE";
	public static String TEST_JSFILE_Regression ="APIRegressionSuite.json";
	public static String TEST_JSFILE_Smoke ="APISmokeSuite.json";
	public static String TEST_JSFILE_UserRole ="APIUserroleSuite.json";
	public static String TEST_RegressionType ="Regression";
	public static String TEST_SmokeType ="Smoke";
	public static String TEST_UserRoleType ="User Role";
	public static String GlobalHeader="globalheaders";	
	public static String TCID = "operationId";
	public static String DATASET = "DatasetID";
	public static String TESTRUNMODE = "RunMode";
	public static String SERVER="Server";	
	public static String URL="RequestURL";	
	public static String Summary="summary";	
	public static String MethodType="MethodType";
	public static String headers="headers";
	public static String expected="Expected";
	public static String output="Output";
	public static String parameters="parameters";
	public static String requestparameters="RequestParameters";
	public static String pathparameters="Pathparameters";
	public static String Queryparameters="Queryparameters";
	public static String postbody="postbody";
	public static String Header_Keys="Header_Keys";	
	public static String Header_Values="Header_Values";	
	public static String Param_Keys="Param_Keys";	
	public static String Param_Values="Param_Values";
	public static String Expected_Keys="Expected_Keys";
	public static String Expected_Values="Expected_Values";
	public static String ExpectedStatusCode="ExpectedStatusCode";
	public static String ExpectedSchema="ExpectedSchema";
	public static String GetOutputKey="GetOutputKey";
	public static String SwitchingMode="SwitchingMode";
	public static String TestStatus = "TestStatus";
	public static String RESULT = "TestResultStatus";
	public static String ResponseDescription="ResponseDescription";
	public static String ResponseTime="ResponseTime";
	public static String Output_Values="Output_Values";
	public static String Response="Response";
	public static String ExeTag="tags";
	public static String Dependent="Dependent";
	public static String UserPermissions="Userpermissions";
	public static String DataDescription="DataDescription";
	
	//TestResults
	public static String RepIssue_key="operationId";
	public static String RepAPIMethodType="MethodType";
	public static String RepAPIRequest="RequestURL";
	public static String RepAPIURL="APIURL";
	public static String RepAPIDescription="Summary";
	public static String RepInput_KeyValues="RequestParameter";
	public static String RepExpected="Expected";
	public static String RepTestResultStatus="TestResultStatus";
	public static String RepResponseDescription="ResponseDescription";
	public static String RepResponseTime="ResponseTime";
	public static String RepOutput_Values="Output_Values";
	public static String RepStatusCode="StatusCode";
	public static String RepResponse="Response";
	public static String ResponseFilePath="ResponseFilePath";
	
	// Csv File Header
	public static final String REFURLValue = "RefValue";
	public static final String METHOD_TYPE = "MethodType";
	public static final String HEADER_KEYS = "Header_Keys";
	public static final String HEADER_VALUES = "Header_Values";
	public static final String PARAM_KEYS = "Param_Keys";
	public static final String PARAM_VALUES = "Param_Values";
	public static final String EXPECTED_KEYS = "Expected_Keys";
	public static final String EXPECTED_VALUES = "Expected_Values";
	public static final String EXPECTED_STATUS_CODE = "ExpectedStatusCode";
	public static final String EXPECTED_SCHEMA = "ExpectedSchema";
	public static final String GET_OUTPUT_KEY = "GetOutputKey";
	public static final String SWITCHING_MODE = "SwitchingMode";
	public static final String TEST_RESULT_STATUS = "TestResultStatus";
	public static final String RESPONSE_DESCRIPTION = "ResponseDescription";
	public static final String RESPONSE_TIME = "ResponseTime";
	public static final String OUTPUT_VALUES = "Output_Values";
	public static final String PASS = "Pass";
	public static final String FAILED = "Failed";
	public static final String NULL_VALUE = "null";
	public static final String RUNMODE_VALUE_YES = "Yes";
	public static final String RUNMODE_VALUE_NO = "No";
	public static final String ISSUE_KEY_LIST = "Issue_key";
	public static final String ISSUE_KEY = "Issue_key";	
	public static final String PROJECT = "Project_key";
	public static final String SPRINT = "Sprint";
	public static  final String FIXVERSION = "Version";
	public static final String FIXRELEASEDATE = "ReleaseDate";
	public static final String SUMMARY = "summary";
	public static final String DETAILS = "Details";
	public static final String INPUT_VALUES = "INPUT_VALUES";
	public static final String LABELS = "labels";
	public static final String FIX_VERSION = "Fix Version/s";
	public static final String TESTINGTYPE = "TestingType";
	public static final String RecordDelimiter = "\\r?\\n";
	public static final String NEWLineDelimiter = "\n";
	public static final String ValueDelimiter = ",";
	public static final String DATAFLAG = "DSFlag";
	public static final String DATASETID = "DatasetID";
	public static final String DATASETS = "Datasets";
	public static final String Tests = "Tests";
	public static final String DEPENDENTISSUES = "DependentIssues";
	public static final String EnvironmentData = "environment";
	public static final String CurrentSuiteData = "currentsuite";
	public static final String GenerateOauthToken = "generateoauthtoken";
	public static final String SecretKey = "PAAUTOMATIONSECKEY";
	

	//JSON Report TAG
	public static String JIRAProject = "Pearson Access";
	public static String JIRAIssueType = "Test";
	public static String JIRASprint = "Sprint-1";
	public static String TestingType = "Smoke";
	public static String ExecutionDuration = "30";
	public static String TimeType = "Mins";
	public static String ReleaseType = "Build";
	public static String BuildReleaseVersion = "271";
	public static String JIRAReleaseDate = "2017-03-31";
	//JSON Report TAG
	public static String JSReportTitle = "TestDataTitle";
	public static String JSRunDate = "RunDate";
	public static String JSRunEnvironment = "RunEnvironment";
	public static String JSTestingType = "TestingType";
	public static String JSReleaseVersion = "ReleaseVersion";
	public static String JSReleaseDate = "ReleaseDate";
	public static String JSVersion = "Version";
	public static String JSsuite = "suite";
	public static String JSsuiteTitle = "title";
	public static String JSsuiteName = "SUITENAME";
	public static String JSsuiteDes = "DESCRIPTION";
	public static String JSProject = "Project";
	public static String JSIssueType = "IssueType";
	public static String JSSprint = "Sprint";
	public static String JSsuiteStatus = "Status";
	public static String JSExecutionDuration = "TimeTaken";
	public static String JSsuiteNoOfTestCases = "NoOfTestCases";
	public static String JSsuiteNoOfPassed = "NoOfPassed";
	public static String JSsuiteNoOfFailed = "NoOfFailed";
	public static String JSsuitNoOfSkipped = "NoOfSkipped";
	public static String JSsuitTest = "tests";
	public static String JSsuitDataSets = "Datasets";
	

}