package com.pavue.common.core;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;

import com.aventstack.extentreports.Status;
import com.pavue.common.util.Constants;
import com.pavue.webdriver.CheckBox;
import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.KendoDropdown;
import com.pavue.webdriver.LeftClick;
import com.pavue.webdriver.Log;
import com.pavue.webdriver.SelectDropdown;
import com.pavue.webdriver.TextBox;
import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;
import com.pavue.common.core.FileReaderManager;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class CommonFunctions {
	public static String strLoadURL=null;
	public static String strLoginUserName=null;
	public static String strLoginPassword=null;
	static LinkedHashMap<String, String>[] data = null;
	static ArrayList<LinkedHashMap<String, String>> htData;
	static int rowIndex = 0, columnIndex = 0;
	

	/**Function Name :- InitializeDriver<br/>
	 * Description   :- Initialize web driver
	 * @param BrowserType
	 */
	public static void InitializeWebDriver(String BrowserType) {
		WebDriver driver;
		try {
			driver = LocalDriverFactory.createInstance(BrowserType);
			WebDriverMain.setDriver(driver);
			//Log._logInfo("Browser Launched : "+BrowserType);
			CommonUtility._sleepForGivenTime(1000);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**Function Name :- CloseWebDriver<br/>
	 * Description   :- Closer web driver
	 */
	public static void CloseWebDriver() {
		WebDriver driver = WebDriverMain._getDriver();
		if (driver != null) {
			driver.close();
		}
	}
	
	/**Function Name :- CloseAllWebDriver<br/>
	 * Description   :- Closer all web driver
	 */
	public static void CloseAllWebDriver() {
		try{
			WebDriver driver = WebDriverMain._getDriver();
			if (driver != null) {
				driver.close();
				Thread.sleep(3000);
				driver.quit();
				Thread.sleep(3000);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}


	/**Function Name :- Get_Cookie<br/>
	 * Description   :- Get cookie value from webdriver
	 * @param cookiename
	 * @param valuetype
	 * @return String
	 */
	public static String Get_Cookie(String cookiename,String valuetype) {
		
		WebDriver driver = WebDriverMain._getDriver();
		String RetValue=null;
		if (driver != null) {
			  
		        Cookie cookie=driver.manage().getCookieNamed(cookiename);
		        switch(valuetype.toLowerCase())
		        {
		        case "value":
		        	RetValue=cookie.getValue();
		        	break;
		        case "domain":
		        	RetValue=cookie.getDomain();
		        	break;
		        case "path":
		        	RetValue=cookie.getPath();
		        	break;
		        case "expiry":
		        	RetValue=cookie.getExpiry().toString();
		        	break;
		        default:
		        	RetValue=cookie.getValue();
		        }
		}
		return RetValue;
	
}
	
	
	/**Function Name :- Get_Authorizationfromlog<br/>
	 * Description   :- Get Authorization value from log
	 * @param cookiename
	 * @param valuetype
	 * @return String
	 */
	public static HashMap<String, Object> Get_Authorizationfromlog() {
		
		LogEntries les = WebDriverMain._getDriver().manage().logs().get(LogType.PERFORMANCE);
		String authorization=null;
		HashMap<String,Object> MapPerfLogs=  null;
		String OrgRefId=null;
		for (LogEntry le :les ) {
			String infomsg=le.getMessage();
			if ((infomsg.contains("authorization"))&&(infomsg.contains("orgreferenceid"))) {
				//System.out.println("infomsg: " +infomsg);
				MapPerfLogs=  new HashMap<String,Object>();
				String part1infomsg=infomsg.substring(infomsg.indexOf("authorization")+16);
				 authorization=part1infomsg.substring(0, part1infomsg.indexOf("\",\""));
				// System.out.println("part1infomsg: " +part1infomsg);
				 String part2infomsg=part1infomsg.substring(part1infomsg.indexOf("orgreferenceid")+17);
				 OrgRefId=part2infomsg.substring(0,part2infomsg.indexOf("\",\""));
				 MapPerfLogs.put("authorization", authorization);
				 MapPerfLogs.put("orgreferenceid", OrgRefId);
				 //System.out.println("part2infomsg: " +part2infomsg);
				 //	System.out.println("Auth: " +authorization);
			//	System.out.println("orgreferenceid: " +OrgRefId);
				return MapPerfLogs;
			}
		}
		
		return MapPerfLogs;
	
}

	

	/**Function Name :- PleaseWaitMessage<br/>
	 * Description   :- wait for the element for a default duration of customized seconds
	 * @param locator
	 * @param wdDriver
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean PleaseWaitAndLoadingMessage() throws IOException {
		
		int msgTimeOut = 20;
		boolean status=true;
		int i =0;
		while(status){
			if((!WebDriverMain._isElementVisible(By.cssSelector("div.blockUI.blockMsg.blockElement")))&&(!WebDriverMain._isElementVisible(By.cssSelector("div.blockUI.blockMsg.blockPage")))
					&&((boolean)((JavascriptExecutor) WebDriverMain._getDriver()).executeScript("return 'complete' == document.readyState;"))
					)
				status=false;
			i++;
			if(i>msgTimeOut) {
				status=false;
				//Log._logWarning("*****Time out happened*******");
			}
		}
		
		return true;	
	}

	/**Function Name :- switchCase<br/>
	 * Description   :- Provides the operation depending on fieldtype 
	 * @param arg
	 * @param locator
	 * @param fieldType
	 * @param strValue
	 * @param Label
	 * @param WebDriverMain._getDriver()
	 * @return boolean
	 * @throws IOException 
	 */
	public static String FillInputswitchCase(String fieldType,By locator,By subLocator, String strValue,String Label) throws IOException{
		/*if(fieldType.equalsIgnoreCase("Button") || fieldType.equalsIgnoreCase("linktext") || fieldType.equalsIgnoreCase("CheckBox")){*/
		//PleaseWaitAndLoadingMessage();
		String RetnstrValue=null;
		boolean flag =true;
		try{
			if(strValue.equalsIgnoreCase(null)){

				strValue = "";
			}
			
		}catch(NullPointerException nullE){
			strValue = "";
		}
		fieldType = fieldType.toLowerCase().trim();
		switch(fieldType){
		case "textbox":
			
			if ((strValue.indexOf("@mail.com")>=0)||(strValue.indexOf("@pearson.com")>=0)||(strValue.indexOf("@pathway.com")>=0)) {
				String RtnEmail="AutoTest";
				String RecSplit[] = null;
				String RtnEmail_last=null;
				
				if (strValue.indexOf("@pearson.com")>=0) {
					 RecSplit=strValue.split("@pearson.com");
					 RtnEmail_last="@pearson.com";
				}
				else if (strValue.indexOf("@mail.com")>=0) {
					 RecSplit=strValue.split("@mail.com");
					 RtnEmail_last="@mail.com";
				}
				else if (strValue.indexOf("@pathway.com")>=0) {
					 RecSplit=strValue.split("@pathway.com");
					 RtnEmail_last="@pathway.com";
				}
				if (RecSplit.length>=1)
					if (RecSplit[0].indexOf("@random")>=0)
							RtnEmail=generateRandomString(RecSplit[0]);
					else
							RtnEmail=strValue;
						
				strValue=RtnEmail+RtnEmail_last;
			}
			if (strValue.indexOf("@random")>=0)
				strValue=generateRandomString(strValue);
		
			flag = TextBox._setTextBox(locator, strValue.trim());
			if(flag)
				RetnstrValue=strValue;
				
			break;
		case "dropdown":
			flag = SelectDropdown._selectByVisibleText(locator, strValue);
			break;
			
		case "datepicker":
			if (strValue.indexOf("@random")>=0)
				strValue=generateRandomDate(strValue);
		
			flag = SetDateInput(locator,Label, strValue);
			if(flag) {
				RetnstrValue=TextBox._GetTextBoxValue(locator);
				//RetnstrValue=removeZeroPadding(RetnstrValue);
			}
			break;
		case "radio":
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
				flag = LeftClick._click(locator);
				if(flag)
					RetnstrValue=strValue;
			}
			else if(strValue.equalsIgnoreCase("No") || strValue.equalsIgnoreCase("False")){
				flag = LeftClick._click(locator);
				if(flag)
					RetnstrValue=strValue;
			}
			else{
				RetnstrValue=RadioSelect(locator,strValue);
				//Log._logInfo("Already selected the radio button "+Label);
			}
			break;
		case "button":
			flag = LeftClick._click(locator);
			break;
		case "link":
			flag = LeftClick._click(locator);
			break;
		case "label":
			String FieldTxt=WebDriverMain._getTextFromElement(locator);
			if(FieldTxt!=null) {
				if(strValue.equalsIgnoreCase("@getlabeltext"))
					RetnstrValue=FieldTxt;
				else {
				if(FieldTxt.toLowerCase().contains(strValue.toLowerCase()))
					RetnstrValue=strValue;
				}
				
			}
			
			break;
		case "checkbox":
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")) {
					flag = CheckBox._check(locator, strValue);
			}
			else if(strValue.equalsIgnoreCase("No") || strValue.equalsIgnoreCase("False")) {
					//flag = CheckBox._check(locator, strValue);
			}
			RetnstrValue=strValue;
			break;
		case "dropdownlist":
	
			By objPopupListlocator=CommonUtility._getByLocator(Constants.popupdropdownlist);
			String strArrObjLocs[] = CommonUtility._split(strValue,";");
			if(strArrObjLocs.length>1){
				// List<String> retlist= new ArrayList<>();
				 for (int i = 0; i < strArrObjLocs.length; i++) {
					 if (strArrObjLocs[i].indexOf("@random")>=0)
							flag =KendoDropdown._selectByIndex(locator, objPopupListlocator, 1);
						else {
							if(subLocator!=null)
								flag = KendoDropdown._selectByValue(locator, objPopupListlocator,subLocator, strArrObjLocs[i]);
							else
								flag = KendoDropdown._selectByValue(locator, objPopupListlocator, strArrObjLocs[i]);
						}
					 if(flag)
						 RetnstrValue=strArrObjLocs[i]+";"+RetnstrValue;
					 
				
				 }
				//retlist=KendoDropdown._getMultipleSelectedVisibleText(subLocator);
			}
			else {
				if (strValue.indexOf("@random")>=0)
					flag =KendoDropdown._selectByIndex(locator, objPopupListlocator, 1);
				else {
					if(subLocator!=null)
						flag = KendoDropdown._selectByValue(locator, objPopupListlocator,subLocator, strValue);
					else
						flag = KendoDropdown._selectByValue(locator, objPopupListlocator, strValue);
				}
				if(flag)
					RetnstrValue=strValue;
			}
			
			
			
		}
		return RetnstrValue;
	}


	

	/**Function Name :- FieldValidationswitchCase<br/>
	 * Description   :- Provides the operation depending on fieldtype 
	 * @param arg
	 * @param locator
	 * @param fieldType
	 * @param strValue
	 * @param Label
	 * @param MinLength
	 * @param MaxLength
	 * @param Regex
	 * @param WebDriverMain._getDriver()
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean FieldValidationswitchCase(String fieldType,By locator,By subLocator, String strValue,String Label,String MinLength, String MaxLength, String RegEX) throws IOException{
		/*if(fieldType.equalsIgnoreCase("Button") || fieldType.equalsIgnoreCase("linktext") || fieldType.equalsIgnoreCase("CheckBox")){*/
		//PleaseWaitAndLoadingMessage();
		boolean flag =true;
		try{
			if(strValue.equalsIgnoreCase(null)){

				strValue = "";
			}
			
		}catch(NullPointerException nullE){
			strValue = "";
		}
		fieldType = fieldType.toLowerCase().trim();
		switch(fieldType){
		case "textbox":
			
			if (strValue.indexOf("@random")>=0)
				strValue=generateRandomString(strValue);
			System.out.println("strValue --> " + strValue);
			if (StringUtils.isNumeric(MaxLength)) {
				int iMaxLength=Integer.parseInt(MaxLength);
				strValue=generateRandomString(iMaxLength+2);
				flag = TextBox._setTextBox(locator, strValue.trim());
				String strValue2=TextBox._GetTextBoxValue(locator);
				if(strValue2.length()!=iMaxLength)
					UMReporter.log(Status.FAIL, "The Field " +Label+ " is allowed beyond the maximum length : " +iMaxLength);		
			}
			
			if (StringUtils.isNumeric(MinLength)) {
				int iMinLength=Integer.parseInt(MinLength);
				if (iMinLength>2) {
					strValue=generateRandomString(iMinLength-1);
					flag = TextBox._setTextBox(locator, strValue.trim());
					return flag;
				}
			}
			if ((RegEX.length()>2)&&(!RegEX.equalsIgnoreCase("null"))){
				strValue=GetInValidData(RegEX);
				flag = TextBox._setTextBox(locator, strValue.trim());
				return flag;	
			}
			flag = TextBox._setTextBox(locator," ");
			break;
		case "dropdown":
			flag = SelectDropdown._selectByVisibleText(locator, strValue);
			break;
		case "datepicker":
			flag = SetDateInput(locator,Label, strValue);
			break;
		case "radio":
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
				flag = LeftClick._click(locator);
			}
			else{
				//Log._logInfo("Already selected the radio button "+Label);
			}
			break;
		case "button":
			flag = LeftClick._click(locator);
			break;
		case "link":
			flag = LeftClick._click(locator);
			break;
		case "checkbox":
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")) {
				if (!ispalibCheckSelected(subLocator))
					flag = CheckBox._check(locator, strValue);
			}
			else if(strValue.equalsIgnoreCase("No") || strValue.equalsIgnoreCase("False")) {
				if (ispalibCheckSelected(subLocator))
					flag = CheckBox._check(locator, strValue);
			}
			break;
		case "dropdownlist":
			flag =KendoDropdown._removeMultiSelected(locator);
			//retlist=KendoDropdown._getMultipleSelectedVisibleText(subLocator);
		}
		return flag;
	}

	
	


	/**Function Name :- FieldDataValidationswitchCase<br/>
	 * Description   :- Provides the operation depending on fieldtype 
	 * @param arg
	 * @param locator
	 * @param fieldType
	 * @param strValue
	 * @param Label
	 * @param MinLength
	 * @param MaxLength
	 * @param Regex
	 * @param WebDriverMain._getDriver()
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean FieldDataValidationswitchCase(String fieldType,By locator,By subLocator, String strValue,String Label) throws IOException{
		/*if(fieldType.equalsIgnoreCase("Button") || fieldType.equalsIgnoreCase("linktext") || fieldType.equalsIgnoreCase("CheckBox")){*/
		//PleaseWaitAndLoadingMessage();
		boolean flag =true;
		try{
			if(strValue.equalsIgnoreCase(null)){

				strValue = "";
			}
			
		}catch(NullPointerException nullE){
			strValue = "";
		}
		fieldType = fieldType.toLowerCase().trim();
		switch(fieldType){
		case "textbox":
			flag=TextBox._compareTextBox(locator, strValue);	
			break;
		case "dropdown":
			flag = SelectDropdown._selectByVisibleText(locator, strValue);
			break;
		case "datepicker":
			//flag = SetDateInput(locator,Label, strValue);
			flag=TextBox._compareTextBox(locator, strValue);	
			break;
		case "radio":
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
				flag = LeftClick._click(locator);
			}
			else{
				//Log._logInfo("Already selected the radio button "+Label);
			}
			break;
		case "button":
			flag = LeftClick._click(locator);
			break;
		case "link":
			flag = LeftClick._click(locator);
			break;
		case "checkbox":
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")) {
				if (!ispalibCheckSelected(subLocator))
					flag = CheckBox._check(locator, strValue);
			}
			else if(strValue.equalsIgnoreCase("No") || strValue.equalsIgnoreCase("False")) {
				if (ispalibCheckSelected(subLocator))
					flag = CheckBox._check(locator, strValue);
			}
			break;
		case "dropdownlist":
			List<String> ListSelectedText =KendoDropdown._getMultipleSelectedVisibleText(locator);
			for (String SelectedText: ListSelectedText){
				if (SelectedText.contains(strValue)) {
					UMReporter.log(Status.PASS, "The text " +strValue+ "is selected in the field" +Label);
					return flag;
				}
			}
			
			//retlist=KendoDropdown._getMultipleSelectedVisibleText(subLocator);
		}
		return flag;
	}
	
	
	
	/**Function Name :- FieldEditDataswitchCase<br/>
	 * Description   :- Provides the operation depending on fieldtype 
	 * @param arg
	 * @param locator
	 * @param fieldType
	 * @param strValue
	 * @param Label
	 * @param MinLength
	 * @param MaxLength
	 * @param Regex
	 * @param WebDriverMain._getDriver()
	 * @return boolean
	 * @throws IOException 
	 */
	public static String FieldEditDataswitchCase(String fieldType,By locator,By subLocator, String strValue,String Label) throws IOException{
		/*if(fieldType.equalsIgnoreCase("Button") || fieldType.equalsIgnoreCase("linktext") || fieldType.equalsIgnoreCase("CheckBox")){*/
		//PleaseWaitAndLoadingMessage();
		boolean flag =false;
		String RetnstrValue=null;
		try{
			if(strValue.equalsIgnoreCase(null)){

				strValue = "";
			}
			
		}catch(NullPointerException nullE){
			strValue = "";
		}
		fieldType = fieldType.toLowerCase().trim();
		switch(fieldType){
		case "textbox":
			if (strValue.indexOf("@random")>=0)
				strValue=generateRandomString(strValue);
			
			flag=TextBox._compareAndSetTextBox(locator, strValue);
			if(flag)
				RetnstrValue=strValue;
			break;
		case "dropdown":
			flag = SelectDropdown._selectByVisibleText(locator, strValue);
			break;
		case "datepicker":
			flag=TextBox._compareTextBox(locator, strValue);
			if (!flag) {
				flag = SetDateInput(locator,Label, strValue);
				if(flag)
					RetnstrValue=TextBox._GetTextBoxValue(locator);
			}
			break;
		case "radio":
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
				flag = LeftClick._click(locator);
			}
			else{
				//Log._logInfo("Already selected the radio button "+Label);
			}
			break;
		case "checkbox":
			
				if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")) {
					if (!ispalibCheckSelected(subLocator))
						flag = CheckBox._check(locator, strValue);
				}
				else if(strValue.equalsIgnoreCase("No") || strValue.equalsIgnoreCase("False")) {
					if (ispalibCheckSelected(subLocator))
						flag = CheckBox._check(locator, strValue);
				}
					
						
			
			break;
		case "dropdownlist":
			By objPopupListlocator=CommonUtility._getByLocator(Constants.popupdropdownlist);
			List<String> ListSelectedText =KendoDropdown._getMultipleSelectedVisibleText(subLocator);
			String strArrObjLocs[] = CommonUtility._split(strValue,";");
			if(strArrObjLocs.length>1){
				 List<String> retlist= new ArrayList<>();
				 for (int i = 0; i < strArrObjLocs.length; i++) {
					if (!ListSelectedText.contains(strArrObjLocs[i])) {
						 retlist.add(strArrObjLocs[i]);
					}	
				 }
				flag = KendoDropdown._selectByValue(locator, objPopupListlocator, retlist);
				if(flag)
					RetnstrValue=retlist.toString();
			}
			else {
				for (String SelectedText: ListSelectedText){
					if (!SelectedText.contains(strValue)) 
						flag = KendoDropdown._selectByValue(locator, objPopupListlocator, strValue);
				}
				if(flag)
					RetnstrValue=strValue;
			}
		}
		return RetnstrValue;
	}
	
	/**
	 * Function Name :- SetDateInput<br>
	 * Description :- Set date input field.
	 * 
	 * @return boolean
	 */
	public static boolean SetDateInput(By DateLocator,String Label, String setDate) throws IOException{
		boolean flag= false;
		if(setDate==null){
			WebElement ele=WebDriverMain._getDriver().findElement(DateLocator);
				ele.sendKeys(Keys.BACK_SPACE);
				ele.sendKeys(Keys.BACK_SPACE);
				ele.sendKeys(Keys.BACK_SPACE);
				flag=true;
			}
		
		else{
			
			if (setDate.contains("/")){
		        String temp[]=setDate.split("/");
		        String sDate=temp[0];
		        String sMonth=temp[1];
		        String sYears=temp[2];
		        if (sMonth.length()==1)
		        	sMonth="0"+sMonth;
		        if (sDate.length()==1)
		        	sDate="0"+sDate;
//		        if (sYears.length()==4)
//		        	sYears=sYears;
		        
		        setDate=sMonth+sDate+sYears;
	        }
		WebElement dobele=WebDriverMain._getDriver().findElement(DateLocator);
		  if (dobele != null) {
	        	if(dobele.isEnabled()){	        		
	        		dobele.sendKeys(Keys.BACK_SPACE);
	        		dobele.sendKeys(Keys.BACK_SPACE);
	        		dobele.sendKeys(setDate);
	        		CommonUtility._sleepForGivenTime(500);
	        		//UMReporter.log(Status.PASS, "The value "+setDate+" is selected from " +Label);
	        		flag=true;	
	        	}
	        	else
	        	{
	        		flag=false;
	        		UMReporter.log(Status.FAIL, "The field "+Label+" is disabled  and unable to set value "+setDate);
	        	}
		  }
		}
		return flag;
	}
	
	/**
	 * Function Name :- isChecked<br>
	 * Description :- To check checkbox selected.
	 * 
	 * @return boolean
	 */
	public static boolean ispalibCheckSelected(By CheckLocator) {
		String classValue = "";
		WebElement checkElement=WebDriverMain._getDriver().findElement(CheckLocator);//palib-checkbox
		if(checkElement != null){
			if(checkElement.isEnabled()){
				classValue=checkElement.getAttribute("class");
				if (classValue.startsWith("ng-valid"))
					return true;
				else if(classValue.startsWith("ng-untouched"))
					return false;
			}
		}
		return false;
	}
	

	/**
	 * Function Name :- genString<br>
	 * Description :- Generate random letters.
	 * 
	 * @return boolean
	 */
	public static String generateRandomString(char first, int len) {
		String s = "";
		for (int i = 1 ; i < len ; i++)
			s += (char)(Math.random() * ('Z' - 'A' + 1) + 'A');
		return first + s;
	}

	/**
	 * Function Name :- genString<br>
	 * Description :- Generate random letters.
	 * 
	 * @return boolean
	 */
	public static String generateRandomString( int len) {
		String s = "";
		for (int i = 1 ; i <= len ; i++)
			s += (char)(Math.random() * ('Z' - 'A' + 1) + 'A');
		return  s;
	}

	/**
	 * Function Name :- genString<br>
	 * Description :- Generate random letters.
	 * 
	 * @return boolean
	 */
	public static String generateRandomString(String InputValue) {
		String RetnString="";
        	String RecSplit[]=InputValue.split("@");
            for (String cnt : RecSplit){
            	String ConcatString=cnt;
              if (ConcatString.indexOf("random")>=0){
            	  String NumSplit[]=ConcatString.split("_");
            	  if (NumSplit.length>1)
            	  {
            		  String ranNum=NumSplit[1];
            		  if (ranNum.contains("#"))
                	  {
            			  String NumericSplit[]=ranNum.split("#");
            			  ranNum=NumericSplit[0];
            			  if (isNumeric(ranNum))
                			  ConcatString=generateRandomNumber(Integer.parseInt(ranNum));
            			  else
            				  ConcatString=generateRandomNumber(4);
            				  
                	  }
            		  else {
            			  if (isNumeric(ranNum))
            				  ConcatString=generateRandomString(Integer.parseInt(ranNum));
            			  else
            				  ConcatString=generateRandomString(4);
            		  }
            	  }
            	  else
            	  {
            		  ConcatString=generateRandomString(4);
            	  }
              }
              RetnString=RetnString+ConcatString;
            }
            //System.out.println("Randon RetnString: "+RetnString);
            return RetnString;
       
	}
	
	 public static String generateRandomNumber(int len)
	 {
		 String RetnResult;
		 SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMddHHmmss");
		 Date now = new Date();
		 String strDate = sdfDate.format(now);
		 RetnResult=StringUtils.right(strDate, len);
		 //System.out.println("Randam Numeric Value : "+strDate+"Requested value "+RetnResult);//20160627172129
		 return RetnResult;
	 }
	 
	 /**
		 * Function Name :- generateRandomDate<br>
		 * Description :- Generate random Date.
		 * 
		 * @return boolean
		 */
		public static String generateRandomDate(String InputValue) {
			String RetnString="";
	        	String RecSplit[]=InputValue.split("@");
	            for (String cnt : RecSplit){
	            	String ConcatString=cnt;
	              if (ConcatString.indexOf("random")>=0){
	            	  String NumSplit[]=ConcatString.split("_");
	            	  if (NumSplit.length>1)
	            	  {
	            		  String ranNum=NumSplit[1];          		  
	            		  String NumericSplit[]=ranNum.split("#");
	            		  if (NumericSplit.length>=1)
	                	  {
	            			  ranNum=NumericSplit[0];
	            			  if (isNumeric(ranNum))
	                			  ConcatString=generateRandomDate(Integer.parseInt(ranNum));
	            			  else
	            				  ConcatString=generateRandomDate(0);
	                	  }
	            		  else {
	            			  if (isNumeric(ranNum))
	            				  ConcatString=generateRandomDate(Integer.parseInt(ranNum));
	            			  else
	            				  ConcatString=generateRandomDate(0);
	            		  }
	            	  }
	            	  else
	            	  {
	            		  ConcatString=generateRandomDate(0);
	            	  }
	              }
	              RetnString=ConcatString;
	            }
	            //System.out.println("Random RetnDate: "+RetnString);
	            return RetnString;
	       
		}
	 
	 public static String generateRandomDate(int dayadd)
	 {
		 String RetnResult=null;
		 SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		 Calendar c = Calendar.getInstance();
		 Date now = new Date();
		 c.setTime(now); // Now use today date.
		 c.add(Calendar.DATE, dayadd); // Adding 5 days
		 RetnResult = sdf.format(c.getTime());
		 System.out.println("Randam Numeric Value : "+RetnResult+" add days: "+dayadd);//20160627172129
		 return RetnResult;
			
	 }

	/**
	 * Function Name :- isNumeric<br>
	 * Description :- Provided string is numeric.
	 * 
	 * @return boolean
	 */
	public static boolean isNumeric(String strNum) {
	    try {
	      Double.parseDouble(strNum);
	    } catch (NumberFormatException | NullPointerException nfe) {
	        return false;
	    }
	    return true;
	}
	
	 public static boolean isValidDate(String inDate) {
	        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	        dateFormat.setLenient(false);
	        try {
	            dateFormat.parse(inDate.trim());
	        } catch (ParseException pe) {
	            return false;
	        }
	        return true;
	    }
	 
	 
	 public static boolean isDateBefore(String inDate,int days) throws ParseException {
		 boolean flag=false;
		 try {
		      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
		      LocalDateTime CreatedDate = LocalDateTime.parse(inDate, formatter);
		      LocalDateTime today = LocalDateTime.now();
		      LocalDateTime Checkdata = today.minus(Period.ofDays(days));
		      if (CreatedDate.isBefore(Checkdata))
		    	  flag=true;
		 }
		 catch(Exception e) {
			 return false;
		 }
		return flag;
	 }
	
	/**
	 * Function Name :- GetInValidData<br>
	 * Description :- Get invalid string.
	 * 
	 * @return String
	 */
	public static String GetInValidData(String strRegEx) {
		 String strValue=null;
	    try {
	        strValue = Constants.INVALID_DATA;
	    } catch (NumberFormatException | NullPointerException nfe) {
	        return "inValid";
	    }
	    return strValue;
	}
	
	
	/**
	 * Function Name :- RadioSelect<br>
	 * Description :- To select Radio Options.
	 *
	 */
	public static String RadioSelect(By radioLocator,String optionname) throws IOException {
		CommonUtility._sleepForGivenTime(1000);
		String sAtrRadioValue =null;
		String sRetnValue =null;
		List<WebElement> lstRadioOptions = WebDriverMain._getElementsWithWait(radioLocator);
		for (WebElement radioOpt : lstRadioOptions) {
			sAtrRadioValue = radioOpt.getAttribute("for");
			if (sAtrRadioValue.toLowerCase().contains(optionname.toLowerCase())) {
				//radioOpt.click();
				LeftClick.clickByWebElementJS(radioOpt);
				CommonFunctions.PleaseWaitAndLoadingMessage();
				sRetnValue=sAtrRadioValue;
				return sRetnValue;
			}
		}
		return sRetnValue;
	}
	
	
	/**
	 * Function Name :- VerifyDialogTitle<br>
	 * Description :- Verify Popup string.
	 * 
	 * @return boolean
	 */
	public static boolean VerifyDialogTitle(String ModalTitleTxt) throws IOException {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog/div[contains(@class,'k-dialog')]");
		By ModalHeaderlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog-titlebar/div[contains(@class,'k-dialog-title')]");
		WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
		if (targetElement != null) {
			try{
				if(targetElement.isDisplayed()){
					//Verify Modal Title
					WebElement ModalTitleElement =targetElement.findElement(ModalHeaderlocator);
					if (ModalTitleElement != null) {
						String ModalTitile=ModalTitleElement.getText();
							if (ModalTitile.toUpperCase().trim().contains(ModalTitleTxt.toUpperCase().trim())) 
								flag=true;
								//UMReporter.log(Status.Pass, "The Confirm popup title is matched with expected value "+ModalTitleTxt);
							else 
								UMReporter.log(Status.FAIL, "The Dialog window title is mismatched with expected value "+ModalTitleTxt);
					}
				}
			}
			catch(Exception e){
				return false;
			}
		}
		return flag;
		
	}
	
	/**
	 * Function Name :- VerifyConfirmPopupContent<br>
	 * Description :- Verify Popup string.
	 * 
	 * @return boolean
	 */
	public static boolean VerifyConfirmPopupContent(String ModalTitleTxt,String ModalBodyTxt) throws IOException {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog/div[contains(@class,'k-dialog')]");
		By ModalHeaderlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog-titlebar/div[contains(@class,'k-dialog-title')]");
		By Modalbodylocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'k-dialog-content')]/p");
		WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
		if (targetElement != null) {
			try{
				if(targetElement.isDisplayed()){
					//Verify Modal Title
					WebElement ModalTitleElement =targetElement.findElement(ModalHeaderlocator);
					if (ModalTitleElement != null) {
						String ModalTitile=ModalTitleElement.getText();
							if (ModalTitile.toUpperCase().trim().contains(ModalTitleTxt.toUpperCase().trim())) 
								flag=true;
								//UMReporter.log(Status.Pass, "The Confirm popup title is matched with expected value "+ModalTitleTxt);
							else 
								UMReporter.log(Status.FAIL, "The Confirm popup title is mismatched with expected value "+ModalTitleTxt);
					}
					
					//Verify Modal Body
					WebElement ModalBodyEle =targetElement.findElement(Modalbodylocator);
					if (ModalBodyEle != null) {
						String ModalBody=ModalBodyEle.getText();
						String RecSplit[]=ModalBodyTxt.split("\\(X\\)");
			            for (String ModalBodycnt : RecSplit){	
			            	if (ModalBody.toUpperCase().trim().contains(ModalBodycnt.toUpperCase().trim())) 
			            		flag=true;
			            		//	UMReporter.log(Status.Pass, "The Confirm popup title is matched with expected value "+ModalTitleTxt);
			            	else 
			            		UMReporter.log(Status.FAIL, "The Confirm popup message is mismatched with expected value "+ModalBodyTxt);
			            }
					}
					
				}
			}
			catch(Exception e){
				return false;
			}
		}
		return flag;
		
	}
	
	/**
	 * Function Name :- ConfirmPopupActionBtn<br>
	 * Description :- To Confirm Popup string.
	 * 
	 * @return boolean
	 */
	public static boolean ConfirmPopupActionBtn(String ModalActionButton) throws IOException {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog/div[contains(@class,'k-dialog')]");
		By ModalActnBtnlocator = CommonUtility._getObjectLocator("xpath=//button[contains(text(),'"+ModalActionButton+"')]");
		WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
		if (targetElement != null) {
			try{
				if(targetElement.isDisplayed()){
					
					//Verify Modal Action
					if (ModalActionButton.length()>1) {
						WebElement ModalBtnEle =targetElement.findElement(ModalActnBtnlocator);
						if (ModalBtnEle != null) {
							if (LeftClick._click(ModalBtnEle)) 
								flag=true;
								//UMReporter.log(Status.Pass, "The Confirm popup action button "+ModalBtnEle);
							 else 
								UMReporter.log(Status.FAIL, "The Confirm popup action button is not exist "+ModalActionButton);
						}
					}
					
				}
			}
			catch(Exception e){
				return false;
			}
		}
		return flag;
		
	}
	
	/**
	 * Function Name :- VerifyConfirmPopupDisplayed<br>
	 * Description :- To Verify Popup displayed.
	 * 
	 */
	public static boolean VerifyConfirmPopupDisplayed() throws IOException {
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog/div[contains(@class,'k-dialog')]");
		if (WebDriverMain._isElementPresent(objlocator)) {
			WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
			if (targetElement != null) {
				try{
					if(targetElement.isDisplayed())
						return true;
					}
				catch(Exception e) {
					return false;
				}
			}
		}
		return false;
	}
	
	
	/**
	 * Function Name :- CloseDialog<br>
	 * Description :- To Close Dialog string.
	 * 
	 * @return boolean
	 */
	public static boolean CloseDialog() throws IOException {
		boolean flag=false;
		if (VerifyConfirmPopupDisplayed()) {
			try{
				By ModalActnBtnlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog-titlebar//div[contains(@class,'k-dialog-actions')]/a[contains(@class,'k-dialog-close')]");
				if (WebDriverMain._isElementPresent(ModalActnBtnlocator)) {
					flag=LeftClick._click(ModalActnBtnlocator);
				}
			}
			catch(Exception e){
				return false;
			}
		}
		return flag;
	}
	
	/**
	 * Function Name :- GetDailogTitle<br>
	 * Description :- To Get Dialog Popup string.
	 * 
	 * @return String
	 */
	public static String GetDailogTitle() throws IOException {
		String RetnValue=null;
		if (VerifyConfirmPopupDisplayed()) {
			try{
				By ModalActnBtnlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog-titlebar/div[contains(@class,'k-dialog-title')]");
				if (WebDriverMain._isElementPresent(ModalActnBtnlocator)) {
					RetnValue=WebDriverMain._getTextFromElement(ModalActnBtnlocator);
				}
			}
			catch(Exception e){
				return RetnValue;
			}
		}
		return RetnValue;
	}
	
	/**
	 * Function Name :- GetDailogContent<br>
	 * Description :- To Get Popup Dialog string.
	 * 
	 * @return List<String>
	 */
	public static List<String> GetDailogContent() throws IOException {
		 List<String> retlist= null;
		if (VerifyConfirmPopupDisplayed()) {
			try{
				By ModalActnBtnlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog//div[contains(@class,'k-dialog-content')]//div[contains(@class,'col')]");
				if (WebDriverMain._isElementPresent(ModalActnBtnlocator)) {
					retlist= new ArrayList<>();
					List<WebElement> lstDialogOptions = WebDriverMain._getElementsWithWait(ModalActnBtnlocator);
					for (WebElement dialogOpt : lstDialogOptions) {
						String Content=dialogOpt.getText();
						retlist.add(Content);
					}
				}
			}
			catch(Exception e){
				return retlist;
			}
		}
		return retlist;
	}
	
	
	/**
	 * Function Name :- SelectDailogContent<br>
	 * Description :- To Select Popup Dialog string.
	 * 
	 * @return List<String>
	 */
	public static boolean SelectDailogContent(String SearchText) throws IOException {
		boolean flag= false;
		if (VerifyConfirmPopupDisplayed()) {
			try{
				By ModalActnBtnlocator = CommonUtility._getObjectLocator("xpath=//kendo-dialog//div[contains(@class,'k-dialog-content')]//div[contains(@class,'col')]/a[contains(text(),'"+SearchText+"')]");
				if (WebDriverMain._isElementPresent(ModalActnBtnlocator)) {
					if (LeftClick._click(ModalActnBtnlocator)) 
						flag=true;
				}
			}
			catch(Exception e){
				return flag;
			}
		}
		return flag;
	}

	/**
	 * Function Name :- VerifySuccessPopupDisplayed<br>
	 * Description :- To Verify Popup displayed.
	 * 
	 * @return boolean
	 */
	public static boolean VerifySuccessPopupDisplayed() throws IOException {
		By objlocator = CommonUtility._getObjectLocator("xpath=//palib-custom-modal//div[@class='modal-dialog']/div[@class='modal-content']");
		WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
		if (targetElement != null) {
			try{
				if(targetElement.isDisplayed())
					return true;
				}
			catch(Exception e) {
				return false;
			}
		}
		return false;
	}
	
	/**
	 * Function Name :- CancelSuccesspopup<br>
	 * Description :- To Cancel Popup displayed.
	 * 
	 * @return boolean
	 */
	public static boolean CancelSuccesspopup() throws IOException {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//palib-custom-modal//div[@class='modal-dialog']/div[@class='modal-content']");
		By ModalActnBtnlocator = CommonUtility._getObjectLocator("xpath=//a[@id='cancelBtn']");
		WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
		if (targetElement != null) {
			try{
				if(targetElement.isDisplayed()){
					//Verify Modal Cancel
						WebElement ModalBtnEle =targetElement.findElement(ModalActnBtnlocator);
						if (ModalBtnEle != null) {
							if (LeftClick._click(ModalBtnEle)) 
								flag=true;
								//UMReporter.log(Status.Pass, "The Confirm popup action button "+ModalBtnEle);
							 else 
								UMReporter.log(Status.FAIL, "The Success popup cancel option is not exist ");
						}
					
					
				}
			}
			catch(Exception e){
				return false;
			}
		}
		return flag;
		
	}
	
	/**
	 * Function Name :- VerifySuccessPopupContent<br>
	 * Description :- To Verify Popup Content.
	 * 
	 * @return boolean
	 */
	public static boolean VerifySuccessPopupContent(String ModalTitleTxt,String ModalBodyTxt) throws IOException {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//palib-custom-modal//div[@class='modal-dialog']/div[@class='modal-content']");
		By ModalHeaderlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'modal-header')]/h5[@class='modal-title']");
		By Modalbodylocator = CommonUtility._getObjectLocator("xpath=//div[@class='modal-body']");
		WebElement targetElement = WebDriverMain._getElementWithWait(objlocator);
		if (targetElement != null) {
			try{
				if(targetElement.isDisplayed()){
					//Verify Modal Title
					WebElement ModalTitleElement =targetElement.findElement(ModalHeaderlocator);
					if (ModalTitleElement != null) {
						String ModalTitile=ModalTitleElement.getText();
						if (ModalTitile.toUpperCase().trim().contains(ModalTitleTxt.toUpperCase().trim())) 
							flag=true;
							//UMReporter.log(Status.Pass, "The Confirm popup title is matched with expected value "+ModalTitleTxt);
						 else 
							UMReporter.log(Status.FAIL, "The Success popup title is mismatched with expected value "+ModalTitleTxt);
					}
					
					//Verify Modal Body
					WebElement ModalBodyEle =targetElement.findElement(Modalbodylocator);
					if (ModalBodyEle != null) {
						String ModalBody=ModalBodyEle.getText();
						String RecSplit[]=ModalBodyTxt.split("\\(X\\)");
			            for (String ModalBodycnt : RecSplit){	
			            	if (ModalBody.toUpperCase().trim().contains(ModalBodycnt.toUpperCase().trim())) 
			            		flag=true;
			            		//UMReporter.log(Status.Pass, "The Confirm popup title is matched with expected value "+ModalTitleTxt);
			            	else 
			            		UMReporter.log(Status.FAIL, "The Success popup message is mismatched with expected value "+ModalBodyTxt);
			            }
					}
				}
			}
			catch(Exception e){
				return false;
			}
		}
		return flag;
		
	}
	
	/**
	 * Function Name :- VerifySuccessPopupContent<br>
	 * Description :- To Verify Popup Content.
	 * 
	 * @return boolean
	 */
	public static String GetCurrentWindowHandle(){
		String originalHandle = WebDriverMain._getDriver().getWindowHandle();
		System.out.println("CurrentBrowserHandle:"+originalHandle);
	    return originalHandle;
		
	}
	
	/**
	 * Function Name :- removeZeroPadding<br>
	 * Description :- To remove zero padding  in date string.
	 * 
	 * @return boolean
	 */
	public static String removeZeroPadding(String setDate){
		String retnDate=null;
		if (setDate.contains("/")){
	        String temp[]=setDate.split("/");
	        String sMonth=temp[0];
	        String sDate=temp[1];
	        String sYears=temp[2];
	        if (sMonth.length()==2) {
	        	if (sMonth.substring(0, 1).equalsIgnoreCase("0"))
	        		sMonth=sMonth.substring(1, 2);
	        }
	        if (sDate.length()==2) {
	        	if (sDate.substring(0, 1).equalsIgnoreCase("0"))
	        		sDate=sDate.substring(1, 2);
	        }
	        retnDate=sMonth+"/"+sDate+"/"+sYears;
	    }
		else
			retnDate=setDate;
			
		return retnDate;
	}
	
	/**
	 * Function Name :- CloseAllWindowExceptCurrent<br>
	 * Description :- To Close All Popup Content.
	 * 
	 * @return boolean
	 */
	public static boolean CloseAllWindowExceptCurrent(String originalHandle){
		
		try{
			if (originalHandle == null) 
				return false;
		    for(String handle : WebDriverMain._getDriver().getWindowHandles()) {
		    	System.out.println("BrowserWin:"+handle);
		        if (!handle.equals(originalHandle)) {
		        	WebDriverMain._getDriver().switchTo().window(handle);
		        	PleaseWaitAndLoadingMessage();
		        	WebDriverMain._getDriver().close();
		        	CommonUtility._sleepForGivenTime(1000);
		        }
		    }
		    WebDriverMain._getDriver().switchTo().window(originalHandle);
		}catch(Exception e){
			return false;
		}
	    return true;
	}
	
	/**
	 * Function Name :- getAllWindowExceptCurrent<br>
	 * Description :- To get All Window size.
	 * 
	 * @return boolean
	 */
	public static int getAllWindowExceptCurrent(){
		int wincount=0;
		try{
			Set<String> winHand= WebDriverMain._getDriver().getWindowHandles();
			wincount=winHand.size();
			return wincount;
		}catch(Exception e){
			return wincount;
		}
	}
	/**
	 * Function Name :- SwitchtoNewWindow<br>
	 * Description :- To switch to New Window.
	 * 
	 * @return boolean
	 */
	public static boolean SwitchtoNewWindow(String originalHandle){
		try{
			if (originalHandle == null) 
				return false;
		    for(String handle : WebDriverMain._getDriver().getWindowHandles()) {
		    	System.out.println("BrowserWin:"+handle);
		        if (!handle.equals(originalHandle)) {
		        	WebDriverMain._getDriver().switchTo().window(handle);
		        	PleaseWaitAndLoadingMessage();
		        	CommonUtility._sleepForGivenTime(1000);
		        	return true;
		        }
		    }
		}catch(Exception e){
			return false;
		}
	    return true;
	}
	
	/**
	 * Function Name :- SwitchtoCurrentWindow<br>
	 * Description :- To switch to Current Window.
	 * 
	 * @return boolean
	 */
	public static boolean SwitchtoCurrentWindow(String originalHandle){
		try{
			if (originalHandle == null) 
				return false;
		    for(String handle : WebDriverMain._getDriver().getWindowHandles()) {
		    	System.out.println("BrowserWin:"+handle);
		        if (handle.equals(originalHandle)) {
		        	WebDriverMain._getDriver().switchTo().window(handle);
		        	PleaseWaitAndLoadingMessage();
		        	CommonUtility._sleepForGivenTime(1000);
		        	return true;
		        }
		    }
		}catch(Exception e){
			return false;
		}
	    return true;
	}
	
	
	/**Function Name :- getTestData<br/>
	 * Description   :- To get test data from json file 
	 * @param fieldType
	 */
	public static String getTestData(String fieldType) {
		Log._logInfo("Get Environment field  "+fieldType);
		String RetnstrValue=null;
		switch(fieldType){
		case "$pin_state":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getPinState();
			break;
		case "$pin_lea":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getPinLea();
			break;
		case "$pin_district":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getPinDst();
			break;
		case "$pin_school":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getPinSch();
			break;
		case "$state":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getState(true);
			break;
		case "$lea":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getLea(true);
			break;
		case "$district":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getDst(true);
			break;
		case "$school":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getSch(true);
			break;
		case "$admin":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getAdminName(true);
			break;
		case "$test":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getTestName(true);
			break;
		case "$grade":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getGradeName(true);
			break;
		case "$student":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getstudentName(true);
			break;
		case "$class":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getclassName(true);
			break;
		case "$session":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getsessionName(true);
			break;
		case "$papersession":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getPapersessionName(true);
			break;
		case "$user":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getuserName(true);
			break;
			//Seconday Values
		case "$statesearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getState(false);
			break;
		case "$leasearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getLea(false);
			break;
		case "$districtsearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getDst(false);
			break;
		case "$schoolsearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getSch(false);
			break;
		case "$paperadmin":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getPaperAdminName();
			break;
		case "$papertest":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getPaperTestName();
			break;
		case "$studentsearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getstudentName(false);
			break;
		case "$classsearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getclassName(false);
			break;
		case "$sessionsearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getsessionName(false);
			break;
		case "$papersessionsearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getPapersessionName(false);
			break;
		case "$usersearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getuserName(false);
			break;
		case "$dataimportsearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getDataImports(false);
			break;
			//Teacher role related values
		case "$teachername":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getNamebyRole("Teacher");
			 String temp[]=RetnstrValue.split(" ");
			 RetnstrValue=temp[0];
			break;
		case "$teacherstudent":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getteacherstudentName();
			break;
		case "$teacherclass":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getteacherclassName();
			break;
		case "$teachersession":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getTeachersessionName();
			break;
		case "$teacheruser":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getteacheruserName();
			break;
		case "$producttype":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getproductType(true);
			break;
		case "$course":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getCourse(true);
			break;
		case "$producttypesearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getproductType(false);
			break;
		case "$coursesearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getCourse(false);
			break;
		case "$adminsearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getAdminName(false);
			break;
		case "$testsearchtext":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getTestName(false);
			break;
		case "customerrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getCustomerrefID();
			break;
		case "staterefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getStateRefID();
			break;
		case "learefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getLeaRefID();
			break;
		case "districtrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getDstRefID();
			break;
		case "schoolrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getSchRefID();
			break;
		case "adminrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getAdminRefID();
			break;
		case "testrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getTestRefID();
			break;
		case "studentrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getstudentRefid();
			break;
		case "classrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getclassRefID();
			break;
		case "sessionrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getsessionRefID();
			break;
		case "userrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getuserRefid();
			break;
		case "dataimportsrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getDataImportsRefID();
			break;
		case "producttyperefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getProductTypeRefID();
			break;
		case "teacherstudentrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getteacherstudentrefid();
			break;
		case "teacherclassrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getteacherclassrefid();
			break;
		case "teachersessionrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getteachersessionrefid();
			break;
		case "teacheruserrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getteacheruserrefid();
			break;
		case "lowstakesadminrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getlowstakesadminrefid();
			break;
		case "lowstakessessionrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getlowstakessessionrefid();
			break;
		case "highstakesadminrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().gethighstakesadminrefid();
			break;
		case "highstakessessionrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().gethighstakessessionrefid();
			break;
		case "masteradminrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getmasteradminrefid();
			break;
		case "lowstakesproducttyperefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getlowstakesproducttyperefid();
			break;		
		case "highstakesproducttyperefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().gethighstakesproducttyperefid();
			break;
		
		case "providerconfigrefid":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getproviderconfigrefid();
			break;
		case "gradeReferenceId":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getgradeReferenceId();
			break;
		case "subjectReferenceId":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getsubjectReferenceId();
			break;
		case "productTypeProviderReferenceId":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getproductTypeProviderReferenceId();
			break;
			
		case "courseReferenceId":
			RetnstrValue=FileReaderManager.getInstance().getJsonReader().getcourseReferenceId();
			break;
		}
		
		//System.out.println("TestData: "+fieldType+" => "+RetnstrValue);
		Log._logInfo("Get Environment field "+fieldType+" Value  "+RetnstrValue);
		return RetnstrValue;
	}
	
	
	
	  /*************************************************************************************************
			 *  Function name 		: toMap
			 *  Reuse Function 		: 
			 *  Description 		: Convert JSONObject To Map<String, Object>
			/**************************************************************************************************/ 
		  public static Map<String, Object> toMap(JSONObject object) throws JSONException {
	  	    Map<String, Object> map = new HashMap<String, Object>();

	  	    Iterator<String> keysItr = object.keys();
	  	    while(keysItr.hasNext()) {
	  	        String key = keysItr.next();
	  	        Object value = object.get(key);

	  	        if(value instanceof JSONArray) {
	  	            value = toList((JSONArray) value);
	  	        }

	  	        else if(value instanceof JSONObject) {
	  	            value = toMap((JSONObject) value);
	  	        }
	  	        map.put(key, value);
	  	    }
	  	    return map;
	  	}
		  
		   /*************************************************************************************************
			 *  Function name 		: toList
			 *  Reuse Function 		: 
			 *  Description 		: Convert JSONArray To List<Object>
			/**************************************************************************************************/ 
		  public static List<Object> toList(JSONArray array) throws JSONException {
	  	    List<Object> list = new ArrayList<Object>();
	  	    for(int i = 0; i < array.length(); i++) {
	  	        Object value = array.get(i);
	  	        if(value instanceof JSONArray) {
	  	            value = toList((JSONArray) value);
	  	        }

	  	        else if(value instanceof JSONObject) {
	  	            value = toMap((JSONObject) value);
	  	        }
	  	        list.add(value);
	  	    }
	  	    return list;
	  	}
		  
		  
		  /**
			 * Function Name :- waitUntilLoadingSpinner<br>
			 * Description :- To wait Loadingspinner is not visible
			 */
			public static boolean waitUntilLoadingSpinner(int maxtime) throws Exception{
				int timer=0;
				By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//div[@class='k-loading-image']");
				while((WebDriverMain._isElementVisible(objlocator))&&(timer<maxtime))
				{
					CommonUtility._sleepForGivenTime(1000);
					timer=timer+1;
				}
				if (WebDriverMain._isElementVisible(objlocator))
					return false;
				else
					return true;
			}
			
			 /**
			 * Function Name :- waitUntilCreatingLoadingSpinner<br>
			 * Description :- To wait Creatingspinner is not visible
			 */
			public static boolean waitUntilCreatingLoadingSpinner(int maxtime) throws Exception{
				int timer=0;
				By objlocator = CommonUtility._getObjectLocator("xpath=//pa-root/div[contains(@class,'spinner-container') and contains(@class,'d-flex')]");
				while((WebDriverMain._isElementVisible(objlocator))&&(timer<maxtime))
				{
					CommonUtility._sleepForGivenTime(1000);
					timer=timer+1;
				}
				if (WebDriverMain._isElementVisible(objlocator))
					return false;
				else
					return true;
			}

}