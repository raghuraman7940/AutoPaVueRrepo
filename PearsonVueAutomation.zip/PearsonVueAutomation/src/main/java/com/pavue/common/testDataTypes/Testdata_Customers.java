package com.pavue.common.testDataTypes;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Testdata_Customers {

@SerializedName("customer")
@Expose
private String customer;
@SerializedName("testnavurl")
@Expose
private String testnavurl;
@SerializedName("state")
@Expose
private String state;
@SerializedName("lea")
@Expose
private String lea;
@SerializedName("distict")
@Expose
private String distict;
@SerializedName("school")
@Expose
private String school;
@SerializedName("functional")
@Expose
private Testdata_Customers_Functional functional;
@SerializedName("searchtext")
@Expose
private Testdata_Customers_Searchtext searchtext;
@SerializedName("apidata")
@Expose
private Testdata_Customers_APIDATA apidata;
@SerializedName("oauthtoken")
@Expose
private List<Testdata_Customers_Oauthtoken> oauthtoken = null;
@SerializedName("users")
@Expose
private List<Testdata_Customers_Users> users = null;


public String getCustomer() {
return customer;
}

public void setCustomer(String customer) {
this.customer = customer;
}
public String getTestNavUrl() {
return testnavurl;
}

public void setTestNavUrl(String testnavurl) {
this.testnavurl = testnavurl;
}

public String getState() {
return state;
}

public void setState(String state) {
this.state = state;
}

public String getLea() {
return lea;
}

public void setLea(String lea) {
this.lea = lea;
}

public String getDistict() {
return distict;
}

public void setDistict(String distict) {
this.distict = distict;
}

public String getSchool() {
return school;
}

public void setSchool(String school) {
this.school = school;
}

public Testdata_Customers_Functional getFunctional() {
return functional;
}

public void setFunctional(Testdata_Customers_Functional functional) {
this.functional = functional;
}

public Testdata_Customers_Searchtext getsearchtext() {
return searchtext;
}

public void setsearchtext(Testdata_Customers_Searchtext searchtext) {
this.searchtext = searchtext;
}

public Testdata_Customers_APIDATA getAPIDATA() {
return apidata;
}

public void setAPIDATA(Testdata_Customers_APIDATA apidata) {
this.apidata = apidata;
}

public List<Testdata_Customers_Oauthtoken> getoauthtoken() {
return oauthtoken;
}

public void setoauthtoken(List<Testdata_Customers_Oauthtoken> oauthtoken) {
this.oauthtoken = oauthtoken;
}

public List<Testdata_Customers_Users> getUsers() {
return users;
}

public void setUsers(List<Testdata_Customers_Users> users) {
this.users = users;
}

}