package com.pavue.common.dataProviders;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
public class ConfigFileReader {	
	private Properties properties;
	private final String propertyFilePath= "src/main/resources/com/pavue/config/Configuration.properties";

	/**
	 * 
	 * Constructor for configuring the properties.
	 * 
	 */
	public ConfigFileReader(){
		BufferedReader reader = null;
		String PropFile=propertyFilePath;
		try {
			properties = new Properties();
			String sysconfigFile = System.getProperty("config.file");
			//sysconfigFile="confd/templates/Configuration.properties.tmpl";
			if ((sysconfigFile!=null)&&(sysconfigFile.length()>1))
				PropFile = sysconfigFile;
			
			System.out.println("PropFile : "+PropFile);
			reader = new BufferedReader(new FileReader(PropFile));
			properties.load(reader);
		} catch (IOException e) {
			throw new RuntimeException("Properties file not found at path : " + PropFile);
		}finally {
			try { if(reader != null) reader.close(); }
			catch (IOException ignore) {}
		}
	}
	

	/**
	 * Get the Implicit wait.
	 * 
	 * @return timeout
	 */
	public long getImplicitlyWait() {
		String implicitlyWait =GetPropertyValue("implicitlyWait");
		if(implicitlyWait != null) {
			try{
				return Long.parseLong(implicitlyWait);
			}catch(NumberFormatException e) {
				throw new RuntimeException("Not able to parse value : " + implicitlyWait + " in to Long");
			}
		}
		return 30;		
	}
	

	/**
	 * Get the Browser name.
	 * 
	 * @return browserName
	 */
	public String getBrowser() {
		String browserName =GetPropertyValue("browser");
		if(browserName == null || browserName.equalsIgnoreCase("chrome")) return "CHROME";
		else if(browserName.equalsIgnoreCase("firefox")) return "FIREFOX";
		else if(browserName.equalsIgnoreCase("iexplorer")|| browserName.equalsIgnoreCase("INTERNETEXPLORER")) return "INTERNETEXPLORER";
		else if(browserName.equalsIgnoreCase("PHANTOMJS")) return "PHANTOMJS";
		return "CHROME";
		
	}
	
	/**
	 * Get the execution type.
	 * 
	 * @return environmenttype
	 */
	public String getExecutionType() {
			String exetype = GetPropertyValue("executiontype");
			if(exetype == null || exetype.equalsIgnoreCase("remote")) return "REMOTE";
			else return "LOCAL";
	}
	
	/**
	 * Get the Remote host.
	 * 
	 * @return remotehost
	 */
	public String getRemoteHost() {
		String sysexetype=null;
		sysexetype = GetPropertyValue("remotehost");
		return sysexetype;		  
	}
	
	/**
	 * Get the execution environment type.
	 * 
	 * @return environmenttype
	 */
	public String getEnvironment() {
			String environmentName = GetPropertyValue("environment");
			if (environmentName == null || environmentName.equalsIgnoreCase("PADEV")|| environmentName.equalsIgnoreCase("pa-dev-main")) return "PADEV";
//			else if(environmentName.equalsIgnoreCase("PAACP")|| environmentName.equalsIgnoreCase("pa-acp-main")) return "PAACP";
			else if (environmentName.equalsIgnoreCase("PASMK")|| environmentName.equalsIgnoreCase("pa-smk-main")) return "PASMK";
			else if (environmentName.equalsIgnoreCase("PAUAT")|| environmentName.equalsIgnoreCase("pa-uat-main")) return "PAUAT";
			else if (environmentName.equalsIgnoreCase("PAPVT")|| environmentName.equalsIgnoreCase("pa-pv-main")) return "PAPVT";
			else if (environmentName.equalsIgnoreCase("PAPROD")|| environmentName.equalsIgnoreCase("pa-prod-main")) return "PAPROD";
			else if(environmentName.equals("LOCAL")) return "LOCAL";
			else return "PADEV";
	}
	
	/**
	 * Get the execution environment file.
	 * 
	 * @return getEnvironmentFile
	 */
	public String getEnvironmentFile() {
			String sysEnvFile = System.getProperty("envfile");
		 if ((sysEnvFile!=null)&&(sysEnvFile.length()>4)) {
			 File envfile=new File(sysEnvFile);
			 if (envfile.exists()) 
				 return sysEnvFile;
			 else 
				 throw new RuntimeException("Environment File not Found : "+sysEnvFile);
		 }
		 return null;
	}
	
	/**
	 * Get the execution environment os.
	 * 
	 * @return os
	 */
	public String getOSType() {
			String runOS = GetPropertyValue("ostype");
			if(runOS.equalsIgnoreCase("windows")) return "WINDOWS";
			 else if(runOS.equalsIgnoreCase("MAC")) return "MAC";
			 else if(runOS.equalsIgnoreCase("LINUX")) return "LINUX";
			 else return "WINDOWS";
			 
		
	}
	
	/**
	 * Get the browser headless.
	 * 
	 * @return isBrowserHeadless
	 */
	public boolean isBrowserHeadless() {
		String envheadless = GetPropertyValue("headless");
		if(envheadless.equalsIgnoreCase("No") || envheadless.equalsIgnoreCase("False")) return false;
		else  return true;
	}
	
	/**
	 * Get the application url.
	 * 
	 * @return url
	 */
	public String getApplicationUrl() {
		String url = null;
		url = GetPropertyValue("url");
		if(url != null) return url;
		else throw new RuntimeException("Application Url not specified in the Configuration.properties file for the Key:url");
			
	}
	
	/**
	 * Get the application url.
	 * 
	 * @return url
	 */
	public String getAdminApplicationUrl() {
		
		String url = null;
		url = GetPropertyValue("admin.url");
		if(url != null) return url;
		else throw new RuntimeException("Application Admin Url not specified in the Configuration.properties file for the Key:url");
	}
	
	/**
	 * Get the application username.
	 * 
	 * @return username
	 */
	public String getApplicationUsername() {
		
		String username =null;
		String PropertName= FormUserPropertyName("System Admin","username");
		username = GetPropertyValue(PropertName);
		if(username != null) return username;
		else throw new RuntimeException("Application username not specified in the Configuration.properties file for the Key: username");	
	}
	
	/**
	 * Get the application password.
	 * 
	 * @return password
	 */
	public String getApplicationPassword() {
		
		String password =null;		
		String PropertName= FormUserPropertyName("System Admin","password");
		password = GetPropertyValue(PropertName);
		if(password != null) return password;
		else throw new RuntimeException("Application password not specified in the Configuration.properties file for the Key:url");
	}
	

	
	/**
	 * Get the Test Data Resource Path.
	 * 
	 * @return TestDataResourcePath
	 */
	public String getTestDataResourcePath(){
		String testDataResourcePath = GetPropertyValue("testDataResourcePath");
		if(testDataResourcePath!= null) return testDataResourcePath;
		else throw new RuntimeException("Test Data Resource Path not specified in the Configuration.properties file for the Key:testDataResourcePath");		
	}

	
	/**
	 * Get the Download Path.
	 * 
	 * @return downloadpath
	 */
	public String getDownloadPath(){
		String downloadsPath = GetPropertyValue("downloadPath");
		if(downloadsPath!= null) return downloadsPath;
		else throw new RuntimeException("Download Path not specified in the Configuration.properties file for the Key:downloadsPath");		
	}
	/**
	 * Get the ApplicationCustomer.
	 * 
	 * @return Scope
	 */
	public String getApplicationCustomer(){
		String AppCust = null;
		AppCust = GetPropertyValue("customer");
		if(AppCust!= null) return AppCust;
		else throw new RuntimeException("Customer not specified in the Configuration.properties file for the Key:Customer");		
	}
	
	/**
	 * Get the getApplicationOrganization.
	 * 
	 * @return OrganName
	 */
	public String getApplicationOrganization(){
		String OrgNmae = GetPropertyValue("organization");
		if(OrgNmae!= null) return OrgNmae;
		else throw new RuntimeException("Organization not specified in the Configuration.properties file for the Key:Organization");		
	}
	
	/**
	 * Get the Report Config Path.
	 * 
	 * @return ReportConfigPath
	 */
	public String getReportConfigPath(){
		String reportConfigPath = GetPropertyValue("reportConfigPath");
		if(reportConfigPath!= null) return reportConfigPath;
		else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}
	
	/**
	 * Get the getApplicationOrganization.
	 * 
	 * @return OrganName
	 */
	public String getTestNavUrl(){
		String TestNavUrl =  GetPropertyValue("testnav.url");;
		if(TestNavUrl!= null) return TestNavUrl;
		else throw new RuntimeException("testnav.url not specified in the Configuration.properties file for the Key:testnav.url");		
	}
	
	/**Function Name :- getSelectOrgName<br/>
	 * Description   :- Get the SelectOrgName State, District, School from Properties.
	 * @return String
	 */
	public String getSelectOrgName(String OrgType){
		String FS_State=null,FS_Lea=null,FS_Dst=null,FS_Schl=null,FS_Retn=null;
		try {
			FS_State=getPinState();
			FS_Lea=getPinLea();
			FS_Dst=getPinDst();
			FS_Schl=getPinSch();
			switch (OrgType.toLowerCase()) {
			case "state":
				FS_Retn=FS_State;
				break;
			case "lea":
				FS_Retn=FS_State+">"+FS_Lea;
				break;
			case "district":
				if (FS_Lea.length()>1)
					FS_Retn=FS_State+">"+FS_Lea+">"+FS_Dst;
				else
					FS_Retn=FS_State+">"+FS_Dst;	
				break;
			case "school":
				if (FS_Lea.length()>1)
					FS_Retn=FS_State+">"+FS_Lea+">"+FS_Dst+">"+FS_Schl;
				else
					FS_Retn=FS_State+">"+FS_Dst+">"+FS_Schl;
				break;
			default:
				FS_Retn=FS_State;
				break;
			}
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Retn;
	}
	
	/**Function Name :- getPinState<br/>
	 * Description   :- Get the State from Properties.
	 * @return String
	 */
	public String getPinState(){
		String FS_State=null;
		try {
			FS_State=GetPropertyValue("state");
			
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_State;
	}
	
	/**Function Name :- getPinLea<br/>
	 * Description   :- Get the LEA from Properties.
	 * @return String
	 */
	public String getPinLea(){
		String FS_Lea=null;
		try {
			FS_Lea=GetPropertyValue("lea");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Lea;
	}
	
	/**Function Name :- getPinDst<br/>
	 * Description   :- Get the District from Properties.
	 * @return String
	 */
	public String getPinDst(){
		String FS_Dst=null;
		try {
			FS_Dst=GetPropertyValue("distict");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Dst;
	}
	
	/**Function Name :- getPinSch<br/>
	 * Description   :- Get the School from Properties.
	 * @return String
	 */
	public String getPinSch(){
		String FS_Schl=null;
		try {
			FS_Schl=GetPropertyValue("school");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Schl;
	}
	
	/**Function Name :- getState<br/>
	 * Description   :- Get the State from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getState(boolean isFunctional){
		String FS_State=null;
		try {
			if (isFunctional)
				FS_State=GetPropertyValue("testdata.state");
			else
			FS_State=GetPropertyValue("searchtext.state");
			
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_State;
	}
	
	/**Function Name :- getLea<br/>
	 * Description   :- Get the LEA from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getLea(boolean isFunctional){
		String FS_Lea=null;
		try {
			if (isFunctional)
				FS_Lea=GetPropertyValue("testdata.lea");
			else
				FS_Lea=GetPropertyValue("searchtext.lea");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Lea;
	}
	
	
	/**Function Name :- getDst<br/>
	 * Description   :- Get the District from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getDst(boolean isFunctional){
		String FS_Dst=null;
		try {
			if (isFunctional)
				FS_Dst=GetPropertyValue("testdata.distict");
			else
				FS_Dst=GetPropertyValue("searchtext.distict");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Dst;
	}
	
	/**Function Name :- getSch<br/>
	 * Description   :- Get the School from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getSch(boolean isFunctional){
		String FS_Schl=null;
		try {
			if (isFunctional)
				FS_Schl=GetPropertyValue("testdata.school");
			else
				FS_Schl=GetPropertyValue("searchtext.school");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Schl;
	}
	
	/**Function Name :- getAdminName<br/>
	 * Description   :- Get the Admin Name from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getAdminName(boolean isFunctional){
		String FS_Admin=null;
		try {
			if (isFunctional)
				FS_Admin=GetPropertyValue("testdata.admin");
			else
				FS_Admin=GetPropertyValue("testdata.paper.admin");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Admin;
	}
	
	/**Function Name :- getTestName<br/>
	 * Description   :- Get the Test Name from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getTestName(boolean isFunctional){
		String FS_Test=null;
		try {
			if (isFunctional)
				FS_Test=GetPropertyValue("testdata.test");
			else
				FS_Test=GetPropertyValue("testdata.paper.test");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Test;
	}
	
	/**Function Name :- getstudentName<br/>
	 * Description   :- Get the Student Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getstudentName(boolean isFunctional){
		String FS_Student=null;
		try {
			if (isFunctional)
				FS_Student=GetPropertyValue("testdata.student");
			else
				FS_Student=GetPropertyValue("searchtext.student");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Student;
	}
	
	/**Function Name :- getclassName<br/>
	 * Description   :- Get the Class Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getclassName(boolean isFunctional){
		String FS_class=null;
		try {
			if (isFunctional)
				FS_class=GetPropertyValue("testdata.class");
			else
				FS_class=GetPropertyValue("searchtext.class");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_class;
	}
	
	/**Function Name :- getsessionName<br/>
	 * Description   :- Get the Session Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getsessionName(boolean isFunctional){
		String FS_session=null;
		try {
			if (isFunctional)
				FS_session=GetPropertyValue("testdata.session");
			else
				FS_session=GetPropertyValue("searchtext.session");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_session;
	}
	
	/**Function Name :- getuserName<br/>
	 * Description   :- Get the userName search text from Properties.
	 * @return String
	 */
	public String getuserName(boolean isFunctional){
		String FS_user=null;
		try {
			if (isFunctional)
				FS_user=GetPropertyValue("testdata.user");
			else
				FS_user=GetPropertyValue("searchtext.user");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	
	/**Function Name :- getDataImports<br/>
	 * Description   :- Get the userName search text from Properties.
	 * @return String
	 */
	public String getDataImports(boolean isFunctional){
		String FS_user=null;
		try {
			if (isFunctional)
				FS_user=GetPropertyValue("testdata.dataimports");
			else
				FS_user=GetPropertyValue("searchtext.dataimports");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	/**Function Name :- getUserNamebyRole<br/>
	 * Description   :- Get the specified role userName from Properties.
	 * @return String
	 */
	public String getUserNamebyRole(String role){
		String username=null;
		try {
			String PropertName= FormUserPropertyName(role,"username");
			username = GetPropertyValue(PropertName);
		}
		catch(Exception e)
		{
			return null;
		}
		return username;
	}
	
	/**Function Name :- getPasswordbyRole<br/>
	 * Description   :- Get the specified role password from Properties.
	 * @return String
	 */
	public String getPasswordbyRole(String role){
		String paassword=null;
		try {
			String PropertName= FormUserPropertyName(role,"password");
			paassword = GetPropertyValue(PropertName);
		}
		catch(Exception e)
		{
			return null;
		}
		return paassword;
	}
	
	/**Function Name :- getNamebyRole<br/>
	 * Description   :- Get the specified role user name from Properties.
	 * @return String
	 */
	public String getNamebyRole(String role){
		String name=null;
		try {
			String PropertName= FormUserPropertyName(role,"name");
			name = GetPropertyValue(PropertName);
		}
		catch(Exception e)
		{
			return null;
		}
		return name;
	}
	
	/**Function Name :- getstudentName<br/>
	 * Description   :- Get the Student Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getteacherstudentName(){
		String FS_Student=null;
		try {
			FS_Student=GetPropertyValue("testdata.teacher.student");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Student;
	}
	
	/**Function Name :- getclassName<br/>
	 * Description   :- Get the Class Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getteacherclassName(){
		String FS_class=null;
		try {
			FS_class=GetPropertyValue("testdata.teacher.class");
	
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_class;
	}
	
	/**Function Name :- getTeachersessionName<br/>
	 * Description   :- Get the Session Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getTeachersessionName(){
		String FS_session=null;
		try {
			FS_session=GetPropertyValue("testdata.teacher.session");
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_session;
	}
	
	/**Function Name :- getteacheruserName<br/>
	 * Description   :- Get the Teacher userName  search text from Properties.
	 * @return String
	 */
	public String getteacheruserName(){
		String FS_user=null;
		try {
			
				FS_user=GetPropertyValue("testdata.teacher.user");
			
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**
	 * Get the get Mail Hostname.
	 * 
	 * @return mailHostname
	 */
	public String getMailHostname(){
		String mailHostname = GetPropertyValue("mailHostname");
		if(mailHostname!= null) return mailHostname;
		else throw new RuntimeException("mailHostname not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}
	
	/**
	 * Get the get Mail Sender.
	 * 
	 * @return mailSender
	 */
	public String getMailSender(){
		String mailuser = GetPropertyValue("mailSender");
		if(mailuser!= null) return mailuser;
		else throw new RuntimeException("mailSender not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}
	
	/**
	 * Get the get Mail Username.
	 * 
	 * @return mailuser
	 */
	public String getMailUsername(){
		String mailuser = GetPropertyValue("mailUsername");
		if(mailuser!= null) return mailuser;
		else throw new RuntimeException("mailUsername not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}
	
	/**
	 * Get the get Mail Password.
	 * 
	 * @return mailpwd
	 */
	public String getMailPassword(){
		String mailpwd = GetPropertyValue("mailPassword");
		if(mailpwd!= null) return mailpwd;
		else throw new RuntimeException("mailPassword not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}
	
	/**
	 * Get the Mail Recipients Address
	 * 
	 * @return mailRecp
	 */
	public String getMailRecipientsAddress(){
		String mailRecp = GetPropertyValue("mailRecipients");
		if(mailRecp!= null) return mailRecp;
		else throw new RuntimeException("mailRecipients not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}
	
	/**
	 * Get the Mail Seconday Recipients Address
	 * 
	 * @return mailRecp
	 */
	public String getMailSecondarRecipientsAddress(){
		String mailRecp = GetPropertyValue("mailSecondarRecipients");
		if(mailRecp!= null) return mailRecp;
		else throw new RuntimeException("mailSecondarRecipients not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}
	
	/**
	 * Get the Property Value 
	 * 
	 * @return PropertyValue
	 */
	public String GetPropertyValue(String PropertyName){
		String PropertyValue=null;
		PropertyValue=GetSystemPropertyValue(PropertyName);
		if (PropertyValue==null) 
			PropertyValue=GetStaticFilePropertyValue(PropertyName);
			//System.out.println("Config Property => "+PropertyName+" : "+PropertyValue);
		return PropertyValue;
			
	}
	
	/**
	 * Get the GetSystemPropertyValue
	 * 
	 * @return PropertyValue
	 */
	public String GetSystemPropertyValue(String PropertyName){
		String PropertyValue=null;
		if(System.getProperty(PropertyName)!=null) {
			PropertyValue = System.getProperty(PropertyName);
			//if blank
			 if (PropertyValue.length()<1)
				 PropertyValue = null;
			 System.out.println("System Property => "+PropertyName+" : "+PropertyValue);
		}
		return PropertyValue;
			
	}
	/**
	 * Get the GetStaticFilePropertyValue
	 * 
	 * @return PropertyValue
	 */
	public String GetStaticFilePropertyValue(String PropertyName){
		String PropertyValue=null;
		String FSPropertyName=PropertyName;
		try {
			PropertyName="tstconfig."+PropertyName;
			PropertyValue = properties.getProperty(PropertyName);
			if(PropertyValue!= null) {
				PropertyValue = PropertyValue.replace("\"", "");
				System.out.println("Config Property => "+FSPropertyName+" : "+PropertyValue);
			}
		}
		catch(Exception e)
		{
			return PropertyValue;
		}
		return PropertyValue;
			
	}
	/**
	 * Get the FormUserPropertyName
	 * 
	 * @return PropertyValue
	 */
	public String FormUserPropertyName(String role, String PropertyName){
		switch(role){
		case "System Admin":
			PropertyName="user.systemadmin."+PropertyName;
			break;
		case "Admin":
			PropertyName="user.admin."+PropertyName;
			break;
		case "Test Administrator":
			PropertyName="user.testadmin."+PropertyName;
			break;
		case "Reporting Administrator":
			PropertyName="user.reportadmin."+PropertyName;
			break;
		case "Hand Scoring Administrator":
			PropertyName="user.handscoreadmin."+PropertyName;
			break;
		case "Test Coordinator":
			PropertyName="user.testcord."+PropertyName;
			break;
		case "Test Coordinator - Interim":
			PropertyName="user.testcordint."+PropertyName;
			break;
		case "Teacher":
			PropertyName="user.teacher."+PropertyName;
			break;
		case "Customer Support 1":
			PropertyName="user.systemadmin."+PropertyName;
			break;
		case "Customer Support 2":
			PropertyName="user.systemadmin."+PropertyName;
			break;
		case "Technical Support":
			PropertyName="user.systemadmin."+PropertyName;
			break;
		case "Student Administrator":
			PropertyName="user.studadmin."+PropertyName;
			break;
		default:
			PropertyName="user."+PropertyName;
			break;	
		}
		return PropertyName;
	}

}