package com.pavue.common.dataProviders;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;



import com.google.gson.Gson;
import com.pavue.common.core.FileReaderManager;
import com.pavue.common.testDataTypes.Testdata;
import com.pavue.common.testDataTypes.Testdata_Customers;
import com.pavue.common.testDataTypes.Testdata_Customers_APIDATA;
import com.pavue.common.testDataTypes.Testdata_Customers_Functional;
import com.pavue.common.testDataTypes.Testdata_Customers_Searchtext;

public class JsonDataReader {

	private final String TestDataFilePath = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() + "testdata.json";
	private static String environmentType;
	private static String customer;
	private static String ENVTestDataFilePath=null;
	private List<Testdata> testDataList;
	
	public JsonDataReader(){
		
		environmentType = FileReaderManager.getInstance().getConfigReader().getEnvironment();
		//Get dynamic env file
		ENVTestDataFilePath=FileReaderManager.getInstance().getConfigReader().getEnvironmentFile();
		//Get resources env files
		if (ENVTestDataFilePath==null) {
			if (environmentType.equalsIgnoreCase("PADEV")) 
				ENVTestDataFilePath=FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() + "PADEV.json";
			else if (environmentType.equalsIgnoreCase("PASMK")) 
				ENVTestDataFilePath=FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() + "PASMK.json";
			else if(environmentType.equals("LOCAL")) 
					ENVTestDataFilePath=FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() + "LOCAL.json";
			else 
				ENVTestDataFilePath=FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() + "PADEV.json";
		}
		testDataList=getTestDatabyfile(ENVTestDataFilePath);
		customer= FileReaderManager.getInstance().getConfigReader().getApplicationCustomer();
	}
	
	
	/**Function Name :- getTestData<br/>
	 * Description   :- Get the Testdata Value specified to the data set from JSON file.
	 * @return List<Testdata>
	 */
	private List<Testdata> getTestData() {
		Gson gson = new Gson();
		BufferedReader bufferReader = null;
		try {
			bufferReader = new BufferedReader(new FileReader(TestDataFilePath));
			Testdata[] testdata = gson.fromJson(bufferReader, Testdata[].class);
			//System.out.println("No of Config List :"+config.length);
			return Arrays.asList(testdata);
		}catch(FileNotFoundException e) {
			throw new RuntimeException("Json file not found at path : " + TestDataFilePath);
		}finally {
			try { if(bufferReader != null) bufferReader.close();}
			catch (IOException ignore) {}
		}
	}
	
	
	/**Function Name :- getTestData<br/>
	 * Description   :- Get the Testdata Value specified to the data set from JSON file.
	 * @return List<Testdata>
	 */
	private List<Testdata> getTestDatabyfile(String EnvTestDataFile) {
		Gson gson = new Gson();
		BufferedReader bufferReader = null;
		try {
			bufferReader = new BufferedReader(new FileReader(EnvTestDataFile));
			Testdata[] testdata = gson.fromJson(bufferReader, Testdata[].class);
			//System.out.println("No of Config List :"+config.length);
			return Arrays.asList(testdata);
		}catch(FileNotFoundException e) {
			throw new RuntimeException("Json file not found at path : " + EnvTestDataFile);
		}finally {
			try { if(bufferReader != null) bufferReader.close();}
			catch (IOException ignore) {}
		}
	}
	
	/**Function Name :- getApplicationUrl<br/>
	 * Description   :- Get the AppUrl from JSON file for environment.
	 * @return String
	 */
	public String getApplicationUrl(){
		String FS_URL=null;
		FS_URL=testDataList.stream().filter(x ->x.getEnvironment().equalsIgnoreCase(environmentType)).findAny().get().getUrl();
		if(FS_URL != null) return FS_URL;
		else throw new RuntimeException("Application url not specified in the testdata file for the Key:url");
		
	}
	
	/**Function Name :- getAdminApplicationUrl<br/>
	 * Description   :- Get the Application AdminUrl from JSON file for environment.
	 * @return String
	 */
	public String getAdminApplicationUrl(){
		String FS_AdminURL=null;
		FS_AdminURL=testDataList.stream().filter(x ->x.getEnvironment().equalsIgnoreCase(environmentType)).findAny().get().getAdminUrl();
		if(FS_AdminURL != null) return FS_AdminURL;
		else throw new RuntimeException("Application Admin url not specified in the testdata file for the Key:adminurl");
	}
	
	/**Function Name :- getCustomerslist<br/>
	 * Description   :- Get the customer list from JSON file for environment.
	 * @return List<Testdata_Customers>
	 */
	public List<Testdata_Customers> getCustomerslist(){
		List<Testdata_Customers> lstcustomers=null;
		try {
			lstcustomers=testDataList.stream().filter(x ->x.getEnvironment().equalsIgnoreCase(environmentType)).findAny().get().getCustomers();
		}
		catch(Exception e)
		{
			return null;
		}
		return lstcustomers;
	}
	
	/**Function Name :- getCustomerFields<br/>
	 * Description   :- Get the customer fields from JSON file for environment and customer.
	 * @return Testdata_Customers
	 */
	public Testdata_Customers getCustomerFields(){
		Testdata_Customers customerfields=null;
		try {
			customerfields=getCustomerslist().stream().filter(y->y.getCustomer().equalsIgnoreCase(customer)).findAny().get();
		}
		catch(Exception e)
		{
			return null;
		}
		return customerfields;
	}
	
	/**Function Name :- getFunctionalFields<br/>
	 * Description   :- Get the Functional fields from JSON file for environment and customer.
	 * @return Testdata_Customers_Functional
	 */
	public Testdata_Customers_Functional getFunctionalFields(){
		Testdata_Customers_Functional functionalfields=null;
		try {
		functionalfields=getCustomerFields().getFunctional();
		}
		catch(Exception e)
		{
			return null;
		}
		return functionalfields;
	}
	
	/**Function Name :- getSecondaryFields<br/>
	 * Description   :- Get the Secondary fields from JSON file for environment and customer.
	 * @return Testdata_Customers_Secondary
	 */
	public Testdata_Customers_Searchtext getSecondaryFields(){
		Testdata_Customers_Searchtext secondaryfields=null;
		try {
			secondaryfields=getCustomerFields().getsearchtext();
		}
		catch(Exception e)
		{
			return null;
		}
		return secondaryfields;
	}
	
	/**Function Name :- Testdata_Customers_APIDATA<br/>
	 * Description   :- Get the APIDATA fields from JSON file for environment and customer.
	 * @return Testdata_Customers_APIDATA
	 */
	public Testdata_Customers_APIDATA getAPIDataFields(){
		Testdata_Customers_APIDATA APIDatafields=null;
		try {
			APIDatafields=getCustomerFields().getAPIDATA();
		}
		catch(Exception e)
		{
			return null;
		}
		return APIDatafields;
	}
	/**Function Name :- getApplicationCustomer<br/>
	 * Description   :- Get the Customer from JSON file for environment and Customer.
	 * @return String
	 */
	public String getApplicationCustomer(){
		String FS_Customer=null;
		try {
			FS_Customer=getCustomerFields().getCustomer();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Customer;
	}
	
	/**Function Name :- getTestNavUrl<br/>
	 * Description   :- Get the TestNavUrl from JSON file for environment and Customer.
	 * @return String
	 */
	public String getTestNavUrl(){
		String FS_TestNavURL=null;
		try {
			FS_TestNavURL=getCustomerFields().getTestNavUrl();
			
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_TestNavURL;
	}
	
	/**Function Name :- getSelectOrgName<br/>
	 * Description   :- Get the SelectOrgName State, District, School from JSON file for environment and Customer.
	 * @return String
	 */
	public String getSelectOrgName(String OrgType){
		String FS_State=null,FS_Lea=null,FS_Dst=null,FS_Schl=null,FS_Retn=null;
		try {
			FS_State=getCustomerFields().getState();
			FS_Lea=getCustomerFields().getLea();
			FS_Dst=getCustomerFields().getDistict();
			FS_Schl=getCustomerFields().getSchool();
			switch (OrgType.toLowerCase()) {
			case "state":
				FS_Retn=FS_State;
				break;
			case "lea":
				FS_Retn=FS_State+">"+FS_Lea;
				break;
			case "district":
				if (FS_Lea.length()>1)
					FS_Retn=FS_State+">"+FS_Lea+">"+FS_Dst;
				else
					FS_Retn=FS_State+">"+FS_Dst;	
				break;
			case "school":
				if (FS_Lea.length()>1)
					FS_Retn=FS_State+">"+FS_Lea+">"+FS_Dst+">"+FS_Schl;
				else
					FS_Retn=FS_State+">"+FS_Dst+">"+FS_Schl;
				break;
			default:
				FS_Retn=FS_State;
				break;
			}
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Retn;
	}
	
	/**
	 * Get the getApplicationOrganization.
	 * 
	 * @return OrganName
	 */
	public String getApplicationOrganization(){
		String OrgNmae = getSelectOrgName("state");
		if(OrgNmae!= null) return OrgNmae;
		else throw new RuntimeException("Organization not specified in the from JSON file for the Key:State,LEA,District,School");		
	}
	
	/**Function Name :- getPinState<br/>
	 * Description   :- Get the State from JSON file for environment and Customer.
	 * @return String
	 */
	public String getPinState(){
		String FS_State=null;
		try {
			FS_State=getCustomerFields().getState();
			
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_State;
	}
	
	/**Function Name :- getPinLea<br/>
	 * Description   :- Get the LEA from JSON file for environment and Customer.
	 * @return String
	 */
	public String getPinLea(){
		String FS_Lea=null;
		try {
			FS_Lea=getCustomerFields().getLea();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Lea;
	}
	
	/**Function Name :- getPinDst<br/>
	 * Description   :- Get the District from JSON file for environment and Customer.
	 * @return String
	 */
	public String getPinDst(){
		String FS_Dst=null;
		try {
			FS_Dst=getCustomerFields().getDistict();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Dst;
	}
	
	/**Function Name :- getPinSch<br/>
	 * Description   :- Get the School from JSON file for environment and Customer.
	 * @return String
	 */
	public String getPinSch(){
		String FS_Schl=null;
		try {
			FS_Schl=getCustomerFields().getSchool();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Schl;
	}
	
	/**Function Name :- getState<br/>
	 * Description   :- Get the State from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getState(boolean isFunctional){
		String FS_State=null;
		try {
			if (isFunctional)
				FS_State=getFunctionalFields().getState();
			else
			FS_State=getSecondaryFields().getState();
			
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_State;
	}
	
	/**Function Name :- getLea<br/>
	 * Description   :- Get the LEA from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getLea(boolean isFunctional){
		String FS_Lea=null;
		try {
			if (isFunctional)
				FS_Lea=getFunctionalFields().getLea();
			else
			FS_Lea=getSecondaryFields().getLea();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Lea;
	}
	
	
	/**Function Name :- getDst<br/>
	 * Description   :- Get the District from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getDst(boolean isFunctional){
		String FS_Dst=null;
		try {
			if (isFunctional)
				FS_Dst=getFunctionalFields().getDistict();
			else
				FS_Dst=getSecondaryFields().getDistict();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Dst;
	}
	
	/**Function Name :- getSch<br/>
	 * Description   :- Get the School from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getSch(boolean Functional){
		String FS_Schl=null;
		try {
			if (Functional)
				FS_Schl=getFunctionalFields().getSchool();
			else
			FS_Schl=getSecondaryFields().getSchool();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Schl;
	}
	
	/**Function Name :- getAdminName<br/>
	 * Description   :- Get the Admin Name from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getAdminName(boolean isFunctional){
		String FS_Admin=null;
		try {
			if (isFunctional)
				FS_Admin=getFunctionalFields().getAdmin();
			else
				FS_Admin=getSecondaryFields().getAdmin();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Admin;
	}
	
	/**Function Name :- getTestName<br/>
	 * Description   :- Get the Test Name from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getTestName(boolean Functional){
		String FS_Test=null;
		try {
			if (Functional)
				FS_Test=getFunctionalFields().getTest();
			else
				FS_Test=getSecondaryFields().getTest();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Test;
	}
	
	
	/**Function Name :- getPaperAdminName<br/>
	 * Description   :- Get the Admin Name from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getPaperAdminName(){
		String FS_Admin=null;
		try {
				FS_Admin=getFunctionalFields().getPaperAdmin();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Admin;
	}
	
	/**Function Name :- getPaperTestName<br/>
	 * Description   :- Get the Test Name from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getPaperTestName(){
		String FS_Test=null;
		try {
			
			FS_Test=getFunctionalFields().getPaperTest();
			
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Test;
	}
	
	/**Function Name :- getstudentName<br/>
	 * Description   :- Get the Student Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getstudentName(boolean isFunctional){
		String FS_Student=null;
		try {
			if (isFunctional)
				FS_Student=getFunctionalFields().getStudent();
			else
				FS_Student=getSecondaryFields().getStudent();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Student;
	}
	
	/**Function Name :- getclassName<br/>
	 * Description   :- Get the Class Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getclassName(boolean isFunctional){
		String FS_class=null;
		try {
			if (isFunctional)
				FS_class=getFunctionalFields().getClass_();
			else
				FS_class=getSecondaryFields().getClass_();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_class;
	}
	
	/**Function Name :- getsessionName<br/>
	 * Description   :- Get the Session Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getsessionName(boolean isFunctional){
		String FS_session=null;
		try {
			if (isFunctional)
				FS_session=getFunctionalFields().getSession();
			else
				FS_session=getSecondaryFields().getSession();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_session;
	}
	
	/**Function Name :- getPapersessionName<br/>
	 * Description   :- Get the Paper Session Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getPapersessionName(boolean isFunctional){
		String FS_session=null;
		try {
			if (isFunctional)
				FS_session=getFunctionalFields().getPaperSession();
			else
				FS_session=getSecondaryFields().getPaperSession();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_session;
	}
	
	/**Function Name :- getuserName<br/>
	 * Description   :- Get the userName search text from JSON file for environment and Customer.
	 * @return String
	 */
	public String getuserName(boolean isFunctional){
		String FS_user=null;
		try {
			if (isFunctional)
				FS_user=getFunctionalFields().getUser();
			
			else
				FS_user=getSecondaryFields().getUser();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	

	/**Function Name :- getDataImports<br/>
	 * Description   :- Get the userName search text from Properties.
	 * @return String
	 */
	public String getDataImports(boolean isFunctional){
		String FS_user=null;
		try {
			if (isFunctional)
				FS_user=getFunctionalFields().getDataImports();
			else
				FS_user=getSecondaryFields().getDataImports();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getUserNamebyRole<br/>
	 * Description   :- Get the specified role userName from JSON file for environment and Customer.
	 * @return String
	 */
	public String getUserNamebyRole(String role){
		String username=null;
		try {
			username=getCustomerFields().getUsers().stream().filter(z->z.getRole().equalsIgnoreCase(role)).findAny().get().getUsername();
		}
		catch(Exception e)
		{
			return null;
		}
		return username;
	}
	
	/**Function Name :- getPasswordbyRole<br/>
	 * Description   :- Get the specified role password from JSON file for environment and Customer.
	 * @return String
	 */
	public String getPasswordbyRole(String role){
		String paassword=null;
		try {
			paassword=getCustomerFields().getUsers().stream().filter(z->z.getRole().equalsIgnoreCase(role)).findAny().get().getPassword();
		}
		catch(Exception e)
		{
			return null;
		}
		return paassword;
	}
	
	/**Function Name :- getNamebyRole<br/>
	 * Description   :- Get the specified role user name from JSON file for environment and Customer.
	 * @return String
	 */
	public String getNamebyRole(String role){
		String name=null;
		try {
			name=getCustomerFields().getUsers().stream().filter(z->z.getRole().equalsIgnoreCase(role)).findAny().get().getName();
		}
		catch(Exception e)
		{
			return null;
		}
		return name;
	}
	
	/**Function Name :- getApplicationUsername<br/>
	 * Description   :- Get the specified role user name from JSON file for environment and Customer.
	 * @return String
	 */
	public String getApplicationUsername() {
		
		String username =null;
		username = getUserNamebyRole("System Admin");
		if(username != null) return username;
		else throw new RuntimeException("Application username not specified in the testdata file for the Key: username");	
	}
	
	/**Function Name :- getApplicationPassword<br/>
	 * Description   :- Get the specified role password from JSON file for environment and Customer.
	 * @return String
	 */
	public String getApplicationPassword() {
		
		String password =null;		
		password = getPasswordbyRole("System Admin");
		if(password != null) return password;
		else throw new RuntimeException("Application password not specified in the testdata file for the Key:url");
	}
	

	/**Function Name :- getstudentName<br/>
	 * Description   :- Get the Student Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getteacherstudentName(){
		String FS_Student=null;
		try {
			FS_Student=getFunctionalFields().getTeacherstudent();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Student;
	}
	
	/**Function Name :- getclassName<br/>
	 * Description   :- Get the Class Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getteacherclassName(){
		String FS_class=null;
		try {
			FS_class=getFunctionalFields().getTeacherclass();
	
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_class;
	}
	
	/**Function Name :- getTeachersessionName<br/>
	 * Description   :- Get the Session Search text from JSON file in Functional for environment and Customer.
	 * @return String
	 */
	public String getTeachersessionName(){
		String FS_session=null;
		try {
			FS_session=getFunctionalFields().getTeachersession();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_session;
	}
	
	/**Function Name :- getteacheruserName<br/>
	 * Description   :- Get the Teacher userName  search text from Properties.
	 * @return String
	 */
	public String getteacheruserName(){
		String FS_user=null;
		try {
			
				FS_user=getFunctionalFields().getTeacheruser();
			
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	
	/**Function Name :- getCustomerrefID<br/>
	 * Description   :- Get the Customer RefID from JSON file for environment and Customer.
	 * @return String
	 */
	public String getCustomerrefID(){
		String FS_Customer=null;
		try {
			FS_Customer=getAPIDataFields().getcustomerRefID();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Customer;
	}
	
	/**Function Name :- getStateRefID<br/>
	 * Description   :- Get the State RefID from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getStateRefID(){
		String FS_State=null;
		try {
				FS_State=getAPIDataFields().getStateRefID();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_State;
	}
	
	/**Function Name :- getLeaRefID<br/>
	 * Description   :- Get the LEA RefID from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getLeaRefID(){
		String FS_Lea=null;
		try {
			FS_Lea=getAPIDataFields().geLEARefID();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Lea;
	}
	
	
	/**Function Name :- getDstRefID<br/>
	 * Description   :- Get the District Ref Id from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getDstRefID(){
		String FS_Dst=null;
		try {
			FS_Dst=getAPIDataFields().getDistrictRefID();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Dst;
	}
	
	/**Function Name :- getSchRefID<br/>
	 * Description   :- Get the School RefID from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getSchRefID(){
		String FS_Schl=null;
		try {
			FS_Schl=getAPIDataFields().getSchoolRefID();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Schl;
	}
	
	/**Function Name :- getAdminRefID<br/>
	 * Description   :- Get the Admin RefID from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getAdminRefID(){
		String FS_Admin=null;
		try {
			FS_Admin=getAPIDataFields().getadminRefId();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Admin;
	}
	
	/**Function Name :- getTestRefID<br/>
	 * Description   :- Get the Test RefID from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getTestRefID(){
		String FS_Test=null;
		try {
			FS_Test=getAPIDataFields().gettestrefid();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Test;
	}
	
	/**Function Name :- getstudentRefid<br/>
	 * Description   :- Get the Student RefID  from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getstudentRefid(){
		String FS_Student=null;
		try {
			FS_Student=getAPIDataFields().getstudentRefId();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Student;
	}
	
	/**Function Name :- getclassRefID<br/>
	 * Description   :- Get the Class RefID  from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getclassRefID(){
		String FS_class=null;
		try {
			FS_class=getAPIDataFields().getclassRefId();
	
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_class;
	}
	
	/**Function Name :- getsessionRefID<br/>
	 * Description   :- Get the Session RefID from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getsessionRefID(){
		String FS_session=null;
		try {
			FS_session=getAPIDataFields().getsessionRefId();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_session;
	}
	
	/**Function Name :- getuserRefid<br/>
	 * Description   :- Get the Users RefID  from JSON file in APIDATA for environment and Customer.
	 * @return String
	 */
	public String getuserRefid(){
		String FS_user=null;
		try {
			
				FS_user=getAPIDataFields().getuserRefId();
			
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getDataImportsRefID<br/>
	 * Description   :- Get the Dataimports RefID  text from Properties.
	 * @return String
	 */
	public String getDataImportsRefID(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getdataimportsRefId();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getProductTypeRefID<br/>
	 * Description   :- Get the Product Type RefID  text from Properties.
	 * @return String
	 */
	public String getProductTypeRefID(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getproducttyperefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getteacherstudentrefid<br/>
	 * Description   :- Get the RefID  text from Properties.
	 * @return String
	 */
	public String getteacherstudentrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getteacherstudentrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getteacherclassrefid<br/>
	 * Description   :- Get the RefID  text from Properties.
	 * @return String
	 */
	public String getteacherclassrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getteacherclassrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	/**Function Name :- getteachersessionrefid<br/>
	 * Description   :- Get the RefID  text from Properties.
	 * @return String
	 */
	public String getteachersessionrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getteachersessionrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	/**Function Name :- getteacheruserrefid<br/>
	 * Description   :- Get the  RefID  text from Properties.
	 * @return String
	 */
	public String getteacheruserrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getteacheruserrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	/**Function Name :- getlowstakesadminrefid<br/>
	 * Description   :- Get the RefID  text from Properties.
	 * @return String
	 */
	public String getlowstakesadminrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getlowstakesadminrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	/**Function Name :- getlowstakessessionrefid<br/>
	 * Description   :- Get the lowstakessession RefID  text from Properties.
	 * @return String
	 */
	public String getlowstakessessionrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getlowstakessessionrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- gethighstakesadminrefid<br/>
	 * Description   :- Get the RefID  text from Properties.
	 * @return String
	 */
	public String gethighstakesadminrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().gethighstakesadminrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	/**Function Name :- gethighstakessessionrefid<br/>
	 * Description   :- Get the lowstakessession RefID  text from Properties.
	 * @return String
	 */
	public String gethighstakessessionrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().gethighstakessessionrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	
	/**Function Name :- getmasteradminrefid<br/>
	 * Description   :- Get the master admin RefID  text from Properties.
	 * @return String
	 */
	public String getmasteradminrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getmasteradminrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	/**Function Name :- getlowstakesproducttyperefid<br/>
	 * Description   :- Get the lowstakes producttype refid  text from Properties.
	 * @return String
	 */
	public String getlowstakesproducttyperefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getlowstakesproducttyperefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	/**Function Name :- gethighstakesproducttyperefid<br/>
	 * Description   :- Get the high stakes producttype refid  text from Properties.
	 * @return String
	 */
	public String gethighstakesproducttyperefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().gethighstakesproducttyperefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	public String getproductType(boolean isFunctional){
		String FS_user=null;
		try {
			if (isFunctional)
				FS_user=getFunctionalFields().getproducttype();
			else
				FS_user=getSecondaryFields().getproducttype();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	public String getCourse(boolean isFunctional){
		String FS_user=null;
		try {
			if (isFunctional)
				FS_user=getFunctionalFields().getcourses();
			else
				FS_user=getSecondaryFields().getcourses();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getproviderconfigrefid<br/>
	 * Description   :- Get the providerconfigrefid  text from Properties.
	 * @return String
	 */
	public String getproviderconfigrefid(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getproviderconfigrefid();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getgradeReferenceId<br/>
	 * Description   :- Get the gradeReferenceId  text from Properties.
	 * @return String
	 */
	public String getgradeReferenceId(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getgradeReferenceId();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getsubjectReferenceId<br/>
	 * Description   :- Get the subjectReferenceId  text from Properties.
	 * @return String
	 */
	public String getsubjectReferenceId(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getsubjectReferenceId();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getproductTypeProviderReferenceId<br/>
	 * Description   :- Get the productTypeProviderReferenceId  text from Properties.
	 * @return String
	 */
	public String getproductTypeProviderReferenceId(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getproductTypeProviderReferenceId();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	/**Function Name :- getClientidbyTokenname<br/>
	 * Description   :- Get the specified Token name Clientid from JSON file for environment and Customer.
	 * @return String
	 */
	public String getClientidbyTokenname(String Tokenname){
		String clientid=null;
		try {
			clientid=getCustomerFields().getoauthtoken().stream().filter(z->z.gettokenname().equalsIgnoreCase(Tokenname)).findAny().get().getclientid();
		}
		catch(Exception e)
		{
			return null;
		}
		return clientid;
	}
	
	/**Function Name :- getClientsecretbyTokenname<br/>
	 * Description   :- Get the specified Token name Clientsecret from JSON file for environment and Customer.
	 * @return String
	 */
	public String getClientsecretbyTokenname(String Tokenname){
		String clientid=null;
		try {
			clientid=getCustomerFields().getoauthtoken().stream().filter(z->z.gettokenname().equalsIgnoreCase(Tokenname)).findAny().get().getclientsecret();
		}
		catch(Exception e)
		{
			return null;
		}
		return clientid;
	}
	/**Function Name :- gettokenurlbyTokenname<br/>
	 * Description   :- Get the specified Token name tokenurl from JSON file for environment and Customer.
	 * @return String
	 */
	public String gettokenurlbyTokenname(String Tokenname){
		String tokenurl=null;
		try {
			tokenurl=getCustomerFields().getoauthtoken().stream().filter(z->z.gettokenname().equalsIgnoreCase(Tokenname)).findAny().get().gettokenurl();
		}
		catch(Exception e)
		{
			return null;
		}
		return tokenurl;
	}
	/**Function Name :- getscopebyTokenname<br/>
	 * Description   :- Get the specified Token name scope from JSON file for environment and Customer.
	 * @return String
	 */
	public String getscopebyTokenname(String Tokenname){
		String scope=null;
		try {
			scope=getCustomerFields().getoauthtoken().stream().filter(z->z.gettokenname().equalsIgnoreCase(Tokenname)).findAny().get().getscope();
		}
		catch(Exception e)
		{
			return null;
		}
		return scope;
	}
	/**Function Name :- getgranttypebyTokenname<br/>
	 * Description   :- Get the specified Token name granttype from JSON file for environment and Customer.
	 * @return String
	 */
	public String getgranttypebyTokenname(String Tokenname){
		String granttype=null;
		try {
			granttype=getCustomerFields().getoauthtoken().stream().filter(z->z.gettokenname().equalsIgnoreCase(Tokenname)).findAny().get().getgranttype();
		}
		catch(Exception e)
		{
			return null;
		}
		return granttype;
	}
	
	/**Function Name :- getcourseReferenceId<br/>
	 * Description   :- Get the courseReferenceId  text from Properties.
	 * @return String
	 */
	public String getcourseReferenceId(){
		String FS_user=null;
		try {
			FS_user=getAPIDataFields().getcourseReferenceId();
		
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_user;
	}
	
	public String getGradeName(boolean Functional){
		String FS_Grade=null;
		try {
			if (Functional)
				FS_Grade=getFunctionalFields().getGrade();
			else
				FS_Grade=getSecondaryFields().getGrade();
		}
		catch(Exception e)
		{
			return null;
		}
		return FS_Grade;
	}
	
}