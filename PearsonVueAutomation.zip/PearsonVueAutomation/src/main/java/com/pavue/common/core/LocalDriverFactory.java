package com.pavue.common.core;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
//import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.pavue.webdriver.CommonUtility;

import io.github.bonigarcia.wdm.WebDriverManager;

@SuppressWarnings("unused")
public class LocalDriverFactory {
	public static WebDriver createInstance(String browserName) throws MalformedURLException {
		WebDriver driver = null;
		String DriverLoc=null;
		String OSTYpe=null;
		boolean isHeadless=true;
		String ExecutionType=null;
		String downloadpath=null;
		String Remotehost=null;
		DesiredCapabilities capabilities = new DesiredCapabilities();
		if ((browserName.equalsIgnoreCase("FIREFOX"))){
			
	        downloadpath=FileReaderManager.getInstance().getConfigReader().getDownloadPath();
			
			  // Creating firefox profile
	        FirefoxProfile profile = new FirefoxProfile();
	 
	        // Instructing firefox to use custom download location
	        profile.setPreference("browser.download.folderList", 2);
	 
	        // Setting custom download directory
	        profile.setPreference("browser.download.dir", System.getProperty("user.dir")+downloadpath);
	        
	
	        // Skipping Save As dialog box for types of files with their MIME
	        profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
	                "text/csv,application/java-archive, application/x-msexcel,application/excel,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,application/vnd.microsoft.portable-executable");
	        profile.setPreference( "browser.download.manager.showWhenStarting", false );
		
			FirefoxOptions options = new FirefoxOptions();
			options.setProfile(profile);
			
			isHeadless=FileReaderManager.getInstance().getConfigReader().isBrowserHeadless();
			//Set Firefox Headless mode as TRUE
			if (isHeadless) {
				options.setHeadless(true);
			}
			ExecutionType=FileReaderManager.getInstance().getConfigReader().getExecutionType();
			if (ExecutionType.equalsIgnoreCase("REMOTE")) {
				Remotehost=FileReaderManager.getInstance().getConfigReader().getRemoteHost();
				OSTYpe=FileReaderManager.getInstance().getConfigReader().getOSType();
				//Set BrowserName
				capabilities = DesiredCapabilities.firefox();
				capabilities.setCapability("browserName", "firefox");
				capabilities.setCapability("os", OSTYpe);
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				//Set Browser
				driver = new RemoteWebDriver(new URL("http://" + Remotehost + ":4444/wd/hub"), capabilities);
			}
			else {
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver(options);
			}
		
		}
		else if (browserName.equalsIgnoreCase("INTERNETEXPLORER")){
			ExecutionType=FileReaderManager.getInstance().getConfigReader().getExecutionType();
			if (ExecutionType.equalsIgnoreCase("REMOTE")) {
				Remotehost=FileReaderManager.getInstance().getConfigReader().getRemoteHost();
				OSTYpe=FileReaderManager.getInstance().getConfigReader().getOSType();
				//Set BrowserName
				capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setBrowserName("ie");
				capabilities.setCapability("os", OSTYpe);
				//Set Browser
				 driver = new RemoteWebDriver(new URL("http://" + Remotehost + ":4444/wd/hub"), capabilities);
			}
			else {
				
//				String localDownloadPath = System.getProperty("java.io.tmpdir");
//				System.out.println("localDownloadPath : "+localDownloadPath);
				String LaunchURL=FileReaderManager.getInstance().getConfigReader().getApplicationUrl();
				//String LaunchURL=FileReaderManager.getInstance().getConfigReader().getTestNavUrl();
				capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, LaunchURL);
				capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			 WebDriverManager.iedriver().arch32().setup();
			driver = new InternetExplorerDriver(capabilities);
			}
		}
		else if (browserName.equalsIgnoreCase("EDGE")){
			ExecutionType=FileReaderManager.getInstance().getConfigReader().getExecutionType();
			if (ExecutionType.equalsIgnoreCase("REMOTE")) {
				Remotehost=FileReaderManager.getInstance().getConfigReader().getRemoteHost();
				OSTYpe=FileReaderManager.getInstance().getConfigReader().getOSType();
				//Set BrowserName
				capabilities = DesiredCapabilities.edge();
//				capabilities.setBrowserName("ie");
//				capabilities.setCapability("os", OSTYpe);
				//Set Browser
				 driver = new RemoteWebDriver(new URL("http://" + Remotehost + ":4444/wd/hub"), capabilities);
			}
			else {
				
				//File file = new File("C:\\MyDrive\\Raghu\\MyInstalled\\edge\\MicrosoftWebDriver.exe");
			    //System.setProperty("webdriver.edge.driver", file.getAbsolutePath());
			    capabilities = DesiredCapabilities.edge();
			   // driver = new EdgeDriver(capabilities);
				    
			 WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver(capabilities);
			}
		}
		else if (browserName.equalsIgnoreCase("CHROME"))
		{       	
			isHeadless=FileReaderManager.getInstance().getConfigReader().isBrowserHeadless();
			downloadpath=FileReaderManager.getInstance().getConfigReader().getDownloadPath();
			
			//Set Chrome Headless mode as TRUE
			ChromeOptions options = new ChromeOptions();
		    
			 // Setting new download directory path
	        Map<String, Object> prefs = new HashMap<String, Object>();
	        System.out.println("DownloadPath "+System.getProperty("user.dir")+downloadpath);
	        prefs.put("download.default_directory",System.getProperty("user.dir")+downloadpath);
	        options.setExperimentalOption("prefs", prefs);
	        //Headless
			if (isHeadless) {
				options.addArguments("--headless");
				options.addArguments("--disable-gpu");
				options.addArguments("window-size=1200x600");
				options.addArguments("--no-sandbox");
			}
			ExecutionType=FileReaderManager.getInstance().getConfigReader().getExecutionType();
			//Start browser initialize
			System.out.println("Chrome browser initialization... ");
			capabilities = DesiredCapabilities.chrome();
			if (ExecutionType.equalsIgnoreCase("REMOTE")) {
				Remotehost=FileReaderManager.getInstance().getConfigReader().getRemoteHost();
				OSTYpe=FileReaderManager.getInstance().getConfigReader().getOSType();
				//Set BrowserName
				capabilities.setBrowserName("chrome");
				capabilities.setCapability("os", OSTYpe);
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				//Set Browser
			     driver = new RemoteWebDriver(new URL("http://" + Remotehost + ":4444/wd/hub"), capabilities);
				//driver = new RemoteWebDriver(new URL(RemoteUrl), capabilities);
			}
			else{
				//Performance Log properties 
				LoggingPreferences logP = new LoggingPreferences();
			    logP.enable(LogType.PERFORMANCE, Level.INFO);
				capabilities.setCapability(CapabilityType.LOGGING_PREFS, logP);
				options.setExperimentalOption("w3c", false);
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver(capabilities);
			}
	 
		}
		else if(browserName.equalsIgnoreCase("SAFARI")){
				capabilities = DesiredCapabilities.safari();
				capabilities.setBrowserName("safari");
				capabilities.setPlatform(org.openqa.selenium.Platform.MAC);
				capabilities.setJavascriptEnabled(true);
				/*driver = new RemoteWebDriver(new URL("http://172.21.76.157:4444/wd/hub"), capabilities);*/
		}
		else if(browserName.equalsIgnoreCase("PHANTOMJS"))	{
				WebDriverManager.phantomjs().setup();	
				driver = new PhantomJSDriver();
		}
//		driver.manage().timeouts().pageLoadTimeout(250, TimeUnit.SECONDS);
//		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//		driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
		if (!isHeadless) {
			
			driver.manage().timeouts().pageLoadTimeout(160, TimeUnit.SECONDS);
			//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
			driver.manage().window().maximize();
		}
		else {
			driver.manage().timeouts().pageLoadTimeout(250, TimeUnit.SECONDS);
			//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);
			
		}
		
		return driver;
	}
}