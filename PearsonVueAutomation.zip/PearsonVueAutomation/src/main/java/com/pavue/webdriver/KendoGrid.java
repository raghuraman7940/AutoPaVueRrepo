package com.pavue.webdriver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.LeftClick;
import com.pavue.webdriver.WebDriverMain;


public class KendoGrid {
	
	public static String Kendogrid = "xpath|//kendo-grid//table";
	public static String KD_HeaderRow= "xpath|//kendo-grid//table/thead/tr/th";
	public static String KD_DataRowList= "xpath|//kendo-grid//kendo-grid-list//table/tbody/tr";
	public static String KD_Pager_CurrentPage= "xpath|//kendo-grid/kendo-pager/kendo-pager-input/span[contains(@class,'k-pager-input')]/input";
	public static String KD_Pager_MaxPage= "xpath|//kendo-grid/kendo-pager/pa-grid-pagination/span[contains(text(),'Showing ')]";
	public static String KD_Pager_Items= "xpath|//kendo-grid/kendo-pager/kendo-pager-info";
	public static String KD_Pager_ItemsperPage= "xpath|//kendo-grid/kendo-pager/kendo-pager-page-sizes/select";
	public static String KD_Pager_NextPage= "xpath|//kendo-grid/kendo-pager/pa-grid-pagination/span[contains(@class,'arrow-chevron-right')]";
	public static String KD_Pager_PrevPage= "xpath|//kendo-grid/kendo-pager/pa-grid-pagination/span[contains(@class,'arrow-chevron-left')]";
	public static String KD_Pager_FirstPage= "xpath|//kendo-grid/kendo-pager/kendo-pager-prev-buttons/a[@title='Go to the first page']";
	public static String KD_Pager_LastPage= "xpath|//kendo-grid/kendo-pager/kendo-pager-next-buttons/a[@title='Go to the last page']";
	public static String KD_DatagridHeaderRow = "xpath|//kendo-grid//table/thead/tr/th";
	
	
	/**
	 * To Set the Kendo objects
	 * 
	 * @param byStrgylocValue 
	 * @return By 
	 */
	public static By KendoGridObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}
	
	
	/**
	 * Returns a list Kendo grid column header
	 * 
	 * 
	 * @return List<String>
	 * @throws IOException 
	 */
	public static List<String> getColumnHeaders() throws IOException {
		By objlocator = null;
		List<String> MapDgHeader = null;
		List<WebElement> lstheaderRow = WebDriverMain._getElementsWithWait(KendoGridObjects(KD_DatagridHeaderRow));
		if (lstheaderRow.size() >= 1) {
			MapDgHeader=new ArrayList<String>();
			for (int iCol = 0; iCol < lstheaderRow.size(); iCol++) {
				String sDGColmnName = lstheaderRow.get(iCol).getText();
				MapDgHeader.add(sDGColmnName);
			}
		}
		return MapDgHeader;
	}
	

	/**
	 * Returns a list Kendo grid column header and values
	 * 
	 * @param rowindex
	 * @return HashMap<String, String>
	 * @throws IOException 
	 */
	public static HashMap<String, String> getValuebyRow(int rowindex) throws IOException {
		
		By objlocator = null;
		HashMap<String, String> MapDgOrgRec = null;
		
		  if (rowindex <= 0) {
			  return MapDgOrgRec;
	    }
		  
		List<WebElement> lstOrgrRow = WebDriverMain._getElementsWithWait(KendoGridObjects(KD_DatagridHeaderRow));
		System.out.println("Row Count : " + lstOrgrRow.size());
		List<WebElement> lstheaderRow = WebDriverMain
				._getElementsWithWait(KendoGridObjects(KD_DatagridHeaderRow));
		if (lstOrgrRow.size() > 1) {
			for (int Irow = 1; Irow <= lstOrgrRow.size(); Irow++) {
				if (rowindex == Irow) {
					MapDgOrgRec = new HashMap<String, String>();
					objlocator = CommonUtility
							._getObjectLocator("xpath=//kendo-grid//kendo-grid-list//table/tbody/tr["
									+ Irow + "]/td");
					List<WebElement> dataRec = WebDriverMain._getElementsWithWait(objlocator);
					if (dataRec.size()==lstheaderRow.size()) {
						for (int iCol = 0; iCol < dataRec.size(); iCol++) {
							String sDGColmnName = lstheaderRow.get(iCol).getText();
							String sDGColmnValue = dataRec.get(iCol).getText();
							MapDgOrgRec.put(sDGColmnName, sDGColmnValue);
						}
						return MapDgOrgRec;
					}
					
				}
			}
		} 
		return MapDgOrgRec;
	}
	
	/**
	 * Function Name :- SelectCheckbox<br>
	 * Description :- To click Checkbox.
	 *
	 */
	public static boolean SelectRecord() throws IOException {
		By objlocator = null;
		CommonUtility._sleepForGivenTime(1000);
		List<WebElement> lstUserRow = WebDriverMain._getElementsWithWait(KendoGridObjects(KD_DatagridHeaderRow));
		if (lstUserRow.size() >= 1) {
			for (WebElement UserRow : lstUserRow) {
				objlocator = CommonUtility._getObjectLocator(
						"xpath=//label[contains(@class,'k-checkbox-label')]");
				WebElement tsElm = UserRow.findElement(objlocator);
				if (tsElm!=null) {
					LeftClick.clickByWebElementJS(tsElm);
					CommonUtility._sleepForGivenTime(2000);
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Returns a Kendo grid current page number
	 * 
	 * @return int
	 * @throws IOException 
	 */
	public static int GetCurrentPageNum() throws IOException {
		int currpage=0;
		CommonUtility._sleepForGivenTime(1000);
		WebElement KendoGridEle= WebDriverMain._getElementWithWait(KendoGridObjects(Kendogrid));
		if (KendoGridEle!=null) {
			WebElement PagerEle= WebDriverMain._getElementWithWait(KendoGridObjects(KD_Pager_CurrentPage));
			if (PagerEle!=null) {
				String pagesStr=PagerEle.getText();
				 if (CommonUtility.isNumeric(pagesStr))
					 currpage=Integer.parseInt(pagesStr);
			}
		}
		
		return currpage;
	}
	
	/**
	 * Returns a Kendo grid max page number
	 * 
	 * @return int
	 * @throws IOException 
	 */
	public static int GetMaxPageNum() throws IOException {
		int maxpage=0;
		CommonUtility._sleepForGivenTime(1000);
		WebElement KendoGridEle= WebDriverMain._getElementWithWait(KendoGridObjects(Kendogrid));
		if (KendoGridEle!=null) {
			WebElement PagerEle= WebDriverMain._getElementWithWait(KendoGridObjects(KD_Pager_MaxPage));
			if (PagerEle!=null) {
				String pagesStr=PagerEle.getText();
				String NumericSplit[]=pagesStr.split("of ");
       		  	if (NumericSplit.length>=1){
       			  String ranNum=NumericSplit[1];
       			  if (ranNum.contains("many"))
       				maxpage=2;
       			  else if (CommonUtility.isNumeric(ranNum))
       				  maxpage=Integer.parseInt(ranNum);
       		  	}
			}
		}
		
		return maxpage;
	}
	
	/**
	 * Returns a Kendo grid showing items page number
	 * 
	 * @return int
	 * @throws IOException 
	 */
	public static int GetShowingMaxItems() throws IOException {
		int maxpage=0;
		CommonUtility._sleepForGivenTime(1000);
		WebElement KendoGridEle= WebDriverMain._getElementWithWait(KendoGridObjects(Kendogrid));
		if (KendoGridEle!=null) {
			WebElement PagerEle= WebDriverMain._getElementWithWait(KendoGridObjects(KD_Pager_MaxPage));
			if (PagerEle!=null) {
				CommonUtility._scrolldown();
				String pagesStr=PagerEle.getText();
				String NumericSplit[]=pagesStr.split("of ");
       		  	if (NumericSplit.length>=1){
       			  String ranNum=NumericSplit[1];
       			  if (ranNum.contains("many"))
       				maxpage=35;
       			  else if (CommonUtility.isNumeric(ranNum))
       				  maxpage=Integer.parseInt(ranNum);
       		  	}
			}
		}
		
		return maxpage;
	}

	/**
	 * Returns select Next page in Kendo grid
	 * 
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean SelectNextPage() throws IOException {
		boolean flag=false;
		CommonUtility._sleepForGivenTime(1000);
		WebElement KendoGridEle= WebDriverMain._getElementWithWait(KendoGridObjects(Kendogrid));
		if (KendoGridEle!=null) {
			WebElement PagerEle= WebDriverMain._getElementWithWait(KendoGridObjects(KD_Pager_NextPage));
			if (PagerEle!=null) {
				if(PagerEle.isEnabled()){
					PagerEle.click();
					CommonUtility._sleepForGivenTime(1000);
					flag=true;
				}
			}
		}
		
		return flag;
	}
	
	/**
	 * Returns select Previous page in Kendo grid
	 * 
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean SelectPreviousPage() throws IOException {
		boolean flag=false;
		CommonUtility._sleepForGivenTime(1000);
		WebElement KendoGridEle= WebDriverMain._getElementWithWait(KendoGridObjects(Kendogrid));
		if (KendoGridEle!=null) {
			WebElement PagerEle= WebDriverMain._getElementWithWait(KendoGridObjects(KD_Pager_PrevPage));
			if (PagerEle!=null) {
				if(PagerEle.isEnabled()){
					PagerEle.click();
					CommonUtility._sleepForGivenTime(1000);
					flag=true;
				}
			}
		}
		
		return flag;
	}
	
	/**
	 * Returns select First page in Kendo grid
	 * 
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean SelectFirstPage() throws IOException {
		boolean flag=false;
		CommonUtility._sleepForGivenTime(1000);
		WebElement KendoGridEle= WebDriverMain._getElementWithWait(KendoGridObjects(Kendogrid));
		if (KendoGridEle!=null) {
			WebElement PagerEle= WebDriverMain._getElementWithWait(KendoGridObjects(KD_Pager_FirstPage));
			if (PagerEle!=null) {
				if(PagerEle.isEnabled()){
					PagerEle.click();
					CommonUtility._sleepForGivenTime(1000);
					flag=true;
				}
			}
		}
		
		return flag;
	}
	
	/**
	 * Returns select Items Per page in Kendo grid
	 * 
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean SelectItemsPerPage(String strOption) throws IOException {
		if (strOption == null) {
			throw new IllegalArgumentException(
					"The Option value cannot be null.");
		}
		boolean flag=false;
		CommonUtility._sleepForGivenTime(1000);
		WebElement KendoGridEle= WebDriverMain._getElementWithWait(KendoGridObjects(Kendogrid));
		if (KendoGridEle!=null) {
			WebElement PagerEle= WebDriverMain._getElementWithWait(KendoGridObjects(KD_Pager_ItemsperPage));
			if (PagerEle!=null) {
				Select dropdown = new Select(PagerEle);
				dropdown.selectByValue(strOption);
				CommonUtility._sleepForGivenTime(2000);
				flag=true;
				//flag=DropdownList._byVisibleTextDropdownList(KendoGridObjects(KD_Pager_ItemsperPage), strOption);
			}
		}
		
		return flag;
	}
}