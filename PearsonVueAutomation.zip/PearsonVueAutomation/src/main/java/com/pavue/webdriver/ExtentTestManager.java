package com.pavue.webdriver;

import java.util.HashMap;
import java.util.Map;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import com.pavue.webdriver.ExtentManager;

public class ExtentTestManager {  // new
    static Map<Integer, ExtentTest> extentTestMap = new HashMap<Integer, ExtentTest>();
    public static ExtentReports extent = ExtentManager.getInstance();

    public static synchronized ExtentTest getTest() {
       return extentTestMap.get((int) (long) (Thread.currentThread().getId()));
    	
    }

    public static synchronized void endTest() {
        extent.endTest(extentTestMap.get((int) (long) (Thread.currentThread().getId())));
    }
    
    public static synchronized void FlushTest() {
        //extent.endTest(extentTestMap.get((int) (long) (Thread.currentThread().getId())));
    	//extentTestMap.get((int) (long) (Thread.currentThread().getId())).getTest()..flush().close();
    	extent.flush();
    	//CommonUtility._sleepForGivenTime(2000);
    	//extent.close();
    }
    
    public static synchronized void CloseTest() {
    	extent.close();
    }
    
    
    

    public static synchronized ExtentTest startTest(String testName) {
        return startTest(testName, "");
    }

    public static synchronized ExtentTest startTest(String testName, String desc) {
        ExtentTest test = extent.startTest(testName, desc);
        extentTestMap.put((int) (long) (Thread.currentThread().getId()), test);

        return test;
    }
}
