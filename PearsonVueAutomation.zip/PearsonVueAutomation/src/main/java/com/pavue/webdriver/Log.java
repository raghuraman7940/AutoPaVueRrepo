package com.pavue.webdriver;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.Reporter;

import com.relevantcodes.extentreports.LogStatus;

import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.WebDriverMain;



public class Log {
	private static Logger logger;
	private static String path=null;
	
	public static Logger _getLogger(){
		logger= Logger.getLogger(Thread.currentThread().getStackTrace()[3].getClassName());
		path=CommonUtility._getProjectWS()+"/Log/log4j.properties";
		PropertyConfigurator.configure(path);
		return logger;
	}

	public static void _logInfo(String value){
		_getLogger();
		//ExtentTestManager.getTest().log(LogStatus.INFO, value);
		logger.info(value);
		Reporter.log(value+"<br/>");
	}
	public static boolean _logWarning(String value){
		_getLogger();
		logger.warn(value);
		//ExtentTestManager.getTest().log(LogStatus.INFO,"<font color='red'>"+"WARNING-"+value+"</font><br/>");
	
		Reporter.log("<font color='red'>"+value+"</font><br/>");
		return false;
	}
	public static boolean _logWarningWithScreenShot(String value){
		_getLogger();
		logger.warn(value);
		//ExtentTestManager.getTest().log(LogStatus.INFO, "<font color='red'>"+"WARNING-"+value+"</font><br/>");
		Reporter.log("<font color='red'>"+value+"</font><br/>");
		
		//Take screenshot
		WebDriverMain._takeScreenshot(Thread.currentThread().getStackTrace()[2].getMethodName());
		return false;
	}
}
