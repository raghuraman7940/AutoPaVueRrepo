package com.pavue.webdriver;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;


public class LeftClick{
	
	/**
     * Click on Element as per the specified locator. 
     *
     * @param locator
     *            The element locator to find.
     * @return boolean
	 * @throws InterruptedException 
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _click(By locator) throws IOException{
		boolean bflag=true;
		if (locator == null) {
			UMReporter.log(Status.ERROR, "The Locator value is NULL");
			throw new IllegalArgumentException(
					"The Element locator to send cannot be null.");
		}
		WebElement targetElement = WebDriverMain._getElementWithWait(locator);
		if (targetElement != null) {
			try{
				if(targetElement.isEnabled()){
					CommonUtility.highlighElement(targetElement);
					targetElement.click();
					//UMReporter.log(Status.PASS, " The Locator "+locator+" is clicked ");
					com.pavue.webdriver.WebDriverMain._clickLoading();
					return true;
				}else{
					//Log._logInfo("Element Click: "+locator+" is disabled.");
					//UMReporter.log(Status.PASS, " The Locator "+locator+" is disabled ");
					return true;
				}

			}
			catch(ElementNotVisibleException e)
			{
				com.pavue.webdriver.WebDriverMain._pleaseWaitAndLoadingMessage();
				WebDriverMain._waitForElementVisible(locator);
				targetElement = WebDriverMain._getElementWithWait(locator);
				if(targetElement.isEnabled()){
					CommonUtility.highlighElement(targetElement);
					targetElement.click();
					//UMReporter.log(Status.PASS, " The Locator "+locator+" is clicked ");
					return true;
				}else{
					//Log._logInfo("Element Click: "+locator+" is disabled.");
					//UMReporter.log(Status.PASS, " The Locator "+locator+" is disabled ");
					return true;
				}

			}
			catch(ElementNotInteractableException e)
			{
				targetElement = WebDriverMain._getElementWithWait(locator);
				if(targetElement.isEnabled()){
					targetElement.click();
					return true;
				}else{
					return true;
				}

			}
			catch(StaleElementReferenceException e){
				/*				WebDriverMain._pleaseWaitAndLoadingMessage();
				WebElement staleElement = WebDriverMain._getElementWithWait(locator);
				if (staleElement != null) {
					if(staleElement.isEnabled()){
						staleElement.click();
						return true;
					}else{
						Log._logInfo("Element Click: "+locator+" is disabled.");
						return true;
					}
				}else{
					Log._logWarning("Fail to click on Stale Element "+locator);
					return false;
				}*/

				for (int i = 0; i <= 6; i++) {

					try{
						com.pavue.webdriver.WebDriverMain._pleaseWaitAndLoadingMessage();
						WebElement staleElement = WebDriverMain._getElementWithWait(locator);
						if (staleElement != null) {
							if(staleElement.isEnabled()){
								CommonUtility.highlighElement(staleElement);
								staleElement.click();
								//UMReporter.log(Status.PASS, " The Locator "+locator+" is clicked ");
								return true;
							}else{
								//Log._logInfo("Element Click: "+locator+" is disabled.");
								//UMReporter.log(Status.PASS, " The Locator "+locator+" is clicked ");
								return true;
							}
						}else{
							//Log._logWarning("Fail to click on Stale Element "+locator);
							UMReporter.log(Status.FAIL, " The Locator "+locator+" is unable to click ");
							return false;
						}
					}
					catch(StaleElementReferenceException se)
					{
						CommonUtility._sleepForGivenTime(2000);
						//Log._logWarning("Fail to click on Stale Element "+locator);
						UMReporter.log(Status.FAIL, " The Locator "+locator+" is unable to click ");
						if(i==6) bflag= false;
					}
				}
			}
			catch(TimeoutException timeout){
				if(timeout.getMessage().toLowerCase().contains("waiting for page load.")){
					for(int i =1;i<=3;i++){
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						try {
							Runtime.getRuntime().exec(CommonUtility._getProjectWS()+"\\src\\global\\test\\com\\panext\\resources\\BrowserStop.exe");
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						//Log._logWarning("Page Load Occured - Stopping Browser using AutoIT - Counter: "+i);
						UMReporter.log(Status.FAIL, " Page Load Occured - Stopping Browser using AutoIT - Counter: " +i);
					}
				}else
					throw timeout;
			}
		} else {
			//Log._logWarning("Element "+locator+" could not be found to send text to.");
			UMReporter.log(Status.FAIL, "Element "+locator+" could not be found to send text to.");
			return false;
		}
		return bflag;
	}
	
	/**
     * This method is to click on given element with its locator using java
     * script
     * 
     * @param locator
	 * @throws IOException 
     */
    public static boolean clickByJS( By locator ) throws IOException {

        try {
            WebElement element = WebDriverMain._getDriver().findElement(locator);
            JavascriptExecutor js = (JavascriptExecutor) WebDriverMain._getDriver();
            js.executeScript( "arguments[0].click();", element );
            //UMReporter.log(Status.PASS, " The Locator "+locator+" is clicked ");
        } catch ( Exception e ) {
            e.printStackTrace();
            UMReporter.log(Status.ERROR, " The Locator "+locator+" is not clicked ");
            return false;
        }
        return true;
    }
    
    /**
     * This method is to click on given element with its WebElement using java
     * script
     * 
     * @param locator
     * @throws IOException 
     */
    public static void clickByWebElementJS( WebElement element ) throws IOException {

        try {            
            JavascriptExecutor js = (JavascriptExecutor) WebDriverMain._getDriver();
            js.executeScript( "arguments[0].click();", element );
            //UMReporter.log(Status.PASS, " The element "+element+" is clicked ");
        } catch ( Exception e ) {
            e.printStackTrace();
            UMReporter.log(Status.ERROR, " The element "+element+" is not clicked ");
        }
    }
	
	/**
   * Click on Element as per the specified locator. 
   *
   * @param locator
   *            The element locator to find.
   * @return boolean
	 * @throws IOException 
   * 
   * @throws IllegalArgumentException
   *             Thrown if locator/strText/driver is null.
   */
public static boolean _click(WebElement targetElement) throws IOException{
  if (targetElement != null) {
    try{
      if(targetElement.isEnabled()){
    	CommonUtility.highlighElement(targetElement);  
        targetElement.click();
        //UMReporter.log(Status.PASS, " The targetElement "+targetElement+" is clicked ");
        return true;
      }else{
        //Log._logInfo("Element Click: "+targetElement+" is disabled.");
    	  //UMReporter.log(Status.PASS, " The targetElement "+targetElement+" is not enable ");
        return true;
      }

    }
    catch(ElementNotVisibleException e)
    {
      if(targetElement.isEnabled()){
    	CommonUtility.highlighElement(targetElement);  
        targetElement.click();
        //UMReporter.log(Status.PASS, " The targetElement "+targetElement+" is clicked ");
        return true;
      }else{
        //Log._logInfo("Element Click: "+targetElement+" is disabled.");
    	  //UMReporter.log(Status.PASS, " The targetElement "+targetElement+" is not enable ");
        return true;
      }

    }
    catch(ElementNotInteractableException e)
	{
		if(targetElement.isEnabled()){
			targetElement.click();
			return true;
		}else{
			return true;
		}
	}
    catch(StaleElementReferenceException e){
    	com.pavue.webdriver.WebDriverMain._pleaseWaitAndLoadingMessage();
        if(targetElement.isEnabled()){
          CommonUtility.highlighElement(targetElement);
          targetElement.click();
          //UMReporter.log(Status.PASS, " The targetElement "+targetElement+" is clicked ");
          return true;
        }else{
          //Log._logInfo("Element Click: "+targetElement+" is disabled.");
        	//UMReporter.log(Status.PASS, " The targetElement "+targetElement+" is not enable ");
          return true;
        }
      
    }
  } else {
    //Log._logWarning("Element "+targetElement+" could not be found to send text to.");
	  UMReporter.log(Status.FAIL, " The targetElement "+targetElement+" is not clicked ");
    return false;
  }
}

}
