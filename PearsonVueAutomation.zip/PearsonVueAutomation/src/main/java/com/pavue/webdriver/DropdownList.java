/*
 *UMreporter.log method is called to capture the action in Extent Report 
 */

package com.pavue.webdriver;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.Status;

import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.LeftClick;
import com.pavue.webdriver.Log;
import com.pavue.webdriver.TextBox;
import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;

public class DropdownList{

	/**
	 * Select Drop down list using visible text in the specified locator. 
	 *
	 * @param optionLocator
	 *            The Select locator to input text.
	 * @param strOption
	 * 			  The Option value to select.
	 * @return boolean
	 * @throws IOException 
	 * 
	 * @throws IllegalArgumentException
	 *             Thrown if locator/strText/driver is null.
	 */
	public static boolean _byVisibleTextDropdownList(By optionLocator, String strOption) throws IOException{

		if (optionLocator == null) {
			throw new IllegalArgumentException(
					"The Element locator to send cannot be null.");
		}
		if (strOption == null) {
			throw new IllegalArgumentException(
					"The Option value cannot be null.");
		}

		WebElement targetElement = WebDriverMain._getElementWithWait(optionLocator);
		if (targetElement != null) {
			if(strOption.contains("&"))
				strOption = strOption.split(" ")[0];

			CommonUtility._sleepForGivenTime(4000);
			TextBox._setTextBox(optionLocator, strOption.trim());
			DropdownSearching();

			//Application specific Class Name for finding the list in drop down list. 
			List<WebElement> targetList = WebDriverMain._getElementsWithWait(By.className("select2-result-label"));
			if(!targetList.isEmpty()){
				for(WebElement element : targetList){
					if(element.getText().contains("(")){
						String[] split = element.getText().split("\\(");

						if(("("+split[1]).trim().equalsIgnoreCase("("+strOption+")") || split[0].trim().equalsIgnoreCase(strOption)){
							element.click();
							/*
							 * UMreporter.log method is called to capture the action in Extent Report 
							 */
							//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
							return true;
						}
					}else{
						if(element.getText().toLowerCase().equalsIgnoreCase(strOption.toLowerCase())){
							element.click();
							//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
							return true;
						}
					}
				}
			}else{
				//Application specific Class Name for finding the list in drop down list. 
				if(WebDriverMain._isElementPresent(By.className("select2-no-results"))){
					//Log._logWarning("Element Located but no option value found: "+strOption);
					Actions builder=new Actions(WebDriverMain._getDriver());
					builder.sendKeys(Keys.ESCAPE).build().perform();
					UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
					return false;
				}
			}
			Actions builder=new Actions(WebDriverMain._getDriver());
			builder.sendKeys(Keys.ESCAPE).build().perform();
			//Log._logWarning("Element Located but option value not found: "+strOption);
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
			return false;
		} 

		else {
			//Log._logWarning("Element not found: "+optionLocator);
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
			return false;
		}
	}

	/**
	 * Select Drop down list using partial text in the specified locator. 
	 *
	 * @param optionLocator
	 *            The Select locator to input text.
	 * @param strOption
	 * 			  The Option value to select.
	 * @return boolean
	 * @throws IOException 
	 * 
	 * @throws IllegalArgumentException
	 *             Thrown if locator/strText/driver is null.
	 */
	public static boolean _byContainsTextDropdownList(By optionLocator, String strOption) throws IOException{

		if (optionLocator == null) {
			throw new IllegalArgumentException(
					"The Element locator to send cannot be null.");
		}
		if (strOption == null) {
			throw new IllegalArgumentException(
					"The Option value cannot be null.");
		}

		WebElement targetElement = WebDriverMain._getElementWithWait(optionLocator);
		if (targetElement != null) {
			if(strOption.contains("&"))
				strOption = strOption.split(" ")[0];

			TextBox._setTextBox(optionLocator, strOption.trim());
			DropdownSearching();

			//Application specific Class Name for finding the list in drop down list. 
			List<WebElement> targetList = WebDriverMain._getElementsWithWait(By.className("select2-result-label"));
			if(!targetList.isEmpty()){
				for(WebElement element : targetList){

					if(element.getText().toLowerCase().contains(strOption.toLowerCase())){
						element.click();
						//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
						return true;
					}
				}

			}else{
				//Application specific Class Name for finding the list in drop down list. 
				if(WebDriverMain._isElementPresent(By.className("select2-no-results"))){
					//Log._logWarning("Element Located but no option value found: "+strOption);
					Actions builder=new Actions(WebDriverMain._getDriver());
					builder.sendKeys(Keys.ESCAPE).build().perform();
					UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
					return false;
				}
			}
			Actions builder=new Actions(WebDriverMain._getDriver());
			builder.sendKeys(Keys.ESCAPE).build().perform();
			//Log._logWarning("Element Located but option value not found: "+strOption);
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
			return false;
		} 

		else {
			//Log._logWarning("Element not found: "+optionLocator);
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
			return false;
		}
	}

	/**
	 * Select Drop down list using exact visible text in the specified locator. 
	 *
	 * @param locator
	 *            The Select locator to input text.
	 * @param strOption
	 * 			  The Option value to select.
	 * @return boolean
	 * @throws IOException 
	 * 
	 * @throws IllegalArgumentException
	 *             Thrown if locator/strText/driver is null.
	 */
	public static boolean _byVisibleTextDropdownListEqual(By locator, String strOption) throws IOException{

		if (locator == null) {
			throw new IllegalArgumentException(
					"The Element locator to send cannot be null.");
		}
		if (strOption == null) {
			throw new IllegalArgumentException(
					"The Option value cannot be null.");
		}
		WebElement targetElement = WebDriverMain._getElementWithWait(locator);
		if (targetElement != null) {
			if(strOption.contains("&"))
				strOption = strOption.split(" ")[0];

			TextBox._setTextBox(locator, strOption.trim());
			DropdownSearching();

			//Application specific Class Name for finding the list in drop down list. 
			List<WebElement> targetList = WebDriverMain._getElementsWithWait(By.className("select2-result-label"));
			if(!targetList.isEmpty()){
				for(WebElement element : targetList){
					if(element.getText().contains("(")){
						if(element.getText().toLowerCase().contains("("+strOption.toLowerCase()+")")){
							element.click();
							//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
							return true;
						}
					}else{
						if(element.getText().toLowerCase().equals(strOption.toLowerCase())){
							element.click();
							//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
							return true;
						}
					}
				}
			}else{
				//Application specific Class Name for finding the list in drop down list. 
				if(WebDriverMain._isElementPresent(By.className("select2-no-results"))){
					//Log._logWarning("Element Located but no option value found: "+strOption);
					Actions builder=new Actions(WebDriverMain._getDriver());
					builder.sendKeys(Keys.ESCAPE).build().perform();
					UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
					return false;
				}
			}
			Actions builder=new Actions(WebDriverMain._getDriver());
			builder.sendKeys(Keys.ESCAPE).build().perform();
			//Log._logWarning("Element Located but option value not found: "+strOption);
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
			return false;
		} else {
			//Log._logWarning("Element not found: "+locator);
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
			return false;
		}
	}

	/**
	 * Select Drop down list using exact visible text in the specified locator. 
	 *
	 * @param locator
	 *            The Select locator to input text.
	 * @param strOption
	 * 			  The Option value to select.
	 * @return boolean
	 * @throws IOException 
	 * 
	 * @throws IllegalArgumentException
	 *             Thrown if locator/strText/driver is null.
	 */
	public static boolean _byVisibleTextDropdownListEqual(WebElement targetElement, String strOption) throws IOException{

		if (targetElement == null) {
			throw new IllegalArgumentException(
					"The Element locator to send cannot be null.");
		}
		if (strOption == null) {
			throw new IllegalArgumentException(
					"The Option value cannot be null.");
		}

		if(strOption.contains("&"))
			strOption = strOption.split(" ")[0];

		TextBox._setTextBox(targetElement, strOption.trim());
		DropdownSearching();

		//Application specific Class Name for finding the list in drop down list. 
		List<WebElement> targetList = WebDriverMain._getElementsWithWait(By.className("select2-result-label"));
		if(!targetList.isEmpty()){
			for(WebElement element : targetList){
				if(element.getText().contains("(")){
					if(element.getText().toLowerCase().contains("("+strOption.toLowerCase()+")")){
						element.click();
						//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
						return true;
					}
				}else{
					if(element.getText().toLowerCase().equals(strOption.toLowerCase())){
						element.click();
						//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
						return true;
					}
				}
			}
		}else{
			//Application specific Class Name for finding the list in drop down list. 
			if(WebDriverMain._isElementPresent(By.className("select2-no-results"))){
				//Log._logWarning("Element Located but no option value found: "+strOption);
				Actions builder=new Actions(WebDriverMain._getDriver());
				builder.sendKeys(Keys.ESCAPE).build().perform();
				UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
				return false;
			}
		}
		Actions builder=new Actions(WebDriverMain._getDriver());
		builder.sendKeys(Keys.ESCAPE).build().perform();
		//Log._logWarning("Element Located but option value not found: "+strOption);
		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
		return false;
	} 


	/**
	 * Close Selected Drop down option if it is not present in Excepted Option list.
	 *	
	 * @param closeLocator
	 *            Close locator to cancel select option.
	 * @param choiceLocator
	 *            The Select locator find the list of selected options.
	 * @param strOption
	 * 			  The Option value to select.
	 * @return void
	 * @throws IOException 
	 * 
	 * @throws IllegalArgumentException
	 *             Thrown if locator/strText/driver is null.
	 */
	public static boolean _byVisibleTextWOWait(By optionLocator, String strOption) throws IOException{
		
		boolean flag = false;
		if (optionLocator == null) {
			throw new IllegalArgumentException(
					"The Element locator to send cannot be null.");
		}
		if (strOption == null) {
			throw new IllegalArgumentException(
					"The Option value cannot be null.");
		}

		WebElement targetElement = WebDriverMain._getElementWithWait(optionLocator);
		if (targetElement != null) {
			if(strOption.contains("&"))
				strOption = strOption.split(" ")[0];

			CommonUtility._sleepForGivenTime(1000);
			TextBox._setTextBox(optionLocator, strOption.trim());
			DropdownSearching();

			List<WebElement> targetList = WebDriverMain._getDriver().findElements(By.className("select2-result-label"));

			if(!targetList.isEmpty()){
				for(WebElement element : targetList){
					if(element.getText().contains("(")){
						String[] split = element.getText().split("\\(");

						if(("("+split[1]).trim().equalsIgnoreCase("("+strOption+")") || split[0].trim().equalsIgnoreCase(strOption)){
							element.click();
							flag = true;
						}
					}else{
						if(element.getText().toLowerCase().contains(strOption.toLowerCase())){
							element.click();
							flag = true;
						}
					}
				}
			}else {
				Actions builder=new Actions(WebDriverMain._getDriver());
				builder.sendKeys(Keys.ESCAPE).build().perform();
				CommonUtility._sleepForGivenTime(3000);
				//Log._logWarning("Element Located but option value not found: "+strOption);
			}		
		} 

		else 
			//Log._logWarning("Element not found: "+optionLocator);
		if(flag = true)
		{
			//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
		}
		else
		{
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
		}
		return flag;
	}

	/**
	 * Ignore already selected drop down option and return true. 
	 *	If Not present return false.
	 *
	 * @param choiceLocator
	 *            The Select locator find the list of selected options.
	 * @param optionLocator
	 *            The Select locator to input text.
	 * @param strOption
	 * 			  The Option value to select.
	 * @return boolean
	 * @throws IOException 
	 * 
	 * @throws IllegalArgumentException
	 *             Thrown if locator/strText/driver is null.
	 */
	private static boolean _byIgnoreSelectedDropdownList(By optionLocator, String strOption) throws IOException{
		if (optionLocator == null) {
			throw new IllegalArgumentException(
					"The Element locator to send cannot be null.");
		}
		if (strOption == null) {
			throw new IllegalArgumentException(
					"The Option value cannot be null.");
		}
		//Expected Option to be selected
		List<String> expOption =Arrays.asList(strOption.split(";"));

		//Actual Option present in UI
		List<WebElement> actOptionEle = WebDriverMain._getElementsWithWait(optionLocator);
		if(!actOptionEle.isEmpty()){
			for(WebElement ele : actOptionEle){
				String option=ele.getText();
				if(option.contains("(")){
					option = option.split("\\(")[1].replaceAll("\\)", "");
				}
				if(expOption.contains(option)){
					//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
					return true;
				}
			}
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
			return false;
		}else{
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
			return false;
		}
	}

	/**
	 * Close Selected Drop down option if it is not present in Excepted Option list.<br>
	 *	Ignore already selected drop down option.<br>
	 * Select Drop down list using visible text in the specified locator.
	 * @param closeLocator
	 *            Close locator to cancel select option.
	 * @param choiceLocator
	 *            The Select locator find the list of selected options.
	 * @param optionLocator
	 *            The Select locator to input text.           
	 * @param strOption
	 * 			  The Option value to select.
	 * @return void
	 * @throws IOException 
	 * 
	 * @throws IllegalArgumentException
	 *             Thrown if locator/strText/driver is null.
	 */
	public static boolean _bySelectDropdownList(By closeLocator, By optionLocator, String strOption) throws IOException{
		String status="";
		//Close Remaining option elements.
		//_byVisibleTextCloseDropdownList(closeLocator, optionLocator, strOption);

		//Check selected Option and Ignore if already present
		//Expected Option to be selected
		List<String> expOption =Arrays.asList(strOption.split(";"));
		for(String option: expOption){
			if(_byIgnoreSelectedDropdownList(optionLocator, strOption)){
				Log._logInfo("Option provided: "+option+" already Selected.");
				continue;
			}else{
				LeftClick._click(closeLocator);
				status += _byVisibleTextDropdownList(optionLocator, option);
			}
		}
		if(status.contains("false"))
		{
			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from optionLocator");
			return false;
		}
		else
		{
			//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from optionLocator");
			return true;
		}
			
	}

	/**Function Name :- DropdownSearching<br/>
	 * Description   :- wait till dropdown searching option is available.
	 * 
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean DropdownSearching() throws IOException {
		int msgTimeOut = 15;
		boolean status=true;
		//sleepForGivenTime(1000);
		int i =0;
		while(status){
			CommonUtility._sleepForGivenTime(1000);
			if(!WebDriverMain._isElementPresent(By.cssSelector("li.select2-searching")))
				status=false;
			//System.out.println("Please Wait Present waiting for sec. ");
			i++;
			if(i==msgTimeOut)
				status=false;
		}
		//sleepForGivenTime(1000);
		System.out.println("Dropdown Searching... Total sec:- "+i);	
		return true;	
	}
}
