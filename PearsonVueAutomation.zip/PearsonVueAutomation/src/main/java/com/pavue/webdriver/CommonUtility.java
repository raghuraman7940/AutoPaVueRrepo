package com.pavue.webdriver;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.io.File;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.mustache.Value;

import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.Log;
import com.pavue.webdriver.WebDriverMain;


public class CommonUtility {

	static char specialCharacters[] = { '!', '@', '#', '$', '%', '^', '&', '*',
			'(', ')', '?', '/', '"', '|', '{', '[', '<', '>', ';', '`', ',',
			'_', '-','\n' };
	
	static String specialCharacters1[] =new String[]{ "!", "@", "#", "$", "%", "^", "&", "*","(", ")", "?", "/", "\"", "|", "{", "[", "<", ">", ";", "`", ",","_", "-","\n" };
			
	static String Delimiter="\\|";
	static WebElement PrvHighelement;
	/**
	 * Format the xpath with String
	 * 
	 * @param locator
	 * @param index
	 * 
	 * @return By
	 */
	public static By _locatorFormatString(By locator, String string) {
		String xpath = String.format(locator.toString(), string);
		String newXpath = xpath.substring(xpath.indexOf('/'));
		return By.xpath(newXpath);
	}

	/* This function highlights the element being currently used on the webpage*/
	public static void highlighElement(WebElement element)
		{
			 JavascriptExecutor js = (JavascriptExecutor) WebDriverMain._getDriver();
	                 js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
	                 js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
	               //  js.executeScript("arguments[0].setAttribute('style','border:none');", element); 
		}
	
	/* This function highlights the element being currently used on the webpage*/
	public static void unhighlighElement(WebElement element)
	{
		 JavascriptExecutor js = (JavascriptExecutor) WebDriverMain._getDriver();
		 js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
	}
	
	/* This function scroll the element being currently used on the webpage*/
	public static void _scrollElement(WebElement element)
	{
		 JavascriptExecutor js = (JavascriptExecutor) WebDriverMain._getDriver();
		 js.executeScript("arguments[0].scrollIntoView(true);",element); 
		 CommonUtility._sleepForGivenTime(500);
	}
	
	
	/* This function scroll up currently used on the webpage*/
	public static void _scrollup()
	{
		 JavascriptExecutor js = (JavascriptExecutor) WebDriverMain._getDriver();
		 js.executeScript("window.scrollTo(document.body.scrollHeight,0)"); 
		 CommonUtility._sleepForGivenTime(500);
	}
	
	
	/* This function scroll down currently used on the webpage*/
	public static void _scrolldown()
	{
		 JavascriptExecutor js = (JavascriptExecutor) WebDriverMain._getDriver();
		 js.executeScript("window.scrollTo(0,document.body.scrollHeight)"); 
			CommonUtility._sleepForGivenTime(500);
	}
	/**Function Name :- LocatorFormatString<br/>
	 * Description   :- Format the xpath with two String arguments 
	 * @param locator
	 * @param str1
	 * @param str2
	 * @return
	 */
	public static By _locatorFormatString(By locator,String str1,String str2) {
		String xpath=String.format(locator.toString(),str1,str2);
		String newXpath=xpath.substring(xpath.indexOf('/'));
		return By.xpath(newXpath);
	}

	/**Function Name :- LocatorFormatString<br/>
	 * Description   :- Format the xpath with two String arguments 
	 * @param locator
	 * @param str1
	 * @param str2
	 * @return
	 */
	public static By _locatorFormatString(By locator,String str1,String str2,String str3) {
		String xpath=String.format(locator.toString(),str1,str2,str3);
		String newXpath=xpath.substring(xpath.indexOf('/'));
		return By.xpath(newXpath);
	}
	
	/**
	 * Format the xpath with integer
	 * 
	 * @param locator
	 * 
	 * @return By
	 */
	public static By _locatorFormatInt(By locator, int index) {
		String xpath = String.format(locator.toString(), "" + index);
		String newXpath = xpath.substring(xpath.indexOf('/'));
		return By.xpath(newXpath);
	}

	/**
	 * Generate random string of special characters of length x
	 * 
	 * 
	 * @return String
	 */
	public static String _getRandomSpecialString(int length) {
		int len = specialCharacters.length;
		String str = "";
		Random randomGenerator = new Random();
		int index;

		for (int i = 0; i < length; i++) {
			index = randomGenerator.nextInt(len - 1);
			str = str + specialCharacters[index];
		}
		return str;
	}

	/**
	 * Sleep for given time
	 * 
	 * @param time
	 * @return void
	 */
	public static void _sleepForGivenTime(long time) {
		try {
			long t2=400;
			
			Thread.sleep(time);
		//	Log._logInfo("Sleeping for "+time+" milliseconds");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Returns the property value from property key
	 * 
	 * @param propertyFile
	 * @param propertyKey
	 * @return String
	 */
	public static String _getProperty(String propertyFile, String propertyKey) {

		/*
		 *  * Description : This function will return the value of property key
		 * if available, otherwise returns null Arg1 : 'propertyFile' - used to
		 * identify the properties file Arg2 : 'propertyKey' - used to identify
		 * the key and the fetch the value of it.
		 */
		Properties prop = new Properties();
		String propertyValue = null;
		try {
			// Loading the properties
			/*
			 * prop.load(new FileInputStream(getProjectWS() + "/InputTestData/"
			 * + propertyFile + ".properties"));
			 */
			prop.load(new FileInputStream(propertyFile));

			// Getting the value for the properties file using key
			propertyValue = prop.getProperty(propertyKey);

			return propertyValue;
		} catch (Exception e) {
			return propertyValue;
		}

	}

	/**
	 * Provide the path of the project workspace
	 * 
	 * @return String
	 */
	public static String _getProjectWS() {
		/*
		 * Description : This function will return the project work space(
		 * canonical path) Example : For windows - c:\windows For unix flavours
		 * - /user
		 */
		String projectWS = null;
		try {
			File directory = new File(".");
			projectWS = directory.getCanonicalPath();
			return projectWS;
		} catch (IOException ioe) {
			return projectWS;
		}
	}

	/**
	 * Provides the time in any format
	 * 
	 * @param format
	 * @return String
	 */
	public static String _getTimeStamp(String format) {

		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat displayFormat = new SimpleDateFormat(format);
		SimpleDateFormat parseFormat = new SimpleDateFormat(format + " a");

		Date date = null;
		try {
			date = parseFormat.parse(parseFormat.format(currentDate.getTime()));
		} catch (ParseException ex) {
		}
		return displayFormat.format(date);
	}

	/**
	 * Returns the date in yyyy-mm-dd
	 * 
	 * @param format
	 * @return String
	 */
	public static String _getDateYYYYmmDDformat(String dateInString) {
		String strFormattedDate = null;
		SimpleDateFormat formatter;
		// Add code so that mm-dd-yyyy to be converted to MM/DD/YYY,separately
		// format each of the possibilities
		try {
			if (dateInString.contains("-")
					&& dateInString.split("-")[0].length() == 4) {
				formatter = new SimpleDateFormat("yyyy-MM-dd");
				Date date = formatter.parse(dateInString);
				formatter = new SimpleDateFormat("yyyy-MM-dd");
				strFormattedDate = formatter.format(date);
			} else if (!dateInString.contains("-")
					&& !dateInString.contains("/")) {
				// Format date from MMDDYY to MM-DD-YY
				if(dateInString.startsWith("20") || dateInString.startsWith("19"))
				{
					formatter = new SimpleDateFormat("yyyyMMdd");
					Date date = formatter.parse(dateInString);
					formatter = new SimpleDateFormat("MM/dd/yyyy");
					strFormattedDate = formatter.format(date);
				}
				else{
				formatter = new SimpleDateFormat("MMddyy");
				Date date = formatter.parse(dateInString);
				formatter = new SimpleDateFormat("MM/dd/yyyy");
				strFormattedDate = formatter.format(date);
				}
			} else {
				formatter = new SimpleDateFormat("MM/dd/yyyy");
				Date date = formatter.parse(dateInString);
				formatter = new SimpleDateFormat("yyyy-MM-dd");
				strFormattedDate = formatter.format(date);
			}

		} catch (Exception e) {
			strFormattedDate = "";
		}
		return strFormattedDate;
	}
	
	
	/**
	 * Returns desired date format to parse
	 * 
	 * @param format
	 * @return String
	 */
	public static SimpleDateFormat _getDateFormatter(String dateInString) {
		SimpleDateFormat formatter=null;
		// Add code so that mm-dd-yyyy to be converted to MM/DD/YYY,separately
		// format each of the possibilities
		try {
			
			if (dateInString.contains("-") && dateInString.split("-")[0].length() == 4) {
				formatter = new SimpleDateFormat("yyyy-MM-dd");
			} 
			
			else if (!dateInString.contains("-") && !dateInString.contains("/")) 
			{
				// Format date from MMDDYY to MM-DD-YY
				if(dateInString.startsWith("20") || dateInString.startsWith("19"))
				{
					formatter = new SimpleDateFormat("yyyyMMdd");
				}
				
				else
				{
				formatter = new SimpleDateFormat("MMddyy");
				}
			} 
			
			else {
				formatter = new SimpleDateFormat("MM/dd/yyyy");

			}

		} catch (Exception e) {
			
		}
		return formatter;
	}
	
	

	/**
	 * Returns the difference between two dates in the form of days
	 * 
	 * @param strOldDate must be in '2015-04-14 02:15 AM' format
	 * @return int
	 * @throws ParseException 
	 */
	public static Long _getDifferenceBetweenTwoDates(String strOldDate) throws ParseException {
		
		Date currentDate = new Date();  
		Date oldDate = new Date(); 
		
		//Format as 2015-04-14 02:15 AM
		DateFormat formatter1 = null;
		DateFormat formatter2 = null;
		
		if(strOldDate.contains("/"))
		{
			 formatter1 = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aaa");
			 formatter2 = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aaa");
		}
		else
		{
		 formatter1 = new SimpleDateFormat("yyyy-MM-dd hh:mm aaa");
		 formatter2 = new SimpleDateFormat("yyyy-MM-dd hh:mm aaa");
		}		
		//Convert the old date from String to Date based on above format
		oldDate=formatter1.parse(strOldDate);
		
		//Convert to iowa time zone
		formatter1.setTimeZone(TimeZone.getTimeZone("US/Central")); 
		String strtemp=formatter1.format(currentDate);
		currentDate=formatter2.parse(strtemp);
		
		//Find the difference in days between current date and olddate
		long diff = currentDate.getTime() - oldDate.getTime();
		diff=TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	    return diff;
	}
	
	/**
	 * Generate 8 digit Random number
	 * 
	 * @return int
	 */
	public static int _randomNumber() {
		return new Random().nextInt(90000000) + 10000000;
	}

	/**
	 * Generate 98 character Random number ending with 'END'
	 * 
	 * @return String
	 */
	public static String _randomNumberChar98() {
		BigInteger char98 = new BigInteger(new Integer(
				new Random().nextInt(90000000)).toString())
				.add(new BigInteger(
						"10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"));

		return char98.toString() + "END";
	}

	/**
	 * Provides the array of strings by splitting
	 * 
	 * @param arg
	 * @param strDelimiter
	 * @return String[]
	 */
	public static String[] _split(String arg, String strDelimiter) {
		String args[] = null;
		arg = arg.trim();
		if ((arg.length() != 0 || arg != null)) {
			args = arg.split(strDelimiter);
		}
		return args;
	}

	/**
	 * Get current date time with Date()
	 * 
	 * @return String
	 */
	public static String _getTime() {
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Date date = new Date();
		return dateFormat.format(date);
	}

	/**
	 * Removes a unknown character(ASCII 160) from excel
	 * 
	 * @param excel
	 * @return String
	 */
	public static String _StringUnknownChar(String excel) {

		CharSequence unknownS = "" + (char) 160;
		char unknownC = (char) 160;
		if (excel.contains(unknownS)) {
			excel = excel.replace(unknownC, ' ');
		}
		return excel;
	}

	/**
	 * Return the string by stripping its special characters
	 * 
	 * @param strText
	 * @return String
	 */
	public static String _textWithoutSpecialCharacters(String strText) {
		for (String sc1 : specialCharacters1) {
			strText = strText.replace(sc1, "");
		}
		return strText;
	}

	/**_compareStringIgnoringSpecialCharacters
	 * 
	 * @param str1
	 * @param str2
	 * @return boolean
	 */
	public static boolean _compareStringIgnoringSpecialCharacters(String str1,String str2)
	{
		str1= _textWithoutSpecialCharacters(_StringUnknownChar(str1).trim().replaceAll(" ", ""));
		str2= _textWithoutSpecialCharacters(_StringUnknownChar(str2).trim().replaceAll(" ", ""));
		if(str1.equalsIgnoreCase(str2))
			return true ; else return false;
		
	}

	/**
	 * Func_EncryptDecrypt<br/>
	 * Returns encrypted/decrypted string using ROT-13 algo
	 * 
	 * @param strData
	 * @return String
	 */
	public static String _encryptDecrypt(String strData) {
		// ROT-13 encryption algorithm
		String encodedText = "";
		int textLength = strData.length();

		for (int i = 0; i < textLength; i++) {
			char currentChar = strData.charAt(i);
			if ((currentChar >= 65 && currentChar <= 77)
					|| (currentChar >= 97 && currentChar <= 109)) {
				encodedText += (char) (currentChar + 13);
			} else if ((currentChar >= 78 && currentChar <= 90)
					|| (currentChar >= 110 && currentChar <= 122)) {
				encodedText += (char) (currentChar - 13);
			} else {
				encodedText += currentChar;
			}
		}
		return encodedText;
	}

	/**
	 * Returns digit present in the String
	 * 
	 * @param arg
	 * @return String
	 */
	public static String _getNumberFromString(String args) {
		args = args.replaceAll("\\D+", "");
		return args;
	}

	/**
	 * Returns string with specified starting and ending string
	 * 
	 * @param strActualString
	 * @param strStartString
	 * @param strEndString
	 * @return
	 */
	public static String _getStringUsingStartEndStrings(String strActualString,
			String strStartString, String strEndString) {
		if (strActualString.contains(strStartString)
				&& strActualString.contains(strEndString)) {
			int startIndex = strActualString.indexOf(strStartString);
			int endIndex = strActualString.indexOf(strEndString);
			return strActualString.substring(startIndex+1, endIndex-1
					+ strEndString.length());
		} else
			return "";
	}
	
	/**
	 * Function Name :- isNumeric<br>
	 * Description :- Provided string is numeric.
	 * @param strNum
	 * @return boolean
	 */
	public static boolean isNumeric(String strNum) {
	    try {
	        double d = Double.parseDouble(strNum);
	    } catch (NumberFormatException | NullPointerException nfe) {
	        return false;
	    }
	    return true;
	}

	/**
	 *Converts the String to By locator 
	 * @param strLocator
	 * @return By
	 */
	public static By _getObjectLocator(String strLocator) {
	
		By by = null;
		if(strLocator.toLowerCase().startsWith("css")){
			strLocator = strLocator.replace("css=", "");
			by = By.cssSelector(strLocator);
			//by = By.cssSelector("#s2id_orgFilters input");
		}else if(strLocator.toLowerCase().startsWith("name")){
			strLocator = strLocator.replace("name=", "");
			by = By.name(strLocator);
		}else if(strLocator.toLowerCase().startsWith("xpath")){
			strLocator = strLocator.replace("xpath=", "");
			by = By.xpath(strLocator);
		}else if(strLocator.toLowerCase().startsWith("id")){
			strLocator = strLocator.replace("id=", "");
			by = By.id(strLocator);
		}else if(strLocator.toLowerCase().startsWith("linktext")){
			strLocator = strLocator.replace("id=", "");
			by = By.linkText(strLocator);
		}
		else if(!strLocator.contains("=")){
			by=By.name(strLocator);
		}
		return by;
	}
	
	
	/**
	 *Converts the String to By locator 
	 * @param strLocator
	 * @return By
	 */
	public static By _getByLocator(String byStrgylocValue) {
        By by = null;
        if (byStrgylocValue.contains("|"))
        {
        	
	        String temp[]=byStrgylocValue.split(Delimiter);
	        String byStrategy=temp[0];
	        String locatorValue=temp[1];
	        switch (byStrategy.toUpperCase()) {
		        case "ID":
		            by = By.id(locatorValue);
		            break;
		        case "NAME":
		            by = By.name(locatorValue);
		            break;
		        case "CLASS":
		            by = By.className(locatorValue);
		            break;
		        case "LINKTEXT":
		            by = By.linkText(locatorValue);
		            break;
		        case "XPATH":
		            by = By.xpath(locatorValue);
		            break;
		        case "CSS":
		            by = By.cssSelector(locatorValue);
		            break;
		        case "TAGNAME":
		            by = By.tagName(locatorValue);
		            break;
	        }
        }
        return by;
    }


	/**Function Name :- testCaseRunReport<br/>
	 * Description   :- Provides the test case name in the TestNG Report
	 * @param arg
	 * @return void
	 */
	public static void _testCaseRunReport(String arg) {
		Reporter.log("<h3 style=color:#0000CD>**********Test Case:- " + arg+"**********</h3>");
	}

	/**Function Name :- functionNameReportStart<br/>
	 * Description   :- Provides the started function name in the TestNG Report
	 * @param arg
	 * @return void
	 */
	public static void _functionNameReportStart(String arg) {
		Reporter.log("<h3 align='left' style=color:#2E8B57>*****Function-			"+arg + ":- Start*****</h3>");
	}

	/**Function Name :- functionNameReportFinish<br/>
	 * Description   :- Provides the finished function name in the TestNG Report
	 * @param arg
	 * @return void
	 */
	public static void _functionNameReportFinish(String arg) {
		Reporter.log("<h3 align='left' style=color:#2E8B57>*****Function-			"+arg + ":- Finish*****</h3>");
	}

	/**Function Name :- SubfunctionNameReportStart<br/>
	 * Description   :- Provides the started sub function name in the TestNG Report
	 * @param arg
	 * @return void
	 */
	public static void _SubfunctionNameReportStart(String arg) {
		Reporter.log("<h4 align='left' style=color:#CC99FF>*****Function-			"+arg + ":- Start*****</h4>");
	}

	/**Function Name :- SubfunctionNameReportFinish<br/>
	 * Description   :- Provides the finished sub function name in the TestNG Report
	 * @param arg
	 * @return void
	 */
	public static void _SubfunctionNameReportFinish(String arg) {
		Reporter.log("<h4 align='left' style=color:#CC99FF>*****Function-			"+arg + ":- Finish*****</h4>");
	}

	/**Function Name :- _getFileNamesFromZip<br/>
	 * Description   :- Return a list of file names present in the provided zip path and deletes the zip if needed
	 * @param filePath
	 * @param boolDeleteAfter
	 * @return
	 * @throws IOException
	 */
	public static List<String> _getFileNamesFromZip(String filePath,boolean boolDeleteAfter) throws IOException{
		List<String> fileNamesInZip=new ArrayList<String>();
		FileInputStream fis = null;
		ZipInputStream zipIs = null;
		ZipEntry zEntry = null;
		fis = new FileInputStream(filePath);
		zipIs = new ZipInputStream(new BufferedInputStream(fis));
		while((zEntry = zipIs.getNextEntry()) != null)
			fileNamesInZip.add(zEntry.getName());
		
		Log._logInfo("File names extracted from the zip file("+filePath+") are:-<br/>"+fileNamesInZip);
		zipIs.close();
		if(boolDeleteAfter) new File(filePath).delete();
		return fileNamesInZip;
	}

}
