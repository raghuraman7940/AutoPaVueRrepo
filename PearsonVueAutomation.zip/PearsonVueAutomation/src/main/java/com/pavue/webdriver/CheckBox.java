package com.pavue.webdriver;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import com.pavue.webdriver.LeftClick;
import com.pavue.webdriver.Log;
import com.pavue.webdriver.WebDriverMain;

public class CheckBox{

	/**
     * Check selected locator if specified string value is YES or TRUE.
     *
     * @param locator
     *            The element locator to find.
     * @param YesORNo
     *            The element locator to find.           
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _check(By locator, String YesORNo) throws IOException{
		
		try {
			if(YesORNo.equalsIgnoreCase("Yes") || YesORNo.equalsIgnoreCase("True")){
				WebElement targetElement = WebDriverMain._getElementWithWait(locator);
				if(targetElement != null){
					if(targetElement.isEnabled()){
						if(!targetElement.isSelected()){
							if(LeftClick.clickByJS(locator))
								return true;
							else
								return false;
						}else{
							return true;
						}
					}else{
						//Log._logInfo("Element Checkbox: "+locator+" is disabled.");
			            return true;
					}
				}else{
					//Log._logWarning("Element Checkbox: "+locator+" could not be found.");
			        return false;
				}
				
			}else{
				WebElement targetElement = WebDriverMain._getElementWithWait(locator);
				if(targetElement != null){
					if(targetElement.isEnabled()){
						if(targetElement.isSelected()){
							if(LeftClick.clickByJS(locator))
								return true;
							else
								return false;
						}else{
							return true;
						}
					}else{
						Log._logInfo("Element Checkbox: "+locator+" is disabled.");
			            return true;
					}
				}else{
					Log._logWarning("Element Checkbox: "+locator+" could not be found.");
			        return false;
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	/**
     * Check selected locator if specified string value is YES or TRUE.
	 * 
	 * @param targetElement
	 * @param YesORNo
	 * @return
	 * @throws IOException 
	 */
	public static boolean _check(WebElement targetElement, String YesORNo) throws IOException{
		if(YesORNo.equalsIgnoreCase("Yes") || YesORNo.equalsIgnoreCase("True")){
			if(targetElement != null){
				if(targetElement.isEnabled()){
					if(!targetElement.isSelected()){
						if(LeftClick._click(targetElement))
							return true;
						else
							return false;
					}else{
						return true;
					}
				}else{
					Log._logInfo("Element Checkbox: "+targetElement+" is disabled.");
		            return true;
				}
			}else{
				Log._logWarning("Element Checkbox: "+targetElement+" could not be found.");
	            return false;
			}
			
		}else{
			if(targetElement != null){
				if(targetElement.isEnabled()){
					if(targetElement.isSelected()){
						if(LeftClick._click(targetElement))
							return true;
						else
							return false;
					}else{
						return true;
					}
				}else{
					Log._logInfo("Element Checkbox: "+targetElement+" is disabled.");
		            return true;
				}
			}else{
				Log._logWarning("Element Checkbox: "+targetElement+" could not be found.");
	            return false;
			}
			
		}
	}
}
