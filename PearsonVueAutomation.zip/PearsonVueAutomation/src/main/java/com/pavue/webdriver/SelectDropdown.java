package com.pavue.webdriver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;

//import organizations.ManageOrganizationsObjects.ManageOrganizationsPageObjects;


public class SelectDropdown {
	
	/**
     * Select Drop down using visible text in the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @param strOption
     * 			  The Option value to select.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _selectByVisibleText(By locator, String strOption) throws IOException{
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        if (strOption == null) {
            throw new IllegalArgumentException(
                    "The Option value cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	if(targetElement.isEnabled()){
        		Select dropDownSelector = new Select(targetElement);
            	try{
            		dropDownSelector.selectByVisibleText(strOption);
            		//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +locator);
            		return true;
            	}catch(NoSuchElementException e){
            		//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
            		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +locator);
            		return false;
            	}
			}else{
				//Log._logInfo("Element Select locator: "+locator+" is disabled.");
				//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +locator);
	            return true;
			}
        } else {
        	//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
        	UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +locator);
            return false;
        }
	}
	
	/**
     * Select Drop down using text which matches with one of the existing options
     *
     * @param locator
     *            The Select locator to find.
     * @param strOption
     * 			  The Option value to select.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _selectByContainsText(By locator, String strOption) throws IOException{
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        if (strOption == null) {
            throw new IllegalArgumentException(
                    "The Option value cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	if(targetElement.isEnabled()){
        		Select dropDownSelector = new Select(targetElement);
            	try{
            		
            		for(WebElement ele: dropDownSelector.getOptions())
            		{
            			if(!ele.getText().equals("") && ele.getText().contains(strOption))
            			{
            				strOption=ele.getText();
            				break;
            			}
            		}
            		dropDownSelector.selectByVisibleText(strOption);
            		//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +locator);
            		return true;
            	}catch(NoSuchElementException e){
            		//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
            		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +locator);
            		return false;
            	}
			}else{
				//Log._logInfo("Element Select locator: "+locator+" is disabled.");
				//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +locator);
	            return true;
			}
        } else {
        	//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
        	UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +locator);
            return false;
        }
	}
	/**
     * Select Drop down using value in the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @param strOption
     * 			  The Option value to select.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _selectByValue(By locator, String strOption) throws IOException{
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        if (strOption == null) {
            throw new IllegalArgumentException(
                    "The Option value cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	if(targetElement.isEnabled()){
        		Select dropDownSelector = new Select(targetElement);
            	try{
            		dropDownSelector.selectByValue(strOption);
            		//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +locator);
            		return true;
            	}catch(NoSuchElementException e){
            		//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
            		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +locator);
            		return false;
            	}
			}else{
				//Log._logInfo("Element Select locator: "+locator+" is disabled.");
				//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +locator);
	            return true;
			}
        } else {
        	//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
        	UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +locator);
            return false;
        }
	}
	
	/**
     * get visible text drop down using the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @return String
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static String _getSelectedVisibleText(By locator) throws IOException{
		String ret = null;
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	Select dropDownSelector = new Select(targetElement);
        	try{
        		ret = dropDownSelector.getFirstSelectedOption().getText();
        	}catch(NoSuchElementException e){
        		//Log._logWarning("No options are selected.");
        		UMReporter.log(Status.FAIL, "Unable to get the selected visible text");
        	}
        }else {
        	//Log._logWarning("Failed to find Dropdown Option value :-"+locator);
        	UMReporter.log(Status.FAIL, "Unable to get the selected visible text");
        }
        return ret;
	}

	/**
	 * Returns a list containing options available in the dropdown
	 * 
	 * @param by
	 * @return List<String>
	 * @throws IOException 
	 */
	public static List<String> _getDropDownOptions(By locator) throws IOException
	{
		//Get the Dropdown as a Select using its name attribute
		Select make = new Select(WebDriverMain._getElementWithWait(locator));

		List<String> act_options = new ArrayList<String>();

		//Retrieve the option values from Dropdown using getOptions() method
		for(WebElement option : make.getOptions())
			act_options.add(option.getText());
		return act_options;
	}
	
	
	public static String _dropdownSearchByValue(By locator, String Value) throws IOException
	{
		String ret = null;
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	
        	try{
        		Actions DropdownSearch = new Actions(WebDriverMain._getDriver()).moveToElement(targetElement).sendKeys(Value);
        		DropdownSearch.build().perform();
        	}catch(NoSuchElementException e){
        		//Log._logWarning("No options are selected.");
        		UMReporter.log(Status.FAIL, "No options are selected.");
        	}
        }else {
        	//Log._logWarning("Failed to find Dropdown Option value :-"+locator);
        	UMReporter.log(Status.FAIL, "No options are selected.");
        }
       return ret;
		
	}
}
