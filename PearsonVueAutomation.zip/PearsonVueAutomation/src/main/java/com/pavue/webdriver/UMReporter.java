/*
 * 
 * 
 */

package com.pavue.webdriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
//import com.aventstack.extentreports.MediaEntityBuilder;
//import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentXReporter;

import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;
public class UMReporter {
	
	private static ExtentReports extentD = new ExtentReports();
	private static ExtentReports extentDwss = new ExtentReports();
	private static ExtentReports extentM  = new ExtentReports();
	private static ExtentReports extentMwss = new ExtentReports();

	public static String reportPath;
	public static ThreadLocal<ExtentTest> test = new ThreadLocal<ExtentTest>();
	public static ThreadLocal<ExtentTest> testWss = new ThreadLocal<ExtentTest>();
	public static ThreadLocal<Boolean> isPassed = new ThreadLocal<Boolean>();

	public static ExtentXReporter extentxReporter ;
	static HashMap<Object, Object> parentList = new HashMap<>();
	static HashMap<Object, Object> parentListWSS = new HashMap<>();

	public static int passCountD = 0;
	public static int failCountD = 0;
	public static int passCountM = 0;
	public static int failCountM = 0;
	public static int passCount = 0;
	public static int FailCount = 0;
	public static String env ;
	public static Map<String,UMReporter> classReportMap = new HashMap<String,UMReporter>();
	public static Map<String,Map<String,Map<String, ArrayList<Map<String,Boolean>>>>> mailOverview = new HashMap<String,Map<String,Map<String, ArrayList<Map<String,Boolean>>>>>();

	public static void initReport(String suiteName,String projectName) {

	try {
			String path = "./custom_report/";
			String fileName = new SimpleDateFormat("yyyyMMddhhmm").format(new Date());
//		String history_Prerequisite = ConfigProp.getPropertyValue("History_Prerequisite");
			File reportConfig= new File("./reportConfig.xml");
			/*if(history_Prerequisite.equalsIgnoreCase("Yes")){
				reportConfig = new File("./report_config_with_history.xml");
			}else{
				reportConfig = new File("./reportConfig.xml");
			}*/
			String reportName = "Report_" + fileName;
			new File(path + reportName).mkdirs();
			reportPath = path + "Report_" + fileName;
			System.out.println("The report path is ------ "+reportPath);		
			//System.out.println("Into Init Report");
			String css = ".categoryOS,.categoryBrowser,.categoryheightwidth,.categoryEnvironment { background-color: #537851; border-radius: 3px;  color: #fff; font-size: 12px; margin-right: 3px; padding: 2px 4px; font-family: Roboto, Nunito, 'Source Sans Pro', Arial; font-weight: 400; line-height: 1.5;}";
			boolean historyReport = false;
			if(historyReport){
				/*System.out.println("MongoDB Server ---- "+ConfigProp.getPropertyValue("MongoDBServer"));
				System.out.println("Report name -- "+projectName);
				extentxReporter = new ExtentXReporter(ConfigProp.getPropertyValue("MongoDBServer"), 27017);
				extentxReporter.config().setProjectName(projectName);
				extentxReporter.config().setServerUrl(ConfigProp.getPropertyValue("ReportServerURL"));
				extentxReporter.config().setReportName(reportName);*/
			}		

			if (suiteName.equalsIgnoreCase("Desktop")) {
				ExtentHtmlReporter htmlReporterD = new ExtentHtmlReporter(reportPath + "/UM_Execution_Result_Desktop.htm");
				ExtentHtmlReporter htmlReporterDWSS = new ExtentHtmlReporter(reportPath + "/UM_Execution_Resultwss_Desktop.htm");
				htmlReporterD.loadXMLConfig(reportConfig);
				htmlReporterDWSS.loadXMLConfig(reportConfig);
				htmlReporterD.config().setCSS(css);
				htmlReporterDWSS.config().setCSS(css);
				htmlReporterD.config().setReportName(projectName);
				htmlReporterDWSS.config().setReportName(projectName);
				extentD.attachReporter(htmlReporterD);
				if(historyReport)
					extentDwss.attachReporter(htmlReporterDWSS,extentxReporter);
				else
					extentDwss.attachReporter(htmlReporterDWSS);

			}
			if (!suiteName.equalsIgnoreCase("Desktop")) {
				ExtentHtmlReporter htmlReporterM = new ExtentHtmlReporter(reportPath + "/UM_Execution_Result_Mobile.htm");
				ExtentHtmlReporter htmlReporterMWSS = new ExtentHtmlReporter(reportPath + "/UM_Execution_Resultwss_Mobile.htm");
				htmlReporterM.loadXMLConfig(reportConfig);
				htmlReporterMWSS.loadXMLConfig(reportConfig);
				htmlReporterM.config().setCSS(css);
				htmlReporterMWSS.config().setCSS(css);
				htmlReporterM.config().setReportName("PAUIR Report");
				htmlReporterMWSS.config().setReportName("PAUIR Report");
				extentM.attachReporter(htmlReporterM);
				if(historyReport)
					extentMwss.attachReporter(htmlReporterMWSS,extentxReporter);
				else
					extentMwss.attachReporter(htmlReporterMWSS);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public UMReporter(String testName, String description, String suiteName) {
		try {
			initParent(testName, description, suiteName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}


	public static void log(Status logStatus, String stepName) throws IOException {
		try {
			test.get().log(logStatus, stepName);
			String path = "";
			switch (logStatus) {
			case PASS:
				String SSValue = "No";
				if(SSValue.equalsIgnoreCase("YES")){
					path = WebDriverMain.captureScreen();
					testWss.get().log(logStatus, stepName + testWss.get().addScreenCaptureFromPath(path));
				}else{
					testWss.get().log(logStatus, stepName);
				}
				break;
			case FAIL:
				path = WebDriverMain.captureScreen();
				//testWss.get().log(logStatus, stepName + testWss.get().addScreenCaptureFromPath(path));
				testWss.get().log(logStatus, stepName , MediaEntityBuilder.createScreenCaptureFromPath(path).build());
				//testWss.get().log(logStatus, stepName);
				isPassed.set(false);
				break;
			case INFO:
			case SKIP:
			case WARNING:
				testWss.get().log(logStatus, stepName);
				break;
			case ERROR:
			case FATAL:
				path = WebDriverMain.captureScreen();
				//testWss.get().log(logStatus, stepName + testWss.get().addScreenCaptureFromPath(path));
				testWss.get().log(logStatus, stepName , MediaEntityBuilder.createScreenCaptureFromPath(path).build());
				//testWss.get().log(logStatus, stepName);
				isPassed.set(false);
				System.out.println(isPassed.get());
				break;
			default:			
				break;
			}
			//System.out.println(isPassed.get());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void initParent(String testName, String description, String suiteName) {
		try {
			if ("Desktop".equalsIgnoreCase(suiteName)) {
				if(parentList.get(testName) == null){
					ExtentTest testParent = extentD.createTest(testName, description);
					parentList.put(testName, testParent);
				}
				if(parentListWSS.get(testName) == null){
					ExtentTest testParentWss = extentDwss.createTest(testName, description);
					parentListWSS.put(testName, testParentWss);
				}
			} else {
				if(parentList.get(testName) == null){
					ExtentTest testParent = extentM.createTest(testName, description);
					parentList.put(testName, testParent);
					System.out.println("parent list --- "+testName );
				}
				if(parentListWSS.get(testName) == null){
					ExtentTest testParentWss = extentMwss.createTest(testName, description);
					parentListWSS.put(testName, testParentWss);
					System.out.println("parent listWSS --- "+testName );
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void initTest(String className,String testName,String suiteName, String browsertype, String RunEnvironment,String OSType,String Description) {
		try {
			//System.out.println("Code Enters InitTest");
			String browser = browsertype;
			String os = OSType;
			String environment = RunEnvironment;
			env= environment;
			String description = Description;
			String hw = null;
			if ("Desktop".equalsIgnoreCase(suiteName)) {           
				{
					testName = testName + 
							" <span class='categoryOS'>" + os + "</span>"+
							" <span class='categoryBrowser '>"+ browser + "</span>"+
							" <span class='categoryEnvironment '>"+ environment + "</span>";
				}	
			}
			isPassed.set(true);
			ExtentTest parent = (ExtentTest) parentList.get(className);
			//System.out.println("testName : "+testName+" description : "+description);
			test.set(parent.createNode(testName,description));
			ExtentTest parentWSS = (ExtentTest) parentListWSS.get(className);
			testWss.set(parentWSS.createNode(testName,description));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

	}

	public static void assignCatogory(String Catogory) {
		try {
			test.get().assignCategory(Catogory);
			testWss.get().assignCategory(Catogory);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void endReport(String suiteName) {
		try {
			if ("Desktop".equalsIgnoreCase(suiteName)) {
				extentD.flush();
				extentDwss.flush();
			} else {
				extentM.flush();
				extentMwss.flush();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void appendParent() {
		try {
			if("Desktop".equalsIgnoreCase("Desktop")){
				if(isPassed.get()){
					passCountD = passCountD + 1;
				}else{
					failCountD = failCountD + 1;
				}	
			}else{
				if(isPassed.get()){
					passCountM = passCountM + 1;
				}else{
					failCountM = failCountM + 1;
				}	}
			test.remove();
			testWss.remove();
			isPassed.remove();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void addMailContents(String className,String methodName,String desc,String browser){
		try {
			Map<String,Map<String, ArrayList<Map<String,Boolean>>>> methods = new HashMap<String,Map<String, ArrayList<Map<String,Boolean>>>>();
			Map<String, ArrayList<Map<String,Boolean>>> descr = new HashMap<String, ArrayList<Map<String,Boolean>>>();
			ArrayList<Map<String,Boolean>> bAndS = new ArrayList<Map<String,Boolean>>();
			Map<String,Boolean> list = new HashMap<String,Boolean>();		
			methods = mailOverview.computeIfAbsent(className, cl -> new HashMap<String,Map<String, ArrayList<Map<String,Boolean>>>>());
			descr = methods.computeIfAbsent(methodName, mn -> new HashMap<String, ArrayList<Map<String,Boolean>>>());
			bAndS = descr.computeIfAbsent(desc, de-> new ArrayList<Map<String,Boolean>>());
			list.put(browser, isPassed.get());
			bAndS.add(list);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}
	public static void GenerateXtendReport() {
		try {
			String destpath = "./custom_report/LatestReport";
			File destDir = new File(destpath);
			if (destDir.exists()) 
				//deleteDir(destDir);
				System.out.println("Generated Report : "+destpath );
			else
				destDir.mkdirs();
			
			File srcDir = new File(reportPath);
			FileUtils.copyDirectory(srcDir, destDir);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void CleanReportFolder() {
		try {
			String destpath = "./custom_report/LatestReport";
			File destDir = new File(destpath);
			if ((destDir.exists())&&(destDir.canWrite())) {
				deleteDir(destDir);
				System.out.println("Latest Report Folder ------ "+destpath );
			}
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void deleteDir(File file) {
		try {
		    String[]entries = file.list();
		    for(String s: entries){
		        File currentFile = new File(file.getPath(),s);
		        currentFile.delete();
		    }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static String getReportPath() {
		String repPth=reportPath;
		return repPth;
	}
	
	

}
