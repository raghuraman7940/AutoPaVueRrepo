package com.pavue.webdriver;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestContext;
import org.testng.Reporter;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import com.pavue.webdriver.ExtentManager;


public class ExtentManager {

    public static ITestContext context;
    static Map<Integer, ExtentTest> extentTestMap = new HashMap<Integer, ExtentTest>();
    public static ExtentReports extent = ExtentManager.getInstance();
    
    
    public synchronized static ExtentReports getInstance() {
        if (extent == null) {
           /* File outputDirectory = new File(context.getOutputDirectory());
            File resultDirectory = new File(outputDirectory.getParentFile(), "html");
            extent = new ExtentReports(resultDirectory + File.separator +  "Report.html", true);
            Reporter.log("Extent Report directory: " + resultDirectory, true);
            */
            extent= new ExtentReports(System.getProperty("user.dir")+"/test-output/AdvancedReport.html",true);
    		extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
    	
        
        
        }

        return extent;
    }
    
    
 

    public static synchronized ExtentTest getTest() {
        return extentTestMap.get((int) (long) (Thread.currentThread().getId()));
    }

    public static synchronized void endTest() {
        extent.endTest(extentTestMap.get((int) (long) (Thread.currentThread().getId())));
    }

    public static synchronized ExtentTest startTest(String testName) {
        return startTest(testName, "");
    }

    public static synchronized ExtentTest startTest(String testName, String desc) {
        ExtentTest test = extent.startTest(testName, desc);
        extentTestMap.put((int) (long) (Thread.currentThread().getId()), test);

        return test;
    }

    public static void setOutputDirectory(ITestContext context) {
        ExtentManager.context = context;
    }
}
