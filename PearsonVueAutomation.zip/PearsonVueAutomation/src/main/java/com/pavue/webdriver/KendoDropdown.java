package com.pavue.webdriver;



import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;


public class KendoDropdown {
	
	
	/**
     * Select Drop down using value in the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @param strOption
     * 			  The Option value to select.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _selectByValue(By locator,By optionLocator, String strOption) throws IOException{
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        if (strOption == null) {
            throw new IllegalArgumentException(
                    "The Option value cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	if(targetElement.isEnabled()){
            	try{
            		
            		targetElement.click();
            		CommonUtility._sleepForGivenTime(500);
            		List<WebElement> targetList = WebDriverMain._getElementsWithWait(optionLocator);
            		
            		if(!targetList.isEmpty()){
	            		for (WebElement ele: targetList){ 
	            			String EleText=ele.getText().toLowerCase();
							  if(!EleText.equals("") && EleText.contains(strOption.toLowerCase())&&EleText.startsWith(strOption.toLowerCase())){
		            				strOption=EleText;
		            				ele.click();
		            				//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +optionLocator);
		            				return true;
		            			}
						  }
	            		targetElement.click();
	            		//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
	            		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
	            		return false;
            		}
            		else
            		{
            			//Log._logWarning("Element Located but no option value found: "+strOption);
            			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
            			return false;
            		}
            	}catch(NoSuchElementException e){
            		//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
            		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
            		return false;
            	}
			}else{
				//Log._logInfo("Element Select locator: "+locator+" is disabled.");
				UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
	            return true;
			}
        } else {
        	//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
        	UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
            return false;
        }	 	 
	}
	
	
	/**
     * Select Drop down using value in the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @param strOption
     * 			  The Option value to select.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _selectByValue(By locator,By optionLocator, List<String> Multidata) throws IOException{
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        if (Multidata == null) {
            throw new IllegalArgumentException(
                    "The Option value cannot be null.");
        }
        List<String> retlist= null;
        boolean selectedflag;
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	if(targetElement.isEnabled()){
            	try{
            		retlist= new ArrayList<>();
            		 //Select multi value
  				  for (String strOption: Multidata){
  					if(targetElement.isEnabled()){
	            		targetElement.click();
	            		selectedflag=false;
	            		List<WebElement> targetList = WebDriverMain._getElementsWithWait(optionLocator);
	            		if(!targetList.isEmpty()){
		            		for (WebElement ele: targetList){ 
		            			String EleText=ele.getText().toLowerCase();
		            			  if(!EleText.equals("") && EleText.contains(strOption.toLowerCase())&&EleText.startsWith(strOption.toLowerCase())){
			            				strOption=ele.getText();
			            				retlist.add(strOption);
			            				ele.click();
			            				selectedflag=true;
			            				break;
			            			}
							  }
		            		if (!selectedflag)
		            			targetElement.click();
	            		}
	            		else
	            		{
	            			//Log._logWarning("Element Located but no option value found: "+strOption);
	            			UMReporter.log(Status.FAIL, "The value  is not selected from " +optionLocator);
	            			return false;
	            		}
  					}
            		
  				  }
  				//UMReporter.log(Status.PASS, "The value  is not selected from " +optionLocator);
  				return true;
            	}catch(NoSuchElementException e){
            		//Log._logWarning("Fail to find Dropdown Option value "+Multidata+".");
            		UMReporter.log(Status.FAIL, "The value  is not selected from " +optionLocator);
            		return false;
            	}
			}else{
				//Log._logInfo("Element Select locator: "+locator+" is disabled.");
				//UMReporter.log(Status.PASS, "The value is selected from " +optionLocator);
	            return true;
			}
        } else {
        	//Log._logWarning("Fail to find Dropdown Option value "+Multidata+".");
        	UMReporter.log(Status.FAIL, "The value  is not selected from " +optionLocator);
            return false;
        }	 	 
	}
	

	/**
     * Select Drop down using value in the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @param strOption
     * 			  The Option value to select.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _selectByIndex(By locator,By optionLocator, int index) throws IOException{
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        if (index <= 0) {
            throw new IllegalArgumentException(
                    "The Option value cannot be null.");
        }
        String strOption="";
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	if(targetElement.isEnabled()){
            	try{
            		targetElement.click();
            		List<WebElement> targetList = WebDriverMain._getElementsWithWait(optionLocator);
            		if(!targetList.isEmpty()){
            			int counter=1;
	            		for (WebElement ele: targetList){ 
	            			if (index==counter)
	            			{
	            				strOption=ele.getText();
	            				ele.click();
	            				//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +optionLocator);
	            				return true;
	            			}
							  
						  }
	            		targetElement.click();
	            		//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
	            		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
	            		return false;
            		}
            		else
            		{
            			//Log._logWarning("Element Located but no option value found: "+strOption);
            			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
            			return false;
            		}
            	}catch(NoSuchElementException e){
            		//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
            		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
            		return false;
            	}
			}else{
				//Log._logInfo("Element Select locator: "+locator+" is disabled.");
				//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +optionLocator);
	            return true;
			}
        } else {
        	//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
        	UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
            return false;
        }	 	 
	}
	
	/**
     * Select Drop down using value in the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @param strOption
     * 			  The Option value to select.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _selectByValue(By locator,By optionLocator,By AutoInputLocator, String strOption) throws IOException{
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        if (strOption == null) {
            throw new IllegalArgumentException(
                    "The Option value cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	if(targetElement.isEnabled()){
            	try{
            		targetElement.click();
            		CommonUtility._sleepForGivenTime(500);
            		WebElement AutoInputElement = WebDriverMain._getElementWithWait(AutoInputLocator);
	            	if (AutoInputElement != null) {
            			if (AutoInputElement.getTagName().equalsIgnoreCase("input")) {
            				AutoInputElement.sendKeys(strOption);
            				CommonUtility._sleepForGivenTime(4000);
            			}
            		}
            		List<WebElement> targetList = WebDriverMain._getElementsWithWait(optionLocator);
            		if(!targetList.isEmpty()){
	            		for (WebElement ele: targetList){ 
	            			String EleText=ele.getText().toLowerCase();
	            			  if(!EleText.equals("") && EleText.contains(strOption.toLowerCase())&&EleText.startsWith(strOption.toLowerCase())){
		            				strOption=ele.getText();
		            				ele.click();
		            				//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +optionLocator);
		            				return true;
		            			}
						  }
	            		targetElement.click();
	            		//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
	            		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
	            		return false;
            		}
            		else
            		{
            			//Log._logWarning("Element Located but no option value found: "+strOption);
            			UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
            			return false;
            		}
	            	
            	}catch(NoSuchElementException e){
            		//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
            		UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
            		return false;
            	}
			}else{
				//Log._logInfo("Element Select locator: "+locator+" is disabled.");
				//UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +optionLocator);
	            return true;
			}
        } else {
        	//Log._logWarning("Fail to find Dropdown Option value "+strOption+".");
        	UMReporter.log(Status.FAIL, "The value "+strOption+" is not selected from " +optionLocator);
            return false;
        }	
        //UMReporter.log(Status.PASS, "The value "+strOption+" is selected from " +optionLocator);
       // return true;
	}
	/**
     * get visible text drop down using the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @return String
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static String _getSelectedVisibleText(By locator) throws IOException{
		String ret = null;
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	try{
        		ret = targetElement.getText();
        	}catch(NoSuchElementException e){
        		//Log._logWarning("No options are selected.");
        		UMReporter.log(Status.FAIL, "Selected value is unable to retrive");
        	}
        }else {
        	//Log._logWarning("Failed to find Dropdown Option value :-"+locator);
        	UMReporter.log(Status.FAIL, "Selected value is unable to retrive");
        }
        return ret;
	}
	
	/**
     * get visible text drop down using the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @return String
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static List<String> _getMultipleSelectedVisibleText(By locator) throws IOException{
		String ret = null;
		 List<String> retlist= new ArrayList<>();
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        List<WebElement> targetElements = WebDriverMain._getElementsWithWait(locator);
        if (targetElements != null) {
        	try{
        		 for (WebElement targetElement: targetElements){
					  ret = targetElement.getText();
					  retlist.add(ret);
				  }
        		
        	}catch(NoSuchElementException e){
        		//Log._logWarning("No options are selected.");
        		UMReporter.log(Status.FAIL, "Selected value is unable to retrive");
        	}
        }else {
        	//Log._logWarning("Failed to find Dropdown Option value :-"+locator);
        	UMReporter.log(Status.FAIL, "Selected value is unable to retrive");
        }
        return retlist;
	}
	
	
	/**
     * Remove visible text drop down using the specified locator. 
     *
     * @param locator
     *            The Select locator to find.
     * @return String
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _removeMultiSelected(By locator) throws IOException{
		boolean ret = false;
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        List<WebElement> targetElements = WebDriverMain._getElementsWithWait(locator);
        if (targetElements != null) {
        	try{
        		 for (WebElement targetElement: targetElements){
					  targetElement.click();
					  ret=true;
					  //UMReporter.log(Status.PASS, "Removed the list value");
				  }
        		
        	}catch(NoSuchElementException e){
        		//Log._logWarning("No options are selected.");
        		UMReporter.log(Status.FAIL, "Remove list value is unable to retrive on the location :"+locator);
        	}
        }else {
        	//Log._logWarning("Failed to find Dropdown Option value :-"+locator);
        	UMReporter.log(Status.FAIL, "Selected value is unable to retrive");
        }
        return ret;
	}

	/**
	 * Returns a list containing options available in the dropdown
	 * 
	 * @param by
	 * @return List<String>
	 * @throws IOException 
	 */
	public static List<String> _getDropDownOptions(By locator,By optionLocator) throws IOException
	{
		//Get the Dropdown as a Select using its name attribute
		List<String> act_options = new ArrayList<String>();
		if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	if(targetElement.isEnabled()){
            	try{
            		//open dropdowm list
            		targetElement.click();
            		CommonUtility._sleepForGivenTime(500);
            		List<WebElement> targetList = WebDriverMain._getElementsWithWait(optionLocator);
            		if(!targetList.isEmpty()){
	            		for (WebElement option: targetList)
	            			act_options.add(option.getText());
	            		//Close dropdowm list
	            		CommonUtility._sleepForGivenTime(500);
	            		targetElement.click();
	            		return act_options;
            		}
            		else
            		{
            			//Log._logWarning("Element Located but no option value found: ");
            			UMReporter.log(Status.FAIL, "Element Located but no option value found:");
            			return act_options;
            		}
            	}catch(NoSuchElementException e){
            		//Log._logWarning("Element Located but no option value found: ");
            		UMReporter.log(Status.FAIL, "Element Located but no option value found:");
            		return act_options;
            	}
			}else{
				//Log._logInfo("Element Select locator: "+locator+" is disabled.");
				UMReporter.log(Status.FAIL, "Element Located but no option value found:");
	            return act_options;
			}
        } else {
        	//Log._logWarning("Element Located but no option value found: ");
        	UMReporter.log(Status.FAIL, "Element Located but no option value found:");
            return act_options;
        }
	}
}
