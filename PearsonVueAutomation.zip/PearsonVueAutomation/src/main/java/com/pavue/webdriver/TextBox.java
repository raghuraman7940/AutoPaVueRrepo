package com.pavue.webdriver;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;

public class TextBox{


	/**
     * Set Text Box value as per the specified String value. 
     *
     * @param locator
     *            The element locator to find.
     * @param strText
     *            The Text value to enter.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _setTextBox(By locator, String strText) throws IOException{
		try {
			if (locator == null) {
			    throw new IllegalArgumentException(
			            "The Element locator to send cannot be null.");
			}
			if (strText == null) {
			    throw new IllegalArgumentException(
			            "The text to send cannot be null.");
			}
			WebElement targetElement = WebDriverMain._getElementWithWait(locator);
			if (targetElement != null) {
				if(targetElement.isEnabled()){
					targetElement.clear();
			        targetElement.sendKeys(strText);
			        //UMReporter.log(Status.PASS, "The text " +strText+ "is entered into the locator" +locator);
			        return true;
				}else{
					//Log._logInfo("Element TextBox: "+locator+" is disabled.");
					//UMReporter.log(Status.PASS, "The text " +strText+ "is entered into the locator" +locator);
			        return false;
				}
			} else {
				UMReporter.log(Status.FAIL, "The text " +strText+ "is not entered into the locator" +locator);
			    return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			UMReporter.log(Status.FAIL, "The text " +strText+ "is not entered into the locator" +locator);
			return false;
		}
		
	}
	
	/**
     * Set Text Box value as per the specified String value. 
     *
     * @param locator
     *            The element locator to find.
     * @param strText
     *            The Text value to enter.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _clearTextBox(By locator) throws IOException{
		try {
			if (locator == null) {
			    throw new IllegalArgumentException(
			            "The Element locator to send cannot be null.");
			}
			
			WebElement targetElement = WebDriverMain._getElementWithWait(locator);
			if (targetElement != null) {
				if(targetElement.isEnabled()){
					targetElement.clear();
					Thread.sleep(1000);
					targetElement.sendKeys(Keys.TAB);
					Thread.sleep(1000);
			        return true;
				}else{
					//Log._logInfo("Element TextBox: "+locator+" is disabled.");
					//UMReporter.log(Status.PASS, "The text " +strText+ "is entered into the locator" +locator);
			        return false;
				}
			} else {
				UMReporter.log(Status.FAIL, "The text is not cleared into the locator" +locator);
			    return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			UMReporter.log(Status.FAIL, "The text is not cleared into the locator" +locator);
			return false;
		}
		
	}
	
	/**
     * Set Text Box value as per the specified String value. 
     *
     * @param locator
     *            The element locator to find.
     * @param strText
     *            The Text value to enter.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _setTextBox(WebElement targetElement, String strText) throws IOException{
		if (targetElement == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        if (strText == null) {
            throw new IllegalArgumentException(
                    "The text to send cannot be null.");
        }

        	if(targetElement.isEnabled()){
        		targetElement.clear();
                targetElement.sendKeys(strText);
                //UMReporter.log(Status.PASS, "The text " +strText+ "is entered into the locator" +targetElement);
                return true;
			}else{
				//Log._logInfo("Element TextBox: "+targetElement+" is disabled.");
				//UMReporter.log(Status.PASS, "The text " +strText+ "is entered into the locator" +targetElement);
	            return true;
			}
        } 
	
	
	/**
     * Compare Text Box value as per the specified String value. 
     *
     * @param locator
     *            The element locator to find.
     * @param strText
     *            The Text value to enter.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _compareTextBox(By locator, String strText) throws IOException{
		String uiText;
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        if (strText == null) {
            throw new IllegalArgumentException(
                    "The text to send cannot be null.");
        }
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	//Get Text value of Web Element.
        	if ("INPUT".equalsIgnoreCase(targetElement.getTagName()))
        		uiText=targetElement.getAttribute("value").trim();
        	else if ("textarea".equalsIgnoreCase(targetElement.getTagName()))
        		uiText=targetElement.getAttribute("value").trim();
    		else
    		   	uiText=WebDriverMain._getTextFromElement(locator);
    		    
   		    //Verify if the text is already present .If yes,do not enter again
   		    if(uiText.equalsIgnoreCase(strText)){
   		    	//UMReporter.log(Status.PASS, "The text " +strText+ "is entered into the locator" +targetElement);
   		    	return true;
   		    }else{
   		    	//UMReporter.log(Status.FAIL, "The expected text " +strText+ " is not matched with the actual " +uiText);
   		    	return false;
   		    }
        } else {
        	//Log._logWarning(locator+" could not be found to send text to.");
        	UMReporter.log(Status.FAIL, "The text " +strText+ " is not entered into the locator : " +targetElement);
            return false;
        }
	}
	
	
	/**
     * Compare Text Box value as per the specified String value. 
     *
     * @param locator
     *            The element locator to find.
     * @param strText
     *            The Text value to enter.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static String _GetTextBoxValue(By locator) throws IOException{
		String uiText=null;
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The Element locator to send cannot be null.");
        }
        
        WebElement targetElement = WebDriverMain._getElementWithWait(locator);
        if (targetElement != null) {
        	//Get Text value of Web Element.
        	if ("INPUT".equalsIgnoreCase(targetElement.getTagName()))
        		uiText=targetElement.getAttribute("value").trim();
        	else if ("textarea".equalsIgnoreCase(targetElement.getTagName()))
        		uiText=targetElement.getAttribute("value").trim();
    		else
    		   	uiText=WebDriverMain._getTextFromElement(locator);
        	
   		   	//UMReporter.log(Status.PASS, "The text " +uiText+ " is displayed ");
   		    return uiText;
   		    
        } else {
        	//Log._logWarning(locator+" could not be found to send text to.");
        	UMReporter.log(Status.FAIL, "The text box is not exist into the locator" +targetElement);
            return uiText;
        }
	}
	
	/**
     * Compare and Set Text Box value as per the specified String value if not same. 
     *
     * @param locator
     *            The element locator to find.
     * @param strText
     *            The Text value to enter.
     * @return boolean
	 * @throws IOException 
     * 
     * @throws IllegalArgumentException
     *             Thrown if locator/strText/driver is null.
     */
	public static boolean _compareAndSetTextBox(By locator, String strText) throws IOException{
		boolean status;
		status = _compareTextBox(locator, strText);
		if(!status){
			status = _setTextBox(locator, strText);
		}
		return status;
	}

}
