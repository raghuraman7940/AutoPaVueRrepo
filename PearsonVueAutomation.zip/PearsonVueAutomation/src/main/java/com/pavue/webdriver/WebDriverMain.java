package com.pavue.webdriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.aventstack.extentreports.Status;
import com.google.common.base.Function;
import com.relevantcodes.extentreports.LogStatus;

import com.pavue.webdriver.Alerts;
import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;

/**
 * WebDriver Main Class
 *
 * @author Anand Tiwari
 * 
 *
 */
public class WebDriverMain{

    private static final int POLLING_MS = 200;
    
    private static int timeout = 4000;
    private static int medtimeout = 2000;
    
    private static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
    
    
	/**
     * Waits for one or more elements to appear.
     *
     * @author Anand Tiwari
     * 
     *
     */
	private static final class WaitForElementFunction implements
			Function<WebDriver, WebElement> {
		private final By by;

		/**
		 * Create a new WaitForElementFunction with the given By.
		 *
		 * @param by
		 *            The element to wait for.
		 */
		public WaitForElementFunction(final By by) {
			this.by = by;
		}

		@Override
		public WebElement apply(final WebDriver wdDriver) {
			return wdDriver.findElement(this.by);
		}
	}
	
	 /**
     * Waits for one or more elements to appear.
     *
     * @author Anand Tiwari
     * 
     *
     */
    private static final class WaitForElementsFunction implements
            Function<WebDriver, List<WebElement>> {
        private final By by;

        /**
         * Create a new WaitForElementsFunction with the given By.
         *
         * @param by
         *            The elements to wait for.
         */
        public WaitForElementsFunction(final By by) {
            this.by = by;
        }

        @Override
        public List<WebElement> apply(final WebDriver wdDriver) {
            List<WebElement> result = null;

            result = wdDriver.findElements(this.by);

            // if there are no elements we need to return null to enforce the
            // driver wait.util
            if (result.isEmpty()) {
                result = null;
            }

            return result;
        }
    }
    

    public static WebDriver _getDriver(){
    	return driver.get();
    }
    
    public static void setDriver(WebDriver wddriver){
    	driver.set(wddriver);
    }
    
    /**
     * Close the currently active browser window. If this is the last browser
     * window open, the browser will close.
     */
    public static final void _close() {
    	_getDriver().close();
    }

    /**
     * Load a page in the currently active browser window.
     *
     * @param url
     *            The url to navigate to.
     */
    public static final void _get(final String url) {
    	_getDriver().get(url);
    	try{
    	
    	}
    	catch(Exception e)
    	{
    		//Log._logWarningWithScreenShot("get url exception");
    		_getDriver().quit();
    		e.printStackTrace();
    		throw new TimeoutException(e.getMessage());
    	}
    }

    /**
     * Get the current URL of the currently active browser window.
     *
     * @return The url of the currently active browser window.
     */
    public static final String _getCurrentUrl() {
        return _getDriver().getCurrentUrl();
    }
    
    /**
     * Navigate to the URL of the currently active browser window.
     *
     * @return The url of the currently active browser window.
     * @throws IOException 
     */
    public static final void _navigateToURL(final String url) throws IOException
    {
    	try{
    	_getDriver().navigate().to(url);
    	//UMReporter.log(Status.PASS, "Navigated to URL "+url+" Successfully");
    	}catch(UnhandledAlertException a){
    		Alerts._acceptAlert();
    		_getDriver().navigate().to(url);
    		//UMReporter.log(Status.PASS, "Navigated to URL "+url+" Successfully");
    	}
    }
    
    /**
     * Get one or more browser elements, waiting up to the amount of time given
     * in the driverElement.
     *
     * @param locator
     *            The elements to find.
     * @return The elements if found, otherwise an empty list.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if the driverElement is null.
     */
    public static List<WebElement> _getElementsWithWait(
            final By locator) throws IOException {
        if (locator == null) {
        	UMReporter.log(Status.FAIL, "Locator Value is NULL");
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        List<WebElement> result = null;

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
            		_getDriver())
                    .withTimeout(medtimeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            result = wait.until(new WaitForElementsFunction(locator));
        } catch (TimeoutException e) {
        	e.printStackTrace();
            //Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
        	UMReporter.log(Status.FAIL, "Could not find locator located by "+locator+" within "+timeout+" ms.");
        }

        if (result == null) {
            result = new ArrayList<>();
        }

        return result;
    }
    
    
    /**
     * Get one or more browser elements, waiting up to the amount of time given
     * in the driverElement.
     *
     * @param locator
     *            The elements to find.
     * @return The elements if found, otherwise an empty list.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if the driverElement is null.
     */
    public static List<String> _getListOfTextFromElements(final By locator) throws IOException {
    	if (locator == null) {
    		throw new IllegalArgumentException("The locator cannot be null.");
    	}

    	List<WebElement> result = null;
    	List<String> texts = new ArrayList<String>();

    	try {
    		Wait<WebDriver> wait = new FluentWait<WebDriver>(
    				_getDriver())
    				.withTimeout(medtimeout,
    						TimeUnit.MILLISECONDS)
    						.pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
    						.ignoring(NoSuchElementException.class);

    		result = wait.until(new WaitForElementsFunction(locator));
    		for(WebElement ele:result)
    		{
    			texts.add(ele.getText().trim().replace("  ", " "));
    		}
    	} catch (TimeoutException e) {
    		e.printStackTrace();
    		//Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
    		UMReporter.log(Status.FAIL, "Could not find locator located by "+locator+" within "+timeout+" ms.");
    	}
    	return texts;
    }
    
    /**
     * Get a browser element, waiting up to the time given in the driverElement
     * object.
     *
     * @param locator
     *            The element to find.
     * @return The element if found, otherwise null.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if driverElement is null.
     */
    public static WebElement _getElementWithWait(final By locator) throws IOException {
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        WebElement result = null;

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
            		_getDriver())
                    .withTimeout(medtimeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            result = wait.until(new WaitForElementFunction(locator));
        } catch (TimeoutException e) {
        	e.printStackTrace();
        	//Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
        	UMReporter.log(Status.FAIL, "Could not find locator located by "+locator+" within "+timeout+" ms.");
        	return result;
        //	throw new TimeoutException("Could not find locator located by "+locator+" within "+timeout+" ms.");
        }
        return result;
    }
    
    /**
     * Get a browser element, waiting up to the 3Sec time in the driverElement
     * object.
     *
     * @param locator
     *            The element to find.
     * @return True if found, otherwise false.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if driverElement is null.
     */
    public static boolean _isElementPresent(final By locator) throws IOException{
    	if (locator == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
            		_getDriver())
                    .withTimeout(medtimeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.presenceOfElementLocated(locator));
            //UMReporter.log(Status.PASS, "Element "+locator+" is present");
            return true;
        } catch (TimeoutException e) {
        	//Log._logWarning("Could not find locator located by "+locator+" within "+3+" sec.");
        	//UMReporter.log(Status.FAIL, "Element "+locator+" is not present");
        	return false;
        }
    }
    
    /**
     * Get one or more browser elements, waiting up to the amount of time given
     * in the driverElement.
     *
     * @param locator
     *            The elements to find.
     * @return The elements if found, otherwise an empty list.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if the driverElement is null.
     */
    public static List<WebElement> _isElementsPresent(
            final By locator) throws IOException {
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        List<WebElement> result = null;

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
                _getDriver())
                    .withTimeout(medtimeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            result = wait.until(new WaitForElementsFunction(locator));
        } catch (TimeoutException e) {
          e.printStackTrace();
            //Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
         UMReporter.log(Status.FAIL, "Could not find locator located by "+locator+" within "+timeout+" ms");
        }

        if (result == null) {
            result = new ArrayList<>();
        }

        return result;
    }
    
    /**
     * Get a browser element, waiting up to the 5 Sec time for the element to be visible
     *
     * @param locator
     *            The element to find.
     * @return True if found, otherwise false.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if driverElement is null.
     */
    public static boolean _isElementVisible(final By locator) throws IOException{
    	if (locator == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
            		_getDriver())
                    .withTimeout(medtimeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            //UMReporter.log(Status.PASS, "Element with  "+locator+" is visible");
            return true;
        } catch (TimeoutException e) {
        	//Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
        	//UMReporter.log(Status.FAIL, "Could not find locator located by "+locator+" within "+timeout+" ms.");
        	return false;
        }
    }
    
    /**
     * Get a browser element, waiting up to the 5 Sec time for the element to be visible
     *
     * @param locator
     *            The webElement element to find.
     * @return True if found, otherwise false.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if driverElement is null.
     */
    public static boolean _isElementVisible(final WebElement webElement) throws IOException{
      if (webElement == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
                _getDriver())
                    .withTimeout(medtimeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.visibilityOf(webElement));
            //UMReporter.log(Status.PASS, "Element with  "+webElement+" is visible");
            return true;
        } catch (TimeoutException e) {
          //Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
        	UMReporter.log(Status.FAIL, "Element with  "+webElement+" is not visible");
          return false;
        }
    }
    
    /**
     * Get a browser element, waiting up to the 5 Sec time for the element to be Clickable
     *
     * @param webElement
     *            The webElement element to find.
     * @return True if found, otherwise false.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if driverElement is null.
     */
    public static boolean _isElementClickable(final WebElement webElement) throws IOException{
      if (webElement == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
                _getDriver())
                    .withTimeout(medtimeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.elementToBeClickable(webElement));
            //UMReporter.log(Status.PASS, "Element with  "+webElement+" is Clickable");
            return true;
        } catch (TimeoutException e) {
          //Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
        	UMReporter.log(Status.FAIL, "Element with  "+webElement+" is not Clickable");
          return false;
        }
    }
    
    /**
     * Get a browser element, waiting up to the 5 Sec time for the element to be Clickable
     *
     * @param By
     *           The locator of the element to find.
     * @return True if found, otherwise false.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if driverElement is null.
     */
    public static boolean _isElementClickable(final By by) throws IOException{
      if (by == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
                _getDriver())
                    .withTimeout(medtimeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.elementToBeClickable(by));
            //UMReporter.log(Status.PASS, "Element with  is Clickable");
            return true;
        } catch (TimeoutException e) {
          //Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
        	UMReporter.log(Status.FAIL, "Element with  is not Clickable");
          return false;
        }
    }
    
    /**
     * Get one or more browser elements, waiting up to the amount of time given
     * in the driverElement.
     *
     * @param locator
     *            The elements to find.
     * @return The elements if found, otherwise an empty list.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if the driverElement is null.
     */
    public static void _waitForElementVisible(
            final By locator) throws IOException {
        if (locator == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
            		_getDriver())
                    .withTimeout(timeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        } catch (TimeoutException e) {
        	e.printStackTrace();
            //Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
        	//UMReporter.log(Status.FAIL, "Could not find locator located by "+locator+" within "+timeout+" ms.");
            throw new TimeoutException("Could not find locator located by "+locator+" within "+timeout+" ms.");
        }

    }
    
    /**
     * Get one or more browser elements, waiting up to the amount of time given
     * in the driverElement.
     *
     * @param webElement
     *            The webElement to find.
     * @return The elements if found, otherwise an empty list.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if the driverElement is null.
     */
    public static void _waitForElementVisible(
            final WebElement webElement) throws IOException {
        if (webElement == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
                _getDriver())
                    .withTimeout(timeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.visibilityOf(webElement));
        } catch (TimeoutException e) {
        	e.printStackTrace();
            //Log._logWarning("Could not find locator located by "+webElement+" within "+timeout+" ms.");
        	//UMReporter.log(Status.FAIL, "Could not find locator located by "+webElement+" within "+timeout+" ms.");
            throw new TimeoutException("Could not find locator located by "+webElement+" within "+timeout+" ms.");
        }

    }
    
    /**
     * Get a browser element, waiting up to the time given for the element to be Clickable
     *
     * @param webElement
     *            The webElement element to find.
     * @return True if found, otherwise false.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if driverElement is null.
     */
    public static boolean _waitForElementClickable(final WebElement webElement) throws IOException{
      if (webElement == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
                _getDriver())
                    .withTimeout(timeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.elementToBeClickable(webElement));
            //UMReporter.log(Status.PASS, "Element with value "+webElement+" is Clickable");
            return true;
        } catch (TimeoutException e) {
        	e.printStackTrace();
          //Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
        	UMReporter.log(Status.FAIL, "Element with "+webElement+"  is not Clickable");
          return false;
        }
    }
    
    /**
     * Get a browser element, waiting up to the time given for the element to be Clickable
     *
     * @param webElement
     *            The webElement element to find.
     * @return True if found, otherwise false.
     * @throws IOException 
     * @throws IllegalArgumentException
     *             Thrown if driverElement is null.
     */
    public static boolean _waitForElementClickable(final By byLoc) throws IOException{
      if (byLoc == null) {
            throw new IllegalArgumentException(
                    "The locator cannot be null.");
        }

        try {
            Wait<WebDriver> wait = new FluentWait<WebDriver>(
                _getDriver())
                    .withTimeout(timeout,
                            TimeUnit.MILLISECONDS)
                    .pollingEvery(POLLING_MS, TimeUnit.MILLISECONDS)
                    .ignoring(NoSuchElementException.class);

            wait.until(ExpectedConditions.elementToBeClickable(byLoc));
            //UMReporter.log(Status.PASS, "Element is Clickable");
            return true;
        } catch (TimeoutException e) {
            e.printStackTrace();
          //Log._logWarning("Could not find locator located by "+locator+" within "+timeout+" ms.");
            UMReporter.log(Status.FAIL, "Element is not Clickable");
          return false;
        }
    }
    
	/**
	 * This function checks whether particular text over a page is present or not
	 * @param string
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean _isTextPresent(String string) throws IOException
	{
		if (string== null) {
			UMReporter.log(Status.FAIL, "Locator value is NULL");
			throw new IllegalArgumentException(
					"The string value cannot be null.");
		}
		if(_getTextFromElement(By.tagName("body")).contains(string))
		{
			//UMReporter.log(Status.PASS, "The text" +string+ "Present");
			return true;
		}
		else
			UMReporter.log(Status.FAIL, "The text" +string+ "is not Present");
			return false;
	}

	/**
	 * This function checks whether particular text of the element is present or not
	 * @param locator
	 * @param string
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean _isTextPresentInElement(By locator,String string) throws IOException {
		if(string== null) {
			UMReporter.log(Status.FAIL, "String value is NULL");
			throw new IllegalArgumentException(
					"The string value cannot be null.");
		}
		if(locator== null) {
			UMReporter.log(Status.FAIL, "Locator value is NULL");
			throw new IllegalArgumentException(
					"The locator value cannot be null.");
		}
		if (_getTextFromElement(locator).contains(string)) {
			//UMReporter.log(Status.PASS, "The text" +string+ "Present");
			return true;
		} else {
			UMReporter.log(Status.FAIL, "The text " +string+ "is not Present");
			return false;
		}
	}
		
	/**
	 * Compares the exact value of locator field with the provided strText.
	 * @param locator
	 * @param strText
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean _compareText(By locator, String strText) throws IOException {
		String strCompareText;
		strCompareText = _getTextFromElement(locator);
		if (strCompareText.toUpperCase().trim()
				.equals(strText.toUpperCase().trim())) {
			//UMReporter.log(Status.PASS, "The Actual Text " +strCompareText+ " is matched with expected text " +strText);
			return true;
		} else {
			UMReporter.log(Status.FAIL, "The Actual Message \"" +strCompareText+ "\" is not matched with expected Message \"" +strText + "\"");
			return false;
		}
	}
	
	/**
	 * Contains the value of locator field with the provided strText.
	 * @param locator
	 * @param strText
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean _containText(By locator, String strText) throws IOException {
		String strCompareText;
		strCompareText = _getTextFromElement(locator);
		if (strCompareText.toUpperCase().trim()
				.contains(strText.toUpperCase().trim())) {
			//UMReporter.log(Status.PASS, "The Actual Text " +strCompareText+ " is matched with expected text " +strText);
			return true;
		} else {
			UMReporter.log(Status.FAIL, "The Actual Text " +strCompareText+ " is not matched with expected text " +strText);
			return false;
		}
	}
	
	/**
	 * Returns the text from an element 
	 * @param locator
	 * @return String
	 * @throws IOException 
	 */
	public static String _getTextFromElement(By locator) throws IOException {
		WebElement targetElement = null;
		String strReturn = null;
		int i=1;
		try{
			while(i<4){
				if(_isElementVisible(locator)){
					targetElement=_getElementWithWait(locator);
					break;
				}
				i++;
			}
			strReturn = targetElement.getText();
			return strReturn;
		}catch(NullPointerException e){
			if(_isElementVisible(locator)){
					targetElement=_getElementWithWait(locator);
					strReturn = targetElement.getText();
			}
			else{
				if(i<=1)
					//Log._logWarningWithScreenShot("Null pointer exception may be thrwon since element is not visible with locator:-"+locator);
					UMReporter.log(Status.FAIL, " Null pointer exception may be thrwon since element is not visible with locator:-"+locator);
					strReturn = "";
				}
				if(!(strReturn==""))
					return strReturn;
				i++;
			return strReturn;
		}catch(StaleElementReferenceException e){
			if(_isElementVisible(locator)){
					targetElement=_getElementWithWait(locator);
					strReturn = targetElement.getText();
				}
				if(!(strReturn==""))
					return strReturn;
				i++;
			return strReturn;
		}
	}

	/**
	 * Take the screenshot at runtime 
	 * @param methodName
	 * @return void
	 */
	public static void _takeScreenshot(String methodName) {

		try {
			String path = CommonUtility._getProjectWS() + "\\screenshots";
	
			if (!path.endsWith("\\")) {
				path = path + "\\";
			}
			String dateNow;
			dateNow = CommonUtility._getTimeStamp("MMM_dd_yyyy_HH_mm_ss");
			if (new File(path + dateNow + ".png").exists()) {
				dateNow = CommonUtility._getTimeStamp("MMM_dd_yyyy_HH_mm_SSSSSS");
			}

			//driver = new Augmenter().augment(driver);
			//WebDriver augmentedDriver = new Augmenter().augment(driver);
			//File scrFile = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);

			File scrFile = ((TakesScreenshot) _getDriver()).getScreenshotAs(OutputType.FILE);
			
			String encodedBase64 = null;
		    FileInputStream fileInputStreamReader = null;
		      try {
		          fileInputStreamReader = new FileInputStream(scrFile);
		          byte[] bytes = new byte[(int) scrFile.length()];
		          fileInputStreamReader.read(bytes);
		          encodedBase64 = new String(Base64.encodeBase64(bytes));
		        } catch (FileNotFoundException e) {
		          e.printStackTrace();
		        } catch (IOException e) {
		          e.printStackTrace();
		        }

		    
		    
		    

			
			String strFileName = path + methodName + "_"+ dateNow + ".png";
			
			FileUtils.copyFile(scrFile, new File(strFileName));
			
			System.out.println(strFileName);
			
			Reporter.log("Screenshot Capture: " + "<a href=\"" + strFileName
			          + "\"><br /><p align=\"left\">Screenshot for scenario failed at " + new Date() + "</p>");
			      String imagebase64 = "data:image/png;base64," + encodedBase64;
			     // String screen = ExtentManager.getTest().addScreenCapture(imagebase64);

			//Log._logInfo("<a href='"+CommonUtility._getProjectWS()+"\\Screenshots\\"+methodName + "_"+ dateNow + ".png'>Screenshot</a><br/>");

		
		//ExtentManager.getTest().log(LogStatus.INFO, "<font color='red'>",screen+"</font><br/>");
			
		} catch (Exception e) {
			e.printStackTrace();
			//Log._logWarning("Exception while capturing screenshot:"+ e.getMessage());
		}
	}

	/**Function Name :- PleaseWaitMessage<br/>
	 * Description   :- wait for the element for a default duration of customized seconds
	 * 
	 * @return boolean
	 * @throws IOException 
	 */
	protected static boolean _pleaseWaitAndLoadingMessage() throws IOException {
	  int msgTimeOut = 5;
	  boolean status=true;
	  int i =0;
	  while(status){
	    CommonUtility._sleepForGivenTime(1000);
	    if((!WebDriverMain._isElementVisible(By.cssSelector("div.blockUI.blockMsg.blockElement")))&&(!WebDriverMain._isElementVisible(By.cssSelector("div.blockUI.blockMsg.blockPage")))
	        &&((boolean)((JavascriptExecutor) WebDriverMain._getDriver()).executeScript("return 'complete' == document.readyState;"))
	        )
	      status=false;
	    i++;
	    if(i>msgTimeOut)
	      status=false;
	  }
	  System.out.println("Page load total time :- "+i);
	  return true;	
	}

	/**Function Name :- PleaseWaitMessage<br/>
	 * Description   :- wait for the element for a default duration of customized seconds
	 * 
	 * @return boolean
	 */
	protected static boolean _clickLoading() {
	  int msgTimeOut = 10;
	  boolean status=true;
	  int i =0;
	  while(status){
	    if((boolean)((JavascriptExecutor) WebDriverMain._getDriver()).executeScript("return 'complete' == document.readyState;")){
	      status=false;
	      break;
	    }
	    CommonUtility._sleepForGivenTime(500);
	    i++;
	    if(i>msgTimeOut){
	      status=false;
	      System.out.println("Page load total time :- "+i);
	     }
	  }
	  //System.out.println("Page load total time :- "+i);
	  return true;  
	}

	/**Function Name :- PleaseWaitMessage<br/>
	 * Description   :- wait for the text to be present in the body for 10 seconds
	 *                  if text is not present then return false
	 *          
	 * @return boolean
	 */
	public static boolean _waitForTextToBePresent(String expectedText) {
		try {
			WebDriverWait wait = new WebDriverWait(WebDriverMain._getDriver(), 10);
			final String  str=expectedText;
			Boolean b;
			try {
				b =wait.until(new ExpectedCondition<Boolean>() {

					@Override
					public Boolean apply(WebDriver d)
					{
						try {
							return WebDriverMain._isTextPresentInElement(By.tagName("body"), str);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return false;
					}
				});
			} catch (TimeoutException e) {
				b=false;
			}
			return b;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public static String captureScreen() throws IOException {
		// WebDriver driver = DriverFactory.getCurrentDriver();
		String path;
		File trgtPath = null;
		WebDriver driverLoc = _getDriver();
		try {
			WebDriver augmentedDriver = new Augmenter().augment(driverLoc);
			File source = ((TakesScreenshot) augmentedDriver)
					.getScreenshotAs(OutputType.FILE);
			// java.util.Date date= new java.util.Date();
			// Timestamp tstamp = new Timestamp(date.getTime());
			//			path = ConfigProp.getPropertyValue("SSPath") + source.getName();
			path = UMReporter.reportPath + "/" + source.getName();
			System.out.println(path);
			trgtPath = new File(path);

			FileUtils.copyFile(source, trgtPath);
		} catch (Exception e) {
			path = "Failed to capture screenshot: " + e.getMessage();
			UMReporter.log(Status.FAIL, "Failed to capture screenshot");
			UMReporter.log(Status.ERROR, path);
		}
		return trgtPath.getAbsolutePath();
	}
}
