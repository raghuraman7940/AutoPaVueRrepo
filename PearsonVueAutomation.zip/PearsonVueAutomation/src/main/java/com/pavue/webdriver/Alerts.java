package com.pavue.webdriver;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;

import com.aventstack.extentreports.Status;

import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.WebDriverMain;

public class Alerts{

	/**
	 * Returns the text message of alert 
	 * @return String
	 * @throws IOException 
	 */
	public static String _getAlertMessage() throws IOException {
		String message = null;
		try {
			Alert alert = WebDriverMain._getDriver().switchTo().alert();

			message = alert.getText();
			alert.accept();
			//UMReporter.log(Status.PASS, "The Alert with message" +message+ "is accepted");
		} catch (Exception e) {
			// Sometimes the text exist, but not the accept button.
			// this means the popup wasn't displayed and therefore
			// really never existed.
			message = null;
			UMReporter.log(Status.FAIL, "The Alert with message" +message+ "is unable to accept");
		}
		return message;
	}

	/**
	 * Clicks on the cancel of popup message box
	 * @return String
	 * @throws IOException 
	 */
	public static String _cancelPopupMessageBox() throws IOException {
		String message = null;
		try {
			Alert alert = WebDriverMain._getDriver().switchTo().alert();

			message = alert.getText();
			alert.dismiss();
			//UMReporter.log(Status.PASS, "The Alert with message" +message+ "is cancelled");
		} catch (Exception e) {
			// Sometimes the text exist, but not the accept button.
			// this means the popup wasn't displayed and therefore
			// really never existed.
			//
			message = null;
			UMReporter.log(Status.FAIL, "The Alert with message" +message+ "is unable to cancel");
		}

		return message;
	}

	/**
	 * Checks alert present or not
	 * @return boolean
	 * @throws IOException 
	 */
	public static boolean _isAlertPresent() throws IOException { 
		try { 
			WebDriverMain._getDriver().switchTo().alert(); 
			//UMReporter.log(Status.PASS, "The Alert is present");
			return true; 
		} 
		catch (NoAlertPresentException Ex) { 
			UMReporter.log(Status.FAIL, "The Alert is not present");
			return false; 
		}    
	} 

	/**
	 * Clicks on ok button of Popup message
	 * @return void
	 * @throws IOException 
	 */
	public static void _acceptAlert() throws IOException {

		try {
			Alert alert = WebDriverMain._getDriver().switchTo().alert();
			alert.accept();
			//UMReporter.log(Status.PASS, "The Alert is Accepted");
		} catch (Exception e) {
			// Sometimes the text exist, but not the accept button.
			// this means the popup wasn't displayed and therefore
			// really never existed.
			UMReporter.log(Status.FAIL, "The Alert is not accepted");
		}
	}

	

}
