package com.pavue.pages;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.aventstack.extentreports.Status;
import com.pavue.common.core.CommonFunctions;
import com.pavue.webdriver.CommonUtility;
import com.pavue.webdriver.LeftClick;
import com.pavue.webdriver.TextBox;
import com.pavue.webdriver.UMReporter;
import com.pavue.webdriver.KendoDropdown;
import com.pavue.webdriver.WebDriverMain;

public class Home {

	// Initialize variable
	WebDriver driver;
	CommonFunctions common;
	

	// Home page locators
	public static String HOME = "xpath|//pa-context-bar/div/pa-title/span[@class='d-inline-block']";
	public static String HomeComponent = "xpath|//pa-home//h5[contains(text(),'Student')]";
	public static String AdminHome = "xpath|//pa-main/main/pa-home/p";

	public static String YourAccount = "xpath|//kendo-popup//ul/li[contains(text(),'Your Account')]";
	public static String PROGRAM_SELECTED = "xpath|//*[@id='navbarContent']/ul/li[1]";
	public static String PROGRAM_DROPDOWN = "xpath|//*[@id='navbarContent']/ul/li[1]/kendo-popup/div/div/div/kendo-dropdownlist";
	public static String PROGRAM_LIST = "xpath|//pa-root/kendo-popup/div/kendo-list/div/ul/li";
	public static String YEAR_LIST = "xpath|//*[@id='navbarContent']/ul/li[1]/kendo-popup/div/div/ul";
	public static String ADMIN_LIST = "xpath|//li[@class='adminLink']";
	public static String Menuoption = "xpath|.//button[contains(@class,'fa fa-bars')]";
	public static String Menuoption_ChangedonUsers = "xpath|.//span[contains(@class,'fa fa-bars')]";
	public static String NavHeader = "xpath|//div[@id='navbarContentOrg']";
	
	public static String Navigation_Bar = "xpath|.//nav/ul";
	
	public static String Menuoption_StudentTest = "xpath|.//li/a[contains(.,'Student Tests')]";
	

	public static String Menuoption_OnlineTesting_Settings = "xpath|.//li/a[contains(.,'Settings')]";
	
	//public static String OrgSelector = "xpath|.//div[@id='navbarContent']//li[2]/div[2]";
	public static String OrgSelector = "xpath|.//div[@id='navbarContent']//li[1]//following-sibling::li[@class='mr-3 nav-link pointer']//div[2]/child::i[starts-with(@class,'fa')]";
	public static String OrgFilter = "xpath|.//input[@name='currentOrgFilter']";
	public static String OrgLink = "xpath|.//li[@class='orgLink']";

	public static String Menuoption_Collapsed = "xpath|//pa-nav-links/nav/ul[contains(@class,'collapsed')]";
	public static String Menuoption_Home = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Home')]";
	public static String MenuoptionOrganizations = "xpath|//h6[contains(text(),'Organizations')]";
	public static String Menuoption_MyState = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'State')]";
	public static String Menuoption_MyDistrict = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'District')]";
	public static String Menuoption_MySchool = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'School')]";
	public static String Menuoption_Districts = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Districts')]";
	public static String Menuoption_Schools = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Schools')]";
	
	public static String Menuoption_Students = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Students')]";
	public static String Menuoption_Classes = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Classes')]";
	public static String Menuoption_ClassMgmt = "xpath|.//li/a[contains(.,'Class Management')]";
	public static String Menuoption_Session = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Sessions')]";
	public static String Menuoption_Users = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Users')]";
	public static String Menuoption_ViewReports = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Reports')]";
	public static String Menuoption_DataImports = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Imports/Exports')]";
	public static String Menuoption_Shipments = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Shipments')]";
	public static String Menuoption_Products = "xpath|//pa-nav-links/nav/ul/li/a//span[contains(text(),'Tests')]";
	public static String Menuoption_Courses = "xpath|//pa-nav-links/nav/ul/li//span[contains(text(),'Courses')]";

	public static String Org_Selected = "xpath|//pa-filterable-org-tree//div[contains(@class,'pa-org-name')]";
	public static String Org_SelectArrow = "xpath|.//pa-filterable-org-tree//button/i";
	public static String Org_PopUp = "xpath|.//pa-filterable-org-tree/div/kendo-popup";
	public static String Org_PopUp_filterbox = "xpath|.//pa-filterable-org-tree/div/kendo-popup//input";
	public static String Org_PopUp_StateList = "xpath|//pa-filterable-org-tree/div/kendo-popup//kendo-treeview/ul/li";
	
	public static String Cus_Selected = "xpath|//pa-customer-switcher//span[contains(@class,'customer-name')]";
	public static String Cus_SelectArrow = "xpath|//pa-customer-switcher//i[contains(@class,'customerContextToggle')]";
	public static String Cus_PopUp = "xpath|//pa-customer-switcher//kendo-popup";
	public static String Cus_PopUp_List = "xpath|//pa-customer-switcher//kendo-popup/div//button";
	
	public static String Header_WelcomeMsg = "xpath|//pa-customer-switcher//span[@class='welcome-message']";
	public static String Header_Role = "xpath|//pa-customer-switcher//div[contains(@class,'role-name')]";
	public static String Header_LocoImg = "xpath|//pa-logo/img";
	
	
	public static String USERICON = "xpath|//div[@id='navbarContentUser']//kendo-dropdownbutton/button[@role='button']/span[contains(@class,'fa-user')]";
	public static String USERDROPDOWN = "xpath|//kendo-popup//kendo-button-list/ul/li";
	public static String Logout = "xpath|//kendo-popup//kendo-button-list/ul/li/div[contains(text(),'Sign out')]";
	public static String MyAccount = "xpath|//kendo-popup//kendo-button-list/ul/li/span[contains(text(),'My Account')]";
	
	public static String MyAccDlg = "xpath|//pa-user-profile/kendo-dialog/div[contains(@class,'k-dialog')]";
	public static String MyAccDlgTitle = "xpath|//kendo-dialog-titlebar[contains(@id,'kendo-dialog-title')]/div[contains(@class,'k-dialog-title')]//h2";
	public static String MyAccDlgTitle_OrgRoles = "xpath|//kendo-dialog-titlebar[contains(@id,'kendo-dialog-title')]/div[contains(@class,'k-dialog-title')]//div/ul/li";
	public static String MyAccDlg_TabTitle = "xpath|//pa-user-profile/kendo-dialog/div[2]/div[contains(@class,'k-dialog-content')]/h2";
	public static String MyAccDlg_Tabs = "xpath|//pa-user-profile/kendo-dialog//kendo-tabstrip/ul/li/span";
	
	public static String MyAccDlg_Tab_Detail = "xpath|//pa-user-profile/kendo-dialog//kendo-tabstrip/ul/li//span[contains(text(),'Details')]";
	public static String MyAccDlg_Tab_Security = "xpath|//pa-user-profile/kendo-dialog//kendo-tabstrip/ul/li//span[contains(text(),'Security Questions')]";
	public static String MyAccDlg_Tab_PwdReset = "xpath|//pa-user-profile/kendo-dialog//kendo-tabstrip/ul/li//span[contains(text(),'Password Reset')]";
	public static String MyAccDlg_Edit = "xpath|//kendo-dialog//kendo-dialog-actions/button[contains(text(),'Edit')]";
	public static String MyAccDlg_Save = "xpath|//kendo-dialog//kendo-dialog-actions/button[contains(text(),'Save')]";
	public static String MyAccDlg_Cancel = "xpath|//kendo-dialog//kendo-dialog-actions/button[contains(text(),'Cancel')]";
	public static String MyAccDlg_Close = "xpath|//kendo-dialog//kendo-dialog-actions/button[contains(.,'Close') or contains(.,'Cancel')]";
	public static String lodingspinner = "xpath|//div[contains(@class,'card-deck')]/div[contains(@class,'spinner-container justify-content-center d-flex')]//div[contains(@class,'spinner-style')]";
	public static String popupdropdownlist="xpath|//kendo-popup/div/kendo-list/div/ul/li";
	public static String Success_Message="xpath|//div[@id='alerts']/div[@role='alert']/span/span";
	public static String CloseAlerts="xpath|//div[@id='alerts']//button[@class='close']";
	public static String MyAccDlg_ErrorHint="xpath|//div[contains(@class,'form-control-error ng-star-inserted')]";
	public static String MyAccDlg_ErrorMessage="xpath|//div[@id='alerts']/div[@role='alert']/span/span";	
	
	
	public static String Footer_Copyright = "xpath|//pa-root//main//footer//div//span[@class = 'footer-copyright']";
	public static String Footer_Conditions= "xpath|//pa-root//main//footer//div//button[@class='btn btn-link footer-link']";
	public static String Footer_Privacy = "xpath|//pa-root//main//footer//div//button[2][@class='btn btn-link footer-link']";
	public static String Footer_logo = "xpath|//pa-root//main//footer//span/img";
	
	public static String cntTotalStudents="xpath|//pa-session-details-status//button[contains(text(),'Total Students:')]";
	public static String TestSesWidHasNoData="xpath|//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'Test Sessions Overview')]/../../../../div[@class='card-body']//div[contains(text(),'No data to display')]";
	
	public static String studentaccom="xpath|//pa-student-edit//form//h2";
	public static String studentaccomexpandup="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]/../../..//i[contains(@class,'fa-angle-up')]";
	public static String studentaccomcollapsedown="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]/../../..//i[contains(@class,'fa-angle-down')]";
	public static String studentaccombody="xpath|//pa-student-edit//div[contains(@class,'card-header')]//h2[contains(text(),'Accommodations')]/../../../../../div[contains(@class,'card-body')]";
	
	
	/**
	 * Constructor Description :- To initialize the values.
	 * 
	 * @return boolean
	 */
	public Home() {

		// PageFactory.initElements(driver, this);
	}

	/**
	 * Function Name :- HomePageObjects<br>
	 * Description :- To set homepage page locator.
	 * 
	 * @return By
	 */
	public By HomePageObjects(String byStrgylocValue) {
		By by = null;
		by = CommonUtility._getByLocator(byStrgylocValue);
		return by;
	}

	/**
	 * Function Name :- VerifyLoggedinHomePage<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean WaitLoggedinHomePage() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementVisible(HomePageObjects(HomeComponent))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- VerifyLoggedinHomePage<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean VerifyLoggedinHomePage() throws IOException {
		
		if (WebDriverMain._isElementPresent(HomePageObjects(USERICON))) {
//		String ActualText = WebDriverMain._getTextFromElement(HomePageObjects(HomeComponent));
//		if (ActualText.contains("Student")) {
			return true;
		} else {
			return false;
		}
	}
	

	/**
	 * Function Name :- VerifyMenuOptions<br>
	 * Description :- Verify Menu options
	 * 
	 * @return String
	 * @throws IOException
	 */
	public boolean VerifyMenuOptions() throws IOException {
		boolean ConfState=false;
		CommonFunctions.PleaseWaitAndLoadingMessage();
		
		if (WebDriverMain._isElementVisible(HomePageObjects(Menuoption_Collapsed))) {
			LeftClick._click(HomePageObjects(Menuoption));
			CommonUtility._sleepForGivenTime(1000);
		}	
		if (WebDriverMain._isElementVisible(HomePageObjects(Menuoption_Home))&&(WebDriverMain._isElementVisible(HomePageObjects(NavHeader)))) {
			LeftClick._click(HomePageObjects(Menuoption));
			return true;
		}
		else
		{
			//ChangeOrgAndRefresh();
			PageRefresh();
			//AppendPageRefresh();
			CommonFunctions.PleaseWaitAndLoadingMessage();	
		}
		return ConfState;
	}

	/**
	 * Function Name :- VerifyLoggedinAdminHomePage<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean VerifyLoggedinAdminHomePage() throws IOException {
		String ActualText = WebDriverMain._getTextFromElement(HomePageObjects(AdminHome));
		if (ActualText.contains("Admin")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- VerifyLoggedinHomePage<br>
	 * Description :- To verify the Logged Home text.
	 *
	 */
	public boolean VerifyUserIcon() throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();
		if (WebDriverMain._isElementPresent(HomePageObjects(USERICON))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Function Name :- Logout<br>
	 * Description :- To Click logout from user dropdown.
	 *
	 */
	public boolean Logout() throws IOException {
		LeftClick._click(HomePageObjects(USERICON));
		if (WebDriverMain._isElementPresent(HomePageObjects(USERDROPDOWN))) {
			LeftClick._click(HomePageObjects(Logout));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	
	/**
	 * Function Name :- Func_SelectOrg<br>
	 * Description :- To search organization in org filter
	 *
	 */

	public boolean Func_SelectOrg(String org) throws Exception {
	
		if (LeftClick._click(HomePageObjects(OrgSelector))) 
		{
		    CommonUtility._sleepForGivenTime(1000);
		    if(TextBox._setTextBox(HomePageObjects(OrgFilter), org))
		        {  
			       CommonUtility._sleepForGivenTime(1000);
			       LeftClick._click(HomePageObjects(OrgLink));
			       return true;
		        }
		  
		    else
		     {
			       return false;
		     }
	 	   
		
		}

		else
		{
			return false;
		}
		
		
	}

	/**
	 * Function Name :- Func_ChangeAdmin<br>
	 * Description :- Compare and change <b>Scope</b> if required
	 * 
	 * @param strProgram
	 *            Program Name
	 * @param strAdmin
	 *            Admin Name
	 * @param strYear
	 *            Year to Select
	 * @throws IOException
	 * 
	 */
	public void Func_ChangeAdmin(String strProgram, String strAdmin, String strYear) throws IOException {
		CommonFunctions.PleaseWaitAndLoadingMessage();

		CommonUtility._functionNameReportStart(Thread.currentThread().getStackTrace()[1].getMethodName());
		strAdmin = CommonUtility._StringUnknownChar(strAdmin);
		String currentAdmin = null;

		CommonUtility._sleepForGivenTime(1000);
		// In case change admin acccess is disabled ,for eg in case of
		// organization administrator user role
		if (!WebDriverMain._isElementPresent(HomePageObjects(PROGRAM_SELECTED))) {
			currentAdmin = WebDriverMain._getTextFromElement(HomePageObjects(PROGRAM_SELECTED));
			if (!currentAdmin.contains(strAdmin)) {
				// Log._logWarning("Admin cannot be changed and<br/> current
				// admin:-" + currentAdmin + " is not same as expected admin:-"
				// + strAdmin);
			} else {
				// Log._logInfo("-->Admin " + strAdmin + " is already
				// selected.");
			}

		}
		// In case change admin access is available
		else {
			CommonUtility._sleepForGivenTime(1000);
			currentAdmin = WebDriverMain._getTextFromElement(HomePageObjects(PROGRAM_SELECTED));
			String[] arrAdmin = currentAdmin.split(">");
			CommonFunctions.PleaseWaitAndLoadingMessage();
			if (!(arrAdmin[2].trim().equalsIgnoreCase(strAdmin) && arrAdmin[0].trim().contains(strProgram))) {
				CommonUtility._sleepForGivenTime(2000);
				LeftClick._click(HomePageObjects(PROGRAM_SELECTED));
				CommonUtility._sleepForGivenTime(1000);
				KendoDropdown._selectByValue(HomePageObjects(PROGRAM_DROPDOWN), HomePageObjects(PROGRAM_LIST),
						strProgram);
				// Log._logInfo("-->Selected the Program "+strProgram+" in the
				// Program selector dropdown ");
				CommonUtility._sleepForGivenTime(1000);
				List<WebElement> Yrlst = WebDriverMain._getElementsWithWait(HomePageObjects(YEAR_LIST));
				for (WebElement YrElm : Yrlst) {
					String yrStr = YrElm.getText();
					// System.out.println("yrStr:"+yrStr);
					if (yrStr.contains(strYear)) {
						List<WebElement> Admlst = WebDriverMain._getElementsWithWait(HomePageObjects(ADMIN_LIST));
						if (Admlst.size() > 1)
							YrElm.click();
						CommonUtility._sleepForGivenTime(2000);
						// Log._logInfo("-->Selected the Year "+yrStr+" in the
						// Year selector dropdown ");
						// List<WebElement>
						// Admlst=WebDriverMain._getElementsWithWait(HomePageObjects(ADMIN_LIST));
						for (WebElement AdmElm : Admlst) {
							String AdmStr = AdmElm.getText();
							// System.out.println("AdmStr:"+AdmStr);
							if (AdmStr.contains(strAdmin)) {
								AdmElm.click();
								CommonFunctions.PleaseWaitAndLoadingMessage();
								// Log._logInfo("-->Selected the Admin
								// "+strAdmin+" in the Admin selector dropdown
								// ");
								return;
							}
						}
					}
				}
			} else {
				// Log._logInfo("-->Admin "+strAdmin+" is already selected.");
			}
		}
		CommonUtility._functionNameReportFinish(Thread.currentThread().getStackTrace()[1].getMethodName());

	}

	/**
	 * Function Name :- Func_GetAdmin<br>
	 * Description :- Get Current Acount details <b>Admin</b> if required
	 * 
	 * @return HashMap with Program, Admin and Year
	 * @throws IOException
	 */
	public Map<String, String> Func_GetAcountDetails() throws IOException {
		Map<String, String> AcountDetails = new HashMap<String, String>();
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._functionNameReportStart(Thread.currentThread().getStackTrace()[1].getMethodName());
		String currentAdmin = null;
		CommonUtility._sleepForGivenTime(1000);
		// In case change admin acccess is disabled ,for eg in case of
		// organization administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(PROGRAM_SELECTED))) {
			CommonUtility._sleepForGivenTime(1000);
			currentAdmin = WebDriverMain._getTextFromElement(HomePageObjects(PROGRAM_SELECTED));
			String[] arrAdmin = currentAdmin.split(">");
			CommonFunctions.PleaseWaitAndLoadingMessage();
			System.out.println("arrAdmin:" + arrAdmin);
			System.out.println("arrAdmin length:" + arrAdmin.length);
			// Store response in a map
			if (arrAdmin.length > 2) {
				AcountDetails.put("PROGRAM", arrAdmin[0].trim());
				AcountDetails.put("YEAR", arrAdmin[1].trim());
				AcountDetails.put("ADMIN", arrAdmin[2].trim());
			}
			// Log._logInfo("-->Program Details is displayed.");
		} else {
			// Log._logWarning("Program Details is not displayed.");
		}
		CommonUtility._functionNameReportFinish(Thread.currentThread().getStackTrace()[1].getMethodName());
		return AcountDetails;
	}

	/**
	 * Function Name :- Func_VerifyAcountDetails<br>
	 * Description :- Verify Current Acount details <b>Admin</b> if required
	 * 
	 * @return HashMap with Program, Admin and Year
	 * @throws IOException
	 */
	public boolean Func_VerifyAcountDetails(String strProgram, String strAdmin, String strYear) throws IOException {
	//	Map<String, String> AcountDetails = new HashMap<String, String>();
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._functionNameReportStart(Thread.currentThread().getStackTrace()[1].getMethodName());
		String currentAdmin = null;
		CommonUtility._sleepForGivenTime(1000);
		// In case change admin acccess is disabled ,for eg in case of
		// organization administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(PROGRAM_SELECTED))) {
			CommonUtility._sleepForGivenTime(1000);
			currentAdmin = WebDriverMain._getTextFromElement(HomePageObjects(PROGRAM_SELECTED));
			String[] arrAdmin = currentAdmin.split(">");
			// Verify the Scope details
			if (arrAdmin.length > 2) {
				if ((strProgram.equalsIgnoreCase(arrAdmin[0].trim())) && (strYear.equalsIgnoreCase(arrAdmin[1].trim()))
						&& (strAdmin.equalsIgnoreCase(arrAdmin[2].trim())))
					return true;
			}
		}

		return false;
	}

	/**
	 * Function Name :- Func_GetCurrentOrgName<br>
	 * Description :- Get Current Organization details
	 * 
	 * @return String
	 * @throws IOException
	 */
	public String Func_GetCurrentOrgName() throws IOException {
	//	Map<String, String> AcountDetails = new HashMap<String, String>();
		CommonFunctions.PleaseWaitAndLoadingMessage();
		String currentAdmin = null;
		CommonUtility._sleepForGivenTime(3000);
		// In case change admin acccess is disabled ,for eg in case of
		// organization administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(Org_Selected))) {
			currentAdmin = WebDriverMain._getTextFromElement(HomePageObjects(Org_Selected));
		} 
		else
		{
			CommonUtility._sleepForGivenTime(3000);
			if (WebDriverMain._isElementPresent(HomePageObjects(Org_Selected))) {
				currentAdmin = WebDriverMain._getTextFromElement(HomePageObjects(Org_Selected));
			} 
			
		}
		return currentAdmin;
	}
	
	
	/**
	 * Function Name :- Func_GetCurrentOrgName<br>
	 * Description :- Get Current Organization details
	 * 
	 * @return String
	 * @throws IOException
	 */
	public String Func_GetPinnedOrgName() throws IOException {
		String currentAdmin = "";
		if (WebDriverMain._isElementPresent(HomePageObjects(Org_Selected))) {
			currentAdmin = WebDriverMain._getTextFromElement(HomePageObjects(Org_Selected));
			 if (currentAdmin.contains("\n")) 
				 currentAdmin=currentAdmin.replace("\n", "");
			String[] arrOrg = currentAdmin.split("\\(");
			if (arrOrg.length >=1) {
				currentAdmin= arrOrg[0].trim();
			}
		} 
		return currentAdmin;
	}
	/**
	 * Function Name :- Func_GetCurrentOrgName<br>
	 * Description :- Get Current Organization details
	 * 
	 * @return String
	 * @throws IOException
	 */
	public boolean Func_VerifyOrgName(String OrgName) throws IOException {
	//	Map<String, String> AcountDetails = new HashMap<String, String>();
		String currentAdmin = null;
		CommonUtility._sleepForGivenTime(1000);
		String[] arrOrg = OrgName.split(">");
		String OrgNametobeSelected=arrOrg[arrOrg.length-1].trim();
		// organization administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(Org_Selected))) {
			currentAdmin = WebDriverMain._getTextFromElement(HomePageObjects(Org_Selected));
			if (currentAdmin.contains(OrgNametobeSelected))
				return true;
		} 
		return false;
	}
	
	/**
	 * Function Name :- Func_ChangeOrganization<br>
	 * Description :- Compare and change <b>Organization</b> if required
	 * 
	 * @param OrgName
	 *            Organization Name
	 * @throws IOException
	 * 
	 */
	public void Func_ChangeOrganization(String OrgName) throws IOException {
		String FS_State=null,FS_Dst=null,FS_Schl=null;
		CommonUtility._sleepForGivenTime(1000);
		//OrgName="State>Dst>Sch";
		String[] arrOrg = OrgName.split(">");
		if (arrOrg.length == 3) {
			FS_State= arrOrg[0].trim();
			FS_Dst= arrOrg[1].trim();
			FS_Schl= arrOrg[2].trim();
		}
		else if (arrOrg.length == 2) {
			FS_State= arrOrg[0].trim();
			FS_Dst= arrOrg[1].trim();
			FS_Schl= null;
		}
		else if (arrOrg.length == 1) {
			FS_State= arrOrg[0].trim();
			FS_Dst= null;
			FS_Schl= null;
		}
		String OrgtobeSelected=arrOrg[arrOrg.length-1].trim();
		
		//Get Current Org name
		String CurrentOrgName=Func_GetCurrentOrgName();
		// If Org not provide
		if ((!CurrentOrgName.contains(OrgtobeSelected))&&(WebDriverMain._isElementPresent(HomePageObjects(Org_SelectArrow)))) {
			LeftClick._click(HomePageObjects(Org_SelectArrow));
			CommonUtility._sleepForGivenTime(2000);
			if (WebDriverMain._isElementPresent(HomePageObjects(Org_PopUp))) {
				//Clear Filter
				TextBox._setTextBox(HomePageObjects(Org_PopUp_filterbox), OrgtobeSelected);
				CommonUtility._sleepForGivenTime(2000);
				
				List<WebElement> Statelst = WebDriverMain._getElementsWithWait(HomePageObjects(Org_PopUp_StateList));
				for (int iStateCnt = 1; iStateCnt <= Statelst.size(); iStateCnt++) {
					By by = CommonUtility._getObjectLocator("xpath=//kendo-popup//kendo-treeview/ul/li["+iStateCnt+"]/div/span[contains(@class,'k-in')]");
					WebElement StateElm= WebDriverMain._getElementWithWait(by);
					String stateStr = StateElm.getText();
					 if (stateStr.contains("\n")) 
						 stateStr=stateStr.replace("\n", "");
					System.out.println("State:"+stateStr);
					if (stateStr.contains(FS_State)) {
						System.out.println("Selected State:"+stateStr);
						if (stateStr.contains(OrgtobeSelected)) {
							StateElm.click();
							return;
						}
						by = CommonUtility._getObjectLocator("xpath=//kendo-popup//kendo-treeview/ul/li["+iStateCnt+"]/ul/li");
						List<WebElement> Dstlst = WebDriverMain._getElementsWithWait(by);
						//CommonUtility._sleepForGivenTime(500);
						for (int iDstCnt = 1; iDstCnt <=Dstlst.size(); iDstCnt++) {
							by = CommonUtility._getObjectLocator("xpath=//kendo-popup//kendo-treeview/ul/li["+iStateCnt+"]/ul/li["+iDstCnt+"]/div/span[contains(@class,'k-in')]");
							WebElement DstElm=WebDriverMain._getElementWithWait(by);
							String DstStr = DstElm.getText();
							 if (DstStr.contains("\n")) 
								 DstStr=DstStr.replace("\n", "");
							if (DstStr.contains(FS_Dst)) {
								System.out.println("District:"+DstStr);
								if (DstStr.contains(OrgtobeSelected)) {
									DstElm.click();
									System.out.println("Selected District:"+DstStr);
									return;
								}
								
								 System.out.println("Selected DstStr:"+DstStr);
								by = CommonUtility._getObjectLocator("xpath=//kendo-popup//kendo-treeview/ul/li["+iStateCnt+"]/ul/li["+iDstCnt+"]/ul/li");
								List<WebElement> Schlst = WebDriverMain._getElementsWithWait(by);
								//CommonUtility._sleepForGivenTime(500);
								for (int iSchCnt = 1; iSchCnt <= Schlst.size(); iSchCnt++) {
									by = CommonUtility._getObjectLocator("xpath=//kendo-popup//kendo-treeview/ul/li["+iStateCnt+"]/ul/li["+iDstCnt+"]/ul/li["+iSchCnt+"]/div/span[contains(@class,'k-in')]");
									WebElement SchElm=WebDriverMain._getElementWithWait(by);
									String SchStr = SchElm.getText();
									 if (SchStr.contains("\n")) 
										 SchStr=SchStr.replace("\n", "");
									if ((SchStr.contains(FS_Schl))&&(SchStr.contains(OrgtobeSelected))) {
										 System.out.println("Selected School:"+SchStr);
										SchElm.click();
										CommonUtility._sleepForGivenTime(1000);
										return;
									}
								}
							}
						}
					}
				}
				
			} 
			

		}
		
		

	}
	
	
	/**
	 * Function Name :- GetStatefromOrgName<br>
	 * Description :- Get State Organization details
	 * 
	 * @return String
	 * @throws IOException
	 */
	public String GetStatefromOrgName(String OrgName) throws IOException {
		String ConfState=null;
		//OrgName="State>Dst>Sch";
		String[] arrOrg = OrgName.split(">");
		if (arrOrg.length >=1) {
			ConfState= arrOrg[0].trim();
		}
		return ConfState;
	}


	
	/**
	 * Function Name :- ChangeOrgAndRefresh<br>
	 * Description :- Change Organization details
	 * 
	 * @return String
	 * @throws IOException
	 */
	public boolean ChangeOrgAndRefresh() throws IOException {
		boolean ConfState=false;
		Func_ChangeOrganization("Virginia>District 1");
		WebDriverMain._getDriver().navigate().refresh();
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(1000);
		Func_ChangeOrganization("Virginia");
		return ConfState;
	}
	
	/**
	 * Function Name :- PageRefresh<br>
	 * Description :- PageRefresh
	 * 
	 * @throws IOException
	 */
	public void PageRefresh() throws IOException {
		WebDriverMain._getDriver().navigate().refresh();
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(2000);
	}
	
	/**
	 * Function Name :- AppendUrlDirectPageNavigate<br>
	 * Description :- Append URL PageRefresh
	 * 
	 * @throws IOException
	 */
	public void AppendUrlDirectPageNavigate() throws IOException {
		//WebDriverMain._getDriver().navigate().refresh();
		String URL=WebDriverMain._getDriver().getCurrentUrl();
		//WebDriverMain._get(URL+"org/d3d6bc4e-2bb1-41b2-865b-52c0a6c23e75/home/views");
		System.out.println("URL : " + URL );
		if (URL.contains("views/list"))
			WebDriverMain._get(URL+"/details/create");
		else
			WebDriverMain._get(URL+"/list/details/create");
		CommonFunctions.PleaseWaitAndLoadingMessage();
		CommonUtility._sleepForGivenTime(2000);
	}
	
	
	/**
	 * Function Name :- Func_GetCurrentCusName<br>
	 * Description :- Get Current Customer details
	 * 
	 * @return String
	 * @throws IOException
	 */
	public String Func_GetCurrentCusName() throws IOException {
		String currentAdmin = null;
		CommonUtility._sleepForGivenTime(3000);
		// Customer administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(Cus_Selected))) {
			currentAdmin = WebDriverMain._getTextFromElement(HomePageObjects(Cus_Selected));
		} 
		return currentAdmin;
	}
	
	/**
	 * Function Name :- Func_VerifyCusName<br>
	 * Description :- Get Current Customer details
	 * 
	 * @return String
	 * @throws IOException
	 */
	public boolean Func_VerifyCusName(String CusName) throws IOException {
	//	Map<String, String> AcountDetails = new HashMap<String, String>();
		String currentCus = null;
		CommonUtility._sleepForGivenTime(1000);
		// organization administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(Org_Selected))) {
			currentCus = Func_GetCurrentCusName();
			if (currentCus.contains(CusName))
				return true;
		} 
		return false;
	}
	
	/**
	 * Function Name :- Func_ChangeCustomer<br>
	 * Description :- Compare and change Customer if required
	 * 
	 * @param CusName
	 *            Customer Name
	 * @throws IOException
	 * 
	 */
	public boolean Func_ChangeCustomer(String CusName) throws IOException {
		//Get Current Cus name
		boolean flag=false;
		CommonUtility._sleepForGivenTime(1000);
		String CurrentCusName=Func_GetCurrentCusName();
		// If Cus not provide
		if (!CurrentCusName.contains(CusName)) {
			flag=KendoDropdown._selectByValue(HomePageObjects(Cus_SelectArrow), HomePageObjects(Cus_PopUp_List),CusName);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			CommonUtility._sleepForGivenTime(2000);
			return flag;
		}
		else
			return true;
		
	}
	
	
	/**
	 * Function Name :- Func_CustomerDropdown<br>
	 * Description :- Compare and change Customer if required
	 * 
	 * @param CusName
	 *            Customer Name
	 * @throws IOException
	 * 
	 */
	public List<String> Func_CustomerDropdownList() throws IOException {
		//Get Current Cus name
		List<String> act_options = new ArrayList<String>();
		// Get All Items
		act_options=KendoDropdown._getDropDownOptions(HomePageObjects(Cus_SelectArrow), HomePageObjects(Cus_PopUp_List));
		return act_options;
		
		
	}
	
	/**
	 * Function Name :- Func_GetWelcomeMessage<br>
	 * Description :- Get Welcome Message with User details
	 * 
	 * @return String
	 * @throws IOException
	 */
	public String Func_GetWelcomeMessage() throws IOException {
		String Message = null;
		CommonUtility._sleepForGivenTime(3000);
		// Customer administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(Header_WelcomeMsg))) {
			Message = WebDriverMain._getTextFromElement(HomePageObjects(Header_WelcomeMsg ));
		} 
		return Message;
	}
	
	/**
	 * Function Name :- Func_GetRole<br>
	 * Description :- Get role in Customer
	 * 
	 * @return String
	 * @throws IOException
	 */
	public String Func_GetRole() throws IOException {
		String Message = null;
		CommonUtility._sleepForGivenTime(3000);
		// Customer administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(Header_Role))) {
			Message = WebDriverMain._getTextFromElement(HomePageObjects(Header_Role));
		} 
		return Message;
	}
	
	/**
	 * Function Name :- GetCustomerLogoSrc<br>
	 * Description :- Get customer loco img src
	 * 
	 * @return String
	 * @throws IOException
	 */
	public String GetCustomerLogoSrc() throws IOException
	{
		WebElement delete = WebDriverMain._getElementWithWait(HomePageObjects(Header_LocoImg));
		String attributeText = delete.getAttribute("src");
		return attributeText;
	}
	
	/**
	 * Function Name :- SelectCustomerLogo<br>
	 * Description :- Select customer loco img 
	 * 
	 * @return boolean
	 * @throws IOException
	 */
	public boolean SelectCustomerLogo() throws IOException
	{
		LeftClick._click(HomePageObjects(Header_LocoImg));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- GetProfileIconOptions<br>
	 * Description :- To get the Profile icon options.
	 *
	 */
	public boolean SelectProfileIconOptions() throws IOException {
		if (WebDriverMain._isElementPresent(HomePageObjects(USERICON))) {
			LeftClick._click(HomePageObjects(USERICON));
			if (WebDriverMain._isElementPresent(HomePageObjects(USERDROPDOWN))) {
				return true;
			}
			return false;
		} else {
			return false;
		}
	}
	
	
	/**
	 * Function Name :- CloseProfileIconOptions<br>
	 * Description :- To Close the Profile icon options.
	 *
	 */
	public boolean CloseProfileIconOptions() throws IOException {
		if (WebDriverMain._isElementPresent(HomePageObjects(USERDROPDOWN))) {
			LeftClick._click(HomePageObjects(USERICON));
			return true;
		} else 
			return true;
		
	}
	
	/**
	 * Function Name :- GetProfileIconOptions<br>
	 * Description :- To get the Profile icon options.
	 *
	 */
	public List<String> GetProfileIconOptions() throws IOException {
		List<String> lstProfopts = new ArrayList<String>();
		CommonFunctions.PleaseWaitAndLoadingMessage();
		if (WebDriverMain._isElementPresent(HomePageObjects(USERDROPDOWN))) {
				List<WebElement> lstelm = WebDriverMain._getElementsWithWait(HomePageObjects(USERDROPDOWN));
			for (WebElement elm : lstelm) {
				String strval = elm.getText();
				lstProfopts.add(strval);
			}
			return lstProfopts;
		} else {
			return lstProfopts;
		}
	}
	
	/**
	 * Function Name :- MyAccount<br>
	 * Description :- To Click MyAccount from user dropdown.
	 *
	 */
	public boolean MyAccount() throws IOException {
		LeftClick._click(HomePageObjects(USERICON));
		CommonUtility._sleepForGivenTime(1000);
		if (WebDriverMain._isElementPresent(HomePageObjects(USERDROPDOWN))) {
			LeftClick._click(HomePageObjects(MyAccount));
			CommonUtility._sleepForGivenTime(1000);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			return true;
		}
		return false;
	}
	
	
	/**
	 * Function Name :- VerifyMyccountDialog<br>
	 * Description :- To verify the Myccount Dialog opens.
	 *
	 */
	public boolean VerifyMyccountDialog() throws IOException {
		if (WebDriverMain._isElementPresent(HomePageObjects(MyAccDlg))) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Function Name :- Func_GetOrgNRoles<br>
	 * Description :- Get Org and roles in My Account details
	 * 
	 * @return List<String>
	 * @throws IOException
	 */
	public List<String> Func_GetOrgNRoles() throws IOException {
		String Message = null;
		List<String> lstOrgRoles = new ArrayList<String>();
		CommonUtility._sleepForGivenTime(3000);
		// get dialog title
		if (WebDriverMain._isElementPresent(HomePageObjects(MyAccDlg))) {
			List<WebElement> orgRoleslstelm = WebDriverMain._getElementsWithWait(HomePageObjects(MyAccDlgTitle_OrgRoles));
			for (WebElement orgRoleelm : orgRoleslstelm) {
				String strorgRole = orgRoleelm.getText();
				lstOrgRoles.add(strorgRole.toUpperCase());
			}
		} 
		return lstOrgRoles;
	}
	
	/**
	 * Function Name :- Func_VerifyMyAccountTitle<br>
	 * Description :- Verify Title in My Account details
	 * 
	 * @return String
	 * @throws IOException
	 */
	public boolean Func_VerifyMyAccountTitle(String title) throws IOException {
		String Message = null;
		CommonUtility._sleepForGivenTime(3000);
		// Customer administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(MyAccDlg))) {
			Message = WebDriverMain._getTextFromElement(HomePageObjects(MyAccDlgTitle));
			if (Message.contains(title)) {
				return true;
			}
		} 
		return false;
	}
	
	/**
	 * Function Name :- verifyUserLabel<br>
	 * Description :- To verify the label on User details page form.
	 *
	 */
	public boolean verifyUserLabel(String labelmessage) throws IOException{
		By objlocator = CommonUtility._getObjectLocator("xpath=//div[@role='tabpanel']//label[contains(text(),'"+labelmessage+"')]");
		if (WebDriverMain._isElementVisible(objlocator))
			return true;
		else
			return false;
	}
	
	/**
	 * Function Name :- GetValueforUserLabel<br>
	 * Description :- To get the value for label on User details page form.
	 *
	 */
	public String GetValueforUserLabel(String labelmessage) throws IOException{
		String LabelValue=null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//div[@role='tabpanel']//label[contains(text(),'"+labelmessage+"')]/./following-sibling::p");
		if (WebDriverMain._isElementVisible(objlocator)) {
			LabelValue=WebDriverMain._getTextFromElement(objlocator);
			return LabelValue;
		
		}
		return LabelValue;
	}
	
	/**
	 * Function Name :- SelectMyAccountTabOption<br>
	 * Description :- Select the Tab options
	 * 
	 * @param Primary,
	 * @throws IOException
	 */
	public boolean SelectMyAccountTabOption(String TabOption) throws IOException {
		boolean flag=false;
		if (WebDriverMain._isElementPresent(HomePageObjects(MyAccDlg_Tabs))) {
			switch (TabOption.toLowerCase()) {
				case "nameactivity":
					flag=LeftClick._click(HomePageObjects(MyAccDlg_Tab_Detail));
					CommonUtility._sleepForGivenTime(1000);
					break;
				case "security":
					flag=LeftClick._click(HomePageObjects(MyAccDlg_Tab_Security));
					CommonUtility._sleepForGivenTime(1000);
					break;
				case "passwordreset":
					flag=LeftClick._click(HomePageObjects(MyAccDlg_Tab_PwdReset));
					CommonUtility._sleepForGivenTime(1000);
					break;
				
				default:
					flag=LeftClick._click(HomePageObjects(MyAccDlg_Tab_Detail));
					CommonUtility._sleepForGivenTime(1000);
					break;
			}
		}
		else
			return false;
		return flag;

	}
	
	/**
	 * Function Name :- UserEditButton_isVisible<br>
	 * Description :- To verify Edit button is visible
	 */
	public boolean EditButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(HomePageObjects(MyAccDlg_Edit)))
			return true;
		else
			return false;
	
	}
	/**
	 * Function Name :- EditButton_isEnabled<br>
	 * Description :- To verify Edit button is enabled
	 *
	 */
	public boolean EditButton_isEnabled() throws IOException{
		
		WebElement delete = WebDriverMain._getElementWithWait(HomePageObjects(MyAccDlg_Edit));
		String attributeText = delete.getAttribute("outerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
		
	}
	
	/**
	 * Function Name :- clickEditButton<br>
	 * Description :- To click the Edit User button.
	 *
	 */
	public boolean clickEditButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(HomePageObjects(MyAccDlg_Edit));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- CanceltButton_isVisible<br>
	 * Description :- To verify Cancel button is visible
	 */
	public boolean CanceltButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(HomePageObjects(MyAccDlg_Cancel)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- clickCancelButton<br>
	 * Description :- To click the Cancel User button.
	 *
	 */
	public boolean clickCancelButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(HomePageObjects(MyAccDlg_Cancel));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- CloseButton_isVisible<br>
	 * Description :- To verify Close button is visible
	 */
	public boolean CloseButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(HomePageObjects(MyAccDlg_Close)))
			return true;
		else
			return false;
	
	}
	
	/**
	 * Function Name :- clickCloseButton<br>
	 * Description :- To click the Close User button.
	 *
	 */
	public boolean clickCloseButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(HomePageObjects(MyAccDlg_Close));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	

	/**
	 * Function Name :- SaveButton_isVisible<br>
	 * Description :- To verify Save button is visible
	 */
	public boolean SaveButton_isVisible() throws Exception{
		if (WebDriverMain._isElementVisible(HomePageObjects(MyAccDlg_Save)))
			return true;
		else
			return false;
	
	}
	/**
	 * Function Name :- SaveButton_isEnabled<br>
	 * Description :- To verify Edit button is enabled
	 *
	 */
	public boolean SaveButton_isEnabled() throws IOException{
		
		WebElement delete = WebDriverMain._getElementWithWait(HomePageObjects(MyAccDlg_Save));
		String attributeText = delete.getAttribute("outerHTML");
		if(attributeText.contains("disabled"))
			return false;
		else
			return true;
		
	}
	
	/**
	 * Function Name :- clickSaveButton<br>
	 * Description :- To click the Edit User button.
	 *
	 */
	public boolean clickSaveButton() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(HomePageObjects(MyAccDlg_Save));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- verifySuccessMessage<br>
	 * Description :- To verify Success Message
	 * @throws IOException 
	 */
	public boolean verifySuccessMessage(String successmessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess=WebDriverMain._getTextFromElement(HomePageObjects(Success_Message));
		if(textSuccess.toLowerCase().contains(successmessage.toLowerCase())){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Function Name :- GetAlertMessage<br>
	 * Description :- To get alert Message
	 * @throws IOException 
	 */
	public String GetAlertMessage() throws IOException{
		String textSuccess=null;
		CommonUtility._sleepForGivenTime(2000);
		textSuccess=WebDriverMain._getTextFromElement(HomePageObjects(Success_Message));
		return textSuccess;
	}
	
	/**
	 * Function Name :- Verify_Session_StudentList<br>
	 * Description :- To verify Session Student List  is visible
	 *
	 */
	public boolean Close_Alerts() throws IOException{
		
		List<WebElement> lstAlertsRow = WebDriverMain._getElementsWithWait(HomePageObjects(CloseAlerts));
		for (WebElement AlertEle : lstAlertsRow) {
			if (WebDriverMain._isElementClickable(AlertEle)) {
				//CommonUtility._scrollElement(AlertEle);
				CommonUtility._sleepForGivenTime(300);
				AlertEle.click();
				CommonUtility._sleepForGivenTime(1000);
			}
		}
		return true;
	}

	/**
	 * Function Name :- verifyViewUserDetails<br>
	 * Description :- To verify the view  User details Page 
	 * @throws IOException 
	 */	
	public boolean verifyViewUserDetails(HashMap<String,String> MapFilledField) throws IOException{
		boolean verifedFlag=true;
		HashMap<String, String> MapDgStuRec = new HashMap<String, String>();
		try{
			
			By objlocator=null;
			for (Map.Entry<String,String> entry : MapFilledField.entrySet()){
	            System.out.println("INFO ViewMap - Fields  : " + entry.getKey() );
	            String sFieldLabel= entry.getKey();
	            String sFieldValue= entry.getValue();
	            
	            if (sFieldLabel.length()>1) {
		            objlocator = CommonUtility._getObjectLocator("xpath=//div[@role='tabpanel']//label[contains(text(),'"+sFieldLabel+"')]");
					boolean isFieldLabelPresent=WebDriverMain._isElementPresent(objlocator);
					if (isFieldLabelPresent) {
						if(sFieldValue.length()>1) { 
							MapDgStuRec.put(sFieldLabel, sFieldValue);
							objlocator = CommonUtility._getObjectLocator("xpath=//div[@role='tabpanel']//label[contains(text(),'"+sFieldLabel+"')]/./following-sibling::p[contains(text(),'"+sFieldValue+"')]");
							boolean isFieldValuePresent=WebDriverMain._isElementPresent(objlocator);
							if (!isFieldValuePresent) {
								verifedFlag=false;
								UMReporter.log(Status.FAIL, "The field "+sFieldLabel+" not matched with expected value : " +sFieldValue);
							}
						}
					}
	            }
			}
		}
		catch(NoSuchElementException e){
			e.printStackTrace();
		}
		
		if (verifedFlag)
			UMReporter.log(Status.PASS,"Verified the User field value in User details page :"+MapDgStuRec);
		return verifedFlag;
	}
	
	/**
	 * Function Name :- waitLoadingspinner_Invisible<br>
	 * Description :- To wait Loadingspinner is not visible
	 */
	public boolean waitLoadingspinner_Invisible() throws Exception{
		int timer=0;
		int maxtimer=20;
		while((WebDriverMain._isElementVisible(HomePageObjects(lodingspinner)))&&(timer<maxtimer))
		{
			CommonUtility._sleepForGivenTime(1000);
			timer=timer+1;
		}
		if (WebDriverMain._isElementVisible(HomePageObjects(lodingspinner)))
			return false;
		else
			return true;
	}
	
	/**
	 * Function Name :- SelectWidgetAdministration<br>
	 * Description :- Select Administration
	 * 
	 * @param AdminName
	 * @throws Exception 
	 * 
	 */
	public boolean SelectWidgetAdministration(String WidgetTitle, String AdminName) throws Exception {

		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dropdownlist[@name='testAdmin']//span[@class='k-input']");
		//Get Current selected
		String selectedText=KendoDropdown._getSelectedVisibleText(objlocator);
		// If already exist
		if (!selectedText.equalsIgnoreCase(AdminName)) {
			flag=KendoDropdown._selectByValue(objlocator,HomePageObjects(popupdropdownlist),AdminName);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			flag=waitLoadingspinner_Invisible();
			CommonUtility._sleepForGivenTime(1000);
			return flag;
		}
		else {
			flag=waitLoadingspinner_Invisible();
			return true;
		}
		
		
	}
	
	/**
	 * Function Name :- SelectWidgetGrade<br>
	 * Description :- Select Grade
	 * 
	 * @param Grade
	 * @throws Exception 
	 * 
	 */
	public boolean SelectWidgetGrade(String WidgetTitle, String Grade) throws Exception {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dropdownlist[@name='grade']//span[@class='k-input']");
		//Get Current selected
		String selectedText=KendoDropdown._getSelectedVisibleText(objlocator);
		// If already exist
		if (!selectedText.equalsIgnoreCase(Grade)) {
			flag=KendoDropdown._selectByValue(objlocator,HomePageObjects(popupdropdownlist),Grade);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			flag=waitLoadingspinner_Invisible();
			CommonUtility._sleepForGivenTime(1000);
			return flag;
		}
		else {
			flag=waitLoadingspinner_Invisible();
			return true;
		}
		
	}
	
	/**
	 * Function Name :- SelectWidgetSubject<br>
	 * Description :- Select Subject
	 * 
	 * @param Subject
	 * @throws Exception 
	 * 
	 */
	public boolean SelectWidgetSubject(String WidgetTitle, String Subject) throws Exception {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dropdownlist[@name='subject']//span[@class='k-input']");
		//Get Current selected
		String selectedText=KendoDropdown._getSelectedVisibleText(objlocator);
		// If already exist
		if (!selectedText.equalsIgnoreCase(Subject)) {
			flag=KendoDropdown._selectByValue(objlocator,HomePageObjects(popupdropdownlist),Subject);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			flag=waitLoadingspinner_Invisible();
			CommonUtility._sleepForGivenTime(1000);
			return flag;
		}
		else {
			flag=waitLoadingspinner_Invisible();
			return true;
		}
		
	}
	
	/**
	 * Function Name :- SelectWidgetSubject<br>
	 * Description :- Select Subject
	 * 
	 * @param Subject
	 * @throws Exception 
	 * 
	 */
	public boolean SelectWidgetTestname(String WidgetTitle, String Testname) throws Exception {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//kendo-dropdownlist[@name='test']//span[@class='k-input']");
		//Get Current selected
		String selectedText=KendoDropdown._getSelectedVisibleText(objlocator);
		// If already exist
		if (!selectedText.equalsIgnoreCase(Testname)) {
			flag=KendoDropdown._selectByValue(objlocator,HomePageObjects(popupdropdownlist),Testname);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			flag=waitLoadingspinner_Invisible();
			CommonUtility._sleepForGivenTime(1000);
			return flag;
		}
		else {
			flag=waitLoadingspinner_Invisible();
			return true;
		}
		
	}
	
	/**
	 * Function Name :- SelectWidgetSession<br>
	 * Description :- Select Session
	 * 
	 * @param Grade
	 * @throws Exception 
	 * 
	 */
	public boolean SelectWidgetSession(String WidgetTitle, String Session) throws Exception {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../..//kendo-combobox//kendo-searchbar/input[@class='k-input']");
		//Get Current selected
		String selectedText=KendoDropdown._getSelectedVisibleText(objlocator);
		// If already exist
		if (!selectedText.equalsIgnoreCase(Session)) {
			flag=KendoDropdown._selectByValue(objlocator,HomePageObjects(popupdropdownlist),objlocator,Session);
			CommonFunctions.PleaseWaitAndLoadingMessage();
			flag=waitLoadingspinner_Invisible();
			CommonUtility._sleepForGivenTime(1000);
			return flag;
		}
		else {
			flag=waitLoadingspinner_Invisible();
			return true;
		}
		
	}
	
	/**
	 * Function Name :- GetWidgetContent<br>
	 * Description :- Get Widget Content.
	 * 
	 * @return boolean
	 */
	public List<Map<String, String>> GetArcWidgetContent(String WidgetTitle) throws IOException {
		boolean flag=false;
		
		Map<String, String> mapWidCard = null;
		 List<Map<String, String>> lstWidCards = null;
	 
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			By objsublocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']");
			WebElement targetElement = WebDriverMain._getElementWithWait(objsublocator);
			if (targetElement != null) {
				try{
					//CommonUtility._scrollElement(targetElement);
					By NoDatalocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(text(),'No data to display')]");
					WebElement NoDataElement = WebDriverMain._getElementWithWait(objsublocator);
					//Check if No data to display
					if (!WebDriverMain._isElementVisible(NoDatalocator)) {
						By CardBodylocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]");
						//Get list of subjects
						List<WebElement> lstCardElement =WebDriverMain._getElementsWithWait(CardBodylocator);
						if (lstCardElement != null) {
							//mapWidCard = new HashMap<String, String>();
							lstWidCards = new ArrayList<Map<String, String>>();
	//						for (WebElement CardElement:lstCardElement) {
							for (int icardCnt = 1; icardCnt <= lstCardElement.size(); icardCnt++) {
								mapWidCard = new HashMap<String, String>();
								System.out.println("icardCnt : "+icardCnt);
								By CardTitlelocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]");
								By CardLeftlinklocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]/../../..//div/div[1]/button[contains(@class,'btn-link')]/div[1]");
								By CardLeftLbllocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]/../../..//div/div[1]/button[contains(@class,'btn-link')]/div[2]");
								By Cardrightlinklocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]/../../..//div/div[2]/button[contains(@class,'btn-link')]/div[1]");
								By CardrightLbllocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]/../../..//div/div[2]/button[contains(@class,'btn-link')]/div[2]");
				
//								String strCardtitle=WebDriverMain._getTextFromElement(CardTitlelocator);
//								String strCardLeftlink=WebDriverMain._getTextFromElement(CardLeftlinklocator);
//								String strCardLeftLbl=WebDriverMain._getTextFromElement(CardLeftLbllocator);
//								String strCardrightlink=WebDriverMain._getTextFromElement(Cardrightlinklocator);
//								String strCardrightLbl=WebDriverMain._getTextFromElement(CardrightLbllocator);
//								
								WebElement CardTitleElement=WebDriverMain._getElementWithWait(CardTitlelocator);
								String strCardtitle = CardTitleElement.getText();
								//Left link and label
								WebElement CardLeftlinkElement=WebDriverMain._getElementWithWait(CardLeftlinklocator);
								String strCardLeftlink = CardLeftlinkElement.getText();
								WebElement CardLeftLblElement=WebDriverMain._getElementWithWait(CardLeftLbllocator);
								String strCardLeftLbl = CardLeftLblElement.getText();
								//Right link and label
								WebElement CardrightlinkElement=WebDriverMain._getElementWithWait(Cardrightlinklocator);
								String strCardrightlink = CardrightlinkElement.getText();
								WebElement CardrightLblElement=WebDriverMain._getElementWithWait(CardrightLbllocator);
								String strCardrightLbl = CardrightLblElement.getText();
								
								mapWidCard.put("subject", strCardtitle);
								mapWidCard.put(strCardLeftLbl, strCardLeftlink);
								mapWidCard.put(strCardrightLbl, strCardrightlink);
								System.out.println("Cardtitle : "+strCardtitle);
								System.out.println("Card details : "+mapWidCard);
								lstWidCards.add(mapWidCard);
							}	
							System.out.println("Lst Card details : "+lstWidCards);
						}
				}
				else 
					//No data to display
					return lstWidCards;
					
			}
			catch(Exception e){
					return lstWidCards;
			}
		}
	}
	return lstWidCards;
		
	}
	
	/**
	 * Function Name :- GetTestingInfoArcWidgetContent<br>
	 * Description :- Get Testing Info Widget Content.
	 * 
	 * @return boolean
	 */
	public Map<String, String> GetTestingInfoArcWidgetContent(String WidgetInfo,String WidgetTitle, String Widget) throws IOException {
		boolean flag=false;
		Map<String, String> mapWidCard = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetInfo+"')]/../../../..//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			try{
				//CommonUtility._scrollElement(targetElement);
				By NoDatalocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(text(),'No data to display')]");
				//Check if No data to display
				if (!WebDriverMain._isElementVisible(NoDatalocator)) {
					mapWidCard = new HashMap<String, String>();
					By CardTitlelocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]");
					By CardLeftlinklocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]/../../../..//div/div[1]/button[contains(@class,'btn-link')]/div[1]");
					By CardLeftLbllocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]/../../../..//div/div[1]/button[contains(@class,'btn-link')]/div[2]");
					By Cardrightlinklocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]/../../../..//div/div[2]/button[contains(@class,'btn-link')]/div[1]");
					By CardrightLbllocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]/../../../..//div/div[2]/button[contains(@class,'btn-link')]/div[2]");
					
					//Title
					WebElement CardTitleElement=WebDriverMain._getElementWithWait(CardTitlelocator);
					String strCardtitle = CardTitleElement.getText();
					
					//Left link and label
					WebElement CardLeftlinkElement=WebDriverMain._getElementWithWait(CardLeftlinklocator);
					String strCardLeftlink = CardLeftlinkElement.getText();
					WebElement CardLeftLblElement=WebDriverMain._getElementWithWait(CardLeftLbllocator);
					String strCardLeftLbl = CardLeftLblElement.getText();
					//Right link and label
					WebElement CardrightlinkElement=WebDriverMain._getElementWithWait(Cardrightlinklocator);
					String strCardrightlink = CardrightlinkElement.getText();
					WebElement CardrightLblElement=WebDriverMain._getElementWithWait(CardrightLbllocator);
					String strCardrightLbl = CardrightLblElement.getText();
					
					mapWidCard.put("Widget", strCardtitle);
					mapWidCard.put(strCardLeftLbl, strCardLeftlink);
					mapWidCard.put(strCardrightLbl, strCardrightlink);
					System.out.println("Card details : "+mapWidCard);
			}
			else 
				//No data to display
				return mapWidCard;
			}
			catch(Exception e){
				return mapWidCard;
			}
		}
		return mapWidCard;
	}
	
	
	/**
	 * Function Name :- SelectTestingInfoArcWidgetContent<br>
	 * Description :- Select Testing Info Widget Content.
	 * 
	 * @return boolean
	 */
	public Map<String, String> SelectTestingInfoArcWidgetContent(String WidgetInfo,String WidgetTitle, String Widget,String Selectstatus) throws IOException {
		boolean flag=false;
		Map<String, String> mapWidCard = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetInfo+"')]/../../../..//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			try{
				//CommonUtility._scrollElement(targetElement);
				By NoDatalocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(text(),'No data to display')]");
				//Check if No data to display
				if (!WebDriverMain._isElementVisible(NoDatalocator)) {
					mapWidCard = new HashMap<String, String>();
					By CardTitlelocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]");
					By CardLeftlinklocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]/../../../..//div/div[1]/button[contains(@class,'btn-link')]/div[1]");
					By CardLeftLbllocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]/../../../..//div/div[1]/button[contains(@class,'btn-link')]/div[2]");
					By Cardrightlinklocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]/../../../..//div/div[2]/button[contains(@class,'btn-link')]/div[1]");
					By CardrightLbllocator = CommonUtility._getObjectLocator("xpath=//pa-dashboard-arc-gauge//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]/../../../..//div/div[2]/button[contains(@class,'btn-link')]/div[2]");
					
					//Title
					WebElement CardTitleElement=WebDriverMain._getElementWithWait(CardTitlelocator);
					String strCardtitle = CardTitleElement.getText();
					
					//Left link and label
					WebElement CardLeftlinkElement=WebDriverMain._getElementWithWait(CardLeftlinklocator);
					String strCardLeftlink = CardLeftlinkElement.getText();
					WebElement CardLeftLblElement=WebDriverMain._getElementWithWait(CardLeftLbllocator);
					String strCardLeftLbl = CardLeftLblElement.getText();
					//Right link and label
					WebElement CardrightlinkElement=WebDriverMain._getElementWithWait(Cardrightlinklocator);
					String strCardrightlink = CardrightlinkElement.getText();
					WebElement CardrightLblElement=WebDriverMain._getElementWithWait(CardrightLbllocator);
					String strCardrightLbl = CardrightLblElement.getText();
					
					mapWidCard.put("Widget", strCardtitle);
					mapWidCard.put(strCardLeftLbl, strCardLeftlink);
					mapWidCard.put(strCardrightLbl, strCardrightlink);
					System.out.println("Card details : "+mapWidCard);
					if (strCardLeftLbl.equalsIgnoreCase(Selectstatus)) {
						if ((strCardLeftlink.equalsIgnoreCase("0"))||(strCardLeftlink.equalsIgnoreCase("nan")))
							//return null;
							System.out.println(strCardLeftLbl+" count "+strCardLeftlink);
						else {	
							LeftClick._click(CardLeftlinklocator);
							CommonFunctions.PleaseWaitAndLoadingMessage();
							return mapWidCard;
						}
					}
					else if (strCardrightLbl.equalsIgnoreCase(Selectstatus)) {
						if ((strCardrightlink.equalsIgnoreCase("0"))||(strCardrightlink.equalsIgnoreCase("nan")))
							//return null;
							System.out.println(strCardrightLbl+" count "+strCardrightlink);
						else {	
							LeftClick._click(Cardrightlinklocator);
							CommonFunctions.PleaseWaitAndLoadingMessage();
							return mapWidCard;
						}
					}
			}
			else 
				//No data to display
				return mapWidCard;
			}
			catch(Exception e){
				return mapWidCard;
			}
		}
		return mapWidCard;
	}
	
	/**
	 * Function Name :- SelectWidgetContent<br>
	 * Description :- Select Widget Count by status.
	 * 
	 * @return Map<String, String>
	 */
	public Map<String, String> SelectArcWidgetContent(String WidgetTitle,String Selectstatus) throws IOException {
		boolean flag=false;
		Map<String, String> mapWidCard = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			By objsublocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']");
			WebElement targetElement = WebDriverMain._getElementWithWait(objsublocator);
			if (targetElement != null) {
				try{
					//CommonUtility._scrollElement(targetElement);
					By NoDatalocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(text(),'No data to display')]");
					//Check if No data to display
					if (!WebDriverMain._isElementPresent(NoDatalocator)) {
						By CardBodylocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]");
						//Get list of subjects
						List<WebElement> lstCardElement =WebDriverMain._getElementsWithWait(CardBodylocator);
						if (lstCardElement != null) {
							mapWidCard = new HashMap<String, String>();
	//						for (WebElement CardElement:lstCardElement) {
							for (int icardCnt = 1; icardCnt <= lstCardElement.size(); icardCnt++) {	
								System.out.println("Widget card : "+icardCnt);
								By CardTitlelocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]");
								By CardLeftlinklocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]/../../..//div/div[1]/button[contains(@class,'btn-link')]/div[1]");
								By CardLeftLbllocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]/../../..//div/div[1]/button[contains(@class,'btn-link')]/div[2]");
								By Cardrightlinklocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]/../../..//div/div[2]/button[contains(@class,'btn-link')]/div[1]");
								By CardrightLbllocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//h3[contains(@class,'card-title')]/../../..//div/div[2]/button[contains(@class,'btn-link')]/div[2]");
				
								WebElement CardTitleElement=WebDriverMain._getElementWithWait(CardTitlelocator);
								String strCardtitle = CardTitleElement.getText();
								//Left link and label
								WebElement CardLeftlinkElement=WebDriverMain._getElementWithWait(CardLeftlinklocator);
								String strCardLeftlink = CardLeftlinkElement.getText();
								WebElement CardLeftLblElement=WebDriverMain._getElementWithWait(CardLeftLbllocator);
								String strCardLeftLbl = CardLeftLblElement.getText();
								//Right link and label
								WebElement CardrightlinkElement=WebDriverMain._getElementWithWait(Cardrightlinklocator);
								String strCardrightlink = CardrightlinkElement.getText();
								WebElement CardrightLblElement=WebDriverMain._getElementWithWait(CardrightLbllocator);
								String strCardrightLbl = CardrightLblElement.getText();
								
								mapWidCard.put("subject", strCardtitle);
								mapWidCard.put(strCardLeftLbl, strCardLeftlink);
								mapWidCard.put(strCardrightLbl, strCardrightlink);
								
								System.out.println("Cardtitle : "+strCardtitle);
								System.out.println("Card Details : "+mapWidCard);
								
								if (strCardLeftLbl.equalsIgnoreCase(Selectstatus)) {
									if ((strCardLeftlink.equalsIgnoreCase("0"))||(strCardLeftlink.equalsIgnoreCase("nan")))
										//return null;
										System.out.println(strCardLeftLbl+" count "+strCardLeftlink);
									else {	
										LeftClick._click(CardLeftlinklocator);
										CommonFunctions.PleaseWaitAndLoadingMessage();
										return mapWidCard;
									}
								}
								else if (strCardrightLbl.equalsIgnoreCase(Selectstatus)) {
									if ((strCardrightlink.equalsIgnoreCase("0"))||(strCardrightlink.equalsIgnoreCase("nan")))
										//return null;
										System.out.println(strCardrightLbl+" count "+strCardrightlink);
									else {	
										LeftClick._click(Cardrightlinklocator);
										CommonFunctions.PleaseWaitAndLoadingMessage();
										return mapWidCard;
									}
								}
							}
							return null;
						}
				}
				else 
					//No data to display
					return mapWidCard;
					
			}
			catch(Exception e){
					return mapWidCard;
			}
		}
	}
	return mapWidCard;
		
	}
	
	/**
	 * Function Name :- GetSessionOverviewWidgetContent<br>
	 * Description :- Get Widget Content.
	 * 
	 * @return Map<String, String> 
	 */
	public Map<String, String> GetSessionOverviewWidgetContent(String WidgetTitle) throws IOException {
		boolean flag=false;
		
		Map<String, String> mapWidCard = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			By objsublocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']");
			WebElement targetElement = WebDriverMain._getElementWithWait(objsublocator);
			if (targetElement != null) {
				try{
					By NoDatalocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(text(),'No data to display')]");
					WebElement NoDataElement = WebDriverMain._getElementWithWait(objsublocator);
					//Check if No data to display
					if (!WebDriverMain._isElementVisible(NoDatalocator)) {
						By CardBodylocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'subject-cards-row')]//div[contains(@class,'status-cards-col')]");
						//Get list of subjects
						List<WebElement> lstCardElement =WebDriverMain._getElementsWithWait(CardBodylocator);
						if (lstCardElement != null) {
							mapWidCard = new HashMap<String, String>();
							//Total
							By CardStudTotStatuslocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col')]//button[contains(text(),'Student Tests in Total')]");
							By CardStudTotCountlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col')]//button[contains(text(),'Student Tests in Total')]//div[@class='count-lg']");
							
							WebElement CardStudTotStatusElement=WebDriverMain._getElementWithWait(CardStudTotStatuslocator);
							String strCardStudTotStatus = CardStudTotStatusElement.getText();
					
							WebElement CardStudTotCnttlnkElement=WebDriverMain._getElementWithWait(CardStudTotCountlocator);
							String strStudTotCnt = CardStudTotCnttlnkElement.getText();
							mapWidCard.put(strCardStudTotStatus, strStudTotCnt);
							
							//ready
							By CardStudreadylocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Ready')]");
							By CardStudreadyCountlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Ready')]//div[@class='count-sm']");
							
							WebElement CardStudreadyStatusElement=WebDriverMain._getElementWithWait(CardStudreadylocator);
							String strCardStudreadyStatus = CardStudreadyStatusElement.getText();
					
							WebElement CardStudreadyCnttlnkElement=WebDriverMain._getElementWithWait(CardStudreadyCountlocator);
							String strStudreadyCnt = CardStudreadyCnttlnkElement.getText();
							mapWidCard.put(strCardStudreadyStatus, strStudreadyCnt);
							
							//Active
							By CardStudactivelocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Active')]");
							By CardStudactiveCountlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Active')]//div[@class='count-sm']");
							
							WebElement CardStudactiveStatusElement=WebDriverMain._getElementWithWait(CardStudactivelocator);
							String strCardStudactiveStatus = CardStudactiveStatusElement.getText();
					
							WebElement CardStudactiveCnttlnkElement=WebDriverMain._getElementWithWait(CardStudactiveCountlocator);
							String strStudactiveCnt = CardStudactiveCnttlnkElement.getText();
							mapWidCard.put(strCardStudactiveStatus, strStudactiveCnt);
							
							//Exited
							By CardStudExitedlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Exited')]");
							By CardStudExitedCountlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Exited')]//div[@class='count-sm']");
							
							WebElement CardStudExitedStatusElement=WebDriverMain._getElementWithWait(CardStudExitedlocator);
							String strCardStudExitedStatus = CardStudExitedStatusElement.getText();
					
							WebElement CardStudExitedCnttlnkElement=WebDriverMain._getElementWithWait(CardStudExitedCountlocator);
							String strStudExitedCnt = CardStudExitedCnttlnkElement.getText();
							mapWidCard.put(strCardStudExitedStatus, strStudExitedCnt);
							
							//Resumed
							By CardStudResumedlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Resumed')]");
							By CardStudResumedCountlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Resumed')]//div[@class='count-sm']");
							
							WebElement CardStudResumedStatusElement=WebDriverMain._getElementWithWait(CardStudResumedlocator);
							String strCardStudResumedStatus = CardStudResumedStatusElement.getText();
					
							WebElement CardStudResumedCnttlnkElement=WebDriverMain._getElementWithWait(CardStudResumedCountlocator);
							String strStudResumedCnt = CardStudResumedCnttlnkElement.getText();
							mapWidCard.put(strCardStudResumedStatus, strStudResumedCnt);
							
							//Completed
							By CardStudCompletedlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Completed')]");
							By CardStudCompletedCountlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'status-cards-col multi')]//button[contains(text(),'Completed')]//div[@class='count-sm']");
							
							WebElement CardStudCompletedStatusElement=WebDriverMain._getElementWithWait(CardStudCompletedlocator);
							String strCardStudCompletedStatus = CardStudCompletedStatusElement.getText();
					
							WebElement CardStudCompletedCnttlnkElement=WebDriverMain._getElementWithWait(CardStudCompletedCountlocator);
							String strStudCompletedCnt = CardStudCompletedCnttlnkElement.getText();
							mapWidCard.put(strCardStudCompletedStatus, strStudCompletedCnt);	
						}	
							System.out.println("Card details : "+mapWidCard);
						}
				
				else 
					//No data to display
					return mapWidCard;
					
			}
			catch(Exception e){
					return mapWidCard;
			}
		}
	}
	return mapWidCard;
		
	}
	
	/**
	 * Function Name :- SelectStatusSessionOverviewWidgetContent<br>
	 * Description :- Select Widget Content.
	 * 
	 * @return Map<String, String> 
	 */
	public Map<String, String> SelectStatusSessionOverviewWidgetContent(String WidgetTitle, String TestStatus) throws IOException {
		boolean flag=false;
		
		Map<String, String> mapWidCard = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			By objsublocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']");
			WebElement targetElement = WebDriverMain._getElementWithWait(objsublocator);
			if (targetElement != null) {
				try{
					By NoDatalocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(text(),'No data to display')]");
					WebElement NoDataElement = WebDriverMain._getElementWithWait(objsublocator);
					//Check if No data to display
					if (!WebDriverMain._isElementVisible(NoDatalocator)) {
						By CardBodylocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'subject-cards-row')]//div[contains(@class,'status-cards-col')]");
						//Get list of subjects
						List<WebElement> lstCardElement =WebDriverMain._getElementsWithWait(CardBodylocator);
						if (lstCardElement != null) {
							mapWidCard = new HashMap<String, String>();
							
							//Total
							By CardStudTotStatuslocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//button[contains(text(),'"+TestStatus+"')]");
							By CardStudTotCountlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//button[contains(text(),'"+TestStatus+"')]/div[contains(@class,'count')]");
							
							WebElement CardStudTotStatusElement=WebDriverMain._getElementWithWait(CardStudTotStatuslocator);
							String strCardStudTotStatus = CardStudTotStatusElement.getText();
					
							if (strCardStudTotStatus.toLowerCase().contains(TestStatus.toLowerCase())) {
								WebElement CardStudTotCnttlnkElement=WebDriverMain._getElementWithWait(CardStudTotCountlocator);
								String strStudTotCnt = CardStudTotCnttlnkElement.getText();
								
								//strCardStudTotStatus=strCardStudTotStatus.replace(strStudTotCnt, "");
										
								mapWidCard.put(TestStatus, strStudTotCnt);
								
								if ((strStudTotCnt.equalsIgnoreCase("0"))||(strStudTotCnt.equalsIgnoreCase("nan")))
									//return null;
									System.out.println(strStudTotCnt+" count "+strCardStudTotStatus);
								else {	
									LeftClick._click(CardStudTotCountlocator);
									CommonFunctions.PleaseWaitAndLoadingMessage();
									return mapWidCard;
								}
							}
							
								
						}	
							System.out.println("Card details : "+mapWidCard);
						}
				
				else 
					//No data to display
					return mapWidCard;
					
			}
			catch(Exception e){
					return mapWidCard;
			}
		}
	}
	return mapWidCard;
		
	}
	// Sheetal 
	public boolean verifyErrorHint(String errormessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess=WebDriverMain._getTextFromElement(HomePageObjects(MyAccDlg_ErrorHint));
		if(textSuccess.contains(errormessage)){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean verifyErrorMessage(String errormessage) throws IOException{
		CommonUtility._sleepForGivenTime(2000);
		String textSuccess=WebDriverMain._getTextFromElement(HomePageObjects(MyAccDlg_ErrorMessage));
		if(textSuccess.contains(errormessage)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * Function Name :- VerifyArcWidgetTitle<br>
	 * Description :- To Verify Widget Content.
	 * 
	 * @return boolean
	 */
	public boolean VerifyArcWidgetTitle(String WidgetTitle) throws IOException {
		boolean flag=false;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			WebElement WidEle=WebDriverMain._getElementWithWait(objlocator);
			CommonUtility._scrollElement(WidEle);
			flag=true;
		}
		return flag;
	}
	
	/**
	 * Function Name :- getTotalStudentsCnt<br>
	 * Description :- To get the Student In Admin.
	 *
	 */
	public int getTotalStudentsCnt() throws IOException {
		int cnt =0;
		if (WebDriverMain._isElementPresent(HomePageObjects(cntTotalStudents))) {
			String studentsInSession = WebDriverMain._getTextFromElement(HomePageObjects(cntTotalStudents));
			if (studentsInSession.contains(":")) {
				String TotStudSplit[]=studentsInSession.split(":");
				cnt = Integer.parseInt(TotStudSplit[1].trim());
			}
		}
		return cnt;
		
	}
	
	/**
	 * Function Name :- SelectTotalStudents<br>
	 * Description :- To get the Student In Select.
	 *
	 */
	public int SelectTotalStudents() throws IOException {
		int cnt =0;
		if (WebDriverMain._isElementPresent(HomePageObjects(cntTotalStudents))) {
			String studentsInSession = WebDriverMain._getTextFromElement(HomePageObjects(cntTotalStudents));
			if (studentsInSession.contains(":")) {
				String TotStudSplit[]=studentsInSession.split(":");
				cnt = Integer.parseInt(TotStudSplit[1].trim());
				if (cnt>0) {
					LeftClick._click(HomePageObjects(cntTotalStudents));
					CommonUtility._sleepForGivenTime(1000);
					CommonFunctions.PleaseWaitAndLoadingMessage();
				}
			}
		}
		return cnt;
		
	}
	
	/**
	 * Function Name :- checkWidhasNoData<br>
	 * Description :- To Check the Widget has No Data 
	 *
	 */
	public boolean checkWidhasNoData() throws IOException {
		try {
		if (WebDriverMain._isElementVisible(HomePageObjects(TestSesWidHasNoData))) 
			return true;
		}
		catch(Exception e) {
			return false;
		}
		return false;
		
	}
		

	public String Func_GetCopyrights() throws IOException {
		String Message = null;
		CommonUtility._sleepForGivenTime(3000);
		// Customer administrator user role
		if (WebDriverMain._isElementPresent(HomePageObjects(Footer_Copyright))) {
			Message = WebDriverMain._getTextFromElement(HomePageObjects(Footer_Copyright));
		} 
		return Message;
	}
	
	
	/**
	 * Function Name :- click Terms & conditions Link<br>
	 * Description :- To click Terms & conditions Link.
	 *
	 */
	public boolean clickConditions() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(HomePageObjects(Footer_Conditions));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	
	/**
	 * Function Name :- Privacy Link<br>
	 * Description :- To click privacy Link.
	 *
	 */
	public boolean clickprivacy() throws IOException{
		CommonUtility._sleepForGivenTime(500);
		LeftClick._click(HomePageObjects(Footer_Privacy));
		CommonUtility._sleepForGivenTime(2000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- Footer PearsonLogo<br>
	 * Description :- Select Footer Logo
	 * 
	 * @return boolean
	 * @throws IOException
	 */
	public boolean SelectfooterLogo() throws IOException
	{
		LeftClick._click(HomePageObjects(Footer_logo));
		CommonUtility._sleepForGivenTime(1000);
		CommonFunctions.PleaseWaitAndLoadingMessage();
		return true;
	}
	
	/**
	 * Function Name :- MenuOtion<br>
	 * Description :- Select the menu options
	 * 
	 * @param Primary,
	 * @param Secondary
	 * @throws IOException
	 */
	public boolean VerifyMenuOtion(String Primary, String Secondary) throws IOException {
		boolean MenuFlag=false;
		By objlocator =null;
		switch (Primary.toLowerCase()) {
			case "home":
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Home']");
				break;
			case "organizations":
				switch (Secondary.toLowerCase()) {
				case "my state":
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='State']");
					break;
				case "my district":
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='District']");
					break;
				case "my school":
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='School']");
					break;
				case "districts":
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Districts']");
					break;
				case "schools":
					objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Schools']");
					break;
				}
				break;
			case "students":
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Students']");
				break;
			case "sessions":
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Sessions']");
				break;
			case "users":
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Users']");
				break;
			case "classes":
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Classes']");
				break;
			case "view reports":
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Reports']");
				break;
			case "data imports":
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Data Imports']");
				break;
			case "products":
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//a//img[@alt='Products']");
				break;	
			case "course":
				objlocator = CommonUtility._getObjectLocator("xpath=//pa-nav-links/nav/ul/li//span[contains(text(),'Courses')]");
				break;
			case "settings":
				MenuFlag=WebDriverMain._isElementPresent(HomePageObjects(Menuoption_Students));
				break;
		}
		if (objlocator!=null)
			MenuFlag=WebDriverMain._isElementPresent(objlocator);
		
		return MenuFlag;
	}
	
	/**
	 * Function Name :- DashboardWidgetBladeExpand<br>
	 * Description :- To Expand/Collapse the Student Dashboard Blade.
	 *
	 */
	public boolean DashboardWidgetBladeExpand(String WidgetTitle,String strValue) throws IOException{
		boolean flag=false;
		By objExpandUplocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../..//i[contains(@class,'fa-angle-up')]");
		By objCollapseDownlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../..//i[contains(@class,'fa-angle-down')]");
		try {
			if(strValue.equalsIgnoreCase("Yes") || strValue.equalsIgnoreCase("True")){
				if (WebDriverMain._isElementPresent(objExpandUplocator)) {
					if (IsCardBodyDisplayed(WidgetTitle))
						return true;//Display session info if collapse
				}
				else if (WebDriverMain._isElementPresent(objCollapseDownlocator)){
					flag = LeftClick._click(objCollapseDownlocator);
					CommonUtility._sleepForGivenTime(1000);
					if (IsCardBodyDisplayed(WidgetTitle))
						return true;//Display session info if collapse
				}
			}
			else {
				if (WebDriverMain._isElementPresent(objCollapseDownlocator)) {
					if (!IsCardBodyDisplayed(WidgetTitle))
						return true;//Not display session info if collapse
				}
				else if (WebDriverMain._isElementPresent(objExpandUplocator)){
					flag = LeftClick._click(objExpandUplocator);
					CommonUtility._sleepForGivenTime(1000);
					if (!IsCardBodyDisplayed(WidgetTitle))
						return true; //Not display session info if collapse
				}
			}
		 }
		 catch(Exception e) {
		 		return false;
		 }
		return flag;
	}
	
	/**
	 * Function Name :- IsCardBodyDisplayed<br>
	 * Description :- To verify Card Body section is visible
	 *
	 */
	public boolean IsCardBodyDisplayed(String WidgetTitle) throws IOException{
		By objBodylocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']");
		if (WebDriverMain._isElementPresent(objBodylocator)) {
			WebElement EleCardBody = WebDriverMain._getElementWithWait(objBodylocator);
			String attributeText = EleCardBody.getAttribute("outerHTML");
			//System.out.println("Hidden"+EleCardBody.getAttribute("hidden"));
			if(attributeText.contains("hidden"))
				return false;
			else
				return true;
			
		}
		else
			return false; 
	}
	
	/**
	 * Function Name :- GetCardsWidgetContent<br>
	 * Description :- Get Widget Content.
	 * 
	 * @return Map<String, String> 
	 */
	public Map<String, String> GetCardsWidgetContent(String WidgetTitle) throws IOException {
		int IrregCount=0;
		Map<String, String> mapWidCard = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			try{
				By objsublocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']");
				WebElement targetElement = WebDriverMain._getElementWithWait(objsublocator);
				if (targetElement != null) {
					By CardBodylocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]");
					//Get list of Cards
					List<WebElement> lstCardElement =WebDriverMain._getElementsWithWait(CardBodylocator);
					if (lstCardElement != null) {
						mapWidCard = new HashMap<String, String>();
//						for (WebElement CardElement:lstCardElement) {
						for (int icardCnt = 1; icardCnt <= lstCardElement.size(); icardCnt++) {	
							//Title
							By CardTitlelocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'card-deck')]//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//div[@class='card-header']//h3");
							WebElement CardTitleElement=WebDriverMain._getElementWithWait(CardTitlelocator);
							String strCardtitle = CardTitleElement.getText();
							//Count
							By CardStudCountlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'subject-cards-col')]["+icardCnt+"]//div[@class='card-body']//button");
							WebElement CardStudCountElement=WebDriverMain._getElementWithWait(CardStudCountlocator);
							String strCardStudCount = CardStudCountElement.getText();
//							if (StringUtils.isNumeric(strCardStudCount)) 
//								IrregCount=Integer.parseInt(strCardStudCount);		
							mapWidCard.put(strCardtitle, strCardStudCount);
							
						}
					}
					
				}
			}
			catch(Exception e){
					return mapWidCard;
			}
		}
		return mapWidCard;
	}
	
	
	/**
	 * Function Name :- SelectCardWidgetContent<br>
	 * Description :- Select Card Count in Widget Content.
	 * 
	 * @return Map<String, String> 
	 */
	public int SelectCardWidgetContent(String WidgetTitle,String WidgetCard) throws IOException {
		int IrregCount=0;
		By objlocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			try{
				By objsublocator = CommonUtility._getObjectLocator("xpath=//pa-home//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']");
				WebElement targetElement = WebDriverMain._getElementWithWait(objsublocator);
				if (targetElement != null) {
					//Count
					By CardStudTotStatuslocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetTitle+"')]/../../../../div[@class='card-body']//div[contains(@class,'subject-cards-col')]//div[@class='card-header']//h3[contains(text(),'"+WidgetCard+"')]/../../../..//button");
					WebElement CardStudTotStatusElement=WebDriverMain._getElementWithWait(CardStudTotStatuslocator);
					String strCardStudTotStatus = CardStudTotStatusElement.getText().trim();
					if (StringUtils.isNumeric(strCardStudTotStatus)) { 
						IrregCount=Integer.parseInt(strCardStudTotStatus);
						if (IrregCount>0) {
							LeftClick._click(CardStudTotStatuslocator);
							CommonUtility._sleepForGivenTime(1000);
							CommonFunctions.PleaseWaitAndLoadingMessage();
						}
					}
				}
			}
			catch(Exception e){
					return IrregCount;
			}
		}
		return IrregCount;
	}
	
	/**
	 * Function Name :- GetRegisteredCardsWidgetContent<br>
	 * Description :- Get Registered Testing Info Widget Content.
	 * 
	 * @return boolean
	 */
	public Map<String, String> GetRegisteredCardsWidgetContent(String WidgetInfo,String WidgetTitle, String Widget) throws IOException {
		boolean flag=false;
		Map<String, String> mapWidCard = null;
		By objlocator = CommonUtility._getObjectLocator("xpath=//div[contains(@class,'card')]/div[@class='card-header']//h2[contains(text(),'"+WidgetInfo+"')]/../../../..//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]");
		if (WebDriverMain._isElementVisible(objlocator)) {
			try{
				//CommonUtility._scrollElement(targetElement);
				By NoDatalocator = CommonUtility._getObjectLocator("xpath=//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(text(),'No data to display')]");
				//Check if No data to display
				if (!WebDriverMain._isElementVisible(NoDatalocator)) {
					mapWidCard = new HashMap<String, String>();
					//Title
					By CardTitlelocator = CommonUtility._getObjectLocator("xpath=//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]");
					WebElement CardTitleElement=WebDriverMain._getElementWithWait(CardTitlelocator);
					String strCardtitle = CardTitleElement.getText();
					//Count
					By CardStudCountlocator = CommonUtility._getObjectLocator("xpath=//div[@class='card-header']//h3[contains(text(),'"+WidgetTitle+"')]/../../../..//div[contains(@class,'card-body')]//h5[contains(text(),'"+Widget+"')]/../../../..//div[contains(@class,'card-body')]//button");
					WebElement CardStudCountElement=WebDriverMain._getElementWithWait(CardStudCountlocator);
					String strCardStudCount = CardStudCountElement.getText();
					mapWidCard.put(strCardtitle, strCardStudCount);
					System.out.println("Card details : "+mapWidCard);
			}
			else 
				//No data to display
				return mapWidCard;
			}
			catch(Exception e){
				return mapWidCard;
			}
		}
		return mapWidCard;
	}
	
}
