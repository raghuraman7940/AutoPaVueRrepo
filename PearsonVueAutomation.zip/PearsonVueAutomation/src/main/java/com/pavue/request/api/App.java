package com.pavue.request.api;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static io.restassured.matcher.RestAssuredMatchers.matchesXsd;
import static io.restassured.matcher.RestAssuredMatchers.matchesDtd;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.ProxySpecification;
import org.apache.commons.io.FilenameUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.pavue.common.core.CommonFunctions;
import com.pavue.common.core.FileReaderManager;
import com.pavue.common.util.Constants;
import com.pavue.webdriver.Log;


public class App implements Runnable

{
  	public static String ApiDescription = "";
  	public static String APIStatus="";
	public static String ResponseFilePath;
	public static String ContentType;
	public static long responseTime=0;
	public static String responseTimeinMs;
	public static String OutValues;
	public static Response res = null;
	public static List<Map<String , Object>> lstDataSetresult =null;
	static CloseableHttpClient httpclient;
	static HttpClientContext context;
 
  	static ProxySpecification proxySpecification;
  	int ExpStatusid;
	int rowNum;
	boolean bExpected;
	String APIURL,URL,HeaderKey,HeaderValues,ParamKey,ParamValues,methodType,APIServer,Url,Details,HeaderKeyValue,ExpStatusCode,InputValues,GivenExpectedValues;
	String XLSheetname_TestResults;
	String resString=null;
	String ThreadExecType=null;
	String OpKey,XlsxInputFile,XLInputSheetName,SwitchingMode,ExpectedSchemaPath,ExpectedKeys,ExpectedValues,TestCaseID,DataSetID;
	JSONObject jsonTestReport=null;
	JSONObject jsonTestSet=null;
	static JSONObject CurrentTestset=null;
	public Map<String,String> APIResult= new HashMap<String,String>();;
  	public App() throws IOException
  	{
  		
  		//Log._logInfo("Initialize App Constructor");
  		lstDataSetresult  = new ArrayList<Map<String,Object>>();
  		//Proxy host details


  	}
  	
  	
	public App(JSONObject jsTestReportData,String TestCaseID,String DataSetID,String Details,String APIServer,String Url, String MethodType, String HeaderKey,String HeaderValues,String ParamKey, String ParamValues,String OpKey, String Switchingmode, String ExpectedKeys, String ExpectedValues, String ExpectedStatusCode, String ExpectedSchemaPath, String ThreadExecType)
	{
		//Initialize values
		this.ThreadExecType=ThreadExecType;
		this.jsonTestReport=jsTestReportData;
		this.TestCaseID= TestCaseID;
		this.DataSetID=DataSetID;
		this.Details = Details;
		this.APIServer = APIServer;
		this.Url = Url;
		this.methodType = MethodType;
		this.HeaderKey = HeaderKey;
		this.HeaderValues=HeaderValues;
		this.ParamKey = ParamKey;
		this.ParamValues = ParamValues;
		this.ExpStatusCode = ExpectedStatusCode;
		this.OpKey = OpKey;
		this.SwitchingMode= Switchingmode;
		this.ExpectedSchemaPath = ExpectedSchemaPath;
		this.ExpectedKeys = ExpectedKeys;
		this.ExpectedValues = ExpectedValues;
		
		 //Proxy Specification
	    proxySpecification=null;

	}
	
	
	 /**************************************************************************
     *  Function name 		: run
     *  Reuse Function 		:
     *  Description 		: Execute non dependent test cases
     /**********************************************************************/
	public void run()
	{
		Log._logInfo("Run Method :");
		System.out.println(Thread.currentThread().getName()+" (Start) "+ThreadExecType+" :"+TestCaseID+DataSetID);
//		 try {
//			APICall(jsonTestReport,TestCaseID,DataSetID,Details,APIServer,Url, methodType, HeaderKey,HeaderValues,ParamKey, ParamValues,OpKey, SwitchingMode, ExpectedKeys, ExpectedValues, ExpStatusCode, ExpectedSchemaPath);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		System.out.println(Thread.currentThread().getName()+" (End)"+ThreadExecType+" :"+TestCaseID+DataSetID);//prints thread name
	}
	
    /**************************************************************************
     *  Function name 		: APICall
     *  Reuse Function 		:
     *  Description 		: Initialize and set API input values
     /**********************************************************************/
	public Map<String,Object> APICall(JSONObject jsTestReportData,JSONObject Testset,String TestCaseID,String DataSetID,String Details,String Url, String MethodType, JSONObject headers,JSONObject parameters, JSONObject expected, JSONArray jsArrayUserPerms,Map<String,Object> ApiHeaders,List<String> UserPermissions) throws IOException
	{
		  String APIURL;
	      String Status=Constants.KEYWORD_FAIL;
	      String Description=null;
	      JSONObject pathparam=null;
	      JSONObject qryparam=null;
	      JSONObject postbody=null;
	      JSONObject jsTestSuiteData=null;
	      Map<String,Object> testCaseResult = new HashMap<String,Object>();
	      Map<String,Object> Api_Headers = new HashMap<String,Object>();
	      Map<String, String> mapRefUrl=null;
	      List<String> lstUserPerms= new ArrayList<String>();
	      try{
	    	  //Add Current Testdata
	    	  
	    	  jsTestSuiteData=jsTestReportData;
	    	  // jsTestSuiteData.append("Tests", Testset);
	    	  
	    	  CurrentTestset=Testset;
	    	 // System.out.println("ApiHeaders1 :"+ApiHeaders);
	    	  System.out.println("authorization :"+ApiHeaders.get("authorization"));
	    	  //System.out.println("Testset :"+Testset);
	    	  //API Url initialize
	    	  //Header value
	    	  
	    	  if (headers.length()>0){
	    		  Map<String, Object> mapRefHeaders=JSONtoJSON(jsTestSuiteData,headers);
	    		  if (mapRefHeaders.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_SKIP)){
				    	  Status= Constants.KEYWORD_SKIP;
				    	  Description=mapRefHeaders.get("ApiDescription").toString();
				  	}
	    		  headers= (JSONObject) mapRefHeaders.get("ReferenceValue");
	    		  Map<String,Object> testHeader =CommonFunctions.toMap(headers);
	    		  
	    		  ApiHeaders.putAll(testHeader);	
	    		//  System.out.println("ApiHeaders2 :"+ApiHeaders);
	    	  }
			
	    	  //Path Parameter
	    	  pathparam=parameters.getJSONObject(Constants.pathparameters);
	    	  if (pathparam.length()>0) {
	    		  mapRefUrl=GetPathParameter(jsTestSuiteData,pathparam,Url);
			      if (mapRefUrl.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_SKIP)){
			    	  Status= Constants.KEYWORD_SKIP;
			    	  Description=mapRefUrl.get("ApiDescription");
			      }
			      Url= mapRefUrl.get("ReferenceValue");
	    	  }
		      
			  //Query Parameter
		      mapRefUrl=null;
		      qryparam=parameters.getJSONObject(Constants.Queryparameters);
		      if (qryparam.length()>0) {
			      mapRefUrl=GetQueryParameter(jsTestSuiteData,qryparam,Url);
			      if (mapRefUrl.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_SKIP)){
			    	  Status= Constants.KEYWORD_SKIP;
			    	  Description=mapRefUrl.get("ApiDescription");
			      }
			      Url= mapRefUrl.get("ReferenceValue");
		      }
		      
		      //Final API Request Url
		      APIURL=Constants.APIServer+Url;
			
		      //Post input values
		      postbody=parameters.getJSONObject(Constants.postbody);
		      if (postbody.length()>0){
				Map<String, Object> mapRefPostBody=JSONtoJSON(jsTestSuiteData,postbody);
				if (mapRefPostBody.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_SKIP)){
			    	  Status= Constants.KEYWORD_SKIP;
			    	  Description=mapRefPostBody.get("ApiDescription").toString();
			    }
				//System.out.println(mapRefPostBody);
				//System.out.println(mapRefPostBody.get("ReferenceValue"));
				postbody= (JSONObject) mapRefPostBody.get("ReferenceValue");
		      }
				
			//Expected values
			if (expected.length()>0){
				
			}
			
			//Permission
			if (jsArrayUserPerms.length()>0) {
				 List<Object> lstPerms=CommonFunctions.toList(jsArrayUserPerms);
				 for (Object oo:lstPerms)
					 lstUserPerms.add(oo.toString());
			}
			
			Log._logInfo("APICall Request Input : "+MethodType+" "+APIURL+" "+headers+" "+parameters+" "+expected);
			//System.out.println("Request Input : "+MethodType+" "+APIURL+" "+headers+" "+parameters+" "+expected);
    		testCaseResult.put("TestCaseID",TestCaseID);
    		
    		testCaseResult.put("methodType",MethodType);
    		testCaseResult.put("APIURL",APIURL);
    		testCaseResult.put("Details",Details);
    		testCaseResult.put("headers",headers.toString());
    		testCaseResult.put("parameters",parameters.toString());
    		testCaseResult.put("expected",expected.toString());
		    //Start test level execution
		    if (!Status.equalsIgnoreCase(Constants.KEYWORD_SKIP)) {
	          //Execute API Call
	            Map<String,Object> APIResult=ExecuteAPICall( TestCaseID,DataSetID, Details, APIURL,  MethodType,  ApiHeaders, postbody,  expected,lstUserPerms,UserPermissions);
	            
	    		testCaseResult.put("ContentType",APIResult.get("ContentType"));
	    		testCaseResult.put("resString",APIResult.get("resString"));
	    		testCaseResult.put("APIStatus",APIResult.get("APIStatus"));
	    		testCaseResult.put("Statuscode",APIResult.get("Statuscode"));
	    		testCaseResult.put("ApiDescription",APIResult.get("ApiDescription"));
	    		testCaseResult.put("Output_Values",APIResult.get("Output_Values"));
	    		testCaseResult.put("responseTime",APIResult.get("responseTime"));
	    		testCaseResult.put("ResponseFilePath",APIResult.get("ResponseFilePath"));
		    }
		    else{
		    	testCaseResult.put("ContentType","");
	    		testCaseResult.put("resString","");
	    		testCaseResult.put("APIStatus",Status);
	    		testCaseResult.put("ApiDescription",Description);
	    		testCaseResult.put("Statuscode","0");
	    		testCaseResult.put("Output_Values","");
	    		testCaseResult.put("responseTime","0");
	    		testCaseResult.put("ResponseFilePath","");
		    }
		    
		    lstDataSetresult.add(testCaseResult);
	      }
	      catch(Exception e)
	      {
	    	  e.printStackTrace();
			return testCaseResult;
	      }
	      return testCaseResult;
	}
	
	
	/**************************************************************************
     *  Function name 		: ExecuteAPICall
     *  Reuse Function 		:
     *  Description 		: Execute API Call
     /
     * @throws IOException 
     * @throws ProcessingException **********************************************************************/
	public Map<String,Object> ExecuteAPICall(String TestCaseID,String DataSetID,String Details,String APIURL, String MethodType, Map<String,Object> headers,JSONObject postbody, JSONObject expresponses, List<String> LstUserPermissions,List<String> UserPermissions) throws  IOException
	{
		Log._logInfo("ExecuteAPICall "+TestCaseID+" - "+DataSetID);
		
		Response res=null;
		String ContentType="",ResponseFilePath="",OutValues="";
		long responseTime=0;
		int ActStatusid=0;
		int ExpStatusid=0;
		String Status=Constants.KEYWORD_SKIP;
		String resString="";
		String Description="";		
		
		//Store response in a map
		Map<String,Object> testCaseResult = new HashMap<String,Object>();
		try
		{
			switch(MethodType.toUpperCase())
			{
				case "GET":
					res=Get_Method(APIURL,headers);
					break;
				case "POST":
					if (headers.containsValue("multipart/form-data"))
						if (postbody.has("UploadFile"))
							res=Post_MethodByMultiPartForm(APIURL,headers,postbody);
						else
							res=Post_MethodByFormParam(APIURL,headers,postbody);
					else {
						res=Post_Method(APIURL,headers,postbody);
						
					}
					break;
				case "PUT":
					res=Put_Method(APIURL,headers,postbody);
					break;
				case "DELETE":
					if (headers.containsValue("multipart/form-data"))
						res=Delete_MethodByFormParam(APIURL,headers,postbody);
					else
						res=Delete_Method(APIURL,headers,postbody);
					break;
			}
			//testCaseResult.put("RequestDateTime",Date());
			
			if (res!=null) {
				ActStatusid=res.getStatusCode();
		        ContentType = GetResponseContentType(res);
		        //System.out.println(TestCaseID+"_"+DataSetID+" - Status : "+ActStatusid);
		        resString=GetRespString(res);
		        ResponseFilePath = StoreRespose(TestCaseID+"_"+DataSetID, ContentType,resString);
		        ExpStatusid = (int) Double.parseDouble(expresponses.getString("StatusCode"));
		        //Verify Status code
		        Map<String, String> mapAPIRespStatus=null;
		        if (LstUserPermissions.size()>0)
		        	mapAPIRespStatus=VerifyResponseStatuswithPermission(ExpStatusid,ActStatusid, LstUserPermissions,UserPermissions);
		        else
		        	mapAPIRespStatus=VerifyResponseStatus(TestCaseID+"_"+DataSetID, res, ExpStatusid);
		        
		        Status=mapAPIRespStatus.get("APIStatus");
		        Description=mapAPIRespStatus.get("ApiDescription");
		        responseTime = GetResponseTime(res);
				if(Status.equalsIgnoreCase(Constants.KEYWORD_PASS)) {
					//Get value for GetOutputKey
		            OutValues = GetOutkeyValueFromResponse(res, expresponses.getString(Constants.GetOutputKey));
		            if (OutValues==null)
		            	OutValues="";
		            String ExpKeys=expresponses.getString(Constants.Expected_Keys);
		            if (ExpKeys.length()>1) {
			            Map<String, String> mapAPIRespKeyValues = ResponseExpectedValidation(TestCaseID+"_"+DataSetID, res, expresponses.getString(Constants.Expected_Keys), expresponses.getString(Constants.Expected_Values));
			            if(mapAPIRespKeyValues.get("APIStatus")!=null)
			            {
				            Status=mapAPIRespKeyValues.get("APIStatus");
				       	 	Description=Description+mapAPIRespKeyValues.get("ApiDescription");
			            }
		            }
		        }
				Description=Description.replace("null", "");
			}
			
			//System.out.println(TestCaseID+DataSetID+" 2: "+Status);
			testCaseResult.put("TestCaseID",TestCaseID);
			testCaseResult.put("DataSetID",DataSetID);
			testCaseResult.put("ContentType",ContentType);
			testCaseResult.put("resString",resString);
			testCaseResult.put("APIStatus",Status);
			testCaseResult.put("Statuscode",ActStatusid);
			testCaseResult.put("ApiDescription",Description);
			testCaseResult.put("Output_Values",OutValues);
			testCaseResult.put("responseTime",String.valueOf(responseTime));
			testCaseResult.put("ResponseFilePath",ResponseFilePath);	
			
			Log._logInfo("ExecuteAPICall "+TestCaseID+" - "+DataSetID+" - "+Status);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return testCaseResult;
		}
	
		return testCaseResult;
	}
	
    
  
    
    /***************************************************************************************
	 *  Function name 		: Get_Method
	 *  Reuse Function 		:  
	 *  Description 		: GET Method API WebServices
	/****************************************************************************************/         
    public Response Get_Method(String apiurl,String HKeys, String HValues)
    {    
    	Log._logInfo("Execute GET Call :"+apiurl+HKeys+HValues);
    	Response GetResp = null;
    	try
    	{
    		Map<String, String> header = GetKeyValuePair(HKeys,HValues);
	    	GetResp=given()   
	    			//.relaxedHTTPSValidation()
	        .proxy(proxySpecification)
	        .headers(header)
			.get(apiurl);
    	}
    	catch(Exception e)
    	{
    		return GetResp;
    	}
    	return GetResp;
   }
    
    /***************************************************************************************
   	 *  Function name 		: Get_Method
   	 *  Reuse Function 		:  
   	 *  Description 		: GET Method API WebServices
   	/****************************************************************************************/         

       public Response Get_Method(String apiurl,JSONObject header)
       {    
       	int StatusCode=0;
       	Response GetResp = null;
       	//System.out.println("Get call"+apiurl+HKeys+HValues);
       	Map<String,Object> result =
       			CommonFunctions.toMap(header);
       	try
       	{
       		//Map<String, String> header = GetKeyValuePair(HKeys,HValues);
   	    	GetResp=given()   
   	    	//.relaxedHTTPSValidation()
   	        //.proxy(proxySpecification)
   	    			
   	        .headers(result)
   			 //.cookies(cookies)
   			.get(apiurl);
   	    	
   	    	StatusCode=GetResp.getStatusCode();
   	    	//System.out.println("GetResp Statuscode: "+StatusCode);
   	    	//System.out.println("GetResp asString: "+GetResp.asString());
   	    	
   	    	//VerifyResponseStatus(GetResp,200);
       	}
       	catch(Exception e)
       	{
       		return GetResp;
       	}
       	return GetResp;
      }
       
       /***************************************************************************************
      	 *  Function name 		: Get_Method
      	 *  Reuse Function 		:  
      	 *  Description 		: GET Method API WebServices
      	/****************************************************************************************/         

          public Response Get_Method(String apiurl,Map<String,Object> header)
          {    
        	Log._logInfo("Execute GET Call :"+apiurl);
          	int StatusCode=0;
          	Response GetResp = null;
          	//System.out.println("Get call"+apiurl+HKeys+HValues);
   
          	try
          	{
          		//Map<String, String> header = GetKeyValuePair(HKeys,HValues);
      	    	GetResp=given()   
      	    	//.relaxedHTTPSValidation()
      	        //.proxy(proxySpecification)
      	    			
      	        .headers(header)
      			 //.cookies(cookies)
      			.get(apiurl);
      	    	
      	    	StatusCode=GetResp.getStatusCode();
      	    	//System.out.println("GetResp Statuscode: "+StatusCode);
      	    	//System.out.println("GetResp asString: "+GetResp.asString());
      	    	
      	    	//VerifyResponseStatus(GetResp,200);
          	}
          	catch(Exception e)
          	{
          		return GetResp;
          	}
          	return GetResp;
         }
       
       
     
	/***************************************************************************************
	 *  Function name 		: Post_Method
	 *  Reuse Function 		:  
	 *  Description 		: Post Method API WebServices
	/****************************************************************************************/         
    public Response Post_MethodByFormParam(String apiurl,Map<String,Object> header,JSONObject postbody){
    	Log._logInfo("Execute Form POST Call :"+apiurl+postbody);
    	Response PostResp = null;
    	try
    	{

    		Map<String, Object> BodyParameter = CommonFunctions.toMap(postbody);
    		PostResp=given()   	
	        .headers(header)
	        .multiPart("", "")
//	       	.multiPart("printableFormPath", "Null")
//	        .formParam("code", "TSTFORMMATH25")
//	        .formParam("subjectReferenceId", "109ec3af-257a-487c-a3aa-22feb75e3692")
//	        .formParam("productTypeReferenceId", "7aac677c-041b-466f-8235-47a2679dcbe7")
//	        .formParam("mode", "online")
//	        .formParam("hasSealCode", false)
//	        .formParam("abbiAdminCode", "AD93482")
//	        .formParam("accountCode", "AC93482")
//	        .formParam("testCode", "TC93482")
	        .formParams(BodyParameter)
	      
			.when()
			.post(apiurl);
    	}
      	catch(Exception e)
    	{
    		return PostResp;
    	}
      	return PostResp;
    	
   }
    
    
    /***************************************************************************************
	 *  Function name 		: Post_Method
	 *  Reuse Function 		:  
	 *  Description 		: Post Method API WebServices
	/****************************************************************************************/         
    public Response Post_MethodByMultiPartForm(String apiurl,Map<String,Object> header,JSONObject postbody){
    	Log._logInfo("Execute Form POST Call :"+apiurl+postbody);
    	Response PostResp = null;
    	try
    	{
    	
    		Map<String, Object> BodyParameter = CommonFunctions.toMap(postbody);
    		String key=BodyParameter.get("UploadFileKey").toString();
    		String filename=BodyParameter.get("UploadFile").toString();
    		File file= new File(System.getProperty("user.dir")+Constants.SRC_RES_EXPORTFILEPATH+filename);
	    		if (file.exists()) {
	    		PostResp=given()   	
		        .headers(header)
		        .multiPart("", "")
		        .multiPart(key, file)
	//	       	.multiPart("printableFormPath", "Null")
	//	        .formParam("code", "TSTFORMMATH25")
	//	        .formParam("subjectReferenceId", "109ec3af-257a-487c-a3aa-22feb75e3692")
	//	        .formParam("productTypeReferenceId", "7aac677c-041b-466f-8235-47a2679dcbe7")
	//	        .formParam("mode", "online")
	//	        .formParam("hasSealCode", false)
	//	        .formParam("abbiAdminCode", "AD93482")
	//	        .formParam("accountCode", "AC93482")
	//	        .formParam("testCode", "TC93482")
	//	        .formParams(BodyParameter)
		      
				.when()
				.post(apiurl);
    		}
    	}
      	catch(Exception e)
    	{
    		return PostResp;
    	}
      	return PostResp;
    	
   }
    
    /***************************************************************************************
	 *  Function name 		: Post_Method
	 *  Reuse Function 		:  
	 *  Description 		: Post Method API WebServices
	/****************************************************************************************/         
    public Response Post_Method(String apiurl,Map<String,Object> header,JSONObject postbody){
    	Log._logInfo("Execute POST Call :"+apiurl+postbody);
    	Response PostResp = null;
    	//Map<String, Object> BodyParameter = CommonFunctions.toMap(postbody);
    	//System.out.println("POST BodyParameter :"+BodyParameter);
    	//System.out.println("POST postbody :"+postbody);
    	try
    	{
    		PostResp=given()   
	       // .proxy(proxySpecification)		
	        .headers(header)
	        
	        .body(postbody.toString())
			.when()
			.post(apiurl);
    	}
      	catch(Exception e)
    	{
    		return PostResp;
    	}
      	return PostResp;
    	
   }
    
	
    
    /***************************************************************************************
	 *  Function name 		: Delete_Method
	 *  Reuse Function 		: ReadExcel_Data
	 *  Description 		: Delete Method API WebServices  
	/****************************************************************************************/ 
    public Response Delete_Method(String apiurl,Map<String,Object> header,JSONObject postbody){
    	Log._logInfo("Execute DELETE Call :"+apiurl+postbody);
    	Map<String, Object> BodyParameter = CommonFunctions.toMap(postbody);
    	Response res=given()
    	//.proxy(proxySpecification)	
    	.headers(header)
		.body(BodyParameter)
		.when()
		.delete(apiurl);
		 return res;
   }
    
    /***************************************************************************************
  	 *  Function name 		: Delete_MethodByFormParam
  	 *  Reuse Function 		: ReadExcel_Data
  	 *  Description 		: Delete Method API WebServices  
  	/****************************************************************************************/ 
      public Response Delete_MethodByFormParam(String apiurl,Map<String,Object> header,JSONObject postbody){
      	Log._logInfo("Execute FORM DELETE Call :"+apiurl+postbody);
      	Map<String, Object> BodyParameter = CommonFunctions.toMap(postbody);
      	Response res=given()
      	//.proxy(proxySpecification)	
      	.headers(header)
        .multiPart("", "")
  		.formParams(BodyParameter)
  		.when()
  		.delete(apiurl);
  		 return res;
     }
	
	/***************************************************************************************
	 *  Function name 		: Delete_Method
	 *  Reuse Function 		: ReadExcel_Data
	 *  Description 		: Delete Method API WebServices  
	/****************************************************************************************/ 
    public Response Delete_Method(String apiurl,String HKeys, String HValues,String PKeys, String PValues){
    	Log._logInfo("Execute DELETE Call :"+apiurl+HKeys+HValues+PKeys+PValues);
    	Map<String, String> BodyParameter = GetKeyValuePair(PKeys,PValues);
    	Map<String, String> header = GetKeyValuePair(HKeys,HValues);
    	Response res=given()
    //	.proxy(proxySpecification)	
    	.headers(header)
		.body(BodyParameter)
		.when()
		.delete(apiurl);
		 return res;
   }
	/***************************************************************************************
	 *  Function name 		: Put_Method
	 *  Reuse Function 		: 
	 *  Description 		: Update Method API WebServices 
	/****************************************************************************************/ 
    public Response Put_Method(String apiurl,Map<String,Object> header,JSONObject postbody){
    	Log._logInfo("Execute PUT Call :"+apiurl+postbody);
    	
    	Map<String, Object> BodyParameter = CommonFunctions.toMap(postbody);
    	Response res=given()
    	//.proxy(proxySpecification)	
    	.headers(header)
		.body(BodyParameter)
		.when()
		.put(apiurl);
    	return res;
   }
    
    /***************************************************************************************
	 *  Function name 		: Put_Method
	 *  Reuse Function 		: 
	 *  Description 		: Update Method API WebServices 
	/****************************************************************************************/ 
    public Response Put_Method(String apiurl,String HKeys, String HValues,String PKeys, String PValues){
    	Log._logInfo("Execute PUT Call :"+apiurl+HKeys+HValues+PKeys+PValues);
    	
    	//int StatusCode;
    	//StatusCode=1;
    	Map<String, String> BodyParameter = GetKeyValuePair(PKeys,PValues);
    	Map<String, String> header = GetKeyValuePair(HKeys,HValues);
    	Response res=given()
    	.proxy(proxySpecification)	
    	.headers(header)
		.body(BodyParameter)
		.when()
		.put(apiurl);
    	return res;
   }
   
	/***************************************************************************************
	 *  Function name 		: GetOutkeyValueFromResponse
	 *  Reuse Function 		:  GetResponseContentType
	 *  Description 		: Get output key value from the response
	/****************************************************************************************/    
	public String GetOutkeyValueFromResponse(Response res,String Key) 
	{
		Log._logInfo("Get Key Value from Response :"+Key);
	   	String repOutputKey=null;
	   	String repContentType=null;
    	try
   		 {  
    		if ((Key.length()>0)&&(!Key.equalsIgnoreCase("null")))
    		{
    			repContentType=GetResponseContentType(res);
	    		if ((repContentType.contains("json"))|(repContentType.contains("JSON")))
	    		{
	    			//repOutputKey=res.then().extract().jsonPath().get(Key);
	    			repOutputKey=res.then().extract().jsonPath().getString(Key);
	    			
		    	
	    		}
	    		else if ((repContentType.contains("xml"))|(repContentType.contains("XML")))
	    		{
	    			repOutputKey=res.then().extract().xmlPath().getString(Key);
	    		}	
	    		else if ((repContentType.contains("html"))|(repContentType.contains("HTML")))
	    		{
	    			repOutputKey=res.then().extract().htmlPath().getString(Key);
	    		}
	    		
	    	   	if ((repOutputKey.contains("["))&(repOutputKey.contains("]")))
	            {
	    	   		repOutputKey=repOutputKey.replace("[", "");
	    	   		repOutputKey=repOutputKey.replace("]", "");
	            }
    			}	
	    	}
	    	catch (AssertionError e)
	   		 {     		
	   			 System.out.println("Err Catch GetOutkeyValue :"+e.getMessage());
	   			 return repOutputKey;
	   		 }
	    	catch (Exception e)
	   		 {     		
	   			 System.out.println("Err Catch GetOutkeyValue :"+e.getMessage());
	   			 return repOutputKey;
	   		 }
    	return repOutputKey;
	    	
	    }

	/*************************************************************************************************
	 *  Function name 		: GetJsonValueFromResponse
	 *  Reuse Function 		: 
	 *  Description 		:  Get the Value of  key from responsestring
	/**************************************************************************************************/
	 public String GetJsonValueFromResponse(String ResponseString,String Key)
	 {   	
		 Log._logInfo("Get Key Value from Response :"+Key);
	    	String ReString;
	    	ReString=null;
	    	ReString="Not Found";
		    try 
		        {
		    	if (APIStatus.equalsIgnoreCase(Constants.KEYWORD_PASS))
		    	{
			    	JsonPath jsonResponse = new JsonPath(ResponseString);
				    ReString= jsonResponse.getString(Key);			 		 
					System.out.println("Json Values for output key "+Key+" is "+ReString);
		    	}
		    	else
		    	{
		    		ReString="";
		    	}
		        } 
		     catch (Exception e) 
		        {
		        	e.printStackTrace();
		        }        	      
	     	return ReString;
	      }    
	
	 
		/*************************************************************************************************
		 *  Function name 		: GetJsonValueFromResponse2
		 *  Reuse Function 		: 
		 *  Description 		: Get the Value of  key from external json file
		/**************************************************************************************************/
		 public String GetJsonValueFromResponse2(String FileName,String FileType,String Key)
		    {   	
			 Log._logInfo("Get Key Value from Response File :"+Key);
		    	String ReString;
		    	ReString=null;
		    	ReString="Not Found";
			    File file = new File(System.getProperty("user.dir")+"/src/test/resources/Response/"+FileName+"."+FileType);
			    try 
			        {
			    	
			    	JsonPath jsonResponse = new JsonPath(new FileReader(file));
				    ReString= jsonResponse.getString(Key);			 		 
					System.out.println("Json Values for output key "+Key+" is "+ReString);

			        } 
			     catch (IOException e) 
			        {
			        	e.printStackTrace();
			        }        	      
		     	return ReString;
		      }    
		
		/**************************************************************************
		 *  Function name 		: ExpectedValueValidation
		 *  Reuse Function 		: 
		 *  Description 		: Get Method with validation
		 	/**********************************************************************/
	    public boolean ExpectedValueValidation(String apiurl,String Key,String ExpectedValue) 
	    {
	    	Log._logInfo("Validate response code with expected:"+ExpectedValue);
	    		try
	    		 {    
	    			get(apiurl).then().assertThat().body(Key, equalTo(ExpectedValue));
	    			return true;
	    		 }
	    		 catch (AssertionError e)
	    		 {     			
	    			 return false;
	    		 }
	    }
	    
    /**************************************************************************
	 *  Function name 		: GetKeyValuePair
	 *  Reuse Function 		: 
	 *  Description 		: Provide paired key values from  excel input key values    
	 /**********************************************************************/    
	    public ArrayList<NameValuePair> GetNameValuePair(String PKeys,String PValues) 
		{
			//Map<String, String>  mKeyValue=new HashMap<>();
	    	Log._logInfo("Get Arraylist Input Value Pair:"+PKeys+PValues);
			ArrayList<NameValuePair> mKeyValue = null;

	        
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
					mKeyValue = new ArrayList<NameValuePair>();
			        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	mKeyValue.add(new BasicNameValuePair(ArKeys[i], ArValues[i]));
			        }
				
 
				}
				return mKeyValue;
			}
	    
	    
    /**************************************************************************
	 *  Function name 		: GetKeyValuePair
	 *  Reuse Function 		: 
	 *  Description 		: Provide paired key values from  excel input key values    
	 /**********************************************************************/    
	    public Map<String, String> GetKeyValuePair(String PKeys,String PValues) 
		{
	    	Log._logInfo("Get Maplist of Key Value Pair :"+PKeys+PValues);
			Map<String, String>  mKeyValue=new HashMap<>();
				if ((PKeys.length()>0)&(PValues.length()>0))
				{
			        
					//jsonAsMap = new HashMap<>();
			        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
			        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
			        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
			        {
			        	mKeyValue.put(ArKeys[i], ArValues[i]);
			        	
			        }
 
				}
				return mKeyValue;
			}
	    
	    /**************************************************************************
		 *  Function name 		: ResponseExpectedValidation
		 *  Reuse Function 		: 
		 *  Description 		: Validate response with expected key value pair    
		 /**********************************************************************/    
	    public boolean ResponseExpectedValidation(Response res, String PKeys,String PValues)
	    {
	    	Log._logInfo("Validation API Response with expected keyvalue :"+PKeys+PValues);
	    	 boolean Validation= false;
	    	 String ExpecKeytoFind=null;
	    	 String repKeyExist=null;
	  
		    	try
		   		 {  
		    		 if ((PKeys.length()>0)&(PValues.length()>0)&(!PKeys.equalsIgnoreCase("null"))&(!PKeys.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("null")))
					{
			    		
				        String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
				        Object[] ArValues = PValues.split(Constants.DATA_SPLIT);
				        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
				        {
				        	ExpecKeytoFind=ArKeys[i];
				        
				        	//Check whether key is present
				        	repKeyExist=res.then().extract().path(ArKeys[i]);
				        	if(repKeyExist!=null)
				        	{	
						        res.then().assertThat().body(ArKeys[i], equalTo(ArValues[i]));
						    	Validation= true;
				        	}
				        	else
				        	{
				        		ApiDescription=ApiDescription+"\n  Key not found : "+ArKeys[i];
					   			APIStatus=Constants.KEYWORD_FAIL;
					   			System.out.println("Err Catch ResponseExpectedValidation :"+ApiDescription);
					   			return false;
				        	}
				        }
	
					}
			    	else
			    	{
			    		 Validation= true;
			    		 //ApiDescription=ApiDescription+"\n  Expected Values not provided";
			    		 return Validation;
			    	}
		   		 }
		   		 catch (AssertionError e)
		   		 {     		
		   			System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Mismatched Actual Values:"+e.getMessage();
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    	catch (ClassCastException e)
		   		 {     		
		    		System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Key not found  :"+ExpecKeytoFind;
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
			    APIStatus=Constants.KEYWORD_PASS;
				ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
		    		

	    	return Validation;
	    	
	    }
    /**************************************************************************
     *  Function name 		: ResponseExpectedValidation
     *  Reuse Function 		:
     *  Description 		: Validate response with expected key value pair
     /**********************************************************************/
    public  Map<String, String> ResponseExpectedValidation(String TestCaseId,Response res, String PKeys,String PValues)
    {
    	Log._logInfo("Validation API Response with expected keyvalue :"+TestCaseId+PKeys+PValues);
        String repKeyExist=null;
        Map<String, String> mapKeyValueValidation = new HashMap<String,String>();
        Map<String, String> mapMatched = new HashMap<String,String>();
        Map<String, String> mapNotMatched = new HashMap<String,String>();
        String Description = "";
        String CurrKey=null;
   	 	String CurrValue=null;
        String Status=null;
            try
            {
            	 if ((PKeys.length()>0)&(PValues.length()>0)&(!PKeys.equalsIgnoreCase("null"))&(!PValues.equalsIgnoreCase("null")))
                {

                    String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
                    String[] ArValues = PValues.split(Constants.DATA_SPLIT);
                    for(int i =0; i < (ArKeys.length & ArValues.length) ; i++){
                    	CurrKey=ArKeys[i];
                    	CurrValue=ArValues[i];
                        //Check whether key is present
                        repKeyExist=res.then().extract().path(CurrKey).toString();
                        if(repKeyExist!=null){
                        	//System.out.println("repKeyExist "+repKeyExist.toString());
                        	//If no value to check hasitem assertion
                        	if (!CurrValue.equalsIgnoreCase("na")) {
                        		//Assert Equals
                        		//res.then().assertThat().body(ArKeys[i], equalTo(ArValues[i]));
	                        	if (repKeyExist.equalsIgnoreCase(CurrValue)) {
	                        		if (CurrKey.length()>15)
	                        			mapMatched.put(CurrKey.substring(CurrKey.length() - 10), CurrValue);
	                        		else
	                        			mapMatched.put(CurrKey, CurrValue);
	                        	}
	                        	//res.then().assertThat().body(ArKeys[i], contains(ArValues[i]));
                        		//Assert Contains
	                        	else if (repKeyExist.toLowerCase().contains(CurrValue.toLowerCase())) {
	                        		if (CurrKey.length()>15)
	                        			mapMatched.put(CurrKey.substring(CurrKey.length() - 10), CurrValue);
	                        		else
	                        			mapMatched.put(CurrKey, CurrValue);
	                        	}
                        		//Assert Fails
	                        	else {
	                        		mapNotMatched.put(CurrKey, CurrValue);
	                        	}
                        	}
                        	else {
                        		//Assert has items
                        		//res.then().assertThat().body(ArKeys[i], hasItem(ArValues[i]));
                        		mapMatched.put(CurrKey, "");
                        	}
                        }
                        else{
                        	mapNotMatched.put(CurrKey, CurrValue);
                        }
                    }
                }
                else{
                    mapKeyValueValidation.put("APIStatus", Status);
                    mapKeyValueValidation.put("ApiDescription", Description); 
                    return mapKeyValueValidation;
                }
            }
            catch (AssertionError e){
                Description="Response validation error :"+e.getMessage();
                Status=Constants.KEYWORD_FAIL;
                mapKeyValueValidation.put("APIStatus", Status);
                mapKeyValueValidation.put("ApiDescription", Description); 
                return mapKeyValueValidation;
            }
            catch (ClassCastException e){
                Description="Response validation ClassCastError  :"+CurrKey;
                Status=Constants.KEYWORD_FAIL;
                mapKeyValueValidation.put("APIStatus", Status);
                mapKeyValueValidation.put("ApiDescription", Description); 
                return mapKeyValueValidation;
            }
            catch (Exception e){
                Description="Response validation Error: "+e.getMessage();
                Status=Constants.KEYWORD_FAIL;
                mapKeyValueValidation.put("APIStatus", Status);
                mapKeyValueValidation.put("ApiDescription", Description); 
                return mapKeyValueValidation;
            }
            
            if (mapNotMatched.size()>0) {
            	 Status=Constants.KEYWORD_FAIL;
            	 Description="Response Data Validation Failed : "+mapNotMatched;
            	 if (mapMatched.size()>0)
            		 Description=Description+" Response validated : "+mapMatched;
            }
            else {
            	Status=Constants.KEYWORD_PASS;
            	if (mapMatched.size()>0)
            		Description="Response Data Validated : "+mapMatched;
            }
            mapKeyValueValidation.put("APIStatus", Status);
            mapKeyValueValidation.put("ApiDescription", Description); 
            return mapKeyValueValidation;
    }
    
   
	    /**************************************************************************
		 *  Function name 		: ResponseExpectedValidation
		 *  Reuse Function 		: 
		 *  Description 		: Validate response with expected key value pair    
		 /**********************************************************************/    
	    public boolean ResponseValidation_hasitem(Response res, String PKeys,String PValues)
	    {
	    	Log._logInfo("Validation API Response hasitem with expected keyvalue :"+PKeys+PValues);
	    	 boolean Validation= false;
	    	 String CurrKey=null;
	    	 String CurrValue=null;
	    	 String repKeyExist=null;
		    	try
		   		 {  
		    		 if ((PKeys.length()>0)&(PValues.length()>0)&(!PKeys.equalsIgnoreCase("null"))&(!PKeys.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("NA"))&(!PValues.equalsIgnoreCase("null")))
		                {
		    			 String[] ArKeys = PKeys.split(Constants.DATA_SPLIT);
				        String[] ArValues = PValues.split(Constants.DATA_SPLIT);
				        for(int i =0; i < (ArKeys.length & ArValues.length) ; i++)
				        {
				        	CurrKey=ArKeys[i];
				        	//Check whether key is present
				        	repKeyExist=res.then().extract().path(CurrKey);
				        	if(repKeyExist!=null)
				        	{	
				        		CurrValue=ArValues[i];
				        		if (!CurrValue.equalsIgnoreCase("na")) {
				        			res.then().assertThat().body(CurrKey, hasItem(CurrValue));
				        			Validation= true;
				        		}
				        		else
				        			Validation= true;
				        		
				        	}
				        	else
				        	{
				        		ApiDescription=ApiDescription+"\n  Key not found : "+CurrKey;
					   			APIStatus=Constants.KEYWORD_FAIL;
					   			System.out.println("Response not matched expected :"+ApiDescription);
					   			return false;
				        	}
				        }
					}
			    	else
			    	{
			    		 Validation= true;
			    		 //ApiDescription=ApiDescription+"\n  Expected Values not provided";
			    		 return Validation;
			    	}
		   		 }
		   		 catch (AssertionError e)
		   		 {     		
		   			System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Mismatched Actual Values:"+e.getMessage();
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    	catch (ClassCastException e)
		   		 {     		
		    		System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Key not found :"+CurrKey;
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    	catch (Exception e)
		   		 {     		
		    		System.out.println("Err Catch ResponseExpectedValidation :"+e.getMessage());
		   			ApiDescription=ApiDescription+"\n  Validation fails :"+e.getMessage();
		   			APIStatus=Constants.KEYWORD_FAIL;
		   			return false;
		   		 }
		    APIStatus=Constants.KEYWORD_PASS;
			ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
	    	return Validation;
	    	
	    }
	    
	    /***************************************************************************************
		 *  Function name 		: GetOutkeyValueFromResponse
		 *  Reuse Function 		:  GetResponseContentType
		 *  Description 		: Get output key value from the response
		/****************************************************************************************/    
		public static String VerifyPathFromResponse(Response res,String Key) 
		{
			Log._logInfo("Verify the key exist in API Response :"+Key);
		   	String bResPathValid=null;
	
		    	try
		   		 {  
		    		bResPathValid=res.then().extract().path(Key);
			    	System.out.println("Path exist : "+Key+" : "+bResPathValid);
		    	}
		    	catch (AssertionError e)
		   		 {     		
		   			 System.out.println("Err Catch VerifyPathFromResponse :"+e.getMessage());
		   			 return bResPathValid;
		   		 }
		    	catch (ClassCastException e)
		   		 {     		
		   			 System.out.println("Err Catch VerifyPathFromResponse :"+e.getMessage());
		   			 return bResPathValid;
		   		 }
		    	return bResPathValid;
		    	
		    }
	    
	    /**************************************************************************
		 *  Function name 		: GetResponseTime
		 *  Reuse Function 		: 
		 *  Description 		: Get response time from response    
		 /**********************************************************************/  
	    public long GetResponseTime(Response res)
	    {
	    	Log._logInfo("Get API Response Time ");
	    	long repTime=0;
		    	try{  
				    repTime=res.then().extract().response().getTime();
				    //System.out.println("Response Time "+repTime);
				   // ApiDescription=ApiDescription+"\n  Response Time:"+repTime +" ms";
				 }
		    	catch (AssertionError e){     		
		   			 System.out.println("Err Catch GetResponseTime :"+e.getMessage());
		   			 ApiDescription=ApiDescription+"\n  Invalid Response Time: "+repTime;
		   			 return repTime;
		   		 }
	    	return repTime;	    	
	    }

	    /**************************************************************************
		 *  Function name 		: GetResponseTimeinMS
		 *  Reuse Function 		: 
		 *  Description 		: Get response time in ms from response    
		 /**********************************************************************/  
	    public String GetResponseTimeinMS(Response res)
	    {
	    	Log._logInfo("Get Response time(ms) ");
	    	String respinms="";
	    	long repTime=0;
		    	try
		   		 {  
				    repTime=res.then().extract().response().getTime();
				    System.out.println("Resp Time "+repTime);
				    respinms=repTime+" ms";
				   // ApiDescription=ApiDescription+"\n  Response Time:"+repTime +" ms";
				 }
		    	catch (AssertionError e)
		   		 {     		
		   			
		   			 System.out.println("Err Catch GetResponseTime :"+e.getMessage());
		   			 ApiDescription=ApiDescription+"\n  Invalid Response Time: "+repTime;
		   			 return respinms;
		   		 }
		    	//ApiDescription=ApiDescription+"\n  Expected Values matched with actual values";
	    	return respinms;
	    	
	    }
	    
	    /**************************************************************************
		 *  Function name 		: GetResponseContentType
		 *  Reuse Function 		: 
		 *  Description 		: Get content type from response    
		 /**********************************************************************/  
	    public static String GetResponseContentType(Response res)
	    {
	    	Log._logInfo("Get Response ContentType ");
	    	String repContentType=null;
	    	String RespContent=null;
	    	try
	   		 {  
	    		repContentType=res.then().extract().response().contentType();
			    //System.out.println("Resp Content Type "+repContentType);
	    		
	      		if ((repContentType.contains("json"))|(repContentType.contains("JSON")))
	    		{
	      			RespContent="json";
	    		}
	    		else if ((repContentType.contains("xml"))|(repContentType.contains("XML")))
	    		{
	    			RespContent="xml";
	    		}	
	    		else if ((repContentType.contains("html"))|(repContentType.contains("HTML")))
	    		{
	    			RespContent="html";
	    		}
	    		else
	    		{
	    			RespContent="txt";
	    		}
	  
			 }
	    	catch (AssertionError e){     		
	   			 System.out.println("Err Catch GetResponseContentType :"+e.getMessage());
	   			 ApiDescription=ApiDescription+"\n  Invalid Content Type:"+repContentType;
	   			 return RespContent;
	   		 }
	    	return RespContent;
	    }
	    
    /********************************************************************************
	 *  Function name 		: ValidataSchema
	 *  Reuse Function 		: 
	 *  Description 		: Validate response with schema from JSON, XML-XSD/DTD
	 /*******************************************************************************/  
	public Map<String, String> ValidataSchema(Response res,String SchemaFilepath,String ResponseFilePath) throws IOException
	{
		Log._logInfo("Validate API Response with Schema file "+SchemaFilepath);
	   	String repContentType=null;
	    File SchmFile = new File(SchemaFilepath);
	 	Map<String, String> mapSchValidation = new HashMap<String,String>();
	 	String Description = null;
	 	String Status=null;
	   	 if (SchmFile.exists())
    	 {
	    	try
	   		 {  
	    			repContentType=GetResponseContentType(res);
		    		if ((repContentType.contains("json"))|(repContentType.contains("JSON")))
		    		{
		    			Description="Json Schema Validation : ";
		    			//res.then().assertThat().body(matchesJsonSchemaInClasspath(""));
		    			//Map<String, String> mapJsonSchValidation =ValidateJSONSchema(SchemaFilepath,ResponseFilePath);
		    			//Status=mapJsonSchValidation.get("APIStatus");
		    			//Description=Description+"\n"+mapJsonSchValidation.get("ApiDescription");
		    		}
		    		else if ((repContentType.contains("xml"))|(repContentType.contains("XML")))
		    		{
		    			String ext =FilenameUtils.getExtension(SchemaFilepath);
		    			if (ext.equalsIgnoreCase("xsd"))
		    			{
		    				Description="XML Schema Valitation with XSD :";
		    				res.then().assertThat().body(matchesXsd(SchmFile));
		    				Status=Constants.KEYWORD_PASS;
		    				Description=Description+"\n Passed ";
		    			}
		    			else if (ext.equalsIgnoreCase("dtd"))
		    			{
		    				Description="XML Schema Valitation with Dtd :";
		    				res.then().assertThat().body(matchesDtd(SchmFile));
		    				Status=Constants.KEYWORD_PASS;
		    				Description=Description+"\n Passed ";
		    			}
		    		else if ((repContentType.contains("html"))|(repContentType.contains("HTML")))
		    		{
		    			
		    		}
	    	}
			 }
	    	catch (AssertionError e)
	   		 {     		
	   			System.out.println("Err Catch ValidataSchema :"+e.getMessage());
	   			Status=Constants.KEYWORD_FAIL;
	   			Description=Description+"\n Faileded :";
	   		  	mapSchValidation.put("APIStatus", Status);
	   		   	mapSchValidation.put("ApiDescription", Description); 
	   			 return mapSchValidation;
	   		 }
	    	
    	 }
	   	 
	  	
	   	mapSchValidation.put("APIStatus", Status);
	   	mapSchValidation.put("ApiDescription", Description);   
	    	return mapSchValidation;
	    	
	    }
	   
   

    /********************************************************************************
	 *  Function name 		: VerifyResponseStatus
	 *  Reuse Function 		:
	 *  Description 		: Validate expected status from response
	 /*******************************************************************************/
	    public int VerifyResponseStatus(Response res,int expStatusCode)
	    {
	    	Log._logInfo("Validate API Response code "+expStatusCode);
	    	int RespStatus=0;
	    	try
	   		 {

			    res.then().assertThat().statusCode(expStatusCode);
			    RespStatus=res.getStatusCode();
			   // System.out.println("Response Status :"+RespStatus);

			 }
	    	catch (AssertionError e)
	   		 {
	    		 System.out.println("Err Catch ResponseStatus :"+e.getMessage());
	   			 APIStatus=Constants.KEYWORD_FAIL;
	   			 ApiDescription="The following response details: \n Invalid Response Code:"+RespStatus+"\n"+e.getMessage();
	   			 return RespStatus;
	   		 }
	    	APIStatus=Constants.KEYWORD_PASS;
		    ApiDescription="The following response details: \n Response Code: "+RespStatus;

	    	return RespStatus;
	    }

    /********************************************************************************
     *  Function name 		: VerifyResponseStatus
     *  Reuse Function 		:
     *  Description 		: Validate expected status from response
     /*******************************************************************************/
    public Map<String, String> VerifyResponseStatus(String TestCaseID,Response res,int expStatusCode)
    {
    	Log._logInfo("Verify API Response code "+expStatusCode);
    	Map<String, String> Statusmap = new HashMap<String,String>();
    	String Description;
        int RespStatus=0;
        try{
        	RespStatus=res.getStatusCode();
        	Log._logInfo("API Response code :"+RespStatus);
        	if (expStatusCode==0) {
        		Description="Actual Status Code : "+RespStatus;
		        Statusmap.put("APIStatus", Constants.KEYWORD_PASS);
		        Statusmap.put("ApiDescription", Description);    
		        return Statusmap;
        	}
        	//System.out.println("RespStatus :" +RespStatus);
        	if (RespStatus==expStatusCode){
			 	Description="Response validated : Status Code : "+RespStatus;
		        Statusmap.put("APIStatus", Constants.KEYWORD_PASS);
		        Statusmap.put("ApiDescription", Description);    
		        return Statusmap;
        	}
        	else
        	{
                Description="Response validation fail : Expected status code : "+expStatusCode;
                Statusmap.put("APIStatus", Constants.KEYWORD_FAIL);
                Statusmap.put("ApiDescription", Description);
                return Statusmap;
        	}
        		
            //res.then().assertThat().statusCode(expStatusCode);
          
        }
        catch (Exception e){
            Description="Invalid Response Code:"+RespStatus;
            Statusmap.put("APIStatus", Constants.KEYWORD_FAIL);
            Statusmap.put("ApiDescription", Description);
            Log._logInfo("API Response code :"+RespStatus);
            return Statusmap;
        }
      
    }
    
    
    /********************************************************************************
     *  Function name 		: VerifyResponseStatuswithPermission
     *  Reuse Function 		:
     *  Description 		: Validate expected status from response
     /*******************************************************************************/
    public Map<String, String> VerifyResponseStatuswithPermission(int expStatusCode,int ActStatusCode,List<String> LstUserPermissions,List<String> UserPermissions)
    {
    	Log._logInfo("Verify API Response code "+ActStatusCode);
    	Map<String, String> Statusmap = new HashMap<String,String>();
    	String Description;
        int RespStatus=0;
        try{
        	
        	switch(LstUserPermissions.size()) {
        	case 1:
        		if (UserPermissions.contains(LstUserPermissions.get(0))) 
        			RespStatus=expStatusCode;
        		else 
        			RespStatus=404;        		
        		break;
        	case 2:
        		if ((UserPermissions.contains(LstUserPermissions.get(0)))||(UserPermissions.contains(LstUserPermissions.get(1)))) 
        			RespStatus=expStatusCode;
        		else 
        			RespStatus=404;   
        		break;
        	case 3:
        		if ((UserPermissions.contains(LstUserPermissions.get(0)))||(UserPermissions.contains(LstUserPermissions.get(1)))||(UserPermissions.contains(LstUserPermissions.get(2)))) 
        			RespStatus=expStatusCode;
        		else 
        			RespStatus=404;   
        		break;
        		
        	}
        	
        	//System.out.println("RespStatus :" +RespStatus);
        	if (RespStatus==404) {
	        	if ((ActStatusCode==404)||(ActStatusCode==403))
	        	{
	        		 Description="Response validated : Status Code is "+ActStatusCode+" without permissions :"+LstUserPermissions;
	        	        Statusmap.put("APIStatus", Constants.KEYWORD_PASS);
	        	        Statusmap.put("ApiDescription", Description);    
	        	        Log._logInfo("API Response code :"+RespStatus);
	        	        return Statusmap;
	        		
	        	}
	        	else
	        	{
	                Description="Response validation fail : Expected status code is 403 without permissions :"+LstUserPermissions;
	                Statusmap.put("APIStatus", Constants.KEYWORD_FAIL);
	                Statusmap.put("ApiDescription", Description);
	                Log._logInfo("API Response code :"+RespStatus);
	                return Statusmap;
	        	}
        	}
        	else
        	{
        		
        			if ((ActStatusCode==200)||(ActStatusCode==201)||(ActStatusCode==400))
	        	{
	        		 Description="Response validated : Status Code is "+ActStatusCode+" with permissions :"+LstUserPermissions;
	        	        Statusmap.put("APIStatus", Constants.KEYWORD_PASS);
	        	        Statusmap.put("ApiDescription", Description);    
	        	        Log._logInfo("API Response code :"+RespStatus);
	        	        return Statusmap;
	        		
	        	}
	        	else
	        	{
	                Description="Response validation fail : Expected Status code is "+RespStatus+" with permissions :"+LstUserPermissions;
	                Statusmap.put("APIStatus", Constants.KEYWORD_FAIL);
	                Statusmap.put("ApiDescription", Description);
	                Log._logInfo("API Response code :"+RespStatus);
	                return Statusmap;
	        	}
        		
        	}
        		
            //res.then().assertThat().statusCode(expStatusCode);
          
        }
        catch (Exception e){
            System.out.println("Err Catch ResponseStatus for "+TestCaseID+ " :" +e.getMessage());
            Description="Response invalid status Code:"+RespStatus+"\n"+e.getMessage();
            Statusmap.put("APIStatus", Constants.KEYWORD_FAIL);
            Statusmap.put("ApiDescription", Description);
            Log._logInfo("API Response code :"+RespStatus);
            return Statusmap;
        }
      
    }

    	/********************************************************************************
		 *  Function name 		: VerifyResponseStatus
		 *  Reuse Function 		: 
		 *  Description 		: Validate expected status from Actual
		 /*******************************************************************************/  
	    public static void VerifyResponseStatus(int ActualStatusCode,int expStatusCode)
	    {
	    	Log._logInfo("Validate API Response code "+expStatusCode);
	     
	    		if (ActualStatusCode==expStatusCode)
	    		{
	    			APIStatus=Constants.KEYWORD_PASS;
	    		    ApiDescription="Valid Response Code: "+ActualStatusCode;
	    		}
	    	else
	   		 {     		
	   			APIStatus=Constants.KEYWORD_FAIL;
	   			System.out.println("Response Status "+ActualStatusCode);
	   			ApiDescription="Invalid Response status:"+ActualStatusCode;
	   		 }
	
	    }
	    
	    /*************************************************************************************************
		 *  Function name 		: GetReferenceValue
		 *  Reuse Function 		: 
		 *  Description 		: Get the reference value from the URL column  
		/**************************************************************************************************/   
		public static Map<String, String> GetReferenceValue(JSONObject jsTestReportData, String XString)
	    {
			Log._logInfo("Get reference value  "+XString);
			Map<String, String> Refencemap = new HashMap<String,String>();
	    	String OpValue=null;
	    	String ReTurnString=XString;
	    	String TCID = null,sRefDataSetID=null,TcColm;
	    	String Description=null;
	    	Refencemap.put("ReferenceValue", ReTurnString);
	    	Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
			Refencemap.put("ApiDescription", Description);  
	    	while (ReTurnString.contains(Constants.KEYWORD_REF))
			{
		    	int strlen=XString.length();
		    	if ((XString.contains("{"))&(XString.contains("}")))
		        {
		    		String Url1 = XString.substring(0,XString.indexOf("{"));
		    		String RefString = XString.substring(XString.indexOf("{")+1, XString.indexOf("}"));
		    		//System.out.println("Ref String : "+RefString);
		    		String[] ArTcCol = RefString.split(Constants.DATA_SPLIT);
		    		String RefTCid=ArTcCol[0];
		    		//System.out.println(RefTCid);
		    		String[] A1tTCs=RefTCid.split(Constants.KEYWORD_REF);
		    		if (A1tTCs[1].contains(Constants.DATASET_SPLIT)){
		    			String[] SplitDataset=A1tTCs[1].split(Constants.DATASET_SPLIT);
		    			TCID=SplitDataset[0];
		    			sRefDataSetID=SplitDataset[1];
		    		}
		    		else{
		    			TCID=A1tTCs[1];
		    		}
		    		TcColm=ArTcCol[1];
		    		String Urllast = XString.substring(XString.indexOf("}")+1,strlen);
		    		//Environment Test Data
		    		if (TCID.equalsIgnoreCase(Constants.EnvironmentData))
		    			OpValue=CommonFunctions.getTestData(TcColm);
		    		else if (TCID.equalsIgnoreCase(Constants.CurrentSuiteData))
		    			OpValue=GetCurrentTestSuiteValues(sRefDataSetID,TcColm);
		    		else if (TCID.equalsIgnoreCase(Constants.GenerateOauthToken)) {
		    			if (Constants.OauthToken!=null)
		    				OpValue=Constants.OauthToken;
		    			else {
		    				Constants.OauthToken=getOAuthTokenWithClientCredential(TcColm);
		    				OpValue=Constants.OauthToken;
		    				
		    			}
		    		}
		    		else //Dependend test data
		    			OpValue=GetOutputKeyValue(jsTestReportData,TCID,sRefDataSetID,TcColm);
		    		//System.out.println("Reference Value  : "+TCID+"-"+sRefDataSetID+" : "+TcColm+" :"+OpValue);
		    		if ((OpValue!=null)&&(OpValue.length()>0)){
		    			
		    			Log._logInfo("Get reference value Output "+OpValue);
        				ReTurnString=Url1+OpValue+Urllast;
        				Refencemap.put("ReferenceValue", ReTurnString);
        				Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
        				Refencemap.put("ApiDescription", Description);  
        				return Refencemap;
        			}
		        	else
		        	{
			    		ReTurnString=Url1+"Ref not Found"+Urllast;
			    		Description="Skipped due to dependent Test case  : " +TCID;
			    		Refencemap.put("ReferenceValue", ReTurnString);
        				Refencemap.put("APIStatus", Constants.KEYWORD_SKIP);
        				Refencemap.put("ApiDescription", Description); 
        				return Refencemap;
			    	}
		          }
			}
	    	return Refencemap;
	    }

		
		 /*************************************************************************************************
		 *  Function name 		: GetPathParameter
		 *  Reuse Function 		: 
		 *  Description 		: Get the Path Parameter reference value from the URL  
		/**************************************************************************************************/   
		public static Map<String, String> GetPathParameter(JSONObject jsTestReportData,JSONObject jsParameterData, String XString)
	    {
			Log._logInfo("Get reference value  "+XString);
			Map<String, String> Refencemap = new HashMap<String,String>();
	    	String OpValue=null;
	    	String ReTurnString=XString;
	    	String TCID = null,sRefDataSetID=null,TcColm;
	    	String Description=null;
	    	Refencemap.put("ReferenceValue", ReTurnString);
	    	Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
			Refencemap.put("ApiDescription", Description);  
			
	    	while (ReTurnString.contains("{"))
			{
//	    		System.out.println("ReTurnString pass2: "+ReTurnString);
		    	int strlen=ReTurnString.length();
		    	if ((ReTurnString.contains("{"))&(ReTurnString.contains("}")))
		        {
		    		String Url1 = ReTurnString.substring(0,ReTurnString.indexOf("{"));
		    		String RefString = ReTurnString.substring(ReTurnString.indexOf("{")+1, ReTurnString.indexOf("}"));
		    		String ParamValue =null;
//		    		System.out.println("RefString: "+RefString);
		    	
	    	        //System.out.println("Testsets: "+jsParameterData.toString());
	    	        //System.out.println("RefString: "+RefString);
	    	        ParamValue =  jsParameterData.getString(RefString);
	    	        //System.out.println("ParamValue: "+ParamValue);
	    	        
		    	        // System.out.println("\nTestcaseID Referen json TestData : "+jsTestReportData);
		  	    	  Map<String, String> mapRefUrl=GetReferenceValue(jsTestReportData,ParamValue);
		  	    	
		  	    	if (mapRefUrl.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_SKIP)){
		  	    			Refencemap.put("APIStatus", Constants.KEYWORD_SKIP);
		  	    			Refencemap.put("ApiDescription", mapRefUrl.get("ApiDescription")); 
		  	    			Refencemap.put("ReferenceValue", ReTurnString);
		  	    			return Refencemap;
				      }
		  	    		ParamValue= mapRefUrl.get("ReferenceValue");
	
		    		String Urllast = ReTurnString.substring(ReTurnString.indexOf("}")+1,strlen);
		    		
		    	//	System.out.println("Urllast  : "+Urllast);
		    		if ((ParamValue!=null)&&(ParamValue.length()>0)){
        				ReTurnString=Url1+ParamValue+Urllast;
        				//System.out.println("ReTurnString pass4  : "+ReTurnString);
        				Refencemap.put("ReferenceValue", ReTurnString);
        				Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
        				Refencemap.put("ApiDescription", Description);  
        			
        			}
		        	if(ParamValue==null){
			    		ReTurnString=Url1+"Ref not Found"+Urllast;
			    		Description="Skipped due to dependent Test case  : " +TCID;
			    		Refencemap.put("ReferenceValue", ReTurnString);
        				Refencemap.put("APIStatus", Constants.KEYWORD_SKIP);
        				Refencemap.put("ApiDescription", Description); 
        				return Refencemap;
			    	}
		          }
		    	
		    	///System.out.println("ReTurnString pass5  : "+ReTurnString);
			}
	    	return Refencemap;
	    }
		
		
		/*************************************************************************************************
		 *  Function name 		: GetQueryParameter
		 *  Reuse Function 		: 
		 *  Description 		: Get Query Parameter along with reference value from the URL  
		/**************************************************************************************************/   
		public static  Map<String, String> GetQueryParameter(JSONObject jsTestReportData,JSONObject jsParameterData, String XString){
			Log._logInfo("GetQueryParameter  "+XString);
	    	String OpValue=null;
	    	String ReTurnString=null;
	    	String Description=null;
	    	Map<String, String> Refencemap = new HashMap<String,String>();
	    	Refencemap.put("ReferenceValue", ReTurnString);
	    	Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
			Refencemap.put("ApiDescription", Description); 
			for (Object key : jsParameterData.keySet()) {
		        //based on you key types
		        String keyStr = (String)key;
		        String keyvalue = (String)jsParameterData.get(keyStr);
		        //Print key and value
		       // System.out.println("key: "+ keyStr + " value: " + keyvalue);
		        if (keyvalue.length()>0) {
		        	 if (keyvalue.contains("ref#")) {
		   	   	      // System.out.println("\nTestcaseID Referen json TestData : "+jsTestReportData);
		   	 	    	  Map<String, String> mapRefUrl=GetReferenceValue(jsTestReportData,keyvalue);
		   	 		      if (mapRefUrl.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_PASS)){
		   	 		    	keyvalue= mapRefUrl.get("ReferenceValue");
		   	 		      }
		   	 		      else {
		   	 		    	Refencemap.put("APIStatus", Constants.KEYWORD_SKIP);
		   	 		    	Refencemap.put("ApiDescription",  mapRefUrl.get("ApiDescription")); 
		   	 		    	Refencemap.put("ReferenceValue", ReTurnString);
		   	 		    	return Refencemap;
		   	 		      } 
		   	   	     }
		        	if (OpValue==null)
		        		OpValue="?"+keyStr+"="+keyvalue;
		        	else
		        		OpValue=OpValue+"&"+keyStr+"="+keyvalue;
		        
		        }
		        //Print key and value
		       // System.out.println(" OpValue: " + OpValue);
		    }
			if (OpValue!=null)
				ReTurnString=XString+OpValue;
			else
				ReTurnString=XString;
			
			
			Refencemap.put("ReferenceValue", ReTurnString);
	    	return Refencemap;
	    }
		
		/*************************************************************************************************
		 *  Function name 		: JSONtoJSON
		 *  Reuse Function 		: 
		 *  Description 		: JSONObject Post to update the reference value  
		/**************************************************************************************************/   
	  public static Map<String, Object> JSONtoJSON(JSONObject jsTestReportData,JSONObject Jsonobject) throws JSONException {
		  
		  	Map<String, Object> Refencemap = new HashMap<String,Object>();
	    
			
	    	JSONObject postjson=Jsonobject;
	    	String Description=null;
	    	Refencemap.put("ReferenceValue", postjson);
	    	Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
			Refencemap.put("ApiDescription", Description);
	   	    Iterator<String> keysItr = postjson.keys();
	   	    while(keysItr.hasNext()) {
	   	        String key = keysItr.next();
	   	        Object value = postjson.get(key);
	   	     if(value instanceof JSONArray) {
	  	           // value = JSONArraytoJSONArray(jsTestReportData,(JSONArray) value);
	  	          Map<String, Object> mapRefPostBody=JSONArraytoJSONArray(jsTestReportData,(JSONArray) value);
					if (mapRefPostBody.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_SKIP)){					
				    	  	Description=mapRefPostBody.get("ApiDescription").toString();
				    	  	Refencemap.put("ReferenceValue", postjson);
	      					Refencemap.put("APIStatus", mapRefPostBody.get("APIStatus"));
	      					Refencemap.put("ApiDescription", Description); 
	      				return Refencemap;
				    }
					value= mapRefPostBody.get("ReferenceValue");
	  	            
	  	       }
	   	     else if(value instanceof JSONObject) {
	           // value = JSONObjecttoJSONObject(jsTestReportData,(JSONObject) value);
	            Map<String, Object> mapRefPostBody=JSONtoJSON(jsTestReportData,(JSONObject) value);
				if (mapRefPostBody.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_SKIP)){
				
			    	  	Description=mapRefPostBody.get("ApiDescription").toString();
			    	  	
			    	  	Refencemap.put("ReferenceValue", value);
      					Refencemap.put("APIStatus", mapRefPostBody.get("APIStatus"));
      					Refencemap.put("ApiDescription", Description); 
      				return Refencemap;
			    }
				value= mapRefPostBody.get("ReferenceValue");
	       }
	   	     else {
	   	    	 
	   	    	 if (value.toString().equalsIgnoreCase("null")) {
	 		   		value=JSONObject.NULL;
	 		   		postjson.put(key, value);
	 		   	  }
	   	    	 else {
			   	     Map<String, String> mapRefUrl=GetReferencekeyValue(jsTestReportData,value.toString());
	     		      if (mapRefUrl.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_PASS)){
	     		    	 value= mapRefUrl.get("ReferenceValue");
	     		      }
	     		      else {
	     		    	Refencemap.put("APIStatus", Constants.KEYWORD_SKIP);
	     		    	Refencemap.put("ApiDescription",  mapRefUrl.get("ApiDescription")); 
	     		    	Refencemap.put("ReferenceValue", postjson);
	     		    	return Refencemap;
	     		      } 
	     		      postjson.put(key, value);
	   	    	 }
	   	    	 
		   	 
	   	    }
	   	     
	   	    }
	   	    Refencemap.put("ReferenceValue", postjson);
	   	    return Refencemap;
	   	}
	  
	  
	  /*************************************************************************************************
		 *  Function name 		: JSONObjecttoJSONObject
		 *  Reuse Function 		: 
		 *  Description 		: JSONObject Post to update the reference value  
		/**************************************************************************************************/   
	  public static JSONObject JSONObjecttoJSONObject(JSONObject jsTestReportData,JSONObject Jsonobject) throws JSONException {
		  
		  	Map<String, Object> Refencemap = new HashMap<String,Object>();
	    	JSONObject postjson=Jsonobject;
	   	    Iterator<String> keysItr = postjson.keys();
	   	    while(keysItr.hasNext()) {
	   	         String key = keysItr.next();
	   	         Object value = postjson.get(key);
		   	     if(value instanceof JSONArray) {
		  	            value = JSONArraytoJSONArray(jsTestReportData,(JSONArray) value);
		  	       }
		   	     else {
			   	     if (value.toString().equalsIgnoreCase("null")) 
					   		value=JSONObject.NULL;
			   	     else 
			   	    	value=GetReferencekeyValue(jsTestReportData,value.toString());
			   	  postjson.put(key, value);
		   	    	
		   	     }
	   	    }
	   	    return postjson;
	   	}
	  /*************************************************************************************************
		 *  Function name 		: toList
		 *  Reuse Function 		: 
		 *  Description 		: Convert JSONArray To List<Object>
		/**************************************************************************************************/ 
	  public static Map<String, Object> JSONArraytoJSONArray(JSONObject jsTestReportData,JSONArray array) throws JSONException {
		  Map<String, Object> Refencemap = new HashMap<String,Object>();
	    	String Description=null;
	    	Refencemap.put("ReferenceValue", array);
	    	Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
			Refencemap.put("ApiDescription", Description);
			
		  JSONArray JSONArrlist = new JSONArray();
	    for(int i = 0; i < array.length(); i++) {
	        Object value = array.get(i);
	        if(value instanceof JSONArray) {
	            //value = JSONArraytoJSONArray(jsTestReportData,(JSONArray) value);
	            Map<String, Object> mapRefPostBody=JSONArraytoJSONArray(jsTestReportData,(JSONArray) value);
				if (mapRefPostBody.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_SKIP)){					
			    	  	Description=mapRefPostBody.get("ApiDescription").toString();
			    	  	Refencemap.put("ReferenceValue", JSONArrlist);
      					Refencemap.put("APIStatus", mapRefPostBody.get("APIStatus"));
      					Refencemap.put("ApiDescription", Description); 
      				return Refencemap;
			    }
				value= mapRefPostBody.get("ReferenceValue");
	        }
	        else if(value instanceof JSONObject) {
	           // value = JSONObjecttoJSONObject(jsTestReportData,(JSONObject)value);
	            
	            Map<String, Object> mapRefPostBody=JSONtoJSON(jsTestReportData,(JSONObject) value);
				if (mapRefPostBody.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_SKIP)){
					Description=mapRefPostBody.get("ApiDescription").toString();
		    	  	Refencemap.put("ReferenceValue",JSONArrlist);
  					Refencemap.put("APIStatus", mapRefPostBody.get("APIStatus"));
  					Refencemap.put("ApiDescription", Description); 
  					return Refencemap;
      				//return JSONArrlist;
			    }
				value= mapRefPostBody.get("ReferenceValue");
	        }
	        else
	        {
        	   if (value.toString().equalsIgnoreCase("null")) 
			   		value=JSONObject.NULL;
        	   else {
        		   
        		   Map<String, String> mapRefUrl=GetReferencekeyValue(jsTestReportData,value.toString());
     		      if (mapRefUrl.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_PASS)){
     		    	 value= mapRefUrl.get("ReferenceValue");
     		      }
     		      else {
     		    	Refencemap.put("APIStatus", Constants.KEYWORD_SKIP);
     		    	Refencemap.put("ApiDescription",  mapRefUrl.get("ApiDescription")); 
     		    	Refencemap.put("ReferenceValue", JSONArrlist);
     		    	return Refencemap;
     		      } 
        		   
        	   }
	        }
	        JSONArrlist.put(value);
	    }
	    Refencemap.put("ReferenceValue", JSONArrlist);
	    return Refencemap;
	}
	  
	  /*************************************************************************************************
		 *  Function name 		: GetReferencekeyValue
		 *  Reuse Function 		: 
		 *  Description 		: Get Reference key Value
		/**************************************************************************************************/ 
	  public static Map<String, String> GetReferencekeyValue(JSONObject jsTestReportData,String value) throws JSONException {
		  String RetnValue=null;
		  Map<String, String> Refencemap = new HashMap<String,String>();
	    	String Description=null;
	    	Refencemap.put("ReferenceValue", value);
	    	Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
			Refencemap.put("ApiDescription", Description);
		 
		  if (value.contains(Constants.RANDOM_VALUE)) {
				String tempValue=value;
	   	    	if ((tempValue.contains("@mail.com"))||(tempValue.contains("@pearsonpathway.com"))) {
					String RtnEmail="AutoTest";
					String RecSplit[] = null;
					String RtnEmail_last=null;
					
					if (tempValue.indexOf("@pearsonpathway.com")>=0) {
						 RecSplit=tempValue.split("@pearsonpathway.com");
						 RtnEmail_last="@pearsonpathway.com";
					}
					else if (tempValue.indexOf("@mail.com")>=0) {
						 RecSplit=tempValue.split("@mail.com");
						 RtnEmail_last="@mail.com";
					}
					
					if (RecSplit.length>=1)
						if (RecSplit[0].indexOf("@random")>=0)
							
								RtnEmail=CommonFunctions.generateRandomString(RecSplit[0]);
						else
								RtnEmail=tempValue;
							
					tempValue=RtnEmail+RtnEmail_last;
					RetnValue=tempValue;
				}
	   	    	else
	   	    		RetnValue=CommonFunctions.generateRandomString(tempValue);
		  }
	   	  else if (value.contains(Constants.KEYWORD_REF)) {
 		     Map<String, String> mapRefUrl=GetReferenceValue(jsTestReportData,value);
		      if (mapRefUrl.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_PASS)){
		    	  RetnValue= mapRefUrl.get("ReferenceValue");
		      }
		      else {
		    	Refencemap.put("APIStatus", Constants.KEYWORD_SKIP);
		    	Refencemap.put("ApiDescription",  mapRefUrl.get("ApiDescription")); 
		    	Refencemap.put("ReferenceValue", mapRefUrl.get("ReferenceValue"));
		    	return Refencemap;
		      } 
	   	   }
	   	   else 
	   		   RetnValue=value;
	   	     
	   	    	 
		  Refencemap.put("ReferenceValue",RetnValue);	 
	    return Refencemap;
	}
	  
	  
		
	  
		/*************************************************************************************************
		 *  Function name 		: JSONtoJSON
		 *  Reuse Function 		: 
		 *  Description 		: JSONObject Post to update the reference value  
		/**************************************************************************************************/   
	  public static Map<String, Object> FormHeader(JSONObject jsTestReportData,JSONObject Jsonobject) throws JSONException {
		  
		  	Map<String, Object> Refencemap = new HashMap<String,Object>();
	    
			
	    	JSONObject postjson=Jsonobject;
	    	String Description=null;
	    	Refencemap.put("ReferenceValue", postjson);
	    	Refencemap.put("APIStatus", Constants.KEYWORD_PASS);
			Refencemap.put("ApiDescription", Description);
	   	    Iterator<String> keysItr = postjson.keys();
	   	    while(keysItr.hasNext()) {
	   	        String key = keysItr.next();
	   	        Object value = postjson.get(key);
	   	        
	   	     if (value.toString().contains(Constants.RANDOM_VALUE)) {
	   	    	value=CommonFunctions.generateRandomString(value.toString());
	   	    	postjson.put(key, value);
	   	    	 
	   	     }
	   	     else if (value.toString().contains(Constants.KEYWORD_REF)) {
	   	    	 //System.out.println("\nTestcaseID Referen json TestData : "+jsTestReportData);
	 	    	  Map<String, String> mapRefUrl=GetReferenceValue(jsTestReportData,value.toString());
	 		      if (mapRefUrl.get("APIStatus").equalsIgnoreCase(Constants.KEYWORD_PASS)){
	 		    	 value= mapRefUrl.get("ReferenceValue");
	 		    	 postjson.put(key, value);
	 		      }
	 		      else {
	 		    	 Refencemap.put("ReferenceValue", postjson);
	 		    	 Refencemap.put("APIStatus", Constants.KEYWORD_SKIP);
	 		    	 Refencemap.put("ApiDescription", mapRefUrl.get("ApiDescription"));
	 		    	return Refencemap;
	 		      }
	   	     }
	   	    }
	   	    return Refencemap;
	   	}
	/*************************************************************************************************
	 *  Function name 		: StoreRespose
	 *  Reuse Function 		: 
	 *  Description 		: Store the Web services Response to local src/res/Response path
	/**************************************************************************************************/
    public String StoreRespose(String Filename, String FileType,String Value)throws FileNotFoundException
    {
    	
    	String RespPath=null;
    	String Random = new SimpleDateFormat("yyyyMMddhhmm").format(new Date());
    	Filename=Filename+"_"+Random;
    	Log._logInfo("Export JSON File : "+Filename);
    	File file = new File(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+Filename+"."+FileType);
		try (FileOutputStream fop = new FileOutputStream(file)) 
		{
			// if file doesn't exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			// get the content in bytes
			byte[] contentInBytes = Value.getBytes();
			fop.write(contentInBytes);
			fop.flush();
			fop.close();
			//URL myUrl = file.toURI().toURL();
			RespPath=file.getAbsolutePath();
			//System.out.println("Response stored Path : "+RespPath);	
			///current_TestCase_xls.setCellData(Constants.TEST_STEPS_SHEET, Constants.Response, rowNum,myUrl.toString());
			return RespPath;
			
		}
     catch (IOException e) {e.printStackTrace();}
		return RespPath;
    }
    
	/*************************************************************************************************
	 *  Function name 		: GetRespString
	 *  Reuse Function 		: 
	 *  Description 		: Get Body string from Response
	/**************************************************************************************************/ 
	public String GetRespString(Response respString) 
	{
		Log._logInfo("Get API Response string ");
		String responseString=null;
		try{
	       
	        responseString = respString.asString();
	        //System.out.println("Response Stringsss :"+responseString);
		}
		catch(Exception e){
			 e.printStackTrace();
			 return responseString;
		}
		return responseString;
	}
	
	/*************************************************************************************************
	 *  Function name 		: GetJsonKeyValue
	 *  Reuse Function 		: 
	 *  Description 		: Get value for key from Response string
	/**************************************************************************************************/ 
	public static String GetJsonKeyValue(String JsonSSString,String Key)
    {   	
		Log._logInfo("Get JSON Key Value "+Key);
    	String ReString;
    	ReString=null;
    	ReString="Not Found";
	    try 
	      {
	    	JsonPath jsonResponse = new JsonPath(JsonSSString);
	    	ReString= jsonResponse.getString(Key);			 
	      } 
	    catch (Exception e) 
	      {
	    	e.printStackTrace();
	    	return ReString;
	       }        	      
     	return ReString;
      } 
	
	/*************************************************************************************************
	 *  Function name 		: GetJsonKeyValue
	 *  Reuse Function 		: 
	 *  Description 		: Get value for key from Response string
	/**************************************************************************************************/ 
	public static String GetOutputKeyValue(JSONObject JsonData,String Key1,String Key2,String opkey)
    {   	
		Log._logInfo("Get Output Key : "+Key1+Key2);
    	String ReString;
    	ReString=null;
	    try {
	    	JsonPath jsonResponse2 = new JsonPath(JsonData.toString());

    		String Query1="Tests.find{Tests->Tests.operationId==datefilter1}.Datasets.findAll{ Datasets -> Datasets.DatasetID == datefilter2}.Output.findAll{ Output -> Output.TestResultStatus == datefilter3}";
			List<Map> lstJsonValue = jsonResponse2.param("datefilter1", Key1).param("datefilter2", Key2).param("datefilter3", Constants.KEYWORD_PASS).get(Query1);
			//System.out.println("GetOutputKeyValue -lstJsonValue :"+lstJsonValue);
			if(lstJsonValue!=null){
			 for (Map<String , Object> map :lstJsonValue){
				// System.out.println("lstJsonValue map :"+map);
				 if (opkey.contains("Output_Values")) {
					 if (map.containsKey(opkey)) {
						 ReString=map.get(opkey).toString();
				
						 Log._logInfo("Get Output Key  value: "+opkey+" => "+ReString);
						 
					 }
				 }
				 else if (opkey.contains("Response#")) {
					 if (map.containsKey("Response")) {
						 ReString=map.get("Response").toString();
						 //System.out.println("Reference Value :"+ReString);
						 opkey=opkey.replaceFirst("Response#", "");
						 //System.out.println("opkey :"+opkey);
						 ReString=GetJsonKeyValue(ReString,opkey);
						 //System.out.println("Reference Value of "+opkey+" => "+ReString);
						 Log._logInfo("Get Output Key  value: "+opkey+" => "+ReString);
					 }
				 }
				 return ReString;
			 }
			}
	      } 
	    catch (NullPointerException e) 
	      {
	    	 System.out.println("Null Exception ");
	    	return null;
	    	
	       }   
	    catch (Exception e) 
	      {
	    	e.printStackTrace();
	       }        	      
     	return ReString;
      } 
	
	
	
	/*************************************************************************************************
	 *  Function name 		: GetCurrentTestSuiteValues
	 *  Reuse Function 		: 
	 *  Description 		: Get Current suite value for key from Response string
	/**************************************************************************************************/ 
	public static String GetCurrentTestSuiteValues(String Key1,String opkey)
    {   	
		Log._logInfo("GetCurrentTestSuiteValues : "+Key1);
    	String ReString;
    	ReString=null;
 
	    try {
	    	
	    	JsonPath jpathquery = new JsonPath(CurrentTestset.toString());
    		String Query2="Datasets.findAll{Datasets -> Datasets.DatasetID == datefilter1}.Output.findAll{ Output -> Output.TestResultStatus == datefilter2}";
			List<Map> lstJsonValue = jpathquery.param("datefilter1", Key1).param("datefilter2", Constants.KEYWORD_PASS).get(Query2);
			//System.out.println("GetOutputKeyValue -lstJsonValue :"+lstJsonValue);
			if(lstJsonValue!=null){
			 for (Map<String , Object> map :lstJsonValue){
				// System.out.println("lstJsonValue map :"+map);
				 if (opkey.contains("Output_Values")) {
					 if (map.containsKey(opkey)) {
						 ReString=map.get(opkey).toString();
						 Log._logInfo("GetCurrentTestSuiteValues Output_Values: "+opkey+" => "+ReString);
					 }
				 }
				 else if (opkey.contains("Response#")) {
					 if (map.containsKey("Response")) {
						 ReString=map.get("Response").toString();
						 System.out.println("Reference Value :"+ReString);
						 opkey=opkey.replaceFirst("Response#", "");
						 //System.out.println("opkey :"+opkey);
						 ReString=GetJsonKeyValue(ReString,opkey);
						 //System.out.println("Reference Value of "+opkey+" => "+ReString);
						 Log._logInfo("GetCurrentTestSuiteValues Response#: "+opkey+" => "+ReString);
					 }
				 }
				 return ReString;
			 }
			}
	      } 
	    catch (NullPointerException e) 
	      {
	    	 System.out.println("Null Exception ");
	    	return null;
	    	
	       }   
	    catch (Exception e) 
	      {
	    	e.printStackTrace();
	       }        	      
     	return ReString;
      } 
	
	/*************************************************************************************************
	 *  Function name 		: deletfile
	 *  Reuse Function 		: 
	 *  Description 		: Delete file from location
	/**************************************************************************************************/
	public static void deletfile(String FilePath)
	{
		Log._logInfo("Delete File "+FilePath);
		try {
			
			File files= new File(FilePath);
			if (files.exists())
			{
				files.delete();
				//System.out.println("File "+files.getName()+" deleted: "+bool);
			}
		} catch (Exception x) {
		    // File permission problems are caught here.
		    System.out.println("Err Catch in deletfile"+x);
		}
	}
	
	

	/*************************************************************************************************
	 *  Function name 		: StoreReponseToExternal
	 *  Reuse Function 		: 
	 *  Description 		: Store the response string to local path
	/**************************************************************************************************/ 
	 public void StoreReponseToExternal(String Filename,String Value)throws FileNotFoundException
	    {
		 Log._logInfo("Store response to External "+Filename);
		 	String TempPath=null;
		 	Boolean result;
		 	File folder = new File(TempPath);
	        //ResponseBuilder response = Response.ok((Object) file);
		 	if (!folder.exists()) {
		 		 try{
		 			folder.getParentFile().mkdirs();
		 			//folder.mkdir();
		 	        result = true;
		 	    } 
		 	    catch(SecurityException se){
		 	        //handle it
		 	    }
		 	}
		 	if (result=true)
		 	{
		    	File file = new File(TempPath);
				try (FileOutputStream fop = new FileOutputStream(file)) 
				{
					// if file doesn't exists, then create it
					file.getParentFile().mkdirs();
					if (!file.exists()) {
						file.createNewFile();
					}
					// get the content in bytes
					byte[] contentInBytes = Value.getBytes();
					fop.write(contentInBytes);
					fop.flush();
					fop.close();
				}
		     catch (IOException e) {e.printStackTrace();}
	    }
		 	
	    }
	 
	 /***************************************************************************************
		 *  Function name 		: getOAuthTokenWithClientCredential
		 *  Reuse Function 		:  
		 *  Description 		: Generate Outh Token Permission for different module
		/****************************************************************************************/
	  	public static String getOAuthTokenWithClientCredential(String Tokenname) throws JSONException {
	  		Log._logInfo("GetOauthToken ");
			String Outh2Token=null;
			String Clientid=FileReaderManager.getInstance().getJsonReader().getClientidbyTokenname(Tokenname);
			String Clientsecret=FileReaderManager.getInstance().getJsonReader().getClientsecretbyTokenname(Tokenname);
			String tokenurl=FileReaderManager.getInstance().getJsonReader().gettokenurlbyTokenname(Tokenname);
			String scope=FileReaderManager.getInstance().getJsonReader().getscopebyTokenname(Tokenname);
			String granttype=FileReaderManager.getInstance().getJsonReader().getgranttypebyTokenname(Tokenname);
			Response response = 
			        given()
			 .auth().preemptive().basic(Clientid,Clientsecret)
			 .contentType("application/x-www-form-urlencoded")
			 .formParam("grant_type", granttype)
			 .formParam("scope", scope)
			        .when()
			 .post(tokenurl);
			 int Respcode=response.getStatusCode();
			 //System.out.println("Auth Respcode " + Respcode);
			 if (Respcode==200) {
				 //System.out.println("Resp " + response.asString());
			     JSONObject jsonObject = new JSONObject(response.getBody().asString());
			     String accessToken = jsonObject.get("access_token").toString();
			     String tokenType = jsonObject.get("token_type").toString();
			     Outh2Token=tokenType+" "+accessToken;
			     //System.out.println("Oauth Token with type " +Outh2Token);
			 }
			   return Outh2Token;
			     
			 }	 
   


	}
	