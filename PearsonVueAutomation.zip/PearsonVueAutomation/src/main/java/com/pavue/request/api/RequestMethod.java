package com.pavue.request.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import com.pavue.request.api.App;
import com.pavue.webdriver.Log;
import com.pavue.common.core.CommonFunctions;
import com.pavue.common.core.FileReaderManager;
import com.pavue.common.util.Constants;
import io.restassured.http.Cookies;
import io.restassured.response.Response;
import io.restassured.specification.ProxySpecification;

import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.CloseableHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

public class RequestMethod 
{
	// properties
	public static Properties CONFIG;
	static CloseableHttpClient httpclient;
	static HttpClientContext context;
  	static ProxySpecification proxySpecification;
  	public static String APIServer="";
  	public static String ApiDescription = "";
  	public static String APIStatus="";
  	public Cookies mycookies=null;
  	public static String ScopeUuid=null;
  	public App API=null;
  	public int MaxDeleteStudent=10;
  	
  	public RequestMethod() throws IOException{
		//Initialize
		APIServer=FileReaderManager.getInstance().getJsonReader().getApplicationUrl();
		API=new App();
		//APIServer="https://pa-dev-main.pearsonpathway.com";
	}

    /***************************************************************************************
	 *  Function name 		: GetAccount_Permissions
	 *  Reuse Function 		:  
	 *  Description 		: GET Account Permission for different module
	/****************************************************************************************/  
	public HashMap<String,Object> GetAccount_Permissions(HashMap<String, Object> headerdata, String loggedInuser, String SelectedCustomer)
	{
		
		String APIURL="";
		String Customer="";
		int StatusCode=0;
		Response GetResp=null;
		HashMap<String,Object> MapSetField = null;
		List <Map<String,Object>> LstUserPerms=null;
		List <String> ListPerms= null;
    	APIURL="/api/account?email="+loggedInuser;
		APIURL=APIServer+APIURL;
		System.out.println("Get- Request :"+APIURL);
		GetResp=API.Get_Method(APIURL, headerdata);
    	StatusCode=GetResp.getStatusCode();
    	if (StatusCode==200) {
    		//ScopeUuid= jsonResponse.getString("defaultScopeUuid").toString();
    		System.out.println("INFO api/account Response code = " +StatusCode);
    		//Set JsonObject from API response string
	    	JSONObject jsonObject = new JSONObject(GetResp.asString());
	    	//Iterate the organizationRoles Array
			JSONArray jsviewSectionsArray = jsonObject.getJSONArray("organizationRoles");
			LstUserPerms=new ArrayList<Map<String,Object>>();
			for (int i = 0; i < jsviewSectionsArray.length(); i++) {
				final JSONObject jsSectionobjects = jsviewSectionsArray.getJSONObject(i);
				Customer=jsSectionobjects.get("customerName").toString();
				if (Customer.equalsIgnoreCase(SelectedCustomer)) {
					MapSetField =   new HashMap<>();
					jsSectionobjects.get("customerReferenceId");
					jsSectionobjects.get("organizationName");
					jsSectionobjects.get("organizationReferenceId");
					MapSetField.put("customerName", jsSectionobjects.get("customerName"));
					MapSetField.put("customerReferenceId", jsSectionobjects.get("customerReferenceId"));
					MapSetField.put("organizationName", jsSectionobjects.get("organizationName"));
					MapSetField.put("organizationReferenceId", jsSectionobjects.get("organizationReferenceId"));
					MapSetField.put("roleDisplayCode", jsSectionobjects.get("roleDisplayCode"));
					MapSetField.put("roleReferenceId", jsSectionobjects.get("roleReferenceId"));
			    	//Iterate the Permissions Array
					 JSONArray jsviewCellsArray = jsSectionobjects.getJSONArray("permissions");
					 ListPerms= new ArrayList<String>();
					 for (int j = 0; j < jsviewCellsArray.length(); j++) 
						 ListPerms.add(jsviewCellsArray.get(j).toString());
					 MapSetField.put("Permissions", ListPerms);
					 
					 LstUserPerms.add(MapSetField);
		
				}
			}
			 System.out.println("MapSetField  : "+LstUserPerms);
    	}
    	return MapSetField;
	}
	
	/***************************************************************************************
	 *  Function name 		: GetAndDeleteOrg
	 *  Reuse Function 		:  
	 *  Description 		: GET and Delete Org
	/****************************************************************************************/  
	public HashMap<String,Object> GetAndDeleteOrg(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String orgTypeCode,String OrgSearchtext)
	{
		
		Log._logInfo("GetAndDeleteOrg : "+OrgSearchtext);
		String APIURL="";
		String refid="";
		String orgname="";
		String DeleteUrl="";
		boolean flag = false;
		int StatusCode=0;
		Response GetResp=null;
		HashMap<String,Object> MapSetField = null;
		//Update Header Orgref
		headerdata.put("orgreferenceid", orgreferenceid);
		try {
			if (headerdata==null)
				return MapSetField;
			
			if ((orgreferenceid==null)||(orgreferenceid.length()<1))
				return MapSetField;
			
			
			APIURL="/api/organization?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+OrgSearchtext+"')&descendantOf="+orgreferenceid+"&orgTypeCodeFilter="+orgTypeCode;
			APIURL=APIServer+APIURL;
			Log._logInfo("Get- Request :"+APIURL);
			//System.out.println("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	if (GetResp!=null) {
	    		StatusCode=GetResp.getStatusCode();
	    		//System.out.println("Response Code = " + StatusCode);
		    	if (StatusCode==200) {
		    		MapSetField = new HashMap<String,Object>();
			    	JSONObject jsonObject = new JSONObject(GetResp.asString());
					JSONArray jsdataArray = jsonObject.getJSONArray("data");
					//System.out.println("Org Length  : "+jsdataArray.length());
					for (int i = 0; i < jsdataArray.length(); i++) {
						JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
						refid=jsdataobjects.get("referenceId").toString();
						orgname=jsdataobjects.get("name").toString();
						//System.out.println("Org Details  : "+orgname+" : "+refid);
						boolean deleteflag = false;
						DeleteUrl="/api/organization/"+refid;
						deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
						if (deleteflag)
							MapSetField.put(refid, orgname);
					}
		    	}
	    	}
		}
		catch(Exception e)
		{
			return MapSetField;
		}
    	return MapSetField;
	}
	

	/***************************************************************************************
	 *  Function name 		: GetAndDeleteOrgclass
	 *  Reuse Function 		:  
	 *  Description 		: GET and Delete Orgclass
	/****************************************************************************************/  
	public HashMap<String,Object> GetAndDeleteOrgclass(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String ClassSearchtext)
	{
	
		Log._logInfo("GetAndDeleteOrgclass : "+ClassSearchtext);
		String APIURL="";
		String refid="";
		String classname="";
		String DeleteUrl="";
		boolean flag = false;
		int StatusCode=0;
		Response GetResp=null;
		HashMap<String,Object> MapSetField = null;
		//Update Header Orgref
		headerdata.put("orgreferenceid", orgreferenceid);
		try {
			if (headerdata==null)
				return MapSetField;
			
			if ((orgreferenceid==null)||(orgreferenceid.length()<1))
				return MapSetField;
			
			APIURL="/api/organization/"+orgreferenceid+"/organizationclass?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+ClassSearchtext+"')";
			APIURL=APIServer+APIURL;
			//System.out.println("Get- Request :"+APIURL);
			Log._logInfo("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	if (GetResp!=null) {
	    		StatusCode=GetResp.getStatusCode();
	    		System.out.println("Response Code = " + StatusCode);
		    	if (StatusCode==200) {
		    		MapSetField = new HashMap<String,Object>();
		    		//Set JsonObject from API response string
			    	JSONObject jsonObject = new JSONObject(GetResp.asString());
					JSONArray jsdataArray = jsonObject.getJSONArray("data");
				//	System.out.println("Class Length  : "+jsdataArray.length());
					for (int i = 0; i < jsdataArray.length(); i++) {
						JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
						refid=jsdataobjects.get("referenceId").toString();
						classname=jsdataobjects.get("name").toString();
						//System.out.println("Class Details  : "+classname+" : "+refid);
						flag=GetAndDeleteOrgclassStudents(headerdata,refid);
						if (flag){
							boolean deleteflag = false;
							DeleteUrl="/api/organizationclass/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (deleteflag)
								MapSetField.put(refid, classname);
						}
					}
		    	}
	    	}
		}
		catch(Exception e)
		{
			return MapSetField;
		}
    	return MapSetField;
	}
	
	
	/***************************************************************************************
	 *  Function name 		: GetAndDeleteOrgclassStudents
	 *  Reuse Function 		:  
	 *  Description 		: GET and Delete Orgclass student
	/****************************************************************************************/  
	public boolean GetAndDeleteOrgclassStudents(HashMap<String, Object> headerdata, String ClassRefid)
	{
		Log._logInfo("GetAndDeleteOrgclassStudents ");
		String APIURL="";
		String refid="";
		String studentReferenceId="";
		String DeleteUrl="";
		int StatusCode=0;
		boolean flag = false;
		Response GetResp=null;
		try {
			if (headerdata==null)
				return flag;
			
			if ((ClassRefid==null)||(ClassRefid.length()<1))
				return flag;
			
			APIURL="/api/organizationclass/"+ClassRefid+"/organizationclassstudent?$skip=0&$top=30&$count=true";
			APIURL=APIServer+APIURL;
			//System.out.println("Get- Request :"+APIURL);
			Log._logInfo("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	if (GetResp!=null) {
	    		StatusCode=GetResp.getStatusCode();
	    		//System.out.println("Response Code = " + StatusCode);
		    	if (StatusCode==200) {
		    		//Set JsonObject from API response string
			    	JSONObject jsonObject = new JSONObject(GetResp.asString());
					JSONArray jsdataArray = jsonObject.getJSONArray("data");
					//System.out.println("Class Student Length  : "+jsdataArray.length());
					if (jsdataArray.length()<MaxDeleteStudent) {
						flag=true;
						boolean deleteflag = false;
						for (int i = 0; i < jsdataArray.length(); i++) {
							JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
							refid=jsdataobjects.get("referenceId").toString();
							studentReferenceId=jsdataobjects.get("studentReferenceId").toString();
							//System.out.println("Class Student Details  : "+studentReferenceId+" : "+refid);
							DeleteUrl="/api/organizationclassstudent/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (!deleteflag)
								flag=false;
						}
					}
		    	}
	    	}
		}
		catch(Exception e)
		{
			return false;
		}
    	return flag;
	}
	
	/***************************************************************************************
	 *  Function name 		: DeleteOrgclassorStudents
	 *  Reuse Function 		:  
	 *  Description 		: Delete Orgclass student
	/****************************************************************************************/  
	public boolean DeleteOrgclassorStudents(HashMap<String, Object> headerdata, String DelClassUrl)
	{
		Log._logInfo("DeleteSessionorOrgorclassorStudents");
		String APIURL="";
		int StatusCode=0;
		Response GetResp=null;
		boolean flag = false;
		APIURL=DelClassUrl;
		try {
			if (headerdata==null)
				return flag;
			
			if ((DelClassUrl==null)||(DelClassUrl.length()<1))
				return flag;
			
			APIURL=APIServer+APIURL;
			//System.out.println("Delete- Request :"+APIURL);
			Log._logInfo("Delete- Request :"+APIURL);
			JSONObject postbody= new JSONObject();;
			GetResp=API.Delete_Method(APIURL, headerdata,postbody);
	    	if (GetResp!=null) {
	    		StatusCode=GetResp.getStatusCode();
	    		//System.out.println("Response = "+StatusCode+" - "+GetResp.asString());
		    	if (StatusCode==200) 
		    		flag=true;
		    	else
		    		Log._logWarning("Response : "+StatusCode+" => "+GetResp.asString());
	    	}
		}
		catch(Exception e)
		{
			return false;
		}
    	return flag;
	}
	
	
	/***************************************************************************************
	 *  Function name 		: GetAndDeleteSessions
	 *  Reuse Function 		:  
	 *  Description 		: GET and Delete Sessions
	/****************************************************************************************/  
	public HashMap<String,Object> GetAndDeleteSessions(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String SessSearchtext)
	{
		Log._logInfo("GetAndDeleteSessions");
		String APIURL="";
		String refid="";
		String crtDate,name;
		int compcount,totcount;
		int deletedcnt=0;
		String DeleteUrl="";
		boolean flag = false;
		int StatusCode=0;
		Response GetResp=null;
		boolean deleteflag = false;
		HashMap<String,Object> MapSetField = null;
		//Update Header Orgref
		headerdata.put("orgreferenceid", orgreferenceid);
		try {
			if (headerdata==null)
				return MapSetField;
			
			if ((orgreferenceid==null)||(orgreferenceid.length()<1))
				return MapSetField;
			
			//APIURL="/api/organization/"+orgreferenceid+"/testsessions?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+SessSearchtext+"')&$orderby=createdDate";
			APIURL="/api/organization/"+orgreferenceid+"/testsessions?$skip=10&$top="+maxcount+"&$filter=contains(searchVal,'"+SessSearchtext+"')";
			APIURL=APIServer+APIURL;
			//System.out.println("Get- Request :"+APIURL);
			Log._logInfo("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	if (GetResp!=null) {
	    		StatusCode=GetResp.getStatusCode();
	    		//System.out.println("Response Code = " + StatusCode);
		    	if (StatusCode==200) {
		    		MapSetField = new HashMap<String,Object>();
			    	JSONObject jsonObject = new JSONObject(GetResp.asString());
			    	//Iterate the organizationRoles Array
					JSONArray jsdataArray = jsonObject.getJSONArray("data");
					//System.out.println("Sessions Count  : "+jsdataArray.length());
					for (int i = 0; i < jsdataArray.length(); i++) {
						 flag = false;
						JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
						refid=jsdataobjects.get("referenceId").toString();
						name=jsdataobjects.get("name").toString();
						compcount=jsdataobjects.getInt("completedCount");
						totcount=jsdataobjects.getInt("totalCount");
						crtDate=jsdataobjects.get("createdDate").toString();
						//System.out.println("Session Details  : "+name+" : "+refid+" : "+compcount+" : "+totcount+" : "+crtDate);
						if ((compcount==0)&&(CommonFunctions.isDateBefore(crtDate,MaxDeleteStudent))) {
							if (totcount==0) 
								flag=true;
							else if (totcount<MaxDeleteStudent) 
								flag=GetAndDeleteSessionsStudents(headerdata,refid);
							
							if (flag){
								deleteflag = false;
								DeleteUrl="/api/testsession/"+refid;
								deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
								if (deleteflag)
									MapSetField.put(refid, name);
							}
						}
//						if (MapSetField.size()>=maxcount)
//							break;
					}
		    	}
	    	}
		}
		catch(Exception e)
		{
			return MapSetField;
		}
    	return MapSetField;
	}
	
	/***************************************************************************************
	 *  Function name 		: GetAndDeleteSessionsStudents
	 *  Reuse Function 		:  
	 *  Description 		: GET and Delete Sessions student
	/****************************************************************************************/  
	public boolean GetAndDeleteSessionsStudents(HashMap<String, Object> headerdata, String SessRefid)
	{
		Log._logInfo("GetAndDeleteSessionsStudents");
		String APIURL="";
		String refid="";
		String Teststatus="";
		String Procstatus="";
		String DeleteUrl="";
		int StatusCode=0;
		boolean flag = true;
		Response GetResp=null;
		try {
			if (headerdata==null)
				return flag;
			if ((SessRefid==null)||(SessRefid.length()<1))
				return flag;
			
			APIURL="/api/testsession/"+SessRefid+"/studenttestsession/status";
			APIURL=APIServer+APIURL;
			//System.out.println("Get- Request :"+APIURL);
			Log._logInfo("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	if (GetResp!=null) {
	    		StatusCode=GetResp.getStatusCode();
	    		//System.out.println("Response Code = " + StatusCode);
		    	if (StatusCode==200) {
			    	JSONObject jsonObject = new JSONObject(GetResp.asString());
			    	//Iterate the Data Array
			    	JSONArray keys = jsonObject.names ();
			    	for (int i = 0; i < keys.length (); i++) {
			    	   String key = keys.getString (i); 
			    	   JSONObject jsdataobjects =  jsonObject.getJSONObject(key);
			    	   refid=jsdataobjects.get("studentTestSessionReferenceId").toString();
			    	   Teststatus=jsdataobjects.get("status").toString();
			    	   Procstatus=jsdataobjects.get("proctorStatus").toString();
			    	   if ((!Teststatus.equalsIgnoreCase("ready"))&&(!Procstatus.equalsIgnoreCase("null"))) {	
						flag=false;
			    	   	break; 
			    	   }
			    	}
			    	if (flag) {
			    		boolean deleteflag = false;
			    		for (int i = 0; i < keys.length (); ++i) {
					    	   String key = keys.getString (i); 
					    	   JSONObject jsdataobjects =  jsonObject.getJSONObject(key);
					    	   refid=jsdataobjects.get("studentTestSessionReferenceId").toString();
					    	   
					    	   DeleteUrl="/api/studenttestsession/"+refid;
								deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
								if (!deleteflag) {
									flag=false;
									break;
								}

					    	}
			    	}
					
		    	}
	    	}
		}
		catch(Exception e)
		{
			return false;
		}
    	return flag;
	}
	
	
	/***************************************************************************************
	 *  Function name 		: GetAndDeleteTestAdmins
	 *  Reuse Function 		:  
	 *  Description 		: GET and Delete Test Admins
	/****************************************************************************************/  
	public HashMap<String,Object> GetAndDeleteTestAdmins(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String TestAdminSearchtext)
	{
		Log._logInfo("GetAndDeleteTestAdmins ");
		String APIURL="";
		String refid="";
		String testadminname="";
		String DeleteUrl="";
		boolean flag = false;
		int StatusCode=0;
		Response GetResp=null;
		HashMap<String,Object> MapSetField = null;
		
		try {
			if (headerdata==null)
				return MapSetField;
			
			if ((orgreferenceid==null)||(orgreferenceid.length()<1))
				return MapSetField;
		
			//Update Header Orgref
			headerdata.put("orgreferenceid", orgreferenceid);
			
			APIURL="/api/testadmin?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+TestAdminSearchtext+"')";
			APIURL=APIServer+APIURL;
			//System.out.println("Get- Request :"+APIURL);
			Log._logInfo("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	if (GetResp!=null) {
	    		StatusCode=GetResp.getStatusCode();
	    		//System.out.println("Response Code = " + StatusCode);
		    	if (StatusCode==200) {
		    		MapSetField = new HashMap<String,Object>();
			    	JSONObject jsonObject = new JSONObject(GetResp.asString());
					JSONArray jsdataArray = jsonObject.getJSONArray("data");
					//System.out.println("Tes Admin Count  : "+jsdataArray.length());
					for (int i = 0; i < jsdataArray.length(); i++) {
						JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
						refid=jsdataobjects.get("referenceId").toString();
						testadminname=jsdataobjects.get("name").toString();
						//System.out.println("Test Admin Details  : "+testadminname+" : "+refid);
						//MapSetField.put(refid, orgname);
						boolean deleteflag = false;
						DeleteUrl="/api/testadmin/"+refid;
						deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
						if (deleteflag)
							MapSetField.put(refid, testadminname);
					}
		    	}
	    	}
		}
		catch(Exception e)
		{
			return MapSetField;
		}
    	return MapSetField;
	}
	
	/***************************************************************************************
	 *  Function name 		: GetAndDeleteStudents
	 *  Reuse Function 		:  
	 *  Description 		: GET and Delete Students
	/****************************************************************************************/  
	public HashMap<String,Object> GetAndDeleteStudents(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String StuSearchtext)
	{
		
		String APIURL="";
		String refid="";
		String studfname, studLname="";
		String DeleteUrl="";
		boolean flag = false;
		int StatusCode=0;
		Response GetResp=null;
		HashMap<String,Object> MapSetField = null;
		
		try {
			if (headerdata==null)
				return MapSetField;
			
			if ((orgreferenceid==null)||(orgreferenceid.length()<1))
				return MapSetField;
		
			//Update Header Orgref
			headerdata.put("orgreferenceid", orgreferenceid);
			
			
			APIURL="/api/organization/"+orgreferenceid+"/descendants/student?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+StuSearchtext+"')";
			
			APIURL=APIServer+APIURL;
			System.out.println("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	if (GetResp!=null) {
	    		StatusCode=GetResp.getStatusCode();
	    		System.out.println("Response Code = " + StatusCode);
		    	if (StatusCode==200) {
		    		MapSetField = new HashMap<String,Object>();
			    	JSONObject jsonObject = new JSONObject(GetResp.asString());
			    	//Iterate the organizationRoles Array
					JSONArray jsdataArray = jsonObject.getJSONArray("data");
					System.out.println("Stu Count  : "+jsdataArray.length());
					for (int i = 0; i < jsdataArray.length(); i++) {
						JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
						refid=jsdataobjects.get("referenceId").toString();
						studfname=jsdataobjects.get("firstName").toString();
						studLname=jsdataobjects.get("lastName").toString();
						System.out.println("Student Details  : "+studfname+" "+studLname+" : "+refid);
						//MapSetField.put(refid, orgname);
						flag=CheckStudenthasSessions(headerdata,refid);
						if (flag) {
							boolean deleteflag = false;
							DeleteUrl="/api/student/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (deleteflag)
								MapSetField.put(refid, studfname+" "+studLname);
						}
					}
					 //System.out.println("MapSetField  : "+MapSetField);
		    	}
	    	}
		}
		catch(Exception e)
		{
			return MapSetField;
		}
    	return MapSetField;
	}
	
	/***************************************************************************************
	 *  Function name 		: CheckStudenthasSessions
	 *  Reuse Function 		:  
	 *  Description 		: Check Student has Sessions
	/****************************************************************************************/  
	public boolean CheckStudenthasSessions(HashMap<String, Object> headerdata, String StudRefid)
	{
		
		String APIURL="";
		int StatusCode=0;
		int datacnt=0;
		boolean flag = false;
		Response GetResp=null;
		try {
			if (headerdata==null)
				return flag;
			
			if ((StudRefid==null)||(StudRefid.length()<1))
				return flag;
			
			APIURL="/api/student/"+StudRefid+"/testsessions";
	
			APIURL=APIServer+APIURL;
			System.out.println("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	if (GetResp!=null) {
	    		StatusCode=GetResp.getStatusCode();
	    		System.out.println("Response Code = " + StatusCode);
		    	if (StatusCode==200) {
		    		JSONObject jsonObject = new JSONObject(GetResp.asString());
			    	//Iterate the organizationRoles Array
					JSONArray jsdataArray = jsonObject.getJSONArray("data");
					datacnt=jsdataArray.length();
					System.out.println("Student Session Count  : "+datacnt);
					if (datacnt<1) 
						flag=true;
			
		    	}
	    	}
		}
		catch(Exception e)
		{
			return false;
		}
    	return flag;
	}
	
	 /***************************************************************************************
		 *  Function name 		: GetEnv_CustomLabels
		 *  Reuse Function 		:  
		 *  Description 		: GET GetEnv Custom Labels for different Customer
		/****************************************************************************************/  
		public HashMap<String,String> GetEnv_CustomLabels(HashMap<String, Object> headerdata, String Customerref)
		{
			
			String APIURL="";
			String Customer="";
			int StatusCode=0;
			Response GetResp=null;
			HashMap<String,String> MapSetField = null;
			HashMap<String, String> mapCustlabels =null;
			List <String> ListPerms= null;
			mapCustlabels = GetDefaultCustomlabels();
	    	APIURL="/api/public/i18n/en.json?customerRefId="+Customerref;
			APIURL=APIServer+APIURL;
			System.out.println("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	StatusCode=GetResp.getStatusCode();
	    	if (StatusCode==200) {
	    		//System.out.println("INFO api/env Response = " + GetResp.asString());
	    		//Set JsonObject from API response string
		    	JSONObject jsonObject = new JSONObject(GetResp.asString());
				String lookuptext=null;
				//Map<String,Object> testHeader =CommonFunctions.toMap(jsonObject);
				for (String lookup : mapCustlabels.keySet()) {
					lookuptext=jsonObject.getString(lookup);
					if (!lookuptext.equalsIgnoreCase(mapCustlabels.get(lookup)))
						mapCustlabels.put(lookup, lookuptext);
					System.out.println("lookup: " + lookup+" lookuptext: " + lookuptext);
					  
				}
				
				
	    	}
	    	return mapCustlabels;
		}
		
		
		 /***************************************************************************************
		 *  Function name 		: GetAllEnvCustomLabels
		 *  Reuse Function 		:  
		 *  Description 		: GET GetEnv Custom Labels for different Customer
		/****************************************************************************************/  
		public Map<String,Object> GetAllEnvCustomLabels(HashMap<String, Object> headerdata, String Customerref)
		{
			
			String APIURL="";
			int StatusCode=0;
			Response GetResp=null;
			Map<String,Object> MapEnvLabel =null;
	    	APIURL="/api/public/i18n/en.json?customerRefId="+Customerref;
			APIURL=APIServer+APIURL;
			System.out.println("Get- Request :"+APIURL);
			GetResp=API.Get_Method(APIURL, headerdata);
	    	StatusCode=GetResp.getStatusCode();
	    	if (StatusCode==200) {
	    		//System.out.println("INFO api/env Response = " + GetResp.asString());
	    		//Set JsonObject from API response string
		    	JSONObject jsonObject = new JSONObject(GetResp.asString());
				MapEnvLabel =CommonFunctions.toMap(jsonObject);
	    	}
	    	return MapEnvLabel;
		}
		
		public static HashMap<String, String> GetDefaultCustomlabels() {
			// declare the hashmap
			HashMap<String, String> mapCuslabels = new HashMap<>();
			// put contents to our HashMap
			mapCuslabels.put("label.organizationtype.state", "State");
			mapCuslabels.put("pa.core.org.state.details.title", "State Details");
			mapCuslabels.put("pa.core.org.state.info.label", "State Info");
			mapCuslabels.put("pa.core.org.state.details.org.code", "State Code");
			mapCuslabels.put("pa.core.org.state.contact.info.label", "State Contact");
			
			
			mapCuslabels.put("label.organizationtype.lea", "LEA");
			mapCuslabels.put("pa.core.nav.link.label.org.list.lea", "LEAs");
			mapCuslabels.put("pa.core.nav.tab.label.org.list.lea", "LEA List");
			mapCuslabels.put("pa.core.org.search.column.title.name.lea", "LEA Name");
			mapCuslabels.put("pa.core.org.search.column.title.code.lea", "LEA Code");
			mapCuslabels.put("pa.core.org.lea.details.title", "LEA Details");
			mapCuslabels.put("pa.core.org.lea.info.label", "LEA Info");
			mapCuslabels.put("pa.core.org.lea.details.org.code", "LEA Code");
			mapCuslabels.put("pa.core.org.lea.contact.info.label", "LEA Contact");
			mapCuslabels.put("pa.core.org.lea.create.title", "Create LEA");
			
			mapCuslabels.put("label.organizationtype.district", "District");
			mapCuslabels.put("pa.core.nav.link.label.org.list.dist", "Districts");
			mapCuslabels.put("pa.core.nav.tab.label.org.list.dist", "District List");
			mapCuslabels.put("pa.core.org.search.column.title.name.dist", "District Name");
			mapCuslabels.put("pa.core.org.search.column.title.code.dist", "District Code");
			mapCuslabels.put("pa.core.org.district.details.title", "District Details");
			mapCuslabels.put("pa.core.org.district.info.label", "District Info");
			mapCuslabels.put("pa.core.org.district.details.org.code", "District Code");
			mapCuslabels.put("pa.core.org.district.contact.info.label", "District Contact");
			mapCuslabels.put("pa.core.org.district.create.title", "Create District");
			
			mapCuslabels.put("label.organizationtype.school", "School");
			mapCuslabels.put("pa.core.nav.link.label.org.list.sch", "Schools");
			mapCuslabels.put("pa.core.nav.tab.label.org.list.sch", "School List");
			mapCuslabels.put("pa.core.org.search.column.title.name.sch", "School Name");
			mapCuslabels.put("pa.core.org.search.column.title.code.sch", "School Code");
			mapCuslabels.put("pa.core.org.school.details.title", "School Details");
			mapCuslabels.put("pa.core.org.school.info.label", "School Info");
			mapCuslabels.put("pa.core.org.school.details.org.code", "School Code");
			mapCuslabels.put("pa.core.org.school.contact.info.label", "School Contact");
			mapCuslabels.put("pa.core.org.school.create.title", "Create School");
			mapCuslabels.put("pa.core.class.info.label.schoolname", "School");
			mapCuslabels.put("pa.core.class.search.column.title.school.name", "School");
			mapCuslabels.put("pa.core.grid.student.school.label", "School");
			mapCuslabels.put("pa.core.session.create.school.label", "School");
			mapCuslabels.put("pa.core.session.search.column.title.org", "School");
			mapCuslabels.put("pa.admin.search.student.session.school", "School");
			mapCuslabels.put("pa.core.shipment.column.title.district", "District");
			mapCuslabels.put("pa.core.shipment.column.title.school", "School");
			mapCuslabels.put("pa.core.nav.tab.label.outbound.shipment", "Ship to District/School");
			
			mapCuslabels.put("pa.core.student.search.column.title.state.student.id", "Student Id");
			mapCuslabels.put("pa.core.student.info.label.stateStudentId", "Student Id");
			mapCuslabels.put("pa.core.session.details.student.column.title.student.id", "Student ID");
			
			return mapCuslabels;
		}
		
		
		/***************************************************************************************
		 *  Function name 		: GetAndDeleteTests
		 *  Reuse Function 		:  
		 *  Description 		: GET and Delete Tests
		/****************************************************************************************/  
		public HashMap<String,Object> GetAndDeleteTests(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String TestAdminSearchtext)
		{
			Log._logInfo("GetAndDeleteTests ");
			String APIURL="";
			String refid="";
			String testCode="";
			String DeleteUrl="";
			boolean flag = false;
			int StatusCode=0;
			Response GetResp=null;
			HashMap<String,Object> MapSetField = null;
			
			try {
				if (headerdata==null)
					return MapSetField;
				
				if ((orgreferenceid==null)||(orgreferenceid.length()<1))
					return MapSetField;
			
				//Update Header Orgref
				headerdata.put("orgreferenceid", orgreferenceid);
				
				APIURL="/api/test?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+TestAdminSearchtext+"')";
				APIURL=APIServer+APIURL;
				//System.out.println("Get- Request :"+APIURL);
				Log._logInfo("Get- Request :"+APIURL);
				GetResp=API.Get_Method(APIURL, headerdata);
		    	if (GetResp!=null) {
		    		StatusCode=GetResp.getStatusCode();
		    		//System.out.println("Response Code = " + StatusCode);
			    	if (StatusCode==200) {
			    		MapSetField = new HashMap<String,Object>();
				    	JSONObject jsonObject = new JSONObject(GetResp.asString());
						JSONArray jsdataArray = jsonObject.getJSONArray("data");
						//System.out.println("Tes Admin Count  : "+jsdataArray.length());
						for (int i = 0; i < jsdataArray.length(); i++) {
							JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
							refid=jsdataobjects.get("referenceId").toString();
							testCode=jsdataobjects.get("testCode").toString();
							//System.out.println("Test Admin Details  : "+testadminname+" : "+refid);
							//MapSetField.put(refid, orgname);
							boolean deleteflag = false;
							DeleteUrl="/api/test/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (deleteflag)
								MapSetField.put(refid, testCode);
						}
			    	}
		    	}
			}
			catch(Exception e)
			{
				return MapSetField;
			}
	    	return MapSetField;
		}
		
	

		/***************************************************************************************
		 *  Function name 		: GetAndDeleteTests
		 *  Reuse Function 		:  
		 *  Description 		: GET and Delete Tests
		/****************************************************************************************/  
		public HashMap<String,Object> GetAndDeleteFormcode(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String TestAdminSearchtext)
		{
			Log._logInfo("GetAndDeleteFormcode ");
			String APIURL="";
			String refid="";
			String formcode="";
			String DeleteUrl="";
			boolean flag = false;
			int StatusCode=0;
			Response GetResp=null;
			HashMap<String,Object> MapSetField = null;
			
			try {
				if (headerdata==null)
					return MapSetField;
				
				if ((orgreferenceid==null)||(orgreferenceid.length()<1))
					return MapSetField;
			
				//Update Header Orgref
				headerdata.put("orgreferenceid", orgreferenceid);
				
				APIURL="/api/formcode?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+TestAdminSearchtext+"')";
				APIURL=APIServer+APIURL;
				//System.out.println("Get- Request :"+APIURL);
				Log._logInfo("Get- Request :"+APIURL);
				GetResp=API.Get_Method(APIURL, headerdata);
		    	if (GetResp!=null) {
		    		StatusCode=GetResp.getStatusCode();
		    		//System.out.println("Response Code = " + StatusCode);
			    	if (StatusCode==200) {
			    		MapSetField = new HashMap<String,Object>();
				    	JSONObject jsonObject = new JSONObject(GetResp.asString());
						JSONArray jsdataArray = jsonObject.getJSONArray("data");
						//System.out.println("Tes Admin Count  : "+jsdataArray.length());
						for (int i = 0; i < jsdataArray.length(); i++) {
							JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
							refid=jsdataobjects.get("referenceId").toString();
							formcode=jsdataobjects.get("code").toString();
							//System.out.println("Test Admin Details  : "+testadminname+" : "+refid);
							//MapSetField.put(refid, orgname);
							boolean deleteflag = false;
							DeleteUrl="/api/formcode/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (deleteflag)
								MapSetField.put(refid, formcode);
						}
			    	}
		    	}
			}
			catch(Exception e)
			{
				return MapSetField;
			}
	    	return MapSetField;
		}
		
		/***************************************************************************************
		 *  Function name 		: GetAndDeleteAccommodations
		 *  Reuse Function 		:  
		 *  Description 		: GET and Delete Accommodations
		/****************************************************************************************/  
		public HashMap<String,Object> GetAndDeleteAccommodations(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String TestAdminSearchtext)
		{
			Log._logInfo("GetAndDeleteAccommodations");
			String APIURL="";
			String refid="";
			String accomcode="";
			String DeleteUrl="";
			boolean flag = false;
			int StatusCode=0;
			Response GetResp=null;
			HashMap<String,Object> MapSetField = null;
			
			try {
				if (headerdata==null)
					return MapSetField;
				
				if ((orgreferenceid==null)||(orgreferenceid.length()<1))
					return MapSetField;
			
				//Update Header Orgref
				headerdata.put("orgreferenceid", orgreferenceid);
				
				APIURL="/api/accommodation?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+TestAdminSearchtext+"')";
				APIURL=APIServer+APIURL;
				//System.out.println("Get- Request :"+APIURL);
				Log._logInfo("Get- Request :"+APIURL);
				GetResp=API.Get_Method(APIURL, headerdata);
		    	if (GetResp!=null) {
		    		StatusCode=GetResp.getStatusCode();
		    		//System.out.println("Response Code = " + StatusCode);
			    	if (StatusCode==200) {
			    		MapSetField = new HashMap<String,Object>();
				    	JSONObject jsonObject = new JSONObject(GetResp.asString());
						JSONArray jsdataArray = jsonObject.getJSONArray("data");
						//System.out.println("Tes Admin Count  : "+jsdataArray.length());
						for (int i = 0; i < jsdataArray.length(); i++) {
							JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
							refid=jsdataobjects.get("referenceId").toString();
							accomcode=jsdataobjects.get("code").toString();
							//System.out.println("Test Admin Details  : "+testadminname+" : "+refid);
							//MapSetField.put(refid, orgname);
							boolean deleteflag = false;
							DeleteUrl="/api/accommodation/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (deleteflag)
								MapSetField.put(refid, accomcode);
						}
			    	}
		    	}
			}
			catch(Exception e)
			{
				return MapSetField;
			}
	    	return MapSetField;
		}
		
		
		/***************************************************************************************
		 *  Function name 		: GetAndDeleteIrregularity
		 *  Reuse Function 		:  
		 *  Description 		: GET and Delete irregularity
		/****************************************************************************************/  
		public HashMap<String,Object> GetAndDeleteIrregularity(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String TestAdminSearchtext)
		{
			Log._logInfo("GetAndDeleteIrregularity");
			String APIURL="";
			String refid="";
			String Irregcode="";
			String DeleteUrl="";
			boolean flag = false;
			int StatusCode=0;
			Response GetResp=null;
			HashMap<String,Object> MapSetField = null;
			
			try {
				if (headerdata==null)
					return MapSetField;
				
				if ((orgreferenceid==null)||(orgreferenceid.length()<1))
					return MapSetField;
			
				//Update Header Orgref
				headerdata.put("orgreferenceid", orgreferenceid);
				APIURL="/api/irregularity?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+TestAdminSearchtext+"')";
				APIURL=APIServer+APIURL;
				//System.out.println("Get- Request :"+APIURL);
				Log._logInfo("Get- Request :"+APIURL);
				GetResp=API.Get_Method(APIURL, headerdata);
		    	if (GetResp!=null) {
		    		StatusCode=GetResp.getStatusCode();
		    		//System.out.println("Response Code = " + StatusCode);
			    	if (StatusCode==200) {
			    		MapSetField = new HashMap<String,Object>();
				    	JSONObject jsonObject = new JSONObject(GetResp.asString());
						JSONArray jsdataArray = jsonObject.getJSONArray("data");
						//System.out.println("Tes Admin Count  : "+jsdataArray.length());
						for (int i = 0; i < jsdataArray.length(); i++) {
							JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
							refid=jsdataobjects.get("referenceId").toString();
							Irregcode=jsdataobjects.get("code").toString();
							//System.out.println("Test Admin Details  : "+testadminname+" : "+refid);
							//MapSetField.put(refid, orgname);
							boolean deleteflag = false;
							DeleteUrl="/api/irregularity/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (deleteflag)
								MapSetField.put(refid, Irregcode);
						}
			    	}
		    	}
			}
			catch(Exception e)
			{
				return MapSetField;
			}
	    	return MapSetField;
		}
		
		/***************************************************************************************
		 *  Function name 		: GetAndDeleteIrregularitycategory
		 *  Reuse Function 		:  
		 *  Description 		: GET and Delete irregularity
		/****************************************************************************************/  
		public HashMap<String,Object> GetAndDeleteIrregularitycategory(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String TestAdminSearchtext)
		{
			Log._logInfo("GetAndDeleteIrregularitycategory");
			String APIURL="";
			String refid="";
			String Irregcode="";
			String DeleteUrl="";
			boolean flag = false;
			int StatusCode=0;
			Response GetResp=null;
			HashMap<String,Object> MapSetField = null;
			
			try {
				if (headerdata==null)
					return MapSetField;
				
				if ((orgreferenceid==null)||(orgreferenceid.length()<1))
					return MapSetField;
			
				//Update Header Orgref
				headerdata.put("orgreferenceid", orgreferenceid);
				APIURL="/api/irregularitycategory?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+TestAdminSearchtext+"')";
				APIURL=APIServer+APIURL;
				//System.out.println("Get- Request :"+APIURL);
				Log._logInfo("Get- Request :"+APIURL);
				GetResp=API.Get_Method(APIURL, headerdata);
		    	if (GetResp!=null) {
		    		StatusCode=GetResp.getStatusCode();
		    		//System.out.println("Response Code = " + StatusCode);
			    	if (StatusCode==200) {
			    		MapSetField = new HashMap<String,Object>();
				    	JSONObject jsonObject = new JSONObject(GetResp.asString());
						JSONArray jsdataArray = jsonObject.getJSONArray("data");
						//System.out.println("Tes Admin Count  : "+jsdataArray.length());
						for (int i = 0; i < jsdataArray.length(); i++) {
							JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
							refid=jsdataobjects.get("referenceId").toString();
							Irregcode=jsdataobjects.get("code").toString();
							//System.out.println("Test Admin Details  : "+testadminname+" : "+refid);
							//MapSetField.put(refid, orgname);
							boolean deleteflag = false;
							DeleteUrl="/api/irregularitycategory/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (deleteflag)
								MapSetField.put(refid, Irregcode);
						}
			    	}
		    	}
			}
			catch(Exception e)
			{
				return MapSetField;
			}
	    	return MapSetField;
		}
		
		/***************************************************************************************
		 *  Function name 		: GetAndDeleteTestNavConfig
		 *  Reuse Function 		:  
		 *  Description 		: GET and Delete Test Nav Config
		/****************************************************************************************/  
		public HashMap<String,Object> GetAndDeleteTestNavConfig(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String TestAdminSearchtext)
		{
			Log._logInfo("GetAndDeleteTestNavConfig ");
			String APIURL="";
			String refid="";
			String testCode="";
			String DeleteUrl="";
			boolean flag = false;
			int StatusCode=0;
			Response GetResp=null;
			HashMap<String,Object> MapSetField = null;
			
			try {
				if (headerdata==null)
					return MapSetField;
				
				if ((orgreferenceid==null)||(orgreferenceid.length()<1))
					return MapSetField;
			
				//Update Header Orgref
				headerdata.put("orgreferenceid", orgreferenceid);
				
				APIURL="/api/testnavconfig?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+TestAdminSearchtext+"')";
				APIURL=APIServer+APIURL;
				//System.out.println("Get- Request :"+APIURL);
				Log._logInfo("Get- Request :"+APIURL);
				GetResp=API.Get_Method(APIURL, headerdata);
		    	if (GetResp!=null) {
		    		StatusCode=GetResp.getStatusCode();
		    		//System.out.println("Response Code = " + StatusCode);
			    	if (StatusCode==200) {
			    		MapSetField = new HashMap<String,Object>();
				    	JSONObject jsonObject = new JSONObject(GetResp.asString());
						JSONArray jsdataArray = jsonObject.getJSONArray("data");
						//System.out.println("Tes Admin Count  : "+jsdataArray.length());
						for (int i = 0; i < jsdataArray.length(); i++) {
							JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
							refid=jsdataobjects.get("referenceId").toString();
							testCode=jsdataobjects.get("name").toString();
							//System.out.println("Test Admin Details  : "+testadminname+" : "+refid);
							//MapSetField.put(refid, orgname);
							boolean deleteflag = false;
							DeleteUrl="/api/testnavconfig/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (deleteflag)
								MapSetField.put(refid, testCode);
						}
			    	}
		    	}
			}
			catch(Exception e)
			{
				return MapSetField;
			}
	    	return MapSetField;
		}
		
		/***************************************************************************************
		 *  Function name 		: GetAndDeletePermissions
		 *  Reuse Function 		:  
		 *  Description 		: GET and Delete Permission
		/****************************************************************************************/  
		public HashMap<String,Object> GetAndDeletePermissions(HashMap<String, Object> headerdata,String orgreferenceid,int maxcount, String TestAdminSearchtext)
		{
			Log._logInfo("GetAndDeletePermissions ");
			String APIURL="";
			String refid="";
			String permcode="";
			String DeleteUrl="";
			boolean flag = false;
			int StatusCode=0;
			Response GetResp=null;
			HashMap<String,Object> MapSetField = null;
			
			try {
				if (headerdata==null)
					return MapSetField;
				
				if ((orgreferenceid==null)||(orgreferenceid.length()<1))
					return MapSetField;
			
				//Update Header Orgref
				headerdata.put("orgreferenceid", orgreferenceid);
				
				APIURL="/api/permissions?$skip=0&$top="+maxcount+"&$filter=contains(searchVal,'"+TestAdminSearchtext+"')";
				APIURL=APIServer+APIURL;
				//System.out.println("Get- Request :"+APIURL);
				Log._logInfo("Get- Request :"+APIURL);
				GetResp=API.Get_Method(APIURL, headerdata);
		    	if (GetResp!=null) {
		    		StatusCode=GetResp.getStatusCode();
		    		//System.out.println("Response Code = " + StatusCode);
			    	if (StatusCode==200) {
			    		MapSetField = new HashMap<String,Object>();
				    	JSONObject jsonObject = new JSONObject(GetResp.asString());
						JSONArray jsdataArray = jsonObject.getJSONArray("data");
						//System.out.println("Tes Admin Count  : "+jsdataArray.length());
						for (int i = 0; i < jsdataArray.length(); i++) {
							JSONObject jsdataobjects = jsdataArray.getJSONObject(i);
							refid=jsdataobjects.get("referenceId").toString();
							permcode=jsdataobjects.get("code").toString();
							//System.out.println("Test Admin Details  : "+testadminname+" : "+refid);
							//MapSetField.put(refid, orgname);
							boolean deleteflag = false;
							DeleteUrl="/api/permissions/"+refid;
							deleteflag=DeleteOrgclassorStudents(headerdata,DeleteUrl);
							if (deleteflag)
								MapSetField.put(refid, permcode);
						}
			    	}
		    	}
			}
			catch(Exception e)
			{
				return MapSetField;
			}
	    	return MapSetField;
		}
		
		
		/***************************************************************************************
		 *  Function name 		: Getcustomerdemographics
		 *  Reuse Function 		:  
		 *  Description 		: GET Customer Permission for different module
		/****************************************************************************************/  
		public List <Map<String,Object>> Getcustomerdemographics(HashMap<String, Object> headerdata,String Customerref, String orgreferenceid)
		{
			
			String APIURL="";
			String Customer="";
			int StatusCode=0;
			Response GetResp=null;
			HashMap<String,Object> MapSetField = null;
			List <Map<String,Object>> LstCustDemo=null;
			List <String> ListValidValues= null;
			try {
				APIURL="/api/organization/"+orgreferenceid+"/customerdemographic";
				APIURL=APIServer+APIURL;
				System.out.println("Get- Request :"+APIURL);
				GetResp=API.Get_Method(APIURL, headerdata);
		    	StatusCode=GetResp.getStatusCode();
		    	System.out.println("INFO api/organization/customerdemographic Response code = " +StatusCode);
		    	if (StatusCode==200) {
		    		//ScopeUuid= jsonResponse.getString("defaultScopeUuid").toString();
		    		
		    		Map<String,Object> MapCustEnv = GetAllEnvCustomLabels(headerdata,Customerref);
		    		
		    		//Set JsonObject from API response string
			    	JSONObject jsonObject = new JSONObject(GetResp.asString());
			    	//Iterate the organizationRoles Array
					JSONArray jsdataArray = jsonObject.getJSONArray("data");
					LstCustDemo =new ArrayList<Map<String,Object>>();
					for (int i = 0; i < jsdataArray.length(); i++) {
						final JSONObject jsdemographobjects = jsdataArray.getJSONObject(i);
						String selectval="Yes";
						MapSetField =   new HashMap<>();
						String demographicType=jsdemographobjects.getString("demographicType");
						String demographicDisplayCode=jsdemographobjects.getString("demographicDisplayCode");
						if (MapCustEnv.containsKey(demographicDisplayCode))
							demographicDisplayCode=MapCustEnv.get(demographicDisplayCode).toString();
						
						MapSetField.put("demographicDisplayCode", demographicDisplayCode);
						MapSetField.put("demographicType", demographicType);
						MapSetField.put("customerReferenceId", jsdemographobjects.get("customerReferenceId"));
					
						if (demographicType.equalsIgnoreCase("MULTI_CHOICE")) {
							MapSetField.put("customerDemographicValidValues", jsdemographobjects.get("customerDemographicValidValues"));
							JSONArray jsValidValuesArray = jsdemographobjects.getJSONArray("customerDemographicValidValues");
							ListValidValues= new ArrayList<String>();
							 for (int j = 0; j < jsValidValuesArray.length(); j++) {
								 final JSONObject jsValidValuesobjects = jsValidValuesArray.getJSONObject(j);
								 if (j==0)
									 selectval=jsValidValuesobjects.get("validValue").toString();
								 ListValidValues.add(jsValidValuesobjects.get("validValue").toString());
							 }
							 MapSetField.put("customerDemographicValidValues", ListValidValues);
						}
						else if (demographicType.equalsIgnoreCase("DATE")) { 
							selectval=CommonFunctions.generateRandomDate(0);
							MapSetField.put("customerDemographicValidValues", jsdemographobjects.get("customerDemographicValidValues"));
						}
						else if (demographicType.equalsIgnoreCase("BOOLEAN")) { 
							selectval="No";
							MapSetField.put("customerDemographicValidValues", jsdemographobjects.get("customerDemographicValidValues"));
						}
						else if (demographicType.equalsIgnoreCase("TEXT")) { 
							selectval="UniqTest";
							MapSetField.put("customerDemographicValidValues", jsdemographobjects.get("customerDemographicValidValues"));
						}
						else if (demographicType.equalsIgnoreCase("NUMERIC")) { 
							selectval="2";
							MapSetField.put("customerDemographicValidValues", jsdemographobjects.get("customerDemographicValidValues"));
						}
						else {
							selectval="";
							MapSetField.put("customerDemographicValidValues", jsdemographobjects.get("customerDemographicValidValues"));
						}
						
						MapSetField.put("val", selectval);
				    	//Iterate the Permissions Array
						LstCustDemo.add(MapSetField);
						
					}
					 //System.out.println("LstCustDemo  : "+LstCustDemo);
		    	}
			}
			catch(Exception e) {
				return LstCustDemo;
			}
	    	return LstCustDemo;
		}
		
	}