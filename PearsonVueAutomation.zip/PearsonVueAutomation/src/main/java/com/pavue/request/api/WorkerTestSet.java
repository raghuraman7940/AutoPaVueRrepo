package com.pavue.request.api;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;
import com.pavue.request.api.App;
import com.pavue.webdriver.Log;
import com.pavue.common.core.FileReaderManager;
import com.pavue.common.util.Constants;

public class WorkerTestSet implements Runnable

{
	
  	String ThreadExecType=null;
	public App API=null;
	public String APIServer=null;
	JSONObject jsonTestSet=null;
	public Map<String,String> APIResult= new HashMap<String,String>();
	private static JSONObject jsonTestReportData;
  	public WorkerTestSet() throws IOException
  	{
  		Log._logInfo("Initialize App Constructor");
  		API=new App();
  		jsonTestReportData = new JSONObject();
  		
  	}
	public WorkerTestSet(JSONObject jsTestSet, String ThreadExecType)
	{
		//Initialize values
		this.jsonTestSet= jsTestSet;
		this.ThreadExecType=ThreadExecType;
		APIServer=FileReaderManager.getInstance().getJsonReader().getApplicationUrl();
		
	}
	
	 /**************************************************************************
     *  Function name 		: run
     *  Reuse Function 		:
     *  Description 		: Execute non dependent test cases
     /**********************************************************************/
	public void run()
	{
		Log._logInfo("Run Method :");
		System.out.println(Thread.currentThread().getName()+" (Start) App3 "+ThreadExecType+" :"+jsonTestSet);
		 try {
			 TestExecution(null,jsonTestSet,null,null);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		System.out.println(Thread.currentThread().getName()+" (End) App3 "+ThreadExecType+" :"+jsonTestSet);//prints thread name
	}
	
	
	/*************************************************************************************************
	 *  Function name 		: TestExecution
	 *  Reuse Function 		: 
	 *  Description 		: Read the JSON Test set values.Based on the inputs flow the functionality. 
	/
	 * @throws ProcessingException 
	 * @throws JiraException **************************************************************************************************/  
    public JSONObject TestExecution(JSONObject jsonTestReportData1,JSONObject Testset, Map<String,Object> ApiHeaders,List<String> UserPermissions) throws IOException
    {
    	JSONObject jsonTestReportData=jsonTestReportData1;
    	String Url,MethodType,Details,TestCaseID = null,DataSetID;
        JSONObject headers =null; 
        JSONObject expected=null;
        JSONObject parameters=null;
        JSONObject output=null;
        JSONArray jsArrayUserPerms = null;
     
        String DataRunMode;
        int iCount=0;
		int SumRespTime=0;
		String OverallStatus = null;
		String sTestResponseDes = null;
        int AvgRespTime=0;
    	String ExecuteType="Sequential";//Parallel//Sequential
        ExecutorService executor = null;
        Map<String,Object> APIResult=null;
		int iThread=1;
		executor = Executors.newFixedThreadPool(iThread);
		try{
			//JSONObject Testset = Testsets.getJSONObject(iTestIter);
			TestCaseID = Testset.get(Constants.TCID).toString();
        	sTestResponseDes="DataSetID"+Constants.ValueDelimiter+"TestStatus"+Constants.ValueDelimiter+"ResponseDescription"+Constants.ValueDelimiter+"	ResponseTime"+Constants.ValueDelimiter+"OutValues";
    		OverallStatus=Constants.KEYWORD_PASS;
    		
             Url = Testset.get(Constants.URL).toString();
             MethodType = Testset.get(Constants.MethodType).toString();
             Details = Testset.get(Constants.Summary).toString();
         
             JSONArray DataSets1 = (JSONArray) Testset.get("Datasets");
             for (int iDataItr = 0; iDataItr < DataSets1.length(); iDataItr++) {
				JSONObject DataSet = DataSets1.getJSONObject(iDataItr);
				//System.out.println(DataSet.get("DatasetID"));
				DataSetID = DataSet.get(Constants.DATASET).toString();
				DataRunMode= DataSet.get(Constants.DATAFLAG).toString();
				if (DataRunMode.equalsIgnoreCase("YES")){
				    headers = DataSet.getJSONObject(Constants.headers);
		             parameters=DataSet.getJSONObject(Constants.requestparameters);
		             expected = DataSet.getJSONObject(Constants.expected);
		             
		             jsArrayUserPerms = (JSONArray) DataSet.get(Constants.UserPermissions);
		            
	                if (ExecuteType.contains("Parallel")) {
						// Execute Concurrent in Thread
//						Runnable worker = new App(DriverScript.jsonTestReportData,TestCaseID,DataSetID,Details,APIServer,APIURL, MethodType, HeaderKey,HeaderValues,ParamKey, ParamValues,OpKey, SwitchingMode, ExpectedKeys, ExpectedValues, ExpectedStatusCode, ExpectedSchemaPath,"DataSet");
//						executor.execute(worker);// calling execute
					}
					else{
						 Log._logInfo("Execute Test Dataset "+TestCaseID+"_"+DataSetID);
						APIResult=API.APICall(jsonTestReportData,Testset,TestCaseID,DataSetID,Details,Url, MethodType, headers,parameters,expected,jsArrayUserPerms,ApiHeaders,UserPermissions);
						
						iCount=iCount+1;
		                //System.out.println(TestCaseID+"-"+DataSetID+":"+APIResult.get("APIStatus"));
		                DataSet.put("headers", APIResult.get("headers"));
		                DataSet.put("parameters", APIResult.get("parameters"));
		                DataSet.put("expected", APIResult.get("expected"));
		                DataSet.put("APIURL", APIResult.get("APIURL"));
		                if (APIResult.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_FAIL)){
							 OverallStatus=Constants.KEYWORD_FAIL;
						 }
		                else if ((APIResult.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_SKIP))&&(!OverallStatus.equalsIgnoreCase(Constants.KEYWORD_FAIL))){
	 							OverallStatus=Constants.KEYWORD_SKIP;
	 					}
		                
		                output = DataSet.getJSONObject(Constants.output);
		                sTestResponseDes=sTestResponseDes+"\n"+DataSetID+Constants.ValueDelimiter+APIResult.get("APIStatus")+Constants.ValueDelimiter+APIResult.get("ApiDescription")+Constants.ValueDelimiter+APIResult.get("responseTime")+Constants.ValueDelimiter+APIResult.get("Output_Values")+"\n";
		            	if(APIResult.get("responseTime")!=null)
							 SumRespTime = SumRespTime+Integer.parseInt(APIResult.get("responseTime").toString().replaceAll("\\D+",""));
		            	output.put("TestResultStatus", APIResult.get("APIStatus"));
		            	output.put("ResponseDescription", APIResult.get("ApiDescription"));
		            	output.put("ResponseTime", APIResult.get("responseTime")+" ms");
		            	output.put("Output_Values", APIResult.get("Output_Values"));
		            	output.put("Response", APIResult.get("resString"));
		            	output.put("ResponseFilePath", APIResult.get("ResponseFilePath"));
		            	output.put("StatusCode", APIResult.get("Statuscode"));
					}
				}
            }
            if (ExecuteType.contains("Parallel")) {
 	 			executor.shutdown();
 	 			// Wait Till all thread complete
 	 			while (!executor.isTerminated()) {
 	 			}
 	 			
 	 			System.out.println("DataSet Finished all threads");
 	 			for (int k = 0; k < DataSets1.length(); k++) {
 	 				JSONObject DataSet = DataSets1.getJSONObject(k);
 	 				//System.out.println(DataSet.get("DatasetID"));
 	 				iCount=iCount+1;
 	 				DataSetID = DataSet.get(Constants.DATASET).toString();
 	 				for (Map<String, Object> mapDataSet : App.lstDataSetresult) {
 	 					//Report in Testdata sheet
 	 					if ((TestCaseID.equalsIgnoreCase(mapDataSet.get("TestCaseID").toString()))&&(DataSetID.equalsIgnoreCase(mapDataSet.get("DataSetID").toString())))
 	 					{
 	 						
 	 						//System.out.println("Dataset"+TestCaseID+"-"+DataSetID+":"+mapDataSet.get("APIStatus"));
 	 						DataSet.put("HeaderKeyValue", mapDataSet.get("HeaderKeyValue"));
 	 						DataSet.put("Input_KeyValues", mapDataSet.get("InputValues"));
 	 						DataSet.put("Expected", mapDataSet.get("GivenExpectedValues"));
 	 						DataSet.put("APIURL", mapDataSet.get("APIURL"));
 	 						if (mapDataSet.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_FAIL)){
 	 							OverallStatus=Constants.KEYWORD_FAIL;
 	 						}
 	 						else if (mapDataSet.get("APIStatus").toString().equalsIgnoreCase(Constants.KEYWORD_SKIP)){
 	 							OverallStatus=Constants.KEYWORD_SKIP;
 	 						}
 	 						sTestResponseDes=sTestResponseDes+"\n"+DataSetID+Constants.ValueDelimiter+mapDataSet.get("APIStatus")+Constants.ValueDelimiter+mapDataSet.get("ApiDescription")+Constants.ValueDelimiter+mapDataSet.get("responseTime")+Constants.ValueDelimiter+mapDataSet.get("Output_Values")+"\n";
 	 						if(mapDataSet.get("responseTime")!=null)
 	 							SumRespTime = SumRespTime+Integer.parseInt(mapDataSet.get("responseTime").toString().replaceAll("\\D+",""));
 	 						DataSet.put("TestResultStatus", mapDataSet.get("APIStatus"));
 	 						DataSet.put("ResponseDescription", mapDataSet.get("ApiDescription"));
 	 						DataSet.put("ResponseTime", mapDataSet.get("responseTime")+" ms");
 	 						DataSet.put("Output_Values", mapDataSet.get("Output_Values"));
 	 						DataSet.put("Response", mapDataSet.get("resString"));
 	 						DataSet.put("ResponseFilePath", mapDataSet.get("ResponseFilePath"));
 	 						
 	 						//System.out.println("Data Binding :"+sTestResponseDes);
 	 					}
 	 				}
 	 			}
    	}
        Testset.put(Constants.TestStatus, OverallStatus);
//        if (iCount>0)
//    		AvgRespTime=SumRespTime/iCount;
//        Testset.put("AvgResponseTime", String.valueOf(AvgRespTime)+" ms");
//	 	
	 	
        jsonTestReportData.append("Tests", Testset);
    	
	}
	catch(Exception e){
	    e.printStackTrace();
	}
	return jsonTestReportData;
   }
	
	
	}