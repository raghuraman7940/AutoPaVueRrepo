package com.pavue.request.api;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import com.pavue.request.api.DriverScript;
import com.pavue.webdriver.Log;
import com.pavue.request.api.App;
import com.pavue.common.core.CommonFunctions;
import com.pavue.common.core.FileReaderManager;
import com.pavue.common.util.Constants;

import io.restassured.path.json.JsonPath;

public class DriverScript {

	//App Object creation;
	public static App API;
	public static WorkerTestSet wTestSet;
	public static ReportJSON RepJs;
	// properties
	//public static Properties CONFIG;
	public static List<String> DependentList;
	private static JSONObject jsonTestReportData;
	public static DriverScript test =null;
	public static String contenttype="";
	public static String orgreferenceid="";
	public static String authorization="";
	
	/**
	 * 
	 * Constructor for initializing the log, properties and Object.
	 * 
	 */
	public DriverScript() throws NoSuchMethodException, SecurityException, IOException {
		// Initialize the app logs
		//Log._logInfo("Start API Automation testing");
		wTestSet=new WorkerTestSet();
		DependentList = new ArrayList<String>();
		jsonTestReportData = new JSONObject();	
		API=new App();
		RepJs=new ReportJSON();
		
	}
	
	public static void main(String[] args) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, NoSuchMethodException, SecurityException, ParseException {
	
		//Initialize objects
		API = new App();
		test = new DriverScript();				
		
		//Set Header values
		contenttype= "application/json";
		orgreferenceid="d3d6bc4e-2bb1-41b2-865b-52c0a6c23e75";
		authorization="Bearer eyJraWQiOiJCNVwvNzF0dk8rVjFDVTFXMWVpcGJ4a0JiM3NsVXYrN3VJWkdnd2lMcktWQT0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI0NzBhMDI4Yi0yZjk3LTQxOTEtOTIxNS0wNmUzOTExMTA2MmIiLCJldmVudF9pZCI6IjYzMjQ4NDhhLTUxZGMtNDk4NC1iYjdmLTdkN2U5ZmE5MDA3OCIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiYXdzLmNvZ25pdG8uc2lnbmluLnVzZXIuYWRtaW4gb3BlbmlkIGVtYWlsIiwiYXV0aF90aW1lIjoxNjAzNzY2OTY0LCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0xLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMV81dGdDZVdPaTkiLCJleHAiOjE2MDM3NzA1NjYsImlhdCI6MTYwMzc2Njk2NiwidmVyc2lvbiI6MiwianRpIjoiNWNkZTI5ODItMWFkOS00ZjZhLTkxN2EtYjUyMmEwMDQwYTQ4IiwiY2xpZW50X2lkIjoiMWo0NWR1NmRva2Jmc2VxM2Vvb2Zqb3FrMjYiLCJ1c2VybmFtZSI6IjQ3MGEwMjhiLTJmOTctNDE5MS05MjE1LTA2ZTM5MTExMDYyYiJ9.lKAzDDg5QmRrPl7rSPKrFFU0Ro_QLju1PG2FxBfkxuwRYTMkNE1KDVEZ3fSaYd6QMep7HItkcs8WRq_pkTPFLGsegE7eIJ6Kx-OEKb4c5iLl8AUXdEE_deho8-J5EpIqw3z24mLv7OgEHstW6HnJCh4xBnJ1S2wNtIUM6VjqY6yeqma4ui_OL6SEAHsel6IVWTGmcLyNNm6f4IxA3ckx2VPfgN23KXx2YVJVbUFgID_P2HCi6LPQIhMAzUKO2ipct5EAABVZp_5KyKQFol2aioXtivWdCY4hfjrpDXv9YzPDSWUQZx1RRshgLjAA9QuivnSHaCEw1uUt27aVl3hxvw";
		
		HashMap<String,Object> MapPerfLogs=  new HashMap<String,Object>();
		MapPerfLogs.put("Content-Type", contenttype);
		MapPerfLogs.put("authorization", authorization);
		MapPerfLogs.put("orgreferenceid", orgreferenceid);

		Constants.APIServer=FileReaderManager.getInstance().getJsonReader().getApplicationUrl();

		String SelectedCustomer="VA";
		String LoginUser="thulasiram.marani+dev6@pearson.com";
		
//		//Automation Clean Up
//		test.AutomationDataCleanUp(MapPerfLogs);
//		requests.getOAuthTokenWithClientCredential("externaldev");

		Constants.APIServer=FileReaderManager.getInstance().getJsonReader().getApplicationUrl();
		test.startNewDriverScript("excel","APIRegressionSUITE","System Admin","regression",MapPerfLogs.get("authorization").toString(),MapPerfLogs.get("orgreferenceid").toString(),Constants.PERMISSIONS); //APISmokeSUITE//APIRegressionSUITE//APIUserroleSUITE
	}
		
	/***************************************************************************************
  	 *  Function name 		: startDriverScript
  	 *  Reuse Function 		:  
  	 *  Description 		: Start Execution
  	/****************************************************************************************/ 
	public String startNewDriverScript(String InputType,String SuiteName, String userrole, String Testingtype,String AuthToken,String Orgrefid,List<String> UserPermissions) throws NoSuchMethodException, SecurityException, IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	
		// Initialize and execute
		JSONObject jsonRep=null;
		String GenReportname=null;
		String GenJsOutputReportfile=null;
		String GenJsOutputfile=null;
		String Testdatafile="";
		JSONObject JsonTestData =null;
		String Executiontime;
		Map<String,Object> ApiHeaders = new HashMap<String,Object>();
		String contenttype= "application/json";
		try {
			Log._logInfo("Start Driver Script with API Test suite : "+SuiteName);
			jsonTestReportData = new JSONObject();
		    //Reponse Folder
		    File ResponseDir= new File(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Response");
		    if (!ResponseDir.exists()) 
		    	ResponseDir.mkdirs();
		    
		    //Suite Setup
		    Constants.TEST_SHEET=SuiteName;
		    String userrole1=userrole.replace(" ", "");
	    	userrole=userrole1.replace("-", "_");
		    Constants.BuildReleaseVersion="525";
		    if (SuiteName.equalsIgnoreCase("APIUserroleSUITE")) {
		    	Testdatafile=Constants.TEST_JSFILE_UserRole;
		    }
		    else if (SuiteName.equalsIgnoreCase("APIRegressionSUITE")) {
		    	Testdatafile=Constants.TEST_JSFILE_Regression;
		    }
		    else{
		    	Testdatafile=Constants.TEST_JSFILE_Smoke;
		    }
		    
		    if (InputType.equalsIgnoreCase("excel")) {
		    	JSONObject JsonGLBHeader = new JSONObject();
			    JsonGLBHeader.put("content-type", contenttype);
				JsonGLBHeader.put("orgreferenceid", Orgrefid);
				JsonGLBHeader.put("authorization", AuthToken);
				ApiHeaders=CommonFunctions.toMap(JsonGLBHeader);
		    	//Export test from Excel
		        String XlsxInputFile = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() +Constants.TEST_XLFILE;	
				JsonTestData =RepJs.GenerateTestDataFromExcelData(XlsxInputFile,Constants.TEST_SHEET,JsonGLBHeader);
				//Export Input json to Response folder
				API.StoreRespose("TestdataInputData","json",JsonTestData.toString());
		    }
		    else {
		    	ApiHeaders.put("content-type", contenttype);
		    	ApiHeaders.put("orgreferenceid",Orgrefid);
		    	ApiHeaders.put("authorization",AuthToken);
				
		    	// Export Suite Tests from JSON File
			    String TestFilePath = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath()+Testdatafile;
				File file = new File(TestFilePath); 			
				String jsoncontent = FileUtils.readFileToString(file, "utf-8");
				JsonTestData = new JSONObject(jsoncontent);
		    }
			
		      	
			if (JsonTestData!=null) {
				//Get Start time taken
				long startTime = System.currentTimeMillis();
				// Main driver function, read from JSON/excel and execute
				JSONObject jsRepData=ReadJSON_Data(JsonTestData,ApiHeaders,UserPermissions);
			
				//Calculate execution time taken
				long endTime   = System.currentTimeMillis();

		    	long totalTime = endTime - startTime;
				System.out.println("Start:End:totalTime  ->"+startTime+":"+endTime+":"+totalTime);
		    	if (totalTime<120000) {
		    		Executiontime=Long.toString(TimeUnit.MILLISECONDS.toSeconds(totalTime))+" Secs";
		    		Constants.ExecutionDuration=Long.toString(TimeUnit.MILLISECONDS.toSeconds(totalTime));
		    		Constants.TimeType=" Secs";
		    	}
		    	else {
		    		Executiontime=Long.toString(TimeUnit.MILLISECONDS.toMinutes(totalTime))+" Mins";
		    		Constants.ExecutionDuration=Long.toString(TimeUnit.MILLISECONDS.toMinutes(totalTime));
		    		Constants.TimeType=" Mins";
		    	}
		    	
				//Generate report
		    	GenJsOutputfile=API.StoreRespose("TestdataOutputData_"+userrole,"json",jsRepData.toString());
		    	Constants.mapUserroleJsonOutputfiles.put(userrole, GenJsOutputfile);
		    	jsonRep= RepJs.NewBuildJSONReport(jsRepData,userrole,Testingtype);
		    	GenJsOutputReportfile=API.StoreRespose("TestdataReport_"+userrole,"json",jsonRep.toString());
		    	Constants.mapUserroleJsonReportfiles.put(userrole, GenJsOutputReportfile);
		    	GenReportname=RepJs.GeneratehtmlReport(jsonRep,userrole);
		    	Constants.mapUserrolehtmlReportfiles.put(userrole, GenReportname);
			}
		} 
		 catch (FileNotFoundException e) 
        {
			 System.out.println("FileNotFoundException: "+e.getMessage());
        	e.printStackTrace();
        } 
		catch (IOException e) 
        {
			System.out.println("IOException: "+e.getMessage());
        	e.printStackTrace();
        }  
		catch (Exception e) 
        {
			System.out.println("Exception: "+e.getMessage());
        	e.printStackTrace();
        }
		return GenReportname;
	}
	
	
	
	/***************************************************************************************
  	 *  Function name 		: startDriverScript
  	 *  Reuse Function 		:  
  	 *  Description 		: Start Execution
  	/****************************************************************************************/ 
	public String startDriverScript(String InputType,String SuiteName) throws NoSuchMethodException, SecurityException, IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	
		// Initialize and execute
		JSONObject jsonRep=null;
		String GenReportname=null;
		String userrole="";
		String Testdatafile="";
		JSONObject JsonTestData =null;
		List<String> UserPermissions=null;
		
		Map<String,Object> ApiHeaders = new HashMap<String,Object>();
		try {
			Log._logInfo("Start Driver Script with API Test suite : "+SuiteName);
			jsonTestReportData = new JSONObject();
		    //Reponse Folder
		    File ResponseDir= new File(System.getProperty("user.dir")+Constants.SRC_RES_FILEPATH+"Response");
		    if (!ResponseDir.exists()) 
		    	ResponseDir.mkdirs();
		    
		    //Suite Setup
		    Constants.TEST_SHEET=SuiteName;
		    Constants.BuildReleaseVersion="525";
		    if (SuiteName.equalsIgnoreCase("APIUserroleSUITE")) {
		    	Testdatafile=Constants.TEST_JSFILE_UserRole;
		    	String userrole1=Constants.LOGGEDINUSERROLE.replace(" ", "");
		    	userrole=userrole1.replace("-", "_");
		    	userrole="_"+userrole;
		    	Constants.TestingType=Constants.TEST_UserRoleType;
		    }
		    else if (SuiteName.equalsIgnoreCase("APIRegressionSUITE")) {
		    	Testdatafile=Constants.TEST_JSFILE_Regression;
		    	Constants.TestingType=Constants.TEST_RegressionType;
		    }
		    else
		    {
		    	Testdatafile=Constants.TEST_JSFILE_Smoke;
		    	Constants.TestingType=Constants.TEST_SmokeType;
		    }
		    if (InputType.equalsIgnoreCase("excel")) {
		    	JSONObject JsonGLBHeader = new JSONObject();
			    JsonGLBHeader.put("content-type", contenttype);
				JsonGLBHeader.put("orgreferenceid", orgreferenceid);
				JsonGLBHeader.put("authorization", authorization);
				ApiHeaders=CommonFunctions.toMap(JsonGLBHeader);
		    	//Export test from Excel
		        String XlsxInputFile = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() +Constants.TEST_XLFILE;	
				JsonTestData =RepJs.GenerateTestDataFromExcelData(XlsxInputFile,Constants.TEST_SHEET,JsonGLBHeader);
				//Export Input json to Response folder
				API.StoreRespose("TestdataInputData","json",JsonTestData.toString());
		    }
		    else {
		    	// Export Suite Tests from JSON File
			    String TestFilePath = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath()+Testdatafile;
				File file = new File(TestFilePath); 			
				String jsoncontent = FileUtils.readFileToString(file, "utf-8");
				JsonTestData = new JSONObject(jsoncontent);
		    }
			
		      	
			if (JsonTestData!=null) {
				//Get Start time taken
				long startTime = System.currentTimeMillis();
				// Main driver function, read from JSON/excel and execute
				JSONObject jsRepData=ReadJSON_Data(JsonTestData,ApiHeaders,UserPermissions);
			
				//Calculate execution time taken
				long endTime   = System.currentTimeMillis();
		    	long totalTime = endTime - startTime;
		    	if (totalTime<350) {
		    		Constants.ExecutionDuration=Long.toString(TimeUnit.MILLISECONDS.toSeconds(totalTime));
		    		Constants.TimeType=" Secs";
		    	}
		    	else {
		    		Constants.ExecutionDuration=Long.toString(TimeUnit.MILLISECONDS.toMinutes(totalTime));
		    		Constants.TimeType=" Mins";
		    	}
		    	
				//Generate report
		    	API.StoreRespose("TestdataOutputData","json",jsRepData.toString());
		    	jsonRep= RepJs.BuildJSONReport(jsRepData);
		    	API.StoreRespose("TestdataReport","json",jsonRep.toString());
		    	GenReportname=RepJs.GeneratehtmlReport(jsonRep,userrole);
		    	
			}
	    	
		} 
		 catch (FileNotFoundException e) 
        {
			 System.out.println("FileNotFoundException: "+e.getMessage());
        	e.printStackTrace();
        } 
		catch (IOException e) 
        {
			System.out.println("IOException: "+e.getMessage());
        	e.printStackTrace();
        }  
		catch (Exception e) 
        {
			System.out.println("Exception: "+e.getMessage());
        	e.printStackTrace();
        }
		return GenReportname;
	}
	
	/*************************************************************************************************
	 *  Function name 		: ReadJSON_Data
	 *  Reuse Function 		: 
	 *  Description 		: Read the all the Excel values.Based on the inputs flow the functionality. 
	/
	 * @throws ProcessingException 
	 * @throws JiraException **************************************************************************************************/  
    public JSONObject ReadJSON_Data(JSONObject JsonTestData, Map<String,Object> ApiHeaders,List<String> UserPermissions)throws AbstractMethodError,  IOException
    {
        String TestCaseID,TestRunMode;
		JSONObject jsTestData = JsonTestData;
		String ExecuteType="Sequential";//Parallel//Sequential
		boolean bConExecution=false;
		long startTime =0;
		long endTime =0;
		long totalTime=0;
		String Executiontime=null;
        ExecutorService executor = null;
		int iThread=Integer.parseInt("1");
		executor = Executors.newFixedThreadPool(iThread);
		List<String> DependentList = new ArrayList<String>();;
		JSONObject jsonTestReportData = new JSONObject();
		startTime = System.currentTimeMillis();
		jsonTestReportData.put(Constants.JSReportTitle, "API Automation Test Report");
		Date d = new Date();
		jsonTestReportData.put(Constants.JSRunDate, d.toString());
		JSONObject GLBHeader = jsTestData.getJSONObject(Constants.GlobalHeader);
		//Check wheather dependent or non dependent
		boolean bDependent=VerifyDependents(jsTestData,"Tests.Dependent.operationId","Tests.operationId");
		//Tests
        JSONArray TestSets = (JSONArray) jsTestData.get("Tests");
        for (int iTestIter = 0; iTestIter < TestSets.length(); iTestIter++) {
        	
        	//System.out.println("DependentList : "+DependentList);
        	JSONObject Testset = TestSets.getJSONObject(iTestIter);
            TestRunMode = Testset.get(Constants.TESTRUNMODE).toString();
            TestCaseID = Testset.get(Constants.TCID).toString();
            if ((TestRunMode.equalsIgnoreCase("YES"))&&(!DependentList.contains(TestCaseID))){
                //Execute Dependents Issues
                JSONArray DependentTests = (JSONArray) Testset.get("Dependent");
               // System.out.println("DependentTests Length: "+DependentTests.length());	
                if(DependentTests.length()>0){
	                for (int iDepenIter = 0; iDepenIter < DependentTests.length(); iDepenIter++) {
	                	JSONObject DependentTest = DependentTests.getJSONObject(iDepenIter);
	                	System.out.println("DependentTest : "+DependentTest.toString());	
	                	String FilterQuery="Tests.findAll{Tests->Tests.operationId==datefilter}";
	                	String FilterValue=DependentTest.get("operationId").toString();
	                	if (!DependentList.contains(FilterValue)){
	                		DependentList=DependentIssueExecution(jsTestData, FilterQuery,FilterValue,ApiHeaders,DependentList,UserPermissions);
	                	}
	                }
	                Log._logInfo("Execute Testset :"+TestCaseID);
	                //Sequential Execution
	                jsonTestReportData=wTestSet.TestExecution(jsonTestReportData,Testset,ApiHeaders,UserPermissions);
                	DependentList.add(TestCaseID);
					//System.out.println("Seq: "+jsonTestReportData);	
                }
                else{
                	if ((ExecuteType.contains("Parallel"))&(!bDependent)) {
                		// Execute Concurrent in Thread
                		bConExecution=true;
                		DependentList.add(TestCaseID);
						Runnable worker = new WorkerTestSet(Testset,"Testset");
						executor.execute(worker);// calling execute
						//System.out.println("Concurrent Report: "+jsonTestReportData);
                	}
                	else{
                		Log._logInfo("Execute Testset : "+TestCaseID);
                		jsonTestReportData=wTestSet.TestExecution(jsonTestReportData,Testset,ApiHeaders,UserPermissions);
                		DependentList.add(TestCaseID);
                		//System.out.println("Sequential Report: "+jsonTestReportData);
					}
                }
            }
         }
        if ((ExecuteType.contains("Parallel"))&(bConExecution)) {
 			executor.shutdown();
 			// Wait Till all thread complete
 			while (!executor.isTerminated()) {
 			}
 			System.out.println(" DataSet Finished all threads");
	 	}
        endTime   = System.currentTimeMillis();
    	totalTime = endTime - startTime;
    	if (totalTime<120000) 
    		Executiontime=Long.toString(TimeUnit.MILLISECONDS.toSeconds(totalTime))+" Secs";
    	else 
    		Executiontime=Long.toString(TimeUnit.MILLISECONDS.toMinutes(totalTime))+" Mins";
    	
    	jsonTestReportData.put(Constants.JSExecutionDuration, Executiontime);
        //System.out.println(JsonTestData);
        return jsonTestReportData;
    }
    
    
	/*************************************************************************************************
	 *  Function name 		: DependentIssueExecution
	 *  Reuse Function 		: 
	 *  Description 		: Read the dependent issues and execute first. 
	/
	 * @throws ProcessingException 
	 * @throws JiraException **************************************************************************************************/ 
    public List<String> DependentIssueExecution(JSONObject JsonTestData, String FilterQuery,String FilterValue,Map<String,Object> ApiHeaders,List<String> DependentList,List<String> UserPermissions) throws IOException
    {
    	String TestCaseID = null;
        JSONArray Testsets = null;
        try{
         	if (!DependentList.contains(FilterValue)){
		        JsonPath jsonResponse = new JsonPath(JsonTestData.toString());
				List<JSONObject> jsText = jsonResponse.param("datefilter", FilterValue).get(FilterQuery);
				Testsets = new JSONArray(jsText);
				for (int iTestIter = 0;iTestIter < Testsets.length(); iTestIter++) {
					JSONObject Testset = Testsets.getJSONObject(iTestIter);
					 TestCaseID = Testset.get(Constants.TCID).toString();
		        	if (!DependentList.contains(TestCaseID)){
		        		JSONArray DependentTests = (JSONArray)Testset.get("Dependent");
		        		for (int iDepenIter = 0; iDepenIter < DependentTests.length(); iDepenIter++) {
		        			JSONObject DependentTest = DependentTests.getJSONObject(iDepenIter);
		        			String Query="Tests.findAll{Tests->Tests.operationId==datefilter}";
		        			String QueryValue=DependentTest.get("operationId").toString();
		        			if (!DependentList.contains(QueryValue)){
		        				DependentIssueExecution(JsonTestData, Query,QueryValue,ApiHeaders,DependentList,UserPermissions);
		        			}
		        		}
		        		Log._logInfo("Execute Dependent Test "+TestCaseID);
		        		//System.out.println("Exec Dependent : "+TestCaseID+" --- "+DependentList);	
		        		jsonTestReportData=wTestSet.TestExecution(jsonTestReportData,Testset,ApiHeaders,UserPermissions);
			        	DependentList.add(TestCaseID);
	        		}
				}
         	}
        }
        catch(Exception e){
        	e.printStackTrace();
        }
        return DependentList;
    }

    /*************************************************************************************************
	 *  Function name 		: VerifyDependents
	 *  Reuse Function 		: 
	 *  Description 		: Verify whether Dependents issues in test data
	/**************************************************************************************************/ 
	public static boolean VerifyDependents(JSONObject JsonTestData,String Key, String Key2)
    {   	
		Log._logInfo("Dependents checking ");
    	boolean retnValue=false;
	    try {
	    	JsonPath jsonResponse = new JsonPath(JsonTestData.toString());
	    	List<List<String>> jsText = jsonResponse.get(Key);
			 for (List<String> map :jsText) {
				 for(String Issuekey:map){
					 if(Issuekey.length()>0) {
						 retnValue=true;
//						 ReString=jsonResponse.getString(Key2);
//						 if(ReString.contains(Issuekey))
//						 {
//							 //System.out.println("Contains: "+s);
//						 }
					 }
				 }
			 }
	      } 
	      catch (Exception e){
	    	e.printStackTrace();
	      }        	      
     	  return retnValue;
      } 
	
	
	 
}